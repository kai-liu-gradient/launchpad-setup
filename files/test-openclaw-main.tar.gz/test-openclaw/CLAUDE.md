# Project Configuration

## Project Type
This is a Node.js + React full-stack web project (Express.js backend, Vite-built React SPA frontend).

## Project Overview
- **OpenClaw Launcher** — a web-based management UI for configuring and monitoring the OpenClaw AI agent gateway
- The launcher manages `~/.openclaw/openclaw.json` configuration, monitors the `openclaw-gateway` PM2 process, and provides a setup wizard for first-time configuration
- See `pd/definitions/openclaw.md` for detailed OpenClaw architecture and concepts

## Project Architecture
- **Backend**: Express API at `/api/openclaw/*` with service-oriented architecture (`src/routes/`, `src/services/`, `src/middleware/`)
- **Frontend**: React 19 SPA with React Router, built with Vite (`src/frontend/`)
- **Services**: `openclaw-config`, `credential-discovery`, `telegram-setup`, `pm2-health`, `workspace-browser`
- See `pd/rules/api-conventions.md` for API route reference and conventions
- See `pd/rules/error-handling.md` for error handling patterns across all layers

## Key Paths
- OpenClaw config: `~/.openclaw/openclaw.json`
- OpenClaw workspace: `~/.openclaw/workspace`
- OpenClaw gateway: PM2 process `openclaw-gateway` on port 18789
- Frontend source: `src/frontend/` (built to `dist/`)
- Backend routes: `src/routes/openclaw.js`
- Backend services: `src/services/*.js`
- Middleware: `src/middleware/validation.js`

## Code Organization
- Avoid putting all logic in `server.js`; organize into `src/routes/`, `src/services/`, `src/middleware/`
- Routes handle HTTP concerns only; delegate business logic to services
- Services throw descriptive errors; routes map them to HTTP status codes
- Config responses must always be sanitized (secrets masked) before sending to frontend
- Workspace file access must pass path traversal safety checks

## Development Environment

### PM2 Process Manager
- The application runs via PM2 at **port 3000**
- Process name: `web`
- PM2 executes `npm start` → `scripts/dev.js` for development mode
- Log files:
  - Output: `/var/log/pm2/web-out.log`
  - Errors: `/var/log/pm2/web-error.log`

### Useful PM2 Commands
```bash
pm2 list              # List all processes
pm2 logs web          # View logs for web process
pm2 restart web       # Restart the web process
pm2 show web          # Show detailed process info
```

### Development vs Production
- **`npm start` / `npm run dev`**: Runs `scripts/dev.js` which spawns `node --watch server.js` (backend auto-restart) + `vite build --watch` (frontend incremental rebuilds). All env vars from PM2 pass through naturally.
- **`npm run prod`**: Builds frontend once (`vite build`), then runs `node server.js`. Single process, no watchers.

## Versioning
- Use date-based versioning in `package.json`: `YYYY.M.D.patch` (e.g., `2026.2.28.0`)
- When bumping the version, update to the current date with `.0` patch, or increment the patch number if releasing multiple times on the same day
- The version is displayed in the sidebar footer (bottom-left, below Sign Out) via `__APP_VERSION__` injected by Vite from `package.json`. Whenever the version is bumped, rebuild the frontend (`npm run build:frontend`) so the displayed version updates

## Entry Point
- Main file: `server.js`

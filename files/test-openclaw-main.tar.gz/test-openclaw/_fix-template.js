const fs = require('fs');
const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>My App</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="container">
    <h1>My App</h1>
    <p>Edit <code>public/index.html</code> and <code>server.js</code> to get started.</p>
    <div class="status-card" id="status" style="display:none">
      <span class="status-dot"></span>
      <span id="status-text"></span>
    </div>
  </div>

  <script>
    fetch("/api/status")
      .then(function(r) { return r.json(); })
      .then(function(data) {
        document.getElementById("status-text").textContent = "Server up for " + Math.round(data.uptime) + "s";
        document.getElementById("status").style.display = "";
      })
      .catch(function(err) { console.error("API error:", err); });
  </script>
</body>
</html>
`;
fs.writeFileSync('/workspace/skills/webapp-projects/templates/hybrid-spa/public/index.html', html);
console.log('ok');

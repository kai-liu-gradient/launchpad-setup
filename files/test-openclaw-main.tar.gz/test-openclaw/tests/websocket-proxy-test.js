#!/usr/bin/env node

/**
 * Gateway WebSocket Proxy Integration Test
 *
 * Verifies that WebSocket upgrade through /gateway/ path is proxied
 * correctly to the OpenClaw gateway. Expects the gateway to be running
 * on the configured port (default 18789).
 *
 * Usage: node tests/websocket-proxy-test.js [launcher-port]
 */

const http = require('http');
const crypto = require('crypto');

const LAUNCHER_PORT = process.argv[2] || 3000;
const LAUNCHER_HOST = '127.0.0.1';

function testHttpProxy() {
  return new Promise((resolve) => {
    console.log(`[Test] HTTP proxy: GET http://${LAUNCHER_HOST}:${LAUNCHER_PORT}/gateway/`);

    const req = http.get({
      host: LAUNCHER_HOST,
      port: LAUNCHER_PORT,
      path: '/gateway/',
      timeout: 5000,
    }, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        if (res.statusCode === 502) {
          console.log('[Test] HTTP proxy: 502 — gateway not running (proxy is working, gateway is down)');
          resolve({ pass: true, note: 'Gateway offline but proxy responded correctly' });
        } else if (res.statusCode >= 200 && res.statusCode < 400) {
          console.log(`[Test] HTTP proxy: ${res.statusCode} — gateway reachable through proxy`);
          resolve({ pass: true, note: `Status ${res.statusCode}` });
        } else {
          console.log(`[Test] HTTP proxy: unexpected status ${res.statusCode}`);
          resolve({ pass: false, note: `Unexpected status ${res.statusCode}` });
        }
      });
    });

    req.on('error', (err) => {
      console.log(`[Test] HTTP proxy: connection error — ${err.message}`);
      resolve({ pass: false, note: err.message });
    });

    req.on('timeout', () => {
      req.destroy();
      console.log('[Test] HTTP proxy: timeout');
      resolve({ pass: false, note: 'Timeout' });
    });
  });
}

function testWebSocketUpgrade() {
  return new Promise((resolve) => {
    console.log(`[Test] WS upgrade: ws://${LAUNCHER_HOST}:${LAUNCHER_PORT}/gateway/`);

    const key = crypto.randomBytes(16).toString('base64');
    const req = http.request({
      host: LAUNCHER_HOST,
      port: LAUNCHER_PORT,
      path: '/gateway/',
      method: 'GET',
      headers: {
        'Connection': 'Upgrade',
        'Upgrade': 'websocket',
        'Sec-WebSocket-Key': key,
        'Sec-WebSocket-Version': '13',
      },
      timeout: 5000,
    });

    req.on('upgrade', (res, socket) => {
      console.log('[Test] WS upgrade: 101 Switching Protocols — WebSocket upgrade successful');
      socket.destroy();
      resolve({ pass: true, note: 'WebSocket upgrade succeeded' });
    });

    req.on('response', (res) => {
      res.resume();
      if (res.statusCode === 502) {
        console.log('[Test] WS upgrade: 502 — gateway not running (proxy correctly returned error)');
        resolve({ pass: true, note: 'Gateway offline but proxy handled upgrade correctly' });
      } else {
        console.log(`[Test] WS upgrade: HTTP ${res.statusCode} (no upgrade)`);
        resolve({ pass: false, note: `HTTP ${res.statusCode} instead of upgrade` });
      }
    });

    req.on('error', (err) => {
      console.log(`[Test] WS upgrade: error — ${err.message}`);
      resolve({ pass: false, note: err.message });
    });

    req.on('timeout', () => {
      req.destroy();
      console.log('[Test] WS upgrade: timeout');
      resolve({ pass: false, note: 'Timeout' });
    });

    req.end();
  });
}

function testGatewayWsHealthEndpoint() {
  return new Promise((resolve) => {
    console.log(`[Test] WS health check: GET /api/openclaw/health/gateway/ws`);

    const req = http.get({
      host: LAUNCHER_HOST,
      port: LAUNCHER_PORT,
      path: '/api/openclaw/health/gateway/ws',
      timeout: 5000,
    }, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          const result = JSON.parse(data);
          console.log(`[Test] WS health: ${JSON.stringify(result)}`);
          resolve({ pass: true, note: `wsUpgrade: ${result.wsUpgrade}` });
        } catch (err) {
          resolve({ pass: false, note: `Invalid JSON response: ${err.message}` });
        }
      });
    });

    req.on('error', (err) => {
      resolve({ pass: false, note: err.message });
    });

    req.on('timeout', () => {
      req.destroy();
      resolve({ pass: false, note: 'Timeout' });
    });
  });
}

async function main() {
  console.log('=== Gateway WebSocket Proxy Integration Tests ===\n');

  const results = [];
  results.push({ name: 'HTTP Proxy', ...await testHttpProxy() });
  console.log('');
  results.push({ name: 'WebSocket Upgrade', ...await testWebSocketUpgrade() });
  console.log('');
  results.push({ name: 'WS Health Endpoint', ...await testGatewayWsHealthEndpoint() });

  console.log('\n=== Results ===');
  for (const r of results) {
    console.log(`  ${r.pass ? 'PASS' : 'FAIL'} — ${r.name}: ${r.note}`);
  }

  const failed = results.filter(r => !r.pass);
  if (failed.length > 0) {
    console.log(`\n${failed.length} test(s) failed.`);
    process.exit(1);
  } else {
    console.log('\nAll tests passed.');
  }
}

main().catch((err) => {
  console.error('Test runner error:', err);
  process.exit(1);
});

#!/usr/bin/env node

/**
 * Web Shell WebSocket Integration Test
 *
 * Verifies the terminal WebSocket by:
 * 1. Fetching a shell access token from /api/openclaw/shell/token
 * 2. Opening a WebSocket to /api/openclaw/shell/ws?token=...
 * 3. Sending an input command and verifying output is received
 *
 * Usage: node tests/webshell-test.js [launcher-port]
 */

const http = require('http');
const WebSocket = require('ws');

const LAUNCHER_PORT = process.argv[2] || 3000;
const LAUNCHER_HOST = '127.0.0.1';

function fetchShellToken() {
  return new Promise((resolve, reject) => {
    console.log('[Test] Fetching shell access token...');

    const req = http.get({
      host: LAUNCHER_HOST,
      port: LAUNCHER_PORT,
      path: '/api/openclaw/shell/token',
      timeout: 5000,
    }, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          const result = JSON.parse(data);
          if (result.token) {
            console.log(`[Test] Token received (${result.token.length} chars)`);
            resolve(result.token);
          } else {
            reject(new Error('No token in response'));
          }
        } catch (err) {
          reject(new Error(`Invalid JSON: ${err.message}`));
        }
      });
    });

    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
  });
}

function testUnauthorizedAccess() {
  return new Promise((resolve) => {
    console.log('[Test] Testing unauthorized WebSocket access...');

    const ws = new WebSocket(`ws://${LAUNCHER_HOST}:${LAUNCHER_PORT}/api/openclaw/shell/ws`);
    const timeout = setTimeout(() => {
      ws.close();
      resolve({ pass: false, note: 'Timeout — connection was not rejected' });
    }, 5000);

    ws.on('open', () => {
      clearTimeout(timeout);
      ws.close();
      resolve({ pass: false, note: 'Connection accepted without token (should be rejected)' });
    });

    ws.on('error', () => {
      clearTimeout(timeout);
      console.log('[Test] Unauthorized access correctly rejected');
      resolve({ pass: true, note: 'Correctly rejected unauthorized connection' });
    });

    ws.on('unexpected-response', (req, res) => {
      clearTimeout(timeout);
      console.log(`[Test] Unauthorized access returned HTTP ${res.statusCode}`);
      resolve({ pass: res.statusCode === 401, note: `HTTP ${res.statusCode}` });
    });
  });
}

function testAuthenticatedConnection(token) {
  return new Promise((resolve) => {
    console.log('[Test] Testing authenticated WebSocket connection...');

    const ws = new WebSocket(
      `ws://${LAUNCHER_HOST}:${LAUNCHER_PORT}/api/openclaw/shell/ws?token=${token}`
    );

    let outputReceived = false;
    let outputBuffer = '';
    const timeout = setTimeout(() => {
      ws.close();
      if (outputReceived) {
        resolve({ pass: true, note: 'Connected and received output (timeout while waiting for more)' });
      } else {
        resolve({ pass: false, note: 'Timeout — no output received' });
      }
    }, 10000);

    ws.on('open', () => {
      console.log('[Test] WebSocket connected');
      // Send resize first
      ws.send(JSON.stringify({ type: 'resize', cols: 80, rows: 24 }));
      // Send a simple echo command
      ws.send(JSON.stringify({ type: 'input', data: 'echo "WEBSHELL_TEST_OK"\n' }));
    });

    ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(raw.toString());
        if (msg.type === 'output') {
          outputBuffer += msg.data;
          if (!outputReceived) {
            outputReceived = true;
            console.log('[Test] Receiving terminal output...');
          }
          // Check if our test marker appeared
          if (outputBuffer.includes('WEBSHELL_TEST_OK')) {
            clearTimeout(timeout);
            console.log('[Test] Test marker found in output');
            ws.close();
            resolve({ pass: true, note: 'Command executed and output verified' });
          }
        }
      } catch {
        // Ignore malformed messages
      }
    });

    ws.on('error', (err) => {
      clearTimeout(timeout);
      resolve({ pass: false, note: `Connection error: ${err.message}` });
    });

    ws.on('close', (code) => {
      clearTimeout(timeout);
      if (outputReceived && outputBuffer.includes('WEBSHELL_TEST_OK')) {
        // Already resolved
        return;
      }
      if (outputReceived) {
        resolve({ pass: true, note: 'Connected and received output (marker not found but session works)' });
      } else {
        resolve({ pass: false, note: `Connection closed (code ${code}) without output` });
      }
    });
  });
}

function testTokenStatus() {
  return new Promise((resolve) => {
    console.log('[Test] Testing token status endpoint...');

    const req = http.get({
      host: LAUNCHER_HOST,
      port: LAUNCHER_PORT,
      path: '/api/openclaw/config/token-status',
      timeout: 5000,
    }, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          const result = JSON.parse(data);
          console.log(`[Test] Token status: strength=${result.strength}, length=${result.length}`);
          resolve({ pass: true, note: `strength: ${result.strength}, length: ${result.length}` });
        } catch (err) {
          resolve({ pass: res.statusCode === 404, note: `${res.statusCode} — config may not exist` });
        }
      });
    });

    req.on('error', (err) => {
      resolve({ pass: false, note: err.message });
    });

    req.on('timeout', () => {
      req.destroy();
      resolve({ pass: false, note: 'Timeout' });
    });
  });
}

async function main() {
  console.log('=== Web Shell WebSocket Integration Tests ===\n');

  const results = [];

  // Test token status endpoint
  results.push({ name: 'Token Status API', ...await testTokenStatus() });
  console.log('');

  // Test unauthorized access
  results.push({ name: 'Auth Rejection', ...await testUnauthorizedAccess() });
  console.log('');

  // Fetch token and test authenticated connection
  let token;
  try {
    token = await fetchShellToken();
    results.push({ name: 'Token Fetch', pass: true, note: 'Token obtained' });
  } catch (err) {
    results.push({ name: 'Token Fetch', pass: false, note: err.message });
    console.log('\nCannot proceed with authenticated tests without token.');
  }
  console.log('');

  if (token) {
    results.push({ name: 'Authenticated Session', ...await testAuthenticatedConnection(token) });
    console.log('');
  }

  console.log('=== Results ===');
  for (const r of results) {
    console.log(`  ${r.pass ? 'PASS' : 'FAIL'} — ${r.name}: ${r.note}`);
  }

  const failed = results.filter(r => !r.pass);
  if (failed.length > 0) {
    console.log(`\n${failed.length} test(s) failed.`);
    process.exit(1);
  } else {
    console.log('\nAll tests passed.');
  }
}

main().catch((err) => {
  console.error('Test runner error:', err);
  process.exit(1);
});

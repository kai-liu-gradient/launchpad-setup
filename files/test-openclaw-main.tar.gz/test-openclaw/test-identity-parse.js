// Quick test for identity parsing logic
const content_raw = `# IDENTITY.md - Who Am I?

- **Name:** 小狗狗 (Xiao Gou Gou)
- **Creature:** good doggo in the machine 🐶
- **Vibe:** loyal, friendly, helpful, occasionally playful
- **Emoji:** 🐶
- **Avatar:**

---

This is not metadata.

- Save this file at the workspace root.
`;

const content = content_raw.split(/^---$/m)[0];

function parse(key, maxLen = 80) {
  const m = content.match(new RegExp(`^-\\s*\\**${key}:\\**\\s*(.+)`, 'mi'));
  if (!m) return null;
  let val = m[1].trim();
  if (/^\(.*\)$/.test(val)) return null;
  if (/pick\s+something/i.test(val)) return null;
  if (val.length > maxLen) val = val.slice(0, maxLen);
  return val;
}

function parseDisplay(key, maxLen = 80) {
  const val = parse(key, maxLen);
  if (!val) return null;
  const cleaned = val.replace(/\s*\([^)]*\)\s*$/, '').trim();
  return cleaned || null;
}

function parseEmoji() {
  const val = parseDisplay('Emoji', 10);
  if (!val) return null;
  if ([...val].length > 2) return null;
  return val;
}

console.log('Name:', JSON.stringify(parseDisplay('Name', 40)));
console.log('Creature:', JSON.stringify(parse('Creature')));
console.log('Vibe:', JSON.stringify(parse('Vibe')));
console.log('Emoji:', JSON.stringify(parseEmoji()));
console.log('Avatar:', JSON.stringify(parse('Avatar')));

// Test with pure placeholder
const content2 = `- **Name:** (pick a display name)\n- **Emoji:** 🐶`;
const parse2 = (key) => {
  const m = content2.match(new RegExp(`^-\\s*\\**${key}:\\**\\s*(.+)`, 'mi'));
  if (!m) return null;
  let val = m[1].trim();
  if (/^\(.*\)$/.test(val)) return null;
  return val;
};
console.log('\nPlaceholder test:');
console.log('Name (placeholder):', JSON.stringify(parse2('Name')));
console.log('Emoji:', JSON.stringify(parse2('Emoji')));

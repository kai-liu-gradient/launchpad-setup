#!/bin/bash
# Install openclaw-launcher-cli to ~/.openclaw/tools/launcher-cli
set -e

TOOL_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALL_DIR="$HOME/.openclaw/tools/launcher-cli"

echo "Installing openclaw-launcher-cli..."
echo "  Source: $TOOL_DIR"
echo "  Target: $INSTALL_DIR"

# Create parent directory
mkdir -p "$(dirname "$INSTALL_DIR")"

# Remove existing symlink or directory
if [ -L "$INSTALL_DIR" ]; then
  rm "$INSTALL_DIR"
elif [ -d "$INSTALL_DIR" ]; then
  echo "Warning: $INSTALL_DIR already exists as a directory. Removing..."
  rm -rf "$INSTALL_DIR"
fi

# Copy tool directory
cp -r "$TOOL_DIR" "$INSTALL_DIR"
echo "Copied: $TOOL_DIR -> $INSTALL_DIR"

# Optionally add to PATH via ~/.openclaw/bin
if [ "${1:-}" = "--path" ]; then
  BIN_DIR="$HOME/.openclaw/bin"
  mkdir -p "$BIN_DIR"
  ln -sf "$INSTALL_DIR/bin/launcher-cli.js" "$BIN_DIR/launcher-cli"
  echo "PATH symlink created: $BIN_DIR/launcher-cli"
  echo "Ensure $BIN_DIR is in your PATH."
fi

echo "Done. Run: node $INSTALL_DIR/bin/launcher-cli.js --help"

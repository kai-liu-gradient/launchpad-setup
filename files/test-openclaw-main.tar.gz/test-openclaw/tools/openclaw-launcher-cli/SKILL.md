---
name: launcher-cli
description: |
  Manage Launcher reverse proxy exposures, PM2 services, and marketplace items via CLI. Activate when user wants to register, remove, enable, disable, or control service exposures, manage their PM2 processes, or browse/install marketplace content.
---

# Launcher CLI Tool

Single CLI tool `launcher-cli` for managing reverse proxy exposures, service lifecycle, and marketplace on the OpenClaw Launcher.

Invocation: `launcher-cli <command> [options]`

## Public Access URL

Every Launcher instance has a public domain. Exposed services are accessible at `<public-domain>/open/<slug>/`.

**To find the public domain:** read `~/.pm2/ecosystem.ani-code-daemon.config.js`, find the `PUBLIC_URL` value, and take its origin (scheme + host). For example: `PUBLIC_URL: "https://openclaw-launcher-5883c1.404000000.xyz/.ani-code-callback"` → domain is `https://openclaw-launcher-5883c1.404000000.xyz`. The full URL for a `my-app` exposure is then `https://openclaw-launcher-5883c1.404000000.xyz/open/my-app/`.

Always give users the full public URL. Never say "no public domain" — it always exists in the ecosystem config.

## Command Groups

| Command | Description | Details |
|---------|-------------|---------|
| `expose` | Manage reverse proxy exposures (list, add, update, remove, enable, disable, rename) | See `docs/expose.md` |
| `pm2` | Control PM2 processes for managed services | See `docs/pm2.md` |
| `marketplace` | Browse, preview, install, and uninstall marketplace items | See `docs/marketplace.md` |
| `init` / `scaffold` | Quick-start new web projects | See `docs/init-scaffold.md` |
| `config` | Connection settings (URL, auth token) | See `docs/config.md` |

## Quick Reference

```bash
# Exposures
launcher-cli expose list
launcher-cli expose add --slug my-app --type proxy --target http://127.0.0.1:3001
launcher-cli expose add --slug docs --type static --path projects/my-site
launcher-cli expose update --slug my-app --protect               # Random credentials
launcher-cli expose update --slug my-app --password mySecret123  # Custom password
launcher-cli expose update --slug my-app --remove-password
launcher-cli expose remove --slug my-app

# PM2
launcher-cli pm2 status
launcher-cli pm2 control --slug my-app --action restart
launcher-cli expose recover-pm2 --slug my-app   # Recover PM2 config from running process

# Marketplace
launcher-cli marketplace list
launcher-cli marketplace list --type tool           # Filter by type (skill, mcp, tool, exec)
launcher-cli marketplace info --id webapp-projects
launcher-cli marketplace preview --id webapp-projects
launcher-cli marketplace install --id webapp-projects
launcher-cli marketplace uninstall --id webapp-projects

# Projects
launcher-cli init --slug my-game --description "Snake game"
launcher-cli scaffold
```

## Default Coding Conventions

When building projects to expose via the Launcher:

- **Node.js + Express** backend in a single `server.js` — no TypeScript, no bundlers
- **Self-contained frontend** — plain HTML/CSS/JS, no external CDN scripts (CORS blocks them behind the proxy)
- **Single CSS file or inline styles** — no CSS frameworks unless requested
- **Minimal npm dependencies** — `express` is usually enough
- **Self-contained HTML** for simple projects — embed `<style>` and `<script>` in one file
- **Port via `process.env.PORT`** — env vars managed through PM2, not `.env` files
- **Static files from `public/`** directory via `express.static`

## Constraints

- Target host must be `127.0.0.1`, `localhost`, or `::1` (SSRF protection)
- Target must include explicit port
- Slug: lowercase alphanumeric + hyphens, max 64 chars
- Reserved slugs: `gateway`, `api`, `control`, `health`, `open`, `feishu`
- PM2 process name must use `user-` prefix: `user-<slug>`

## Installation

Installed via Launcher Marketplace. Copies tool to `~/.openclaw/tools/launcher-cli/`. Requires Node.js 18+.

## Troubleshooting

- **Connection refused** — Launcher not running or wrong URL. Check `launcher-cli config show`
- **Unauthorized** — Auth token missing or expired. Set with `launcher-cli config set-token <token>`
- **Reserved slug** — Slugs like `api`, `gateway`, `health` are blocked. Choose a different name
- **SSRF protection** — Proxy targets restricted to loopback addresses (`127.0.0.1`, `localhost`, `::1`)
- **Path traversal blocked** — Static paths must stay within `~/.openclaw/workspace/`

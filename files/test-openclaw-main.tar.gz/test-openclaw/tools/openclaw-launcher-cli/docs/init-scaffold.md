# Init & Scaffold Commands

Quick-start new web projects with automatic setup.

## Init — Create a New Project

Create a fully initialized project with one command — auto-assigns a port, creates project files, runs `npm install`, starts PM2, and registers the exposure:

```bash
launcher-cli init --slug my-app
launcher-cli init --slug my-app --description "Snake game" --protect
```

Only `--slug` is required. Options:
- `--description <text>` — project description (optional)
- `--protect` — enable HTTP Basic Auth (optional)

The project is created at `~/.openclaw/workspace/projects/<slug>/` with Express + plain HTML/JS, ready to edit and serve immediately.

## Scaffold (Hello World)

Scaffold a hello-world demo project:

```bash
launcher-cli scaffold
```

Creates project at `~/.openclaw/workspace/projects/hello-world/` with Express.js, starts as `user-hello-world` PM2 process, registers exposure and prints the full public URL.

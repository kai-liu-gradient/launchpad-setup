# Config Commands

Manage launcher-cli connection settings.

## Set Launcher URL

```bash
launcher-cli config set-url <url>
```

Defaults to `http://localhost:3000`.

## Set Auth Token

```bash
launcher-cli config set-token <jwt-token>
```

Required before first use.

## Show Config

```bash
launcher-cli config show
```

Displays the current URL and token (truncated).

Config stored at `~/.openclaw/tools/launcher-cli/config.json`.

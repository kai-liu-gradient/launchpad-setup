# Expose Commands

Manage reverse proxy exposures — register, update, remove, and control service exposure through the Launcher reverse proxy.

## List Exposures

```bash
launcher-cli expose list
```

Returns table of all exposures with slug, type, target/path, status, password. Also shows the public domain and full access URLs for each enabled exposure.

## Add Proxy Exposure

```bash
launcher-cli expose add --slug my-app --type proxy --target http://127.0.0.1:3001
```

Accessible at `/open/my-app/`. WebSocket supported. The CLI will print the full public URL after creation.

### Add with PM2 Management

```bash
launcher-cli expose add \
  --slug my-app --type proxy --target http://127.0.0.1:3001 \
  --pm2-script server.js \
  --pm2-cwd ~/.openclaw/workspace/projects/my-app \
  --pm2-bootstrap "npm install" \
  --pm2-port 3001
```

PM2 process name is auto-set to `user-my-app` (enforced `user-` prefix).

### Add Static Exposure

```bash
launcher-cli expose add --slug docs --type static --path projects/my-site
```

Path is relative to `~/.openclaw/workspace/`.

### Add with Access Protection

```bash
launcher-cli expose add --slug my-app --type proxy --target http://127.0.0.1:3001 --protect
```

Generates random HTTP Basic Auth credentials (username + password) and prints them. Save the credentials — the password cannot be retrieved later.

## Update Exposure

```bash
launcher-cli expose update --slug my-app --description "My cool project"
launcher-cli expose update --slug my-app --target http://127.0.0.1:4000
launcher-cli expose update --slug my-app --protect                          # Generate new random credentials
launcher-cli expose update --slug my-app --password mySecret123             # Set a custom password
launcher-cli expose update --slug my-app --password mySecret --auth-user admin  # Set custom username + password
launcher-cli expose update --slug my-app --remove-password                  # Remove protection
```

When using `--password`, the server hashes and stores it. If `--auth-user` is omitted, the existing username is kept (or a random one is generated for new protection).

## Rename Exposure

```bash
launcher-cli expose rename --slug old-name --new-slug new-name
```

## Remove Exposure

```bash
launcher-cli expose remove --slug my-app
```

Also cleans up the associated PM2 process if the exposure has PM2 management.

## Recover PM2 Config

If an exposure exists but is missing PM2 configuration (e.g. after manual edits or migration), and a PM2 process named `user-{slug}` is running locally, you can recover the PM2 config:

```bash
launcher-cli expose recover-pm2 --slug my-app
```

This looks up the running PM2 process `user-my-app`, extracts its script, working directory, and port, then attaches the PM2 config to the exposure in `exports.yaml`.

## Enable/Disable Exposure

```bash
launcher-cli expose enable --slug my-app
launcher-cli expose disable --slug my-app
```

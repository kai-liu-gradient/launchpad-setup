# PM2 Service Commands

Manage PM2 processes associated with exposed services.

## Show PM2 Status

```bash
launcher-cli pm2 status
```

Returns table of all PM2-managed exposures with status (online/stopped/errored), PID, memory, uptime, restarts.

## Control PM2 Service

```bash
launcher-cli pm2 control --slug my-app --action restart
```

Available actions: `start`, `stop`, `restart`, `delete`

## Recover PM2 Config

If an exposure is missing its PM2 configuration but a matching `user-{slug}` PM2 process is running, recover it:

```bash
launcher-cli expose recover-pm2 --slug my-app
```

Detects the running process, extracts script/cwd/port, and attaches PM2 config to the exposure. Also available in the Web Apps UI as an "Adopt PM2 Instance" button.

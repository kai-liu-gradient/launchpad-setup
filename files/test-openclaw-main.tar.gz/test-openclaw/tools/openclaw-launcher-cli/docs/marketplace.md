# Marketplace Commands

Browse, preview, install, and uninstall items from the OpenClaw marketplace catalog.

## Catalog Item Types

| Type | Description | Install Location |
|------|-------------|------------------|
| `skill` | AI agent knowledge/capability files | `~/.openclaw/skills/{skillDir}/` |
| `mcp` | MCP (Model Context Protocol) servers | `~/.openclaw/skills/{skillDir}/` |
| `tool` | CLI tools with bin symlinks for shell access | `~/.openclaw/tools/{toolName}/` |
| `exec` | Execute allowed shell commands during install | (record only) |

## List Catalog

```bash
launcher-cli marketplace list
```

Shows all available marketplace items with ID, name, type, version, and installation status.

Filter by type:

```bash
launcher-cli marketplace list --type tool
launcher-cli marketplace list --type skill
```

## Item Info

```bash
launcher-cli marketplace info --id openclaw-launcher-cli
```

Shows detailed information about a catalog item: description, tags, version, dependencies, install status, and type-specific details (folder status, TOOLS.md/AGENTS.md registration for tool types).

## Preview Item

```bash
launcher-cli marketplace preview --id webapp-projects
```

Displays the SKILL.md content (or first file) and a file tree for multi-file items.

To preview a specific file within the item:

```bash
launcher-cli marketplace preview --id webapp-projects --file SKILL.md
```

## Install Item

```bash
launcher-cli marketplace install --id webapp-projects
```

Installs the item. For skill types, copies files to `~/.openclaw/skills/`. For tool types, copies to `~/.openclaw/tools/` and creates bin symlinks for CLI access. Dependencies are auto-installed.

## Uninstall Item

```bash
launcher-cli marketplace uninstall --id webapp-projects
```

Removes installed files and cleans up bin links, TOOLS.md entries, and config overrides.

import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import SetupWizard from './pages/SetupWizard';
import Credentials from './pages/setup/Credentials';
import Channels from './pages/setup/Channels';
import Config from './pages/setup/Config';
import Health from './pages/setup/Health';
import Complete from './pages/setup/Complete';
import ManagedPool from './pages/setup/ManagedPool';
import Workspace from './pages/Workspace';
import Exposures from './pages/Exposures';
import Marketplace from './pages/Marketplace';
import Notices from './pages/Notices';
import SystemStats from './pages/SystemStats';
import ControlUI from './pages/ControlUI';
import Login from './pages/Login';
import AccessLink from './pages/AccessLink';
import { WizardProvider } from './context/WizardContext';
import { AppConfigProvider, useAppConfig } from './context/AppConfigContext';
import { ThemeProvider } from './context/ThemeContext';
import { useAuth } from './hooks/useAuth';

function ProtectedRoute({ children }) {
  const { isAuthenticated } = useAuth();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  return children;
}

function AdaptiveHome() {
  const { isConfigured, gatewayHealthy, loading } = useAppConfig();

  if (loading) return null;
  if (!isConfigured) return <Navigate to="/setup" replace />;
  if (!gatewayHealthy) return <Navigate to="/setup/health" replace />;
  return <Navigate to="/terminal" replace />;
}

function SetupIndex() {
  const { isConfigured, loading } = useAppConfig();

  if (loading) return null;
  if (isConfigured) return <Navigate to="/setup/health" replace />;
  return <Credentials />;
}

export default function App() {
  return (
    <ThemeProvider>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/auth/access" element={<AccessLink />} />
        <Route path="/*" element={
          <ProtectedRoute>
            <AppConfigProvider>
              <Layout>
                <Routes>
                  <Route path="/" element={<AdaptiveHome />} />
                  <Route path="/setup" element={<WizardProvider><SetupWizard /></WizardProvider>}>
                    <Route index element={<SetupIndex />} />
                    <Route path="credentials" element={<Credentials />} />
                    <Route path="channels" element={<Channels />} />
                    <Route path="channels/:channel" element={<Channels />} />
                    <Route path="config" element={<Config />} />
                    <Route path="health" element={<Health />} />
                    <Route path="complete" element={<Complete />} />
                    <Route path="admin" element={<ManagedPool />} />
                  </Route>
                  <Route path="/workspace" element={<Workspace />} />
                  <Route path="/webapps" element={<Exposures />} />
                  <Route path="/marketplace" element={<Marketplace />} />
                  <Route path="/notices" element={<Notices />} />
                  <Route path="/system-stats" element={<SystemStats />} />
                  <Route path="/terminal" element={null} />
                  <Route path="/control-ui" element={<ControlUI />} />
                </Routes>
              </Layout>
            </AppConfigProvider>
          </ProtectedRoute>
        } />
      </Routes>
    </ThemeProvider>
  );
}

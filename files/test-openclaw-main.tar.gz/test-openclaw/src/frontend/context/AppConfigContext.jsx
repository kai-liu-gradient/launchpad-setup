import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { authFetch } from '../hooks/useAuth';

const AppConfigContext = createContext(null);

export function AppConfigProvider({ children }) {
  const [loading, setLoading] = useState(true);
  const [health, setHealth] = useState(null);
  const [config, setConfig] = useState(null);
  const [identity, setIdentity] = useState(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const [healthRes, configRes, identityRes] = await Promise.all([
        authFetch('/api/openclaw/health').then((r) => r.json()).catch(() => null),
        authFetch('/api/openclaw/config').then((r) => r.ok ? r.json() : null).catch(() => null),
        authFetch('/api/openclaw/workspace/identity').then((r) => r.ok ? r.json() : null).catch(() => null),
      ]);
      setHealth(healthRes);
      setConfig(configRes);
      if (identityRes?.found) setIdentity(identityRes);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const configExists = !!health?.config?.exists;
  const hasCredentials = config?.auth?.profiles && Object.keys(config.auth.profiles).length > 0;
  const gatewayPresent = !!health?.pm2?.gateway;
  const gatewayOnline = gatewayPresent && health?.pm2?.gateway?.status === 'online';
  const gatewayReachable = !!health?.gateway?.portReachable;

  // Skip wizard if ANY of these are true:
  // 1. localStorage says wizard was completed
  // 2. launcher.json has managedPool info
  // 3. Gateway process exists in PM2 (even if crashed — setup was done)
  const wizardCompleted = typeof window !== 'undefined' && localStorage.getItem('openclaw-wizard-completed') === 'true';
  const hasManagedPool = !!health?.managedPool?.enabled;
  const isConfigured = wizardCompleted || hasManagedPool || gatewayPresent;
  const gatewayHealthy = isConfigured && gatewayReachable;

  const configStatus = {
    configExists,
    hasCredentials,
    gatewayPresent,
    gatewayOnline,
    gatewayReachable,
    workspaceExists: !!health?.workspace?.exists,
  };

  // Version info from health response
  const versionInfo = health?.version || null;

  // Feature flags from environment
  const features = health?.features || {};
  const marketplaceEnabled = !!features.marketplace;

  // Adoption / managed pool
  const adoptionEnabled = !!health?.managedPool?.enabled;

  return (
    <AppConfigContext.Provider value={{ isConfigured, gatewayHealthy, configStatus, loading, health, config, versionInfo, marketplaceEnabled, adoptionEnabled, identity, refresh }}>
      {children}
    </AppConfigContext.Provider>
  );
}

export function useAppConfig() {
  const ctx = useContext(AppConfigContext);
  if (!ctx) throw new Error('useAppConfig must be used within AppConfigProvider');
  return ctx;
}

import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { useAppConfig } from './AppConfigContext';

const WizardContext = createContext(null);

const STEPS = [
  { key: 'credentials', path: '/setup/credentials', label: 'Credentials' },
  { key: 'channels', path: '/setup/channels', label: 'Channels' },
  { key: 'config', path: '/setup/config', label: 'Config' },
  { key: 'complete', path: '/setup/complete', label: 'Complete' },
];

export function WizardProvider({ children }) {
  const { configStatus, config, isConfigured } = useAppConfig();

  const [completed, setCompleted] = useState({
    credentials: false,
    channels: false,
    config: false,
  });

  const [data, setData] = useState({
    credentials: null,
    channels: null,
    config: null,
  });

  // Pre-populate wizard state from existing config only when fully configured
  // (i.e. returning user editing settings, not a fresh first-time wizard)
  useEffect(() => {
    if (!configStatus || !isConfigured) return;
    setCompleted((prev) => ({
      credentials: prev.credentials || !!configStatus.hasCredentials,
      channels: prev.channels || !!(config?.channels?.telegram?.accounts?.default) || !!(config?.channels?.feishu?.appId),
      config: prev.config || !!(configStatus.configExists && configStatus.gatewayOnline),
    }));
  }, [configStatus, config, isConfigured]);

  const markCompleted = useCallback((step, stepData) => {
    setCompleted((prev) => ({ ...prev, [step]: true }));
    if (stepData) {
      setData((prev) => ({ ...prev, [step]: stepData }));
    }
  }, []);

  return (
    <WizardContext.Provider value={{ steps: STEPS, completed, data, markCompleted, isConfigured }}>
      {children}
    </WizardContext.Provider>
  );
}

export function useWizard() {
  const ctx = useContext(WizardContext);
  if (!ctx) throw new Error('useWizard must be used within WizardProvider');
  return ctx;
}

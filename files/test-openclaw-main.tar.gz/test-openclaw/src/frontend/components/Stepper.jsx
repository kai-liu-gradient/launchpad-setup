import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useWizard } from '../context/WizardContext';

export default function Stepper() {
  const { steps, completed } = useWizard();
  const location = useLocation();
  const navigate = useNavigate();

  const currentIndex = steps.findIndex(
    (s) => location.pathname === s.path || location.pathname.startsWith(s.path + '/') || (location.pathname === '/setup' && s.key === 'credentials')
  );

  const getStepClass = (index, step) => {
    const classes = ['step'];
    if (index === currentIndex) classes.push('active');
    if (completed[step.key]) classes.push('completed');
    return classes.join(' ');
  };

  return (
    <div className="stepper">
      {steps.map((step, index) => (
        <div
          key={step.key}
          className={getStepClass(index, step)}
          onClick={() => navigate(step.path)}
          style={{ cursor: 'pointer' }}
        >
          <div className="step-circle">
            {completed[step.key] ? '\u2713' : index + 1}
          </div>
          <span className="step-label">{step.label}</span>
        </div>
      ))}
    </div>
  );
}

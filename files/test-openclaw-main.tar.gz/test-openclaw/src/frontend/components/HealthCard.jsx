import React from 'react';

export default function HealthCard({ title, status, statusLabel: statusLabelProp, checks, actions, loading, error, onRefresh, lastChecked, children, collapsed, onToggleCollapsed, collapsedSummary, hideCollapsedStatus }) {
  const statusColor = status === 'ok' ? 'badge-success'
    : status === 'warn' ? 'badge-warning'
    : status === 'error' ? 'badge-error'
    : 'badge-info';

  const statusLabel = statusLabelProp != null ? statusLabelProp
    : status === 'ok' ? null
    : status === 'warn' ? 'Warning'
    : status === 'error' ? 'Issues Detected'
    : status === 'info' ? null
    : null;

  const isCollapsible = onToggleCollapsed != null;
  const isCollapsed = isCollapsible && collapsed;
  const hasContent = checks || children;

  const handleHeaderClick = (e) => {
    if (!isCollapsible) return;
    // Don't toggle if clicking on the status badge/refresh button
    if (e.target.closest('.health-card-status')) return;
    onToggleCollapsed();
  };

  return (
    <div className={`card health-card${isCollapsed ? ' health-card-collapsed' : ''}`}>
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: isCollapsed ? 0 : hasContent ? 10 : 0,
          cursor: isCollapsible ? 'pointer' : 'default',
          userSelect: isCollapsible ? 'none' : 'auto',
        }}
        onClick={handleHeaderClick}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, minWidth: 0, flex: 1 }}>
          {isCollapsible && !hideCollapsedStatus && (
            <span style={{ color: 'var(--text-muted)', fontSize: '0.7rem', flexShrink: 0 }}>
              {isCollapsed ? '\u25B8' : '\u25BE'}
            </span>
          )}
          <h3 className="card-title" style={{ marginBottom: 0 }}>{title}</h3>
          {isCollapsed && collapsedSummary && (
            <div className="health-card-collapsed-summary">
              {collapsedSummary}
            </div>
          )}
        </div>
        <div className="health-card-status" style={{ display: 'flex', alignItems: 'center', flexShrink: 0, marginLeft: 8 }}>
          {isCollapsed && hideCollapsedStatus ? null : !loading && status && onRefresh ? (
            statusLabel ? (
              <button
                className={`badge ${statusColor}`}
                onClick={(e) => { e.stopPropagation(); onRefresh(); }}
                disabled={loading}
                style={{
                  border: 'none',
                  cursor: 'pointer',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: 5,
                  fontSize: '0.75rem',
                }}
                title={lastChecked ? `Last checked ${lastChecked.toLocaleTimeString()} — click to refresh` : 'Click to refresh'}
              >
                {statusLabel}
              </button>
            ) : (
              <button
                onClick={(e) => { e.stopPropagation(); onRefresh(); }}
                disabled={loading}
                style={{
                  border: 'none',
                  background: 'none',
                  cursor: 'pointer',
                  display: 'inline-flex',
                  alignItems: 'center',
                  padding: 0,
                  color: 'var(--badge-success-text)',
                  fontSize: '1.1rem',
                }}
                title={lastChecked ? `Last checked ${lastChecked.toLocaleTimeString()} — click to refresh` : 'Click to refresh'}
              >
                ✓
              </button>
            )
          ) : !loading && status ? (
            statusLabel ? (
              <span className={`badge ${statusColor}`}>
                {statusLabel}
              </span>
            ) : (
              <span style={{ color: 'var(--badge-success-text)', fontSize: '1.1rem' }}>✓</span>
            )
          ) : loading ? (
            <span className="badge badge-info" style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
              <span className="spinner" style={{ width: 11, height: 11, borderWidth: 2 }} />
              Checking
            </span>
          ) : null}
        </div>
      </div>

      {!isCollapsed && (
        <>
          {loading && !checks && !children && (
            <div className="health-card-skeleton">
              {[1, 2, 3].map(i => (
                <div key={i} className="health-card-skeleton-row" />
              ))}
            </div>
          )}

          {error && (
            <div style={{
              padding: '10px 14px',
              background: 'var(--badge-error-bg)',
              border: '1px solid var(--error-border)',
              borderRadius: 4,
              color: 'var(--badge-error-text)',
              fontSize: '0.85rem',
            }}>
              {error}
            </div>
          )}

          {!error && checks && checks.length > 0 && (
            <div>
              {checks.map((check, i) => (
                <div
                  key={check.name || i}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '6px 0',
                    borderBottom: i < checks.length - 1 ? '1px solid var(--border-primary)' : 'none',
                    fontSize: '0.85rem',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{
                      color: check.ok ? 'var(--badge-success-text)' : check.warn ? 'var(--badge-warning-text)' : 'var(--badge-error-text)',
                      fontSize: '1rem',
                      width: 16,
                      textAlign: 'center',
                    }}>
                      {check.ok ? '\u2713' : check.warn ? '\u2014' : '\u2717'}
                    </span>
                    <span style={{ color: 'var(--text-primary)' }}>{check.name}</span>
                  </div>
                  {check.onClick ? (
                    <button
                      className={`badge ${check.ok ? 'badge-success' : 'badge-warning'}`}
                      onClick={check.onClick}
                      style={{ border: 'none', cursor: 'pointer', textDecoration: 'underline', textUnderlineOffset: 2 }}
                      title={check.clickTitle || 'Click to view'}
                    >
                      {check.detail}
                    </button>
                  ) : (
                    <span className={`badge ${check.ok ? 'badge-success' : 'badge-warning'}`}>
                      {check.detail}
                    </span>
                  )}
                </div>
              ))}
            </div>
          )}

          {!error && children}

          {actions && (
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              borderTop: '1px solid var(--border-primary)',
              marginTop: 10,
              paddingTop: 10,
            }}>
              {actions}
            </div>
          )}
        </>
      )}
    </div>
  );
}

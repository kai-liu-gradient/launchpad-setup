import React, { useState, useCallback, useEffect } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { FolderOpen, Settings, Wand2, ChevronRight, ChevronLeft, Monitor, TerminalSquare, MessageSquare, Sun, Moon, LogOut, Package, Activity, Bell, Globe } from 'lucide-react';
import { useAppConfig } from '../context/AppConfigContext';
import { subscribe, getSystemStats, setSystemStats } from '../systemStatsStore';
import { useTheme } from '../context/ThemeContext';
import { useAuth, authFetch } from '../hooks/useAuth';
import AsciiLoader from './AsciiLoader';
import ErrorBoundary from './ErrorBoundary';
import Shell from '../pages/Shell';
import NoticeBanner, { useNotices } from './NoticeBanner';

function useWebAppsBadge(configured) {
  const [counts, setCounts] = useState({ total: 0, running: 0 });

  useEffect(() => {
    if (!configured) return;
    let cancelled = false;
    const fetchCounts = async () => {
      try {
        const res = await authFetch('/api/openclaw/exposures/summary');
        if (!res.ok || cancelled) return;
        const data = await res.json();
        setCounts({ total: data.total || 0, running: data.running || 0 });
      } catch {
        // Non-critical
      }
    };
    fetchCounts();
    const interval = setInterval(fetchCounts, 60 * 1000);
    return () => { cancelled = true; clearInterval(interval); };
  }, [configured]);

  return counts;
}

function useMarketplaceBadge(enabled) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!enabled) return;
    let cancelled = false;
    const fetchCount = async () => {
      try {
        const res = await authFetch('/api/openclaw/marketplace/catalog');
        if (!res.ok || cancelled) return;
        const data = await res.json();
        const items = data.items || [];
        setCount(items.filter(i => i.updateAvailable).length);
      } catch {
        // Non-critical
      }
    };
    fetchCount();
    const interval = setInterval(fetchCount, 5 * 60 * 1000);
    return () => { cancelled = true; clearInterval(interval); };
  }, [enabled]);

  return count;
}

export default function Layout({ children }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [loaderAnimationDone, setLoaderAnimationDone] = useState(false);
  const [shellStatus, setShellStatus] = useState(null);
  const [shellMounted, setShellMounted] = useState(false);
  const [altHeld, setAltHeld] = useState(false);
  const [shellSkipTui, setShellSkipTui] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { theme, toggleTheme } = useTheme();
  const { logout } = useAuth();

  const isTerminalRoute = location.pathname === '/terminal';
  const isTerminalRouteRef = React.useRef(isTerminalRoute);
  isTerminalRouteRef.current = isTerminalRoute;

  // Mount Shell permanently once user first visits /terminal
  if (isTerminalRoute && !shellMounted) {
    setShellMounted(true);
  }

  const onShellStatus = useCallback((status) => {
    setShellStatus(status);
  }, []);

  let appConfig = null;
  try {
    appConfig = useAppConfig();
  } catch {
    // Context not yet available during initial render
  }

  const isConfigured = appConfig?.isConfigured ?? false;
  const loading = appConfig?.loading ?? true;
  const marketplaceEnabled = appConfig?.marketplaceEnabled ?? false;
  const identity = appConfig?.identity ?? null;

  const [sysStats, setSysStats] = useState(getSystemStats);
  useEffect(() => subscribe(setSysStats), []);

  // Background polling: keep sidebar CPU/Memory badges fresh
  // even when SystemStats page is not mounted and Shell WS is inactive
  useEffect(() => {
    let cancelled = false;
    const poll = async () => {
      try {
        const res = await authFetch('/api/openclaw/system-stats/latest');
        if (!res.ok || cancelled) return;
        const d = await res.json();
        if (d && !d.collecting) {
          setSystemStats({ cpu: d.cpu, memory: d.memory });
        }
      } catch {
        // Non-critical
      }
    };
    poll();
    const id = setInterval(poll, 30000);
    return () => { cancelled = true; clearInterval(id); };
  }, []);

  const { notices, unreadCount, dismiss: dismissNotice } = useNotices();
  const marketplaceBadge = useMarketplaceBadge(marketplaceEnabled);
  const webAppsCounts = useWebAppsBadge(isConfigured);

  const showLoader = loading || !loaderAnimationDone;

  useEffect(() => {
    const onKeyDown = (e) => {
      if (e.key === 'Alt' && !e.repeat) {
        setAltHeld(prev => !prev);
        // Don't toggle shell mode while user is on the terminal tab — it causes a reconnect
        if (!isTerminalRouteRef.current) {
          setShellSkipTui(prev => !prev);
        }
      }
    };
    // Use capture phase so xterm.js can't swallow the event
    window.addEventListener('keydown', onKeyDown, true);
    return () => {
      window.removeEventListener('keydown', onKeyDown, true);
    };
  }, []);

  const chatLabel = identity?.name
    ? `Chat With ${identity.name}`
    : 'OpenClaw Chat';
  const chatTitle = altHeld
    ? 'Press \u2325 to switch to Chat'
    : identity?.creature
      ? `${chatLabel} — ${identity.creature} (press \u2325 for Terminal)`
      : `${chatLabel} (press \u2325 for Terminal)`;

  const gatewayItems = [
    { to: '/terminal', icon: altHeld ? TerminalSquare : MessageSquare, emoji: !altHeld && identity?.emoji || null, label: altHeld ? 'Terminal' : chatLabel, title: chatTitle, primary: true },
    { to: '/control-ui', icon: Monitor, label: 'Control UI', title: 'Gateway Control UI' },
  ];

  const navItems = isConfigured
    ? [
        ...gatewayItems,
        { to: '/workspace', icon: FolderOpen, label: 'Workspace', title: 'Explorer' },
        { to: '/webapps', icon: Globe, label: 'Web Apps', title: 'Web Apps' },
        { to: '/system-stats', icon: Activity, label: 'System', title: 'System Stats' },
        { to: '/setup/health', icon: Settings, label: 'Settings', title: 'Settings', matchPrefix: '/setup' },
      ]
    : [
        { to: '/setup', icon: Wand2, label: 'Setup', title: 'Setup Wizard', primary: true, pulse: true },
        ...gatewayItems,
      ];

  const isActive = (item) => {
    if (item.to === '/') return location.pathname === '/';
    const prefix = item.matchPrefix || item.to;
    return location.pathname.startsWith(prefix);
  };

  return (
    <div className="app-layout">
      <button className={`mobile-toggle ${sidebarOpen ? 'open' : ''}`} onClick={() => setSidebarOpen(!sidebarOpen)}>
        {sidebarOpen ? <ChevronLeft size={16} /> : <ChevronRight size={16} />}
      </button>

      {sidebarOpen && (
        <div className="sidebar-overlay show" onClick={() => setSidebarOpen(false)} />
      )}

      <nav className={`sidebar ${sidebarOpen ? 'open' : ''}`}>
        <div className="sidebar-header">
          <div className="sidebar-logo">
            <div className="sidebar-logo-icon">&gt;_</div>
            <div className="sidebar-logo-text">
              <div className="sidebar-logo-title">Open<span className="logo-highlight">Claw</span></div>
              <div className="sidebar-logo-sub">Launcher</div>
            </div>
          </div>
        </div>
        <div className="sidebar-nav">
          {!loading && navItems.map((item) => {
            const IconComponent = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                className={`nav-item ${isActive(item) ? 'active' : ''} ${item.primary ? 'nav-primary' : ''} ${item.pulse ? 'nav-pulse' : ''}`}
                onClick={() => {
                  setSidebarOpen(false);
                }}
                title={item.title || item.label}
              >
                <span className="nav-icon">
                  {item.emoji ? <span className="nav-emoji">{item.emoji}</span> : <IconComponent size={18} />}
                </span>
                <span>{item.label}</span>
                {item.badge === 'configured' && (
                  <span className="nav-badge nav-badge-configured" />
                )}
                {item.to === '/system-stats' && sysStats && (
                  <span className="nav-stats-mini">
                    {sysStats.cpu?.usagePercent != null && <span>C{Math.round(sysStats.cpu.usagePercent)}%</span>}
                    {sysStats.memory?.usedPercent != null && <span>M{Math.round(sysStats.memory.usedPercent)}%</span>}
                  </span>
                )}
                {item.to === '/terminal' && shellStatus === 'connected' && !isActive(item) && (
                  <span className="nav-badge nav-badge-live" />
                )}
                {item.to === '/webapps' && webAppsCounts.total > 0 && (
                  <span className="nav-badge-count nav-badge-count-green" title={`${webAppsCounts.total} registered, ${webAppsCounts.running} running`}>
                    {webAppsCounts.running}/{webAppsCounts.total}
                  </span>
                )}
                {item.setupRequired && (
                  <span className="badge badge-warning" style={{ fontSize: '0.65rem', padding: '2px 6px', marginLeft: 'auto' }}>
                    Setup needed
                  </span>
                )}
              </NavLink>
            );
          })}
          <div className="sidebar-nav-divider" />
          {marketplaceEnabled && (
            <NavLink
              to="/marketplace"
              className={`nav-item ${isActive({ to: '/marketplace' }) ? 'active' : ''}`}
              onClick={() => setSidebarOpen(false)}
              title="Marketplace"
            >
              <span className="nav-icon">
                <Package size={18} />
              </span>
              <span>Marketplace</span>
              {marketplaceBadge > 0 && (
                <span className="nav-badge-count">{marketplaceBadge > 9 ? '9+' : marketplaceBadge}</span>
              )}
            </NavLink>
          )}
          <NavLink
            to="/notices"
            className={`nav-item ${isActive({ to: '/notices' }) ? 'active' : ''}`}
            onClick={() => setSidebarOpen(false)}
            title="Notification"
          >
            <span className="nav-icon">
              <Bell size={18} />
            </span>
            <span>Notification</span>
            {unreadCount > 0 && (
              <span className="nav-badge-count">{unreadCount > 9 ? '9+' : unreadCount}</span>
            )}
          </NavLink>
        </div>
        <div className="sidebar-footer">
          <button className="theme-toggle" onClick={toggleTheme} title={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}>
            <span className="nav-icon">
              {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
            </span>
            <span>{theme === 'dark' ? 'Light Mode' : 'Dark Mode'}</span>
          </button>
          <button className="theme-toggle" onClick={logout} title="Sign out">
            <span className="nav-icon">
              <LogOut size={18} />
            </span>
            <span>Sign Out</span>
          </button>
          <div className="sidebar-version">&copy; AniSpark.ai ({typeof __APP_VERSION__ !== 'undefined' ? __APP_VERSION__ : '?'})</div>
        </div>
      </nav>

      <main className="main-content">
        {showLoader ? (
          <AsciiLoader
            isLoading={loading}
            onComplete={() => setLoaderAnimationDone(true)}
          />
        ) : (
          <>
            <NoticeBanner
              notices={notices}
              onDismiss={dismissNotice}
              onOpenInbox={() => navigate('/notices')}
            />
            <div style={{ display: isTerminalRoute ? 'none' : undefined }}><ErrorBoundary>{children}</ErrorBoundary></div>
            {shellMounted && (
              <div style={{ display: isTerminalRoute ? undefined : 'none', height: '100%' }}>
                <Shell visible={isTerminalRoute} onStatusChange={onShellStatus} skipTui={shellSkipTui} />
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
}

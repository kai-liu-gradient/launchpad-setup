import React, { useEffect, useState, useRef } from 'react';

const AsciiLoader = ({ isLoading = true, onComplete }) => {
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState('INITIALIZING SYSTEM');
  const requestRef = useRef();
  const startTimeRef = useRef(Date.now());

  const loadingMessages = [
    'LOADING CORE MODULES...',
    'ESTABLISHING SECURE CONNECTION...',
    'VERIFYING INTEGRITY...',
    'SYNCING GATEWAY PROTOCOLS...',
    'DECRYPTING WORKSPACE...',
    'PREPARING USER INTERFACE...'
  ];

  useEffect(() => {
    // Animation loop
    const animate = () => {
      const now = Date.now();
      const elapsed = now - startTimeRef.current;
      
      setProgress((prev) => {
        let target = 95;
        let speed = 0.2; // Slow progress during real loading

        if (!isLoading) {
          target = 100;
          speed = 2.0; // Fast completion when done
        } else {
            // Artificial slowing as we get closer to 90%
            if (prev > 70) speed = 0.05;
            if (prev > 90) speed = 0.01;
        }

        let next = prev + speed;
        
        // Ensure we don't exceed target unless we are finishing
        if (isLoading && next > target) next = target;
        if (next >= 100) {
            next = 100;
            // Delay calling onComplete slightly to show the 100% state
            if (onComplete) {
                // Check if we haven't already scheduled completion
                if (!requestRef.current.completed) {
                    requestRef.current.completed = true;
                    setTimeout(onComplete, 500); 
                }
            }
        }
        return next;
      });

      // Status text updates
      const messageIndex = Math.floor((now / 2000) % loadingMessages.length);
      setStatusText(loadingMessages[messageIndex]);

      if (!requestRef.current.completed) {
        requestRef.current.id = requestAnimationFrame(animate);
      }
    };

    requestRef.current = { completed: false };
    requestRef.current.id = requestAnimationFrame(animate);

    return () => {
      if (requestRef.current.id) cancelAnimationFrame(requestRef.current.id);
    };
  }, [isLoading, onComplete]);

  const progressPercent = Math.min(progress, 100);

  return (
    <div className="ascii-loader-container" style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      height: '100%',
      minHeight: '100vh',
      width: '100%',
      background: 'var(--bg-primary)',
      fontFamily: '"JetBrains Mono", "Fira Code", monospace',
      color: 'var(--accent)',
      userSelect: 'none'
    }}>
      <div style={{ maxWidth: '600px', width: '90%', display: 'flex', flexDirection: 'column', gap: '20px' }}>

        {/* Branding */}
        <div className="ascii-loader-brand" style={{
            color: 'var(--text-primary)',
            fontWeight: 'bold',
            marginBottom: '20px',
            whiteSpace: 'pre',
            lineHeight: '1.2',
            display: 'flex',
            justifyContent: 'center',
        }}>
{`   ____                    ____ _
  / __ \\____  ___  ____  / ___/ /___ __      __
 / / / / __ \\/ _ \\/ __ \\/ /  / / __ \`/ | /| / /
/ /_/ / /_/ /  __/ / / / /__/ / /_/ /| |/ |/ /
\\____/ .___/\\___/_/ /_/\\___/_/\\__,_/ |__/|__/
    /_/      L A U N C H E R`}
        </div>

        {/* Progress Bar Container */}
        <div style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '10px',
            background: 'var(--bg-surface)',
            padding: '30px',
            border: '1px solid var(--border-primary)',
            boxShadow: '0 0 20px rgba(0,0,0,0.1)'
        }}>

            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.9rem', color: 'var(--accent)' }}>
                <span>{statusText}</span>
                <span>{Math.floor(progress)}%</span>
            </div>

            <div style={{
                width: '100%',
                height: '20px',
                background: 'var(--accent-bg)',
                border: '1px solid var(--border-primary)',
                overflow: 'hidden'
            }}>
                <div style={{
                    width: `${progressPercent}%`,
                    height: '100%',
                    background: 'var(--accent)',
                    transition: 'width 0.1s linear'
                }} />
            </div>

            <div style={{
                fontSize: '0.75rem',
                color: 'var(--text-muted)',
                marginTop: '10px',
                display: 'flex',
                justifyContent: 'space-between'
            }}>
                <span>MEM: OK</span>
                <span>NET: OK</span>
                <span>SEC: OK</span>
            </div>
        </div>

      </div>
    </div>
  );
};

export default AsciiLoader;


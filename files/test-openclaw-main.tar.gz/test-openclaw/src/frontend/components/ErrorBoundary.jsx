import React from 'react';
import { Copy, RefreshCw, AlertTriangle } from 'lucide-react';

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { error };
  }

  componentDidCatch(error, errorInfo) {
    this.setState({ errorInfo });
  }

  handleCopy = () => {
    const { error, errorInfo } = this.state;
    const path = window.location.pathname;
    const text = [
      `Page: ${path}`,
      `Error: ${error?.message || String(error)}`,
      '',
      error?.stack || '',
      errorInfo?.componentStack || '',
    ].join('\n').trim();

    navigator.clipboard.writeText(text).then(() => {
      this.copyBtn?.classList.add('copied');
      setTimeout(() => this.copyBtn?.classList.remove('copied'), 1500);
    });
  };

  handleRefresh = () => {
    window.location.reload();
  };

  render() {
    if (!this.state.error) {
      return this.props.children;
    }

    const { error, errorInfo } = this.state;
    const path = window.location.pathname;

    return (
      <div className="error-dialog-overlay">
        <div className="error-dialog">
          <div className="error-dialog-header">
            <AlertTriangle size={20} />
            <span>Something went wrong</span>
          </div>

          <div className="error-dialog-field">
            <label>Page</label>
            <code>{path}</code>
          </div>

          <div className="error-dialog-field">
            <label>Error</label>
            <code>{error?.message || String(error)}</code>
          </div>

          <div className="error-dialog-stack">
            <label>Stack trace</label>
            <pre>{error?.stack}{errorInfo?.componentStack}</pre>
          </div>

          <div className="error-dialog-actions">
            <button
              className="btn btn-secondary"
              onClick={this.handleCopy}
              ref={(el) => (this.copyBtn = el)}
            >
              <Copy size={14} />
              <span className="copy-label">Copy details</span>
              <span className="copied-label">Copied!</span>
            </button>
            <button className="btn btn-primary" onClick={this.handleRefresh}>
              <RefreshCw size={14} />
              Refresh page
            </button>
          </div>
        </div>
      </div>
    );
  }
}

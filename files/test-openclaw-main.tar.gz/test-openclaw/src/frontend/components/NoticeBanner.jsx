import React, { useState, useEffect, useCallback } from 'react';
import { Bell } from 'lucide-react';
import { authFetch } from '../hooks/useAuth';

const LS_KEY = 'openclaw-dismissed-notices';

/** Simple djb2 hash — deterministic, fast, no crypto needed */
function hashContent(str) {
  let h = 5381;
  for (let i = 0; i < str.length; i++) {
    h = ((h << 5) + h) + str.charCodeAt(i);
    h = h & h;
  }
  return Math.abs(h).toString(36);
}

function contentHash(notice) {
  return hashContent((notice.title || '') + '::' + (notice.message || ''));
}

function readLocalDismissals() {
  try {
    const raw = localStorage.getItem(LS_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function writeLocalDismissals(map) {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(map));
  } catch {
    // Storage full or unavailable — non-critical
  }
}

function isLocallyDismissed(notice) {
  const map = readLocalDismissals();
  return !!map[contentHash(notice)];
}

function dismissLocally(notice) {
  const map = readLocalDismissals();
  map[contentHash(notice)] = Date.now();
  writeLocalDismissals(map);
}

export function useNotices() {
  const [notices, setNotices] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);

  const computeUnread = useCallback((list) => {
    return list.filter(n => !n.dismissed && !isLocallyDismissed(n)).length;
  }, []);

  const refresh = useCallback(async () => {
    try {
      const res = await authFetch('/api/openclaw/notices');
      if (!res.ok) return;
      const data = await res.json();
      const list = (data.notices || []).map(n => ({
        ...n,
        dismissed: n.dismissed || isLocallyDismissed(n),
      }));
      setNotices(list);
      setUnreadCount(list.filter(n => !n.dismissed).length);
    } catch {
      // Silently fail — notices are non-critical
    } finally {
      setLoading(false);
    }
  }, []);

  const dismiss = useCallback(async (noticeId) => {
    // Find the notice to hash its content
    setNotices(prev => {
      const target = prev.find(n => n.id === noticeId);
      if (target) dismissLocally(target);
      const updated = prev.map(n => n.id === noticeId ? { ...n, dismissed: true } : n);
      setUnreadCount(updated.filter(n => !n.dismissed).length);
      return updated;
    });

    // Also persist to server
    try {
      await authFetch(`/api/openclaw/notices/${encodeURIComponent(noticeId)}/dismiss`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
    } catch {
      // Silently fail
    }
  }, []);

  const dismissAll = useCallback(async () => {
    setNotices(prev => {
      const updated = prev.map(n => {
        if (!n.dismissed && n.dismissible !== false) {
          dismissLocally(n);
          return { ...n, dismissed: true };
        }
        return n;
      });
      setUnreadCount(updated.filter(n => !n.dismissed).length);
      return updated;
    });

    try {
      await authFetch('/api/openclaw/notices/dismiss-all', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
    } catch {
      // Silently fail
    }
  }, []);

  useEffect(() => {
    refresh();
    const interval = setInterval(refresh, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, [refresh]);

  return { notices, unreadCount, loading, refresh, dismiss, dismissAll };
}

export default function NoticeBanner({ notices, onDismiss, onOpenInbox }) {
  const bannerNotices = (notices || []).filter(
    n => !n.dismissed && (n.type === 'banner' || n.type === 'both')
  );

  if (bannerNotices.length === 0) return null;

  const count = bannerNotices.length;

  return (
    <div
      className="notice-banner-compact"
      onClick={onOpenInbox}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => { if (e.key === 'Enter') onOpenInbox?.(); }}
    >
      <Bell size={14} />
      <span className="notice-banner-count">{count}</span>
      <span className="notice-banner-label">
        new {count === 1 ? 'notification' : 'notifications'}
      </span>
    </div>
  );
}

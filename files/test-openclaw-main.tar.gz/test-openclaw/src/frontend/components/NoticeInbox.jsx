import React from 'react';
import { X, ExternalLink, Bell, AlertTriangle, AlertCircle, Info, Check } from 'lucide-react';

const PRIORITY_ICONS = {
  critical: AlertCircle,
  warning: AlertTriangle,
  info: Info,
};

const PRIORITY_STYLES = {
  critical: {
    badge: { background: 'var(--badge-error-bg)', color: 'var(--badge-error-text)' },
  },
  warning: {
    badge: { background: 'var(--badge-warning-bg)', color: 'var(--badge-warning-text)' },
  },
  info: {
    badge: { background: 'var(--badge-info-bg)', color: 'var(--badge-info-text)' },
  },
};

function timeAgo(dateStr) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 30) return `${days}d ago`;
  return new Date(dateStr).toLocaleDateString();
}

export default function NoticeInbox({ notices, onDismiss, onDismissAll, onClose }) {
  const nonExpired = notices || [];
  const undismissedCount = nonExpired.filter(n => !n.dismissed && n.dismissible !== false).length;

  return (
    <div className="notice-inbox-overlay" onClick={onClose} style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 'var(--overlay-bg)',
      zIndex: 1000,
      display: 'flex',
      justifyContent: 'flex-end',
    }}>
      <div
        className="notice-inbox-panel"
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '380px',
          maxWidth: '90vw',
          background: 'var(--bg-surface)',
          borderLeft: '1px solid var(--border-primary)',
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          boxShadow: '-4px 0 16px var(--dialog-shadow)',
        }}
      >
        {/* Header */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '14px 16px',
          borderBottom: '1px solid var(--border-primary)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontWeight: 600, fontSize: '0.9rem' }}>
            <Bell size={16} />
            Notices
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            {undismissedCount > 1 && onDismissAll && (
              <button
                onClick={onDismissAll}
                className="notices-dismiss-btn"
              >
                <Check size={12} />
                Dismiss all
              </button>
            )}
            <button
              onClick={onClose}
              style={{
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                color: 'var(--text-secondary)',
                padding: '4px',
              }}
              title="Close"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Notice List */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '8px' }}>
          {nonExpired.length === 0 ? (
            <div style={{
              padding: '40px 16px',
              textAlign: 'center',
              color: 'var(--text-muted)',
              fontSize: '0.85rem',
            }}>
              <Bell size={32} style={{ opacity: 0.3, marginBottom: '12px' }} />
              <div>No notices</div>
            </div>
          ) : (
            nonExpired.map((notice) => {
              const IconComponent = PRIORITY_ICONS[notice.priority] || Info;
              const styles = PRIORITY_STYLES[notice.priority] || PRIORITY_STYLES.info;
              const isDismissed = notice.dismissed;

              return (
                <div
                  key={notice.id}
                  style={{
                    padding: '12px',
                    borderRadius: '6px',
                    marginBottom: '6px',
                    background: isDismissed ? 'transparent' : 'var(--bg-subtle)',
                    border: `1px solid ${isDismissed ? 'var(--border-subtle)' : 'var(--border-primary)'}`,
                    opacity: isDismissed ? 0.5 : 1,
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'flex-start', gap: '8px' }}>
                    {/* Priority badge */}
                    <span
                      style={{
                        ...styles.badge,
                        display: 'inline-flex',
                        alignItems: 'center',
                        padding: '2px 6px',
                        borderRadius: '3px',
                        fontSize: '0.7rem',
                        fontWeight: 600,
                        flexShrink: 0,
                        gap: '3px',
                      }}
                    >
                      <IconComponent size={11} />
                      {notice.priority}
                    </span>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontWeight: 600, fontSize: '0.82rem', lineHeight: 1.3 }}>
                        {notice.title}
                      </div>
                      <div style={{
                        fontSize: '0.78rem',
                        color: 'var(--text-secondary)',
                        marginTop: '3px',
                        lineHeight: 1.4,
                      }}>
                        {notice.message}
                      </div>
                      <div style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '10px',
                        marginTop: '6px',
                      }}>
                        {notice.actionUrl && (
                          <a
                            href={notice.actionUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            style={{
                              fontSize: '0.75rem',
                              color: 'var(--accent)',
                              fontWeight: 600,
                              display: 'inline-flex',
                              alignItems: 'center',
                              gap: '3px',
                              textDecoration: 'none',
                            }}
                          >
                            {notice.actionLabel || 'Learn more'}
                            <ExternalLink size={11} />
                          </a>
                        )}
                        <span style={{
                          fontSize: '0.7rem',
                          color: 'var(--text-muted)',
                        }}>
                          {notice.createdAt ? timeAgo(notice.createdAt) : ''}
                        </span>
                      </div>
                    </div>
                    {/* Dismiss button */}
                    {!isDismissed && notice.dismissible !== false && onDismiss && (
                      <button
                        onClick={() => onDismiss(notice.id)}
                        style={{
                          background: 'none',
                          border: 'none',
                          cursor: 'pointer',
                          color: 'var(--text-muted)',
                          padding: '2px',
                          flexShrink: 0,
                        }}
                        title="Dismiss"
                      >
                        <X size={14} />
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}

import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useWizard } from '../context/WizardContext';

const SETTINGS_TABS = [
  { key: 'credentials', path: '/setup/credentials', label: 'Credentials & Models' },
  { key: 'channels', path: '/setup/channels', label: 'Channels' },
  { key: 'config', path: '/setup/config', label: 'Configuration' },
  { key: 'health', path: '/setup/health', label: 'Health' },
  { key: 'admin', path: '/setup/admin', label: 'Admin' },
];

export default function SettingsTabs() {
  const { completed } = useWizard();
  const location = useLocation();
  const navigate = useNavigate();

  const currentKey = SETTINGS_TABS.find(
    (t) => location.pathname === t.path || location.pathname.startsWith(t.path + '/')
  )?.key || (location.pathname === '/setup' ? 'health' : null);

  return (
    <div className="settings-tabs">
      {SETTINGS_TABS.map((tab) => (
        <button
          key={tab.key}
          className={`settings-tab${tab.key === currentKey ? ' active' : ''}${completed[tab.key] ? ' completed' : ''}`}
          onClick={() => navigate(tab.path)}
        >
          {completed[tab.key] && <span className="settings-tab-check">&#10003;</span>}
          {tab.label}
        </button>
      ))}
    </div>
  );
}

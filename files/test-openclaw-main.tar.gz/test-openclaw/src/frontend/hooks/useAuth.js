import { useState, useEffect, useCallback } from 'react';

const TOKEN_KEY = 'launcher_token';

export function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token) {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearToken() {
  localStorage.removeItem(TOKEN_KEY);
}

export function isTemporarySession() {
  const token = getToken();
  if (!token) return false;
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    return payload.type === 'temporary-session';
  } catch {
    return false;
  }
}

export function authFetch(url, options = {}) {
  const token = getToken();
  const headers = { ...options.headers };
  if (token) {
    headers['Authorization'] = 'Bearer ' + token;
  }
  return fetch(url, { ...options, headers }).then(res => {
    if (res.status === 401) {
      clearToken();
      window.location.href = '/login';
      return Promise.reject(new Error('Unauthorized'));
    }
    return res;
  });
}

export function useAuth() {
  const [isAuthenticated, setIsAuthenticated] = useState(!!getToken());

  const login = useCallback(async (password) => {
    const res = await fetch('/api/openclaw/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password }),
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.message || 'Login failed');
    }
    setToken(data.token);
    setIsAuthenticated(true);
    // The login endpoint already sets the gateway_ws_session cookie via Set-Cookie header,
    // but since we use fetch (not full page reload), the cookie is set automatically by the browser.
    return data;
  }, []);

  const logout = useCallback(() => {
    clearToken();
    setIsAuthenticated(false);
    window.location.href = '/login';
  }, []);

  useEffect(() => {
    const handleStorage = () => {
      setIsAuthenticated(!!getToken());
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  return { isAuthenticated, login, logout, getToken };
}

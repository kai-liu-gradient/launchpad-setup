// Tiny pub/sub store for sharing latest system stats (CPU/Memory)
// across components without a full React context.
// Writers: Shell.jsx (heartbeat pong), SystemStats.jsx (API response)
// Readers: Layout.jsx (sidebar badge)

let latest = null;
const listeners = new Set();

export function setSystemStats(stats) {
  latest = stats;
  listeners.forEach(fn => fn(stats));
}

export function getSystemStats() {
  return latest;
}

export function subscribe(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useWizard } from '../../context/WizardContext';
import { useAppConfig } from '../../context/AppConfigContext';
import { authFetch } from '../../hooks/useAuth';

export default function Complete() {
  const { completed, data } = useWizard();
  const { refresh } = useAppConfig();
  const navigate = useNavigate();
  const [health, setHealth] = useState(null);
  const [transitioning, setTransitioning] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const fetchHealth = async () => {
      try {
        const r = await authFetch('/api/openclaw/health');
        const data = await r.json();
        if (cancelled) return;
        setHealth(data);
        // If gateway isn't reachable yet, retry a few times
        if (!data?.gateway?.portReachable) {
          for (let i = 0; i < 10; i++) {
            await new Promise((resolve) => setTimeout(resolve, 2000));
            if (cancelled) return;
            try {
              const r2 = await authFetch('/api/openclaw/health');
              const data2 = await r2.json();
              if (cancelled) return;
              setHealth(data2);
              if (data2?.gateway?.portReachable) break;
            } catch {
              // keep retrying
            }
          }
        }
      } catch {
        // ignore
      }
    };
    fetchHealth();
    return () => { cancelled = true; };
  }, []);

  // Mark wizard as completed in localStorage so future visits skip the wizard
  useEffect(() => {
    localStorage.setItem('openclaw-wizard-completed', 'true');
  }, []);

  const handleGoToHealth = async () => {
    setTransitioning(true);
    // Refresh config then send user to health page to monitor gateway startup
    // and complete any remaining steps like Telegram pairing
    await refresh();
    navigate('/setup/health');
  };

  const checks = [
    {
      label: 'Credentials',
      ok: completed.credentials,
      detail: data.credentials?.skipped ? 'Skipped' : 'Configured',
    },
    {
      label: 'Telegram',
      ok: completed.channels,
      detail: data.channels?.skipped ? 'Skipped' : 'Configured',
    },
    {
      label: 'Configuration',
      ok: completed.config,
      detail: 'Saved',
    },
    {
      label: 'Gateway Running',
      ok: health?.gateway?.portReachable,
      detail: health?.gateway?.portReachable ? 'Online' : 'Offline',
    },
  ];

  return (
    <div className="card">
      <h2 className="card-title">Setup Complete</h2>
      <p style={{ color: 'var(--text-tertiary)', marginBottom: 20, fontSize: '0.9rem' }}>
        Here is a summary of your configuration status.
      </p>

      <div style={{ marginBottom: 24 }}>
        {checks.map((check) => (
          <div
            key={check.label}
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '12px 0',
              borderBottom: '1px solid var(--border-primary)',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ color: check.ok ? 'var(--badge-success-text)' : 'var(--badge-error-text)', fontSize: '1.1rem' }}>
                {check.ok ? '\u2713' : '\u2717'}
              </span>
              <span style={{ color: 'var(--text-primary)' }}>{check.label}</span>
            </div>
            <span className={`badge ${check.ok ? 'badge-success' : 'badge-warning'}`}>
              {check.ok ? check.detail : 'Pending'}
            </span>
          </div>
        ))}
      </div>

      <div style={{ display: 'flex', justifyContent: 'center', gap: 12 }}>
        <button
          onClick={handleGoToHealth}
          className="btn btn-primary"
          disabled={transitioning}
        >
          {transitioning ? 'Loading...' : 'Continue to Health Dashboard'}
        </button>
      </div>
    </div>
  );
}

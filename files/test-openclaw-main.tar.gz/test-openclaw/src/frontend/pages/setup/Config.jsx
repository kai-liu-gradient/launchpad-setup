import React, { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useWizard } from '../../context/WizardContext';
import { useAppConfig } from '../../context/AppConfigContext';
import { authFetch } from '../../hooks/useAuth';

// Resolve which configured provider owns a model by searching their model lists.
// Returns the provider name only when the model is explicitly found — never falls
// back to an arbitrary provider to avoid mis-attributing models.
function inferProviderFromModel(modelName, configData) {
  const providers = configData?.models?.providers;
  if (providers && typeof providers === 'object') {
    for (const [providerName, providerDef] of Object.entries(providers)) {
      const models = providerDef.models || [];
      for (const m of models) {
        const id = typeof m === 'string' ? m : m.id;
        if (id === modelName) return providerName;
      }
    }
  }
  return null;
}

function buildProviderModels(configData, activeProvider) {
  const providers = configData?.models?.providers;
  if (!providers || typeof providers !== 'object') return [];
  const seen = new Set();
  const result = [];
  for (const [providerName, providerDef] of Object.entries(providers)) {
    // If an active provider is known, only show models from that provider
    if (activeProvider && providerName !== activeProvider) continue;
    const models = providerDef.models || [];

    for (const m of models) {
      const modelId = typeof m === 'string' ? m : m.id;
      const qualifiedId = `${providerName}/${modelId}`;
      if (modelId && !seen.has(qualifiedId)) {
        seen.add(qualifiedId);
        result.push({
          value: qualifiedId,
          label: modelId,
        });
      }
    }
  }
  return result;
}

// Lightweight JSON syntax highlighter (returns HTML string)
function highlightJson(str) {
  return str.replace(
    /("(?:[^"\\]|\\.)*")\s*(:)|("(?:[^"\\]|\\.)*")|(true|false|null)|(-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)/g,
    (match, key, colon, strVal, keyword, num) => {
      if (key && colon) return `<span style="color:var(--accent)">${key}</span>${colon}`;
      if (strVal) return `<span style="color:var(--badge-success-text)">${strVal}</span>`;
      if (keyword) return `<span style="color:var(--badge-warning-text)">${keyword}</span>`;
      if (num) return `<span style="color:var(--badge-info-text)">${num}</span>`;
      return match;
    }
  );
}

export default function Config() {
  const [config, setConfig] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const gatewayPort = '18789';
  const [model, setModel] = useState('');
  const [customModel, setCustomModel] = useState('');
  const [useCustomModel, setUseCustomModel] = useState(false);
  const [thinkingDefault, setThinkingDefault] = useState('off');
  const [doctor, setDoctor] = useState(null);
  const [doctorLoading, setDoctorLoading] = useState(false);
  const [tokenStatus, setTokenStatus] = useState(null);
  const [tokenLoading, setTokenLoading] = useState(false);
  const [generatedToken, setGeneratedToken] = useState(null);
  const [tokenCopied, setTokenCopied] = useState(false);
  const { markCompleted, isConfigured } = useWizard();
  const { refresh: refreshAppConfig } = useAppConfig();
  const navigate = useNavigate();

  useEffect(() => {
    authFetch('/api/openclaw/config')
      .then((r) => {
        if (r.status === 404) throw new Error('404');
        if (!r.ok) throw new Error(`Config fetch failed: ${r.status}`);
        return r.json();
      })
      .then((data) => {
        setConfig({ exists: true, config: data });
        if (data.agents?.defaults?.thinkingDefault) setThinkingDefault(data.agents.defaults.thinkingDefault);

        // Build available models list from providers and set initial model selection
        let currentModel = data.agents?.defaults?.model?.primary || '';
        // Extract provider prefix from current model (e.g. "zai" from "zai/glm-4.7")
        const activeProvider = currentModel.includes('/') ? currentModel.split('/')[0] : null;
        const providerModels = buildProviderModels(data, activeProvider);
        const matchesProvider = providerModels.some((m) => m.value === currentModel);
        if (matchesProvider) {
          setModel(currentModel);
          setUseCustomModel(false);
        } else if (currentModel) {
          // Try matching without provider prefix for legacy configs
          const legacyMatch = providerModels.find((m) => m.value.endsWith('/' + currentModel));
          if (legacyMatch) {
            setModel(legacyMatch.value);
            setUseCustomModel(false);
          } else {
            setModel('__custom__');
            setCustomModel(currentModel);
            setUseCustomModel(true);
          }
        }

        setLoading(false);
      })
      .catch((err) => {
        if (err.message?.includes('404') || err.message?.includes('Not Found')) {
          setConfig({ exists: false });
        } else {
          setError(err.message);
        }
        setLoading(false);
      });
  }, []);

  const fetchTokenStatus = useCallback(() => {
    authFetch('/api/openclaw/config/token-status')
      .then((r) => { if (r.ok) return r.json(); return null; })
      .then((data) => { if (data) setTokenStatus(data); })
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (config?.exists) fetchTokenStatus();
  }, [config, fetchTokenStatus]);

  const handleRegenerateToken = async () => {
    setTokenLoading(true);
    setGeneratedToken(null);
    setTokenCopied(false);
    try {
      const res = await authFetch('/api/openclaw/config/regenerate-token', { method: 'POST' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Failed to regenerate token');
      setGeneratedToken(data.token);
      fetchTokenStatus();
    } catch (err) {
      setError(err.message);
    } finally {
      setTokenLoading(false);
    }
  };

  const handleCopyToken = () => {
    if (generatedToken) {
      navigator.clipboard.writeText(generatedToken).then(() => {
        setTokenCopied(true);
        setTimeout(() => setTokenCopied(false), 3000);
      });
    }
  };


  // Save progress modal state
  const [saveModal, setSaveModal] = useState(null); // null | { steps, currentStep, error }

  const SAVE_STEPS = [
    { key: 'save', label: 'Saving configuration' },
    { key: 'gateway', label: 'Restarting gateway' },
    { key: 'health', label: 'Verifying gateway health' },
    { key: 'done', label: 'Done' },
  ];

  const waitForGateway = async (maxAttempts = 15, intervalMs = 2000) => {
    for (let i = 0; i < maxAttempts; i++) {
      let processStatus = null;
      let portReachable = null;
      try {
        const res = await authFetch('/api/openclaw/health/gateway');
        if (res.ok) {
          const data = await res.json();
          processStatus = data.process?.status || 'unknown';
          portReachable = !!data.probe?.reachable;
          if (portReachable && processStatus === 'online') {
            setSaveModal(prev => prev ? { ...prev, detail: 'Gateway is online and reachable' } : prev);
            return true;
          }
        }
      } catch {
        // ignore, keep polling
      }
      const parts = [];
      if (processStatus) parts.push(`process: ${processStatus}`);
      else parts.push('process: waiting...');
      parts.push(portReachable ? 'port: reachable' : 'port: not yet reachable');
      setSaveModal(prev => prev ? {
        ...prev,
        detail: `Attempt ${i + 1}/${maxAttempts} — ${parts.join(', ')}`,
      } : prev);
      await new Promise((r) => setTimeout(r, intervalMs));
    }
    return false;
  };

  const handleSave = async () => {
    // Capture wizard mode before any async state changes flip isConfigured
    const wizardMode = !isConfigured;
    setError(null);
    setSaveModal({ steps: SAVE_STEPS, currentStep: 'save', error: null, detail: null });
    try {
      const isInit = !config?.exists;
      const body = {};
      let resolvedModel = useCustomModel ? customModel : model;

      // If the model has no provider prefix, infer the correct provider from model name
      if (resolvedModel && resolvedModel !== '__custom__' && !resolvedModel.includes('/')) {
        const provider = inferProviderFromModel(resolvedModel, config?.config);
        if (provider) resolvedModel = `${provider}/${resolvedModel}`;
      }

      if (gatewayPort) body.gateway = { port: parseInt(gatewayPort, 10) };
      if (resolvedModel && resolvedModel !== '__custom__') body.agents = { defaults: { model: { primary: resolvedModel } } };
      if (thinkingDefault) {
        body.agents = body.agents || {};
        body.agents.defaults = body.agents.defaults || {};
        body.agents.defaults.thinkingDefault = thinkingDefault;
      }

      let url = isInit ? '/api/openclaw/config/init' : '/api/openclaw/config';
      let method = isInit ? 'POST' : 'PATCH';

      let res = await authFetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      // If init returns 409 (config already exists), fall back to PATCH
      if (res.status === 409) {
        res = await authFetch('/api/openclaw/config', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body),
        });
      }

      if (!res.ok) {
        const errData = await res.json().catch(() => null);
        throw new Error(errData?.message || `Save failed (${res.status})`);
      }
      const data = await res.json();
      // Only mark config step complete if a model was actually selected
      const hasModel = resolvedModel && resolvedModel !== '__custom__' && resolvedModel !== '';
      if (hasModel) {
        markCompleted('config', data);
      }

      // Step: Restart gateway
      if (data.gatewayRestarted) {
        setSaveModal(prev => ({ ...prev, currentStep: 'gateway' }));
        // Brief pause to show the step
        await new Promise(r => setTimeout(r, 500));

        // Step: Verify health
        setSaveModal(prev => ({ ...prev, currentStep: 'health' }));
        await waitForGateway();
      }

      // Step: Done
      setSaveModal(prev => ({ ...prev, currentStep: 'done', detail: null, warnings: data.warnings || null }));
      await refreshAppConfig();

      setConfig({ exists: true, config: data.config || data });
      // Brief pause to show "Done" before redirect/close
      await new Promise(r => setTimeout(r, 800));
      setSaveModal(null);

      // Token may be auto-generated during init or PATCH (if missing) — show it
      if (data.generatedToken) {
        setGeneratedToken(data.generatedToken);
      }
      fetchTokenStatus();

      // Navigate forward in wizard mode (wizardMode captured before async ops
      // to avoid race with refreshAppConfig flipping isConfigured)
      if (wizardMode) {
        navigate('/setup/health');
        return;
      }

      // Run doctor check after save (background, settings mode only)
      setDoctorLoading(true);
      authFetch('/api/openclaw/doctor')
        .then(r => r.ok ? r.json() : null)
        .then(d => { if (d) setDoctor(d); })
        .catch(() => {})
        .finally(() => setDoctorLoading(false));

    } catch (err) {
      setSaveModal(prev => prev ? { ...prev, error: err.message } : null);
      setError(err.message);
    }
  };

  if (loading) {
    return (
      <div className="card">
        <div className="skeleton">
          <div className="skeleton-row" style={{ width: '35%' }} />
          <div className="skeleton-row" style={{ width: '80%' }} />
          <div className="skeleton-row-lg" style={{ width: '100%' }} />
          <div className="skeleton-row" style={{ width: '60%' }} />
          <div className="skeleton-row-lg" style={{ width: '100%' }} />
        </div>
      </div>
    );
  }

  return (
    <div>
    <div className="card">
      <h2 className="card-title">OpenClaw Configuration</h2>
      <p style={{ color: 'var(--text-tertiary)', marginBottom: 20, fontSize: '0.9rem' }}>
        {config?.exists
          ? 'Review and update your OpenClaw configuration.'
          : 'Initialize a new OpenClaw configuration.'}
      </p>

      {error && <div className="error-container" style={{ marginBottom: 16 }}>{error}</div>}

      <div className="input-group">
        <label className="input-label">Default Model</label>
        {(() => {
          const currentPrimary = config?.config?.agents?.defaults?.model?.primary || '';
          const allowedModels = config?.config?._launcher?.allowedModels || null;
          const activeProvider = currentPrimary.includes('/') ? currentPrimary.split('/')[0] : null;
          let providerModels = buildProviderModels(config?.config, activeProvider);
          // Filter by allowedModels restriction when set by the control API
          if (allowedModels && allowedModels.length > 0) {
            const allowedSet = new Set(allowedModels);
            providerModels = providerModels.filter((m) => allowedSet.has(m.value));
          }
          const showCustomOption = !allowedModels || allowedModels.length === 0;
          if (providerModels.length > 0) {
            return (
              <>
                <select
                  className="input"
                  value={useCustomModel ? '__custom__' : model}
                  onChange={(e) => {
                    if (e.target.value === '__custom__') {
                      setUseCustomModel(true);
                      setModel('__custom__');
                    } else {
                      setUseCustomModel(false);
                      setModel(e.target.value);
                      setCustomModel('');
                    }
                  }}
                >
                  <option value="">-- Select a model --</option>
                  {providerModels.map((m) => (
                    <option key={m.value} value={m.value}>{m.label}</option>
                  ))}
                  {showCustomOption && <option value="__custom__">Custom...</option>}
                </select>
                {useCustomModel && (
                  <input
                    className="input"
                    type="text"
                    value={customModel}
                    onChange={(e) => setCustomModel(e.target.value)}
                    placeholder="e.g. claude-sonnet-4-6"
                    style={{ marginTop: 8 }}
                  />
                )}
              </>
            );
          }
          return (
            <input
              className="input"
              type="text"
              value={model}
              onChange={(e) => setModel(e.target.value)}
              placeholder="e.g. claude-sonnet-4-6"
            />
          );
        })()}
      </div>

      <div className="input-group">
        <label className="input-label">Thinking Level</label>
        <select
          className="input"
          value={thinkingDefault}
          onChange={(e) => setThinkingDefault(e.target.value)}
        >
          <option value="off">Off (fastest responses)</option>
          <option value="minimal">Minimal</option>
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High (deepest reasoning)</option>
        </select>
        <span style={{ fontSize: '0.8rem', color: 'var(--text-tertiary)', marginTop: 4 }}>
          Controls extended thinking for AI responses. Higher levels produce more thorough reasoning but slower responses.
        </span>
      </div>

      <div className="input-group" style={{ marginTop: 16 }}>
        <label className="input-label">Gateway Auth Token</label>
        {config?.exists ? (
          /* Returning user: token has been seen before */
          <>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              marginBottom: 8,
            }}>
              {tokenStatus ? (
                <>
                  <span className={`badge ${
                    tokenStatus.strength === 'strong' ? 'badge-success' :
                    tokenStatus.strength === 'weak' ? 'badge-error' :
                    'badge-error'
                  }`}>
                    {tokenStatus.strength === 'strong' ? 'Strong' :
                     tokenStatus.strength === 'weak' ? 'Weak' : 'Missing'}
                  </span>
                  {tokenStatus.warning && (
                    <span style={{ color: 'var(--badge-error-text)', fontSize: '0.8rem' }}>
                      {tokenStatus.warning}
                    </span>
                  )}
                  {tokenStatus.strength === 'strong' && (
                    <span style={{ color: 'var(--text-secondary)', fontSize: '0.8rem' }}>
                      {tokenStatus.length}-char token configured
                    </span>
                  )}
                </>
              ) : (
                <span style={{ color: 'var(--text-secondary)', fontSize: '0.8rem' }}>Loading token status...</span>
              )}
            </div>

            {generatedToken && (
              <div style={{
                background: 'var(--success-light-bg)',
                border: '1px solid var(--success-light-border)',
                borderRadius: 6,
                padding: 12,
                marginBottom: 8,
              }}>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-tertiary)', marginBottom: 6 }}>
                  New token generated. Copy it now — it will not be shown again.
                </div>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                }}>
                  <code style={{
                    flex: 1,
                    background: 'var(--bg-surface)',
                    border: '1px solid var(--border-primary)',
                    borderRadius: 4,
                    padding: '6px 10px',
                    fontSize: '0.8rem',
                    fontFamily: "'JetBrains Mono', 'Fira Code', Consolas, monospace",
                    wordBreak: 'break-all',
                    color: 'var(--text-primary)',
                  }}>
                    {generatedToken}
                  </code>
                  <button className="btn btn-secondary btn-sm" onClick={handleCopyToken}>
                    {tokenCopied ? 'Copied!' : 'Copy'}
                  </button>
                </div>
              </div>
            )}

            <button
              className="btn btn-secondary btn-sm"
              onClick={handleRegenerateToken}
              disabled={tokenLoading}
            >
              {tokenLoading ? (
                <><span className="spinner" style={{ width: 12, height: 12 }} /> Generating...</>
              ) : (
                'Regenerate Token'
              )}
            </button>
          </>
        ) : (
          /* No config yet: initialize first, then generate token */
          <div style={{
            background: 'var(--info-box-bg)',
            border: '1px solid var(--info-box-border)',
            borderRadius: 6,
            padding: 12,
            fontSize: '0.85rem',
            color: 'var(--text-tertiary)',
          }}>
            A secure gateway auth token will be generated automatically when you initialize.
          </div>
        )}
      </div>

      {config?.config && (
        <details style={{ marginTop: 16 }}>
          <summary style={{ cursor: 'pointer', color: 'var(--accent)', fontSize: '0.85rem' }}>
            View detailed config (JSON)
          </summary>
          <pre style={{
            background: 'var(--config-pre-bg)',
            border: '1px solid var(--border-primary)',
            borderRadius: 6,
            padding: 12,
            marginTop: 8,
            fontSize: '0.8rem',
            overflow: 'auto',
            maxHeight: 400,
            color: 'var(--text-tree)',
            fontFamily: "'JetBrains Mono', 'Fira Code', Consolas, monospace",
          }} dangerouslySetInnerHTML={{ __html: highlightJson(JSON.stringify(config.config, null, 2)) }} />
        </details>
      )}

      {doctorLoading && (
        <div style={{ marginTop: 16, display: 'flex', alignItems: 'center', gap: 8 }}>
          <span className="spinner" style={{ width: 14, height: 14 }} />
          <span style={{ color: 'var(--text-secondary)', fontSize: '0.85rem' }}>Running doctor check...</span>
        </div>
      )}

      {doctor && !doctorLoading && (
        <details
          style={{ marginTop: 16 }}
          open={!doctor.ok}
        >
          <summary style={{ cursor: 'pointer', fontSize: '0.85rem', color: doctor.ok ? 'var(--accent)' : 'var(--badge-error-text)' }}>
            {doctor.ok ? 'Doctor: All checks passed' : 'Doctor: Issues detected'}
          </summary>
          <div style={{
            marginTop: 8,
            border: `1px solid ${doctor.ok ? 'var(--success-light-border)' : 'var(--error-border)'}`,
            borderRadius: 6,
            background: doctor.ok ? 'var(--success-light-bg)' : 'var(--error-light-bg)',
            padding: 12,
          }}>
            {doctor.sections.length > 0 ? doctor.sections.map((s, i) => (
              <div key={i} style={{ marginBottom: i < doctor.sections.length - 1 ? 12 : 0 }}>
                <div style={{ fontWeight: 'bold', fontSize: '0.85rem', marginBottom: 4, color: 'var(--text-primary)' }}>
                  {s.title}
                </div>
                <pre style={{
                  margin: 0,
                  fontSize: '0.8rem',
                  whiteSpace: 'pre-wrap',
                  color: 'var(--text-tree)',
                  fontFamily: "'JetBrains Mono', 'Fira Code', Consolas, monospace",
                }}>
                  {s.content}
                </pre>
              </div>
            )) : (
              <pre style={{
                margin: 0,
                fontSize: '0.8rem',
                whiteSpace: 'pre-wrap',
                color: 'var(--text-tree)',
                fontFamily: "'JetBrains Mono', 'Fira Code', Consolas, monospace",
              }}>
                {doctor.raw || 'No output from doctor.'}
              </pre>
            )}
          </div>
        </details>
      )}

      {config?.exists && tokenStatus?.strength === 'missing' && (
        <div className="error-container" style={{ marginTop: 16 }}>
          Gateway auth token is missing. Click the button below to generate one.
        </div>
      )}

      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, marginTop: 20 }}>
        {!isConfigured ? (
          <button className="btn btn-secondary" onClick={() => navigate('/setup/channels')}>
            Back
          </button>
        ) : (
          <div />
        )}
        {config?.exists && tokenStatus?.strength === 'missing' && !generatedToken ? (
          <button className="btn btn-primary" onClick={handleRegenerateToken} disabled={tokenLoading}>
            {tokenLoading ? (
              <><span className="spinner" /> Generating Token...</>
            ) : (
              'Generate Token'
            )}
          </button>
        ) : !isConfigured && generatedToken ? (
          <button className="btn btn-primary" onClick={() => navigate('/setup/health')}>
            Continue
          </button>
        ) : (
          <button className="btn btn-primary" onClick={handleSave} disabled={!!saveModal}>
            {isConfigured ? 'Save Changes' : config?.exists ? 'Update & Continue' : 'Initialize & Continue'}
          </button>
        )}
      </div>
    </div>

    {saveModal && (
      <div style={{
        position: 'fixed', inset: 0, zIndex: 1000,
        background: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <div style={{
          background: 'var(--bg-surface)', borderRadius: 12, padding: 24,
          width: 360, maxWidth: '90vw', boxShadow: '0 8px 32px rgba(0,0,0,0.3)',
        }}>
          <h3 style={{ color: 'var(--text-primary)', fontSize: '1rem', marginBottom: 20 }}>
            {saveModal.error ? 'Save Failed' : saveModal.currentStep === 'done' ? 'Complete' : 'Saving...'}
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {saveModal.steps.filter(s => s.key !== 'done').map((step) => {
              const isCurrent = saveModal.currentStep === step.key;
              const isDone = saveModal.steps.findIndex(s => s.key === saveModal.currentStep) >
                             saveModal.steps.findIndex(s => s.key === step.key);
              const isFailed = saveModal.error && isCurrent;
              return (
                <div key={step.key} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div style={{ width: 20, display: 'flex', justifyContent: 'center' }}>
                    {isFailed ? (
                      <span style={{ color: 'var(--badge-error-text)', fontSize: '1rem' }}>x</span>
                    ) : isDone ? (
                      <span style={{ color: 'var(--badge-success-text)', fontSize: '1rem' }}>&#10003;</span>
                    ) : isCurrent ? (
                      <span className="spinner" style={{ width: 14, height: 14 }} />
                    ) : (
                      <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--border-secondary)', display: 'inline-block' }} />
                    )}
                  </div>
                  <div>
                    <span style={{
                      fontSize: '0.85rem',
                      color: isDone ? 'var(--text-secondary)' : isCurrent ? 'var(--text-primary)' : 'var(--text-tertiary)',
                      fontWeight: isCurrent ? 600 : 400,
                    }}>
                      {step.label}
                    </span>
                    {isCurrent && saveModal.detail && (
                      <div style={{
                        fontSize: '0.75rem',
                        color: 'var(--text-tertiary)',
                        marginTop: 2,
                        fontFamily: "'JetBrains Mono', 'Fira Code', Consolas, monospace",
                      }}>
                        {saveModal.detail}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
          {saveModal.warnings && saveModal.warnings.length > 0 && (
            <div style={{
              marginTop: 16,
              background: 'var(--info-box-bg)',
              border: '1px solid var(--info-box-border)',
              borderRadius: 6,
              padding: 10,
              fontSize: '0.8rem',
              color: 'var(--text-tertiary)',
            }}>
              <div style={{ fontWeight: 600, marginBottom: 4 }}>Warnings:</div>
              {saveModal.warnings.map((w, i) => (
                <div key={i}>{w}</div>
              ))}
            </div>
          )}
          {saveModal.error && (
            <div style={{ marginTop: 16 }}>
              <div className="error-container" style={{ fontSize: '0.8rem', marginBottom: 12 }}>{saveModal.error}</div>
              <button className="btn btn-secondary" onClick={() => setSaveModal(null)} style={{ width: '100%' }}>
                Close
              </button>
            </div>
          )}
        </div>
      </div>
    )}

    </div>
  );
}

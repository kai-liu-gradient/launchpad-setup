import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useWizard } from '../../context/WizardContext';
import { authFetch } from '../../hooks/useAuth';

const tabStyle = (isActive) => ({
  padding: '8px 16px',
  border: 'none',
  borderBottom: isActive ? '2px solid var(--accent)' : '2px solid transparent',
  background: 'none',
  color: isActive ? 'var(--accent)' : 'var(--text-secondary)',
  fontWeight: isActive ? 600 : 400,
  cursor: 'pointer',
  fontSize: '0.9rem',
  transition: 'color 0.15s, border-color 0.15s',
});

const infoBoxStyle = {
  background: 'var(--info-box-bg)',
  border: '1px solid var(--info-box-border)',
  borderRadius: 8,
  padding: 16,
  marginBottom: 20,
  fontSize: '0.85rem',
  color: 'var(--text-tertiary)',
};

const successBoxStyle = {
  background: 'var(--success-box-bg)',
  border: '1px solid var(--success-box-border)',
  borderRadius: 8,
  padding: 16,
  marginBottom: 16,
};

const testResultStyle = (ok) => ({
  marginTop: 12,
  padding: '10px 14px',
  borderRadius: 6,
  fontSize: '0.85rem',
  background: ok ? 'var(--success-box-bg)' : 'var(--badge-error-bg, #f8d7da)',
  color: ok ? 'var(--success-box-text)' : 'var(--badge-error-text, #721c24)',
  border: `1px solid ${ok ? 'var(--success-box-border)' : 'var(--badge-error-text, #f5c6cb)'}`,
});

function StatusDot({ ok }) {
  return <span className={`status-dot ${ok ? 'online' : 'offline'}`} />;
}

export default function Channels() {
  const { channel } = useParams();
  const initialTab = (channel === 'feishu' || channel === 'telegram') ? channel : 'telegram';
  const [activeTab, setActiveTab] = useState(initialTab);
  const [loading, setLoading] = useState(true);

  // Telegram state
  const [tgToken, setTgToken] = useState('');
  const [tgBotInfo, setTgBotInfo] = useState(null);
  const [tgValidating, setTgValidating] = useState(false);
  const [tgSaving, setTgSaving] = useState(false);
  const [tgError, setTgError] = useState(null);
  const [tgExisting, setTgExisting] = useState(null);
  const [tgReconfiguring, setTgReconfiguring] = useState(false);
  const [tgTesting, setTgTesting] = useState(false);
  const [tgTestResult, setTgTestResult] = useState(null);

  // Feishu state
  const [fsAppId, setFsAppId] = useState('');
  const [fsAppSecret, setFsAppSecret] = useState('');
  const [fsDomain, setFsDomain] = useState('feishu');
  const [fsConnectionMode, setFsConnectionMode] = useState('websocket');
  const [fsBotInfo, setFsBotInfo] = useState(null);
  const [fsValidating, setFsValidating] = useState(false);
  const [fsSaving, setFsSaving] = useState(false);
  const [fsError, setFsError] = useState(null);
  const [fsExisting, setFsExisting] = useState(null);
  const [fsReconfiguring, setFsReconfiguring] = useState(false);
  const [fsTesting, setFsTesting] = useState(false);
  const [fsTestResult, setFsTestResult] = useState(null);
  const [fsCopied, setFsCopied] = useState(false);
  const [fsScopesCopied, setFsScopesCopied] = useState(false);
  const [fsEventCopied, setFsEventCopied] = useState(false);
  const [fsScopesExpanded, setFsScopesExpanded] = useState(false);
  const [fsEventExpanded, setFsEventExpanded] = useState(false);
  const [fsPluginVersion, setFsPluginVersion] = useState('');
  const [fsEncryptKey, setFsEncryptKey] = useState('');
  const [fsVerificationToken, setFsVerificationToken] = useState('');

  // WebSocket probe state
  const [fsWsProbing, setFsWsProbing] = useState(false);
  const [fsWsProbeResult, setFsWsProbeResult] = useState(null);
  const [fsWsProbeSessionId, setFsWsProbeSessionId] = useState(null);
  const [fsWsProbePolling, setFsWsProbePolling] = useState(false);
  const [fsShowWsPrompt, setFsShowWsPrompt] = useState(false);

  const { markCompleted } = useWizard();
  const navigate = useNavigate();

  useEffect(() => {
    Promise.all([
      authFetch('/api/openclaw/telegram/pairing-status').then((r) => r.json()).catch(() => null),
      authFetch('/api/openclaw/feishu/status').then((r) => r.json()).catch(() => null),
    ]).then(([tgData, fsData]) => {
      if (tgData?.configured) setTgExisting(tgData);
      if (fsData?.configured) setFsExisting(fsData);
      // Auto-select the configured channel tab when no explicit channel param
      if (!channel && fsData?.configured && !tgData?.configured) {
        setActiveTab('feishu');
      }
      // Mark channels step complete if at least one channel is configured
      if (tgData?.configured || fsData?.configured) {
        const channelData = {};
        if (tgData?.configured) channelData.telegram = true;
        if (fsData?.configured) channelData.feishu = true;
        markCompleted('channels', channelData);
      }
    }).finally(() => setLoading(false));
  }, []);

  // ========== Telegram handlers ==========

  const handleTgValidate = async () => {
    if (!tgToken.trim()) return;
    setTgValidating(true);
    setTgError(null);
    setTgBotInfo(null);
    try {
      const res = await authFetch('/api/openclaw/telegram/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: tgToken.trim() }),
      });
      const data = await res.json().catch(() => { throw new Error('Unexpected response from server'); });
      if (!res.ok) throw new Error(data.message || data.error || 'Validation failed');
      setTgBotInfo(data.bot || data);
    } catch (err) {
      setTgError(err.message);
    } finally {
      setTgValidating(false);
    }
  };

  const handleTgSave = async () => {
    setTgSaving(true);
    setTgError(null);
    try {
      const res = await authFetch('/api/openclaw/telegram/configure', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: tgToken.trim() }),
      });
      const data = await res.json().catch(() => { throw new Error('Unexpected response from server'); });
      if (!res.ok) throw new Error(data.message || data.error || 'Failed to save');
      setTgExisting({ configured: true, botInfo: data.bot });
      setTgReconfiguring(false);
      setTgBotInfo(null);
      setTgToken('');
    } catch (err) {
      setTgError(err.message);
    } finally {
      setTgSaving(false);
    }
  };

  const handleTgTest = async () => {
    setTgTesting(true);
    setTgTestResult(null);
    try {
      const res = await authFetch('/api/openclaw/telegram/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      const data = await res.json().catch(() => { throw new Error('Unexpected response'); });
      if (!res.ok) throw new Error(data.message || data.error || 'Test failed');
      setTgTestResult({ ok: true, message: data.message, bot: data.bot });
    } catch (err) {
      setTgTestResult({ ok: false, message: err.message });
    } finally {
      setTgTesting(false);
    }
  };

  // ========== Feishu handlers ==========

  const handleFsValidate = async () => {
    if (!fsAppId.trim() || !fsAppSecret.trim()) return;
    setFsValidating(true);
    setFsError(null);
    setFsBotInfo(null);
    try {
      const res = await authFetch('/api/openclaw/feishu/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ appId: fsAppId.trim(), appSecret: fsAppSecret.trim(), domain: fsDomain }),
      });
      const data = await res.json().catch(() => { throw new Error('Unexpected response from server'); });
      if (!res.ok) throw new Error(data.message || data.error || 'Validation failed');
      setFsBotInfo(data.bot || data);
    } catch (err) {
      setFsError(err.message);
    } finally {
      setFsValidating(false);
    }
  };

  const handleFsSave = async () => {
    setFsSaving(true);
    setFsError(null);
    try {
      const res = await authFetch('/api/openclaw/feishu/configure', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          appId: fsAppId.trim(),
          appSecret: fsAppSecret.trim(),
          domain: fsDomain,
          connectionMode: fsConnectionMode,
          ...(fsPluginVersion.trim() ? { pluginVersion: fsPluginVersion.trim() } : {}),
          ...(fsEncryptKey.trim() ? { encryptKey: fsEncryptKey.trim() } : {}),
          ...(fsVerificationToken.trim() ? { verificationToken: fsVerificationToken.trim() } : {}),
        }),
      });
      const data = await res.json().catch(() => { throw new Error('Unexpected response from server'); });
      if (!res.ok) throw new Error(data.message || data.error || 'Failed to save');
      setFsExisting({
        configured: true,
        domain: fsDomain,
        connectionMode: fsConnectionMode,
        botInfo: data.bot,
        pluginVersion: data.pluginVersion || fsPluginVersion.trim() || null,
      });
      setFsReconfiguring(false);
      setFsBotInfo(null);
      setFsAppId('');
      setFsAppSecret('');
      setFsPluginVersion('');
      // Show WebSocket probe prompt for websocket mode
      if (fsConnectionMode !== 'webhook') {
        setFsShowWsPrompt(true);
        setFsWsProbeResult(null);
      }
    } catch (err) {
      setFsError(err.message);
    } finally {
      setFsSaving(false);
    }
  };

  const handleFsTest = async () => {
    setFsTesting(true);
    setFsTestResult(null);
    try {
      const res = await authFetch('/api/openclaw/feishu/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      const data = await res.json().catch(() => { throw new Error('Unexpected response'); });
      if (!res.ok) throw new Error(data.message || data.error || 'Test failed');
      setFsTestResult({ ok: true, message: data.message, bot: data.bot });
    } catch (err) {
      setFsTestResult({ ok: false, message: err.message });
    } finally {
      setFsTesting(false);
    }
  };

  const handleFsWsProbe = async () => {
    setFsWsProbing(true);
    setFsWsProbeResult(null);
    setFsWsProbeSessionId(null);
    try {
      const res = await authFetch('/api/openclaw/feishu/ws-probe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      const data = await res.json().catch(() => { throw new Error('Unexpected response'); });
      if (!res.ok) throw new Error(data.message || data.error || 'Probe failed');
      setFsWsProbeResult(data);
      setFsWsProbeSessionId(data.sessionId);
      // If connected, keep polling until user stops or connection drops (up to 5 min)
      if (data.status === 'connected' && data.sessionId) {
        setFsWsProbePolling(true);
        const pollInterval = setInterval(async () => {
          try {
            const pollRes = await authFetch(`/api/openclaw/feishu/ws-probe/${data.sessionId}`);
            const pollData = await pollRes.json().catch(() => null);
            if (pollData) setFsWsProbeResult(pollData);
            if (!pollData || pollData.status !== 'connected') {
              clearInterval(pollInterval);
              setFsWsProbePolling(false);
            }
          } catch {
            clearInterval(pollInterval);
            setFsWsProbePolling(false);
          }
        }, 3000);
        // Store interval ID so stop can clear it
        window.__fsWsProbeInterval = pollInterval;
      }
    } catch (err) {
      setFsWsProbeResult({ status: 'failed', error: err.message, steps: [] });
    } finally {
      setFsWsProbing(false);
    }
  };

  const handleFsWsProbeStop = async () => {
    if (window.__fsWsProbeInterval) {
      clearInterval(window.__fsWsProbeInterval);
      window.__fsWsProbeInterval = null;
    }
    if (fsWsProbeSessionId) {
      await authFetch(`/api/openclaw/feishu/ws-probe/${fsWsProbeSessionId}`, { method: 'DELETE' }).catch(() => {});
    }
    setFsWsProbePolling(false);
    setFsWsProbing(false);
  };

  const handleCopyWebhookPath = () => {
    navigator.clipboard.writeText(`${window.location.origin}/feishu/events`).then(() => {
      setFsCopied(true);
      setTimeout(() => setFsCopied(false), 2000);
    }).catch(() => {});
  };

  // ========== Navigation ==========

  const handleContinue = () => {
    const channelData = {};
    if (tgExisting?.configured) channelData.telegram = true;
    if (fsExisting?.configured) channelData.feishu = true;
    if (!channelData.telegram && !channelData.feishu) {
      channelData.skipped = true;
    }
    markCompleted('channels', channelData);
    navigate('/setup/config');
  };

  // ========== Render ==========

  if (loading) {
    return (
      <div className="card">
        <div className="skeleton">
          <div className="skeleton-row" style={{ width: '50%' }} />
          <div className="skeleton-row" style={{ width: '90%' }} />
          <div className="skeleton-row-lg" style={{ width: '100%' }} />
          <div className="skeleton-row" style={{ width: '70%' }} />
        </div>
      </div>
    );
  }

  return (
    <div className="card">
      <h2 className="card-title">Channel Configuration</h2>
      <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', marginBottom: 16 }}>
        Configure messaging channels to connect your OpenClaw assistant to chat platforms.
      </p>

      {/* ==================== Configured Channels (shared section) ==================== */}
      {((tgExisting && !tgReconfiguring) || (fsExisting && !fsReconfiguring)) && (
        <div style={{ marginBottom: 20 }}>
          {/* Telegram status */}
          {tgExisting && !tgReconfiguring && (
            <div style={successBoxStyle}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                <StatusDot ok />
                <strong style={{ color: 'var(--success-box-text)' }}>Telegram Bot Configured</strong>
              </div>
              <div style={{ fontSize: '0.85rem', color: 'var(--success-box-detail)' }}>
                {tgExisting.botInfo?.username && <div>Username: @{tgExisting.botInfo.username}</div>}
                {tgExisting.botInfo?.firstName && <div>Name: {tgExisting.botInfo.firstName}</div>}
                {tgExisting.botInfo?.id && <div>Bot ID: {tgExisting.botInfo.id}</div>}
                {tgExisting.dmPolicy && <div>DM Policy: {tgExisting.dmPolicy}</div>}
                {tgExisting.streamMode && <div>Stream Mode: {tgExisting.streamMode}</div>}
                {tgExisting.gatewayReachable !== undefined && (
                  <div>Gateway: {tgExisting.gatewayReachable ? 'Reachable' : 'Not reachable'}</div>
                )}
              </div>
              <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
                <button className="btn btn-secondary btn-sm" onClick={() => { setActiveTab('telegram'); setTgReconfiguring(true); }}>
                  Reconfigure
                </button>
                <button
                  className="btn btn-secondary btn-sm"
                  onClick={handleTgTest}
                  disabled={tgTesting}
                >
                  {tgTesting ? <><span className="spinner" style={{ width: 13, height: 13, borderWidth: 2 }} /> Testing...</> : 'Quick Test'}
                </button>
              </div>
              {tgTestResult && (
                <div style={testResultStyle(tgTestResult.ok)}>
                  <strong>{tgTestResult.ok ? 'Test Passed' : 'Test Failed'}</strong>
                  <div style={{ marginTop: 4 }}>{tgTestResult.message}</div>
                  {tgTestResult.ok && tgTestResult.bot && (
                    <div style={{ marginTop: 4, fontSize: '0.8rem' }}>
                      {tgTestResult.bot.username && <span>@{tgTestResult.bot.username}</span>}
                      {tgTestResult.bot.firstName && <span> ({tgTestResult.bot.firstName})</span>}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Feishu status */}
          {fsExisting && !fsReconfiguring && (
            <div style={successBoxStyle}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                <StatusDot ok />
                <strong style={{ color: 'var(--success-box-text)' }}>Feishu{fsExisting.domain === 'lark' ? ' (Lark)' : ''} Channel Configured</strong>
              </div>
              <div style={{ fontSize: '0.85rem', color: 'var(--success-box-detail)' }}>
                <div>Platform: {fsExisting.domain === 'lark' ? 'Lark (International)' : 'Feishu (China)'}</div>
                <div>Connection Mode: {fsExisting.connectionMode === 'webhook' ? 'Webhook Callback' : 'WebSocket (Long Connection)'}</div>
                {fsExisting.botInfo?.app_name && <div>App Name: {fsExisting.botInfo.app_name}</div>}
                {fsExisting.pluginVersion && <div>Plugin Version: {fsExisting.pluginVersion}</div>}
                {fsExisting.connectionMode === 'webhook' && (
                  <>
                    <div>Encrypt Key: {fsExisting.hasEncryptKey ? 'Configured' : 'Not set'}</div>
                    <div>Verification Token: {fsExisting.hasVerificationToken ? 'Configured' : 'Not set'}</div>
                  </>
                )}
                {fsExisting.dmPolicy && <div>DM Policy: {fsExisting.dmPolicy}</div>}
                {fsExisting.gatewayReachable !== undefined && (
                  <div>Gateway: {fsExisting.gatewayReachable ? 'Reachable' : 'Not reachable'}</div>
                )}
              </div>

              {/* Webhook path display for webhook mode */}
              {fsExisting.connectionMode === 'webhook' && (
                <div style={{
                  background: 'var(--bg-surface-alt)',
                  border: '1px solid var(--border-primary)',
                  borderRadius: 6,
                  padding: '10px 14px',
                  marginTop: 10,
                  fontSize: '0.83rem',
                }}>
                  <div style={{ fontWeight: 600, color: 'var(--text-primary)', marginBottom: 6 }}>Webhook Callback URL</div>
                  <div style={{ color: 'var(--text-secondary)', marginBottom: 6, fontSize: '0.8rem' }}>
                    Set this as the Request URL in Feishu Open Platform's Event Subscription settings:
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <code style={{
                      flex: 1,
                      background: 'var(--bg-primary)',
                      padding: '6px 10px',
                      borderRadius: 4,
                      fontSize: '0.82rem',
                      color: 'var(--text-primary)',
                      wordBreak: 'break-all',
                    }}>
                      {window.location.origin}/feishu/events
                    </code>
                    <button
                      className="btn btn-secondary btn-sm"
                      onClick={handleCopyWebhookPath}
                      style={{ whiteSpace: 'nowrap' }}
                    >
                      {fsCopied ? 'Copied!' : 'Copy'}
                    </button>
                  </div>
                </div>
              )}

              {/* WebSocket probe prompt — shown after saving in websocket mode */}
              {fsShowWsPrompt && fsExisting.connectionMode !== 'webhook' && !fsWsProbeResult && (
                <div style={{
                  background: 'var(--info-box-bg)',
                  border: '1px solid var(--info-box-border)',
                  borderRadius: 6,
                  padding: '12px 14px',
                  marginTop: 10,
                  fontSize: '0.83rem',
                }}>
                  <div style={{ fontWeight: 600, color: 'var(--text-primary)', marginBottom: 6 }}>
                    Verify WebSocket Event Subscription
                  </div>
                  <div style={{ color: 'var(--text-secondary)', fontSize: '0.8rem', marginBottom: 10 }}>
                    WebSocket mode requires your app to have the <code style={{ background: 'var(--info-code-bg)', padding: '2px 5px', borderRadius: 3 }}>im.message.receive_v1</code> event subscription configured.
                    Test the connection now to verify your event subscription is working, or skip if you've already configured it.
                  </div>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button
                      className="btn btn-primary btn-sm"
                      onClick={handleFsWsProbe}
                      disabled={fsWsProbing}
                    >
                      {fsWsProbing ? <><span className="spinner" style={{ width: 13, height: 13, borderWidth: 2 }} /> Testing...</> : 'Test WebSocket Connection'}
                    </button>
                    <button
                      className="btn btn-secondary btn-sm"
                      onClick={() => setFsShowWsPrompt(false)}
                    >
                      Skip
                    </button>
                  </div>
                </div>
              )}

              <div style={{ display: 'flex', gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
                <button className="btn btn-secondary btn-sm" onClick={() => { setActiveTab('feishu'); setFsReconfiguring(true); }}>
                  Reconfigure
                </button>
                <button
                  className="btn btn-secondary btn-sm"
                  onClick={handleFsTest}
                  disabled={fsTesting}
                >
                  {fsTesting ? <><span className="spinner" style={{ width: 13, height: 13, borderWidth: 2 }} /> Testing...</> : 'Quick Test'}
                </button>
                {fsExisting.connectionMode !== 'webhook' && (
                  <button
                    className="btn btn-secondary btn-sm"
                    onClick={handleFsWsProbe}
                    disabled={fsWsProbing || fsWsProbePolling}
                  >
                    {fsWsProbing ? <><span className="spinner" style={{ width: 13, height: 13, borderWidth: 2 }} /> Probing...</> : 'Test WebSocket'}
                  </button>
                )}
              </div>
              {fsTestResult && (
                <div style={testResultStyle(fsTestResult.ok)}>
                  <strong>{fsTestResult.ok ? 'Test Passed' : 'Test Failed'}</strong>
                  <div style={{ marginTop: 4 }}>{fsTestResult.message}</div>
                  {fsTestResult.ok && fsTestResult.bot && (
                    <div style={{ marginTop: 4, fontSize: '0.8rem' }}>
                      {fsTestResult.bot.app_name && <span>App: {fsTestResult.bot.app_name}</span>}
                    </div>
                  )}
                </div>
              )}
              {fsWsProbeResult && (
                <div style={testResultStyle(fsWsProbeResult.status === 'connected' || fsWsProbeResult.status === 'stopped')}>
                  <strong>
                    {fsWsProbeResult.status === 'connected' || fsWsProbeResult.status === 'stopped'
                      ? 'WebSocket Connection Successful'
                      : fsWsProbeResult.status === 'failed'
                        ? 'WebSocket Connection Failed'
                        : 'WebSocket Probe'}
                  </strong>
                  {fsWsProbeResult.error && (
                    <div style={{ marginTop: 4 }}>{fsWsProbeResult.error}</div>
                  )}
                  {fsWsProbeResult.steps?.length > 0 && (
                    <div style={{ marginTop: 6, fontSize: '0.8rem', lineHeight: 1.6 }}>
                      {fsWsProbeResult.steps.map((step, i) => (
                        <div key={i} style={{ opacity: step.ok ? 1 : 0.9 }}>
                          <span style={{ marginRight: 4 }}>{step.ok ? '\u2713' : '\u2717'}</span>
                          {step.message}
                        </div>
                      ))}
                    </div>
                  )}
                  {fsWsProbePolling && (
                    <div style={{ marginTop: 6, fontSize: '0.8rem', color: 'var(--text-tertiary)' }}>
                      <span className="spinner" style={{ width: 11, height: 11, borderWidth: 2, display: 'inline-block', verticalAlign: 'middle', marginRight: 6 }} />
                      Connected — listening for events...
                      <button
                        className="btn btn-secondary btn-sm"
                        onClick={handleFsWsProbeStop}
                        style={{ marginLeft: 8, fontSize: '0.75rem' }}
                      >
                        Disconnect
                      </button>
                    </div>
                  )}
                  {/* Show required event subscription info alongside probe results */}
                  <div style={{
                    marginTop: 10,
                    padding: '8px 10px',
                    background: 'var(--info-code-bg)',
                    borderRadius: 4,
                    fontSize: '0.78rem',
                    lineHeight: 1.7,
                  }}>
                    <div style={{ fontWeight: 600, marginBottom: 4, color: 'var(--text-primary)' }}>Required Event Subscription</div>
                    <div style={{ color: 'var(--text-secondary)' }}>
                      In your Feishu/Lark app console, go to <strong>Event Subscriptions</strong> and add:
                    </div>
                    <div style={{ marginTop: 4 }}>
                      <code style={{ background: 'var(--bg-secondary)', padding: '2px 6px', borderRadius: 3, userSelect: 'all' }}>im.message.receive_v1</code>
                      <span style={{ color: 'var(--text-tertiary)', marginLeft: 6 }}>— Receive messages</span>
                    </div>
                    <div style={{ marginTop: 4, color: 'var(--text-tertiary)', fontSize: '0.75rem' }}>
                      Ensure the app is published/available after adding the subscription. The WebSocket connection will receive events only after this is configured.
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Tab bar */}
      <div style={{ display: 'flex', gap: 0, borderBottom: '1px solid var(--border-primary)', marginBottom: 20 }}>
        <button style={tabStyle(activeTab === 'telegram')} onClick={() => setActiveTab('telegram')}>
          Telegram
          {tgExisting?.configured && <span style={{ marginLeft: 6, color: 'var(--badge-success-text)', fontSize: '0.75rem' }}>{'\u2713'}</span>}
        </button>
        <button style={tabStyle(activeTab === 'feishu')} onClick={() => setActiveTab('feishu')}>
          Feishu / Lark
          {fsExisting?.configured && <span style={{ marginLeft: 6, color: 'var(--badge-success-text)', fontSize: '0.75rem' }}>{'\u2713'}</span>}
        </button>
      </div>

      {/* ==================== Telegram Tab ==================== */}
      {activeTab === 'telegram' && (
        <>
          {tgExisting && !tgReconfiguring ? (
            <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
              Telegram is configured. Use the controls above to test or reconfigure.
            </div>
          ) : (
            <>
              <div style={infoBoxStyle}>
                <p style={{ marginBottom: 8, color: 'var(--text-primary)', fontWeight: 'bold' }}>How to create a Telegram bot:</p>
                <ol style={{ paddingLeft: 20, lineHeight: 1.8 }}>
                  <li>Open Telegram and search for <strong style={{ color: 'var(--accent)' }}>@BotFather</strong></li>
                  <li>Send <code style={{ background: 'var(--info-code-bg)', padding: '2px 6px', borderRadius: 4 }}>/newbot</code> and follow the prompts</li>
                  <li>Copy the bot token provided by BotFather</li>
                  <li>Paste it below and click Validate</li>
                </ol>
              </div>

              <div className="input-group">
                <label className="input-label">Bot Token</label>
                <input
                  className="input"
                  type="text"
                  placeholder="123456789:ABCdefGHIjklMNOpqrsTUVwxyz"
                  value={tgToken}
                  onChange={(e) => setTgToken(e.target.value)}
                />
              </div>

              {tgError && <div className="error-container" style={{ marginBottom: 16 }}>{tgError}</div>}

              {tgBotInfo && (
                <div style={successBoxStyle}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                    <StatusDot ok />
                    <strong style={{ color: 'var(--success-box-text)' }}>Bot Validated Successfully</strong>
                  </div>
                  <div style={{ fontSize: '0.85rem', color: 'var(--success-box-detail)' }}>
                    {tgBotInfo.username && <div>Username: @{tgBotInfo.username}</div>}
                    {(tgBotInfo.firstName || tgBotInfo.first_name) && <div>Name: {tgBotInfo.firstName || tgBotInfo.first_name}</div>}
                    {tgBotInfo.id && <div>Bot ID: {tgBotInfo.id}</div>}
                    {(tgBotInfo.canJoinGroups !== undefined || tgBotInfo.can_join_groups !== undefined) && (
                      <div>Can join groups: {(tgBotInfo.canJoinGroups ?? tgBotInfo.can_join_groups) ? 'Yes' : 'No'}</div>
                    )}
                  </div>
                </div>
              )}

              <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
                {tgReconfiguring && (
                  <button className="btn btn-secondary btn-sm" onClick={() => { setTgReconfiguring(false); setTgError(null); setTgBotInfo(null); setTgToken(''); }}>
                    Cancel
                  </button>
                )}
                {!tgBotInfo ? (
                  <button
                    className="btn btn-primary btn-sm"
                    onClick={handleTgValidate}
                    disabled={!tgToken.trim() || tgValidating}
                  >
                    {tgValidating ? <><span className="spinner" style={{ width: 13, height: 13, borderWidth: 2 }} /> Validating...</> : 'Validate'}
                  </button>
                ) : (
                  <button
                    className="btn btn-primary btn-sm"
                    onClick={handleTgSave}
                    disabled={tgSaving}
                  >
                    {tgSaving ? <><span className="spinner" style={{ width: 13, height: 13, borderWidth: 2 }} /> Saving...</> : 'Save'}
                  </button>
                )}
              </div>
            </>
          )}
        </>
      )}

      {/* ==================== Feishu Tab ==================== */}
      {activeTab === 'feishu' && (
        <>
          {fsExisting && !fsReconfiguring ? (
            <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
              Feishu is configured. Use the controls above to test or reconfigure.
            </div>
          ) : (
            <>
              {/* Platform selector — shown first so all subsequent UI adapts */}
              <div className="input-group" style={{ marginBottom: 16 }}>
                <label className="input-label">Platform</label>
                <div style={{ display: 'flex', gap: 10, maxWidth: 280 }}>
                  <button
                    type="button"
                    onClick={() => setFsDomain('feishu')}
                    disabled={!!fsBotInfo || fsValidating}
                    style={{
                      flex: 1,
                      padding: '8px 14px',
                      borderRadius: 8,
                      border: `2px solid ${fsDomain === 'feishu' ? 'var(--accent)' : 'var(--border-primary)'}`,
                      background: fsDomain === 'feishu' ? 'var(--accent-bg, rgba(99,102,241,0.08))' : 'var(--bg-surface-alt)',
                      color: fsDomain === 'feishu' ? 'var(--accent)' : 'var(--text-secondary)',
                      cursor: (fsBotInfo || fsValidating) ? 'not-allowed' : 'pointer',
                      opacity: (fsBotInfo || fsValidating) ? 0.6 : 1,
                      fontWeight: fsDomain === 'feishu' ? 600 : 400,
                      fontSize: '0.9rem',
                      textAlign: 'center',
                      transition: 'all 0.15s ease',
                    }}
                  >
                    飞书 Feishu<br />
                    <span style={{ fontSize: '0.75rem', fontWeight: 400, opacity: 0.8 }}>中国</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setFsDomain('lark')}
                    disabled={!!fsBotInfo || fsValidating}
                    style={{
                      flex: 1,
                      padding: '8px 14px',
                      borderRadius: 8,
                      border: `2px solid ${fsDomain === 'lark' ? 'var(--accent)' : 'var(--border-primary)'}`,
                      background: fsDomain === 'lark' ? 'var(--accent-bg, rgba(99,102,241,0.08))' : 'var(--bg-surface-alt)',
                      color: fsDomain === 'lark' ? 'var(--accent)' : 'var(--text-secondary)',
                      cursor: (fsBotInfo || fsValidating) ? 'not-allowed' : 'pointer',
                      opacity: (fsBotInfo || fsValidating) ? 0.6 : 1,
                      fontWeight: fsDomain === 'lark' ? 600 : 400,
                      fontSize: '0.9rem',
                      textAlign: 'center',
                      transition: 'all 0.15s ease',
                    }}
                  >
                    Lark<br />
                    <span style={{ fontSize: '0.75rem', fontWeight: 400, opacity: 0.8 }}>International</span>
                  </button>
                </div>
              </div>

              {/* Setup guide + scopes/events in a row */}
              <div style={{ display: 'flex', gap: 12, marginBottom: 16, alignItems: 'flex-start' }}>
                {/* Left: How to setup info box */}
                <div style={{ ...infoBoxStyle, flex: 1, marginBottom: 0 }}>
                  <p style={{ marginBottom: 8, color: 'var(--text-primary)', fontWeight: 'bold' }}>
                    How to set up a {fsDomain === 'lark' ? 'Lark' : 'Feishu'} app:
                  </p>
                  <ol style={{ paddingLeft: 20, lineHeight: 1.8 }}>
                    <li>Visit the <strong style={{ color: 'var(--accent)' }}>{fsDomain === 'lark' ? 'Lark Developer Console' : 'Feishu Open Platform'}</strong></li>
                    <li>Create an enterprise app, fill in name and description</li>
                    <li>From <em>Credentials &amp; Basic Info</em>, copy your <strong>App ID</strong> and <strong>App Secret</strong></li>
                    <li>Under <em>Permission Management</em>, add the required scopes</li>
                    <li>Add event subscription: <code style={{ background: 'var(--info-code-bg)', padding: '2px 6px', borderRadius: 4 }}>im.message.receive_v1</code></li>
                    <li>Publish the app and wait for admin approval</li>
                  </ol>

                  {/* Quick navigation — show only the relevant console */}
                  <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
                    <a
                      href={fsDomain === 'lark' ? 'https://open.larksuite.com' : 'https://open.feishu.cn'}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn btn-secondary btn-sm"
                      style={{ textDecoration: 'none', fontSize: '0.8rem' }}
                    >
                      Open {fsDomain === 'lark' ? 'Lark' : 'Feishu'} Console &#8599;
                    </a>
                  </div>
                </div>

                {/* Right: Required Scopes + Event Subscription stacked */}
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 10 }}>
                  {/* Required Scopes (collapsible) */}
                  <div style={{
                    background: 'var(--bg-surface-alt)',
                    border: '1px solid var(--border-primary)',
                    borderRadius: 6,
                    padding: '10px 14px',
                    fontSize: '0.83rem',
                  }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <button
                        type="button"
                        onClick={() => setFsScopesExpanded(!fsScopesExpanded)}
                        style={{
                          background: 'none',
                          border: 'none',
                          padding: 0,
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          gap: 6,
                          fontWeight: 600,
                          color: 'var(--text-primary)',
                          fontSize: '0.83rem',
                        }}
                      >
                        <span style={{ display: 'inline-block', transition: 'transform 0.15s', transform: fsScopesExpanded ? 'rotate(90deg)' : 'rotate(0deg)', fontSize: '0.75rem' }}>&#9654;</span>
                        Required Bot Scopes
                        {!fsScopesExpanded && (
                          <span style={{ fontWeight: 400, color: 'var(--text-tertiary)', fontSize: '0.78rem', marginLeft: 4 }}>
                            6 scopes
                          </span>
                        )}
                      </button>
                      <button
                        className="btn btn-secondary btn-sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          const scopesJson = JSON.stringify({
                            scopes: {
                              tenant: [
                                'contact:user.base:readonly',
                                'im:message',
                                'im:message.p2p_msg:readonly',
                                'im:message.group_at_msg:readonly',
                                'im:message:send_as_bot',
                                'im:resource',
                              ],
                            },
                          }, null, 2);
                          navigator.clipboard.writeText(scopesJson).then(() => {
                            setFsScopesCopied(true);
                            setTimeout(() => setFsScopesCopied(false), 2000);
                          }).catch(() => {});
                        }}
                        style={{ whiteSpace: 'nowrap', fontSize: '0.75rem' }}
                      >
                        {fsScopesCopied ? 'Copied!' : 'Copy JSON'}
                      </button>
                    </div>
                    {fsScopesExpanded && (
                      <>
                        <div style={{ color: 'var(--text-secondary)', fontSize: '0.8rem', marginBottom: 6, marginTop: 8 }}>
                          Copy this JSON and import it under <em>Permission Management</em> &rarr; <em>API Scopes</em>:
                        </div>
                        <pre style={{
                          background: 'var(--bg-primary)',
                          padding: '8px 10px',
                          borderRadius: 4,
                          fontSize: '0.78rem',
                          color: 'var(--text-primary)',
                          margin: 0,
                          lineHeight: 1.6,
                          overflowX: 'auto',
                        }}>{JSON.stringify({
                          scopes: {
                            tenant: [
                              'contact:user.base:readonly',
                              'im:message',
                              'im:message.p2p_msg:readonly',
                              'im:message.group_at_msg:readonly',
                              'im:message:send_as_bot',
                              'im:resource',
                            ],
                          },
                        }, null, 2)}</pre>
                      </>
                    )}
                  </div>

                  {/* Required Event Subscription (collapsible) */}
                  <div style={{
                    background: 'var(--bg-surface-alt)',
                    border: '1px solid var(--border-primary)',
                    borderRadius: 6,
                    padding: '10px 14px',
                    fontSize: '0.83rem',
                  }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <button
                        type="button"
                        onClick={() => setFsEventExpanded(!fsEventExpanded)}
                        style={{
                          background: 'none',
                          border: 'none',
                          padding: 0,
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          gap: 6,
                          fontWeight: 600,
                          color: 'var(--text-primary)',
                          fontSize: '0.83rem',
                        }}
                      >
                        <span style={{ display: 'inline-block', transition: 'transform 0.15s', transform: fsEventExpanded ? 'rotate(90deg)' : 'rotate(0deg)', fontSize: '0.75rem' }}>&#9654;</span>
                        Required Event Subscription
                        {!fsEventExpanded && (
                          <code style={{ fontWeight: 400, color: 'var(--text-tertiary)', fontSize: '0.75rem', marginLeft: 4 }}>
                            im.message.receive_v1
                          </code>
                        )}
                      </button>
                      <button
                        className="btn btn-secondary btn-sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          navigator.clipboard.writeText('im.message.receive_v1').then(() => {
                            setFsEventCopied(true);
                            setTimeout(() => setFsEventCopied(false), 2000);
                          }).catch(() => {});
                        }}
                        style={{ whiteSpace: 'nowrap', fontSize: '0.75rem' }}
                      >
                        {fsEventCopied ? 'Copied!' : 'Copy Event'}
                      </button>
                    </div>
                    {fsEventExpanded && (
                      <>
                        <div style={{ color: 'var(--text-secondary)', fontSize: '0.8rem', marginBottom: 6, marginTop: 8 }}>
                          Add this under <em>Event Subscriptions</em>:
                        </div>
                        <code style={{
                          display: 'block',
                          background: 'var(--bg-primary)',
                          padding: '6px 10px',
                          borderRadius: 4,
                          fontSize: '0.82rem',
                          color: 'var(--text-primary)',
                        }}>im.message.receive_v1</code>
                      </>
                    )}
                  </div>
                </div>
              </div>

              {/* App ID */}
              <div className="input-group">
                <label className="input-label">App ID</label>
                <input
                  className="input"
                  type="text"
                  placeholder="cli_xxxxxxxxxx"
                  value={fsAppId}
                  onChange={(e) => setFsAppId(e.target.value)}
                />
              </div>

              {/* App Secret */}
              <div className="input-group">
                <label className="input-label">App Secret</label>
                <input
                  className="input"
                  type="password"
                  placeholder="Enter your App Secret"
                  value={fsAppSecret}
                  onChange={(e) => setFsAppSecret(e.target.value)}
                />
              </div>

              {/* Connection Mode — currently only WebSocket is supported */}
              <div className="input-group">
                <label className="input-label">Connection Mode</label>
                <div style={{ fontSize: '0.85rem', color: 'var(--text-primary)', padding: '6px 0' }}>
                  WebSocket <span style={{ fontSize: '0.75rem', color: 'var(--badge-success-text)', fontWeight: 500 }}>(Long Connection)</span>
                </div>
                <div style={{ marginTop: 4, fontSize: '0.8rem', color: 'var(--text-tertiary)' }}>
                  No public URL or SSL certificate needed. Works behind NATs and firewalls.
                </div>
              </div>

              {/* Plugin Version */}
              <div className="input-group">
                <label className="input-label">Feishu Plugin Version</label>
                <div style={{ display: 'flex', alignItems: 'center', gap: 0 }}>
                  <span style={{
                    padding: '7px 10px',
                    background: 'var(--bg-surface-alt)',
                    border: '1px solid var(--border-primary)',
                    borderRight: 'none',
                    borderRadius: '6px 0 0 6px',
                    fontSize: '0.85rem',
                    color: 'var(--text-tertiary)',
                    whiteSpace: 'nowrap',
                    userSelect: 'none',
                  }}>@openclaw/feishu@</span>
                  <input
                    className="input"
                    type="text"
                    placeholder="auto (match gateway version)"
                    value={fsPluginVersion}
                    onChange={(e) => setFsPluginVersion(e.target.value)}
                    style={{ borderRadius: '0 6px 6px 0', flex: 1 }}
                  />
                </div>
                <div style={{ marginTop: 4, fontSize: '0.78rem', color: 'var(--text-tertiary)' }}>
                  Leave empty to auto-detect the version matching your OpenClaw gateway. Override only if you need a specific version.
                </div>
              </div>

              {fsError && <div className="error-container" style={{ marginBottom: 16 }}>{fsError}</div>}

              {fsBotInfo && (
                <div style={successBoxStyle}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                    <StatusDot ok />
                    <strong style={{ color: 'var(--success-box-text)' }}>Credentials Validated Successfully</strong>
                  </div>
                  <div style={{ fontSize: '0.85rem', color: 'var(--success-box-detail)' }}>
                    {fsBotInfo.app_name && <div>App Name: {fsBotInfo.app_name}</div>}
                    {fsBotInfo.open_id && <div>Open ID: {fsBotInfo.open_id}</div>}
                    <div>Platform: {fsDomain === 'lark' ? 'Lark (International)' : 'Feishu (China)'}</div>
                    <div>Mode: {fsConnectionMode === 'webhook' ? 'Webhook Callback' : 'WebSocket'}</div>
                  </div>
                </div>
              )}

              <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
                {fsReconfiguring && (
                  <button className="btn btn-secondary btn-sm" onClick={() => { setFsReconfiguring(false); setFsError(null); setFsBotInfo(null); setFsAppId(''); setFsAppSecret(''); setFsPluginVersion(''); setFsEncryptKey(''); setFsVerificationToken(''); }}>
                    Cancel
                  </button>
                )}
                {!fsBotInfo ? (
                  <button
                    className="btn btn-primary btn-sm"
                    onClick={handleFsValidate}
                    disabled={!fsAppId.trim() || !fsAppSecret.trim() || fsValidating}
                  >
                    {fsValidating ? <><span className="spinner" style={{ width: 13, height: 13, borderWidth: 2 }} /> Validating...</> : 'Validate'}
                  </button>
                ) : (
                  <button
                    className="btn btn-primary btn-sm"
                    onClick={handleFsSave}
                    disabled={fsSaving}
                  >
                    {fsSaving ? <><span className="spinner" style={{ width: 13, height: 13, borderWidth: 2 }} /> Saving...</> : 'Save'}
                  </button>
                )}
              </div>
            </>
          )}
        </>
      )}

      {/* ==================== Navigation ==================== */}
      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, marginTop: 24, paddingTop: 16, borderTop: '1px solid var(--border-primary)' }}>
        <button className="btn btn-secondary" onClick={() => navigate('/setup/credentials')}>
          Back
        </button>
        <div style={{ display: 'flex', gap: 8 }}>
          <button
            className="btn btn-secondary"
            onClick={() => {
              markCompleted('channels', { skipped: true });
              navigate('/setup/config');
            }}
          >
            Skip
          </button>
          <button className="btn btn-primary" onClick={handleContinue}>
            Continue
          </button>
        </div>
      </div>
    </div>
  );
}

import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useWizard } from '../../context/WizardContext';
import { authFetch } from '../../hooks/useAuth';

const PROVIDER_PRESETS = {
  openai: {
    label: 'OpenAI',
    baseUrl: 'https://api.openai.com/v1',
    apiFormat: 'openai-completions',

    description: 'OpenAI API (GPT models)',
  },
  anthropic: {
    label: 'Anthropic',
    baseUrl: 'https://api.anthropic.com',
    apiFormat: 'anthropic-messages',

    description: 'Anthropic Messages API (Claude models)',
  },
  google: {
    label: 'Google',
    baseUrl: 'https://generativelanguage.googleapis.com/v1beta',
    apiFormat: 'google-generative-ai',

    description: 'Google Generative AI API (Gemini models)',
  },
  openrouter: {
    label: 'OpenRouter',
    baseUrl: 'https://openrouter.ai/api/v1',
    apiFormat: 'openai-completions',

    description: 'OpenRouter unified API (OpenAI-compatible)',
  },
  custom: {
    label: 'Custom (OpenAI-compatible)',
    baseUrl: '',
    apiFormat: 'openai-completions',

    description: 'Any OpenAI-compatible endpoint',
  },
};

const API_FORMAT_OPTIONS = [
  { value: 'openai-completions', label: 'OpenAI Completions' },
  { value: 'anthropic-messages', label: 'Anthropic Messages' },
  { value: 'google-generative-ai', label: 'Google Generative AI' },
];

const DISABLED_PROVIDERS = new Set([]);
const DISABLED_DETECTED = new Set([]);

// Map model name prefixes to provider names for allowedModels compatibility check.
// allowedModels entries may lack a provider prefix (e.g. "glm-5" instead of "zai/glm-5").
function inferProviderFromModelName(modelName) {
  const name = modelName.includes('/') ? modelName.split('/')[0] : null;
  if (name) return name;
  if (/^glm/i.test(modelName)) return 'zai';
  if (/^claude/i.test(modelName)) return 'anthropic';
  if (/^(gpt|o[0-9]|dall-e|whisper)/i.test(modelName)) return 'openai';
  if (/^gemini/i.test(modelName)) return 'google';
  return null;
}

// Build a set of provider names that are compatible with the allowedModels list
function getAllowedProviders(allowedModels) {
  if (!allowedModels || allowedModels.length === 0) return null; // null = no restriction
  const providers = new Set();
  for (const m of allowedModels) {
    const p = inferProviderFromModelName(m);
    if (p) providers.add(p);
  }
  return providers;
}

// Check if a specific model string matches any entry in allowedModels,
// handling both prefixed ("anthropic/claude-opus-4-6") and bare ("claude-opus-4-6") formats.
function modelMatchesAllowed(model, allowedModels) {
  if (!model || !allowedModels) return false;
  const modelBase = model.includes('/') ? model.split('/').slice(1).join('/') : model;
  for (const allowed of allowedModels) {
    if (model === allowed) return true;
    const allowedBase = allowed.includes('/') ? allowed.split('/').slice(1).join('/') : allowed;
    if (modelBase === allowedBase) return true;
  }
  return false;
}

// Check if a detected credential is compatible with the allowedModels restriction.
// A credential is allowed if its provider name matches OR any of its actual models match.
function isCredentialAllowed(credential, allowedModels, allowedProviders) {
  if (!allowedModels || allowedModels.length === 0) return true;
  // Provider-level match (works for standard providers like anthropic, openai, google)
  if (allowedProviders && allowedProviders.has(credential.provider)) return true;
  // Model-level match: check credential's actual models array (e.g. ZAI/router providers)
  if (credential.models && credential.models.length > 0) {
    for (const m of credential.models) {
      if (modelMatchesAllowed(m, allowedModels)) return true;
    }
  }
  // Model hint match (e.g. Claude settings with a single model hint)
  if (credential.modelHint && modelMatchesAllowed(credential.modelHint, allowedModels)) return true;
  return false;
}

const PRESET_KEYS = ['openai', 'anthropic', 'google', 'openrouter', 'custom'];

export default function Credentials() {
  const [providers, setProviders] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selected, setSelected] = useState(null);
  const [applying, setApplying] = useState(false);
  const [showManual, setShowManual] = useState(false);
  const [manualProvider, setManualProvider] = useState('');
  const [manualApiKey, setManualApiKey] = useState('');
  const [manualBaseUrl, setManualBaseUrl] = useState('');
  const [manualApiFormat, setManualApiFormat] = useState('openai-completions');
  const [configuredProviders, setConfiguredProviders] = useState({});
  const [defaultModel, setDefaultModel] = useState(null);
  const [allowedProviders, setAllowedProviders] = useState(null); // null = no restriction
  const [allowedModels, setAllowedModels] = useState(null); // raw allowedModels list from launcher
  const { markCompleted } = useWizard();
  const navigate = useNavigate();

  const isCustom = manualProvider === 'custom';
  const currentPreset = PROVIDER_PRESETS[manualProvider] || null;
  const isAnthropicPreset = manualProvider === 'anthropic';

  const providerDisplayName = (name) => name === 'anthropic' ? 'claude' : name;

  const handleProviderChange = (value) => {
    setManualProvider(value);
    if (value && value !== 'custom' && PROVIDER_PRESETS[value]) {
      const preset = PROVIDER_PRESETS[value];
      setManualBaseUrl(preset.baseUrl);
      setManualApiFormat(preset.apiFormat);
    } else if (value === 'custom') {
      setManualBaseUrl('');
      setManualApiFormat('openai-completions');
    } else {
      setManualBaseUrl('');
      setManualApiFormat('openai-completions');
    }
  };

  useEffect(() => {
    Promise.all([
      authFetch('/api/openclaw/credentials/detect').then((r) => r.json()),
      authFetch('/api/openclaw/config').then((r) => r.ok ? r.json() : null).catch(() => null),
    ])
      .then(([detectData, configData]) => {
        setProviders(detectData.detected || detectData.providers || []);
        if (configData?.models?.providers) {
          setConfiguredProviders(configData.models.providers);
        }
        if (configData?.agents?.defaults?.model?.primary) {
          setDefaultModel(configData.agents.defaults.model.primary);
        }
        // Compute which providers are allowed based on launcher allowedModels
        const launcherAllowed = configData?._launcher?.allowedModels || null;
        setAllowedModels(launcherAllowed);
        setAllowedProviders(getAllowedProviders(launcherAllowed));
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, []);

  const handleApply = async () => {
    if (!selected) return;
    setApplying(true);
    setError(null);
    try {
      const res = await authFetch('/api/openclaw/credentials/apply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ provider: selected }),
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.message || 'Failed to apply credentials');
      }
      const data = await res.json();
      markCompleted('credentials', data);
      navigate('/setup/channels');
    } catch (err) {
      setError(err.message);
    } finally {
      setApplying(false);
    }
  };

  const handleManualApply = async () => {
    if (!manualProvider || !manualApiKey) return;
    setApplying(true);
    setError(null);
    try {
      const providerName = isCustom ? 'custom' : manualProvider;

      const res = await authFetch('/api/openclaw/credentials/manual', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          provider: providerName,
          apiKey: manualApiKey,
          baseUrl: manualBaseUrl || undefined,
          apiFormat: manualApiFormat,
        }),
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.message || 'Failed to apply manual credentials');
      }
      const data = await res.json();
      markCompleted('credentials', data);
      navigate('/setup/channels');
    } catch (err) {
      setError(err.message);
    } finally {
      setApplying(false);
    }
  };

  const isEnvProvider = (p) => p.source && p.source.startsWith('env:');
  const isClaudeSettingsProvider = (p) => p.provider === 'anthropic';

  if (loading) {
    return (
      <div className="card">
        <div className="skeleton">
          <div className="skeleton-row" style={{ width: '40%' }} />
          <div className="skeleton-row" style={{ width: '100%' }} />
          <div className="skeleton-row-lg" style={{ width: '100%' }} />
          <div className="skeleton-row-lg" style={{ width: '100%' }} />
          <div className="skeleton-row-lg" style={{ width: '100%' }} />
        </div>
      </div>
    );
  }

  return (
    <div className="card">
      <h2 className="card-title">Credential Detection</h2>
      <p style={{ color: 'var(--text-tertiary)', marginBottom: 20, fontSize: '0.9rem' }}>
        Select a detected provider or provide your own API key.
      </p>

      {error && <div className="error-container" style={{ marginBottom: 16 }}>{error}</div>}

      {!showManual && (
        <>
          {providers && providers.length === 0 && (
            <div className="empty-state">
              <div className="empty-state-icon">{'()'}</div>
              <p>No credential providers detected.</p>
              <p style={{ fontSize: '0.85rem', marginTop: 8 }}>
                Use "Provide API Key" below to configure manually.
              </p>
            </div>
          )}

          {providers && providers.map((p) => {
            const isRestrictedByAllowed = allowedModels !== null && !isCredentialAllowed(p, allowedModels, allowedProviders);
            const isDisabled = DISABLED_DETECTED.has(p.provider) ||
              (p.provider === 'anthropic' && p.authMode === 'oauth') ||
              isRestrictedByAllowed;
            return (
            <div
              key={p.provider + (p.source || '')}
              className="credential-card"
              onClick={() => {
                if (isDisabled) return;
                setSelected(p.provider);
              }}
              style={{
                padding: 16,
                border: `1px solid ${selected === p.provider ? 'var(--accent)' : 'var(--border-secondary)'}`,
                borderRadius: 8,
                marginBottom: 8,
                cursor: isDisabled ? 'not-allowed' : 'pointer',
                background: selected === p.provider ? 'var(--accent-bg)' : 'transparent',
                opacity: isDisabled ? 0.5 : 1,
                transition: 'all 0.2s',
              }}
            >
              <div className="credential-card-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <strong style={{ color: 'var(--text-primary)' }}>{providerDisplayName(p.provider)}</strong>
                  {p.source && !isClaudeSettingsProvider(p) && (
                    <span style={{ color: 'var(--text-secondary)', fontSize: '0.8rem', marginLeft: 8 }}>
                      ({p.source})
                    </span>
                  )}
                </div>
                <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                  {isDisabled && p.authMode === 'oauth' && (
                    <span className="badge" style={{ fontSize: '0.7rem', background: 'rgba(230, 161, 23, 0.2)', color: 'var(--warning, #e6a117)' }}>OAuth Mode</span>
                  )}
                  {isDisabled && isRestrictedByAllowed && p.authMode !== 'oauth' && (
                    <span className="badge" style={{ fontSize: '0.7rem', background: 'var(--border-secondary)', color: 'var(--text-secondary)' }}>Restricted</span>
                  )}
                  {isDisabled && !isRestrictedByAllowed && p.authMode !== 'oauth' && (
                    <span className="badge" style={{ fontSize: '0.7rem', background: 'var(--border-secondary)', color: 'var(--text-secondary)' }}>Not Available</span>
                  )}
                  {!isDisabled && configuredProviders[p.provider] && (
                    <span className="badge badge-success" style={{ fontSize: '0.7rem' }}>Configured</span>
                  )}
                  {!isDisabled && (
                    <span className={`badge ${(p.found || p.available) ? 'badge-success' : 'badge-warning'}`}>
                      <span className={`status-dot ${(p.found || p.available) ? 'online' : 'offline'}`} />
                      {(p.found || p.available) ? 'Found' : 'Not Found'}
                    </span>
                  )}
                </div>
              </div>
              {(() => {
                const rowStyle = { display: 'flex', gap: 6, marginTop: 3 };
                const labelStyle = { color: 'var(--text-tertiary)', fontSize: '0.75rem', minWidth: 56 };
                const valueStyle = { fontSize: '0.75rem', color: 'var(--text-secondary)' };

                if (isDisabled) {
                  if (isRestrictedByAllowed && p.authMode !== 'oauth') {
                    return (
                      <div style={{ color: 'var(--text-tertiary)', fontSize: '0.8rem', marginTop: 6 }}>
                        This provider is not included in the allowed models for this instance.
                      </div>
                    );
                  }
                  if (p.provider === 'anthropic' && p.authMode === 'oauth') {
                    return (
                      <div style={{ color: 'var(--warning, #e6a117)', fontSize: '0.8rem', marginTop: 6, lineHeight: 1.5 }}>
                        Your Claude CLI is authenticated via OAuth (<code style={{ fontSize: '0.75rem' }}>claude login</code>),
                        which cannot be used as a gateway API key.
                        Generate a headless API key from your Claude subscription
                        at{' '}<a href="https://console.anthropic.com" target="_blank" rel="noopener noreferrer"
                          style={{ color: 'var(--accent)' }}>console.anthropic.com</a>{' '}
                        and use "Provide API Key" below instead.
                      </div>
                    );
                  }
                  return (
                    <div style={{ color: 'var(--text-tertiary)', fontSize: '0.8rem', marginTop: 6 }}>
                      Support for this provider is not yet available.
                      {(p.baseUrl || p.modelHint) && (
                        <div style={{ marginTop: 6 }}>
                          {(p.maskedKey || p.hasApiKey) && <div style={rowStyle}><span style={labelStyle}>Key</span><code style={valueStyle}>{p.maskedKey || 'configured'}</code></div>}
                          {p.baseUrl && <div style={rowStyle}><span style={labelStyle}>Endpoint</span><code style={valueStyle}>{p.baseUrl}</code></div>}
                          {p.modelHint && <div style={rowStyle}><span style={labelStyle}>Model</span><code style={valueStyle}>{p.modelHint}</code></div>}
                        </div>
                      )}
                    </div>
                  );
                }

                // Determine source label and model info
                let sourceText;
                let modelDisplay = null;
                if (isEnvProvider(p)) {
                  sourceText = 'Environment variable';
                } else if (isClaudeSettingsProvider(p)) {
                  sourceText = 'Claude Code settings';
                  if (p.modelHint) modelDisplay = p.modelHint;
                } else {
                  sourceText = 'Claude Code Router';
                  if (p.models && p.models.length > 0) {
                    const enabledModel = defaultModel && p.models.includes(defaultModel) ? defaultModel : null;
                    if (enabledModel) {
                      const others = p.models.length - 1;
                      modelDisplay = others > 0 ? `${enabledModel} (+${others} more)` : enabledModel;
                    } else {
                      modelDisplay = p.models.join(', ');
                    }
                  }
                }

                return (
                  <div style={{ color: 'var(--text-secondary)', fontSize: '0.8rem', marginTop: 6 }}>
                    <div style={rowStyle}><span style={labelStyle}>Source</span><span style={valueStyle}>{sourceText}</span></div>
                    {(p.maskedKey || p.hasApiKey) && <div style={rowStyle}><span style={labelStyle}>Key</span><code style={valueStyle}>{p.maskedKey || 'configured'}</code></div>}
                    {p.baseUrl && <div style={rowStyle}><span style={labelStyle}>Endpoint</span><code style={valueStyle}>{p.baseUrl}</code></div>}
                    {modelDisplay && <div style={rowStyle}><span style={labelStyle}>Model</span><code style={valueStyle}>{modelDisplay}</code></div>}
                  </div>
                );
              })()}
            </div>
            );
          })}

          {/* Model selection moved to Config step (step 3) */}

          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, marginTop: 20 }}>
            <button
              className="btn btn-secondary"
              onClick={() => setShowManual(true)}
            >
              Provide API Key
            </button>
            <div style={{ display: 'flex', gap: 8 }}>
              <button
                className="btn btn-secondary"
                onClick={() => {
                  markCompleted('credentials', { skipped: true });
                  navigate('/setup/channels');
                }}
              >
                Skip
              </button>
              <button
                className="btn btn-primary"
                onClick={handleApply}
                disabled={!selected || applying}
              >
                {applying ? <><span className="spinner" /> Applying...</> : 'Apply & Continue'}
              </button>
            </div>
          </div>
        </>
      )}

      {showManual && (
        <>
          <div style={{
            padding: 16,
            border: '1px solid var(--border-secondary)',
            borderRadius: 8,
            marginBottom: 16,
          }}>
            <h3 style={{ color: 'var(--text-primary)', fontSize: '1rem', marginBottom: 12 }}>Manual API Key Configuration</h3>
            <p style={{ color: 'var(--text-secondary)', fontSize: '0.8rem', marginBottom: 16 }}>
              Select a provider preset or choose "Custom" for any OpenAI-compatible endpoint.
            </p>

            <div className="input-group">
              <label className="input-label">Provider</label>
              <select
                className="input"
                value={manualProvider}
                onChange={(e) => handleProviderChange(e.target.value)}
                style={{ cursor: 'pointer' }}
              >
                <option value="">Select a provider...</option>
                {PRESET_KEYS.map((key) => {
                  const isProviderDisabled = DISABLED_PROVIDERS.has(key) ||
                    (allowedProviders !== null && key !== 'custom' && !allowedProviders.has(key));
                  return (
                    <option key={key} value={key} disabled={isProviderDisabled}>
                      {PROVIDER_PRESETS[key].label}{DISABLED_PROVIDERS.has(key) ? ' (Coming Soon)' : ''}{isProviderDisabled && !DISABLED_PROVIDERS.has(key) ? ' (Restricted)' : ''}
                    </option>
                  );
                })}
              </select>
              {currentPreset && (
                <span style={{ color: 'var(--text-secondary)', fontSize: '0.75rem', marginTop: 4, display: 'block' }}>
                  {currentPreset.description}
                  {!isCustom && ` — Base URL: ${currentPreset.baseUrl}, Format: ${currentPreset.apiFormat}`}
                </span>
              )}
            </div>

            {isAnthropicPreset && (
              <div style={{
                padding: 10,
                background: 'var(--accent-bg)',
                borderRadius: 6,
                marginBottom: 12,
                fontSize: '0.8rem',
                color: 'var(--text-tertiary)',
                lineHeight: 1.5,
              }}>
                Use an API key from console.anthropic.com. Avoid using Claude CLI OAuth tokens
                directly — OpenClaw syncs those automatically at runtime.
              </div>
            )}

            <div className="input-group">
              <label className="input-label">API Key</label>
              <input
                className="input"
                type="password"
                value={manualApiKey}
                onChange={(e) => setManualApiKey(e.target.value)}
                placeholder="sk-..."
              />
            </div>

            <div className="input-group">
              <label className="input-label">Base URL{!isCustom ? ' (auto-filled, editable)' : ''}</label>
              <input
                className="input"
                type="text"
                value={manualBaseUrl}
                onChange={(e) => setManualBaseUrl(e.target.value)}
                placeholder={isCustom ? 'https://api.example.com/v1' : (currentPreset ? currentPreset.baseUrl : 'https://api.example.com/v1')}
              />
              <span style={{ color: 'var(--text-secondary)', fontSize: '0.75rem' }}>
                Endpoint base URL. Do not include /messages - it will be appended automatically.
              </span>
            </div>

            {isCustom && (
              <div className="input-group">
                <label className="input-label">API Format</label>
                <select
                  className="input"
                  value={manualApiFormat}
                  onChange={(e) => setManualApiFormat(e.target.value)}
                  style={{ cursor: 'pointer' }}
                >
                  {API_FORMAT_OPTIONS.map((opt) => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                  ))}
                </select>
                <span style={{ color: 'var(--text-secondary)', fontSize: '0.75rem' }}>
                  Select the API format your endpoint uses.
                </span>
              </div>
            )}

            {/* Model selection moved to Config step (step 3) */}
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8 }}>
            <button
              className="btn btn-secondary"
              onClick={() => {
                setShowManual(false);
                setManualProvider('');
                setManualApiKey('');
                setManualBaseUrl('');
                setManualApiFormat('openai-completions');
              }}
            >
              Back to Detected
            </button>
            <button
              className="btn btn-primary"
              onClick={handleManualApply}
              disabled={!manualProvider || !manualApiKey || applying}
            >
              {applying ? <><span className="spinner" /> Applying...</> : 'Apply API Key & Continue'}
            </button>
          </div>
        </>
      )}
    </div>
  );
}

import React, { useState, useEffect, useCallback, useRef } from 'react';
import Markdown from 'react-markdown';
import { authFetch, clearToken, isTemporarySession } from '../../hooks/useAuth';

// Lightweight JSON syntax highlighter (returns HTML string)
function highlightJson(str) {
  return str.replace(
    /("(?:[^"\\]|\\.)*")\s*(:)|("(?:[^"\\]|\\.)*")|(true|false|null)|(-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)/g,
    (match, key, colon, strVal, keyword, num) => {
      if (key && colon) return `<span style="color:var(--accent)">${key}</span>${colon}`;
      if (strVal) return `<span style="color:var(--badge-success-text)">${strVal}</span>`;
      if (keyword) return `<span style="color:var(--badge-warning-text)">${keyword}</span>`;
      if (num) return `<span style="color:var(--badge-info-text)">${num}</span>`;
      return match;
    }
  );
}

const STATUS_LABELS = {
  AVAILABLE: 'Available',
  PROVISIONING: 'Provisioning',
  ACTIVE: 'Active',
  SUSPENDED: 'Suspended',
  TERMINATED: 'Terminated',
};

const STATUS_COLORS = {
  AVAILABLE: 'var(--badge-info-text, #60a5fa)',
  PROVISIONING: 'var(--badge-warning-text, #fbbf24)',
  ACTIVE: 'var(--badge-success-text, #4ade80)',
  SUSPENDED: 'var(--badge-error-text, #f87171)',
  TERMINATED: 'var(--text-muted, #6b7280)',
};

const RISK_STYLES = {
  low: {
    borderColor: 'var(--badge-info-text, #60a5fa)',
    background: 'rgba(96, 165, 250, 0.08)',
    color: 'var(--badge-info-text, #60a5fa)',
    label: 'Low Risk',
  },
  medium: {
    borderColor: 'var(--badge-warning-text, #fbbf24)',
    background: 'rgba(251, 191, 36, 0.08)',
    color: 'var(--badge-warning-text, #fbbf24)',
    label: 'Medium Risk',
  },
  high: {
    borderColor: 'var(--badge-error-text, #f87171)',
    background: 'rgba(248, 113, 113, 0.08)',
    color: 'var(--badge-error-text, #f87171)',
    label: 'High Risk',
  },
};

const RISK_MESSAGES = {
  low: 'Some adoption requests have failed. This may resolve automatically.',
  medium: 'Multiple adoption requests are failing. Check your adoption URL and InstClaw connectivity.',
  high: 'Adoption requests are repeatedly failing. Review the failure log below or reset adoption.',
};

function timeAgo(timestamp) {
  const seconds = Math.floor((Date.now() - new Date(timestamp).getTime()) / 1000);
  if (seconds < 60) return 'just now';
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

export default function ManagedPool() {
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [error, setError] = useState(null);
  const [copied, setCopied] = useState(null);
  const [enableData, setEnableData] = useState(null);
  const [failureLogOpen, setFailureLogOpen] = useState(false);
  const [backupProgress, setBackupProgress] = useState(null);
  const [dangerZoneOpen, setDangerZoneOpen] = useState(false);
  const [accessLink, setAccessLink] = useState(null);
  const [llmsTxt, setLlmsTxt] = useState(null);
  const [llmsTxtOpen, setLlmsTxtOpen] = useState(false);
  const [apiCalls, setApiCalls] = useState(null);
  const [apiCallsListOpen, setApiCallsListOpen] = useState(false);
  const [apiCallsFilter, setApiCallsFilter] = useState('all');
  const [apiCallDetail, setApiCallDetail] = useState(null);
  const [detailCopied, setDetailCopied] = useState(null);
  const [detailHeadersOpen, setDetailHeadersOpen] = useState(false);
  const [confirmDialog, setConfirmDialog] = useState(null);
  const [envPreset, setEnvPreset] = useState(null);
  const [envPresetLoading, setEnvPresetLoading] = useState(false);
  const pollRef = useRef(null);
  const apiCallsPollRef = useRef(null);

  const fetchStatus = useCallback((isPolling) => {
    if (!isPolling) setLoading(true);
    authFetch('/api/openclaw/admin/status')
      .then(r => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json();
      })
      .then(data => {
        setStatus(data);
        setError(null);
      })
      .catch(err => { if (!isPolling) setError(err.message); })
      .finally(() => { if (!isPolling) setLoading(false); });
  }, []);

  useEffect(() => {
    fetchStatus(false);
  }, [fetchStatus]);

  // Auto-refresh polling: 15s when enabled && !isAdopted
  useEffect(() => {
    if (pollRef.current) {
      clearInterval(pollRef.current);
      pollRef.current = null;
    }

    if (status?.enabled && !status?.isAdopted) {
      pollRef.current = setInterval(() => {
        if (!document.hidden) fetchStatus(true);
      }, 15000);
    }

    return () => {
      if (pollRef.current) {
        clearInterval(pollRef.current);
        pollRef.current = null;
      }
    };
  }, [status?.enabled, status?.isAdopted, fetchStatus]);

  // Auto-fetch adoption URL when enabled but not yet consumed
  const fetchAdoptionUrl = useCallback(async () => {
    try {
      const res = await authFetch('/api/openclaw/admin/adoption-url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      if (!res.ok) {
        // Adoption state may have changed — refresh status so UI updates
        fetchStatus(true);
        return;
      }
      const data = await res.json();
      setEnableData(data);
    } catch {
      // Silently fail — adoption URL is not critical for page load
    }
  }, [fetchStatus]);

  useEffect(() => {
    if (status?.enabled && !status?.isAdopted && status?.hasAdoptionToken && !enableData) {
      fetchAdoptionUrl();
    }
  }, [status?.enabled, status?.isAdopted, status?.hasAdoptionToken, enableData, fetchAdoptionUrl]);

  // Fetch llms.txt content (always — not gated behind managed pool)
  useEffect(() => {
    if (!llmsTxt) {
      fetch('/control/v1/llms.txt')
        .then(r => r.ok ? r.text() : null)
        .then(text => { if (text) setLlmsTxt(text); })
        .catch(() => {});
    }
  }, [llmsTxt]);

  // Fetch API call history when section is open
  const fetchApiCalls = useCallback(() => {
    authFetch('/api/openclaw/api-calls')
      .then(r => r.ok ? r.json() : null)
      .then(data => { if (data) setApiCalls(data); })
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (apiCallsPollRef.current) {
      clearInterval(apiCallsPollRef.current);
      apiCallsPollRef.current = null;
    }
    if (!status?.enabled) return;
    fetchApiCalls();
    apiCallsPollRef.current = setInterval(() => {
      if (!document.hidden) fetchApiCalls();
    }, 15000);
    return () => {
      if (apiCallsPollRef.current) {
        clearInterval(apiCallsPollRef.current);
        apiCallsPollRef.current = null;
      }
    };
  }, [status?.enabled, fetchApiCalls]);

  const handleClearApiCalls = async () => {
    try {
      await authFetch('/api/openclaw/api-calls', { method: 'DELETE' });
      setApiCalls({ history: [], count: 0 });
      setApiCallDetail(null);
    } catch {}
  };

  // Fetch environment preset settings
  useEffect(() => {
    authFetch('/api/openclaw/admin/environment')
      .then(r => r.ok ? r.json() : null)
      .then(data => { if (data) setEnvPreset(data); })
      .catch(() => {});
  }, []);

  const handleToggleStopDaemon = async () => {
    if (!envPreset) return;
    setEnvPresetLoading(true);
    try {
      const newVal = !envPreset.stopAniCodeDaemon;
      const res = await authFetch('/api/openclaw/admin/environment', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ stopAniCodeDaemon: newVal }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setEnvPreset(prev => ({ ...prev, ...data }));
    } catch (err) {
      setError(err.message);
    } finally {
      setEnvPresetLoading(false);
    }
  };

  const copyDetail = (text, label) => {
    navigator.clipboard.writeText(text).then(() => {
      setDetailCopied(label);
      setTimeout(() => setDetailCopied(null), 2000);
    });
  };

  // Build bar chart buckets (30 x 1-min buckets over last 30 minutes)
  const buildChartBuckets = useCallback(() => {
    if (!apiCalls?.history?.length) return [];
    const now = Date.now();
    const BUCKET_COUNT = 30;
    const BUCKET_MS = 60 * 1000;
    const buckets = Array.from({ length: BUCKET_COUNT }, (_, i) => ({
      start: now - (BUCKET_COUNT - i) * BUCKET_MS,
      end: now - (BUCKET_COUNT - i - 1) * BUCKET_MS,
      ok: 0,
      fail: 0,
    }));
    for (const call of apiCalls.history) {
      const idx = Math.min(BUCKET_COUNT - 1, Math.floor((call.timestamp - (now - BUCKET_COUNT * BUCKET_MS)) / BUCKET_MS));
      if (idx >= 0 && idx < BUCKET_COUNT) {
        if (call.statusCode < 400) buckets[idx].ok++;
        else buckets[idx].fail++;
      }
    }
    return buckets;
  }, [apiCalls]);

  // Abbreviate control API paths: /control/v1/instances/xxxx/foo → …/foo
  const abbreviatePath = (path) => {
    const match = path.match(/^\/control\/v1\/instances\/[^/]+(\/.*)/);
    if (match) return '…' + match[1];
    return path;
  };

  const getFilteredCalls = useCallback(() => {
    if (!apiCalls?.history) return [];
    if (apiCallsFilter === 'success') return apiCalls.history.filter(c => c.statusCode < 400);
    if (apiCallsFilter === 'failed') return apiCalls.history.filter(c => c.statusCode >= 400);
    return apiCalls.history;
  }, [apiCalls, apiCallsFilter]);

  const handleEnable = async () => {
    setActionLoading(true);
    setError(null);
    try {
      const res = await authFetch('/api/openclaw/admin/enable', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setEnableData(data);
      fetchStatus(false);
    } catch (err) {
      setError(err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleDisable = async () => {
    if (!confirm('Are you sure you want to revoke managed pool adoption? This will clear all control keys and reject future Control API requests.')) return;
    setActionLoading(true);
    setError(null);
    try {
      const res = await authFetch('/api/openclaw/admin/disable', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setEnableData(null);
      fetchStatus(false);
    } catch (err) {
      setError(err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleClearFailures = async () => {
    setActionLoading(true);
    try {
      const res = await authFetch('/api/openclaw/admin/clear-failures', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setFailureLogOpen(false);
      fetchStatus(false);
    } catch (err) {
      setError(err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleResetLauncherToken = () => {
    setConfirmDialog({
      title: 'Reset Launcher Token',
      body: 'This will reset your launcher login password, invalidate all sessions, and redirect you to the login page. Continue?',
      confirmLabel: 'Reset Token',
      onConfirm: async () => {
        setConfirmDialog(null);
        setActionLoading(true);
        try {
          const res = await authFetch('/api/openclaw/auth/reset-launcher-token', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({}),
          });
          if (!res.ok) throw new Error(`HTTP ${res.status}`);
          clearToken();
          window.location.href = '/login';
        } catch (err) {
          setError(err.message);
          setActionLoading(false);
        }
      },
    });
  };

  const handleGenerateLink = async () => {
    setActionLoading(true);
    setError(null);
    try {
      const res = await authFetch('/api/openclaw/auth/generate-link', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setAccessLink(data.link);
    } catch (err) {
      setError(err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const copyToClipboard = (text, label) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(label);
      setTimeout(() => setCopied(null), 2000);
    });
  };

  const buildAdoptionUrl = () => {
    if (!enableData) return null;
    const host = window.location.host;
    return `instclaw-adopt://${host}/control/v1?token=${enableData.adoptionToken}&key=${enableData.controlKey}`;
  };

  const handleDownloadBackup = async () => {
    setActionLoading(true);
    setError(null);
    setBackupProgress(0);

    try {
      const token = localStorage.getItem('launcher_token');
      if (!token) {
        throw new Error('Not authenticated');
      }

      // Request backup as JSON with base64 data
      const res = await fetch('/api/openclaw/admin/backup', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (!res.ok) {
        let errorMsg = `HTTP ${res.status}`;
        try {
          const err = await res.json();
          errorMsg = err.message || errorMsg;
        } catch {}
        throw new Error(errorMsg);
      }

      // Parse JSON response
      const response = await res.json();

      if (!response.success || !response.data) {
        throw new Error(response.error || 'Invalid backup response');
      }

      setBackupProgress(50);

      // Decode base64 to binary
      const binaryString = atob(response.data);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      setBackupProgress(75);

      // Verify gzip magic number
      if (bytes[0] !== 0x1f || bytes[1] !== 0x8b) {
        throw new Error('Invalid backup data: not a valid gzip file');
      }

      // Create blob and download
      const blob = new Blob([bytes], { type: response.mimeType || 'application/gzip' });
      const blobUrl = URL.createObjectURL(blob);

      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = response.filename || 'openclaw-backup.tar.gz';
      a.style.display = 'none';
      document.body.appendChild(a);

      // Trigger download
      a.click();

      setBackupProgress(100);

      // Clean up
      setTimeout(() => {
        document.body.removeChild(a);
        URL.revokeObjectURL(blobUrl);
        setBackupProgress(null);
      }, 100);

    } catch (err) {
      setError(err.message);
      setBackupProgress(null);
    } finally {
      setActionLoading(false);
    }
  };

  const handleResetMarketplaceCatalogs = () => {
    setConfirmDialog({
      title: 'Reset Marketplace Catalogs',
      body: 'This will remove all external catalog items that are not currently installed. Installed items and built-in items will be preserved. Continue?',
      confirmLabel: 'Reset Catalogs',
      onConfirm: async () => {
        setConfirmDialog(null);
        setActionLoading(true);
        setError(null);
        try {
          const res = await authFetch('/api/openclaw/marketplace/reset-catalog', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({}),
          });
          if (!res.ok) throw new Error(`HTTP ${res.status}`);
          const data = await res.json();
          setError(null);
          setConfirmDialog({
            title: 'Catalogs Reset',
            body: data.message || 'Marketplace catalogs have been reset.',
            confirmLabel: 'OK',
            onConfirm: () => setConfirmDialog(null),
          });
        } catch (err) {
          setError(err.message);
        } finally {
          setActionLoading(false);
        }
      },
    });
  };

  const handleDeleteMemory = () => {
    setConfirmDialog({
      title: 'Delete All Data',
      body: 'WARNING: This will permanently delete the entire ~/.openclaw data folder, including all configuration, credentials, workspace files, and conversation history. This action cannot be undone.',
      confirmLabel: 'Delete All',
      onConfirm: () => {
        setConfirmDialog({
          title: 'Are you absolutely sure?',
          body: 'All OpenClaw data will be permanently destroyed. This cannot be reversed.',
          confirmLabel: 'Yes, Delete Everything',
          onConfirm: async () => {
            setConfirmDialog(null);
            setActionLoading(true);
            setError(null);
            try {
              const res = await authFetch('/api/openclaw/admin/delete-data', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({}),
              });
              if (!res.ok) throw new Error(`HTTP ${res.status}`);
              clearToken();
              window.location.href = '/login';
            } catch (err) {
              setError(err.message);
              setActionLoading(false);
            }
          },
        });
      },
    });
  };

  const isEnabled = status?.enabled;
  const adoptionUrl = buildAdoptionUrl();
  const riskLevel = status?.riskLevel;
  const hasFailures = status?.failedAttempts > 0;
  const riskStyle = riskLevel && RISK_STYLES[riskLevel];
  const isTemp = isTemporarySession();

  return (
    <div className="step-container">
      {isTemp && (
        <div className="card" style={{
          padding: '10px 16px', marginBottom: 16,
          borderLeft: '3px solid var(--badge-warning-text, #fbbf24)',
          background: 'rgba(251, 191, 36, 0.06)',
          display: 'flex', alignItems: 'center', gap: 8,
          fontSize: '0.8rem',
        }}>
          <span style={{ color: 'var(--badge-warning-text, #fbbf24)', fontWeight: 600 }}>Temporary session</span>
          <span style={{ color: 'var(--text-muted)' }}>— this access link expires in 1 hour. Some actions are restricted.</span>
        </div>
      )}

      {error && (
        <div className="card" style={{ padding: '12px 16px', marginBottom: 16, borderLeft: '3px solid var(--badge-error-text)' }}>
          <span style={{ color: 'var(--badge-error-text)' }}>{error}</span>
        </div>
      )}

      <div className="card" style={{ padding: 20, marginBottom: 16 }}>
        {loading ? (
          <div className="admin-skeleton">
            <div className="admin-skeleton-row" style={{ width: '40%' }} />
            <div className="admin-skeleton-row" style={{ width: '70%' }} />
            <div className="admin-skeleton-row" style={{ width: '55%' }} />
          </div>
        ) : (<>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: isEnabled ? 0 : 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <h3 style={{ margin: 0, fontSize: '1rem', fontWeight: 600 }}>Managed Pool</h3>
            {isEnabled && (
              <span style={{
                display: 'inline-flex', alignItems: 'center', gap: 5,
                fontSize: '0.75rem', fontWeight: 600,
                padding: '2px 8px', borderRadius: 10,
                background: status.gatewayHealth === 'unhealthy' || status.gatewayHealth === 'crash_loop'
                  ? 'rgba(248, 113, 113, 0.1)'
                  : status.isAdopted
                    ? (status.status ? `${STATUS_COLORS[status.status]}18` : 'rgba(74, 222, 128, 0.1)')
                    : 'rgba(251, 191, 36, 0.1)',
                color: status.gatewayHealth === 'unhealthy' || status.gatewayHealth === 'crash_loop'
                  ? 'var(--badge-error-text, #f87171)'
                  : status.isAdopted
                    ? (status.status ? STATUS_COLORS[status.status] : 'var(--badge-success-text, #4ade80)')
                    : 'var(--badge-warning-text, #fbbf24)',
              }}>
                <span style={{
                  width: 6, height: 6, borderRadius: '50%',
                  background: 'currentColor',
                }} />
                {status.gatewayHealth === 'crash_loop'
                  ? 'Crash Loop'
                  : status.gatewayHealth === 'unhealthy'
                    ? 'Unhealthy'
                    : status.isAdopted
                      ? (status.status ? STATUS_LABELS[status.status] : 'Adopted')
                      : 'Awaiting adoption'}
              </span>
            )}
          </div>
          {!isTemp && <div style={{ display: 'flex', gap: 8 }}>
            <button
              className={isEnabled ? 'btn btn-danger' : 'btn btn-primary'}
              onClick={isEnabled ? handleDisable : handleEnable}
              disabled={actionLoading}
              style={{ fontSize: '0.75rem', padding: '4px 12px', whiteSpace: 'nowrap' }}
            >
              {actionLoading ? 'Working...' : isEnabled ? 'Revoke' : 'Enable'}
            </button>
          </div>}
        </div>

        {!isEnabled && (
          <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', margin: 0, padding: '8px 12px', background: 'var(--bg-secondary, #1a1a2e)', borderRadius: 6 }}>
            Enable to generate a control key and adoption token. Paste the adoption URL into InstClaw to let it manage this instance's lifecycle, billing, and health.
          </p>
        )}

        {isEnabled && (
          <>
            {/* Instance details row */}
            <div style={{
              display: 'flex', gap: 20, flexWrap: 'wrap', alignItems: 'baseline',
              padding: '12px 0', marginTop: 12,
              borderTop: '1px solid var(--border-color, #2a2a3e)',
              fontSize: '0.8rem',
            }}>
              <div>
                <span style={{ color: 'var(--text-muted)' }}>ID </span>
                <code style={{ fontSize: '0.8rem' }}>{status.instanceId || '--'}</code>
              </div>
              {status.modelId && (
                <div>
                  <span style={{ color: 'var(--text-muted)' }}>Model </span>
                  <code style={{ fontSize: '0.8rem' }}>{status.modelId}</code>
                </div>
              )}
              {status.userId && (
                <div>
                  <span style={{ color: 'var(--text-muted)' }}>User </span>
                  <code style={{ fontSize: '0.8rem' }}>{status.userId}</code>
                </div>
              )}
              {status.adoptedAt && (
                <div>
                  <span style={{ color: 'var(--text-muted)' }}>Adopted </span>
                  <span>{timeAgo(status.adoptedAt)}</span>
                </div>
              )}
              {status.gatewayModel?.primary && (
                <div>
                  <span style={{ color: 'var(--text-muted)' }}>Gateway </span>
                  <code style={{ fontSize: '0.8rem' }}>{status.gatewayModel.primary}</code>
                  {status.gatewayModel.available.length > 1 && (
                    <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>
                      {' '}(+{status.gatewayModel.available.length - 1})
                    </span>
                  )}
                </div>
              )}
            </div>

            {/* Gateway health warning */}
            {status.gatewayIssue && (
              <div style={{
                borderTop: '1px solid var(--border-color, #2a2a3e)', marginTop: 4, paddingTop: 12,
              }}>
                <div style={{
                  padding: '8px 12px', borderRadius: 6,
                  background: 'rgba(248, 113, 113, 0.08)',
                  borderLeft: '3px solid var(--badge-error-text, #f87171)',
                  fontSize: '0.8rem',
                }}>
                  <span style={{ color: 'var(--badge-error-text, #f87171)', fontWeight: 600 }}>
                    {status.gatewayHealth === 'crash_loop' ? 'Gateway Crash Loop' : 'Gateway Unreachable'}
                  </span>
                  <p style={{ margin: '4px 0 0', color: 'var(--text-muted)', fontSize: '0.78rem' }}>
                    {status.gatewayIssue}
                  </p>
                </div>
              </div>
            )}

            {/* Adoption URL — reveal button or URL display */}
            {!status.isAdopted && status.hasAdoptionToken && (
              <div style={{ borderTop: '1px solid var(--border-color, #2a2a3e)', paddingTop: 12, marginTop: 4 }}>
                {!adoptionUrl ? (
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                      Adoption token ready — reveal URL to copy into InstClaw
                    </span>
                    <button
                      className="btn btn-primary"
                      onClick={fetchAdoptionUrl}
                      disabled={actionLoading}
                      style={{ fontSize: '0.75rem', padding: '4px 12px', whiteSpace: 'nowrap' }}
                    >
                      Show URL
                    </button>
                  </div>
                ) : (
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <code style={{
                        flex: 1, padding: '6px 10px', background: 'var(--bg-secondary)', borderRadius: 6,
                        fontSize: '0.75rem', wordBreak: 'break-all', fontFamily: 'monospace',
                      }}>
                        {adoptionUrl}
                      </code>
                      <button
                        className="btn btn-secondary"
                        onClick={() => copyToClipboard(adoptionUrl, 'url')}
                        style={{ fontSize: '0.75rem', padding: '4px 10px', whiteSpace: 'nowrap' }}
                      >
                        {copied === 'url' ? 'Copied!' : 'Copy'}
                      </button>
                    </div>
                    <p style={{ fontSize: '0.7rem', color: 'var(--text-muted)', margin: '6px 0 0' }}>
                      Single-use token. Paste into InstClaw dashboard to complete adoption.
                    </p>
                  </div>
                )}
              </div>
            )}


            {/* Risk Banner — inline when there are failures */}
            {hasFailures && riskStyle && (
              <div style={{
                borderTop: '1px solid var(--border-color, #2a2a3e)', marginTop: 4, paddingTop: 12,
              }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: '0.8rem' }}>
                    <span style={{
                      fontSize: '0.7rem', fontWeight: 700, textTransform: 'uppercase',
                      letterSpacing: '0.04em', color: riskStyle.color,
                      padding: '1px 6px', borderRadius: 4, background: riskStyle.background,
                    }}>
                      {riskStyle.label}
                    </span>
                    <span style={{ color: 'var(--text-muted)' }}>
                      {status.failedAttempts} failed{status.lastFailure && (
                        <> — {status.lastFailure.endpoint} {timeAgo(status.lastFailure.timestamp)}</>
                      )}
                    </span>
                  </div>
                  <div style={{ display: 'flex', gap: 6 }}>
                    {status.failureLog && status.failureLog.length > 0 && (
                      <button
                        onClick={() => setFailureLogOpen(!failureLogOpen)}
                        style={{
                          background: 'none', border: 'none', cursor: 'pointer', padding: 0,
                          color: riskStyle.color, fontSize: '0.75rem', textDecoration: 'underline',
                        }}
                      >
                        {failureLogOpen ? 'Hide' : 'Log'}
                      </button>
                    )}
                    <button
                      className="btn btn-secondary"
                      onClick={handleClearFailures}
                      disabled={actionLoading}
                      style={{ fontSize: '0.7rem', padding: '2px 8px' }}
                    >
                      Clear
                    </button>
                  </div>
                </div>
                {failureLogOpen && status.failureLog && (
                  <div style={{
                    marginTop: 8, maxHeight: 200, overflowY: 'auto', borderRadius: 6,
                    background: 'var(--bg-secondary, #1a1a2e)', padding: '6px 10px',
                  }}>
                    {[...status.failureLog].reverse().map((entry, i) => (
                      <div key={i} style={{
                        padding: '4px 0', fontSize: '0.75rem',
                        borderBottom: i < status.failureLog.length - 1 ? '1px solid var(--border-color, #2a2a3e)' : 'none',
                        display: 'flex', gap: 8, alignItems: 'baseline',
                      }}>
                        <span style={{ color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>{timeAgo(entry.timestamp)}</span>
                        <code style={{ color: riskStyle.color, fontSize: '0.7rem' }}>{entry.endpoint}</code>
                        <span style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>[{entry.errorCode}]</span>
                        <span style={{ flex: 1 }}>{entry.errorMessage}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </>
        )}
        </>)}

        {/* Control API Reference (llms.txt) — inside managed pool card, hidden for temp sessions */}
        {llmsTxt && !isTemp && (
          <div style={{ borderTop: '1px solid var(--border-color, #2a2a3e)', marginTop: 16, paddingTop: 14 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <h4 style={{ margin: 0, fontSize: '0.85rem', fontWeight: 600 }}>Control API Reference</h4>
                <p style={{ margin: '2px 0 0', fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                  LLM-consumable API reference — provide this URL to the caller
                </p>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button
                  className="btn btn-secondary"
                  onClick={() => copyToClipboard(`${window.location.origin}/control/v1/llms.txt`, 'llms-url')}
                  style={{ fontSize: '0.72rem', padding: '3px 8px', whiteSpace: 'nowrap' }}
                >
                  {copied === 'llms-url' ? 'Copied!' : 'Copy URL'}
                </button>
                <button
                  className="btn btn-secondary"
                  onClick={() => setLlmsTxtOpen(true)}
                  style={{ fontSize: '0.72rem', padding: '3px 8px', whiteSpace: 'nowrap' }}
                >
                  View
                </button>
              </div>
            </div>
            <div style={{ marginTop: 6 }}>
              <code style={{
                display: 'block', padding: '5px 10px', background: 'var(--bg-secondary)',
                borderRadius: 6, fontSize: '0.72rem', wordBreak: 'break-all', fontFamily: 'monospace',
              }}>
                {window.location.origin}/control/v1/llms.txt
              </code>
            </div>
          </div>
        )}
      </div>

      {/* Control API Reference Modal */}
      {llmsTxtOpen && llmsTxt && (
        <div className="dialog-overlay" onClick={() => setLlmsTxtOpen(false)}>
          <div className="dialog" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 960, width: '94vw' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <h3 className="dialog-title" style={{ marginBottom: 0 }}>Control API Reference</h3>
              <div style={{ display: 'flex', gap: 8 }}>
                <button
                  className="btn btn-secondary btn-sm"
                  onClick={() => copyToClipboard(llmsTxt, 'llms-content')}
                  style={{ padding: '2px 10px', fontSize: '0.8rem' }}
                >
                  {copied === 'llms-content' ? 'Copied!' : 'Copy'}
                </button>
                <button
                  className="btn btn-secondary btn-sm"
                  onClick={() => setLlmsTxtOpen(false)}
                  style={{ padding: '2px 10px', fontSize: '0.8rem' }}
                >
                  Close
                </button>
              </div>
            </div>
            <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', margin: '0 0 10px 0' }}>
              {window.location.origin}/control/v1/llms.txt
            </p>
            <div className="llms-viewer" style={{
              maxHeight: '65vh', overflowY: 'auto',
              background: 'var(--bg-surface-alt)',
              border: '1px solid var(--border-primary)',
              borderRadius: 4, padding: '12px 16px',
            }}>
              <Markdown components={{
                h1: ({ children }) => <h1 style={{ fontSize: '1.1rem', fontWeight: 700, margin: '0 0 8px', color: 'var(--text-primary)', borderBottom: '1px solid var(--border-primary)', paddingBottom: 6 }}>{children}</h1>,
                h2: ({ children }) => <h2 style={{ fontSize: '0.95rem', fontWeight: 700, margin: '16px 0 6px', color: 'var(--accent)' }}>{children}</h2>,
                h3: ({ children }) => <h3 style={{ fontSize: '0.85rem', fontWeight: 600, margin: '12px 0 4px', color: 'var(--text-primary)' }}>{children}</h3>,
                p: ({ children }) => <p style={{ fontSize: '0.8rem', margin: '4px 0', lineHeight: 1.6, color: 'var(--text-secondary)' }}>{children}</p>,
                code: ({ inline, className, children }) => {
                  if (inline) return <code style={{ fontSize: '0.78rem', padding: '1px 4px', borderRadius: 3, background: 'var(--bg-hover)', color: 'var(--code-inline)', fontFamily: "'JetBrains Mono', 'Fira Code', Consolas, monospace" }}>{children}</code>;
                  const content = String(children).replace(/\n$/, '');
                  const isJson = content.trimStart().startsWith('{') || content.trimStart().startsWith('[');
                  return (
                    <pre style={{ margin: '6px 0', padding: '8px 10px', background: 'var(--bg-primary)', border: '1px solid var(--border-primary)', borderRadius: 4, fontSize: '0.75rem', overflowX: 'auto', lineHeight: 1.5 }}>
                      {isJson ? <code dangerouslySetInnerHTML={{ __html: highlightJson(content) }} /> : <code style={{ color: 'var(--text-secondary)' }}>{content}</code>}
                    </pre>
                  );
                },
                pre: ({ children }) => <>{children}</>,
                ul: ({ children }) => <ul style={{ margin: '4px 0', paddingLeft: 20, fontSize: '0.8rem', color: 'var(--text-secondary)' }}>{children}</ul>,
                ol: ({ children }) => <ol style={{ margin: '4px 0', paddingLeft: 20, fontSize: '0.8rem', color: 'var(--text-secondary)' }}>{children}</ol>,
                li: ({ children }) => <li style={{ margin: '2px 0', lineHeight: 1.5 }}>{children}</li>,
                strong: ({ children }) => <strong style={{ color: 'var(--text-primary)' }}>{children}</strong>,
              }}>{llmsTxt}</Markdown>
            </div>
          </div>
        </div>
      )}

      {/* Control API Call History — bar chart card */}
      {isEnabled && (() => {
        const buckets = buildChartBuckets();
        const totalOk = apiCalls?.history?.filter(c => c.statusCode < 400).length || 0;
        const totalFail = apiCalls?.history?.filter(c => c.statusCode >= 400).length || 0;
        const maxBucket = Math.max(1, ...buckets.map(b => b.ok + b.fail));
        const methodColors = { GET: '#60a5fa', POST: '#4ade80', PUT: '#fbbf24', DELETE: '#f87171' };
        const filteredCalls = getFilteredCalls();

        return (
          <>
            <div className="card" style={{ padding: 20, marginTop: 16 }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 12 }}>
                <div>
                  <h3 style={{ margin: 0, fontSize: '0.95rem', fontWeight: 600 }}>API Call History</h3>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 4 }}>
                    <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                      Last 30 minutes
                    </span>
                    {apiCalls && apiCalls.count > 0 && (
                      <div className="apihist-legend" style={{ gap: 10 }}>
                        <span>
                          <span className="apihist-legend-dot" style={{ background: 'var(--badge-success-text, #4ade80)' }} />
                          {totalOk} ok
                        </span>
                        <span>
                          <span className="apihist-legend-dot" style={{ background: 'var(--badge-error-text, #f87171)' }} />
                          {totalFail} failed
                        </span>
                      </div>
                    )}
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  {apiCalls && apiCalls.count > 0 && (
                    <>
                      <button
                        className="btn btn-secondary"
                        onClick={() => setApiCallsListOpen(true)}
                        style={{ fontSize: '0.7rem', padding: '2px 8px' }}
                      >
                        View All
                      </button>
                      <button
                        className="btn btn-secondary"
                        onClick={handleClearApiCalls}
                        style={{ fontSize: '0.7rem', padding: '2px 8px' }}
                      >
                        Clear
                      </button>
                    </>
                  )}
                </div>
              </div>

              {!apiCalls ? (
                <div className="admin-skeleton">
                  <div className="admin-skeleton-row" style={{ width: '80%' }} />
                  <div className="admin-skeleton-row" style={{ width: '60%' }} />
                </div>
              ) : apiCalls.count === 0 ? (
                <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', textAlign: 'center', padding: '16px 0', margin: 0 }}>
                  No API calls recorded in the last hour
                </p>
              ) : (
                <div>
                  <div style={{ display: 'flex', height: 200 }}>
                    {/* Y-axis labels */}
                    <div style={{
                      display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
                      alignItems: 'flex-end', paddingRight: 6, fontSize: '0.62rem',
                      color: 'var(--text-muted)', width: 26, flexShrink: 0,
                      fontVariantNumeric: 'tabular-nums',
                    }}>
                      <span>{maxBucket}</span>
                      <span>{Math.round(maxBucket / 2)}</span>
                      <span>0</span>
                    </div>
                    {/* Bar chart */}
                    <div
                      className="apihist-chart"
                      onClick={() => setApiCallsListOpen(true)}
                      title="Click to view all calls"
                      style={{ flex: 1, height: 200 }}
                    >
                      {buckets.map((b, i) => {
                        const total = b.ok + b.fail;
                        const h = total > 0 ? Math.max(4, Math.round((total / maxBucket) * 192)) : 0;
                        const failH = total > 0 ? Math.round((b.fail / total) * h) : 0;
                        const okH = h - failH;
                        return (
                          <div key={i} className="apihist-bar" style={{ height: 200 }}>
                            <div style={{ flex: 1 }} />
                            {failH > 0 && <div className="apihist-bar-fail" style={{ height: failH }} />}
                            {okH > 0 && <div className="apihist-bar-ok" style={{ height: okH }} />}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  {/* X-axis labels */}
                  <div style={{
                    display: 'flex', justifyContent: 'space-between', marginLeft: 26,
                    fontSize: '0.62rem', color: 'var(--text-muted)', marginTop: 4,
                    fontVariantNumeric: 'tabular-nums',
                  }}>
                    <span>-30m</span>
                    <span>-20m</span>
                    <span>-10m</span>
                    <span>now</span>
                  </div>
                </div>
              )}
            </div>

            {/* List dialog */}
            {apiCallsListOpen && (
              <div className="apihist-overlay" onClick={(e) => { if (e.target === e.currentTarget) setApiCallsListOpen(false); }}>
                <div className="apihist-dialog">
                  <div className="apihist-dialog-header">
                    <span className="apihist-dialog-title">API Call History</span>
                    <button className="apihist-dialog-close" onClick={() => setApiCallsListOpen(false)}>&times;</button>
                  </div>
                  <div className="apihist-tabs">
                    {[
                      { key: 'all', label: 'All', count: apiCalls?.count || 0 },
                      { key: 'success', label: 'Success', count: totalOk },
                      { key: 'failed', label: 'Failed', count: totalFail },
                    ].map(tab => (
                      <button
                        key={tab.key}
                        className={`apihist-tab${apiCallsFilter === tab.key ? ' active' : ''}`}
                        onClick={() => setApiCallsFilter(tab.key)}
                      >
                        {tab.label}
                        <span className="apihist-tab-count">{tab.count}</span>
                      </button>
                    ))}
                  </div>
                  <div className="apihist-list">
                    {filteredCalls.length === 0 ? (
                      <div className="apihist-empty">No {apiCallsFilter === 'all' ? '' : apiCallsFilter} calls recorded</div>
                    ) : filteredCalls.map((call, i) => {
                      const statusColor = call.statusCode < 400
                        ? 'var(--badge-success-text, #4ade80)'
                        : 'var(--badge-error-text, #f87171)';
                      const ts = new Date(call.timestamp);
                      const timeStr = ts.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
                      return (
                        <button
                          key={call.requestId || i}
                          className="apihist-row"
                          onClick={() => { setDetailHeadersOpen(false); setApiCallDetail(call); }}
                        >
                          <span className="apihist-row-time">{timeStr}</span>
                          <span
                            className="apihist-row-method"
                            style={{
                              background: (methodColors[call.method] || '#888') + '18',
                              color: methodColors[call.method] || '#888',
                            }}
                          >
                            {call.method}
                          </span>
                          <span className="apihist-row-path" title={call.path}>{abbreviatePath(call.path)}</span>
                          <span className="apihist-row-status" style={{ color: statusColor }}>{call.statusCode}</span>
                          <span className="apihist-row-dur">{call.durationMs}ms</span>
                          <span className="apihist-row-arrow">&#9654;</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* Detail debug dialog */}
            {apiCallDetail && (
              <div className="apihist-detail-overlay" onClick={(e) => { if (e.target === e.currentTarget) setApiCallDetail(null); }}>
                <div className="apihist-detail">
                  <div className="apihist-detail-header">
                    <div className="apihist-detail-title">
                      <span
                        style={{
                          fontWeight: 700, fontSize: '0.7rem', padding: '2px 7px', borderRadius: 3,
                          background: (methodColors[apiCallDetail.method] || '#888') + '18',
                          color: methodColors[apiCallDetail.method] || '#888',
                        }}
                      >
                        {apiCallDetail.method}
                      </span>
                      <code style={{ fontSize: '0.82rem', fontWeight: 500 }}>{apiCallDetail.path}</code>
                      <span style={{
                        fontWeight: 600, fontSize: '0.78rem',
                        color: apiCallDetail.statusCode < 400 ? 'var(--badge-success-text, #4ade80)' : 'var(--badge-error-text, #f87171)',
                      }}>
                        {apiCallDetail.statusCode}
                      </span>
                    </div>
                    <button className="apihist-dialog-close" onClick={() => setApiCallDetail(null)}>&times;</button>
                  </div>

                  <div className="apihist-detail-body">
                    <div className="apihist-detail-meta">
                      <span>Request ID: <code>{apiCallDetail.requestId}</code></span>
                      <span>IP: <code>{apiCallDetail.ip}</code></span>
                      <span>Duration: <code>{apiCallDetail.durationMs}ms</code></span>
                      <span>Time: <code>{new Date(apiCallDetail.timestamp).toLocaleTimeString()}</code></span>
                    </div>

                    {/* Request Headers */}
                    {apiCallDetail.requestHeaders && (
                      <div className="apihist-detail-section">
                        <div className="apihist-detail-section-head" style={{ cursor: 'pointer' }} onClick={() => setDetailHeadersOpen(v => !v)}>
                          <span className="apihist-detail-section-label">
                            <span style={{ display: 'inline-block', width: 14, fontSize: '0.7rem', transition: 'transform 0.15s', transform: detailHeadersOpen ? 'rotate(90deg)' : 'rotate(0deg)' }}>&#9654;</span>
                            Request Headers
                          </span>
                          {detailHeadersOpen && (
                            <button
                              className="apihist-detail-copy"
                              onClick={(e) => { e.stopPropagation(); copyDetail(JSON.stringify(apiCallDetail.requestHeaders, null, 2), 'headers'); }}
                            >
                              {detailCopied === 'headers' ? 'Copied' : 'Copy'}
                            </button>
                          )}
                        </div>
                        {detailHeadersOpen && (
                          <pre className="apihist-detail-pre" dangerouslySetInnerHTML={{ __html: highlightJson(JSON.stringify(apiCallDetail.requestHeaders, null, 2)) }} />
                        )}
                      </div>
                    )}

                    {/* Request Body */}
                    {apiCallDetail.requestBody && Object.keys(apiCallDetail.requestBody).length > 0 && (
                      <div className="apihist-detail-section">
                        <div className="apihist-detail-section-head">
                          <span className="apihist-detail-section-label">Request Body</span>
                          <button
                            className="apihist-detail-copy"
                            onClick={() => copyDetail(JSON.stringify(apiCallDetail.requestBody, null, 2), 'reqBody')}
                          >
                            {detailCopied === 'reqBody' ? 'Copied' : 'Copy'}
                          </button>
                        </div>
                        <pre className="apihist-detail-pre" dangerouslySetInnerHTML={{ __html: highlightJson(JSON.stringify(apiCallDetail.requestBody, null, 2)) }} />
                      </div>
                    )}

                    {/* Response Body */}
                    <div className="apihist-detail-section">
                      <div className="apihist-detail-section-head">
                        <span className="apihist-detail-section-label">Response Body</span>
                        <button
                          className="apihist-detail-copy"
                          onClick={() => copyDetail(JSON.stringify(apiCallDetail.responseBody, null, 2), 'resBody')}
                        >
                          {detailCopied === 'resBody' ? 'Copied' : 'Copy'}
                        </button>
                      </div>
                      <pre className="apihist-detail-pre" dangerouslySetInnerHTML={{ __html: highlightJson(JSON.stringify(apiCallDetail.responseBody, null, 2)) }} />
                    </div>
                  </div>

                  <div className="apihist-detail-actions">
                    <button
                      className="btn btn-secondary"
                      onClick={() => {
                        const req = {
                          method: apiCallDetail.method,
                          path: apiCallDetail.path,
                          headers: apiCallDetail.requestHeaders,
                          body: apiCallDetail.requestBody,
                        };
                        copyDetail(JSON.stringify(req, null, 2), 'fullReq');
                      }}
                      style={{ fontSize: '0.75rem' }}
                    >
                      {detailCopied === 'fullReq' ? 'Copied' : 'Copy Request'}
                    </button>
                    <button
                      className="btn btn-secondary"
                      onClick={() => {
                        const resp = {
                          statusCode: apiCallDetail.statusCode,
                          body: apiCallDetail.responseBody,
                        };
                        copyDetail(JSON.stringify(resp, null, 2), 'fullRes');
                      }}
                      style={{ fontSize: '0.75rem' }}
                    >
                      {detailCopied === 'fullRes' ? 'Copied' : 'Copy Response'}
                    </button>
                    <button
                      className="btn btn-secondary"
                      onClick={() => {
                        const curlParts = [
                          `curl -X ${apiCallDetail.method}`,
                          `  '${window.location.origin}${apiCallDetail.path}'`,
                        ];
                        if (apiCallDetail.requestHeaders) {
                          for (const [k, v] of Object.entries(apiCallDetail.requestHeaders)) {
                            if (['host', 'content-length', 'connection', 'transfer-encoding'].includes(k.toLowerCase())) continue;
                            curlParts.push(`  -H '${k}: ${v}'`);
                          }
                        }
                        if (apiCallDetail.requestBody && Object.keys(apiCallDetail.requestBody).length > 0) {
                          curlParts.push(`  -d '${JSON.stringify(apiCallDetail.requestBody)}'`);
                        }
                        copyDetail(curlParts.join(' \\\n'), 'curl');
                      }}
                      style={{ fontSize: '0.75rem' }}
                    >
                      {detailCopied === 'curl' ? 'Copied' : 'Copy as cURL'}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </>
        );
      })()}

      {/* Environment Preset */}
      <div className="card" style={{ padding: 20, marginTop: 16 }}>
        <h3 style={{ margin: 0, fontSize: '0.95rem', fontWeight: 600 }}>Environment Preset</h3>
        <p style={{ margin: '4px 0 12px', fontSize: '0.8rem', color: 'var(--text-muted)' }}>
          Manage background services for this launcher environment
        </p>
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '8px 0', borderTop: '1px solid var(--border-color, #2a2a3e)',
        }}>
          <div>
            <span style={{ fontSize: '0.85rem', fontWeight: 500 }}>ani-code-daemon</span>
            <p style={{ margin: '2px 0 0', fontSize: '0.78rem', color: 'var(--text-muted)' }}>
              {envPreset?.stopAniCodeDaemon
                ? 'Disabled — ani-code-daemon is stopped on boot'
                : 'Enabled — ani-code-daemon runs without interference'}
            </p>
          </div>
          <button
            onClick={handleToggleStopDaemon}
            disabled={envPresetLoading || !envPreset}
            style={{
              flexShrink: 0, marginLeft: 16,
              width: 44, height: 24, borderRadius: 12,
              border: 'none', cursor: envPresetLoading || !envPreset ? 'default' : 'pointer',
              background: envPreset?.stopAniCodeDaemon
                ? 'var(--text-muted, #6b7280)'
                : 'var(--badge-success-text, #4ade80)',
              position: 'relative', transition: 'background 0.2s',
              opacity: envPresetLoading ? 0.5 : 1,
            }}
          >
            <span style={{
              position: 'absolute', top: 3, width: 18, height: 18,
              borderRadius: '50%', background: '#fff',
              transition: 'left 0.2s',
              left: envPreset?.stopAniCodeDaemon ? 3 : 23,
              boxShadow: '0 1px 3px rgba(0,0,0,0.2)',
            }} />
          </button>
        </div>
      </div>

      {/* Download Backup */}
      <div className="card" style={{ padding: 20, marginTop: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <h3 style={{ margin: 0, fontSize: '0.95rem', fontWeight: 600 }}>Download Backup</h3>
            <p style={{ margin: '4px 0 0', fontSize: '0.8rem', color: 'var(--text-muted)' }}>
              Download a compressed archive of the entire ~/.openclaw data folder
            </p>
          </div>
          <button
            className="btn btn-secondary"
            onClick={handleDownloadBackup}
            disabled={actionLoading}
            style={{ whiteSpace: 'nowrap' }}
          >
            {actionLoading ? 'Working...' : 'Download Backup'}
          </button>
        </div>
        {backupProgress !== null && (
          <div style={{ marginTop: 12 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', marginBottom: 4 }}>
              <span style={{ color: 'var(--text-muted)' }}>Creating backup archive...</span>
              <span style={{ color: 'var(--text-muted)' }}>{backupProgress}%</span>
            </div>
            <div style={{ height: 4, background: 'var(--bg-border)', borderRadius: 2, overflow: 'hidden' }}>
              <div style={{
                height: '100%', background: 'var(--accent-primary)',
                width: `${backupProgress}%`, transition: 'width 0.2s ease',
              }} />
            </div>
          </div>
        )}
      </div>

      {/* Temporary Access Link — hidden for temp sessions */}
      {!isTemp && <div className="card" style={{ padding: 20, marginTop: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <h3 style={{ margin: 0, fontSize: '0.95rem', fontWeight: 600 }}>Access Link</h3>
            <p style={{ margin: '4px 0 0', fontSize: '0.8rem', color: 'var(--text-muted)' }}>
              Generate a temporary login link that expires in 1 hour
            </p>
          </div>
          {!accessLink && (
            <button
              className="btn btn-secondary"
              onClick={handleGenerateLink}
              disabled={actionLoading}
              style={{ whiteSpace: 'nowrap' }}
            >
              {actionLoading ? 'Working...' : 'Generate Link'}
            </button>
          )}
        </div>
        {accessLink && (
          <div style={{ marginTop: 12, display: 'flex', alignItems: 'center', gap: 8 }}>
            <code style={{
              flex: 1, padding: '6px 10px', background: 'var(--bg-secondary)', borderRadius: 6,
              fontSize: '0.75rem', wordBreak: 'break-all', fontFamily: 'monospace',
            }}>
              {accessLink}
            </code>
            <button
              className="btn btn-secondary"
              onClick={() => copyToClipboard(accessLink, 'link')}
              style={{ fontSize: '0.75rem', padding: '4px 10px', whiteSpace: 'nowrap' }}
            >
              {copied === 'link' ? 'Copied!' : 'Copy'}
            </button>
          </div>
        )}
      </div>}

      {/* Danger Zone — collapsible, hidden for temporary sessions */}
      {!isTemp && (
        <div style={{ marginTop: 16 }}>
          <button
            onClick={() => setDangerZoneOpen(!dangerZoneOpen)}
            style={{
              display: 'flex', alignItems: 'center', gap: 8,
              width: '100%', padding: '8px 0', background: 'none', border: 'none',
              cursor: 'pointer', color: 'var(--text-muted)', textAlign: 'left',
            }}
          >
            <span style={{ fontSize: '0.7rem', transform: dangerZoneOpen ? 'rotate(90deg)' : 'none', transition: 'transform 0.15s' }}>&#9654;</span>
            <span style={{ fontSize: '0.8rem', fontWeight: 500 }}>Danger Zone</span>
          </button>
          {dangerZoneOpen && (
            <div className="card" style={{ marginTop: 8, borderColor: 'var(--badge-error-text, #c33)' }}>
              <div style={{ padding: 20 }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingBottom: 14, borderBottom: '1px solid var(--border-color, #2a2a3e)' }}>
                  <div>
                    <span style={{ fontSize: '0.85rem', fontWeight: 600 }}>Reset Launcher Token</span>
                    <p style={{ margin: '2px 0 0', fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                      Regenerate login password and invalidate all sessions
                    </p>
                  </div>
                  <button
                    className="btn btn-danger"
                    onClick={handleResetLauncherToken}
                    disabled={actionLoading}
                    style={{ fontSize: '0.75rem', padding: '4px 12px', whiteSpace: 'nowrap' }}
                  >
                    {actionLoading ? 'Working...' : 'Reset Token'}
                  </button>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingTop: 14, paddingBottom: 14, borderBottom: '1px solid var(--border-color, #2a2a3e)' }}>
                  <div>
                    <span style={{ fontSize: '0.85rem', fontWeight: 600 }}>Reset Marketplace Catalogs</span>
                    <p style={{ margin: '2px 0 0', fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                      Wipe all external catalog items and keep only installed &amp; built-in items
                    </p>
                  </div>
                  <button
                    className="btn btn-danger"
                    onClick={handleResetMarketplaceCatalogs}
                    disabled={actionLoading}
                    style={{ fontSize: '0.75rem', padding: '4px 12px', whiteSpace: 'nowrap' }}
                  >
                    {actionLoading ? 'Working...' : 'Reset Catalogs'}
                  </button>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingTop: 14 }}>
                  <div>
                    <span style={{ fontSize: '0.85rem', fontWeight: 600 }}>Delete All Data</span>
                    <p style={{ margin: '2px 0 0', fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                      Permanently delete ~/.openclaw including config, credentials, and workspace
                    </p>
                  </div>
                  <button
                    className="btn btn-danger"
                    onClick={handleDeleteMemory}
                    disabled={actionLoading}
                    style={{ fontSize: '0.75rem', padding: '4px 12px', whiteSpace: 'nowrap' }}
                  >
                    {actionLoading ? 'Working...' : 'Delete All'}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Confirm dialog */}
      {confirmDialog && (
        <div className="dialog-overlay" onClick={() => setConfirmDialog(null)}>
          <div className="dialog" onClick={e => e.stopPropagation()}>
            <div className="dialog-title">{confirmDialog.title}</div>
            <div className="dialog-body">{confirmDialog.body}</div>
            <div className="dialog-actions">
              <button className="btn btn-secondary" onClick={() => setConfirmDialog(null)}>
                Cancel
              </button>
              <button className="btn btn-danger" onClick={confirmDialog.onConfirm}>
                {confirmDialog.confirmLabel}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

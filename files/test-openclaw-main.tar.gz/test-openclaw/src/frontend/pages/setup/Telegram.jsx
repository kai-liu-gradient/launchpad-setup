import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useWizard } from '../../context/WizardContext';
import { authFetch } from '../../hooks/useAuth';

export default function Telegram() {
  const [token, setToken] = useState('');
  const [botInfo, setBotInfo] = useState(null);
  const [validating, setValidating] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [existingConfig, setExistingConfig] = useState(null);
  const [reconfiguring, setReconfiguring] = useState(false);
  const { markCompleted } = useWizard();
  const navigate = useNavigate();

  useEffect(() => {
    authFetch('/api/openclaw/telegram/pairing-status')
      .then((r) => r.json())
      .then((data) => {
        if (data.configured) setExistingConfig(data);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const handleValidate = async () => {
    if (!token.trim()) return;
    setValidating(true);
    setError(null);
    setBotInfo(null);
    try {
      const res = await authFetch('/api/openclaw/telegram/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: token.trim() }),
      });
      let data;
      try {
        data = await res.json();
      } catch {
        throw new Error('Unexpected response from server');
      }
      if (!res.ok) throw new Error(data.message || data.error || 'Validation failed');
      setBotInfo(data.bot || data);
    } catch (err) {
      setError(err.message);
    } finally {
      setValidating(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    setError(null);
    try {
      const res = await authFetch('/api/openclaw/telegram/configure', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: token.trim() }),
      });
      let data;
      try {
        data = await res.json();
      } catch {
        throw new Error('Unexpected response from server');
      }
      if (!res.ok) throw new Error(data.message || data.error || 'Failed to save Telegram configuration');
      markCompleted('channels', data);
      navigate('/setup/config');
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="card">
        <div className="skeleton">
          <div className="skeleton-row" style={{ width: '50%' }} />
          <div className="skeleton-row" style={{ width: '90%' }} />
          <div className="skeleton-row-lg" style={{ width: '100%' }} />
          <div className="skeleton-row" style={{ width: '70%' }} />
          <div className="skeleton-row-lg" style={{ width: '100%' }} />
          <div className="skeleton-row" style={{ width: '40%' }} />
        </div>
      </div>
    );
  }

  return (
    <div className="card">
      <h2 className="card-title">Telegram Bot Configuration</h2>

      {existingConfig && !reconfiguring ? (
        <>
          <div style={{
            background: 'var(--success-box-bg)',
            border: '1px solid var(--success-box-border)',
            borderRadius: 8,
            padding: 16,
            marginBottom: 16,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
              <span className="status-dot online" />
              <strong style={{ color: 'var(--success-box-text)' }}>Telegram Bot Already Configured</strong>
            </div>
            <div style={{ fontSize: '0.85rem', color: 'var(--success-box-detail)' }}>
              {existingConfig.botInfo && existingConfig.botInfo.username && <div>Username: @{existingConfig.botInfo.username}</div>}
              {existingConfig.botInfo && existingConfig.botInfo.firstName && <div>Name: {existingConfig.botInfo.firstName}</div>}
              {existingConfig.botInfo && existingConfig.botInfo.id && <div>Bot ID: {existingConfig.botInfo.id}</div>}
              {existingConfig.dmPolicy && <div>DM Policy: {existingConfig.dmPolicy}</div>}
              {existingConfig.streamMode && <div>Stream Mode: {existingConfig.streamMode}</div>}
              {existingConfig.historyLimit !== undefined && <div>History Limit: {existingConfig.historyLimit}</div>}
              {existingConfig.gatewayReachable !== undefined && (
                <div>Gateway: {existingConfig.gatewayReachable ? 'Reachable' : 'Not reachable'}</div>
              )}
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, marginTop: 20 }}>
            <button className="btn btn-secondary" onClick={() => navigate('/setup/credentials')}>
              Back
            </button>
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn btn-secondary" onClick={() => setReconfiguring(true)}>
                Reconfigure
              </button>
              <button
                className="btn btn-primary"
                onClick={() => {
                  markCompleted('channels', { existing: true });
                  navigate('/setup/config');
                }}
              >
                Continue
              </button>
            </div>
          </div>
        </>
      ) : (
        <>
          <div style={{ background: 'var(--info-box-bg)', border: '1px solid var(--info-box-border)', borderRadius: 8, padding: 16, marginBottom: 20, fontSize: '0.85rem', color: 'var(--text-tertiary)' }}>
            <p style={{ marginBottom: 8, color: 'var(--text-primary)', fontWeight: 'bold' }}>How to create a Telegram bot:</p>
            <ol style={{ paddingLeft: 20, lineHeight: 1.8 }}>
              <li>Open Telegram and search for <strong style={{ color: 'var(--accent)' }}>@BotFather</strong></li>
              <li>Send <code style={{ background: 'var(--info-code-bg)', padding: '2px 6px', borderRadius: 4 }}>/newbot</code> and follow the prompts</li>
              <li>Copy the bot token provided by BotFather</li>
              <li>Paste it below and click Validate</li>
            </ol>
          </div>

          <div className="input-group">
            <label className="input-label">Bot Token</label>
            <input
              className="input"
              type="text"
              placeholder="123456789:ABCdefGHIjklMNOpqrsTUVwxyz"
              value={token}
              onChange={(e) => setToken(e.target.value)}
            />
          </div>

          {error && <div className="error-container" style={{ marginBottom: 16 }}>{error}</div>}

          {botInfo && (
            <div style={{
              background: 'var(--success-box-bg)',
              border: '1px solid var(--success-box-border)',
              borderRadius: 8,
              padding: 16,
              marginBottom: 16,
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                <span className="status-dot online" />
                <strong style={{ color: 'var(--success-box-text)' }}>Bot Validated Successfully</strong>
              </div>
              <div style={{ fontSize: '0.85rem', color: 'var(--success-box-detail)' }}>
                {botInfo.username && <div>Username: @{botInfo.username}</div>}
                {(botInfo.firstName || botInfo.first_name) && <div>Name: {botInfo.firstName || botInfo.first_name}</div>}
                {botInfo.id && <div>Bot ID: {botInfo.id}</div>}
                {(botInfo.canJoinGroups !== undefined || botInfo.can_join_groups !== undefined) && (
                  <div>Can join groups: {(botInfo.canJoinGroups ?? botInfo.can_join_groups) ? 'Yes' : 'No'}</div>
                )}
              </div>
            </div>
          )}

          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, marginTop: 20 }}>
            <button className="btn btn-secondary" onClick={() => reconfiguring ? setReconfiguring(false) : navigate('/setup/credentials')}>
              Back
            </button>
            <div style={{ display: 'flex', gap: 8 }}>
              <button
                className="btn btn-secondary"
                onClick={() => {
                  markCompleted('channels', { skipped: true });
                  navigate('/setup/config');
                }}
              >
                Skip
              </button>
              {!botInfo ? (
                <button
                  className="btn btn-primary"
                  onClick={handleValidate}
                  disabled={!token.trim() || validating}
                >
                  {validating ? <><span className="spinner" /> Validating...</> : 'Validate'}
                </button>
              ) : (
                <button
                  className="btn btn-primary"
                  onClick={handleSave}
                  disabled={saving}
                >
                  {saving ? <><span className="spinner" /> Saving...</> : 'Save & Continue'}
                </button>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

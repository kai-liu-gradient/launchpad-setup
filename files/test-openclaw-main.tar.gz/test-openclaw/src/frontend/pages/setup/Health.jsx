import React, { useEffect, useState, useCallback, useRef } from 'react';
import { useNavigate, useOutletContext } from 'react-router-dom';
import { Stethoscope, Rocket } from 'lucide-react';
import { authFetch } from '../../hooks/useAuth';
import HealthCard from '../../components/HealthCard';

const ClawIcon = ({ size = 14, style }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={style}>
    <path d="M5 3c0 4 2 7 5 9" />
    <path d="M12 2c0 5 0 8 0 10" />
    <path d="M19 3c0 4-2 7-5 9" />
    <path d="M8 14c0 3 2 5 4 7" />
    <path d="M16 14c0 3-2 5-4 7" />
  </svg>
);

// Lightweight JSON syntax highlighter (returns HTML string)
function highlightJson(str) {
  return str.replace(
    /("(?:[^"\\]|\\.)*")\s*(:)|("(?:[^"\\]|\\.)*")|(true|false|null)|(-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)/g,
    (match, key, colon, strVal, keyword, num) => {
      if (key && colon) return `<span style="color:var(--accent)">${key}</span>${colon}`;
      if (strVal) return `<span style="color:var(--badge-success-text)">${strVal}</span>`;
      if (keyword) return `<span style="color:var(--badge-warning-text)">${keyword}</span>`;
      if (num) return `<span style="color:var(--badge-info-text)">${num}</span>`;
      return match;
    }
  );
}

// Highlight log output lines (timestamps, status markers, errors)
function highlightLog(str) {
  return str.split('\n').map(line => {
    // Highlight [OK] / [PASS] markers
    let h = line.replace(/\[(OK|PASS|FIXED|SUCCESS)\]/gi, '<span style="color:var(--badge-success-text)">[$1]</span>');
    // Highlight [FAIL] / [ERROR] / [WARN] markers
    h = h.replace(/\[(FAIL|ERROR|ERR|CRITICAL)\]/gi, '<span style="color:var(--badge-error-text)">[$1]</span>');
    h = h.replace(/\[(WARN|WARNING|SKIP)\]/gi, '<span style="color:var(--badge-warning-text)">[$1]</span>');
    // Highlight leading checkmarks/crosses
    h = h.replace(/^(\s*)(✓|✔)/, '$1<span style="color:var(--badge-success-text)">$2</span>');
    h = h.replace(/^(\s*)(✗|✘|×)/, '$1<span style="color:var(--badge-error-text)">$2</span>');
    // Highlight section headers (lines ending with :)
    if (/^[A-Z][A-Za-z\s&]+:$/.test(line.trim())) {
      h = `<span style="color:var(--accent);font-weight:600">${h}</span>`;
    }
    return h;
  }).join('\n');
}

function useHealthSection(url, skipAutoFetch) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [lastChecked, setLastChecked] = useState(null);

  const fetch_ = useCallback(() => {
    setLoading(true);
    authFetch(url)
      .then((r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json();
      })
      .then((d) => {
        setData(d);
        setError(null);
        setLastChecked(new Date());
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [url]);

  const seed = useCallback((d) => {
    setData(d);
    setError(d?.error ? d.error : null);
    setLoading(false);
    setLastChecked(new Date());
  }, []);

  useEffect(() => {
    if (!skipAutoFetch) fetch_();
  }, [fetch_, skipAutoFetch]);

  return { data, loading, error, lastChecked, refresh: fetch_, seed };
}

function SummaryBar({ sections }) {
  if (!sections) return null;

  const items = [
    { key: 'config', label: 'Config' },
    { key: 'version', label: 'Version' },
    { key: 'models', label: 'Models' },
    ...(sections.telegram !== undefined ? [{ key: 'telegram', label: 'Telegram' }] : []),
    ...(sections.feishu !== undefined ? [{ key: 'feishu', label: 'Feishu' }] : []),
    { key: 'connectivity', label: 'Connectivity & Security' },
    { key: 'gateway', label: 'Gateway' },
    ...(sections.zombies ? [{ key: 'zombies', label: 'Zombies' }] : []),
  ];

  const allOk = items.every((item) => sections[item.key] === 'ok' || sections[item.key] === 'info');

  if (allOk) return null;

  return (
    <div className="card" style={{ marginBottom: 16, padding: '14px 20px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8 }}>
        <span style={{ fontWeight: 600, fontSize: '0.9rem', color: 'var(--badge-warning-text)' }}>
          Issues Detected
        </span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
          {items.map((item) => {
            const s = sections[item.key];
            const dotColor = s === 'ok' ? 'var(--badge-success-text)'
              : s === 'warn' ? 'var(--badge-warning-text)'
              : s === 'error' ? 'var(--badge-error-text)'
              : 'var(--text-muted)';
            return (
              <a
                key={item.key}
                href={`#health-${item.key}`}
                style={{ display: 'flex', alignItems: 'center', gap: 5, textDecoration: 'none', fontSize: '0.8rem', color: 'var(--text-secondary)' }}
              >
                <span style={{ width: 8, height: 8, borderRadius: '50%', background: dotColor, display: 'inline-block' }} />
                {item.label}
              </a>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export default function Health() {
  const batchDone = useRef(false);

  const configHealth = useHealthSection('/api/openclaw/health/config', true);
  const versionHealth = useHealthSection('/api/openclaw/health/version', true);
  const modelsHealth = useHealthSection('/api/openclaw/health/models', true);
  const telegramHealth = useHealthSection('/api/openclaw/health/telegram', true);
  const feishuHealth = useHealthSection('/api/openclaw/health/feishu', true);
  const gatewayHealth = useHealthSection('/api/openclaw/health/gateway', true);
  const logsHealth = useHealthSection('/api/openclaw/health/logs', true);

  // Batch fetch all health sections in a single request
  useEffect(() => {
    if (batchDone.current) return;
    batchDone.current = true;
    authFetch('/api/openclaw/health/batch')
      .then((r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json();
      })
      .then((batch) => {
        // Seed successful sections; failed ones get retried individually
        const sections = [
          [batch.config, configHealth],
          [batch.version, versionHealth],
          [batch.models, modelsHealth],
          [batch.telegram, telegramHealth],
          [batch.feishu, feishuHealth],
          [batch.gateway, gatewayHealth],
          [batch.logs, logsHealth],
        ];

        for (const [data, section] of sections) {
          if (data && !data.error) {
            section.seed(data);
          } else {
            // Missing or errored in batch — retry via individual endpoint
            section.refresh();
          }
        }

        // Auto-expand pairing form when there are pending requests and no paired users
        if (batch.telegram?.dmPolicy === 'pairing' && !batch.telegram?.paired && batch.telegram?.pairingRequests?.length > 0) {
          setShowPairingForm(true);
        }
        if (batch.feishu?.configured && batch.feishu?.credentialsValid && !batch.feishu?.paired && batch.feishu?.pairingRequests?.length > 0) {
          setShowPairingForm(true);
        }
      })
      .catch(() => {
        // Batch failed — fall back to individual fetches
        configHealth.refresh();
        versionHealth.refresh();
        modelsHealth.refresh();
        telegramHealth.refresh();
        feishuHealth.refresh();
        gatewayHealth.refresh();
        logsHealth.refresh();
      });
  }, []);

  const [showRestart, setShowRestart] = useState(false);
  const [showOtherProviders, setShowOtherProviders] = useState(false);
  const [logTail, setLogTail] = useState({ loading: false, data: null, visible: false });
  const [restarting, setRestarting] = useState(false);
  const [doctorFix, setDoctorFix] = useState({ loading: false, result: null, showResult: false });
  const [agentTest, setAgentTest] = useState({ loading: false, result: null });
  const [pairingCode, setPairingCode] = useState('');
  const [pairingApproval, setPairingApproval] = useState({ loading: false, result: null });
  const [pairingDone, setPairingDone] = useState(false);
  const [pairingDismissed, setPairingDismissed] = useState(false);
  const [pairingChannel, setPairingChannel] = useState(null);
  const [updateGuideOpen, setUpdateGuideOpen] = useState(false);
  const [configViewer, setConfigViewer] = useState({ visible: false, loading: false, content: null });
  const [showPairingForm, setShowPairingForm] = useState(false);
  const [resourceStats, setResourceStats] = useState({ loading: true, data: null });
  const [agentTestDebugOpen, setAgentTestDebugOpen] = useState(false);
  const [checkUpdateLoading, setCheckUpdateLoading] = useState(false);
  const [upgradePolicyLoading, setUpgradePolicyLoading] = useState(false);
  const [versionOverrideLoading, setVersionOverrideLoading] = useState(false);
  const [versionOverrideResult, setVersionOverrideResult] = useState(null);
  const [versionOverrideInput, setVersionOverrideInput] = useState('');
  const [versionOverrideOpen, setVersionOverrideOpen] = useState(false);
  const [showLauncherRestart, setShowLauncherRestart] = useState(false);
  const [launcherRestarting, setLauncherRestarting] = useState(false);
  // Collapsed state for health cards
  const [cardCollapsed, setCardCollapsed] = useState({
    version: true,
  });
  const toggleCard = (key) => setCardCollapsed(prev => ({ ...prev, [key]: !prev[key] }));
  const navigate = useNavigate();

  const handleViewConfig = async () => {
    setConfigViewer({ visible: true, loading: true, content: null });
    try {
      const res = await authFetch('/api/openclaw/config');
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setConfigViewer({ visible: true, loading: false, content: JSON.stringify(data, null, 2) });
    } catch (err) {
      setConfigViewer({ visible: true, loading: false, content: `Error loading config: ${err.message}` });
    }
  };

  const handleAgentTest = async () => {
    setAgentTest({ loading: true, result: null });
    try {
      const res = await authFetch('/api/openclaw/health/agent-test', { method: 'POST' });
      const data = await res.json();
      setAgentTest({ loading: false, result: data });
    } catch (err) {
      setAgentTest({ loading: false, result: { ok: false, error: err.message } });
    }
  };

  const handleCheckUpdate = async () => {
    setCheckUpdateLoading(true);
    try {
      const res = await authFetch('/api/openclaw/health/version/check', { method: 'POST' });
      if (!res.ok) throw new Error('Update check failed');
      const data = await res.json();
      if (data.versionInfo) {
        versionHealth.seed(data.versionInfo);
      } else {
        versionHealth.refresh();
      }
    } catch (err) {
      console.error('Update check error:', err);
    } finally {
      setCheckUpdateLoading(false);
    }
  };

  const handleToggleUpgradePolicy = async () => {
    if (!versionHealth.data) return;
    const newPolicy = versionHealth.data.upgradePolicy === 'auto' ? 'manual' : 'auto';
    setUpgradePolicyLoading(true);
    try {
      const res = await authFetch('/api/openclaw/upgrade-policy', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ upgradePolicy: newPolicy }),
      });
      if (!res.ok) throw new Error('Failed to update upgrade policy');
      const data = await res.json();
      versionHealth.seed({ ...versionHealth.data, upgradePolicy: data.upgradePolicy });
    } catch (err) {
      console.error('Upgrade policy toggle error:', err);
    } finally {
      setUpgradePolicyLoading(false);
    }
  };

  const handleVersionOverride = async () => {
    const version = versionOverrideInput.trim();
    if (!version) return;
    setVersionOverrideLoading(true);
    setVersionOverrideResult(null);
    try {
      const res = await authFetch('/api/openclaw/version/override', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ version }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.message || 'Failed to override version');
      }
      const data = await res.json();
      versionHealth.seed({ ...versionHealth.data, upgradePolicy: 'manual', latestVersionOverride: data.version });
      setVersionOverrideResult({ ok: true, version: data.version });
    } catch (err) {
      console.error('Version override error:', err);
      setVersionOverrideResult({ ok: false, error: err.message });
    } finally {
      setVersionOverrideLoading(false);
    }
  };

  const handlePairingApprove = async (channel) => {
    if (!pairingCode.trim()) return;
    const resolvedChannel = channel || pairingChannel || 'telegram';
    setPairingApproval({ loading: true, result: null });
    try {
      const res = await authFetch('/api/openclaw/channel/pairing-approve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: pairingCode.trim(), channel: resolvedChannel }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Approval failed');
      setPairingApproval({ loading: false, result: { ok: true, message: data.message } });
      setPairingCode('');
      setPairingDone(true);
      setPairingChannel(resolvedChannel);
      // Re-check health after successful approval
      setTimeout(() => {
        if (resolvedChannel === 'feishu') feishuHealth.refresh();
        else telegramHealth.refresh();
      }, 1000);
    } catch (err) {
      setPairingApproval({ loading: false, result: { ok: false, message: err.message } });
    }
  };

  const handleRestart = async () => {
    setRestarting(true);
    try {
      const res = await authFetch('/api/openclaw/gateway/restart', { method: 'POST' });
      if (!res.ok) throw new Error('Restart failed');
      setShowRestart(false);
      setTimeout(() => {
        gatewayHealth.refresh();
      }, 3000);
    } catch (err) {
      // error displayed via gateway card
    } finally {
      setRestarting(false);
    }
  };

  const handleDoctorFix = async () => {
    setDoctorFix({ loading: true, result: null, showResult: false });
    try {
      const res = await authFetch('/api/openclaw/gateway/doctor-fix', { method: 'POST' });
      const text = await res.text();
      let data;
      try {
        data = JSON.parse(text);
      } catch {
        // Server returned non-JSON (e.g. HTML from a server restart or proxy error)
        setDoctorFix({ loading: false, showResult: true, result: { success: false, doctorOutput: !res.ok ? `Server returned HTTP ${res.status}` : 'Server returned an unexpected response. The gateway may have restarted — please try again.' } });
        return;
      }
      if (!res.ok) {
        setDoctorFix({ loading: false, showResult: true, result: { success: false, doctorOutput: data.message || data.error || `HTTP ${res.status}` } });
        return;
      }
      setDoctorFix({ loading: false, showResult: true, result: data });
      // Refresh health checks after doctor fix (config may also be fixed)
      setTimeout(() => {
        gatewayHealth.refresh();
        configHealth.refresh();
      }, 3000);
    } catch (err) {
      setDoctorFix({ loading: false, showResult: true, result: { success: false, doctorOutput: err.message } });
    }
  };

  const handleLauncherRestart = async () => {
    setLauncherRestarting(true);
    try {
      const res = await authFetch('/api/openclaw/launcher/restart', { method: 'POST' });
      if (!res.ok) throw new Error('Launcher restart failed');
      // The server will restart — poll /api/health until it comes back
      setShowLauncherRestart(false);
      // Show the waiting overlay
      setLauncherRestarting('waiting');
      const poll = async () => {
        const maxWait = 60000;
        const interval = 2000;
        const start = Date.now();
        while (Date.now() - start < maxWait) {
          await new Promise(r => setTimeout(r, interval));
          try {
            const r = await fetch('/api/health');
            if (r.ok) {
              setLauncherRestarting(false);
              window.location.reload();
              return;
            }
          } catch {
            // server still down
          }
        }
        // Timeout — just try reloading
        setLauncherRestarting(false);
        window.location.reload();
      };
      poll();
    } catch (err) {
      setLauncherRestarting(false);
      setShowLauncherRestart(false);
    }
  };

  const handleViewLogs = async () => {
    if (logTail.visible) {
      setLogTail({ loading: false, data: null, visible: false });
      return;
    }
    setLogTail({ loading: true, data: null, visible: true });
    try {
      const res = await authFetch('/api/openclaw/health/logs/tail?lines=50');
      const data = await res.json();
      setLogTail({ loading: false, data, visible: true });
    } catch (err) {
      setLogTail({ loading: false, data: { error: err.message }, visible: true });
    }
  };

  const formatUptime = (ms) => {
    if (!ms) return 'N/A';
    const seconds = Math.floor(ms / 1000);
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h}h ${m}m ${s}s`;
  };

  const formatBytes = (bytes) => {
    if (!bytes) return 'N/A';
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  // Derive section statuses for individual cards
  const versionUiStale = versionHealth.data?.launcher?.version && versionHealth.data?.launcher?.uiBuildVersion && versionHealth.data.launcher.version !== versionHealth.data.launcher.uiBuildVersion;
  const versionStatus = versionHealth.error ? 'error'
    : versionHealth.data ? (versionUiStale ? 'warn' : (versionHealth.data.updateAvailable ? 'info' : (versionHealth.data.installedVersion ? 'ok' : 'info'))) : null;
  const configStatus = configHealth.error ? 'error'
    : configHealth.data?.valid
      ? (configHealth.data.checks?.some(c => c.warn) ? 'warn' : 'ok')
      : configHealth.data ? 'error' : null;
  const modelsStatus = modelsHealth.error ? 'error'
    : modelsHealth.data ? (
      modelsHealth.data.providers.length === 0 ? 'warn'
      : !modelsHealth.data.defaultModel || !modelsHealth.data.defaultModel.includes('/') ? 'warn'
      : modelsHealth.data.providers.every(p => p.reachable) ? 'ok'
      : modelsHealth.data.providers.some(p => p.reachable) ? 'warn'
      : 'error'
    ) : null;
  const telegramPaired = pairingDone || pairingDismissed || telegramHealth.data?.paired || telegramHealth.data?.launcherPairingDone;
  const telegramStatus = telegramHealth.error ? 'error'
    : telegramHealth.data ? (
      !telegramHealth.data.configured ? null
      : !telegramHealth.data.botValid ? 'error'
      : telegramHealth.data.dmPolicy === 'pairing' && !telegramPaired ? 'warn'
      : 'ok'
    ) : null;
  const feishuPaired = (pairingDone && pairingChannel === 'feishu') || pairingDismissed || feishuHealth.data?.paired || feishuHealth.data?.launcherPairingDone;
  const feishuStatus = feishuHealth.error ? 'error'
    : feishuHealth.data ? (
      !feishuHealth.data.configured ? null
      : !feishuHealth.data.credentialsValid ? 'error'
      : !feishuPaired ? 'warn'
      : 'ok'
    ) : null;
  // Detect crash-loop: high restart count with very low uptime (same logic as instance-control.js)
  // Skip during restart grace period — after a user-triggered restart the counters
  // naturally look like a crash loop until the process stabilises.
  const crashLoop = (() => {
    if (gatewayHealth.data?.restartGracePeriod) return false;
    const proc = gatewayHealth.data?.process;
    if (!proc) return false;
    const restarts = proc.restartCount || 0;
    const unstable = proc.unstableRestarts || 0;
    const uptimeMs = proc.uptime || 0;
    return (restarts >= 3 || unstable >= 2) && uptimeMs < 30000;
  })();

  // Whether openclaw.json config file is missing (not just invalid)
  const configMissing = configHealth.data?.checks?.find(c => c.name === 'Config File')?.ok === false;

  const gatewayStatus = gatewayHealth.error ? 'error'
    : gatewayHealth.data ? (
      crashLoop ? 'error'
      : gatewayHealth.data.process?.status === 'online' ? 'ok'
      : gatewayHealth.data.process ? 'warn'
      : 'error'
    ) : null;

  // Connectivity & Security: combines probe and token checks
  const connectivityStatus = (() => {
    if (gatewayHealth.error) return 'error';
    const probeOk = gatewayHealth.data?.probe?.reachable;
    const tokenOk = gatewayHealth.data?.security?.token?.strength === 'strong';
    const syncOk = gatewayHealth.data?.security?.tokenSync?.synced;
    if (probeOk && tokenOk && syncOk) return 'ok';
    if (gatewayHealth.data?.security?.token?.strength === 'missing') return 'error';
    if (!probeOk && gatewayHealth.data) return 'error';
    if (gatewayHealth.data) return 'warn';
    return null;
  })();

  // Zombie process status — only track if zombies are actually found
  const zombieStatus = gatewayHealth.data?.zombies?.found ? 'warn' : null;

  // Build summary from individual check results
  const hasSomeData = configHealth.data || gatewayHealth.data || modelsHealth.data || telegramHealth.data || feishuHealth.data;
  const fullSummary = hasSomeData ? {} : null;
  if (fullSummary) {
    if (configStatus) fullSummary.config = configStatus;
    if (versionStatus) fullSummary.version = versionStatus;
    if (modelsStatus) fullSummary.models = modelsStatus;
    if (telegramStatus && telegramHealth.data?.configured) fullSummary.telegram = telegramStatus;
    if (feishuStatus && feishuHealth.data?.configured) fullSummary.feishu = feishuStatus;
    if (connectivityStatus) fullSummary.connectivity = connectivityStatus;
    if (gatewayStatus) fullSummary.gateway = gatewayStatus;
    if (zombieStatus) fullSummary.zombies = zombieStatus;
  }

  const { setTabActions } = useOutletContext() || {};

  const [refreshingAll, setRefreshingAll] = useState(false);
  const handleRefreshAllRef = useRef(null);
  const handleRefreshAll = () => {
    setRefreshingAll(true);
    authFetch('/api/openclaw/health/batch')
      .then((r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json();
      })
      .then((batch) => {
        const sections = [
          [batch.config, configHealth],
          [batch.version, versionHealth],
          [batch.models, modelsHealth],
          [batch.telegram, telegramHealth],
          [batch.feishu, feishuHealth],
          [batch.gateway, gatewayHealth],
          [batch.logs, logsHealth],
        ];
        for (const [data, section] of sections) {
          if (data && !data.error) {
            section.seed(data);
          } else {
            section.refresh();
          }
        }
      })
      .catch(() => {
        configHealth.refresh();
        versionHealth.refresh();
        modelsHealth.refresh();
        telegramHealth.refresh();
        feishuHealth.refresh();
        gatewayHealth.refresh();
        logsHealth.refresh();
      })
      .finally(() => setRefreshingAll(false));
  };
  handleRefreshAllRef.current = handleRefreshAll;

  // Register Refresh All button in the tab header
  useEffect(() => {
    if (!setTabActions) return;
    setTabActions(
      <button className="btn btn-secondary btn-sm" onClick={() => handleRefreshAllRef.current()} disabled={refreshingAll}>
        {refreshingAll ? <><span className="spinner" style={{ width: 13, height: 13, borderWidth: 2 }} /> Refreshing...</> : 'Refresh All'}
      </button>
    );
    return () => setTabActions(null);
  }, [setTabActions, refreshingAll]);

  // Fetch resource utilization summary
  const fetchResourceStats = useCallback(() => {
    setResourceStats(prev => ({ ...prev, loading: true }));
    authFetch('/api/openclaw/system-stats/summary')
      .then(r => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json();
      })
      .then(d => setResourceStats({ loading: false, data: d }))
      .catch(() => setResourceStats({ loading: false, data: null }));
  }, []);

  useEffect(() => {
    fetchResourceStats();
    const interval = setInterval(fetchResourceStats, 60000);
    return () => clearInterval(interval);
  }, [fetchResourceStats]);

  // Guidance banner states
  const gatewayDown = gatewayStatus === 'error' || gatewayStatus === 'warn';
  const needsTelegramPairing = telegramHealth.data?.configured
    && telegramHealth.data?.botValid
    && telegramHealth.data?.dmPolicy === 'pairing'
    && !telegramPaired
    && !pairingDismissed;
  const needsFeishuPairing = feishuHealth.data?.configured
    && feishuHealth.data?.credentialsValid
    && !feishuPaired
    && !pairingDismissed;
  const needsPairing = needsTelegramPairing || needsFeishuPairing;

  // Determine which channels need pairing for the guidance banner
  const pairingChannels = [];
  if (needsTelegramPairing) pairingChannels.push('telegram');
  if (needsFeishuPairing) pairingChannels.push('feishu');
  // Default pairing channel: if only one needs pairing, use it; otherwise auto-detect from enabled channels
  const defaultPairingChannel = pairingChannels.length === 1 ? pairingChannels[0]
    : (feishuHealth.data?.configured && !telegramHealth.data?.configured) ? 'feishu'
    : 'telegram';

  return (
    <div>
      {/* Global Summary Bar */}
      <SummaryBar sections={fullSummary} />

      {/* Guidance: Gateway down or crash-looping */}
      {!gatewayHealth.loading && gatewayDown && (() => {
        return (
          <div className="health-guidance health-guidance-error">
            <div className="health-guidance-content">
              <div className="health-guidance-icon">&#9888;</div>
              <div>
                <div className="health-guidance-title">{crashLoop ? 'Gateway is crash-looping' : 'Gateway is not running'}</div>
                <div className="health-guidance-desc">
                  {configMissing
                    ? <>The gateway is not properly configured — <strong>openclaw.json</strong> was not found. The gateway will be automatically stopped until you finish the gateway configuration and complete reprovisioning. Doctor Fix will not help in this case.</>
                    : crashLoop
                      ? <>The gateway keeps restarting ({gatewayHealth.data?.process?.restartCount} restarts, uptime {Math.floor((gatewayHealth.data?.process?.uptime || 0) / 1000)}s). Click <strong>Doctor Fix</strong> to diagnose and repair automatically.</>
                      : <>The gateway process appears to be down or unhealthy. Click <strong>Doctor Fix</strong> below to diagnose and restart the service automatically.</>
                  }
                </div>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              {configMissing && (
                <button className="btn btn-primary btn-sm" onClick={() => navigate('/setup/config')}>
                  Configuration
                </button>
              )}
              <button className={configMissing ? 'btn btn-secondary btn-sm' : 'btn btn-primary btn-sm'} style={configMissing ? { opacity: 0.5, cursor: 'not-allowed' } : {}} onClick={configMissing ? undefined : handleDoctorFix} disabled={configMissing || doctorFix.loading}>
                {doctorFix.loading ? <><span className="spinner" style={{ width: 13, height: 13, borderWidth: 2 }} /> Fixing...</> : 'Doctor Fix & Restart'}
              </button>
            </div>
          </div>
        );
      })()}

      {/* Guidance: Config validation failed */}
      {!configHealth.loading && configStatus === 'error' && !gatewayDown && (
        <div className="health-guidance health-guidance-error">
          <div className="health-guidance-content">
            <div className="health-guidance-icon">&#9888;</div>
            <div>
              <div className="health-guidance-title">{configMissing ? 'Configuration not found' : 'Configuration is invalid'}</div>
              <div className="health-guidance-desc">
                {configMissing
                  ? <>The gateway configuration file <strong>openclaw.json</strong> was not found. Complete the gateway configuration to get started.</>
                  : <>The OpenClaw configuration has issues that may prevent the gateway from working correctly. Click <strong>Doctor Fix</strong> to diagnose and repair automatically.</>
                }
              </div>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            {configMissing && (
              <button className="btn btn-primary btn-sm" onClick={() => navigate('/setup/config')}>
                Configuration
              </button>
            )}
            <button className={configMissing ? 'btn btn-secondary btn-sm' : 'btn btn-primary btn-sm'} style={configMissing ? { opacity: 0.5, cursor: 'not-allowed' } : {}} onClick={configMissing ? undefined : handleDoctorFix} disabled={configMissing || doctorFix.loading}>
              {doctorFix.loading ? <><span className="spinner" style={{ width: 13, height: 13, borderWidth: 2 }} /> Fixing...</> : 'Doctor Fix'}
            </button>
          </div>
        </div>
      )}

      {/* Guidance: Channel pairing needed */}
      {!telegramHealth.loading && !feishuHealth.loading && needsPairing && (
        <div className="health-guidance health-guidance-info">
          <div className="health-guidance-content" style={{ flex: 1 }}>
            <div className="health-guidance-icon">&#128172;</div>
            <div style={{ flex: 1 }}>
              <div className="health-guidance-title">
                Pair your {pairingChannels.length > 1 ? 'channel' : (defaultPairingChannel === 'feishu' ? (feishuHealth.data?.domain === 'lark' ? 'Lark' : 'Feishu') : 'Telegram')} account
              </div>
              <div className="health-guidance-desc">
                {(() => {
                  const ch = pairingChannel || defaultPairingChannel;
                  const health = ch === 'feishu' ? feishuHealth.data : telegramHealth.data;
                  const requests = health?.pairingRequests || [];
                  if (requests.length > 0) {
                    return <>Pending code{requests.length > 1 ? 's' : ''}: {requests.map((r, j) => (
                      <span key={j}>
                        {j > 0 && ', '}
                        <code style={{ background: 'var(--bg-primary)', padding: '1px 5px', borderRadius: 3, fontSize: '0.82rem', fontWeight: 600 }}>{r.code || r.requestId || r.id || 'unknown'}</code>
                      </span>
                    ))}. Enter below to approve.</>;
                  }
                  if (ch === 'feishu') {
                    return <>Send a message to your {feishuHealth.data?.domain === 'lark' ? 'Lark' : 'Feishu'} bot, then enter the pairing code below.</>;
                  }
                  return <>Open Telegram and send <code>/start</code> to <strong>@{telegramHealth.data?.botUsername || 'your bot'}</strong>, then enter the code below.</>;
                })()}
              </div>
              {pairingChannels.length > 1 && (
                <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginTop: 6, fontSize: '0.82rem' }}>
                  {pairingChannels.map(ch => (
                    <label key={ch} style={{ display: 'flex', alignItems: 'center', gap: 4, cursor: 'pointer', color: 'var(--text-secondary)' }}>
                      <input
                        type="radio"
                        name="pairing-channel-banner"
                        checked={(pairingChannel || defaultPairingChannel) === ch}
                        onChange={() => { setPairingChannel(ch); setPairingApproval({ loading: false, result: null }); }}
                        style={{ margin: 0 }}
                      />
                      {ch === 'feishu' ? (feishuHealth.data?.domain === 'lark' ? 'Lark' : 'Feishu') : 'Telegram'}
                    </label>
                  ))}
                </div>
              )}
              <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginTop: 8 }}>
                <input
                  type="text"
                  className="input"
                  placeholder="Paste pairing code"
                  value={pairingCode}
                  onChange={(e) => setPairingCode(e.target.value)}
                  style={{ flex: 1, maxWidth: 240, fontSize: '0.83rem', padding: '5px 10px' }}
                />
                <button
                  className="btn btn-primary btn-sm"
                  onClick={() => handlePairingApprove(pairingChannel || defaultPairingChannel)}
                  disabled={!pairingCode.trim() || pairingApproval.loading}
                >
                  {pairingApproval.loading ? <><span className="spinner" style={{ width: 13, height: 13, borderWidth: 2 }} /> Approving...</> : 'Approve'}
                </button>
                <button
                  className="btn btn-secondary btn-sm"
                  onClick={() => setPairingDismissed(true)}
                >
                  Dismiss
                </button>
              </div>
              {pairingApproval.result && (
                <div style={{
                  marginTop: 8,
                  padding: '6px 10px',
                  borderRadius: 4,
                  fontSize: '0.8rem',
                  background: pairingApproval.result.ok ? 'var(--badge-success-bg, var(--success-box-bg))' : 'var(--badge-error-bg)',
                  color: pairingApproval.result.ok ? 'var(--badge-success-text, var(--success-box-text))' : 'var(--badge-error-text)',
                  border: `1px solid ${pairingApproval.result.ok ? 'var(--badge-success-text, var(--success-box-border))' : 'var(--badge-error-text)'}`,
                }}>
                  {pairingApproval.result.message}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Quick Actions */}
      <div className="card" style={{ marginBottom: 16, padding: '14px 20px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8 }}>
          <span style={{ fontWeight: 600, fontSize: '0.9rem', color: 'var(--text-primary)' }}>
            Quick Actions
          </span>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
            <button className={configMissing ? 'btn btn-secondary btn-sm' : 'btn btn-primary btn-sm'} onClick={configMissing ? undefined : handleDoctorFix} disabled={configMissing || doctorFix.loading} style={{ display: 'inline-flex', alignItems: 'center', gap: 5, ...(configMissing ? { opacity: 0.5, cursor: 'not-allowed' } : {}) }} title={configMissing ? 'openclaw.json not found — configure the gateway first' : undefined}>
              {doctorFix.loading ? <><span className="spinner" style={{ width: 13, height: 13, borderWidth: 2 }} /> Fixing...</> : <><Stethoscope size={14} /> Doctor Fix</>}
            </button>
            <button className="btn btn-secondary btn-sm" onClick={() => setShowRestart(true)} style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}>
              <ClawIcon size={14} /> Restart Gateway
            </button>
            <button className="btn btn-secondary btn-sm" onClick={() => setShowLauncherRestart(true)} style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}>
              <Rocket size={14} /> Restart Launcher
            </button>
          </div>
        </div>
      </div>

      {/* Health Cards Grid */}
      <div className="health-grid">
        {/* Config Validation Card */}
        <div id="health-config">
          <HealthCard
            title="Config Validation"
            status={configStatus}
            checks={configHealth.data?.checks?.map(c =>
              c.name === 'Config File' && c.ok
                ? { ...c, onClick: handleViewConfig, clickTitle: 'Click to view openclaw.json' }
                : c
            )}
            loading={configHealth.loading}
            error={configHealth.error}
            onRefresh={configHealth.refresh}
            lastChecked={configHealth.lastChecked}
          />
        </div>

        {/* Version & Updates Card */}
        <div id="health-version">
          <HealthCard
            title="Version & Updates"
            status={versionStatus}
            loading={versionHealth.loading}
            error={versionHealth.error}
            onRefresh={versionHealth.refresh}
            lastChecked={versionHealth.lastChecked}
            collapsed={cardCollapsed.version}
            onToggleCollapsed={() => toggleCard('version')}
            hideCollapsedStatus
            collapsedSummary={versionHealth.data && (
              <span style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: '0.78rem', flexWrap: 'wrap' }}>
                <span className="badge badge-sm badge-success">{versionHealth.data.installedVersion || '?'}</span>
                {versionHealth.data.updateAvailable && (
                  <span className={`badge badge-sm ${versionHealth.data.upgradePolicy === 'manual' ? 'badge-info' : 'badge-warning'}`}>
                    {versionHealth.data.upgradePolicy === 'manual' ? '\u2139' : '\u2191'}{' '}
                    {versionHealth.data.github?.latestVersion || versionHealth.data.npm?.latestVersion || versionHealth.data.latestVersion} Available
                  </span>
                )}
                {versionHealth.data.launcher?.version && versionHealth.data.launcher?.uiBuildVersion && versionHealth.data.launcher.version !== versionHealth.data.launcher.uiBuildVersion && (
                  <span className="badge badge-sm badge-warning">UI build outdated</span>
                )}
              </span>
            )}
            actions={
              <button className="btn btn-secondary btn-sm" onClick={handleCheckUpdate} disabled={checkUpdateLoading}>
                {checkUpdateLoading ? <><span className="spinner" style={{ width: 13, height: 13, borderWidth: 2 }} /> Checking...</> : 'Check for Updates'}
              </button>
            }
          >
            {versionHealth.data && (
              <div>
                {/* OpenClaw Version */}
                <div style={{ fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.03em' }}>OpenClaw</div>
                {[
                  {
                    name: 'Installed',
                    ok: !!versionHealth.data.installedVersion,
                    detail: versionHealth.data.installedVersion || 'Not detected',
                  },
                  ...(() => {
                    const npmVer = versionHealth.data.npm?.latestVersion || versionHealth.data.latestVersion;
                    const ghVer = versionHealth.data.github?.latestVersion;
                    if (!npmVer && !ghVer) return [];
                    // Both sources have the same version → single row "Latest: X (npm, github)"
                    if (npmVer && ghVer && npmVer === ghVer) {
                      return [{
                        name: 'Latest',
                        ok: !(versionHealth.data.installedVersion && npmVer !== versionHealth.data.installedVersion),
                        detail: `${npmVer} (npm, github)`,
                      }];
                    }
                    // Different versions or only one source → single row with both shown inline
                    const parts = [];
                    if (npmVer) parts.push(`${npmVer} (npm)`);
                    if (ghVer) parts.push(`${ghVer} (github)`);
                    return [{
                      name: 'Latest',
                      ok: !versionHealth.data.updateAvailable,
                      detail: parts.join(' \u00B7 '),
                    }];
                  })(),
                ].map((check, i, arr) => (
                  <div
                    key={check.name}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      padding: '6px 0',
                      borderBottom: (i < arr.length - 1) ? '1px solid var(--border-primary)' : 'none',
                      fontSize: '0.85rem',
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <span style={{
                        color: check.ok ? 'var(--badge-success-text)' : 'var(--text-muted)',
                        fontSize: '1rem',
                        width: 16,
                        textAlign: 'center',
                      }}>
                        {check.ok ? '\u2713' : '\u2014'}
                      </span>
                      <span style={{ color: 'var(--text-primary)' }}>{check.name}</span>
                    </div>
                    {check.url ? (
                      <a href={check.url} target="_blank" rel="noopener noreferrer" className={`badge ${check.ok ? 'badge-success' : 'badge-info'}`} style={{ textDecoration: 'none' }}>
                        {check.detail}
                      </a>
                    ) : (
                      <span className={`badge ${check.ok ? 'badge-success' : 'badge-info'}`}>
                        {check.detail}
                      </span>
                    )}
                  </div>
                ))}
                {versionHealth.data.updateAvailable && (
                  <>
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        padding: '6px 0',
                        borderTop: '1px solid var(--border-primary)',
                        fontSize: '0.85rem',
                        cursor: 'pointer',
                        userSelect: 'none',
                      }}
                      onClick={() => setUpdateGuideOpen(!updateGuideOpen)}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span style={{ color: 'var(--badge-info-text, var(--text-muted))', fontSize: '1rem', width: 16, textAlign: 'center' }}>{'\u2191'}</span>
                        <span style={{ color: 'var(--text-primary)' }}>OpenClaw Update Available</span>
                        <span style={{ color: 'var(--text-muted)', fontSize: '0.78rem' }}>
                          {updateGuideOpen ? '\u25BE' : '\u25B8'}
                        </span>
                      </div>
                      <span className="badge badge-info">
                        {versionHealth.data.installedVersion} &rarr; {versionHealth.data.github?.latestVersion || versionHealth.data.npm?.latestVersion || versionHealth.data.latestVersion}
                      </span>
                    </div>
                    {updateGuideOpen && (
                      <div style={{
                        marginTop: 6,
                        padding: '10px 12px',
                        background: 'var(--bg-surface-alt)',
                        border: '1px solid var(--border-primary)',
                        borderRadius: 6,
                        fontSize: '0.83rem',
                        color: 'var(--text-secondary)',
                        lineHeight: 1.5,
                      }}>
                        <div style={{ fontWeight: 600, color: 'var(--text-primary)', marginBottom: 6 }}>How to update</div>
                        <div style={{ marginBottom: 6 }}>
                          Reach the <strong>Launchpad dashboard</strong> or use <strong>instclaw controller</strong> to reset the project to update.
                        </div>
                        <div style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>
                          Don't worry, your data will not be lost.
                        </div>
                      </div>
                    )}
                  </>
                )}
                {/* Launcher Version */}
                <div style={{ fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-secondary)', marginTop: 12, marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.03em' }}>Launcher</div>
                {(() => {
                  const l = versionHealth.data.launcher || {};
                  const uiStale = l.version && l.uiBuildVersion && l.version !== l.uiBuildVersion;
                  return [
                    ...(l.version ? [{
                      name: 'Version',
                      ok: true,
                      detail: l.version,
                    }] : [{
                      name: 'Version',
                      ok: false,
                      detail: 'Unknown',
                    }]),
                    ...(l.uiBuildVersion ? [{
                      name: 'UI Build',
                      ok: !uiStale,
                      detail: uiStale ? `${l.uiBuildVersion} (stale)` : l.uiBuildVersion,
                    }] : []),
                    ...(l.buildTime ? [{
                      name: 'Build Time',
                      ok: true,
                      detail: new Date(l.buildTime).toLocaleString(),
                    }] : []),
                  ];
                })().map((check, i, arr) => (
                  <div
                    key={check.name}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      padding: '6px 0',
                      borderBottom: i < arr.length - 1 ? '1px solid var(--border-primary)' : 'none',
                      fontSize: '0.85rem',
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <span style={{
                        color: check.ok ? 'var(--badge-success-text)' : 'var(--text-muted)',
                        fontSize: '1rem',
                        width: 16,
                        textAlign: 'center',
                      }}>
                        {check.ok ? '\u2713' : '\u2014'}
                      </span>
                      <span style={{ color: 'var(--text-primary)' }}>{check.name}</span>
                    </div>
                    <span className={`badge ${check.ok ? 'badge-success' : 'badge-info'}`}>
                      {check.detail}
                    </span>
                  </div>
                ))}
                {versionHealth.data.launcher?.version && versionHealth.data.launcher?.uiBuildVersion && versionHealth.data.launcher.version !== versionHealth.data.launcher.uiBuildVersion && (
                  <div style={{
                    marginTop: 10,
                    padding: '8px 10px',
                    borderRadius: 6,
                    background: 'var(--status-warning-bg, rgba(234, 179, 8, 0.1))',
                    border: '1px solid var(--status-warning-border, rgba(234, 179, 8, 0.3))',
                    fontSize: '0.82rem',
                    color: 'var(--text-primary)',
                    lineHeight: 1.4,
                  }}>
                    <div style={{ fontWeight: 600, marginBottom: 2, color: 'var(--status-warning-text, #eab308)' }}>
                      UI build outdated
                    </div>
                    <div style={{ color: 'var(--text-muted)' }}>
                      Package version is <strong>{versionHealth.data.launcher.version}</strong> but the UI was built with <strong>{versionHealth.data.launcher.uiBuildVersion}</strong>. Run <code style={{ fontSize: '0.8rem', padding: '1px 4px', borderRadius: 3, background: 'var(--bg-tertiary)' }}>npm install</code> and restart the service to sync.
                    </div>
                  </div>
                )}
                {/* Upgrade Policy */}
                <div style={{ fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-secondary)', marginTop: 12, marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.03em' }}>Upgrade Policy</div>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  padding: '6px 0',
                  fontSize: '0.85rem',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ color: 'var(--badge-success-text)', fontSize: '1rem', width: 16, textAlign: 'center' }}>{'\u2713'}</span>
                    <span style={{ color: 'var(--text-primary)' }}>Reinstall behavior</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <span className={`badge ${versionHealth.data.upgradePolicy === 'auto' ? 'badge-success' : 'badge-info'}`}>
                      {versionHealth.data.upgradePolicy === 'auto' ? 'Auto' : 'Manual'}
                    </span>
                    <button
                      className="btn btn-secondary btn-sm"
                      style={{ padding: '2px 8px', fontSize: '0.75rem' }}
                      onClick={handleToggleUpgradePolicy}
                      disabled={upgradePolicyLoading}
                    >
                      {upgradePolicyLoading ? 'Saving...' : (versionHealth.data.upgradePolicy === 'auto' ? 'Switch to Manual' : 'Switch to Auto')}
                    </button>
                  </div>
                </div>
                <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', padding: '2px 0 0 24px' }}>
                  {versionHealth.data.upgradePolicy === 'auto'
                    ? 'Auto: always install latest version on reinstall.'
                    : 'Manual: pin to current version on reinstall.'}
                </div>
                {/* Version Override */}
                <div style={{ marginTop: 10, padding: '8px 0 0 24px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                    <button
                      className="btn btn-secondary btn-sm"
                      style={{ fontSize: '0.75rem' }}
                      onClick={() => {
                        if (!versionOverrideOpen) {
                          const defaultVer = versionHealth.data.persistedVersion || '';
                          setVersionOverrideInput(defaultVer);
                          setVersionOverrideResult(null);
                        }
                        setVersionOverrideOpen(!versionOverrideOpen);
                      }}
                    >
                      Override & Set Manual Version
                    </button>
                    {versionHealth.data.persistedVersion && !versionOverrideOpen && (
                      <span className="badge badge-info" style={{ fontSize: '0.73rem' }}>
                        .installed-version: {versionHealth.data.persistedVersion}
                      </span>
                    )}
                  </div>
                  {versionOverrideOpen && (
                    <div style={{
                      marginTop: 8,
                      padding: '10px 12px',
                      background: 'var(--bg-surface-alt)',
                      border: '1px solid var(--border-primary)',
                      borderRadius: 6,
                    }}>
                      <div style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', marginBottom: 6 }}>
                        Enter the version to pin in <strong>.installed-version</strong>. This will also set the upgrade policy to manual.
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <input
                          type="text"
                          value={versionOverrideInput}
                          onChange={e => setVersionOverrideInput(e.target.value)}
                          placeholder="e.g. 2026.2.28"
                          style={{
                            flex: 1,
                            padding: '4px 8px',
                            fontSize: '0.83rem',
                            border: '1px solid var(--border-primary)',
                            borderRadius: 4,
                            background: 'var(--bg-primary)',
                            color: 'var(--text-primary)',
                            fontFamily: 'inherit',
                          }}
                          onKeyDown={e => { if (e.key === 'Enter' && versionOverrideInput.trim()) handleVersionOverride(); }}
                        />
                        <button
                          className="btn btn-primary btn-sm"
                          style={{ fontSize: '0.75rem', whiteSpace: 'nowrap' }}
                          onClick={handleVersionOverride}
                          disabled={versionOverrideLoading || !versionOverrideInput.trim()}
                        >
                          {versionOverrideLoading ? 'Saving...' : 'Save'}
                        </button>
                      </div>
                      {versionOverrideResult?.ok && (
                        <div style={{
                          marginTop: 8,
                          padding: '8px 10px',
                          background: 'var(--bg-primary)',
                          border: '1px solid var(--badge-success-border, var(--border-primary))',
                          borderRadius: 6,
                          fontSize: '0.8rem',
                          color: 'var(--badge-success-text, var(--text-primary))',
                        }}>
                          Version overridden to <strong>{versionOverrideResult.version}</strong> with manual policy. Please <strong>reset the project in Launchpad</strong> for the change to take effect.
                        </div>
                      )}
                      {versionOverrideResult && !versionOverrideResult.ok && (
                        <div style={{
                          marginTop: 8,
                          padding: '8px 10px',
                          background: 'var(--bg-primary)',
                          border: '1px solid var(--badge-error-border, var(--border-primary))',
                          borderRadius: 6,
                          fontSize: '0.8rem',
                          color: 'var(--badge-error-text, var(--text-primary))',
                        }}>
                          Failed to override version: {versionOverrideResult.error}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            )}
          </HealthCard>
        </div>

        {/* Model Provider & Connectivity Card (includes Agent Test) */}
        <div id="health-models">
          <HealthCard
            title="Models"
            status={modelsStatus}
            loading={modelsHealth.loading}
            error={modelsHealth.error}
            onRefresh={modelsHealth.refresh}
            lastChecked={modelsHealth.lastChecked}
            actions={
              <>
                <button className="btn btn-secondary btn-sm" onClick={() => navigate('/setup/credentials')}>
                  Modify Models
                </button>
                <button className="btn btn-secondary btn-sm" onClick={handleAgentTest} disabled={agentTest.loading}>
                  {agentTest.loading ? <><span className="spinner" style={{ width: 13, height: 13, borderWidth: 2 }} /> Testing...</> : 'Test Agent'}
                </button>
              </>
            }
          >
            {modelsHealth.data && (() => {
              const displayName = (name) => name === 'anthropic' ? 'claude' : name;
              const allProviders = modelsHealth.data.providers;
              if (allProviders.length === 0) {
                return <div style={{ padding: '10px 0', color: 'var(--text-secondary)', fontSize: '0.85rem' }}>No providers configured</div>;
              }
              const enabledProviders = allProviders.filter(p => modelsHealth.data.defaultModel?.startsWith(p.name + '/'));
              const otherProviders = allProviders.filter(p => !modelsHealth.data.defaultModel?.startsWith(p.name + '/'));
              const modelMissing = !modelsHealth.data.defaultModel || !modelsHealth.data.defaultModel.includes('/');

              const renderProvider = (provider, i, arr) => {
                const defaultModelId = modelsHealth.data.defaultModel || '';
                const prefix = provider.name + '/';
                const enabledModelId = defaultModelId.startsWith(prefix) ? defaultModelId.slice(prefix.length) : null;
                const enabledModelKnown = enabledModelId && provider.models.includes(enabledModelId);

                return (
                  <div
                    key={provider.name}
                    style={{
                      padding: '8px 0',
                      borderBottom: i < arr.length - 1 ? '1px solid var(--border-primary)' : 'none',
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: '0.85rem' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span style={{
                          color: provider.reachable ? 'var(--badge-success-text)' : provider.reachable === false ? 'var(--badge-error-text)' : 'var(--text-muted)',
                          fontSize: '1rem',
                          width: 16,
                          textAlign: 'center',
                        }}>
                          {provider.reachable ? '\u2713' : provider.reachable === false ? '\u2717' : '\u2014'}
                        </span>
                        <span style={{ color: 'var(--text-primary)', fontWeight: 500 }}>{displayName(provider.name)}</span>
                        {provider.apiFormat && (
                          <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem', fontWeight: 400 }}>({provider.apiFormat})</span>
                        )}
                      </div>
                      <span className={`badge ${provider.reachable ? 'badge-success' : provider.reachable === false ? 'badge-error' : 'badge-info'}`}>
                        {provider.detail}
                      </span>
                    </div>
                    <div style={{ marginLeft: 24, marginTop: 4, fontSize: '0.8rem', color: 'var(--text-secondary)', display: 'flex', flexDirection: 'column', gap: 2 }}>
                      {provider.baseUrl && (
                        <div style={{ display: 'flex', gap: 6 }}>
                          <span style={{ color: 'var(--text-muted)', minWidth: 60 }}>Endpoint</span>
                          <span style={{ color: 'var(--text-primary)', wordBreak: 'break-all' }}>{provider.baseUrl}</span>
                        </div>
                      )}
                      <div style={{ display: 'flex', gap: 6 }}>
                        <span style={{ color: 'var(--text-muted)', minWidth: 60 }}>Key</span>
                        {provider.keyPrefix
                          ? <code style={{ color: 'var(--text-primary)', fontSize: '0.78rem', background: 'var(--bg-surface-alt)', padding: '0 4px', borderRadius: 3 }}>{provider.keyPrefix}</code>
                          : <span style={{ color: 'var(--badge-error-text, #dc3545)', fontSize: '0.78rem', fontWeight: 500 }}>Not configured</span>
                        }
                      </div>
                      {enabledModelId && (
                        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                          <span style={{ color: 'var(--text-muted)', minWidth: 60 }}>Model</span>
                          <code style={{ fontSize: '0.75rem', background: 'var(--bg-surface-alt)', padding: '1px 5px', borderRadius: 3, color: 'var(--text-primary)' }}>{enabledModelId}</code>
                        </div>
                      )}
                    </div>
                  </div>
                );
              };

              return (
                <div>
                  {modelMissing && (
                    <div style={{
                      padding: '8px 10px',
                      marginBottom: 6,
                      background: 'var(--bg-warning, rgba(255,193,7,0.1))',
                      border: '1px solid var(--border-warning, rgba(255,193,7,0.3))',
                      borderRadius: 6,
                      fontSize: '0.83rem',
                      color: 'var(--text-warning, #b8860b)',
                    }}>
                      No AI model configured — select a model from <span
                        style={{ textDecoration: 'underline', cursor: 'pointer' }}
                        onClick={() => navigate('/setup/credentials')}
                      >Credentials</span> to get started.
                    </div>
                  )}
                  {enabledProviders.map((p, i) => renderProvider(p, i, enabledProviders))}
                  {otherProviders.length > 0 && (
                    <>
                      <div
                        onClick={() => setShowOtherProviders(!showOtherProviders)}
                        style={{
                          padding: '6px 0',
                          fontSize: '0.78rem',
                          color: 'var(--text-muted)',
                          cursor: 'pointer',
                          borderTop: enabledProviders.length > 0 ? '1px solid var(--border-primary)' : 'none',
                          marginTop: enabledProviders.length > 0 ? 4 : 0,
                          userSelect: 'none',
                        }}
                      >
                        {showOtherProviders ? '\u25BE' : '\u25B8'} {otherProviders.length} other configured provider{otherProviders.length > 1 ? 's' : ''}
                      </div>
                      {showOtherProviders && otherProviders.map((p, i) => renderProvider(p, i, otherProviders))}
                    </>
                  )}
                </div>
              );
            })()}
            {/* Agent Test Results (inline) */}
            {(agentTest.loading || agentTest.result) && (
              <div style={{ borderTop: '1px solid var(--border-primary)', marginTop: 10, paddingTop: 10 }}>
                <div style={{ fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.03em' }}>Agent Test</div>
                {agentTest.loading && (
                  <div style={{ padding: '6px 0', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                    Sending test request to model...
                  </div>
                )}
                {agentTest.result && (
                  <div>
                    {[
                      { name: 'Status', ok: agentTest.result.ok, detail: agentTest.result.ok ? 'Responded' : 'Failed' },
                      ...(agentTest.result.provider ? [{ name: 'Model', ok: true, detail: `${agentTest.result.provider}/${agentTest.result.model}` }] : []),
                      ...(agentTest.result.durationMs ? [{ name: 'Latency', ok: true, detail: `${(agentTest.result.durationMs / 1000).toFixed(1)}s` }] : []),
                    ].map((check, i, arr) => (
                      <div
                        key={check.name}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          padding: '6px 0',
                          borderBottom: i < arr.length - 1 ? '1px solid var(--border-primary)' : 'none',
                          fontSize: '0.85rem',
                        }}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                          <span style={{ color: check.ok ? 'var(--badge-success-text)' : 'var(--badge-error-text)', fontSize: '1rem', width: 16, textAlign: 'center' }}>
                            {check.ok ? '\u2713' : '\u2717'}
                          </span>
                          <span style={{ color: 'var(--text-primary)' }}>{check.name}</span>
                        </div>
                        <span className={`badge ${check.ok ? 'badge-success' : 'badge-error'}`}>
                          {check.detail}
                        </span>
                      </div>
                    ))}
                    {agentTest.result.response && (
                      <div style={{ marginTop: 8, padding: '8px 10px', background: 'var(--bg-surface-alt)', border: '1px solid var(--border-primary)', borderRadius: 4, fontSize: '0.82rem', color: 'var(--text-secondary)', wordBreak: 'break-word' }}>
                        <span style={{ fontWeight: 500, color: 'var(--text-primary)' }}>Response: </span>{agentTest.result.response}
                      </div>
                    )}
                    {agentTest.result.error && !agentTest.result.ok && (
                      <div style={{ marginTop: 8, padding: '8px 10px', background: 'var(--badge-error-bg)', border: '1px solid var(--badge-error-text)', borderRadius: 4, fontSize: '0.82rem', color: 'var(--badge-error-text)', wordBreak: 'break-word' }}>
                        {agentTest.result.error}
                      </div>
                    )}
                    {agentTest.result.debug && (
                      <div style={{ marginTop: 8 }}>
                        <button
                          onClick={() => setAgentTestDebugOpen(!agentTestDebugOpen)}
                          style={{
                            background: 'none',
                            border: 'none',
                            color: 'var(--text-muted)',
                            cursor: 'pointer',
                            fontSize: '0.78rem',
                            padding: 0,
                            display: 'flex',
                            alignItems: 'center',
                            gap: 4,
                          }}
                        >
                          <span style={{ fontSize: '0.7rem' }}>{agentTestDebugOpen ? '\u25BE' : '\u25B8'}</span>
                          {agentTestDebugOpen ? 'Hide' : 'Show'} request details
                        </button>
                        {agentTestDebugOpen && (
                          <div style={{ marginTop: 8, padding: '8px 10px', background: 'var(--bg-surface)', border: '1px solid var(--border-primary)', borderRadius: 4, color: 'var(--text-secondary)', fontSize: '0.78rem', fontFamily: 'monospace' }}>
                            <div style={{ marginBottom: 6 }}>
                              <span style={{ fontWeight: 600, color: 'var(--text-primary)' }}>Request URL: </span>
                              {agentTest.result.debug.requestUrl}
                            </div>
                            {agentTest.result.debug.requestHeaders && (
                              <div style={{ marginBottom: 6 }}>
                                <span style={{ fontWeight: 600, color: 'var(--text-primary)' }}>Request Headers:</span>
                                <pre style={{ margin: '4px 0 0', whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}>{JSON.stringify(agentTest.result.debug.requestHeaders, null, 2)}</pre>
                              </div>
                            )}
                            <div style={{ marginBottom: 6 }}>
                              <span style={{ fontWeight: 600, color: 'var(--text-primary)' }}>Request Payload:</span>
                              <pre style={{ margin: '4px 0 0', whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}>{JSON.stringify(agentTest.result.debug.requestBody, null, 2)}</pre>
                            </div>
                            {agentTest.result.debug.responseStatus && (
                              <div style={{ marginBottom: 6 }}>
                                <span style={{ fontWeight: 600, color: 'var(--text-primary)' }}>Response Status: </span>
                                {agentTest.result.debug.responseStatus}
                              </div>
                            )}
                            {agentTest.result.debug.responseBody && (
                              <div>
                                <span style={{ fontWeight: 600, color: 'var(--text-primary)' }}>Response Body:</span>
                                <pre style={{ margin: '4px 0 0', whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}>{agentTest.result.debug.responseBody}</pre>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </HealthCard>
        </div>

        {/* Telegram Channel Card */}
        <div id="health-telegram">
          <HealthCard
            title="Telegram"
            status={telegramStatus}
            loading={telegramHealth.loading}
            error={telegramHealth.error}
            onRefresh={telegramHealth.refresh}
            lastChecked={telegramHealth.lastChecked}
          >
            {telegramHealth.data && (
              !telegramHealth.data.configured ? (
                <div style={{ padding: '10px 0', color: 'var(--text-secondary)', fontSize: '0.85rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <span>Not configured</span>
                  <button className="btn btn-primary btn-sm" onClick={() => navigate('/setup/channels')}>
                    Configure
                  </button>
                </div>
              ) : (
                <div>
                  {[
                    { name: 'Bot Token', ok: telegramHealth.data.botValid, detail: telegramHealth.data.botValid ? 'Valid' : (telegramHealth.data.detail || 'Invalid') },
                    { name: 'Username', ok: !!telegramHealth.data.botUsername, detail: telegramHealth.data.botUsername ? `@${telegramHealth.data.botUsername}` : 'Unknown' },
                    { name: 'Plugin', ok: telegramHealth.data.pluginEnabled, detail: telegramHealth.data.pluginEnabled ? 'Enabled' : 'Disabled' },
                  ].map((check, i, arr) => (
                    <div
                      key={check.name}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        padding: '6px 0',
                        borderBottom: (telegramHealth.data.dmPolicy === 'pairing' || i < arr.length - 1) ? '1px solid var(--border-primary)' : 'none',
                        fontSize: '0.85rem',
                      }}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span style={{ color: check.ok ? 'var(--badge-success-text)' : 'var(--badge-error-text)', fontSize: '1rem', width: 16, textAlign: 'center' }}>
                          {check.ok ? '\u2713' : '\u2717'}
                        </span>
                        <span style={{ color: 'var(--text-primary)' }}>{check.name}</span>
                      </div>
                      <span className={`badge ${check.ok ? 'badge-success' : 'badge-warning'}`}>
                        {check.detail}
                      </span>
                    </div>
                  ))}
                  {/* Pairing row — clickable to toggle pairing form */}
                  {telegramHealth.data.dmPolicy === 'pairing' && (() => {
                    const hasPaired = telegramHealth.data?.paired || telegramHealth.data?.launcherPairingDone;
                    const isPaired = hasPaired || pairingDone;
                    const isDismissed = pairingDismissed && !isPaired;
                    const hasPending = telegramHealth.data.pairingRequests?.length > 0;
                    const pairingCount = telegramHealth.data.pairedCount || 0;

                    // Determine icon, color, badge style and text
                    let icon, iconColor, badgeClass, badgeText;
                    if (isPaired) {
                      icon = '\u2713';
                      iconColor = 'var(--badge-success-text)';
                      badgeClass = 'badge-success';
                      badgeText = hasPaired
                        ? `${pairingCount} user${pairingCount !== 1 ? 's' : ''} paired`
                        : 'Paired via launcher';
                    } else if (isDismissed) {
                      icon = '\u2014';
                      iconColor = 'var(--text-muted)';
                      badgeClass = 'badge-info';
                      badgeText = 'Ignored';
                    } else if (hasPending) {
                      icon = '\u2717';
                      iconColor = 'var(--badge-warning-text)';
                      badgeClass = 'badge-warning';
                      badgeText = 'Pending approval';
                    } else {
                      icon = '\u2717';
                      iconColor = 'var(--badge-error-text)';
                      badgeClass = 'badge-warning';
                      badgeText = 'No users paired';
                    }

                    const canToggle = telegramHealth.data.botValid;

                    return (
                      <>
                        <div
                          onClick={canToggle ? () => setShowPairingForm(!showPairingForm) : undefined}
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            padding: '6px 0',
                            fontSize: '0.85rem',
                            cursor: canToggle ? 'pointer' : 'default',
                            userSelect: 'none',
                          }}
                        >
                          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                            <span style={{ color: iconColor, fontSize: '1rem', width: 16, textAlign: 'center' }}>
                              {icon}
                            </span>
                            <span style={{ color: 'var(--text-primary)' }}>Pairing</span>
                          </div>
                          <span className={`badge ${badgeClass}`} style={{ cursor: canToggle ? 'pointer' : 'default' }}>
                            {badgeText}
                          </span>
                        </div>
                        {/* Paired users detail */}
                        {isPaired && telegramHealth.data.pairedDetails?.length > 0 && showPairingForm && (
                          <div style={{
                            marginTop: 4,
                            padding: '8px 10px',
                            background: 'var(--bg-surface-alt)',
                            border: '1px solid var(--border-primary)',
                            borderRadius: 6,
                            fontSize: '0.8rem',
                          }}>
                            <div style={{ fontWeight: 600, color: 'var(--text-primary)', marginBottom: 6, fontSize: '0.78rem' }}>
                              Paired Users
                            </div>
                            {telegramHealth.data.pairedDetails.map((u, j) => (
                              <div
                                key={u.userId}
                                style={{
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'space-between',
                                  padding: '4px 0',
                                  borderBottom: j < telegramHealth.data.pairedDetails.length - 1 ? '1px solid var(--border-primary)' : 'none',
                                  color: 'var(--text-secondary)',
                                }}
                              >
                                <span style={{ display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
                                  <span style={{ color: 'var(--badge-success-text)', fontSize: '0.85rem' }}>{'\u2713'}</span>
                                  <span>{u.name || `User ${u.userId}`}</span>
                                  {u.username && (
                                    <span style={{ color: 'var(--text-tertiary)', fontSize: '0.75rem' }}>@{u.username}</span>
                                  )}
                                  <code style={{ background: 'var(--bg-primary)', padding: '1px 5px', borderRadius: 3, fontSize: '0.75rem', color: 'var(--text-tertiary)' }}>
                                    ID: {u.userId}{u.sources?.length > 0 ? ` (${u.sources.join(', ')})` : ''}
                                  </code>
                                </span>
                                <span style={{ color: 'var(--text-tertiary)', fontSize: '0.75rem' }}>
                                  {u.approvedAt ? new Date(u.approvedAt).toLocaleDateString() : ''}
                                </span>
                              </div>
                            ))}
                          </div>
                        )}
                        {/* Pairing form — shown on click */}
                        {showPairingForm && canToggle && (
                          <div style={{
                            marginTop: 8,
                            padding: '12px',
                            background: 'var(--bg-surface-alt)',
                            border: '1px solid var(--border-primary)',
                            borderRadius: 6,
                          }}>
                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
                              <span style={{ fontWeight: 600, color: 'var(--text-primary)', fontSize: '0.83rem' }}>
                                {isPaired ? 'Pair Another User' : 'Pair Telegram User'}
                              </span>
                              {!isPaired && !isDismissed && (
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setPairingDismissed(true);
                                    setShowPairingForm(false);
                                  }}
                                  title="Dismiss"
                                  style={{
                                    background: 'none',
                                    border: 'none',
                                    color: 'var(--text-muted)',
                                    cursor: 'pointer',
                                    fontSize: '0.78rem',
                                    padding: '2px 6px',
                                  }}
                                >
                                  Dismiss
                                </button>
                              )}
                            </div>
                            <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', lineHeight: 1.5, marginBottom: 10 }}>
                              {telegramHealth.data.pairingRequests?.length > 0 ? (
                                <p style={{ margin: '0 0 6px' }}>
                                  A user has sent <code style={{ background: 'var(--bg-primary)', padding: '1px 5px', borderRadius: 3, fontSize: '0.78rem' }}>/start</code> to
                                  your bot. Approve the pairing code below to allow them to chat.
                                </p>
                              ) : (
                                <ol style={{ paddingLeft: 18, margin: 0 }}>
                                  <li>Open Telegram and chat with <strong>@{telegramHealth.data.botUsername}</strong></li>
                                  <li>Send <code style={{ background: 'var(--bg-primary)', padding: '1px 5px', borderRadius: 3, fontSize: '0.78rem' }}>/start</code> to the bot</li>
                                  <li>Paste the pairing code below and click Approve</li>
                                </ol>
                              )}
                            </div>
                            {telegramHealth.data.pairingRequests?.length > 0 && (
                              <div style={{ marginBottom: 8, fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                                <span style={{ fontWeight: 500, color: 'var(--text-primary)' }}>Pending requests:</span>{' '}
                                {telegramHealth.data.pairingRequests.map((r, j) => (
                                  <span key={j}>
                                    {j > 0 && ', '}
                                    <code style={{ background: 'var(--bg-primary)', padding: '1px 5px', borderRadius: 3, fontSize: '0.78rem' }}>
                                      {r.code || r.requestId || r.id || 'unknown'}
                                    </code>
                                    {r.userId && <span style={{ color: 'var(--text-muted)' }}> (user {r.userId})</span>}
                                  </span>
                                ))}
                              </div>
                            )}
                            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                              <input
                                type="text"
                                className="input"
                                placeholder="Paste pairing code (e.g. ZEB27Q3M)"
                                value={pairingCode}
                                onChange={(e) => setPairingCode(e.target.value)}
                                onClick={(e) => e.stopPropagation()}
                                style={{ flex: 1, fontSize: '0.83rem', padding: '6px 10px' }}
                              />
                              <button
                                className="btn btn-primary btn-sm"
                                onClick={(e) => { e.stopPropagation(); handlePairingApprove('telegram'); }}
                                disabled={!pairingCode.trim() || pairingApproval.loading}
                              >
                                {pairingApproval.loading ? <><span className="spinner" style={{ width: 13, height: 13, borderWidth: 2 }} /> Approving...</> : 'Approve'}
                              </button>
                            </div>
                            {pairingApproval.result && (
                              <div style={{
                                marginTop: 8,
                                padding: '6px 10px',
                                borderRadius: 4,
                                fontSize: '0.8rem',
                                background: pairingApproval.result.ok ? 'var(--badge-success-bg, var(--success-box-bg))' : 'var(--badge-error-bg)',
                                color: pairingApproval.result.ok ? 'var(--badge-success-text, var(--success-box-text))' : 'var(--badge-error-text)',
                                border: `1px solid ${pairingApproval.result.ok ? 'var(--badge-success-text, var(--success-box-border))' : 'var(--badge-error-text)'}`,
                              }}>
                                {pairingApproval.result.message}
                              </div>
                            )}
                          </div>
                        )}
                      </>
                    );
                  })()}
                </div>
              )
            )}
          </HealthCard>
        </div>

        {/* Feishu / Lark Channel Card — shown when Feishu is configured */}
        {feishuHealth.data?.configured && (
          <div id="health-feishu">
            <HealthCard
              title={feishuHealth.data?.domain === 'lark' ? 'Lark' : 'Feishu'}
              status={feishuStatus}
              loading={feishuHealth.loading}
              error={feishuHealth.error}
              onRefresh={feishuHealth.refresh}
              lastChecked={feishuHealth.lastChecked}
            >
              {feishuHealth.data && (
                <div>
                  {[
                    { name: 'Credentials', ok: feishuHealth.data.credentialsValid, detail: feishuHealth.data.credentialsValid ? 'Valid' : (feishuHealth.data.detail || 'Invalid') },
                    { name: 'Bot Name', ok: !!feishuHealth.data.botName, detail: feishuHealth.data.botName || 'Unknown' },
                    { name: 'Plugin', ok: feishuHealth.data.pluginEnabled, detail: feishuHealth.data.pluginEnabled ? 'Enabled' : 'Disabled' },
                    { name: 'Connection', ok: true, detail: feishuHealth.data.connectionMode === 'websocket' ? 'WebSocket' : 'Webhook' },
                    { name: 'Platform', ok: true, detail: feishuHealth.data.domain === 'lark' ? 'Lark (International)' : 'Feishu (China)' },
                  ].map((check, i, arr) => (
                    <div
                      key={check.name}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        padding: '6px 0',
                        borderBottom: (feishuHealth.data.credentialsValid || i < arr.length - 1) ? '1px solid var(--border-primary)' : 'none',
                        fontSize: '0.85rem',
                      }}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span style={{ color: check.ok ? 'var(--badge-success-text)' : 'var(--badge-error-text)', fontSize: '1rem', width: 16, textAlign: 'center' }}>
                          {check.ok ? '\u2713' : '\u2717'}
                        </span>
                        <span style={{ color: 'var(--text-primary)' }}>{check.name}</span>
                      </div>
                      <span className={`badge ${check.ok ? 'badge-success' : 'badge-warning'}`}>
                        {check.detail}
                      </span>
                    </div>
                  ))}
                  {/* Feishu Pairing row */}
                  {feishuHealth.data.credentialsValid && (() => {
                    const hasPaired = feishuHealth.data?.paired || feishuHealth.data?.launcherPairingDone;
                    const isPaired = hasPaired || (pairingDone && pairingChannel === 'feishu');
                    const isDismissed = pairingDismissed && !isPaired;
                    const hasPending = feishuHealth.data.pairingRequests?.length > 0;
                    const fpCount = feishuHealth.data.pairedCount || 0;

                    let icon, iconColor, badgeClass, badgeText;
                    if (isPaired) {
                      icon = '\u2713'; iconColor = 'var(--badge-success-text)'; badgeClass = 'badge-success';
                      badgeText = hasPaired ? `${fpCount} user${fpCount !== 1 ? 's' : ''} paired` : 'Paired via launcher';
                    } else if (isDismissed) {
                      icon = '\u2014'; iconColor = 'var(--text-muted)'; badgeClass = 'badge-info'; badgeText = 'Ignored';
                    } else if (hasPending) {
                      icon = '\u2717'; iconColor = 'var(--badge-warning-text)'; badgeClass = 'badge-warning'; badgeText = 'Pending approval';
                    } else {
                      icon = '\u2717'; iconColor = 'var(--badge-error-text)'; badgeClass = 'badge-warning'; badgeText = 'No users paired';
                    }

                    const canToggle = feishuHealth.data.credentialsValid;
                    const platformLabel = feishuHealth.data.domain === 'lark' ? 'Lark' : 'Feishu';

                    return (
                      <>
                        <div
                          onClick={canToggle ? () => setShowPairingForm(!showPairingForm) : undefined}
                          style={{
                            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                            padding: '6px 0', fontSize: '0.85rem',
                            cursor: canToggle ? 'pointer' : 'default', userSelect: 'none',
                          }}
                        >
                          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                            <span style={{ color: iconColor, fontSize: '1rem', width: 16, textAlign: 'center' }}>{icon}</span>
                            <span style={{ color: 'var(--text-primary)' }}>Pairing</span>
                          </div>
                          <span className={`badge ${badgeClass}`} style={{ cursor: canToggle ? 'pointer' : 'default' }}>{badgeText}</span>
                        </div>
                        {showPairingForm && canToggle && (
                          <div style={{
                            marginTop: 8, padding: '12px',
                            background: 'var(--bg-surface-alt)', border: '1px solid var(--border-primary)', borderRadius: 6,
                          }}>
                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
                              <span style={{ fontWeight: 600, color: 'var(--text-primary)', fontSize: '0.83rem' }}>
                                {isPaired ? 'Pair Another User' : `Pair ${platformLabel} User`}
                              </span>
                              {!isPaired && !isDismissed && (
                                <button onClick={(e) => { e.stopPropagation(); setPairingDismissed(true); setShowPairingForm(false); }}
                                  title="Dismiss" style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', fontSize: '0.78rem', padding: '2px 6px' }}>
                                  Dismiss
                                </button>
                              )}
                            </div>
                            <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', lineHeight: 1.5, marginBottom: 10 }}>
                              {hasPending ? (
                                <p style={{ margin: '0 0 6px' }}>A user has messaged your {platformLabel} bot. Approve the pairing code below to allow them to chat.</p>
                              ) : (
                                <ol style={{ paddingLeft: 18, margin: 0 }}>
                                  <li>Open {platformLabel} and chat with your bot{feishuHealth.data.botName ? ` (${feishuHealth.data.botName})` : ''}</li>
                                  <li>Send a message to the bot to initiate pairing</li>
                                  <li>Paste the pairing code below and click Approve</li>
                                </ol>
                              )}
                            </div>
                            {hasPending && (
                              <div style={{ marginBottom: 8, fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                                <span style={{ fontWeight: 500, color: 'var(--text-primary)' }}>Pending requests:</span>{' '}
                                {feishuHealth.data.pairingRequests.map((r, j) => (
                                  <span key={j}>
                                    {j > 0 && ', '}
                                    <code style={{ background: 'var(--bg-primary)', padding: '1px 5px', borderRadius: 3, fontSize: '0.78rem' }}>
                                      {r.code || r.requestId || r.id || 'unknown'}
                                    </code>
                                  </span>
                                ))}
                              </div>
                            )}
                            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                              <input type="text" className="input" placeholder="Paste pairing code"
                                value={pairingCode} onChange={(e) => setPairingCode(e.target.value)}
                                onClick={(e) => e.stopPropagation()}
                                style={{ flex: 1, fontSize: '0.83rem', padding: '6px 10px' }} />
                              <button className="btn btn-primary btn-sm"
                                onClick={(e) => { e.stopPropagation(); handlePairingApprove('feishu'); }}
                                disabled={!pairingCode.trim() || pairingApproval.loading}>
                                {pairingApproval.loading ? <><span className="spinner" style={{ width: 13, height: 13, borderWidth: 2 }} /> Approving...</> : 'Approve'}
                              </button>
                            </div>
                            {pairingApproval.result && (
                              <div style={{
                                marginTop: 8, padding: '6px 10px', borderRadius: 4, fontSize: '0.8rem',
                                background: pairingApproval.result.ok ? 'var(--badge-success-bg, var(--success-box-bg))' : 'var(--badge-error-bg)',
                                color: pairingApproval.result.ok ? 'var(--badge-success-text, var(--success-box-text))' : 'var(--badge-error-text)',
                                border: `1px solid ${pairingApproval.result.ok ? 'var(--badge-success-text, var(--success-box-border))' : 'var(--badge-error-text)'}`,
                              }}>
                                {pairingApproval.result.message}
                              </div>
                            )}
                          </div>
                        )}
                      </>
                    );
                  })()}
                </div>
              )}
            </HealthCard>
          </div>
        )}

        {/* Connectivity & Security Card */}
        <div id="health-connectivity">
          <HealthCard
            title="Connectivity & Security"
            status={connectivityStatus}
            loading={gatewayHealth.loading}
            error={gatewayHealth.error}
            onRefresh={gatewayHealth.refresh}
            lastChecked={gatewayHealth.lastChecked}
          >
            {gatewayHealth.data && (
              <div>
                {[
                  { name: 'Port Reachable', ok: gatewayHealth.data?.probe?.reachable, detail: gatewayHealth.data?.probe?.reachable ? 'Live' : 'Offline' },
                  ...(gatewayHealth.data?.security ? [
                    {
                      name: 'Gateway Token',
                      ok: gatewayHealth.data.security.token?.strength === 'strong',
                      detail: gatewayHealth.data.security.token?.strength === 'strong'
                        ? 'Strong'
                        : gatewayHealth.data.security.token?.warning || gatewayHealth.data.security.token?.strength || 'Unknown',
                    },
                    {
                      name: 'Token Sync',
                      ok: gatewayHealth.data.security.tokenSync?.synced,
                      detail: (() => {
                        const tokenSync = gatewayHealth.data.security.tokenSync;
                        if (tokenSync?.synced) return 'In sync';
                        if (tokenSync?.reason === 'no_running_token') return 'Gateway not running';
                        if (tokenSync?.reason === 'token_mismatch') return 'Config/running mismatch';
                        if (tokenSync?.reason === 'no_config_token') return 'No token configured';
                        return 'Not synced';
                      })(),
                    },
                  ] : []),
                ].map((check, i, arr) => (
                  <div
                    key={check.name}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      padding: '6px 0',
                      borderBottom: i < arr.length - 1 ? '1px solid var(--border-primary)' : 'none',
                      fontSize: '0.85rem',
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <span style={{ color: check.ok ? 'var(--badge-success-text)' : 'var(--badge-error-text)', fontSize: '1rem', width: 16, textAlign: 'center' }}>
                        {check.ok ? '\u2713' : '\u2717'}
                      </span>
                      <span style={{ color: 'var(--text-primary)' }}>{check.name}</span>
                    </div>
                    <span className={`badge ${check.ok ? 'badge-success' : 'badge-warning'}`}>
                      {check.detail}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </HealthCard>
        </div>

        {/* Gateway Service Card */}
        <div id="health-gateway">
          <HealthCard
            title="Gateway Service"
            status={gatewayStatus}
            loading={gatewayHealth.loading}
            error={gatewayHealth.error}
            onRefresh={gatewayHealth.refresh}
            lastChecked={gatewayHealth.lastChecked}
            actions={
              logsHealth.data?.found ? (
                <button className="btn btn-secondary btn-sm" onClick={handleViewLogs} disabled={logTail.loading}>
                  {logTail.loading ? <><span className="spinner" style={{ width: 13, height: 13, borderWidth: 2 }} /> Loading...</> : logTail.visible ? 'Hide Logs' : 'View Logs'}
                </button>
              ) : null
            }
          >
            {gatewayHealth.data && (() => {
              const mgmt = gatewayHealth.data.management;
              return (
                <div>
                  {/* Unmanaged daemon warning */}
                  {mgmt?.unmanagedDaemon && (
                    <div style={{
                      background: 'var(--badge-warning-bg, #fff3cd)',
                      border: '1px solid var(--badge-warning-text, #856404)',
                      borderRadius: 6,
                      padding: '10px 12px',
                      marginBottom: 12,
                      fontSize: '0.82rem',
                      color: 'var(--badge-warning-text, #856404)',
                      lineHeight: 1.5,
                    }}>
                      <strong>Gateway running outside PM2</strong> (PID {mgmt.portPid})
                      <div style={{ marginTop: 4, fontSize: '0.8rem' }}>
                        The gateway may have auto-restarted as a standalone daemon. The launcher cannot manage this process.
                        A <strong>container environment reset</strong> is needed to restore PM2 management.
                      </div>
                    </div>
                  )}
                  {/* Unsafe reload mode warning */}
                  {gatewayHealth.data.reloadMode && gatewayHealth.data.reloadMode !== 'hot' && gatewayHealth.data.reloadMode !== 'off' && (
                    <div style={{
                      background: 'var(--badge-warning-bg, #fff3cd)',
                      border: '1px solid var(--badge-warning-text, #856404)',
                      borderRadius: 6,
                      padding: '10px 12px',
                      marginBottom: 12,
                      fontSize: '0.82rem',
                      color: 'var(--badge-warning-text, #856404)',
                      lineHeight: 1.5,
                    }}>
                      <strong>Reload mode "{gatewayHealth.data.reloadMode}" may cause issues</strong>
                      <div style={{ marginTop: 4, fontSize: '0.8rem' }}>
                        Modes like <strong>hybrid</strong> or <strong>restart</strong> can cause the gateway to auto-restart as a standalone daemon outside PM2, breaking process management. Use <strong>hot</strong> or <strong>off</strong> instead.
                      </div>
                    </div>
                  )}
                  {/* Crash-loop warning */}
                  {crashLoop && (() => {
                    return (
                      <div style={{
                        background: 'var(--badge-error-bg, rgba(248, 113, 113, 0.08))',
                        border: '1px solid var(--badge-error-text, #f87171)',
                        borderRadius: 6,
                        padding: '10px 12px',
                        marginBottom: 12,
                        fontSize: '0.82rem',
                        color: 'var(--badge-error-text, #f87171)',
                        lineHeight: 1.5,
                      }}>
                        <strong>Gateway crash loop detected</strong>
                        <div style={{ marginTop: 4, fontSize: '0.8rem' }}>
                          {configMissing
                            ? <>The gateway is not properly configured — <strong>openclaw.json</strong> was not found. The gateway will be automatically stopped until you finish the gateway configuration and complete reprovisioning. Doctor Fix will not help in this case.</>
                            : <>The gateway keeps restarting ({gatewayHealth.data.process.restartCount} restarts, uptime {Math.floor((gatewayHealth.data.process.uptime || 0) / 1000)}s).
                              Configuration may have issues — run <strong>Doctor Fix</strong> to diagnose and repair automatically.</>
                          }
                        </div>
                      </div>
                    );
                  })()}
                  {/* PM2 restart-needed notice */}
                  {mgmt?.restartNeeded && !mgmt?.unmanagedDaemon && (
                    <div style={{
                      background: 'var(--info-box-bg)',
                      border: '1px solid var(--info-box-border)',
                      borderRadius: 6,
                      padding: '10px 12px',
                      marginBottom: 12,
                      fontSize: '0.82rem',
                      color: 'var(--text-secondary)',
                      lineHeight: 1.5,
                    }}>
                      The gateway may need a restart to pick up recent config changes (hot-reload mode).
                    </div>
                  )}
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 16 }}>
                    {/* Process info */}
                    <div>
                      <div style={{ fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.03em' }}>Process</div>
                      {gatewayHealth.data.process ? (
                        <>
                          {[
                            ['Status', gatewayHealth.data.process.status || 'unknown'],
                            ['PM2 Managed', mgmt?.managed ? 'Yes' : 'No'],
                            ...(!mgmt?.managed ? [
                              ['PID (PM2)', gatewayHealth.data.process.pid || 'N/A'],
                              ...(mgmt?.portPid && mgmt.portPid !== gatewayHealth.data.process.pid
                                ? [['PID (Port)', String(mgmt.portPid)]]
                                : []),
                            ] : []),
                            ...(gatewayHealth.data.reloadMode && gatewayHealth.data.reloadMode !== 'hot'
                              ? [['Reload Mode', gatewayHealth.data.reloadMode]]
                              : []),
                            ['Uptime', formatUptime(gatewayHealth.data.process.uptime)],
                          ].map(([label, value], i, arr) => (
                            <div key={label} style={{
                              display: 'flex',
                              justifyContent: 'space-between',
                              padding: '5px 0',
                              borderBottom: i < arr.length - 1 ? '1px solid var(--border-primary)' : 'none',
                              fontSize: '0.85rem',
                            }}>
                              <span style={{ color: 'var(--text-secondary)' }}>{label}</span>
                              <span style={{
                                color: label === 'PM2 Managed' && value === 'No'
                                  ? 'var(--badge-warning-text)'
                                  : label === 'Reload Mode' && value !== 'hot' && value !== 'off'
                                    ? 'var(--badge-warning-text)'
                                    : 'var(--text-primary)',
                                fontWeight: 500,
                              }}>{value}</span>
                            </div>
                          ))}
                        </>
                      ) : mgmt?.portPid ? (
                        <>
                          {[
                            ['PID (Port)', String(mgmt.portPid)],
                            ['PM2 Managed', 'No'],
                          ].map(([label, value], i, arr) => (
                            <div key={label} style={{
                              display: 'flex',
                              justifyContent: 'space-between',
                              padding: '5px 0',
                              borderBottom: i < arr.length - 1 ? '1px solid var(--border-primary)' : 'none',
                              fontSize: '0.85rem',
                            }}>
                              <span style={{ color: 'var(--text-secondary)' }}>{label}</span>
                              <span style={{ color: 'var(--badge-warning-text)', fontWeight: 500 }}>{value}</span>
                            </div>
                          ))}
                        </>
                      ) : (
                        <div style={{ padding: '8px 0', color: 'var(--text-muted)', fontSize: '0.85rem' }}>No PM2 process found</div>
                      )}
                    </div>

                    {/* Resources */}
                    {gatewayHealth.data.process && (
                      <div>
                        <div style={{ fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.03em' }}>Resources</div>
                        {[
                          ['Memory', formatBytes(gatewayHealth.data.process.memory)],
                          ['CPU', gatewayHealth.data.process.cpu !== undefined ? `${gatewayHealth.data.process.cpu}%` : 'N/A'],
                          ['Restarts', gatewayHealth.data.process.restartCount ?? 'N/A'],
                        ].map(([label, value], i, arr) => (
                          <div key={label} style={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            padding: '5px 0',
                            borderBottom: i < arr.length - 1 ? '1px solid var(--border-primary)' : 'none',
                            fontSize: '0.85rem',
                          }}>
                            <span style={{ color: 'var(--text-secondary)' }}>{label}</span>
                            <span style={{ color: 'var(--text-primary)', fontWeight: 500 }}>{value}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Logs section */}
                  {logsHealth.data?.found && (
                    <div style={{ marginTop: 12, borderTop: '1px solid var(--border-primary)', paddingTop: 10 }}>
                      <div style={{ fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.03em' }}>Logs</div>
                      {[
                        { label: 'Output', count: logsHealth.data.outLines },
                        { label: 'Errors', count: logsHealth.data.errLines },
                      ].map((item, i, arr) => (
                        <div key={item.label} style={{
                          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                          padding: '5px 0',
                          borderBottom: i < arr.length - 1 ? '1px solid var(--border-primary)' : 'none',
                          fontSize: '0.85rem',
                        }}>
                          <span style={{ color: 'var(--text-secondary)' }}>{item.label}</span>
                          <span className={`badge ${item.count > 0 ? (item.label === 'Errors' ? 'badge-warning' : 'badge-info') : 'badge-info'}`}>
                            {item.count} lines
                          </span>
                        </div>
                      ))}
                      {logTail.visible && logTail.data && !logTail.data.error && (
                        <div style={{ marginTop: 8 }}>
                          {logTail.data.errTail?.length > 0 && (
                            <div style={{ marginBottom: 8 }}>
                              <div style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--badge-error-text)', marginBottom: 4, textTransform: 'uppercase', letterSpacing: '0.03em' }}>Errors (last {logTail.data.errTail.length})</div>
                              <pre style={{ margin: 0, padding: '8px 10px', background: 'var(--bg-surface-alt)', border: '1px solid var(--border-primary)', borderRadius: 4, fontSize: '0.75rem', color: 'var(--badge-error-text)', overflowX: 'auto', maxHeight: 200, whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}>
                                {logTail.data.errTail.join('\n')}
                              </pre>
                            </div>
                          )}
                          {logTail.data.outTail?.length > 0 && (
                            <div>
                              <div style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 4, textTransform: 'uppercase', letterSpacing: '0.03em' }}>Output (last {logTail.data.outTail.length})</div>
                              <pre style={{ margin: 0, padding: '8px 10px', background: 'var(--bg-surface-alt)', border: '1px solid var(--border-primary)', borderRadius: 4, fontSize: '0.75rem', color: 'var(--text-secondary)', overflowX: 'auto', maxHeight: 200, whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}>
                                {logTail.data.outTail.join('\n')}
                              </pre>
                            </div>
                          )}
                          {(!logTail.data.outTail?.length && !logTail.data.errTail?.length) && (
                            <div style={{ padding: '6px 0', color: 'var(--text-muted)', fontSize: '0.85rem' }}>No log entries</div>
                          )}
                        </div>
                      )}
                      {logTail.visible && logTail.data?.error && (
                        <div style={{ marginTop: 8, padding: '8px 10px', background: 'var(--badge-error-bg)', border: '1px solid var(--badge-error-text)', borderRadius: 4, fontSize: '0.82rem', color: 'var(--badge-error-text)' }}>
                          {logTail.data.error}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })()}
          </HealthCard>
        </div>

        {/* Zombie Processes Card — only shown when zombies are detected */}
        {gatewayHealth.data?.zombies?.found && (
          <div id="health-zombies">
            <HealthCard
              title="Zombie Processes"
              status={zombieStatus}
              loading={gatewayHealth.loading}
              error={gatewayHealth.error}
              onRefresh={gatewayHealth.refresh}
              lastChecked={gatewayHealth.lastChecked}
            >
              <div>
                <div style={{
                  background: 'var(--badge-warning-bg, #fff3cd)',
                  border: '1px solid var(--badge-warning-text, #856404)',
                  borderRadius: 6,
                  padding: '10px 12px',
                  marginBottom: 12,
                  fontSize: '0.82rem',
                  color: 'var(--badge-warning-text, #856404)',
                  lineHeight: 1.5,
                }}>
                  <strong>Zombie processes detected</strong>
                  <div style={{ marginTop: 4, fontSize: '0.8rem' }}>
                    OpenClaw gateway may have a subprocess management bug. This might be due to a known issue in the current OpenClaw version.
                    Consider <strong>upgrading OpenClaw</strong> to the latest version, or performing a <strong>complete environment reset</strong> to clean up the zombie processes.
                  </div>
                </div>
                {(() => {
                  const allZombies = gatewayHealth.data.zombies.zombies;
                  const total = allZombies.length;
                  const showAll = total <= 5;
                  const displayed = showAll ? allZombies : allZombies.slice(0, 3);
                  return (
                    <>
                      {displayed.map((z, i) => (
                        <div
                          key={i}
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            padding: '6px 0',
                            borderBottom: (showAll ? i < total - 1 : true) ? '1px solid var(--border-primary)' : 'none',
                            fontSize: '0.85rem',
                          }}
                        >
                          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                            <span style={{ color: 'var(--badge-warning-text)', fontSize: '1rem', width: 16, textAlign: 'center' }}>&#x26A0;</span>
                            <span style={{ color: 'var(--text-primary)', fontFamily: "'Cascadia Code', 'Fira Code', 'JetBrains Mono', monospace", fontSize: '0.8rem' }}>
                              PID {z.pid}{z.ppid ? ` (PPID ${z.ppid})` : ''}
                            </span>
                          </div>
                          <span className="badge badge-warning" style={{ maxWidth: 220, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            {z.command}
                          </span>
                        </div>
                      ))}
                      {!showAll && (
                        <div style={{ padding: '8px 0 2px', fontSize: '0.82rem', color: 'var(--text-secondary)' }}>
                          ...and {total - 3} more — <strong>{total} zombie processes</strong> total
                        </div>
                      )}
                    </>
                  );
                })()}
              </div>
            </HealthCard>
          </div>
        )}

        {/* Environment Resource Utilization */}
        <div id="health-resources">
          <HealthCard
            title="Resource Utilization"
            status={(() => {
              const rs = resourceStats.data;
              if (!rs) return null;
              const windows = [rs?.last1m, rs?.last5m, rs?.last30m];
              const highMem = windows.some(w => w?.memory?.avgPercent >= 85);
              const highCpu = windows.some(w => w?.cpu?.avgPercent >= 85);
              return highMem || highCpu ? 'warn' : 'ok';
            })()}
            statusLabel={(() => {
              const rs = resourceStats.data;
              if (!rs) return null;
              const windows = [rs?.last1m, rs?.last5m, rs?.last30m];
              const highMem = windows.some(w => w?.memory?.avgPercent >= 85);
              const highCpu = windows.some(w => w?.cpu?.avgPercent >= 85);
              return highMem || highCpu ? 'High' : null;
            })()}
            loading={resourceStats.loading && !resourceStats.data}
            onRefresh={fetchResourceStats}
          >
            {resourceStats.data && (() => {
              const rs = resourceStats.data;
              const latest = rs.latest;
              const windows = [
                { label: '1m', data: rs.last1m },
                { label: '5m', data: rs.last5m },
                { label: '30m', data: rs.last30m },
              ];
              const memTotal = latest?.memory?.totalMB;
              const cpuCores = latest?.cpu?.quotaCores || latest?.cpu?.cores;
              const highMem = windows.some(w => w.data?.memory?.avgPercent >= 85);
              const highCpu = windows.some(w => w.data?.cpu?.avgPercent >= 85);
              const isHigh = highMem || highCpu;

              return (
                <div>
                  <div className="health-resource-grid">
                    <div className="health-resource-header"></div>
                    {windows.map(w => (
                      <div key={w.label} className="health-resource-header">{w.label}</div>
                    ))}

                    <div className="health-resource-label">Mem</div>
                    {windows.map(w => {
                      const pct = w.data?.memory?.avgPercent;
                      const color = pct == null ? 'var(--text-muted)' : pct >= 90 ? 'var(--badge-error-text)' : pct >= 75 ? 'var(--badge-warning-text)' : '#73BF69';
                      return (
                        <div key={w.label} className="health-resource-value" style={{ color }}>
                          <span className="health-resource-pct">{pct != null ? `${pct}%` : '\u2014'}</span>
                        </div>
                      );
                    })}

                    <div className="health-resource-label">CPU</div>
                    {windows.map(w => {
                      const pct = w.data?.cpu?.avgPercent;
                      const color = pct == null ? 'var(--text-muted)' : pct >= 90 ? 'var(--badge-error-text)' : pct >= 75 ? 'var(--badge-warning-text)' : '#44C0C1';
                      return (
                        <div key={w.label} className="health-resource-value" style={{ color }}>
                          <span className="health-resource-pct">{pct != null ? `${pct}%` : '\u2014'}</span>
                        </div>
                      );
                    })}
                  </div>
                  {memTotal && (
                    <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: 6 }}>
                      {memTotal} MB total{cpuCores ? ` \u00B7 ${cpuCores} core${cpuCores !== 1 ? 's' : ''}` : ''}
                    </div>
                  )}
                  {isHigh && (
                    <div className="health-resource-warning">
                      <span style={{ flexShrink: 0 }}>&#9888;</span>
                      <span>
                        {highMem && highCpu ? 'Memory and CPU are high.'
                          : highMem ? 'Memory usage is high.'
                          : 'CPU usage is high.'}
                        {' '}Upgrade resources or reset container to avoid OOM.
                      </span>
                    </div>
                  )}
                </div>
              );
            })()}
          </HealthCard>
        </div>
      </div>


      {/* Config Viewer Modal */}
      {configViewer.visible && (
        <div className="dialog-overlay" onClick={() => setConfigViewer({ visible: false, loading: false, content: null })}>
          <div className="dialog" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 960, width: '94vw' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <h3 className="dialog-title" style={{ marginBottom: 0 }}>openclaw.json</h3>
              <button
                className="btn btn-secondary btn-sm"
                onClick={() => setConfigViewer({ visible: false, loading: false, content: null })}
                style={{ padding: '2px 10px', fontSize: '0.8rem' }}
              >
                Close
              </button>
            </div>
            <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', margin: '0 0 10px 0' }}>
              Secrets are masked. This is the sanitized view of your configuration.
            </p>
            {configViewer.loading ? (
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: 20, justifyContent: 'center' }}>
                <span className="spinner" style={{ width: 16, height: 16, borderWidth: 2 }} />
                Loading...
              </div>
            ) : (
              <pre style={{
                margin: 0, padding: '12px 14px',
                background: 'var(--bg-surface-alt)',
                border: '1px solid var(--border-primary)',
                borderRadius: 4, fontSize: '0.75rem',
                color: 'var(--text-secondary)',
                overflowX: 'auto', maxHeight: '60vh',
                whiteSpace: 'pre-wrap', wordBreak: 'break-all',
              }} dangerouslySetInnerHTML={{ __html: highlightJson(configViewer.content || '') }} />
            )}
          </div>
        </div>
      )}

      {/* Restart Confirmation Dialog */}
      {showRestart && (
        <div className="dialog-overlay" onClick={() => setShowRestart(false)}>
          <div className="dialog" onClick={(e) => e.stopPropagation()}>
            <h3 className="dialog-title">Restart Gateway?</h3>
            <p className="dialog-body">
              This will restart the openclaw-gateway PM2 process. The gateway will be briefly unavailable.
            </p>
            <div className="dialog-actions">
              <button className="btn btn-secondary" onClick={() => setShowRestart(false)}>
                Cancel
              </button>
              <button className="btn btn-primary" onClick={handleRestart} disabled={restarting}>
                {restarting ? <><span className="spinner" /> Restarting...</> : 'Restart'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Doctor Fix Result Dialog */}
      {doctorFix.showResult && doctorFix.result && (
        <div className="dialog-overlay" onClick={() => setDoctorFix(prev => ({ ...prev, showResult: false }))}>
          <div className="dialog" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 960, width: '94vw' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <h3 className="dialog-title" style={{ marginBottom: 0 }}>Doctor Fix Result</h3>
              <button
                className="btn btn-secondary btn-sm"
                onClick={() => setDoctorFix(prev => ({ ...prev, showResult: false }))}
                style={{ padding: '2px 10px', fontSize: '0.8rem' }}
              >
                Close
              </button>
            </div>
            <div style={{
              display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10, fontSize: '0.9rem',
            }}>
              <span style={{
                color: doctorFix.result.success && doctorFix.result.gateway?.success
                  ? 'var(--badge-success-text)' : 'var(--badge-error-text)',
                fontSize: '1.1rem', width: 18, textAlign: 'center',
              }}>
                {doctorFix.result.success && doctorFix.result.gateway?.success ? '\u2713' : '\u2717'}
              </span>
              <span style={{ color: 'var(--text-primary)', fontWeight: 500 }}>
                {doctorFix.result.success && doctorFix.result.gateway?.success
                  ? 'Doctor fix completed and gateway restarted'
                  : doctorFix.result.success
                    ? 'Doctor fix ran but gateway restart failed'
                    : 'Doctor fix failed'}
              </span>
            </div>
            {doctorFix.result.doctorOutput && (
              <pre style={{
                margin: 0, padding: '10px 12px',
                background: 'var(--bg-surface-alt)',
                border: '1px solid var(--border-primary)',
                borderRadius: 4, fontSize: '0.75rem',
                color: 'var(--text-secondary)',
                overflowX: 'auto', maxHeight: '50vh',
                whiteSpace: 'pre-wrap', wordBreak: 'break-all',
              }} dangerouslySetInnerHTML={{ __html: highlightLog(doctorFix.result.doctorOutput) }} />
            )}
          </div>
        </div>
      )}

      {/* Launcher Restart Confirmation Dialog */}
      {showLauncherRestart && (
        <div className="dialog-overlay" onClick={() => setShowLauncherRestart(false)}>
          <div className="dialog" onClick={(e) => e.stopPropagation()}>
            <h3 className="dialog-title">Restart Launcher UI?</h3>
            <p className="dialog-body">
              This will restart the Launcher web process (<code>pm2 restart web</code>). The page will be temporarily unavailable and will automatically reload when the launcher is back online.
            </p>
            <p className="dialog-body" style={{ fontSize: '0.82rem', color: 'var(--badge-warning-text)', marginTop: 4 }}>
              Use this when the health check reports "UI build outdated" to pick up the latest frontend build.
            </p>
            <div className="dialog-actions">
              <button className="btn btn-secondary" onClick={() => setShowLauncherRestart(false)}>
                Cancel
              </button>
              <button className="btn btn-primary" onClick={handleLauncherRestart} disabled={launcherRestarting === true}>
                {launcherRestarting === true ? <><span className="spinner" /> Restarting...</> : 'Restart Launcher'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Launcher Restart Waiting Overlay */}
      {launcherRestarting === 'waiting' && (
        <div className="dialog-overlay" style={{ zIndex: 9999 }}>
          <div className="dialog" style={{ textAlign: 'center', maxWidth: 400 }}>
            <div style={{ marginBottom: 16 }}>
              <span className="spinner" style={{ width: 32, height: 32, borderWidth: 3 }} />
            </div>
            <h3 className="dialog-title" style={{ marginBottom: 8 }}>Restarting Launcher...</h3>
            <p className="dialog-body" style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
              Waiting for the launcher to come back online. This page will reload automatically.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Stepper from '../components/Stepper';
import SettingsTabs from '../components/SettingsTabs';
import { useWizard } from '../context/WizardContext';

export default function SetupWizard() {
  const { isConfigured } = useWizard();
  const [tabActions, setTabActions] = useState(null);

  return (
    <div className="setup-page">
      <div className="page-header">
        <div className="page-header-row">
          <h1 className="page-title">{isConfigured ? 'Settings' : 'Setup Wizard'}</h1>
          {tabActions && <div className="page-header-actions">{tabActions}</div>}
        </div>
        <p className="page-subtitle">
          {isConfigured ? 'Review and modify your OpenClaw configuration' : 'Configure OpenClaw in a few steps'}
        </p>
      </div>
      {isConfigured ? <SettingsTabs /> : <Stepper />}
      <div className="setup-content">
        <Outlet context={{ setTabActions }} />
      </div>
    </div>
  );
}

import React, { useState, useEffect, useCallback } from 'react';
import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Download, Trash2, X, RefreshCw, AlertTriangle, CheckCircle, XCircle, ShieldAlert, ArrowUpCircle } from 'lucide-react';
import { authFetch } from '../hooks/useAuth';

const TYPE_LABELS = {
  skill: 'Skill',
  mcp: 'MCP Server',
  tool: 'Tool',
  exec: 'Exec',
};

const TYPE_BADGE = {
  skill: 'badge-info',
  mcp: 'badge-warning',
  tool: 'badge-success',
  exec: 'badge-secondary',
};

function ItemIcon({ icon, themeColor, size = 28 }) {
  return (
    <div
      style={{
        width: size,
        height: size,
        minWidth: size,
        borderRadius: 6,
        background: themeColor || '#6366f1',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: '#fff',
        flexShrink: 0,
      }}
      dangerouslySetInnerHTML={{ __html: icon ? icon.replace(/<svg/, `<svg width="${size * 0.6}" height="${size * 0.6}"`) : '' }}
    />
  );
}

function getSkillFileIcon(name) {
  if (/\.md$/i.test(name)) return { icon: '\u25A0', className: 'file-icon-md' };
  if (/\.(js|jsx|mjs|cjs)$/i.test(name)) return { icon: 'JS', className: 'file-icon-js' };
  if (/\.(ts|tsx)$/i.test(name)) return { icon: 'TS', className: 'file-icon-ts' };
  if (/\.json$/i.test(name)) return { icon: '{}', className: 'file-icon-json' };
  if (/\.txt$/i.test(name)) return { icon: '\u2261', className: 'file-icon-txt' };
  if (/\.css$/i.test(name)) return { icon: '#', className: 'file-icon-css' };
  if (/\.html?$/i.test(name)) return { icon: '<>', className: 'file-icon-html' };
  if (/\.py$/i.test(name)) return { icon: '\u{1F40D}', className: 'file-icon-py' };
  if (/\.(ya?ml|toml|ini|cfg)$/i.test(name)) return { icon: '\u2699', className: 'file-icon-config' };
  if (/\.(sh|bash|zsh)$/i.test(name)) return { icon: '$', className: 'file-icon-shell' };
  return { icon: '\u25A0', className: 'file-icon' };
}

function SkillTreeNode({ nodes, onSelect, selectedPath, depth }) {
  if (!nodes || !Array.isArray(nodes)) return null;

  const sorted = [...nodes].sort((a, b) => {
    if (a.name === 'SKILL.md') return -1;
    if (b.name === 'SKILL.md') return 1;
    const aDir = a.type === 'directory';
    const bDir = b.type === 'directory';
    if (aDir && !bDir) return -1;
    if (!aDir && bDir) return 1;
    return a.name.localeCompare(b.name);
  });

  return sorted.map(node => (
    <SkillTreeItem key={node.path || node.name} node={node} onSelect={onSelect} selectedPath={selectedPath} depth={depth} />
  ));
}

function SkillTreeItem({ node, onSelect, selectedPath, depth }) {
  const [expanded, setExpanded] = useState(depth === 0);
  const isDir = node.type === 'directory';
  const indentPx = depth * 16 + 4;

  if (isDir) {
    return (
      <div>
        <div className="ide-tree-item" style={{ paddingLeft: indentPx }} onClick={() => setExpanded(!expanded)}>
          <span className="ide-tree-chevron">{expanded ? '\u25BE' : '\u25B8'}</span>
          <span className="ide-tree-icon folder-icon" style={{ fontSize: '0.8rem' }}>
            {expanded ? '\u{1F4C2}' : '\u{1F4C1}'}
          </span>
          <span className="ide-tree-name">{node.name}</span>
        </div>
        {expanded && node.children && node.children.length > 0 && (
          <div className="ide-tree-children">
            <SkillTreeNode nodes={node.children} onSelect={onSelect} selectedPath={selectedPath} depth={depth + 1} />
          </div>
        )}
      </div>
    );
  }

  const { icon, className } = getSkillFileIcon(node.name);
  return (
    <div
      className={`ide-tree-item ${selectedPath === node.path ? 'selected' : ''}`}
      style={{ paddingLeft: indentPx + 16 }}
      onClick={() => onSelect(node.path)}
    >
      <span className={`ide-tree-icon ${className}`} style={{ fontSize: '0.7rem' }}>{icon}</span>
      <span className="ide-tree-name">{node.name}</span>
    </div>
  );
}

function SkeletonCard() {
  return (
    <div className="card" style={{ padding: '14px 16px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
        <div className="skeleton-row" style={{ width: '55%' }} />
        <div className="skeleton-row" style={{ width: 50, height: 20 }} />
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        <div className="skeleton-row" style={{ width: '90%' }} />
        <div className="skeleton-row" style={{ width: '70%' }} />
      </div>
      <div style={{ marginTop: 12 }}>
        <div className="skeleton-row-lg" style={{ width: '100%' }} />
      </div>
    </div>
  );
}

function DetailPanel({ item, onClose }) {
  const [content, setContent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [tree, setTree] = useState(null);
  const [fileCount, setFileCount] = useState(1);
  const [itemType, setItemType] = useState(null);
  const [selectedPath, setSelectedPath] = useState(null);
  const [fileData, setFileData] = useState(null);
  const [fileLoading, setFileLoading] = useState(false);
  const [treePanelOpen, setTreePanelOpen] = useState(true);

  useEffect(() => {
    setLoading(true);
    setContent(null);
    setTree(null);
    setFileCount(1);
    setItemType(null);
    setSelectedPath(null);
    setFileData(null);
    setError(null);
    setTreePanelOpen(true);
    authFetch(`/api/openclaw/marketplace/preview?itemId=${encodeURIComponent(item.id)}`)
      .then(r => { if (!r.ok) throw new Error(`HTTP ${r.status}`); return r.json(); })
      .then(data => {
        setContent(data.content);
        setTree(data.tree || null);
        setFileCount(data.fileCount || 1);
        setItemType(data.itemType || null);
        setError(null);
      })
      .catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, [item.id]);

  const loadSkillFile = useCallback((filePath) => {
    setSelectedPath(filePath);
    setFileLoading(true);
    setFileData(null);
    authFetch(`/api/openclaw/marketplace/preview/file?itemId=${encodeURIComponent(item.id)}&path=${encodeURIComponent(filePath)}`)
      .then(r => { if (!r.ok) throw new Error(`HTTP ${r.status}`); return r.json(); })
      .then(data => setFileData(data))
      .catch(err => setFileData({ name: filePath, content: `Error loading file: ${err.message}`, isMarkdown: false, extension: '' }))
      .finally(() => setFileLoading(false));
  }, [item.id]);

  const isMultiFile = fileCount > 1 && tree;

  const renderFileContent = () => {
    if (fileLoading) {
      return (
        <div style={{ padding: '12px 16px', display: 'flex', flexDirection: 'column', gap: 10 }}>
          <div className="skeleton-row" style={{ width: '60%' }} />
          <div className="skeleton-row" style={{ width: '90%' }} />
          <div className="skeleton-row" style={{ width: '75%' }} />
        </div>
      );
    }
    if (fileData) {
      if (fileData.isMarkdown) {
        return (
          <div className="ide-markdown" style={{ fontSize: '0.85rem' }}>
            <Markdown remarkPlugins={[remarkGfm]}>{fileData.content}</Markdown>
          </div>
        );
      }
      return (
        <div className="ide-code-view">
          <div className="ide-line-numbers">
            <div className="ide-gutter">
              {fileData.content.split('\n').map((_, i) => <div key={i}>{i + 1}</div>)}
            </div>
            <div className="ide-code-body">
              <pre>{fileData.content}</pre>
            </div>
          </div>
        </div>
      );
    }
    // Default: show SKILL.md from initial fetch
    return (
      <div className="ide-markdown" style={{ fontSize: '0.85rem' }}>
        <Markdown remarkPlugins={[remarkGfm]}>{content}</Markdown>
      </div>
    );
  };

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      height: '100%',
      overflow: 'hidden',
    }}>
      {/* Detail header */}
      <div style={{
        padding: '10px 16px',
        borderBottom: '1px solid var(--border-primary)',
        display: 'flex',
        alignItems: 'flex-start',
        justifyContent: 'space-between',
        gap: 12,
        flexShrink: 0,
      }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
            <ItemIcon icon={item.icon} themeColor={item.themeColor} size={34} />
            <h3 style={{ margin: 0, fontSize: '1.1rem', fontWeight: 600 }}>{item.name}</h3>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
            <span className={`badge ${TYPE_BADGE[item.type] || 'badge-info'}`}>
              {TYPE_LABELS[item.type] || item.type}
            </span>
            {item.status === 'broken' ? (
              <span className="badge badge-error">Broken</span>
            ) : item.updateAvailable ? (
              <span className="badge badge-warning">Update Available</span>
            ) : item.installed ? (
              <span className="badge badge-success">Installed</span>
            ) : null}
            {item.hasToolsEntry && (
              <span className="badge badge-secondary" title="This skill adds an entry to TOOLS.md">TOOLS.md</span>
            )}
            {item.hasAgentsEntry && (
              <span className="badge badge-secondary" title="This skill adds an entry to AGENTS.md">AGENTS.md</span>
            )}
            <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
              {item.installedVersion && item.installedVersion !== item.version
                ? `v${item.installedVersion} \u2192 v${item.version}`
                : `v${item.version}`}
            </span>
          </div>
        </div>
        <button
          className="btn btn-secondary btn-sm"
          onClick={onClose}
          title="Close"
          style={{ padding: '4px 6px', flexShrink: 0 }}
        >
          <X size={14} />
        </button>
      </div>

      {/* Description + tags */}
      <div style={{ padding: '8px 16px', borderBottom: '1px solid var(--border-primary)', flexShrink: 0 }}>
        <p style={{ margin: 0, fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: 1.6 }}>
          {item.description}
        </p>
        {item.tags && item.tags.length > 0 && (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, marginTop: 10 }}>
            {item.tags.map(tag => (
              <span key={tag} style={{
                padding: '1px 6px',
                fontSize: '0.68rem',
                borderRadius: 3,
                background: tag === 'hardcoded' ? 'var(--badge-secondary-bg)' : 'var(--bg-surface-alt)',
                color: tag === 'hardcoded' ? 'var(--badge-secondary-text)' : 'var(--text-muted)',
                border: tag === 'hardcoded' ? '1px solid var(--badge-secondary-text)' : '1px solid var(--border-primary)',
                fontWeight: tag === 'hardcoded' ? 600 : 400,
              }}>
                {tag === 'hardcoded' ? 'Hardcoded' : tag}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Preview content */}
      {loading ? (
        <div style={{ flex: 1, overflowY: 'auto', padding: '12px 16px', minHeight: 0 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <div className="skeleton-row" style={{ width: '60%' }} />
            <div className="skeleton-row" style={{ width: '95%' }} />
            <div className="skeleton-row" style={{ width: '80%' }} />
            <div className="skeleton-row" style={{ width: '90%' }} />
            <div className="skeleton-row" style={{ width: '50%' }} />
            <div className="skeleton-row" style={{ width: '85%' }} />
          </div>
        </div>
      ) : error ? (
        <div style={{ flex: 1, overflowY: 'auto', padding: '12px 16px', minHeight: 0 }}>
          <span style={{ fontSize: '0.85rem', color: 'var(--badge-error-text)' }}>
            Failed to load preview: {error}
          </span>
        </div>
      ) : isMultiFile ? (
        <div style={{ flex: 1, display: 'flex', minHeight: 0, overflow: 'hidden' }}>
          {/* File tree sidebar — collapsible */}
          {treePanelOpen && (
            <div className="marketplace-detail-tree-sidebar" style={{
              width: 200,
              minWidth: 160,
              borderRight: '1px solid var(--border-primary)',
              display: 'flex',
              flexDirection: 'column',
              flexShrink: 0,
            }}>
              <div style={{
                padding: '6px 10px',
                fontSize: '0.7rem',
                fontWeight: 600,
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
                color: 'var(--text-secondary)',
                borderBottom: '1px solid var(--border-primary)',
                userSelect: 'none',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}>
                <span>Files</span>
                <span
                  onClick={() => setTreePanelOpen(false)}
                  style={{ cursor: 'pointer', fontSize: '0.8rem', color: 'var(--text-muted)' }}
                  title="Collapse file tree"
                >✕</span>
              </div>
              <div style={{ flex: 1, overflowY: 'auto', padding: '4px 0' }}>
                <SkillTreeNode nodes={tree} onSelect={loadSkillFile} selectedPath={selectedPath} depth={0} />
              </div>
            </div>
          )}
          {!treePanelOpen && (
            <div
              onClick={() => setTreePanelOpen(true)}
              title="Show file tree"
              style={{
                width: 28,
                flexShrink: 0,
                borderRight: '1px solid var(--border-primary)',
                display: 'flex',
                alignItems: 'flex-start',
                justifyContent: 'center',
                paddingTop: 8,
                cursor: 'pointer',
                color: 'var(--text-muted)',
                fontSize: '0.75rem',
              }}
            >▸</div>
          )}
          {/* File content area */}
          <div style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden', minWidth: 0 }}>
            {renderFileContent()}
          </div>
        </div>
      ) : (
        <div style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden', minHeight: 0, minWidth: 0 }}>
          <div className="ide-markdown" style={{ fontSize: '0.85rem' }}>
            <Markdown remarkPlugins={[remarkGfm]}>{content}</Markdown>
          </div>
        </div>
      )}
    </div>
  );
}

export default function Marketplace() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [actionLoading, setActionLoading] = useState(null);
  const [feedback, setFeedback] = useState(null);
  const [search, setSearch] = useState('');
  const [selectedId, setSelectedId] = useState(null);
  const [externalNotice, setExternalNotice] = useState(null);

  const fetchCatalog = useCallback((silent = false) => {
    if (!silent) setLoading(true);
    authFetch('/api/openclaw/marketplace/catalog')
      .then(r => { if (!r.ok) throw new Error(`HTTP ${r.status}`); return r.json(); })
      .then(data => { setItems(data.items || []); setError(null); })
      .catch(err => { if (!silent) setError(err.message); })
      .finally(() => { if (!silent) setLoading(false); });
  }, []);

  useEffect(() => { fetchCatalog(); }, [fetchCatalog]);

  useEffect(() => {
    if (feedback) {
      const timer = setTimeout(() => setFeedback(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [feedback]);

  const performInstall = async (itemId) => {
    setActionLoading(itemId);
    setFeedback(null);
    try {
      const res = await authFetch('/api/openclaw/marketplace/install', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ itemId }),
      });
      const data = await res.json();
      // 409 = already installed — treat as success, refresh catalog to reflect status
      if (res.status === 409) {
        setFeedback({ type: 'success', message: data.message || 'Already installed' });
        fetchCatalog(true);
        return;
      }
      if (!res.ok) throw new Error(data.message || 'Install failed');
      setFeedback({ type: 'success', message: data.message || 'Installed successfully' });
      fetchCatalog(true);
    } catch (err) {
      setFeedback({ type: 'error', message: err.message });
    } finally {
      setActionLoading(null);
    }
  };

  const handleInstall = (itemId) => {
    const item = items.find(i => i.id === itemId);
    if (item && !item.builtin) {
      setExternalNotice({ itemId, itemName: item.name });
      return;
    }
    performInstall(itemId);
  };

  const confirmExternalInstall = () => {
    if (externalNotice) {
      performInstall(externalNotice.itemId);
      setExternalNotice(null);
    }
  };

  const handleUninstall = async (itemId) => {
    setActionLoading(itemId);
    setFeedback(null);
    try {
      const res = await authFetch('/api/openclaw/marketplace/uninstall', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ itemId }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Uninstall failed');
      setFeedback({ type: 'success', message: data.message || 'Uninstalled successfully' });
      fetchCatalog(true);
    } catch (err) {
      setFeedback({ type: 'error', message: err.message });
    } finally {
      setActionLoading(null);
    }
  };

  const filteredItems = items.filter(item => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      item.name.toLowerCase().includes(q) ||
      item.description.toLowerCase().includes(q) ||
      item.type.toLowerCase().includes(q) ||
      item.tags.some(t => t.toLowerCase().includes(q))
    );
  });

  const upgradableItems = items.filter(i => i.updateAvailable);
  const [upgradingAll, setUpgradingAll] = useState(false);

  const handleUpgradeAll = async () => {
    if (upgradingAll || upgradableItems.length === 0) return;
    setUpgradingAll(true);
    setFeedback(null);
    let successCount = 0;
    let failCount = 0;
    for (const item of upgradableItems) {
      try {
        const res = await authFetch('/api/openclaw/marketplace/install', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ itemId: item.id }),
        });
        if (res.ok || res.status === 409) {
          successCount++;
        } else {
          failCount++;
        }
      } catch {
        failCount++;
      }
    }
    fetchCatalog(true);
    setFeedback({
      type: failCount === 0 ? 'success' : 'error',
      message: failCount === 0
        ? `Updated ${successCount} item${successCount !== 1 ? 's' : ''} successfully`
        : `Updated ${successCount}, failed ${failCount}`,
    });
    setUpgradingAll(false);
  };

  const selectedItem = selectedId ? filteredItems.find(i => i.id === selectedId) : null;
  // Clear selection if item is no longer in filtered list
  if (selectedId && !selectedItem) {
    // Will clear on next render via the check below
  }

  const handleCardClick = (itemId) => {
    setSelectedId(selectedId === itemId ? null : itemId);
  };

  return (
    <div style={{ height: '100vh', maxHeight: '100vh', display: 'flex', flexDirection: 'column', overflow: 'hidden', boxSizing: 'border-box' }}>
      {/* Page header */}
      <div className="page-header" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0, flexWrap: 'wrap', gap: 8 }}>
        <div style={{ minWidth: 0, flex: 1 }}>
          <h1 className="page-title">Marketplace</h1>
          <p className="page-subtitle">
            Install skills and tools for your OpenClaw agent. Skills are installed to ~/.openclaw/skills/ and loaded automatically.
          </p>
        </div>
        {!loading && items.length > 0 && (
          <input
            type="text"
            placeholder="Search..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{
              padding: '6px 12px',
              fontSize: '0.82rem',
              border: '1px solid var(--border-primary)',
              borderRadius: 4,
              background: 'var(--bg-surface)',
              color: 'var(--text-primary)',
              width: 200,
              maxWidth: '100%',
              outline: 'none',
              flexShrink: 0,
            }}
          />
        )}
      </div>

      <div className="setup-content" style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', minHeight: 0, minWidth: 0 }}>
      {/* Split layout: card list + detail panel */}
      <div className="marketplace-split-layout" style={{ flex: 1, display: 'flex', gap: 20, overflow: 'hidden', minHeight: 0, minWidth: 0 }}>
        {/* Left: card list */}
        <div className={`marketplace-catalog-panel${selectedItem ? ' marketplace-catalog-has-detail' : ''}`} style={{
          flex: selectedItem ? '0 0 340px' : '1 1 auto',
          overflowY: 'auto',
          minWidth: 0,
        }}>
          {loading ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {[1, 2, 3].map(i => <SkeletonCard key={i} />)}
            </div>
          ) : error ? (
            <div className="card" style={{ padding: '14px 16px' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <span style={{ fontSize: '0.85rem', color: 'var(--badge-error-text)' }}>
                  Failed to load catalog: {error}
                </span>
                <button className="btn btn-secondary btn-sm" onClick={fetchCatalog}>Retry</button>
              </div>
            </div>
          ) : filteredItems.length === 0 ? (
            <div className="card" style={{ padding: '20px 16px', textAlign: 'center' }}>
              <span style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                {search ? 'No items match your search.' : 'No marketplace items available.'}
              </span>
            </div>
          ) : (
            <div className="marketplace-list">
              {upgradableItems.length > 0 && (
                <div className="marketplace-upgrade-banner">
                  <ArrowUpCircle size={18} />
                  <span className="marketplace-upgrade-banner-text">
                    <span className="marketplace-upgrade-banner-count">{upgradableItems.length}</span>
                    {' '}update{upgradableItems.length !== 1 ? 's' : ''} available
                  </span>
                  <button
                    className="btn btn-primary btn-sm"
                    onClick={handleUpgradeAll}
                    disabled={upgradingAll}
                    style={{ padding: '4px 14px', flexShrink: 0 }}
                  >
                    {upgradingAll ? (
                      <><span className="spinner" style={{ width: 12, height: 12, borderWidth: 2 }} /> Upgrading...</>
                    ) : (
                      <><RefreshCw size={12} /> Upgrade All</>
                    )}
                  </button>
                </div>
              )}
              {(() => {
                const typeOrder = ['skill', 'mcp', 'tool', 'exec'];
                const grouped = {};
                filteredItems.forEach(item => {
                  if (!grouped[item.type]) grouped[item.type] = [];
                  grouped[item.type].push(item);
                });
                // Sort within each category: installed first, then by name
                Object.keys(grouped).forEach(type => {
                  grouped[type].sort((a, b) => {
                    const aInstalled = a.installed || a.updateAvailable ? 1 : 0;
                    const bInstalled = b.installed || b.updateAvailable ? 1 : 0;
                    if (bInstalled !== aInstalled) return bInstalled - aInstalled;
                    return a.name.localeCompare(b.name);
                  });
                });
                const sortedTypes = typeOrder.filter(t => grouped[t]);
                // Include any types not in typeOrder
                Object.keys(grouped).forEach(t => { if (!sortedTypes.includes(t)) sortedTypes.push(t); });

                return sortedTypes.map(type => (
                  <div key={type} className="marketplace-category">
                    <div className="marketplace-category-header">
                      <span className={`marketplace-category-dot ${TYPE_BADGE[type] || 'badge-info'}`} />
                      <span className="marketplace-category-label">{TYPE_LABELS[type] || type}</span>
                      <span className="marketplace-category-count">{grouped[type].length}</span>
                    </div>
                    <div className="marketplace-category-items">
                    {grouped[type].map(item => (
                      <div
                        key={item.id}
                        className="card"
                        onClick={() => handleCardClick(item.id)}
                        style={{
                          padding: '12px 14px',
                          display: 'flex',
                          flexDirection: 'column',
                          cursor: 'pointer',
                          outline: selectedId === item.id ? '2px solid var(--accent-primary)' : 'none',
                          outlineOffset: -2,
                          transition: 'outline 0.15s ease',
                        }}
                      >
                        {/* Header: title (left), action button (right) */}
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8, marginBottom: 2 }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 8, minWidth: 0, flex: 1 }}>
                            <ItemIcon icon={item.icon} themeColor={item.themeColor} size={28} />
                            <h3 className="card-title" style={{ marginBottom: 0, fontSize: '0.88rem' }}>{item.name}</h3>
                          </div>
                          <div style={{ flexShrink: 0 }} onClick={(e) => e.stopPropagation()}>
                            {item.status === 'broken' ? (
                              <button
                                className="btn btn-primary btn-sm"
                                onClick={() => handleInstall(item.id)}
                                disabled={actionLoading === item.id}
                                style={{ padding: '3px 10px' }}
                              >
                                {actionLoading === item.id ? (
                                  <><span className="spinner" style={{ width: 12, height: 12, borderWidth: 2 }} /> Repairing…</>
                                ) : (
                                  <><AlertTriangle size={12} /> Repair</>
                                )}
                              </button>
                            ) : item.updateAvailable ? (
                              <div style={{ display: 'flex', gap: 4 }}>
                                <button
                                  className="btn btn-primary btn-sm"
                                  onClick={() => handleInstall(item.id)}
                                  disabled={actionLoading === item.id}
                                  style={{ padding: '3px 10px' }}
                                >
                                  {actionLoading === item.id ? (
                                    <><span className="spinner" style={{ width: 12, height: 12, borderWidth: 2 }} /> Updating…</>
                                  ) : (
                                    <><RefreshCw size={12} /> Update</>
                                  )}
                                </button>
                                <button
                                  className="btn btn-secondary btn-sm"
                                  onClick={() => handleUninstall(item.id)}
                                  disabled={actionLoading === item.id}
                                  style={{ padding: '3px 10px' }}
                                >
                                  <Trash2 size={12} />
                                </button>
                              </div>
                            ) : item.installed ? (
                              actionLoading === item.id ? (
                                <button
                                  className="btn btn-secondary btn-sm"
                                  disabled
                                  style={{ padding: '3px 10px' }}
                                >
                                  <span className="spinner" style={{ width: 12, height: 12, borderWidth: 2 }} /> Removing…
                                </button>
                              ) : (
                                <div className="marketplace-installed-toggle" onClick={() => handleUninstall(item.id)}>
                                  <span className="marketplace-installed-label">
                                    <CheckCircle size={12} /> Installed
                                  </span>
                                  <span className="marketplace-uninstall-label">
                                    <Trash2 size={12} /> Uninstall
                                  </span>
                                </div>
                              )
                            ) : (
                              <button
                                className="btn btn-primary btn-sm"
                                onClick={() => handleInstall(item.id)}
                                disabled={actionLoading === item.id}
                                style={{ padding: '3px 10px' }}
                              >
                                {actionLoading === item.id ? (
                                  <><span className="spinner" style={{ width: 12, height: 12, borderWidth: 2 }} /> Installing…</>
                                ) : (
                                  <><Download size={12} /> Install</>
                                )}
                              </button>
                            )}
                          </div>
                        </div>

                        {/* Version line */}
                        {!selectedItem && (
                          <div style={{ fontSize: '0.68rem', color: 'var(--text-muted)', marginBottom: 2, paddingLeft: 36 }}>
                            {item.installedVersion && item.installedVersion !== item.version
                              ? `v${item.installedVersion} → v${item.version}`
                              : `v${item.version}`}
                          </div>
                        )}

                        {/* Badges line */}
                        {!selectedItem && (
                          <div style={{ display: 'flex', alignItems: 'center', gap: 4, flexWrap: 'wrap', marginBottom: 6, paddingLeft: 36 }}>
                            <span className={`badge ${TYPE_BADGE[item.type] || 'badge-info'}`} style={{ fontSize: '0.6rem', padding: '0px 5px' }}>
                              {TYPE_LABELS[item.type] || item.type}
                            </span>
                            {item.status === 'broken' && (
                              <span className="badge badge-error" style={{ fontSize: '0.6rem', padding: '0px 5px' }}>Broken</span>
                            )}
                            {item.hasToolsEntry && (
                              <span className="badge badge-secondary" style={{ fontSize: '0.6rem', padding: '0px 5px', flexShrink: 0 }} title="This skill adds an entry to TOOLS.md">TOOLS.md</span>
                            )}
                            {item.hasAgentsEntry && (
                              <span className="badge badge-secondary" style={{ fontSize: '0.6rem', padding: '0px 5px', flexShrink: 0 }} title="This skill adds an entry to AGENTS.md">AGENTS.md</span>
                            )}
                          </div>
                        )}

                        {/* Description - max 3 lines, hidden when detail panel is open */}
                        {!selectedItem && (
                          <p style={{
                            margin: 0,
                            fontSize: '0.78rem',
                            color: 'var(--text-secondary)',
                            lineHeight: 1.4,
                            display: '-webkit-box',
                            WebkitLineClamp: 3,
                            WebkitBoxOrient: 'vertical',
                            overflow: 'hidden',
                          }}>
                            {item.description}
                          </p>
                        )}
                      </div>
                    ))}
                    </div>
                  </div>
                ));
              })()}
            </div>
          )}
        </div>

        {/* Right: detail viewer */}
        {selectedItem && (
          <div className="card marketplace-detail-panel" style={{
            flex: '1 1 auto',
            minWidth: 0,
            maxWidth: '100%',
            overflow: 'hidden',
            display: 'flex',
            flexDirection: 'column',
            padding: 0,
          }}>
            <DetailPanel
              item={selectedItem}
              onClose={() => setSelectedId(null)}
            />
          </div>
        )}
      </div>
      </div>

      {/* Toast notification */}
      {feedback && (
        <div className={`marketplace-toast ${feedback.type === 'success' ? 'marketplace-toast-success' : 'marketplace-toast-error'}`}>
          {feedback.type === 'success' ? <CheckCircle size={14} /> : <XCircle size={14} />}
          <span>{feedback.message}</span>
          <button className="marketplace-toast-close" onClick={() => setFeedback(null)}>
            <X size={12} />
          </button>
        </div>
      )}

      {/* External service notice modal */}
      {externalNotice && (
        <div className="modal-overlay" onClick={() => setExternalNotice(null)}>
          <div className="modal-dialog" onClick={e => e.stopPropagation()} style={{ maxWidth: 480 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
              <ShieldAlert size={22} style={{ color: 'var(--badge-warning-text)', flexShrink: 0 }} />
              <h3 style={{ margin: 0, fontSize: '1rem', fontWeight: 600 }}>External Service Notice</h3>
            </div>
            <p style={{ margin: '0 0 10px', fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: 1.6 }}>
              <strong>{externalNotice.itemName}</strong> is provided by a third-party service.
              Installing it may cause your data — including conversation context, workspace files, or configuration —
              to be transmitted to an external service provider.
            </p>
            <p style={{ margin: '0 0 16px', fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: 1.6 }}>
              Please review the item details and ensure you trust the provider before proceeding.
              By continuing, you acknowledge that data may leave your local environment.
            </p>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
              <button className="btn btn-secondary btn-sm" onClick={() => setExternalNotice(null)}>
                Cancel
              </button>
              <button className="btn btn-primary btn-sm" onClick={confirmExternalInstall}>
                I Understand, Install
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

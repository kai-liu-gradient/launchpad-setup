import React from 'react';
import Markdown from 'react-markdown';
import { ExternalLink, Bell, AlertTriangle, AlertCircle, Info, Check } from 'lucide-react';
import { useNotices } from '../components/NoticeBanner';

const PRIORITY_ICONS = {
  critical: AlertCircle,
  warning: AlertTriangle,
  info: Info,
};

const PRIORITY_COLORS = {
  critical: 'var(--badge-error-text)',
  warning: 'var(--badge-warning-text)',
  info: 'var(--badge-info-text)',
};

function timeAgo(dateStr) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 30) return `${days}d ago`;
  return new Date(dateStr).toLocaleDateString();
}

export default function Notices() {
  const { notices, unreadCount, dismiss, dismissAll } = useNotices();

  return (
    <div className="notices-page">
      <div className="page-header">
        <h1 className="page-title">Notifications</h1>
        <p className="page-subtitle">
          Platform announcements and system notices
          {unreadCount > 0 && (
            <span className="badge badge-info" style={{ fontSize: '0.7rem', padding: '2px 8px', marginLeft: '8px' }}>
              {unreadCount} unread
            </span>
          )}
        </p>
        {unreadCount > 1 && (
          <button onClick={dismissAll} className="notices-dismiss-btn" style={{ marginTop: '8px' }}>
            <Check size={14} />
            Dismiss all
          </button>
        )}
      </div>

      <div className="notices-content">
        {notices.length === 0 ? (
          <div className="notices-empty">
            <Bell size={36} style={{ opacity: 0.3, marginBottom: '12px' }} />
            <div>No notices</div>
          </div>
        ) : (
          <div className="notices-timeline">
            {notices.map((notice) => {
              const IconComponent = PRIORITY_ICONS[notice.priority] || Info;
              const dotColor = PRIORITY_COLORS[notice.priority] || PRIORITY_COLORS.info;
              const isDismissed = notice.dismissed;

              return (
                <div
                  key={notice.id}
                  className={`notices-timeline-item ${isDismissed ? 'dismissed' : ''}`}
                >
                  <div className="notices-timeline-dot" style={{ background: dotColor }} />
                  <div className="notices-timeline-line" />

                  <div className="notices-timeline-card">
                    <div className="notices-timeline-header">
                      <span className="notices-timeline-priority" style={{ color: dotColor }}>
                        <IconComponent size={13} />
                        {notice.priority}
                      </span>
                      <span className="notices-timeline-time">
                        {notice.createdAt ? timeAgo(notice.createdAt) : ''}
                      </span>
                    </div>

                    <div className="notices-timeline-title">
                      {notice.title}
                    </div>

                    {notice.message && (
                      <div className="notices-timeline-message markdown-content">
                        <Markdown>{notice.message}</Markdown>
                      </div>
                    )}

                    <div className="notices-timeline-actions">
                      {notice.actionUrl && (
                        <a
                          href={notice.actionUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="notices-timeline-link"
                        >
                          {notice.actionLabel || 'Learn more'}
                          <ExternalLink size={11} />
                        </a>
                      )}
                      {!isDismissed && notice.dismissible !== false && (
                        <button
                          onClick={() => dismiss(notice.id)}
                          className="notices-dismiss-btn"
                        >
                          <Check size={14} />
                          Mark as read
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

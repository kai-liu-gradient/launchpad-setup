import React, { useEffect, useState, useCallback, useMemo, useRef } from 'react';
import Markdown from 'react-markdown';
import hljs from 'highlight.js/lib/core';
import javascript from 'highlight.js/lib/languages/javascript';
import json from 'highlight.js/lib/languages/json';
import css from 'highlight.js/lib/languages/css';
import xml from 'highlight.js/lib/languages/xml';
import python from 'highlight.js/lib/languages/python';
import bash from 'highlight.js/lib/languages/bash';
import yaml from 'highlight.js/lib/languages/yaml';
import markdown from 'highlight.js/lib/languages/markdown';
import sql from 'highlight.js/lib/languages/sql';
import ini from 'highlight.js/lib/languages/ini';
import typescript from 'highlight.js/lib/languages/typescript';
import 'highlight.js/styles/github-dark.css';
import { authFetch } from '../hooks/useAuth';

hljs.registerLanguage('javascript', javascript);
hljs.registerLanguage('js', javascript);
hljs.registerLanguage('jsx', javascript);
hljs.registerLanguage('json', json);
hljs.registerLanguage('css', css);
hljs.registerLanguage('html', xml);
hljs.registerLanguage('xml', xml);
hljs.registerLanguage('python', python);
hljs.registerLanguage('bash', bash);
hljs.registerLanguage('shell', bash);
hljs.registerLanguage('sh', bash);
hljs.registerLanguage('yaml', yaml);
hljs.registerLanguage('yml', yaml);
hljs.registerLanguage('markdown', markdown);
hljs.registerLanguage('md', markdown);
hljs.registerLanguage('sql', sql);
hljs.registerLanguage('ini', ini);
hljs.registerLanguage('toml', ini);
hljs.registerLanguage('typescript', typescript);
hljs.registerLanguage('ts', typescript);
hljs.registerLanguage('tsx', typescript);

const MAX_UPLOAD_SIZE = 10 * 1024 * 1024; // 10MB per file

const ROOT_OPTIONS = {
  workspace: { label: 'workspace', path: '~/.openclaw/workspace' },
  openclaw: { label: '.openclaw', path: '~/.openclaw' },
};

function getFileIcon(name) {
  if (/\.md$/i.test(name)) return { icon: '\u25A0', className: 'file-icon-md' };
  if (/\.(js|jsx|mjs|cjs)$/i.test(name)) return { icon: 'JS', className: 'file-icon-js' };
  if (/\.(ts|tsx)$/i.test(name)) return { icon: 'TS', className: 'file-icon-ts' };
  if (/\.json$/i.test(name)) return { icon: '{}', className: 'file-icon-json' };
  if (/\.txt$/i.test(name)) return { icon: '\u2261', className: 'file-icon-txt' };
  if (/\.css$/i.test(name)) return { icon: '#', className: 'file-icon-css' };
  if (/\.html?$/i.test(name)) return { icon: '<>', className: 'file-icon-html' };
  if (/\.py$/i.test(name)) return { icon: '\u{1F40D}', className: 'file-icon-py' };
  if (/\.(ya?ml|toml|ini|cfg)$/i.test(name)) return { icon: '\u2699', className: 'file-icon-config' };
  if (/\.(png|jpe?g|gif|webp|svg|ico)$/i.test(name)) return { icon: '\u{1F5BC}', className: 'file-icon-image' };
  if (/\.(zip|gz|tar|7z|rar)$/i.test(name)) return { icon: '\u{1F4E6}', className: 'file-icon-archive' };
  if (/\.(pdf)$/i.test(name)) return { icon: '\u{1F4C4}', className: 'file-icon-pdf' };
  if (/\.(sh|bash|zsh)$/i.test(name)) return { icon: '$', className: 'file-icon-shell' };
  if (/\.(sql)$/i.test(name)) return { icon: 'DB', className: 'file-icon-sql' };
  return { icon: '\u25A0', className: 'file-icon' };
}

function getFileLanguage(name) {
  if (/\.js$/i.test(name)) return 'JavaScript';
  if (/\.(jsx|mjs|cjs)$/i.test(name)) return 'JavaScript';
  if (/\.ts$/i.test(name)) return 'TypeScript';
  if (/\.tsx$/i.test(name)) return 'TypeScript';
  if (/\.json$/i.test(name)) return 'JSON';
  if (/\.md$/i.test(name)) return 'Markdown';
  if (/\.txt$/i.test(name)) return 'Plain Text';
  if (/\.css$/i.test(name)) return 'CSS';
  if (/\.html?$/i.test(name)) return 'HTML';
  if (/\.py$/i.test(name)) return 'Python';
  if (/\.(sh|bash|zsh)$/i.test(name)) return 'Shell';
  if (/\.ya?ml$/i.test(name)) return 'YAML';
  if (/\.sql$/i.test(name)) return 'SQL';
  if (/\.(ini|cfg)$/i.test(name)) return 'INI';
  if (/\.toml$/i.test(name)) return 'TOML';
  if (/\.xml$/i.test(name)) return 'XML';
  return 'Plain Text';
}

function getHljsLanguage(name) {
  if (/\.(js|jsx|mjs|cjs)$/i.test(name)) return 'javascript';
  if (/\.(ts|tsx)$/i.test(name)) return 'typescript';
  if (/\.json$/i.test(name)) return 'json';
  if (/\.md$/i.test(name)) return 'markdown';
  if (/\.css$/i.test(name)) return 'css';
  if (/\.html?$/i.test(name)) return 'html';
  if (/\.xml$/i.test(name)) return 'xml';
  if (/\.py$/i.test(name)) return 'python';
  if (/\.(sh|bash|zsh)$/i.test(name)) return 'bash';
  if (/\.ya?ml$/i.test(name)) return 'yaml';
  if (/\.sql$/i.test(name)) return 'sql';
  if (/\.(ini|cfg|toml)$/i.test(name)) return 'ini';
  return null;
}

function useIsNarrow(breakpoint = 768) {
  const [isNarrow, setIsNarrow] = useState(() => window.innerWidth <= breakpoint);
  useEffect(() => {
    const mq = window.matchMedia(`(max-width: ${breakpoint}px)`);
    const handler = (e) => setIsNarrow(e.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, [breakpoint]);
  return isNarrow;
}

const formatSize = (bytes) => {
  if (!bytes && bytes !== 0) return '';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
};

// Highlighted code block component
function HighlightedCode({ code, language }) {
  const codeRef = useRef(null);

  useEffect(() => {
    if (codeRef.current && code) {
      if (language && hljs.getLanguage(language)) {
        try {
          const result = hljs.highlight(code, { language });
          codeRef.current.innerHTML = result.value;
        } catch {
          codeRef.current.textContent = code;
        }
      } else {
        codeRef.current.textContent = code;
      }
    }
  }, [code, language]);

  return <code ref={codeRef} className={language ? `hljs language-${language}` : 'hljs'} />;
}

// Upload progress modal component
function UploadProgressModal({ uploads, onClose }) {
  if (!uploads || uploads.length === 0) return null;

  const allDone = uploads.every((u) => u.status === 'done' || u.status === 'error');

  return (
    <div className="upload-modal-overlay" onClick={allDone ? onClose : undefined}>
      <div className="upload-modal" onClick={(e) => e.stopPropagation()}>
        <div className="upload-modal-header">
          <span>Uploading Files</span>
          {allDone && (
            <button className="ide-action-btn" onClick={onClose}>Close</button>
          )}
        </div>
        <div className="upload-modal-body">
          {uploads.map((u, i) => (
            <div key={i} className="upload-file-row">
              <div className="upload-file-info">
                <span className="upload-file-name">{u.name}</span>
                <span className="upload-file-size">{formatSize(u.size)}</span>
              </div>
              <div className="upload-progress-bar-track">
                <div
                  className={`upload-progress-bar-fill ${u.status === 'error' ? 'error' : u.status === 'done' ? 'done' : ''}`}
                  style={{ width: `${u.progress}%` }}
                />
              </div>
              <div className={`upload-file-status ${u.status}`}>
                {u.status === 'pending' && 'Pending'}
                {u.status === 'uploading' && `${u.progress}%`}
                {u.status === 'verifying' && 'Verifying...'}
                {u.status === 'done' && (
                  <span title={`MD5: ${u.md5}`}>Done {'\u2713'}</span>
                )}
                {u.status === 'error' && (
                  <span title={u.message}>{u.message || 'Failed'}</span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// Non-previewable file card
function NonPreviewableCard({ meta, reason, onDownload }) {
  return (
    <div className="ide-no-preview">
      <div className="ide-no-preview-icon">{'\u{1F4CE}'}</div>
      <div className="ide-no-preview-title">
        {reason === 'too_large' ? 'File too large to preview' : 'This file cannot be previewed'}
      </div>
      <div className="ide-no-preview-meta">
        {meta?.name && <div><strong>Name:</strong> {meta.name}</div>}
        {meta?.size !== undefined && <div><strong>Size:</strong> {formatSize(meta.size)}</div>}
        {meta?.mimeType && <div><strong>Type:</strong> {meta.mimeType}</div>}
      </div>
      <button className="ide-download-btn" onClick={onDownload}>
        {'\u2B07'} Download File
      </button>
    </div>
  );
}

// Context menu for right-click on tree items
function TreeContextMenu({ x, y, itemPath, itemType, onDelete, onClose }) {
  const menuRef = useRef(null);

  useEffect(() => {
    const handler = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) onClose();
    };
    document.addEventListener('mousedown', handler);
    document.addEventListener('contextmenu', handler);
    return () => {
      document.removeEventListener('mousedown', handler);
      document.removeEventListener('contextmenu', handler);
    };
  }, [onClose]);

  // Adjust position to stay in viewport
  const style = {
    position: 'fixed',
    top: y,
    left: x,
    zIndex: 9999,
    background: 'var(--bg-surface)',
    border: '1px solid var(--border-primary)',
    borderRadius: 4,
    boxShadow: '0 4px 12px rgba(0,0,0,0.2)',
    padding: '4px 0',
    minWidth: 140,
    fontSize: '0.8rem',
  };

  return (
    <div ref={menuRef} style={style}>
      <div
        className="ctx-menu-item"
        style={{
          padding: '6px 12px',
          cursor: 'pointer',
          color: 'var(--badge-error-text)',
          display: 'flex',
          alignItems: 'center',
          gap: 6,
        }}
        onMouseEnter={(e) => e.currentTarget.style.background = 'var(--bg-surface-alt)'}
        onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
        onClick={() => { onDelete(itemPath, itemType); onClose(); }}
      >
        <span style={{ fontSize: '0.75rem' }}>{'\u{1F5D1}'}</span>
        Delete {itemType === 'directory' ? 'Folder' : 'File'}
      </div>
    </div>
  );
}

export default function Workspace() {
  const [tree, setTree] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [openTabs, setOpenTabs] = useState([]);
  const [activeTabIndex, setActiveTabIndex] = useState(-1);
  const isNarrow = useIsNarrow();
  const [showPreview, setShowPreview] = useState(false);
  const [browseRoot, setBrowseRoot] = useState('workspace');

  // Upload state
  const [uploads, setUploads] = useState([]);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef(null);
  // Track selected directory for upload target
  const [selectedDir, setSelectedDir] = useState('');

  // Context menu state
  const [contextMenu, setContextMenu] = useState(null);
  // Delete confirmation
  const [deleteConfirm, setDeleteConfirm] = useState(null);

  const activeTab = activeTabIndex >= 0 ? openTabs[activeTabIndex] : null;
  const selectedFile = activeTab?.path || null;
  const fileContent = activeTab?.content ?? null;
  const fileMeta = activeTab?.meta || null;
  const fileLoading = activeTab?.loading || false;

  const rootParam = browseRoot === 'workspace' ? '' : `&root=${browseRoot}`;
  const rootQuery = browseRoot === 'workspace' ? '' : `?root=${browseRoot}`;

  const refreshTree = useCallback(() => {
    authFetch(`/api/openclaw/workspace/tree${rootQuery}`)
      .then((r) => r.json())
      .then((data) => {
        setTree(data.tree || data);
      })
      .catch(() => {});
  }, [rootQuery]);

  useEffect(() => {
    setLoading(true);
    setTree(null);
    setOpenTabs([]);
    setActiveTabIndex(-1);
    setSelectedDir('');
    authFetch(`/api/openclaw/workspace/tree${rootQuery}`)
      .then((r) => r.json())
      .then((data) => {
        setTree(data.tree || data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, [browseRoot]);

  const loadFile = useCallback(async (filePath) => {
    const currentTabs = openTabs;
    const existingIndex = currentTabs.findIndex((t) => t.path === filePath);

    if (existingIndex >= 0) {
      setActiveTabIndex(existingIndex);
      if (currentTabs[existingIndex].content !== null || currentTabs[existingIndex].loading) return;
      setOpenTabs((prev) =>
        prev.map((t, i) => (i === existingIndex ? { ...t, loading: true, error: null } : t))
      );
    } else {
      const newTab = { path: filePath, content: null, meta: null, loading: true, error: null };
      setOpenTabs((prev) => {
        const newTabs = [...prev, newTab];
        setActiveTabIndex(newTabs.length - 1);
        return newTabs;
      });
    }

    try {
      const res = await authFetch(`/api/openclaw/workspace/file?path=${encodeURIComponent(filePath)}${rootParam}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || data.message || 'Failed to load file');
      const meta = {
        size: data.size,
        modified: data.modified,
        extension: data.extension,
        mimeType: data.mimeType,
        isPreviewable: data.isPreviewable,
        reason: data.reason,
        name: data.name,
      };
      setOpenTabs((prev) =>
        prev.map((t) => (t.path === filePath ? { ...t, content: data.content, meta, loading: false } : t))
      );
    } catch (err) {
      setOpenTabs((prev) =>
        prev.map((t) => (t.path === filePath ? { ...t, content: `Error: ${err.message}`, loading: false, error: err.message } : t))
      );
    }
  }, [openTabs, rootParam]);

  const closeTab = useCallback((index) => {
    setOpenTabs((prev) => {
      const newTabs = prev.filter((_, i) => i !== index);
      setActiveTabIndex((prevActive) => {
        if (newTabs.length === 0) return -1;
        if (index === prevActive) return Math.min(index, newTabs.length - 1);
        if (index < prevActive) return prevActive - 1;
        return prevActive;
      });
      return newTabs;
    });
  }, []);

  // Delete handler
  const handleDelete = useCallback((itemPath, itemType) => {
    setDeleteConfirm({ path: itemPath, type: itemType });
  }, []);

  const confirmDelete = useCallback(async () => {
    if (!deleteConfirm) return;
    try {
      const res = await authFetch(`/api/openclaw/workspace/delete?path=${encodeURIComponent(deleteConfirm.path)}${rootParam}`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Delete failed');
      // Close any tabs for deleted file/folder
      setOpenTabs((prev) => {
        const newTabs = prev.filter((t) => {
          if (deleteConfirm.type === 'directory') {
            return !t.path.startsWith(deleteConfirm.path + '/') && t.path !== deleteConfirm.path;
          }
          return t.path !== deleteConfirm.path;
        });
        if (newTabs.length !== prev.length) {
          setActiveTabIndex((idx) => Math.min(idx, Math.max(newTabs.length - 1, -1)));
        }
        return newTabs;
      });
      refreshTree();
    } catch (err) {
      // Could show error but for now just log
      console.error('Delete failed:', err.message);
    } finally {
      setDeleteConfirm(null);
    }
  }, [deleteConfirm, rootParam, refreshTree]);

  // Upload handler
  const handleUpload = useCallback((fileList) => {
    if (!fileList || fileList.length === 0) return;

    const files = Array.from(fileList);

    // Client-side validation
    const tooLarge = files.filter((f) => f.size > MAX_UPLOAD_SIZE);
    if (tooLarge.length > 0) {
      const uploadEntries = files.map((f) => ({
        name: f.name,
        size: f.size,
        progress: 0,
        status: f.size > MAX_UPLOAD_SIZE ? 'error' : 'pending',
        message: f.size > MAX_UPLOAD_SIZE ? `Exceeds 10MB limit (${formatSize(f.size)})` : null,
        md5: null,
      }));
      setUploads(uploadEntries);
      setShowUploadModal(true);

      // Filter valid files
      const validFiles = files.filter((f) => f.size <= MAX_UPLOAD_SIZE);
      if (validFiles.length === 0) return;

      // Continue with valid files only
      doUpload(validFiles, uploadEntries);
      return;
    }

    const uploadEntries = files.map((f) => ({
      name: f.name,
      size: f.size,
      progress: 0,
      status: 'pending',
      message: null,
      md5: null,
    }));
    setUploads(uploadEntries);
    setShowUploadModal(true);
    doUpload(files, uploadEntries);
  }, [selectedDir, refreshTree, browseRoot]);

  const doUpload = useCallback((files, uploadEntries) => {
    // Mark all valid as uploading
    setUploads((prev) =>
      prev.map((u) => (u.status === 'pending' ? { ...u, status: 'uploading' } : u))
    );

    const formData = new FormData();
    formData.append('targetDir', selectedDir);
    formData.append('root', browseRoot);
    files.forEach((f) => formData.append('files[]', f));

    const xhr = new XMLHttpRequest();

    xhr.upload.addEventListener('progress', (e) => {
      if (e.lengthComputable) {
        const pct = Math.round((e.loaded / e.total) * 100);
        setUploads((prev) =>
          prev.map((u) => (u.status === 'uploading' ? { ...u, progress: pct } : u))
        );
      }
    });

    xhr.addEventListener('load', () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          const results = JSON.parse(xhr.responseText);
          setUploads((prev) =>
            prev.map((u) => {
              if (u.status === 'error') return u; // already failed (too large)
              const result = results.find((r) => r.name === u.name);
              if (!result) return { ...u, status: 'error', progress: 100, message: 'No result from server' };
              if (result.status === 'ok') {
                return { ...u, status: 'done', progress: 100, md5: result.md5 };
              }
              return { ...u, status: 'error', progress: 100, message: result.message };
            })
          );
          refreshTree();
        } catch {
          setUploads((prev) =>
            prev.map((u) => (u.status !== 'error' ? { ...u, status: 'error', progress: 100, message: 'Invalid server response' } : u))
          );
        }
      } else {
        let msg = 'Upload failed';
        try { msg = JSON.parse(xhr.responseText).message || msg; } catch {}
        setUploads((prev) =>
          prev.map((u) => (u.status !== 'error' ? { ...u, status: 'error', progress: 100, message: msg } : u))
        );
      }
    });

    xhr.addEventListener('error', () => {
      setUploads((prev) =>
        prev.map((u) => (u.status !== 'error' ? { ...u, status: 'error', progress: 100, message: 'Network error' } : u))
      );
    });

    // Get auth token for the request
    const token = localStorage.getItem('launcher_token') || sessionStorage.getItem('launcher_token');
    xhr.open('POST', '/api/openclaw/workspace/upload');
    if (token) xhr.setRequestHeader('Authorization', `Bearer ${token}`);
    xhr.send(formData);
  }, [selectedDir, refreshTree, browseRoot]);

  // Drag and drop handlers
  const handleDragOver = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOver(false);
  }, []);

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOver(false);
    if (e.dataTransfer.files?.length > 0) {
      handleUpload(e.dataTransfer.files);
    }
  }, [handleUpload]);

  // Right-click handler for tree items
  const handleTreeContextMenu = useCallback((e, itemPath, itemType) => {
    e.preventDefault();
    e.stopPropagation();
    setContextMenu({ x: e.clientX, y: e.clientY, path: itemPath, type: itemType });
  }, []);

  const isMarkdown = (name) => /\.md$/i.test(name);
  const isHtml = (name) => /\.html?$/i.test(name);

  const pathParts = useMemo(() => {
    if (!selectedFile) return [];
    return selectedFile.split('/').filter(Boolean);
  }, [selectedFile]);

  const fileName = pathParts.length > 0 ? pathParts[pathParts.length - 1] : null;

  const lineCount = useMemo(() => {
    if (!fileContent || isMarkdown(selectedFile || '')) return 0;
    return fileContent.split('\n').length;
  }, [fileContent, selectedFile]);

  if (loading) {
    return (
      <div className="ide-layout">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 1, gap: 12, color: '#717171' }}>
          <span className="spinner" />
          <span>Loading workspace...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="ide-layout">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 1 }}>
          <div className="error-container">{error}</div>
        </div>
      </div>
    );
  }

  const closeFile = () => {
    if (activeTabIndex >= 0) closeTab(activeTabIndex);
  };

  const rootLabel = ROOT_OPTIONS[browseRoot]?.label || 'workspace';

  const handleDownload = () => {
    if (fileContent) {
      const blob = new Blob([fileContent], { type: 'application/octet-stream' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      a.click();
      URL.revokeObjectURL(url);
    } else {
      // For non-previewable files, use the download endpoint
      const url = `/api/openclaw/workspace/download?path=${encodeURIComponent(selectedFile)}${rootParam}`;
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      a.click();
    }
  };

  // Check if current file is non-previewable
  const isNonPreviewable = fileMeta && fileMeta.isPreviewable === false;
  const nonPreviewReason = fileMeta?.reason;

  const editorPanel = (
    <div className="ide-editor">
      {/* Tab bar */}
      <div className="ide-tabs">
        {openTabs.map((tab, i) => {
          const tabName = tab.path.split('/').filter(Boolean).pop();
          return (
            <div
              key={tab.path}
              className={`ide-tab ${i === activeTabIndex ? 'active' : ''}`}
              onClick={() => { setActiveTabIndex(i); setShowPreview(false); }}
              title={tab.path}
            >
              <span className="ide-tab-icon" style={{ fontSize: '0.7rem' }}>
                {getFileIcon(tabName).icon}
              </span>
              <span className="ide-tab-name">{tabName}</span>
              <span
                className="ide-tab-close"
                onClick={(e) => {
                  e.stopPropagation();
                  closeTab(i);
                }}
              >
                {'\u2715'}
              </span>
            </div>
          );
        })}
      </div>

      {/* Breadcrumb bar */}
      {selectedFile && (
        <div className="ide-breadcrumbs">
          <div className="ide-breadcrumbs-path">
            <span className="ide-breadcrumb-link" onClick={closeFile}>
              {rootLabel}
            </span>
            {pathParts.map((part, i) => (
              <React.Fragment key={i}>
                <span className="ide-breadcrumb-sep">{'\u203A'}</span>
                <span className={i === pathParts.length - 1 ? 'ide-breadcrumb-current' : 'ide-breadcrumb-link'}>
                  {part}
                </span>
              </React.Fragment>
            ))}
          </div>
          <div className="ide-breadcrumbs-actions">
            {isHtml(selectedFile) && !fileLoading && !activeTab?.error && !isNonPreviewable && (
              <button
                className="ide-action-btn"
                onClick={() => setShowPreview((p) => !p)}
                title={showPreview ? 'Show source' : 'Preview HTML'}
              >
                {showPreview ? '</>' : '\u25B6 Preview'}
              </button>
            )}
            {!fileLoading && !activeTab?.error && (
              <button
                className="ide-action-btn"
                onClick={handleDownload}
                title="Download file"
              >
                &#8615; Download
              </button>
            )}
          </div>
        </div>
      )}

      {/* Content */}
      <div className="ide-content">
        {fileLoading ? (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', gap: 12, color: '#717171' }}>
            <span className="spinner" />
            <span>Loading...</span>
          </div>
        ) : isNonPreviewable ? (
          <NonPreviewableCard
            meta={fileMeta}
            reason={nonPreviewReason}
            onDownload={handleDownload}
          />
        ) : fileContent !== null ? (
          showPreview && isHtml(selectedFile) ? (
            <iframe
              className="ide-html-preview"
              srcDoc={fileContent}
              title="HTML Preview"
              sandbox="allow-scripts"
            />
          ) : isMarkdown(selectedFile) ? (
            <div className="ide-markdown">
              <Markdown components={{
                code({ className, children, ...props }) {
                  const match = /language-(\w+)/.exec(className || '');
                  const lang = match ? match[1] : null;
                  const isInline = !className;
                  if (isInline) {
                    return <code className={className} {...props}>{children}</code>;
                  }
                  return (
                    <HighlightedCode code={String(children).replace(/\n$/, '')} language={lang} />
                  );
                }
              }}>{fileContent}</Markdown>
            </div>
          ) : (
            <div className="ide-code-view">
              <div className="ide-line-numbers">
                <div className="ide-gutter">
                  {fileContent.split('\n').map((_, i) => (
                    <div key={i}>{i + 1}</div>
                  ))}
                </div>
                <div className="ide-code-body">
                  <pre><HighlightedCode code={fileContent} language={getHljsLanguage(selectedFile || '')} /></pre>
                </div>
              </div>
            </div>
          )
        ) : (
          <div className="ide-welcome">
            <div className="ide-welcome-logo">&gt;_</div>
            <div className="ide-welcome-title">OpenClaw Workspace</div>
            <div className="ide-welcome-hint">Select a file from the explorer to view its contents</div>
          </div>
        )}
      </div>

      {/* Status bar */}
      <div className="ide-statusbar">
        <div className="ide-statusbar-left">
          {selectedFile && (
            <>
              <span className="ide-statusbar-item">{getFileLanguage(fileName)}</span>
              {lineCount > 0 && <span className="ide-statusbar-item">{lineCount} lines</span>}
              {fileMeta?.size !== undefined && (
                <span className="ide-statusbar-item">{formatSize(fileMeta.size)}</span>
              )}
            </>
          )}
          {!selectedFile && <span className="ide-statusbar-item">Ready</span>}
        </div>
        <div className="ide-statusbar-right">
          <span className="ide-statusbar-item">UTF-8</span>
          <span className="ide-statusbar-item">{ROOT_OPTIONS[browseRoot]?.path || '~/.openclaw/workspace'}</span>
        </div>
      </div>
    </div>
  );

  return (
    <div className="ide-layout">
      {/* Explorer Panel with drag-and-drop */}
      <div
        className={`ide-explorer ${dragOver ? 'drag-over' : ''}`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <div className="ide-explorer-header">
          <select
            value={browseRoot}
            onChange={(e) => setBrowseRoot(e.target.value)}
            style={{
              background: 'transparent',
              border: 'none',
              color: 'inherit',
              fontSize: 'inherit',
              fontWeight: 'inherit',
              cursor: 'pointer',
              padding: 0,
              outline: 'none',
              appearance: 'none',
              WebkitAppearance: 'none',
            }}
            title="Browse root"
          >
            <option value="workspace">workspace</option>
            <option value="openclaw">.openclaw</option>
          </select>
          <button
            className="ide-root-switch-btn"
            onClick={() => setBrowseRoot(browseRoot === 'workspace' ? 'openclaw' : 'workspace')}
            title={`Switch to ${browseRoot === 'workspace' ? '.openclaw' : 'workspace'}`}
          >{'\u21C5'}</button>
          <div style={{ flex: 1 }} />
          <button
            className="ide-upload-btn"
            onClick={() => fileInputRef.current?.click()}
            title="Upload files"
          >
            {'\u2B06'} Upload
          </button>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            style={{ display: 'none' }}
            onChange={(e) => {
              handleUpload(e.target.files);
              e.target.value = '';
            }}
          />
        </div>

        {/* Drag overlay */}
        {dragOver && (
          <div className="ide-drag-overlay">
            <div className="ide-drag-overlay-text">
              <span>{'\u{1F4C1}'}</span>
              <span>Drop files to upload</span>
            </div>
          </div>
        )}

        <div className="ide-explorer-tree">
          {tree && tree.length > 0 ? (
            <IDETreeNode
              node={tree}
              onSelect={loadFile}
              onDirSelect={setSelectedDir}
              selectedFile={selectedFile}
              onContextMenu={handleTreeContextMenu}
              depth={0}
              prefix=""
            />
          ) : (
            <div style={{ padding: '16px 12px', color: '#999', fontSize: '0.8rem' }}>
              No files found
            </div>
          )}
        </div>
      </div>

      {/* On narrow screens, show editor as a popup overlay; on wide screens, show inline */}
      {isNarrow ? (
        openTabs.length > 0 && (
          <div className="ide-editor-overlay" onClick={closeFile}>
            <div className="ide-editor-popup" onClick={(e) => e.stopPropagation()}>
              {editorPanel}
            </div>
          </div>
        )
      ) : (
        editorPanel
      )}

      {/* Upload progress modal */}
      {showUploadModal && (
        <UploadProgressModal
          uploads={uploads}
          onClose={() => setShowUploadModal(false)}
        />
      )}

      {/* Right-click context menu */}
      {contextMenu && (
        <TreeContextMenu
          x={contextMenu.x}
          y={contextMenu.y}
          itemPath={contextMenu.path}
          itemType={contextMenu.type}
          onDelete={handleDelete}
          onClose={() => setContextMenu(null)}
        />
      )}

      {/* Delete confirmation dialog */}
      {deleteConfirm && (
        <div className="upload-modal-overlay" onClick={() => setDeleteConfirm(null)}>
          <div className="upload-modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 400 }}>
            <div className="upload-modal-header">
              <span>Confirm Delete</span>
            </div>
            <div className="upload-modal-body" style={{ padding: '16px 20px' }}>
              <p style={{ margin: '0 0 16px', fontSize: '0.85rem', lineHeight: 1.5 }}>
                Are you sure you want to delete <strong>{deleteConfirm.path}</strong>?
                {deleteConfirm.type === 'directory' && (
                  <span style={{ display: 'block', marginTop: 6, color: 'var(--badge-error-text)', fontSize: '0.8rem' }}>
                    This will delete the folder and all its contents.
                  </span>
                )}
              </p>
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
                <button className="btn btn-secondary btn-sm" onClick={() => setDeleteConfirm(null)}>
                  Cancel
                </button>
                <button
                  className="btn btn-sm"
                  style={{ background: 'var(--badge-error-bg)', color: 'var(--badge-error-text)', border: '1px solid var(--badge-error-text)' }}
                  onClick={confirmDelete}
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function IDETreeNode({ node, onSelect, onDirSelect, selectedFile, onContextMenu, depth, prefix }) {
  const [expanded, setExpanded] = useState(false);

  if (!node) return null;

  if (Array.isArray(node)) {
    const sorted = [...node].sort((a, b) => {
      const aDir = a.type === 'directory' || a.children;
      const bDir = b.type === 'directory' || b.children;
      if (aDir && !bDir) return -1;
      if (!aDir && bDir) return 1;
      return a.name.localeCompare(b.name);
    });
    return sorted.map((item, i) => (
      <IDETreeNode key={item.name || i} node={item} onSelect={onSelect} onDirSelect={onDirSelect} selectedFile={selectedFile} onContextMenu={onContextMenu} depth={depth} prefix={prefix} />
    ));
  }

  const isDir = node.type === 'directory' || node.children;
  const fullPath = prefix ? `${prefix}/${node.name}` : node.name;
  const indentPx = depth * 16 + 4;

  if (isDir) {
    const children = node.children || [];
    return (
      <div>
        <div
          className="ide-tree-item"
          style={{ paddingLeft: indentPx }}
          onClick={() => {
            setExpanded(!expanded);
            onDirSelect(fullPath);
          }}
          onContextMenu={(e) => onContextMenu(e, fullPath, 'directory')}
        >
          <span className="ide-tree-chevron">{expanded ? '\u25BE' : '\u25B8'}</span>
          <span className={`ide-tree-icon folder-icon`} style={{ fontSize: '0.8rem' }}>
            {expanded ? '\u{1F4C2}' : '\u{1F4C1}'}
          </span>
          <span className="ide-tree-name">{node.name}</span>
        </div>
        {expanded && children.length > 0 && (
          <div className="ide-tree-children">
            <IDETreeNode node={children} onSelect={onSelect} onDirSelect={onDirSelect} selectedFile={selectedFile} onContextMenu={onContextMenu} depth={depth + 1} prefix={fullPath} />
          </div>
        )}
      </div>
    );
  }

  const { icon, className } = getFileIcon(node.name);

  return (
    <div
      className={`ide-tree-item ${selectedFile === fullPath ? 'selected' : ''}`}
      style={{ paddingLeft: indentPx + 16 }}
      onClick={() => onSelect(fullPath)}
      onContextMenu={(e) => onContextMenu(e, fullPath, 'file')}
    >
      <span className={`ide-tree-icon ${className}`} style={{ fontSize: '0.7rem' }}>
        {icon}
      </span>
      <span className="ide-tree-name">{node.name}</span>
    </div>
  );
}

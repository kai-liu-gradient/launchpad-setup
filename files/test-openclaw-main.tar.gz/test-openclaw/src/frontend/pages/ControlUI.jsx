import React, { useEffect, useState, useCallback } from 'react';
import { useAppConfig } from '../context/AppConfigContext';
import { authFetch } from '../hooks/useAuth';

const SETTINGS_KEY = 'openclaw.control.settings.v1';

function injectGatewayToken(token) {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    const settings = raw ? JSON.parse(raw) : {};
    if (settings.token === token) return;
    settings.token = token;
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    // best-effort
  }
}

export default function ControlUI() {
  const { configStatus } = useAppConfig();
  // fixState: null | 'detected' | 'confirming' | 'fixing' | 'fixed' | 'error'
  //           | 'stale_detected' | 'restoring' | 'restored' | 'manage_fix'
  const [fixState, setFixState] = useState(null);
  const [fixMessage, setFixMessage] = useState('');
  const [staleTmpRoot, setStaleTmpRoot] = useState('');
  const [tmpFixActive, setTmpFixActive] = useState(false);

  const checkControlUi = useCallback(() => {
    authFetch('/api/openclaw/gateway/control-ui-check')
      .then(r => r.json())
      .then(data => {
        if (data.status === 'active_tmp') {
          setTmpFixActive(true);
          setStaleTmpRoot(data.controlUiRoot || '');
        } else if (data.status === 'stale_tmp') {
          setTmpFixActive(false);
          setFixState('stale_detected');
          setStaleTmpRoot(data.controlUiRoot || '');
        } else if ((data.status === 'error_page' || data.status === '404') && data.eligible) {
          setTmpFixActive(false);
          setFixState('detected');
        } else {
          setTmpFixActive(false);
        }
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    // Refresh gateway_ws_session cookie before loading the iframe — required for WS upgrades
    authFetch('/api/openclaw/gateway-ws-session', { method: 'POST' }).catch(() => {});

    // Inject gateway token into localStorage for the Control UI iframe
    authFetch('/api/openclaw/config/gateway-token')
      .then((r) => r.json())
      .then((data) => { if (data.token) injectGatewayToken(data.token); })
      .catch(() => {});

    // Auto-approve pending device pairing requests so the Control UI can
    // connect without manual intervention. The pairing request is created
    // when the iframe first connects, so we poll a few times to catch it.
    const autoPair = () => authFetch('/api/openclaw/gateway/auto-pair', { method: 'POST' }).catch(() => {});
    autoPair();
    const t1 = setTimeout(autoPair, 3000);
    const t2 = setTimeout(autoPair, 8000);
    const t3 = setTimeout(autoPair, 15000);

    // Check for control UI loading issue after a brief delay to let the iframe attempt to load
    const t4 = setTimeout(checkControlUi, 2000);

    // Periodically refresh gateway_ws_session cookie (every 20 min) to keep WS auth alive
    const refreshInterval = setInterval(() => {
      authFetch('/api/openclaw/gateway-ws-session', { method: 'POST' }).catch(() => {});
    }, 20 * 60 * 1000);

    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); clearTimeout(t4); clearInterval(refreshInterval); };
  }, [checkControlUi]);

  const applyFix = useCallback(() => {
    setFixState('fixing');
    setFixMessage('Applying fix... This may take up to 30 seconds while the gateway restarts.');
    authFetch('/api/openclaw/gateway/control-ui-fix', { method: 'POST' })
      .then(r => r.json())
      .then(data => {
        if (data.success) {
          setFixState('fixed');
          setFixMessage('Fix applied successfully! Reloading...');
          setTimeout(() => window.location.reload(), 1500);
        } else {
          setFixState('error');
          setFixMessage(data.message || data.error || 'Fix was applied but the gateway may need more time. Try refreshing the page.');
        }
      })
      .catch(err => {
        setFixState('error');
        setFixMessage(`Failed to apply fix: ${err.message}`);
      });
  }, []);

  const restoreOriginalConfig = useCallback(() => {
    setFixState('restoring');
    setFixMessage('Restoring original config and restarting gateway...');
    authFetch('/api/openclaw/gateway/control-ui-restore', { method: 'POST' })
      .then(r => r.json())
      .then(data => {
        if (data.success) {
          setFixState('restored');
          setFixMessage('Config restored! Reloading...');
          setTimeout(() => window.location.reload(), 1500);
        } else {
          setFixState('error');
          setFixMessage(data.message || data.error || 'Restore failed. Try again or redo the fix.');
        }
      })
      .catch(err => {
        setFixState('error');
        setFixMessage(`Failed to restore: ${err.message}`);
      });
  }, []);

  // Show modal when any fix state is active (except cleared states)
  const showFixDialog = fixState && fixState !== 'fixed' && fixState !== 'restored';

  // Dialog title varies by state
  const dialogTitle = fixState === 'error' ? 'Error'
    : fixState === 'manage_fix' ? 'Temporary Fix Active'
    : 'Control UI Issue Detected';

  return (
    <div className="control-ui-page">
      <div className="control-ui-header">
        <div className="control-ui-title">
          <span>Control UI</span>
          <span className="control-ui-badge">Gateway</span>
        </div>
        <div className="control-ui-header-right">
          {tmpFixActive && !showFixDialog && (
            <button
              className="control-ui-tmpfix-badge"
              onClick={() => setFixState('manage_fix')}
              title="Temporary fix applied — click to manage"
            >
              <span className="control-ui-tmpfix-icon">&#x26A0;</span>
              <span className="control-ui-tmpfix-label">Temporary fix applied</span>
            </button>
          )}
          <a
            href="/gateway/"
            target="_blank"
            rel="noopener noreferrer"
            className="control-ui-open-btn"
            title="Open in New Tab"
          >
            <span className="control-ui-open-label">Open in New Tab</span>
            <span className="control-ui-open-icon">&#x2197;</span>
          </a>
        </div>
      </div>
      {showFixDialog && (
        <div className="control-ui-fix-overlay">
          <div className="control-ui-fix-dialog">
            <div className="control-ui-fix-header">
              {dialogTitle}
              <button
                className="control-ui-fix-close"
                onClick={() => { setFixState(null); if (fixState === 'error') checkControlUi(); }}
                title="Dismiss"
              >&times;</button>
            </div>
            <div className={`control-ui-fix-body${fixState === 'error' ? ' control-ui-fix-error' : ''}`}>
              {fixState === 'detected' && (
                <><strong>Control UI is not loading.</strong> This may be caused by a known hardlink issue in OpenClaw. Would you like to apply a quick fix?</>
              )}
              {fixState === 'confirming' && (
                <>This will copy the Control UI files to a temporary location and update your gateway config to serve from there, then restart the gateway.</>
              )}
              {fixState === 'stale_detected' && (
                <>
                  <strong>Previous fix has expired.</strong> Your config points to <code>{staleTmpRoot}</code> which no longer exists (likely cleaned up after a reboot).
                  <br /><br />
                  You can <strong>restore the original config</strong> and restart the gateway to check if the issue has been resolved in a newer version, or <strong>redo the fix</strong> to copy the files again.
                </>
              )}
              {fixState === 'manage_fix' && (
                <>
                  Your config is currently using a temporary fix, serving Control UI from <code>{staleTmpRoot}</code>. This will need to be reapplied after a reboot.
                  <br /><br />
                  You can <strong>restore the original config</strong> to test if the issue has been resolved in a newer OpenClaw version, or <strong>redo the fix</strong> to refresh the temporary files.
                </>
              )}
              {(fixState === 'fixing' || fixState === 'restoring') && (
                <><span className="control-ui-fix-spinner" /> {fixMessage}</>
              )}
              {fixState === 'error' && fixMessage}
            </div>
            <div className="control-ui-fix-actions">
              {fixState === 'detected' && (
                <>
                  <button className="btn btn-secondary" onClick={() => setFixState(null)}>Dismiss</button>
                  <button className="btn btn-primary" onClick={() => setFixState('confirming')}>Apply Quick Fix</button>
                </>
              )}
              {fixState === 'confirming' && (
                <>
                  <button className="btn btn-secondary" onClick={() => setFixState(null)}>Cancel</button>
                  <button className="btn btn-primary" onClick={applyFix}>Yes, Fix It</button>
                </>
              )}
              {(fixState === 'stale_detected' || fixState === 'manage_fix') && (
                <>
                  <button className="btn btn-secondary" onClick={() => setFixState(null)}>Dismiss</button>
                  <button className="btn btn-secondary" onClick={restoreOriginalConfig}>Restore Original</button>
                  <button className="btn btn-primary" onClick={applyFix}>Redo Fix</button>
                </>
              )}
              {fixState === 'error' && (
                <button className="btn btn-secondary" onClick={() => { setFixState(null); checkControlUi(); }}>Dismiss</button>
              )}
            </div>
          </div>
        </div>
      )}
      <iframe
        className="control-ui-frame"
        src="/gateway/"
        title="OpenClaw Control UI"
        sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
      />
    </div>
  );
}

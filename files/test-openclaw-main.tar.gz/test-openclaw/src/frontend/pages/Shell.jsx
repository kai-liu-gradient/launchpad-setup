import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Terminal as XTerm } from '@xterm/xterm';
import { FitAddon } from '@xterm/addon-fit';
import '@xterm/xterm/css/xterm.css';
import { authFetch, getToken } from '../hooks/useAuth';
import { setSystemStats } from '../systemStatsStore';

const HEARTBEAT_INTERVAL = 5000; // Send ping every 5s

function formatMB(mb) {
  if (mb >= 1024) return (mb / 1024).toFixed(1) + ' GB';
  return mb + ' MB';
}

const AUTO_RECONNECT_DELAYS = [1000, 2000, 4000, 8000]; // Backoff delays in ms

export default function Shell({ visible, onStatusChange, skipTui = false }) {
  const termRef = useRef(null);
  const xtermRef = useRef(null);
  const wsRef = useRef(null);
  const fitRef = useRef(null);
  const heartbeatRef = useRef(null);
  const autoReconnectRef = useRef(null);
  const reconnectAttemptRef = useRef(0);
  const intentionalCloseRef = useRef(false);
  const skipTuiRef = useRef(skipTui);
  const [status, setStatus] = useState('connecting');
  const [disconnectInfo, setDisconnectInfo] = useState(null);
  const [latency, setLatency] = useState(null);
  const [resources, setResources] = useState(null);

  const stopHeartbeat = useCallback(() => {
    if (heartbeatRef.current) {
      clearInterval(heartbeatRef.current);
      heartbeatRef.current = null;
    }
  }, []);

  const startHeartbeat = useCallback((ws) => {
    stopHeartbeat();
    heartbeatRef.current = setInterval(() => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'ping', ts: Date.now() }));
      }
    }, HEARTBEAT_INTERVAL);
  }, [stopHeartbeat]);

  const connect = useCallback(async () => {
    if (!termRef.current) return;

    // Cancel any pending auto-reconnect
    if (autoReconnectRef.current) {
      clearTimeout(autoReconnectRef.current);
      autoReconnectRef.current = null;
    }
    intentionalCloseRef.current = false;

    // Clean up previous terminal instance if reconnecting
    stopHeartbeat();
    if (xtermRef.current) {
      if (xtermRef.current._resizeObserver) {
        xtermRef.current._resizeObserver.disconnect();
      }
      xtermRef.current.dispose();
      xtermRef.current = null;
    }
    if (wsRef.current) {
      intentionalCloseRef.current = true;
      wsRef.current.close();
      wsRef.current = null;
    }

    // Clear the terminal container for fresh mount
    while (termRef.current.firstChild) {
      termRef.current.removeChild(termRef.current.firstChild);
    }

    const isMobile = window.matchMedia('(max-width: 768px)').matches;
    const term = new XTerm({
      cursorBlink: true,
      fontSize: isMobile ? 11 : 14,
      fontFamily: '"Cascadia Code", "Fira Code", "JetBrains Mono", "Courier New", monospace',
      theme: {
        background: '#0d1117',
        foreground: '#c9d1d9',
        cursor: '#58a6ff',
        selectionBackground: '#264f78',
        black: '#0d1117',
        red: '#ff7b72',
        green: '#3fb950',
        yellow: '#d29922',
        blue: '#58a6ff',
        magenta: '#bc8cff',
        cyan: '#39d353',
        white: '#c9d1d9',
      },
    });

    const fitAddon = new FitAddon();
    term.loadAddon(fitAddon);
    term.open(termRef.current);
    fitAddon.fit();

    xtermRef.current = term;
    fitRef.current = fitAddon;

    // Show connecting feedback
    setStatus('connecting');
    setDisconnectInfo(null);

    // Fetch terminal access token
    let shellToken;
    try {
      const tokenRes = await authFetch('/api/openclaw/shell/token');
      if (!tokenRes.ok) throw new Error('Failed to get terminal token');
      const tokenData = await tokenRes.json();
      shellToken = tokenData.token;
    } catch (err) {
      setStatus('error');
      term.write(`\r\n\x1b[31mAuthentication failed: ${err.message}\x1b[0m\r\n`);
      return;
    }

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const launcherToken = getToken();
    const ws = new WebSocket(`${protocol}//${window.location.host}/api/openclaw/shell/ws?token=${shellToken}&launcher_token=${launcherToken}`);
    wsRef.current = ws;

    ws.onopen = () => {
      setStatus('connected');
      setLatency(null);
      setResources(null);
      reconnectAttemptRef.current = 0;
      intentionalCloseRef.current = false;
      ws.send(JSON.stringify({ type: 'resize', cols: term.cols, rows: term.rows }));
      // Auto-launch openclaw TUI unless in terminal-only mode
      if (!skipTuiRef.current) {
        ws.send(JSON.stringify({ type: 'input', data: 'openclaw tui\n' }));
      }
      // Send first ping immediately, then start recurring heartbeat
      ws.send(JSON.stringify({ type: 'ping', ts: Date.now() }));
      startHeartbeat(ws);
    };

    ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        if (msg.type === 'output') {
          term.write(msg.data);
        } else if (msg.type === 'pong' && msg.ts) {
          setLatency(Date.now() - msg.ts);
          if (msg.resources) {
            setResources(msg.resources);
            setSystemStats(msg.resources);
          }
        }
      } catch {
        // Ignore malformed messages
      }
    };

    ws.onclose = (event) => {
      stopHeartbeat();
      setLatency(null);
      setResources(null);
      // code 1000 = normal closure (e.g. shell process exited)
      // code 1006 = abnormal closure (network drop, server killed connection)
      const now = new Date().toLocaleTimeString();
      const info = { time: now, code: event.code, reason: event.reason || '' };
      if (event.code === 1000) {
        setStatus('disconnected');
      } else {
        setStatus('error');
        // Auto-reconnect on unexpected disconnection (not intentional close)
        if (!intentionalCloseRef.current) {
          const attempt = reconnectAttemptRef.current;
          const delay = AUTO_RECONNECT_DELAYS[Math.min(attempt, AUTO_RECONNECT_DELAYS.length - 1)];
          info.reason = (info.reason ? info.reason + ' · ' : '') + `reconnecting in ${(delay / 1000).toFixed(0)}s...`;
          autoReconnectRef.current = setTimeout(() => {
            reconnectAttemptRef.current += 1;
            connect();
          }, delay);
        }
      }
      setDisconnectInfo(info);
      term.write('\r\n\x1b[90m[Session ended');
      if (event.code !== 1000) {
        term.write(` — code ${event.code}`);
      }
      term.write(` at ${now}]\x1b[0m\r\n`);
    };

    ws.onerror = () => {
      const now = new Date().toLocaleTimeString();
      setDisconnectInfo({ time: now, code: null, reason: 'WebSocket error' });
      setStatus('error');
    };

    term.onData((data) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'input', data }));
      }
    });

    const handleResize = () => {
      fitAddon.fit();
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'resize', cols: term.cols, rows: term.rows }));
      }
    };

    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(termRef.current);

    // Store cleanup reference
    term._resizeObserver = resizeObserver;
  }, [startHeartbeat, stopHeartbeat]);

  useEffect(() => {
    connect();

    return () => {
      stopHeartbeat();
      if (autoReconnectRef.current) {
        clearTimeout(autoReconnectRef.current);
        autoReconnectRef.current = null;
      }
      if (xtermRef.current) {
        if (xtermRef.current._resizeObserver) {
          xtermRef.current._resizeObserver.disconnect();
        }
        xtermRef.current.dispose();
        xtermRef.current = null;
      }
      if (wsRef.current) {
        intentionalCloseRef.current = true;
        wsRef.current.close();
        wsRef.current = null;
      }
    };
  }, [connect]);

  // Reconnect when skipTui mode changes
  useEffect(() => {
    if (skipTuiRef.current !== skipTui) {
      skipTuiRef.current = skipTui;
      reconnectAttemptRef.current = 0;
      connect();
    }
  }, [skipTui, connect]);

  // Notify parent of status changes
  useEffect(() => {
    if (onStatusChange) onStatusChange(status);
  }, [status, onStatusChange]);

  // Re-fit terminal when tab becomes visible again
  useEffect(() => {
    if (visible && fitRef.current && xtermRef.current) {
      // Small delay to let the DOM layout settle after display change
      const timer = setTimeout(() => {
        fitRef.current.fit();
        xtermRef.current.focus();
      }, 50);
      return () => clearTimeout(timer);
    }
  }, [visible]);

  // Adjust font size when crossing mobile/desktop breakpoint (e.g. rotation)
  useEffect(() => {
    const mq = window.matchMedia('(max-width: 768px)');
    const handler = (e) => {
      if (xtermRef.current && fitRef.current) {
        xtermRef.current.options.fontSize = e.matches ? 11 : 14;
        fitRef.current.fit();
      }
    };
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  // Handle mobile virtual keyboard: resize terminal to visible area
  useEffect(() => {
    const vv = window.visualViewport;
    if (!vv) return;
    const handleViewport = () => {
      const page = termRef.current?.closest('.shell-page');
      if (page) {
        // Set page height to visual viewport height to avoid keyboard overlap
        page.style.height = `${vv.height}px`;
      }
      if (fitRef.current && xtermRef.current) {
        fitRef.current.fit();
      }
    };
    vv.addEventListener('resize', handleViewport);
    return () => vv.removeEventListener('resize', handleViewport);
  }, []);

  const disconnect = useCallback(() => {
    // Cancel any pending auto-reconnect
    if (autoReconnectRef.current) {
      clearTimeout(autoReconnectRef.current);
      autoReconnectRef.current = null;
    }
    stopHeartbeat();
    if (wsRef.current) {
      intentionalCloseRef.current = true;
      wsRef.current.close();
      wsRef.current = null;
    }
  }, [stopHeartbeat]);

  const reconnect = useCallback(() => {
    reconnectAttemptRef.current = 0;
    connect();
  }, [connect]);

  return (
    <div className="shell-page">
      <div className="shell-header">
        <div className="shell-title">
          <span>{skipTui ? 'Terminal' : 'OpenClaw Chat'}</span>
        </div>
        <div className="shell-status">
          {status === 'connected' ? (
            <button className="shell-status-btn shell-status-btn-connected" onClick={disconnect} title="Click to disconnect">
              <span className={`shell-status-dot shell-status-${status}`} />
              <span className="shell-status-text">
                connected
                {latency != null && (
                  <span className={`shell-latency ${latency > 200 ? 'shell-latency-high' : latency > 100 ? 'shell-latency-mid' : ''}`}>
                    ({latency} ms)
                  </span>
                )}
                {resources?.memory && (
                  <span className="shell-memory shell-resource-stat" title={`${formatMB(resources.memory.usedMB)} / ${formatMB(resources.memory.totalMB)}`}>
                    MEM {resources.memory.usedPercent}%
                  </span>
                )}
                {resources?.cpu && resources.cpu.usagePercent != null && (
                  <span className="shell-memory shell-resource-stat" title={`${resources.cpu.cores} cores`}>
                    CPU {resources.cpu.usagePercent}%
                  </span>
                )}
              </span>
            </button>
          ) : status === 'connecting' ? (
            <>
              <span className={`shell-status-dot shell-status-${status}`} />
              <span className="shell-status-text">connecting</span>
            </>
          ) : (
            <button className="shell-status-btn shell-status-btn-disconnected" onClick={reconnect} title="Click to reconnect">
              <span className={`shell-status-dot shell-status-${status}`} />
              <span className="shell-status-text">{status}</span>
            </button>
          )}
        </div>
      </div>
      <div className="shell-terminal-wrapper">
        {status === 'connecting' && (
          <div className="shell-connecting-overlay">
            <div className="shell-spinner" />
          </div>
        )}
        {(status === 'disconnected' || status === 'error') && (
          <div className="shell-disconnected-overlay">
            <div className="shell-disconnected-content">
              <div className="shell-disconnected-icon">&#x26A0;</div>
              <div className="shell-disconnected-title">
                {status === 'error' ? 'Connection Lost' : 'Session Ended'}
              </div>
              <div className="shell-disconnected-message">
                {status === 'error'
                  ? 'The terminal connection was interrupted.'
                  : 'The terminal session has ended.'}
              </div>
              {disconnectInfo && (
                <div className="shell-disconnected-details">
                  <span>{disconnectInfo.time}</span>
                  {disconnectInfo.code != null && <span> · code {disconnectInfo.code}</span>}
                  {disconnectInfo.reason && <span> · {disconnectInfo.reason}</span>}
                </div>
              )}
              <button className="shell-reconnect-overlay-btn" onClick={reconnect}>
                Reconnect
              </button>
            </div>
          </div>
        )}
        <div className="shell-terminal" ref={termRef} />
      </div>
    </div>
  );
}

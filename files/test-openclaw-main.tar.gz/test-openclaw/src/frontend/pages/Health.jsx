// This file is no longer used. Health dashboard is now at pages/setup/Health.jsx
export { default } from './setup/Health';

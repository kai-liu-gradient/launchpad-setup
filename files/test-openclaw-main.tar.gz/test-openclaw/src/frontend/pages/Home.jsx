import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { authFetch } from '../hooks/useAuth';

export default function Home() {
  const [health, setHealth] = useState(null);

  useEffect(() => {
    authFetch('/api/openclaw/health')
      .then((r) => r.json())
      .then(setHealth)
      .catch(() => {});
  }, []);

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">OpenClaw Launcher</h1>
        <p className="page-subtitle">Gateway daemon management and workspace browser</p>
      </div>

      <div className="page-content">
      {health && (
        <div className="card" style={{ marginBottom: 24 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <span className={`status-dot ${health.gateway?.portReachable ? 'online' : 'offline'}`} />
            <span style={{ color: '#1e1e1e', fontWeight: 'bold' }}>
              Gateway: {health.gateway?.portReachable ? 'Online' : 'Offline'}
            </span>
            {health.config?.exists && (
              <span className="badge badge-success">Config OK</span>
            )}
            {health.workspace?.exists && (
              <span className="badge badge-success">Workspace OK</span>
            )}
          </div>
        </div>
      )}

      <div className="grid-2">
        <Link to="/setup" className="quick-action">
          <div className="quick-action-icon">{'\u2699'}</div>
          <div className="quick-action-text">
            <h3>Setup Wizard</h3>
            <p>Configure credentials, Telegram, and OpenClaw</p>
          </div>
        </Link>

        <Link to="/health" className="quick-action">
          <div className="quick-action-icon">{'\u2665'}</div>
          <div className="quick-action-text">
            <h3>Health Dashboard</h3>
            <p>Monitor gateway process and system health</p>
          </div>
        </Link>

        <Link to="/workspace" className="quick-action">
          <div className="quick-action-icon">{'\u2610'}</div>
          <div className="quick-action-text">
            <h3>Workspace Browser</h3>
            <p>Browse and view workspace files</p>
          </div>
        </Link>

        <a href="/health" className="quick-action">
          <div className="quick-action-icon">{'\u2139'}</div>
          <div className="quick-action-text">
            <h3>Server Health</h3>
            <p>Express server health status page</p>
          </div>
        </a>
      </div>
      </div>
    </div>
  );
}

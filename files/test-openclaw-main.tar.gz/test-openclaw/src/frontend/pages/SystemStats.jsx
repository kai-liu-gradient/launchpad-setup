import React, { useEffect, useState, useCallback, useRef, useMemo } from 'react';
import { authFetch } from '../hooks/useAuth';
import { setSystemStats } from '../systemStatsStore';

// ── Time range definitions ────────────────────────────────────

const TIME_RANGES = [
  { key: '30m', label: '30m', minutes: 30,   bucketMin: 1 },
  { key: '1h',  label: '1h',  minutes: 60,   bucketMin: 1 },
  { key: '6h',  label: '6h',  minutes: 360,  bucketMin: 5 },
  { key: '24h', label: '24h', minutes: 1440, bucketMin: 15 },
];

// ── Aggregate history into buckets ────────────────────────────

function aggregateHistory(history, rangeMinutes, bucketMin) {
  if (!history.length) return [];
  if (bucketMin <= 1) return history;

  const bucketMs = bucketMin * 60 * 1000;
  const buckets = [];
  let bucketStart = new Date(history[0].timestamp).getTime();
  let current = [];

  for (const s of history) {
    const t = new Date(s.timestamp).getTime();
    if (t >= bucketStart + bucketMs && current.length > 0) {
      buckets.push(meanSnapshot(current));
      current = [];
      while (bucketStart + bucketMs <= t) bucketStart += bucketMs;
    }
    current.push(s);
  }
  if (current.length > 0) buckets.push(meanSnapshot(current));
  return buckets;
}

function meanSnapshot(samples) {
  const n = samples.length;
  const avg = (arr, fn) => arr.reduce((s, x) => s + (fn(x) || 0), 0) / n;

  return {
    timestamp: samples[Math.floor(n / 2)].timestamp,
    processes: {
      total: Math.round(avg(samples, s => s.processes?.total)),
      zombie: Math.round(avg(samples, s => s.processes?.zombie)),
    },
    memory: {
      totalMB: samples[0].memory?.totalMB || 0,
      usedMB: Math.round(avg(samples, s => s.memory?.usedMB)),
      usedPercent: parseFloat(avg(samples, s => s.memory?.usedPercent).toFixed(1)),
    },
    cpu: samples[0].cpu ? {
      cores: samples[0].cpu.cores,
      quotaCores: samples[0].cpu.quotaCores,
      usagePercent: samples.some(s => s.cpu?.usagePercent != null)
        ? parseFloat(avg(samples.filter(s => s.cpu?.usagePercent != null), s => s.cpu.usagePercent).toFixed(1))
        : null,
    } : null,
    heap: {
      rssMB: parseFloat(avg(samples, s => s.heap?.rssMB).toFixed(1)),
      heapUsedMB: parseFloat(avg(samples, s => s.heap?.heapUsedMB).toFixed(1)),
      heapTotalMB: parseFloat(avg(samples, s => s.heap?.heapTotalMB).toFixed(1)),
    },
    gpu: samples[0].gpu ? {
      name: samples[0].gpu.name,
      usedMB: Math.round(avg(samples, s => s.gpu?.usedMB)),
      totalMB: samples[0].gpu.totalMB,
      utilPercent: Math.round(avg(samples, s => s.gpu?.utilPercent)),
      tempC: Math.round(avg(samples, s => s.gpu?.tempC)),
    } : null,
    storage: {
      workspaceMB: Math.round(avg(samples, s => s.storage?.workspaceMB)),
    },
  };
}

// ── Grafana-style SVG area chart with sparse data support ─────

const CHART_H = 180;
const CHART_PAD = { top: 24, right: 12, bottom: 24, left: 48 };

function TimeSeriesChart({ data, timestamps, max: maxProp, color, unit, height = CHART_H, rangeMinutes }) {
  const ref = useRef(null);
  const [hover, setHover] = useState(null);

  const w = 560;
  const plotW = w - CHART_PAD.left - CHART_PAD.right;
  const plotH = height - CHART_PAD.top - CHART_PAD.bottom;

  // Fixed time axis: rangeStart → now
  const now = useMemo(() => Date.now(), [timestamps]); // eslint-disable-line react-hooks/exhaustive-deps
  const rangeMs = (rangeMinutes || 30) * 60 * 1000;
  const rangeStart = now - rangeMs;

  // Build time labels for axis (always 6 labels across the full range)
  const timeLabels = useMemo(() => {
    const count = 6;
    const labels = [];
    for (let i = 0; i < count; i++) {
      const frac = i / (count - 1);
      const t = rangeStart + frac * rangeMs;
      labels.push({ frac, label: fmtTime(new Date(t).toISOString()) });
    }
    return labels;
  }, [rangeStart, rangeMs]);

  // Compute points positioned by actual timestamp on the fixed time axis
  // null values represent gaps (missing data)
  const points = useMemo(() => {
    if (!data || !data.length || !timestamps || !timestamps.length) return [];
    return data.map((v, i) => {
      const t = new Date(timestamps[i]).getTime();
      const frac = (t - rangeStart) / rangeMs;
      const x = CHART_PAD.left + frac * plotW;
      const isNull = v == null;
      return { x, v, isNull, t };
    });
  }, [data, timestamps, rangeStart, rangeMs, plotW]);

  const hasData = points.length > 0 && points.some(p => !p.isNull);

  // Ceil / yTicks
  const ceil = hasData
    ? (maxProp || niceMax(Math.max(...points.filter(p => !p.isNull).map(p => p.v), 1)))
    : (maxProp || 100);
  const yTicks = buildYTicks(ceil, 4);

  // Build segmented line/area paths — break at null values
  const { segments, gradId } = useMemo(() => {
    if (!hasData) return { segments: [], gradId: '' };
    const gId = `grad-${color.replace(/[^a-z0-9]/gi, '')}-${height}`;
    const segs = [];
    let current = [];
    for (const p of points) {
      if (p.isNull) {
        if (current.length > 0) { segs.push(current); current = []; }
      } else {
        const y = CHART_PAD.top + plotH - (p.v / ceil) * plotH;
        current.push({ x: p.x, y, v: p.v });
      }
    }
    if (current.length > 0) segs.push(current);
    return { segments: segs, gradId: gId };
  }, [hasData, points, ceil, plotH, color, height]);

  // Find closest non-null point for hover
  const onMouseMove = (e) => {
    if (!hasData) return;
    const svg = ref.current;
    if (!svg) return;
    const rect = svg.getBoundingClientRect();
    const svgX = ((e.clientX - rect.left) / rect.width) * w;
    // Find closest non-null point
    let bestIdx = null;
    let bestDist = Infinity;
    for (let i = 0; i < points.length; i++) {
      if (points[i].isNull) continue;
      const dist = Math.abs(points[i].x - svgX);
      if (dist < bestDist) { bestDist = dist; bestIdx = i; }
    }
    if (bestIdx != null && bestDist < 30) setHover(bestIdx);
    else setHover(null);
  };

  // Tooltip positioning
  const tipW = 96;
  const tipH = 36;
  let tipX = null, tipY = null;
  const hoverPt = hover != null ? points[hover] : null;
  const hoverY = hoverPt && !hoverPt.isNull
    ? CHART_PAD.top + plotH - (hoverPt.v / ceil) * plotH
    : null;
  if (hoverPt && hoverY != null) {
    tipX = hoverPt.x - tipW / 2;
    if (tipX < 2) tipX = 2;
    if (tipX + tipW > w - 2) tipX = w - tipW - 2;
    tipY = hoverY - tipH - 12;
    if (tipY < 2) tipY = hoverY + 14;
  }

  return (
    <svg
      ref={ref}
      viewBox={`0 0 ${w} ${height}`}
      className="graf-chart-svg"
      preserveAspectRatio="xMidYMid meet"
      onMouseMove={onMouseMove}
      onMouseLeave={() => setHover(null)}
    >
      {hasData && (
        <defs>
          <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.35" />
            <stop offset="100%" stopColor={color} stopOpacity="0.02" />
          </linearGradient>
        </defs>
      )}

      {/* grid lines + y labels */}
      {yTicks.map((tick) => {
        const y = CHART_PAD.top + plotH - (tick / ceil) * plotH;
        return (
          <g key={tick}>
            <line x1={CHART_PAD.left} y1={y} x2={w - CHART_PAD.right} y2={y} className="graf-grid-line" />
            <text x={CHART_PAD.left - 6} y={y + 3.5} className="graf-y-label">{fmtTickVal(tick, unit)}</text>
          </g>
        );
      })}

      {/* bottom axis */}
      <line x1={CHART_PAD.left} y1={CHART_PAD.top + plotH} x2={w - CHART_PAD.right} y2={CHART_PAD.top + plotH} className="graf-grid-line" />

      {/* time labels */}
      {timeLabels.map(({ frac, label }, i) => {
        const x = CHART_PAD.left + frac * plotW;
        return <text key={i} x={x} y={height - 5} className="graf-x-label">{label}</text>;
      })}

      {/* "No data" message */}
      {!hasData && (
        <text x={w / 2} y={CHART_PAD.top + plotH / 2} className="graf-no-data">No data in range</text>
      )}

      {/* data rendering — segmented for gaps */}
      {hasData && segments.map((seg, si) => {
        if (seg.length < 1) return null;
        const linePath = seg.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.x},${p.y}`).join(' ');
        const areaPath = linePath
          + ` L${seg[seg.length - 1].x},${CHART_PAD.top + plotH}`
          + ` L${seg[0].x},${CHART_PAD.top + plotH} Z`;
        return (
          <g key={si}>
            <path d={areaPath} fill={`url(#${gradId})`} />
            <path d={linePath} fill="none" stroke={color} strokeWidth="1.8" strokeLinejoin="round" />
          </g>
        );
      })}

      {/* latest point dot */}
      {hasData && (() => {
        const lastSeg = segments[segments.length - 1];
        if (!lastSeg || !lastSeg.length) return null;
        const last = lastSeg[lastSeg.length - 1];
        return <circle cx={last.x} cy={last.y} r="3" fill={color} />;
      })()}

      {/* hover crosshair + tooltip */}
      {hoverPt && hoverY != null && (
        <g>
          <line x1={hoverPt.x} y1={CHART_PAD.top} x2={hoverPt.x} y2={CHART_PAD.top + plotH} stroke={color} strokeWidth="1" strokeDasharray="3,3" opacity="0.6" />
          <circle cx={hoverPt.x} cy={hoverY} r="4" fill={color} stroke="var(--bg-surface)" strokeWidth="2" />
          <rect x={tipX} y={tipY} width={tipW} height={tipH} rx="4" className="graf-tooltip-bg" />
          <text x={tipX + tipW / 2} y={tipY + 15} className="graf-tooltip-val">{fmtVal(hoverPt.v, unit)}</text>
          {timestamps?.[hover] && (
            <text x={tipX + tipW / 2} y={tipY + 28} className="graf-tooltip-time">{fmtTime(timestamps[hover])}</text>
          )}
        </g>
      )}
    </svg>
  );
}

// ── Skeleton components ───────────────────────────────────────

function StatPanelSkeleton() {
  return (
    <div className="graf-stat-panel">
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, padding: '4px 0' }}>
        <div className="skeleton-row" style={{ width: '50%', height: 12 }} />
        <div className="skeleton-row-lg" style={{ width: '60%' }} />
        <div className="skeleton-row" style={{ width: '70%', height: 10 }} />
      </div>
    </div>
  );
}

function ChartPanelSkeleton() {
  return (
    <div className="graf-panel">
      <div className="graf-panel-header">
        <div className="skeleton-row" style={{ width: 100, height: 12 }} />
        <div className="skeleton-row" style={{ width: 40, height: 12 }} />
      </div>
      <div className="graf-panel-body" style={{ height: CHART_H + 16 }}>
        <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', height: '100%', gap: 6, padding: '12px 0' }}>
          <div className="skeleton-row" style={{ width: '100%', height: 6 }} />
          <div className="skeleton-row" style={{ width: '100%', height: 6 }} />
          <div className="skeleton-row" style={{ width: '100%', height: 6 }} />
          <div className="skeleton-row" style={{ width: '80%', height: 6 }} />
        </div>
      </div>
    </div>
  );
}

// ── Stat panel ────────────────────────────────────────────────

function StatPanel({ label, value, sub, color }) {
  return (
    <div className="graf-stat-panel">
      <div className="graf-stat-label">{label}</div>
      <div className="graf-stat-value" style={{ color }}>{value}</div>
      {sub && <div className="graf-stat-sub">{sub}</div>}
    </div>
  );
}

// ── Graph panel ───────────────────────────────────────────────

function GraphPanel({ title, children, sub }) {
  return (
    <div className="graf-panel">
      <div className="graf-panel-header">
        <span className="graf-panel-title">{title}</span>
        {sub && <span className="graf-panel-sub">{sub}</span>}
      </div>
      <div className="graf-panel-body">
        {children}
      </div>
    </div>
  );
}

// ── Helpers ───────────────────────────────────────────────────

function niceMax(v) {
  if (v <= 0) return 1;
  const mag = Math.pow(10, Math.floor(Math.log10(v)));
  const norm = v / mag;
  if (norm <= 1) return mag;
  if (norm <= 2) return 2 * mag;
  if (norm <= 5) return 5 * mag;
  return 10 * mag;
}

function buildYTicks(max, count) {
  const step = max / count;
  const ticks = [];
  for (let i = 0; i <= count; i++) ticks.push(Math.round(step * i * 100) / 100);
  return ticks;
}

function fmtTime(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

const formatMB = (mb) => mb >= 1024 ? `${(mb / 1024).toFixed(1)} GB` : `${Math.round(mb)} MB`;

function fmtVal(v, unit) {
  if (unit === 'MB') return formatMB(v);
  if (unit === '%') return v.toFixed(1) + '%';
  if (unit === '\u00B0C') return v + '\u00B0C';
  return typeof v === 'number' ? (v % 1 === 0 ? v.toString() : v.toFixed(1)) : v;
}

function fmtTickVal(v, unit) {
  if (unit === 'MB') {
    if (v >= 1024) return (v / 1024).toFixed(v >= 10240 ? 0 : 1) + 'G';
    if (v >= 1) return Math.round(v) + 'M';
    return v.toFixed(1) + 'M';
  }
  if (unit === '%') return v + '%';
  if (v >= 1000) return (v / 1000).toFixed(1) + 'k';
  return v.toString();
}

// ── Main page ─────────────────────────────────────────────────

const COLORS = {
  green: '#73BF69',
  blue: '#5794F2',
  orange: '#FF9830',
  purple: '#B877D9',
  red: '#F2495C',
  yellow: '#FADE2A',
  cyan: '#44C0C1',
};

export default function SystemStats() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [resetting, setResetting] = useState(false);
  const [range, setRange] = useState('30m');
  const [showExtra, setShowExtra] = useState(false);
  const [actionsOpen, setActionsOpen] = useState(false);
  const actionsRef = useRef(null);

  const rangeDef = TIME_RANGES.find(r => r.key === range) || TIME_RANGES[0];

  const fetchStats = useCallback((rangeMinutes) => {
    const mins = rangeMinutes || 30;
    authFetch(`/api/openclaw/system-stats?range=${mins}`)
      .then(r => { if (!r.ok) throw new Error(`HTTP ${r.status}`); return r.json(); })
      .then(d => {
        setData(d);
        setError(null);
        if (d?.latest) setSystemStats({ cpu: d.latest.cpu, memory: d.latest.memory });
      })
      .catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  // Fetch on mount, on range change, and on 60s interval
  useEffect(() => {
    setLoading(prev => !data ? prev : false); // don't flash loading on refetch
    fetchStats(rangeDef.minutes);
    const interval = setInterval(() => fetchStats(rangeDef.minutes), 60000);
    return () => clearInterval(interval);
  }, [fetchStats, rangeDef.minutes]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleRefresh = useCallback(() => {
    fetchStats(rangeDef.minutes);
  }, [fetchStats, rangeDef.minutes]);

  const handleReset = useCallback(() => {
    if (!confirm('Clear all collected stats history?')) return;
    setResetting(true);
    authFetch('/api/openclaw/system-stats', { method: 'DELETE' })
      .then(r => { if (!r.ok) throw new Error(`HTTP ${r.status}`); return r.json(); })
      .then(() => fetchStats(rangeDef.minutes))
      .catch(err => setError(err.message))
      .finally(() => setResetting(false));
  }, [fetchStats, rangeDef.minutes]);

  const rawHistory = data?.history || [];
  const latest = data?.latest;

  const chartHistory = useMemo(
    () => aggregateHistory(rawHistory, rangeDef.minutes, rangeDef.bucketMin),
    [rawHistory, rangeDef.minutes, rangeDef.bucketMin]
  );

  const timestamps = useMemo(() => chartHistory.map(s => s.timestamp), [chartHistory]);
  const series = useCallback((fn) => chartHistory.map(fn), [chartHistory]);

  // Close actions dropdown on outside click
  useEffect(() => {
    if (!actionsOpen) return;
    const handler = (e) => {
      if (actionsRef.current && !actionsRef.current.contains(e.target)) setActionsOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [actionsOpen]);

  const headerActions = (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      {data?.count > 0 && (
        <span className="stats-sample-count" style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontVariantNumeric: 'tabular-nums' }}>
          {data.count} samples
        </span>
      )}
      <div className="stats-actions-inline">
        <button className="btn btn-secondary btn-sm" onClick={handleRefresh} disabled={loading}>
          {loading ? <span className="spinner" style={{ width: 12, height: 12, borderWidth: 2 }} /> : 'Refresh'}
        </button>
        <button className="btn btn-secondary btn-sm" onClick={handleReset} disabled={resetting} title="Clear all history">
          {resetting ? <span className="spinner" style={{ width: 12, height: 12, borderWidth: 2 }} /> : 'Reset'}
        </button>
      </div>
      <div className="stats-actions-dropdown" ref={actionsRef}>
        <button className="btn btn-secondary btn-sm" onClick={() => setActionsOpen(!actionsOpen)} aria-label="Actions">
          &#x22EE;
        </button>
        {actionsOpen && (
          <div className="stats-actions-menu">
            <button onClick={() => { handleRefresh(); setActionsOpen(false); }} disabled={loading}>
              {loading ? 'Refreshing...' : 'Refresh'}
            </button>
            <button onClick={() => { handleReset(); setActionsOpen(false); }} disabled={resetting}>
              {resetting ? 'Resetting...' : 'Reset History'}
            </button>
          </div>
        )}
      </div>
    </div>
  );

  // ── Initial loading skeleton ──
  if (loading && !data) {
    return (
      <div>
        <div className="page-header" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <h1 className="page-title">System Stats</h1>
            <p className="page-subtitle">System utilization metrics collected every minute</p>
          </div>
        </div>
        <div className="setup-content">
          {/* Stat panel skeletons */}
          <div className="graf-stat-row">
            <StatPanelSkeleton />
            <StatPanelSkeleton />
            <StatPanelSkeleton />
            <StatPanelSkeleton />
          </div>
          {/* Range bar skeleton */}
          <div className="graf-range-bar">
            <div className="skeleton-row" style={{ width: 180, height: 28, borderRadius: 4 }} />
          </div>
          {/* Chart panel skeletons */}
          <div className="graf-grid">
            <ChartPanelSkeleton />
            <ChartPanelSkeleton />
            <ChartPanelSkeleton />
            <ChartPanelSkeleton />
          </div>
        </div>
      </div>
    );
  }

  if (error && !data) {
    return (
      <div>
        <div className="page-header">
          <h1 className="page-title">System Stats</h1>
          <p className="page-subtitle">System utilization metrics collected every minute</p>
        </div>
        <div className="setup-content">
          <div className="graf-panel" style={{ padding: 20, color: 'var(--badge-error-text)' }}>
            Failed to load: {error}
          </div>
        </div>
      </div>
    );
  }

  const cpuSub = latest?.cpu
    ? `${latest.cpu.quotaCores || latest.cpu.cores} cores`
    : null;

  const procSub = latest?.processes?.zombie > 0
    ? `${latest.processes.zombie} zombie`
    : null;

  const rangeLabel = rangeDef.bucketMin > 1
    ? `${chartHistory.length} pts \u00B7 ${rangeDef.bucketMin}min avg`
    : `${chartHistory.length} pts`;

  return (
    <div>
      <div className="page-header" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <h1 className="page-title">System Stats</h1>
          <p className="page-subtitle">System utilization metrics collected every minute</p>
        </div>
        {headerActions}
      </div>

      <div className="setup-content">
        {!latest ? (
          <div className="graf-panel" style={{ padding: 24, color: 'var(--text-muted)', textAlign: 'center' }}>
            Collecting first sample...
          </div>
        ) : (
          <>
            {/* ── Stat panels row ── */}
            <div className="graf-stat-row">
              <StatPanel label="Memory" value={`${latest.memory.usedPercent}%`} sub={`${formatMB(latest.memory.usedMB)} / ${formatMB(latest.memory.totalMB)}`} color={COLORS.green} />
              {latest.cpu && (
                <StatPanel
                  label="CPU"
                  value={latest.cpu.usagePercent != null ? `${latest.cpu.usagePercent}%` : '\u2014'}
                  sub={cpuSub}
                  color={COLORS.cyan}
                />
              )}
              <StatPanel
                label="Processes"
                value={latest.processes.total}
                sub={procSub}
                color={latest.processes.zombie > 0 ? COLORS.red : COLORS.orange}
              />
              <StatPanel label="Workspace" value={formatMB(latest.storage.workspaceMB)} sub="/workspace" color={COLORS.purple} />
              {latest.gpu && (
                <>
                  <StatPanel label="GPU Util" value={`${latest.gpu.utilPercent}%`} sub={latest.gpu.name} color={COLORS.cyan} />
                  <StatPanel label="GPU Temp" value={`${latest.gpu.tempC}\u00B0C`} color={latest.gpu.tempC > 80 ? COLORS.red : COLORS.yellow} />
                </>
              )}
            </div>

            {/* ── Time range selector ── */}
            <div className="graf-range-bar">
              <div className="graf-range-pills">
                {TIME_RANGES.map(r => (
                  <button
                    key={r.key}
                    className={`graf-range-pill${range === r.key ? ' active' : ''}`}
                    onClick={() => setRange(r.key)}
                  >
                    {r.label}
                  </button>
                ))}
              </div>
              <span className="graf-range-info">{rangeLabel}</span>
            </div>

            {/* ── Chart panels ── */}
            <div className="graf-grid">
              <GraphPanel title="Memory Usage" sub={`${latest.memory.usedPercent}%`}>
                <TimeSeriesChart
                  data={series(s => s.memory?.usedMB || 0)}
                  timestamps={timestamps}
                  max={latest.memory.totalMB}
                  color={COLORS.green}
                  unit="MB"
                  rangeMinutes={rangeDef.minutes}
                />
              </GraphPanel>

              <GraphPanel title="CPU Usage" sub={latest.cpu?.usagePercent != null ? `${latest.cpu.usagePercent}%` : '\u2014'}>
                <TimeSeriesChart
                  data={series(s => s.cpu?.usagePercent ?? null)}
                  timestamps={timestamps}
                  max={100}
                  color={COLORS.cyan}
                  unit="%"
                  rangeMinutes={rangeDef.minutes}
                />
              </GraphPanel>

              <GraphPanel title="Process Count" sub={latest.processes.total}>
                <TimeSeriesChart
                  data={series(s => s.processes?.total || 0)}
                  timestamps={timestamps}
                  color={COLORS.orange}
                  rangeMinutes={rangeDef.minutes}
                />
              </GraphPanel>

              <GraphPanel title="Workspace Storage" sub={formatMB(latest.storage.workspaceMB)}>
                <TimeSeriesChart
                  data={series(s => s.storage?.workspaceMB || 0)}
                  timestamps={timestamps}
                  color={COLORS.purple}
                  unit="MB"
                  rangeMinutes={rangeDef.minutes}
                />
              </GraphPanel>

              {latest.gpu && (
                <>
                  <GraphPanel title="GPU Utilization" sub={`${latest.gpu.utilPercent}%`}>
                    <TimeSeriesChart
                      data={series(s => s.gpu?.utilPercent || 0)}
                      timestamps={timestamps}
                      max={100}
                      color={COLORS.cyan}
                      unit="%"
                      rangeMinutes={rangeDef.minutes}
                    />
                  </GraphPanel>

                  <GraphPanel title="GPU Memory" sub={formatMB(latest.gpu.usedMB)}>
                    <TimeSeriesChart
                      data={series(s => s.gpu?.usedMB || 0)}
                      timestamps={timestamps}
                      max={latest.gpu.totalMB}
                      color={COLORS.yellow}
                      unit="MB"
                      rangeMinutes={rangeDef.minutes}
                    />
                  </GraphPanel>

                  <GraphPanel title="GPU Temperature" sub={`${latest.gpu.tempC}\u00B0C`}>
                    <TimeSeriesChart
                      data={series(s => s.gpu?.tempC || 0)}
                      timestamps={timestamps}
                      color={COLORS.red}
                      unit={'\u00B0C'}
                      rangeMinutes={rangeDef.minutes}
                    />
                  </GraphPanel>
                </>
              )}
            </div>

            {/* ── Additional info (Node.js internals) ── */}
            <button
              className="graf-extra-toggle"
              onClick={() => setShowExtra(!showExtra)}
            >
              <span className={`graf-extra-arrow${showExtra ? ' open' : ''}`}>{'\u25B6'}</span>
              Node.js Internals
              <span className="graf-extra-hint">
                Heap {formatMB(latest.heap.heapUsedMB)} {'\u00B7'} RSS {formatMB(latest.heap.rssMB)}
              </span>
            </button>

            {showExtra && (
              <div className="graf-grid" style={{ marginTop: 10 }}>
                <GraphPanel title="Heap Used" sub={formatMB(latest.heap.heapUsedMB)}>
                  <TimeSeriesChart
                    data={series(s => s.heap?.heapUsedMB || 0)}
                    timestamps={timestamps}
                    color={COLORS.blue}
                    unit="MB"
                    rangeMinutes={rangeDef.minutes}
                  />
                </GraphPanel>

                <GraphPanel title="RSS Memory" sub={formatMB(latest.heap.rssMB)}>
                  <TimeSeriesChart
                    data={series(s => s.heap?.rssMB || 0)}
                    timestamps={timestamps}
                    color={COLORS.purple}
                    unit="MB"
                    rangeMinutes={rangeDef.minutes}
                  />
                </GraphPanel>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

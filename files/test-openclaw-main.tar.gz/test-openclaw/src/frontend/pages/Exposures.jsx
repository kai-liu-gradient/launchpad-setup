import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Globe, Server, FolderOpen, Shield, ShieldOff, ExternalLink, Power, PowerOff, Trash2, Plus, Copy, Check, X, ArrowUpRight, CheckCircle, XCircle, Download, BookOpen, Zap, Terminal, Play, Square, RotateCw, Activity, ChevronDown, ChevronUp, Rocket, Cpu, Clock, AlertTriangle, FileText, Eye, Lock, Settings, Edit3, ArrowLeft } from 'lucide-react';
import { authFetch } from '../hooks/useAuth';

/* ── helpers ─────────────────────────────────────────────── */

function portFromTarget(target) {
  try { return new URL(target).port; } catch { return null; }
}

function friendlyLabel(exp) {
  if (exp.description) return exp.description;
  if (exp.pm2 && exp.pm2.name) return `PM2 service: ${exp.pm2.name}`;
  if (exp.type === 'proxy') {
    const port = portFromTarget(exp.target);
    return port ? `Local service on port ${port}` : 'Reverse proxy';
  }
  const segments = (exp.path || '').replace(/\/+$/, '').split('/');
  const name = segments[segments.length - 1] || exp.path;
  return `Serving ${name}/`;
}

function formatUptime(ms) {
  if (!ms) return '';
  const sec = Math.floor((Date.now() - ms) / 1000);
  if (sec < 60) return `${sec}s`;
  if (sec < 3600) return `${Math.floor(sec / 60)}m`;
  if (sec < 86400) return `${Math.floor(sec / 3600)}h ${Math.floor((sec % 3600) / 60)}m`;
  return `${Math.floor(sec / 86400)}d`;
}

function formatBytes(bytes) {
  if (!bytes || bytes < 1024) return '0 KB';
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / 1048576).toFixed(1)} MB`;
}

function formatTime(ts) {
  const d = new Date(ts);
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

/* ── Add-exposure form ───────────────────────────────────── */

function AddForm({ onAdd, show, onClose }) {
  const [mode, setMode] = useState('new'); // 'new' or 'adopt'
  const [slug, setSlug] = useState('');
  const [description, setDescription] = useState('');
  const [enableAuth, setEnableAuth] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [createdCreds, setCreatedCreds] = useState(null);

  // Adopt mode state
  const [adoptableProcesses, setAdoptableProcesses] = useState([]);
  const [adoptLoading, setAdoptLoading] = useState(false);
  const [selectedPm2, setSelectedPm2] = useState(null);
  const [adoptPort, setAdoptPort] = useState('');
  const [renaming, setRenaming] = useState(null); // pm2 name currently being renamed

  const loadAdoptable = useCallback(() => {
    setAdoptLoading(true);
    authFetch('/api/openclaw/exposures/adoptable-pm2')
      .then(r => r.json())
      .then(data => { setAdoptableProcesses(data.processes || []); setAdoptLoading(false); })
      .catch(() => { setAdoptableProcesses([]); setAdoptLoading(false); });
  }, []);

  useEffect(() => {
    if (show && mode === 'adopt') loadAdoptable();
  }, [show, mode, loadAdoptable]);

  if (!show) return null;

  const resetForm = () => {
    setSlug(''); setDescription(''); setEnableAuth(false);
    setSelectedPm2(null); setAdoptPort(''); setError(null);
  };

  const handleRenamePm2 = async (oldName) => {
    const newName = `user-${oldName}`;
    setRenaming(oldName);
    setError(null);
    try {
      const res = await authFetch('/api/openclaw/exposures/rename-pm2', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ oldName, newName }),
      });
      const data = await res.json();
      if (!res.ok) {
        // If the broken process was cleaned up, refresh the list silently
        if (data.cleaned) {
          loadAdoptable();
          setSelectedPm2(null);
        }
        throw new Error(data.message || data.error || 'Rename failed');
      }
      // Refresh the list — the process now has the prefix
      loadAdoptable();
      setSelectedPm2(null);
    } catch (err) {
      setError(err.message);
    } finally {
      setRenaming(null);
    }
  };

  const handleNewSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const body = { name: slug };
      if (description) body.description = description;
      if (enableAuth) body.enableAuth = true;
      const res = await authFetch('/api/openclaw/exposures/scaffold-new', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || data.error || 'Failed');
      if (data.credentials) {
        setCreatedCreds(data.credentials);
      } else {
        resetForm(); onClose();
      }
      onAdd();
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleAdoptSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    if (!selectedPm2) { setError('Select a PM2 process to adopt'); return; }
    if (!selectedPm2.hasRequiredPrefix) {
      setError(`"${selectedPm2.name}" must be renamed with the "user-" prefix before adopting. Run: pm2 delete ${selectedPm2.name} && pm2 start <script> --name user-${selectedPm2.name}`);
      return;
    }
    setSubmitting(true);
    try {
      const body = { pm2Name: selectedPm2.name };
      if (description) body.description = description;
      if (enableAuth) body.enableAuth = true;
      const port = adoptPort || selectedPm2.port;
      if (port) body.port = Number(port);
      const res = await authFetch('/api/openclaw/exposures/adopt-pm2', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || data.error || 'Failed');
      if (data.credentials) {
        setCreatedCreds(data.credentials);
      } else {
        resetForm(); onClose();
      }
      onAdd();
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const dismissCreds = () => {
    setCreatedCreds(null);
    resetForm();
    onClose();
  };

  if (createdCreds) {
    return (
      <div className="modal-overlay">
        <div className="modal-dialog" style={{ maxWidth: 420 }}>
          <h3 className="card-title" style={{ marginBottom: 8 }}>Credentials Generated</h3>
          <div style={{ background: 'var(--bg-inset, var(--bg-surface-alt))', border: '1px solid var(--border-primary)', borderRadius: 6, padding: '10px 12px', marginBottom: 10 }}>
            <div style={{ fontFamily: "'JetBrains Mono', 'Fira Code', Consolas, monospace", fontSize: '0.75rem', lineHeight: 1.7 }}>
              <div><span style={{ color: 'var(--text-muted)' }}>Username:</span> {createdCreds.username}</div>
              <div><span style={{ color: 'var(--text-muted)' }}>Password:</span> {createdCreds.password}</div>
            </div>
          </div>
          <p style={{ fontSize: '0.72rem', color: 'var(--badge-warning-text)', margin: '0 0 10px' }}>Save these credentials — the password cannot be retrieved later.</p>
          <div style={{ display: 'flex', gap: 6 }}>
            <button className="btn btn-sm" onClick={() => navigator.clipboard.writeText(`Username: ${createdCreds.username}\nPassword: ${createdCreds.password}`).catch(() => {})}><Copy size={11} /> Copy</button>
            <button className="btn btn-sm btn-primary" onClick={dismissCreds}>Done</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="modal-overlay" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal-dialog" style={{ maxWidth: 520 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
          <h3 className="card-title" style={{ marginBottom: 0 }}>New Web App</h3>
          <button className="btn btn-sm" onClick={onClose} title="Cancel" style={{ padding: '2px 6px' }}><X size={14} /></button>
        </div>

        {/* Mode tabs */}
        <div className="expose-type-toggle" style={{ marginBottom: 14 }}>
          <button type="button" className={mode === 'new' ? 'active' : ''} onClick={() => { setMode('new'); setError(null); }}>
            <Rocket size={13} /> New Project
          </button>
          <button type="button" className={mode === 'adopt' ? 'active' : ''} onClick={() => { setMode('adopt'); setError(null); }}>
            <Cpu size={13} /> Adopt PM2
          </button>
        </div>

        {mode === 'new' ? (
          <form onSubmit={handleNewSubmit}>
            <div className="expose-form-grid">
              <label style={{ gridColumn: '1 / -1' }}>
                <span className="expose-field-label">Name <span style={{ color: 'var(--accent-primary)', fontWeight: 600 }}>*</span></span>
                <input type="text" placeholder="my-app" value={slug} onChange={e => setSlug(e.target.value)} required pattern="[a-z0-9]([a-z0-9-]*[a-z0-9])?" title="Lowercase alphanumeric with hyphens" autoFocus />
              </label>
              <label style={{ gridColumn: '1 / -1' }}>
                <span className="expose-field-label">Description <span style={{ fontWeight: 400, color: 'var(--text-muted)' }}>(optional)</span></span>
                <input type="text" placeholder="e.g. Snake game built with React" value={description} onChange={e => setDescription(e.target.value)} />
              </label>
              <div className="expose-toggle-row" style={{ gridColumn: '1 / -1' }}>
                <button type="button" className={`expose-toggle-switch ${enableAuth ? 'active' : ''}`} onClick={() => setEnableAuth(!enableAuth)} aria-pressed={enableAuth}>
                  <span className="expose-toggle-knob" />
                </button>
                <Lock size={13} />
                <span>Require authentication</span>
                <span style={{ fontWeight: 400, color: 'var(--text-muted)', fontSize: '0.75rem' }}> — random credentials generated</span>
              </div>
            </div>
            <p style={{ fontSize: '0.72rem', color: 'var(--text-muted)', margin: '8px 0 0' }}>Creates a ready-to-run Express + React project with auto-assigned port, npm install, and PM2 start.</p>
            {error && <div className="expose-error" style={{ marginTop: 8 }}>{error}</div>}
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 14 }}>
              <button type="button" className="btn btn-sm" onClick={onClose}>Cancel</button>
              <button type="submit" className="btn btn-primary btn-sm" disabled={submitting}>
                {submitting ? 'Creating...' : 'Create Project'}
              </button>
            </div>
          </form>
        ) : (
          <form onSubmit={handleAdoptSubmit}>
            <div className="expose-form-grid">
              {adoptLoading ? (
                <div style={{ gridColumn: '1 / -1', padding: '16px 0', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.8rem' }}>Loading PM2 processes...</div>
              ) : adoptableProcesses.length === 0 ? (
                <div style={{ gridColumn: '1 / -1', padding: '16px 0', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.8rem' }}>No adoptable PM2 processes found.</div>
              ) : (
                <div style={{ gridColumn: '1 / -1' }}>
                  <span className="expose-field-label">Select PM2 Process <span style={{ color: 'var(--accent-primary)', fontWeight: 600 }}>*</span></span>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 4, marginTop: 4 }}>
                    {adoptableProcesses.map(p => (
                      <button
                        key={p.name}
                        type="button"
                        onClick={() => { setSelectedPm2(p); setAdoptPort(p.port ? String(p.port) : ''); setError(null); }}
                        style={{
                          display: 'flex', alignItems: 'center', gap: 8, padding: '8px 10px',
                          background: selectedPm2?.name === p.name ? 'var(--bg-active, rgba(99,102,241,0.15))' : 'var(--bg-inset, var(--bg-surface-alt))',
                          border: `1px solid ${selectedPm2?.name === p.name ? 'var(--accent-primary)' : 'var(--border-primary)'}`,
                          borderRadius: 6, cursor: 'pointer', textAlign: 'left', width: '100%', color: 'inherit', fontSize: '0.8rem',
                        }}
                      >
                        <span className={`expose-dot ${p.status === 'online' ? 'expose-dot-online' : 'expose-dot-offline'}`} />
                        <span style={{ fontWeight: 500, flex: 1 }}>{p.name}</span>
                        {!p.hasRequiredPrefix && (
                          <span style={{ fontSize: '0.68rem', color: 'var(--badge-warning-text)', background: 'var(--badge-warning-bg)', padding: '1px 6px', borderRadius: 4 }}>needs rename</span>
                        )}
                        {p.port && <span style={{ color: 'var(--text-muted)', fontSize: '0.72rem' }}>:{p.port}</span>}
                        <span style={{ color: 'var(--text-muted)', fontSize: '0.72rem' }}>{p.status}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
              {selectedPm2 && !selectedPm2.hasRequiredPrefix && (
                <div style={{ gridColumn: '1 / -1', background: 'var(--badge-warning-bg)', border: '1px solid var(--badge-warning-text)', borderRadius: 6, padding: '8px 10px', fontSize: '0.72rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                    <span><strong>Rename required.</strong> Will rename <code>{selectedPm2.name}</code> to <code>user-{selectedPm2.name}</code></span>
                    <button
                      type="button"
                      className="btn btn-sm btn-primary"
                      style={{ flexShrink: 0, fontSize: '0.7rem', padding: '3px 10px' }}
                      disabled={renaming === selectedPm2.name}
                      onClick={() => handleRenamePm2(selectedPm2.name)}
                    >
                      {renaming === selectedPm2.name ? 'Renaming...' : 'Rename Now'}
                    </button>
                  </div>
                </div>
              )}
              {selectedPm2 && selectedPm2.hasRequiredPrefix && (
                <>
                  <label style={{ gridColumn: '1 / -1' }}>
                    <span className="expose-field-label">Port {!selectedPm2.port && <span style={{ color: 'var(--accent-primary)', fontWeight: 600 }}>*</span>}</span>
                    <input type="number" placeholder={selectedPm2.port ? String(selectedPm2.port) : 'e.g. 3001'} min="1" max="65535" value={adoptPort} onChange={e => setAdoptPort(e.target.value)} required={!selectedPm2.port} />
                  </label>
                  <label style={{ gridColumn: '1 / -1' }}>
                    <span className="expose-field-label">Description <span style={{ fontWeight: 400, color: 'var(--text-muted)' }}>(optional)</span></span>
                    <input type="text" placeholder="e.g. My existing service" value={description} onChange={e => setDescription(e.target.value)} />
                  </label>
                  <div className="expose-toggle-row" style={{ gridColumn: '1 / -1' }}>
                    <button type="button" className={`expose-toggle-switch ${enableAuth ? 'active' : ''}`} onClick={() => setEnableAuth(!enableAuth)} aria-pressed={enableAuth}>
                      <span className="expose-toggle-knob" />
                    </button>
                    <Lock size={13} />
                    <span>Require authentication</span>
                  </div>
                </>
              )}
            </div>
            {error && <div className="expose-error" style={{ marginTop: 8 }}>{error}</div>}
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 14 }}>
              <button type="button" className="btn btn-sm" onClick={onClose}>Cancel</button>
              <button type="submit" className="btn btn-primary btn-sm" disabled={submitting || !selectedPm2 || !selectedPm2.hasRequiredPrefix}>
                {submitting ? 'Adopting...' : 'Adopt Process'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

/* ── Sidebar exposure list item ──────────────────────────── */

function ExposureListItem({ exposure, probeStatus, stats, selected, onClick }) {
  const isOnline = probeStatus === true;
  const isOffline = probeStatus === false;
  const TypeIcon = exposure.type === 'proxy' ? Server : FolderOpen;
  const accessHour = stats?.lastHour ?? 0;

  return (
    <button className={`exp-list-item ${selected ? 'exp-list-item-selected' : ''} ${!exposure.enabled ? 'exp-list-item-disabled' : ''}`} onClick={onClick}>
      <div className="exp-list-item-icon"><TypeIcon size={15} /></div>
      <div className="exp-list-item-body">
        <div className="exp-list-item-name">{exposure.slug}</div>
        <div className="exp-list-item-desc">{exposure.description || friendlyLabel(exposure)}</div>
      </div>
      <div className="exp-list-item-status">
        {exposure.enabled && (
          <span className={`expose-dot ${isOnline ? 'expose-dot-online' : isOffline ? 'expose-dot-offline' : 'expose-dot-probing'}`} />
        )}
        {!exposure.enabled && <span className="badge badge-sm badge-secondary">Off</span>}
      </div>
    </button>
  );
}

/* ── Detail tab: Overview ────────────────────────────────── */

function TabOverview({ exposure, probeStatus, pm2Status, onPm2Action, onRefresh }) {
  const [actionBusy, setActionBusy] = useState(null);
  const [recoverBusy, setRecoverBusy] = useState(false);
  const [recoverError, setRecoverError] = useState(null);
  const isOnline = probeStatus === true;
  const isOffline = probeStatus === false;
  const isManaged = !!(exposure.pm2 && exposure.pm2.name);
  const pm2s = pm2Status || {};
  const pm2state = pm2s.status || 'not_found';
  const isRecoverable = !isManaged && pm2s.recoverable;

  const handlePm2 = async (action) => {
    setActionBusy(action);
    try { await onPm2Action(exposure.slug, action); } finally { setActionBusy(null); }
  };

  const handleRecoverPm2 = async () => {
    setRecoverBusy(true);
    setRecoverError(null);
    try {
      const res = await authFetch(`/api/openclaw/exposures/${exposure.slug}/recover-pm2`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}',
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || data.error || 'Recovery failed');
      onRefresh();
    } catch (err) { setRecoverError(err.message); }
    finally { setRecoverBusy(false); }
  };

  return (
    <div className="exp-tab-content">
      {/* Info grid */}
      <div className="exp-info-grid">
        <div className="exp-info-item">
          <span className="exp-info-label">Type</span>
          <span className={`badge badge-sm ${exposure.type === 'proxy' ? 'badge-info' : 'badge-success'}`}>
            {exposure.type === 'proxy' ? 'Service' : 'Static'}
          </span>
        </div>
        <div className="exp-info-item">
          <span className="exp-info-label">{exposure.type === 'proxy' ? 'Target' : 'Path'}</span>
          <code style={{ fontSize: '0.78rem' }}>{exposure.type === 'proxy' ? exposure.target : exposure.path}</code>
        </div>
        <div className="exp-info-item">
          <span className="exp-info-label">Auth</span>
          {exposure.password ? <span style={{ color: 'var(--badge-success-text)' }}><Shield size={12} /> Protected{exposure.authUser && <span style={{ color: 'var(--text-muted)', fontWeight: 400 }}> (user: {exposure.authUser})</span>}</span> : <span style={{ color: 'var(--text-muted)' }}><ShieldOff size={12} /> Open</span>}
        </div>
      </div>

      {/* PM2 section — managed */}
      {isManaged && (
        <div className="exp-pm2-section">
          <div className="exp-pm2-header">
            <Cpu size={14} />
            <span style={{ fontWeight: 600 }}>PM2: {exposure.pm2.name}</span>
            <span className={`badge badge-sm ${pm2state === 'online' ? 'badge-success' : pm2state === 'stopped' ? 'badge-secondary' : pm2state === 'errored' ? 'badge-error' : 'badge-warning'}`}>
              {pm2state === 'online' ? 'Running' : pm2state === 'stopped' ? 'Stopped' : pm2state === 'errored' ? 'Errored' : 'Not Started'}
            </span>
            {pm2state === 'online' && pm2s.uptime && <span className="exp-pm2-stat"><Clock size={10} /> {formatUptime(pm2s.uptime)}</span>}
            {pm2state === 'online' && pm2s.memory > 0 && <span className="exp-pm2-stat">{formatBytes(pm2s.memory)}</span>}
            {pm2s.restarts > 0 && <span className="exp-pm2-stat" style={{ color: 'var(--badge-error-text)' }}><AlertTriangle size={10} /> {pm2s.restarts} restarts</span>}
          </div>
          <div className="exp-pm2-details">
            {exposure.pm2.script && <div><span className="exp-info-label">Script</span> <code>{exposure.pm2.script}</code></div>}
            {exposure.pm2.cwd && <div><span className="exp-info-label">Directory</span> <code>{exposure.pm2.cwd}</code></div>}
            {exposure.pm2.env?.PORT && <div><span className="exp-info-label">Port</span> <code>{exposure.pm2.env.PORT}</code></div>}
            {pm2s.pid && <div><span className="exp-info-label">PID</span> <code>{pm2s.pid}</code></div>}
          </div>
          <div className="exp-pm2-controls">
            {(pm2state === 'stopped' || pm2state === 'not_found') && (
              <button className="btn btn-sm btn-pm2-start" onClick={() => handlePm2('start')} disabled={!!actionBusy}>{actionBusy === 'start' ? <span className="spinner" style={{ width: 11, height: 11, borderWidth: 2 }} /> : <Play size={12} />} Start</button>
            )}
            {pm2state === 'online' && (
              <>
                <button className="btn btn-sm" onClick={() => handlePm2('restart')} disabled={!!actionBusy}>{actionBusy === 'restart' ? <span className="spinner" style={{ width: 11, height: 11, borderWidth: 2 }} /> : <RotateCw size={12} />} Restart</button>
                <button className="btn btn-sm btn-pm2-stop" onClick={() => handlePm2('stop')} disabled={!!actionBusy}>{actionBusy === 'stop' ? <span className="spinner" style={{ width: 11, height: 11, borderWidth: 2 }} /> : <Square size={12} />} Stop</button>
              </>
            )}
            {pm2state === 'errored' && (
              <button className="btn btn-sm btn-pm2-start" onClick={() => handlePm2('restart')} disabled={!!actionBusy}><RotateCw size={12} /> Restart</button>
            )}
          </div>
        </div>
      )}

      {/* PM2 section — recoverable (no config but matching process found) */}
      {isRecoverable && (
        <div className="exp-pm2-section" style={{ borderColor: 'var(--badge-warning-bg, #fbbf24)' }}>
          <div className="exp-pm2-header">
            <Cpu size={14} />
            <span style={{ fontWeight: 600 }}>PM2: user-{exposure.slug}</span>
            <span className={`badge badge-sm ${pm2s.status === 'online' ? 'badge-success' : pm2s.status === 'stopped' ? 'badge-secondary' : 'badge-warning'}`}>
              {pm2s.status === 'online' ? 'Running' : pm2s.status === 'stopped' ? 'Stopped' : pm2s.status}
            </span>
            {pm2s.status === 'online' && pm2s.uptime && <span className="exp-pm2-stat"><Clock size={10} /> {formatUptime(pm2s.uptime)}</span>}
            {pm2s.status === 'online' && pm2s.memory > 0 && <span className="exp-pm2-stat">{formatBytes(pm2s.memory)}</span>}
          </div>
          <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', margin: '6px 0' }}>
            A PM2 process matching this exposure was detected but is not linked. Adopt it to enable PM2 management.
          </div>
          <div className="exp-pm2-controls">
            <button className="btn btn-sm btn-pm2-start" onClick={handleRecoverPm2} disabled={recoverBusy}>
              {recoverBusy ? <span className="spinner" style={{ width: 11, height: 11, borderWidth: 2 }} /> : <Zap size={12} />} Adopt PM2 Instance
            </button>
          </div>
          {recoverError && <div className="expose-error" style={{ marginTop: 6, fontSize: '0.75rem' }}>{recoverError}</div>}
        </div>
      )}

    </div>
  );
}

/* ── Detail tab: Logs ────────────────────────────────────── */

function TabLogs({ exposure }) {
  const [logs, setLogs] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [lines, setLines] = useState(80);
  const logRef = useRef(null);
  const isManaged = !!(exposure.pm2 && exposure.pm2.name);

  const fetchLogs = useCallback(async () => {
    if (!isManaged) return;
    setLoading(true);
    setError(null);
    try {
      const res = await authFetch(`/api/openclaw/exposures/${exposure.slug}/logs?lines=${lines}`);
      if (!res.ok) throw new Error('Failed to fetch logs');
      const data = await res.json();
      setLogs(data.logs || '(no output)');
      if (data.error) setError(data.error);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [exposure.slug, lines, isManaged]);

  useEffect(() => { fetchLogs(); }, [fetchLogs]);
  useEffect(() => { if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight; }, [logs]);

  if (!isManaged) {
    return <div className="exp-tab-content"><div className="exp-empty-tab"><FileText size={24} strokeWidth={1} /><p>Logs are only available for PM2-managed services.</p></div></div>;
  }

  return (
    <div className="exp-tab-content exp-tab-logs">
      <div className="exp-logs-toolbar">
        <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>PM2 logs: {exposure.pm2.name}</span>
        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          <select value={lines} onChange={e => setLines(Number(e.target.value))} className="exp-logs-select">
            <option value={30}>30 lines</option>
            <option value={80}>80 lines</option>
            <option value={200}>200 lines</option>
            <option value={500}>500 lines</option>
          </select>
          <button className="btn btn-sm" onClick={fetchLogs} disabled={loading}><RotateCw size={12} /> Refresh</button>
        </div>
      </div>
      {error && <div className="expose-error" style={{ marginBottom: 8, fontSize: '0.75rem' }}>{error}</div>}
      <pre className="exp-logs-pre" ref={logRef}>{loading ? 'Loading...' : logs}</pre>
    </div>
  );
}

/* ── Detail tab: Access ──────────────────────────────────── */

function TabAccess({ exposure, stats }) {
  const [accessLog, setAccessLog] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchAccessLog = useCallback(async () => {
    setLoading(true);
    try {
      const res = await authFetch(`/api/openclaw/exposures/${exposure.slug}/access-log`);
      if (res.ok) {
        const data = await res.json();
        setAccessLog(data.entries || []);
      }
    } catch { /* ignore */ }
    finally { setLoading(false); }
  }, [exposure.slug]);

  useEffect(() => { fetchAccessLog(); }, [fetchAccessLog]);

  const s = stats || {};

  return (
    <div className="exp-tab-content">
      <div className="exp-info-grid" style={{ marginBottom: 16 }}>
        <div className="exp-info-item"><span className="exp-info-label">Last Minute</span><span style={{ fontWeight: 600 }}>{s.lastMinute ?? 0} requests</span></div>
        <div className="exp-info-item"><span className="exp-info-label">Last Hour</span><span style={{ fontWeight: 600 }}>{s.lastHour ?? 0} requests</span></div>
      </div>
      <div className="exp-access-table-wrap">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
          <span style={{ fontSize: '0.78rem', fontWeight: 600 }}>Recent Requests</span>
          <button className="btn btn-sm" onClick={fetchAccessLog} disabled={loading}><RotateCw size={12} /></button>
        </div>
        {accessLog.length === 0 && !loading && <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', padding: '12px 0' }}>No recent access recorded.</div>}
        {accessLog.length > 0 && (
          <table className="exp-access-table">
            <thead><tr><th>Time</th><th>Method</th><th>Path</th><th>Status</th><th>Duration</th></tr></thead>
            <tbody>
              {accessLog.slice(0, 100).map((entry, i) => (
                <tr key={i}>
                  <td>{formatTime(entry.ts)}</td>
                  <td><code>{entry.method || '-'}</code></td>
                  <td title={entry.path}><code className="exp-access-path">{entry.path || '/'}</code></td>
                  <td><span className={entry.status >= 400 ? 'exp-access-err' : ''}>{entry.status || '-'}</span></td>
                  <td>{entry.duration ? `${entry.duration}ms` : '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

/* ── Detail tab: Settings ────────────────────────────────── */

function TabSettings({ exposure, onRefresh, onDeselect, publicBaseUrl }) {
  const [desc, setDesc] = useState(exposure.description || '');
  const [newSlug, setNewSlug] = useState(exposure.slug);
  const [saving, setSaving] = useState(null);
  const [feedback, setFeedback] = useState(null);
  const [generatedCreds, setGeneratedCreds] = useState(null);
  const [authUsername, setAuthUsername] = useState(exposure.authUser || '');
  const [authPassword, setAuthPassword] = useState('');
  const [backupBusy, setBackupBusy] = useState(false);

  const handleBackup = async () => {
    setBackupBusy(true);
    try {
      const res = await authFetch(`/api/openclaw/exposures/${exposure.slug}/backup`);
      if (!res.ok) { const e = await res.json().catch(() => ({})); alert(e.message || 'Backup failed'); return; }
      const data = await res.json();
      const binary = atob(data.data);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      const blob = new Blob([bytes], { type: 'application/gzip' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = data.filename; document.body.appendChild(a); a.click();
      a.remove(); URL.revokeObjectURL(url);
    } catch (err) { alert('Backup failed: ' + err.message); }
    finally { setBackupBusy(false); }
  };

  useEffect(() => { setDesc(exposure.description || ''); setNewSlug(exposure.slug); setAuthUsername(exposure.authUser || ''); setAuthPassword(''); }, [exposure]);

  const saveField = async (field, value) => {
    setSaving(field);
    setFeedback(null);
    try {
      const res = await authFetch(`/api/openclaw/exposures/${exposure.slug}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ [field]: value }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Failed');
      if (data.credentials) setGeneratedCreds(data.credentials);
      setFeedback({ type: 'success', message: `${field} updated` });
      onRefresh();
    } catch (err) {
      setFeedback({ type: 'error', message: err.message });
    } finally { setSaving(null); }
  };

  const handleRename = async () => {
    if (newSlug === exposure.slug) return;
    setSaving('rename');
    setFeedback(null);
    try {
      const res = await authFetch(`/api/openclaw/exposures/${exposure.slug}/rename`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ newSlug }),
      });
      if (!res.ok) { const d = await res.json(); throw new Error(d.message || 'Failed'); }
      setFeedback({ type: 'success', message: `Renamed to ${newSlug}` });
      onRefresh();
    } catch (err) {
      setFeedback({ type: 'error', message: err.message });
    } finally { setSaving(null); }
  };

  const handleToggle = async () => {
    setSaving('toggle');
    try {
      await authFetch(`/api/openclaw/exposures/${exposure.slug}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled: !exposure.enabled }),
      });
      onRefresh();
    } catch { /* ignore */ }
    finally { setSaving(null); }
  };

  const handleDelete = async () => {
    setSaving('delete');
    try {
      await authFetch(`/api/openclaw/exposures/${exposure.slug}`, { method: 'DELETE' });
      onDeselect();
      onRefresh();
    } catch { /* ignore */ }
    finally { setSaving(null); }
  };

  const handleGeneratePassword = async () => {
    setGeneratedCreds(null);
    await saveField('password', 'generate');
  };

  const handleRemovePassword = async () => {
    setGeneratedCreds(null);
    await saveField('password', null);
  };

  const copyCreds = () => {
    if (!generatedCreds) return;
    navigator.clipboard.writeText(`Username: ${generatedCreds.username}\nPassword: ${generatedCreds.password}`).catch(() => {});
  };

  return (
    <div className="exp-tab-content">
      {feedback && (
        <div className={`gp-feedback ${feedback.type}`} style={{ marginBottom: 12 }}>
          {feedback.type === 'success' ? <CheckCircle size={11} /> : <XCircle size={11} />} {feedback.message}
        </div>
      )}

      {/* Description */}
      <div className="exp-settings-group">
        <label className="exp-settings-label">Description</label>
        <div style={{ display: 'flex', gap: 6 }}>
          <input type="text" className="exp-settings-input" placeholder="What does this project do?" value={desc} onChange={e => setDesc(e.target.value)} />
          <button className="btn btn-sm btn-primary" onClick={() => saveField('description', desc)} disabled={saving === 'description' || desc === (exposure.description || '')}>
            {saving === 'description' ? <span className="spinner" style={{ width: 11, height: 11, borderWidth: 2 }} /> : 'Save'}
          </button>
        </div>
      </div>

      {/* Rename */}
      <div className="exp-settings-group">
        <label className="exp-settings-label">Rename Slug</label>
        <div style={{ display: 'flex', gap: 6 }}>
          <input type="text" className="exp-settings-input" value={newSlug} onChange={e => setNewSlug(e.target.value)} pattern="[a-z0-9]([a-z0-9-]*[a-z0-9])?" />
          <button className="btn btn-sm btn-primary" onClick={handleRename} disabled={saving === 'rename' || newSlug === exposure.slug || !newSlug}>
            {saving === 'rename' ? <span className="spinner" style={{ width: 11, height: 11, borderWidth: 2 }} /> : 'Rename'}
          </button>
        </div>
        <div className="exp-settings-hint">Changing the slug will update the public URL.</div>
      </div>

      {/* Password Protection (htaccess-style) */}
      <div className="exp-settings-group">
        <label className="exp-settings-label">Access Control (HTTP Basic Auth)</label>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
          {exposure.password
            ? <span style={{ fontSize: '0.78rem' }}><Shield size={12} style={{ color: 'var(--badge-success-text)' }} /> Protected {exposure.authUser && <span style={{ color: 'var(--text-muted)' }}> &mdash; user: <code style={{ fontSize: '0.72rem' }}>{exposure.authUser}</code></span>}</span>
            : <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}><ShieldOff size={12} /> Open access (no authentication)</span>
          }
        </div>
        {generatedCreds && (
          <div style={{ background: 'var(--bg-inset, var(--bg-surface-alt))', border: '1px solid var(--border-primary)', borderRadius: 6, padding: '10px 12px', marginBottom: 8, fontSize: '0.78rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
              <span style={{ fontWeight: 600, color: 'var(--badge-success-text)' }}><Lock size={11} /> Credentials saved</span>
              <button className="btn btn-sm" onClick={copyCreds} style={{ padding: '2px 6px' }}><Copy size={11} /> Copy</button>
            </div>
            <div style={{ fontFamily: "'JetBrains Mono', 'Fira Code', Consolas, monospace", fontSize: '0.72rem', lineHeight: 1.6 }}>
              <div><span style={{ color: 'var(--text-muted)' }}>Username:</span> {generatedCreds.username}</div>
              <div><span style={{ color: 'var(--text-muted)' }}>Password:</span> {generatedCreds.password}</div>
            </div>
          </div>
        )}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 8 }}>
          <div style={{ display: 'flex', gap: 6 }}>
            <input type="text" className="exp-settings-input" placeholder="Username" value={authUsername} onChange={e => setAuthUsername(e.target.value)} style={{ flex: 1 }} />
            <input type="text" className="exp-settings-input" placeholder={exposure.password ? '(unchanged)' : 'Password'} value={authPassword} onChange={e => setAuthPassword(e.target.value)} style={{ flex: 1 }} />
          </div>
          <div className="exp-settings-hint">Set a custom username and password, or leave empty to auto-generate. Rate limiting protects against brute-force.</div>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          <button className="btn btn-sm btn-primary" onClick={async () => {
            setGeneratedCreds(null);
            setSaving('password');
            setFeedback(null);
            try {
              const body = {};
              if (authUsername || authPassword) {
                body.password = authPassword || undefined;
                body.authUser = authUsername || undefined;
                body.customAuth = true;
              } else {
                body.password = 'generate';
              }
              const res = await authFetch(`/api/openclaw/exposures/${exposure.slug}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body),
              });
              const data = await res.json();
              if (!res.ok) throw new Error(data.message || 'Failed');
              if (data.credentials) setGeneratedCreds(data.credentials);
              setFeedback({ type: 'success', message: 'Access control updated' });
              setAuthPassword('');
              onRefresh();
            } catch (err) {
              setFeedback({ type: 'error', message: err.message });
            } finally { setSaving(null); }
          }} disabled={saving === 'password'}>
            {saving === 'password' ? <span className="spinner" style={{ width: 11, height: 11, borderWidth: 2 }} /> : <><Lock size={12} /> {exposure.password ? 'Update Credentials' : 'Enable Protection'}</>}
          </button>
          {exposure.password && (
            <button className="btn btn-sm" onClick={handleRemovePassword} disabled={saving === 'password'}>
              <ShieldOff size={12} /> Remove
            </button>
          )}
        </div>
      </div>

      {/* Enable / Disable */}
      <div className="exp-settings-group">
        <label className="exp-settings-label">Availability</label>
        <button className="btn btn-sm" onClick={handleToggle} disabled={saving === 'toggle'}>
          {exposure.enabled ? <><PowerOff size={13} /> Disable</> : <><Power size={13} /> Enable</>}
        </button>
      </div>

      {/* Download backup */}
      {(exposure.pm2?.cwd || exposure.path) && (
        <div className="exp-settings-group">
          <label className="exp-settings-label">Source Backup</label>
          <div className="exp-backup-section">
            <button className="btn btn-sm" onClick={handleBackup} disabled={backupBusy}>
              {backupBusy ? <span className="spinner" style={{ width: 11, height: 11, borderWidth: 2 }} /> : <Download size={12} />}
              {backupBusy ? ' Preparing...' : ' Download Source Backup'}
            </button>
            <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginLeft: 8 }}>tar.gz (excludes node_modules)</span>
          </div>
        </div>
      )}

      {/* Delete */}
      <div className="exp-settings-group exp-settings-danger">
        <label className="exp-settings-label">Danger Zone</label>
        <button className="btn btn-sm btn-danger" onClick={handleDelete} disabled={saving === 'delete'}>
          <Trash2 size={13} /> Delete Web App
        </button>
      </div>
    </div>
  );
}

/* ── Detail panel (right side) ───────────────────────────── */

const TABS = [
  { id: 'overview', label: 'Overview', icon: Globe },
  { id: 'logs', label: 'Logs', icon: FileText },
  { id: 'access', label: 'Access', icon: Eye },
  { id: 'settings', label: 'Settings', icon: Settings },
];

function DetailPanel({ exposure, probeStatus, pm2Status, stats, publicBaseUrl, onPm2Action, onRefresh, onDeselect }) {
  const [activeTab, setActiveTab] = useState('overview');
  const [copied, setCopied] = useState(false);
  const baseUrl = publicBaseUrl || window.location.origin;
  const openUrl = exposure ? `${baseUrl}/open/${exposure.slug}/` : '';

  const copyLink = () => {
    navigator.clipboard.writeText(openUrl).then(() => { setCopied(true); setTimeout(() => setCopied(false), 1500); }).catch(() => {});
  };

  if (!exposure) {
    return (
      <div className="exp-detail-empty">
        <Globe size={32} strokeWidth={1} style={{ color: 'var(--text-muted)' }} />
        <p>Select a web app to view details</p>
      </div>
    );
  }

  return (
    <div className="exp-detail">
      {/* Header */}
      <div className="exp-detail-header">
        <button className="btn btn-sm exp-detail-back" onClick={onDeselect} title="Back to list"><ArrowLeft size={14} /></button>
        <div className="exp-detail-title">
          <div className="exp-detail-name">{exposure.slug}</div>
          <div className="exp-detail-url-row">
            <code className="exp-url-text-inline">{openUrl}</code>
            <button className="btn btn-sm expose-link-btn" onClick={copyLink} title="Copy" style={{ padding: '1px 4px' }}>{copied ? <Check size={11} /> : <Copy size={11} />}</button>
            <a href={openUrl} target="_blank" rel="noopener noreferrer" className="btn btn-sm expose-link-btn" title="Open" style={{ padding: '1px 4px' }}><ExternalLink size={11} /></a>
          </div>
        </div>
        <div className="exp-detail-status">
          {exposure.enabled && (
            <span className={`expose-dot ${probeStatus === true ? 'expose-dot-online' : probeStatus === false ? 'expose-dot-offline' : 'expose-dot-probing'}`} />
          )}
          <span className={`badge badge-sm ${exposure.enabled ? (probeStatus === true ? 'badge-success' : probeStatus === false ? 'badge-error' : 'badge-secondary') : 'badge-secondary'}`}>
            {exposure.enabled ? (probeStatus === true ? 'Online' : probeStatus === false ? 'Offline' : 'Checking') : 'Disabled'}
          </span>
        </div>
      </div>

      {/* Tabs */}
      <div className="exp-tabs">
        {TABS.map(tab => (
          <button key={tab.id} className={`exp-tab ${activeTab === tab.id ? 'exp-tab-active' : ''}`} onClick={() => setActiveTab(tab.id)}>
            <tab.icon size={13} /> {tab.label}
          </button>
        ))}
      </div>

      {/* Tab content */}
      <div className="exp-tab-body">
        {activeTab === 'overview' && <TabOverview exposure={exposure} probeStatus={probeStatus} pm2Status={pm2Status} onPm2Action={onPm2Action} onRefresh={onRefresh} />}
        {activeTab === 'logs' && <TabLogs exposure={exposure} />}
        {activeTab === 'access' && <TabAccess exposure={exposure} stats={stats} />}
        {activeTab === 'settings' && <TabSettings exposure={exposure} onRefresh={onRefresh} onDeselect={onDeselect} publicBaseUrl={publicBaseUrl} />}
      </div>
    </div>
  );
}

/* ── Quick start banner (when no exposures) ──────────────── */

const SCAFFOLD_STEPS = [
  { id: 'project', label: 'Create project files', duration: 800 },
  { id: 'deps', label: 'Install dependencies', duration: 8000 },
  { id: 'pm2', label: 'Start PM2 service', duration: 2000 },
  { id: 'expose', label: 'Register web app', duration: 500 },
  { id: 'verify', label: 'Verify health checks', duration: 2000 },
];

function QuickStartBanner({ onDone, toolsStatus, marketplaceEnabled }) {
  const [installing, setInstalling] = useState(null);
  const [scaffoldPhase, setScaffoldPhase] = useState('idle');
  const [activeStep, setActiveStep] = useState(-1);
  const [completedSteps, setCompletedSteps] = useState(new Set());
  const [scaffoldResult, setScaffoldResult] = useState(null);
  const [scaffoldError, setScaffoldError] = useState(null);
  const stepTimers = useRef([]);

  const cliInstalled = toolsStatus?.cli?.installed;
  const skillInstalled = toolsStatus?.skill?.installed;
  const allInstalled = cliInstalled && skillInstalled;

  const handleInstallAll = async () => {
    setInstalling('all');
    try {
      const res = await authFetch('/api/openclaw/exposures/install-all-tools', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
      if (!res.ok) throw new Error('Install failed');
      window.dispatchEvent(new CustomEvent('expose-tools-changed'));
    } catch { /* ignore */ }
    finally { setInstalling(null); }
  };

  const handleScaffold = async () => {
    setScaffoldPhase('running');
    setActiveStep(0); setCompletedSteps(new Set());
    setScaffoldResult(null); setScaffoldError(null);
    let cum = 0;
    stepTimers.current = [];
    SCAFFOLD_STEPS.forEach((step, idx) => {
      if (idx === 0) return;
      cum += SCAFFOLD_STEPS[idx - 1].duration;
      const t = setTimeout(() => { setCompletedSteps(prev => new Set([...prev, SCAFFOLD_STEPS[idx - 1].id])); setActiveStep(idx); }, cum);
      stepTimers.current.push(t);
    });
    try {
      const res = await authFetch('/api/openclaw/exposures/scaffold-hello', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || data.error || 'Failed');
      stepTimers.current.forEach(t => clearTimeout(t));
      setCompletedSteps(new Set(SCAFFOLD_STEPS.map(s => s.id)));
      setActiveStep(SCAFFOLD_STEPS.length);
      setScaffoldResult(data);
      setScaffoldPhase('done');
      onDone();
    } catch (err) {
      stepTimers.current.forEach(t => clearTimeout(t));
      setScaffoldError(err.message);
      setScaffoldPhase('error');
    }
  };

  return (
    <div className="exp-quickstart">
      {!allInstalled && marketplaceEnabled && (
        <div style={{ marginBottom: 12 }}>
          <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginBottom: 6, fontSize: '0.78rem' }}>
            <span className={`gp-dot ${cliInstalled ? 'gp-dot-ok' : ''}`} /> CLI Tool {cliInstalled ? '(ready)' : ''}
            &nbsp;&nbsp;
            <span className={`gp-dot ${skillInstalled ? 'gp-dot-ok' : ''}`} /> Web App Skill {skillInstalled ? '(ready)' : ''}
          </div>
          <button className="btn btn-primary btn-sm" onClick={handleInstallAll} disabled={!!installing}>
            {installing ? <><span className="spinner" style={{ width: 11, height: 11, borderWidth: 2 }} /> Installing...</> : <><Download size={11} /> Install Tools</>}
          </button>
        </div>
      )}
      {scaffoldPhase === 'idle' && (
        <>
          <p style={{ fontSize: '0.82rem', marginBottom: 10 }}>Scaffold a hello-world project with PM2 to get started.</p>
          <button className="btn btn-primary btn-sm" onClick={handleScaffold}><Rocket size={12} /> Create Hello World</button>
        </>
      )}
      {scaffoldPhase === 'running' && (
        <div className="qs-steps">{SCAFFOLD_STEPS.map((s, i) => {
          const done = completedSteps.has(s.id); const active = activeStep === i;
          return (<div key={s.id} className={`qs-step ${done ? 'qs-step-done' : active ? 'qs-step-active' : 'qs-step-waiting'}`}><span className="qs-step-icon">{done ? <CheckCircle size={13} /> : active ? <span className="spinner" style={{ width: 11, height: 11, borderWidth: 2 }} /> : <span className="qs-step-num">{i + 1}</span>}</span><span className="qs-step-label">{s.label}</span></div>);
        })}</div>
      )}
      {scaffoldPhase === 'done' && scaffoldResult && (
        <div><CheckCircle size={14} style={{ color: 'var(--badge-success-text)' }} /> Hello World created!
          <a href={scaffoldResult.publicUrl || scaffoldResult.url} target="_blank" rel="noopener noreferrer" className="btn btn-primary btn-sm" style={{ marginLeft: 8 }}><ExternalLink size={12} /> Open</a>
        </div>
      )}
      {scaffoldPhase === 'error' && <div className="expose-error">{scaffoldError} <button className="btn btn-sm" onClick={() => setScaffoldPhase('idle')} style={{ marginLeft: 8 }}>Retry</button></div>}
    </div>
  );
}

/* ── Guide panel (right sidebar) ──────────────────────────── */

function GuidePanel({ toolsStatus, marketplaceEnabled, hasExposures, onScaffoldDone }) {
  const [installing, setInstalling] = useState(null);
  const [feedback, setFeedback] = useState(null);
  const [openSections, setOpenSections] = useState({ tools: true });
  const [scaffoldPhase, setScaffoldPhase] = useState('idle');
  const [scaffoldResult, setScaffoldResult] = useState(null);
  const [scaffoldError, setScaffoldError] = useState(null);
  const [activeStep, setActiveStep] = useState(-1);
  const [completedSteps, setCompletedSteps] = useState(new Set());
  const stepTimers = useRef([]);

  const cliInstalled = toolsStatus?.cli?.installed;
  const skillInstalled = toolsStatus?.skill?.installed;
  const allInstalled = cliInstalled && skillInstalled;
  const noneInstalled = !cliInstalled && !skillInstalled;

  const toggle = (id) => setOpenSections(prev => ({ ...prev, [id]: !prev[id] }));
  const isOpen = (id, defaultOpen = true) => openSections[id] !== undefined ? openSections[id] : defaultOpen;

  const handleScaffold = async () => {
    setScaffoldPhase('running');
    setActiveStep(0); setCompletedSteps(new Set());
    setScaffoldResult(null); setScaffoldError(null);
    let cum = 0;
    stepTimers.current = [];
    SCAFFOLD_STEPS.forEach((step, idx) => {
      if (idx === 0) return;
      cum += SCAFFOLD_STEPS[idx - 1].duration;
      const t = setTimeout(() => { setCompletedSteps(prev => new Set([...prev, SCAFFOLD_STEPS[idx - 1].id])); setActiveStep(idx); }, cum);
      stepTimers.current.push(t);
    });
    try {
      const res = await authFetch('/api/openclaw/exposures/scaffold-hello', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || data.error || 'Failed');
      stepTimers.current.forEach(t => clearTimeout(t));
      setCompletedSteps(new Set(SCAFFOLD_STEPS.map(s => s.id)));
      setActiveStep(SCAFFOLD_STEPS.length);
      setScaffoldResult(data);
      setScaffoldPhase('done');
      if (onScaffoldDone) onScaffoldDone();
    } catch (err) {
      stepTimers.current.forEach(t => clearTimeout(t));
      setScaffoldError(err.message);
      setScaffoldPhase('error');
    }
  };

  const handleInstallAll = async () => {
    setInstalling('all');
    setFeedback(null);
    try {
      const res = await authFetch('/api/openclaw/exposures/install-all-tools', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
      if (!res.ok) throw new Error('Install failed');
      setFeedback({ type: 'success', message: 'Installed successfully' });
      window.dispatchEvent(new CustomEvent('expose-tools-changed'));
    } catch (err) { setFeedback({ type: 'error', message: err.message }); }
    finally { setInstalling(null); }
  };

  const SectionHead = ({ id, icon: Icon, label, defaultOpen }) => (
    <button className="gp-head" onClick={() => toggle(id)} aria-expanded={isOpen(id, defaultOpen)}>
      <Icon size={13} />
      <span className="gp-head-label">{label}</span>
      {isOpen(id, defaultOpen) ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
    </button>
  );

  return (
    <div className="expose-guide-panel">
      <div className="gp">
        {/* Integration status */}
        <div className="gp-section">
          <SectionHead id="tools" icon={Zap} label="Integration" />
          {isOpen('tools') && (
            <div className="gp-body">
              <div className="gp-row">
                <span className={`gp-dot ${cliInstalled ? 'gp-dot-ok' : ''}`} />
                <span className="gp-row-text">CLI Tool</span>
                <span className={`gp-tag ${cliInstalled ? 'gp-tag-ok' : 'gp-tag-miss'}`}>{cliInstalled ? 'Ready' : 'Missing'}</span>
              </div>
              <div className="gp-row">
                <span className={`gp-dot ${skillInstalled ? 'gp-dot-ok' : ''}`} />
                <span className="gp-row-text">Web App Skill</span>
                <span className={`gp-tag ${skillInstalled ? 'gp-tag-ok' : 'gp-tag-miss'}`}>{skillInstalled ? 'Ready' : 'Missing'}</span>
              </div>
              {!allInstalled && marketplaceEnabled && (
                <button className="btn btn-primary btn-sm gp-install-btn" onClick={handleInstallAll} disabled={!!installing}>
                  {installing
                    ? <><span className="spinner" style={{ width: 11, height: 11, borderWidth: 2 }} /> Installing...</>
                    : <><Download size={11} /> Install {noneInstalled ? 'All' : !cliInstalled ? 'CLI Tool' : 'Skill'}</>}
                </button>
              )}
              {feedback && (
                <div className={`gp-feedback ${feedback.type}`}>
                  {feedback.type === 'success' ? <CheckCircle size={11} /> : <XCircle size={11} />}
                  {feedback.message}
                </div>
              )}
              {allInstalled && <div className="gp-ok-msg">OpenClaw can build and deploy web apps.</div>}
            </div>
          )}
        </div>

        {/* Commands */}
        <div className="gp-section">
          <SectionHead id="cmd" icon={Terminal} label="Commands" />
          {isOpen('cmd') && (
            <div className="gp-body gp-ref">
              <div className="gp-ref-row"><span className="gp-ref-k">List</span><code>launcher-cli expose list</code></div>
              <div className="gp-ref-row"><span className="gp-ref-k">Add</span><code>launcher-cli expose add --slug &lt;n&gt; ...</code></div>
              <div className="gp-ref-row"><span className="gp-ref-k">Update</span><code>launcher-cli expose update --slug &lt;n&gt; ...</code></div>
              <div className="gp-ref-row"><span className="gp-ref-k">Remove</span><code>launcher-cli expose remove --slug &lt;n&gt;</code></div>
              <div className="gp-ref-row"><span className="gp-ref-k">PM2</span><code>pm2 logs user-&lt;slug&gt;</code></div>
              <div className="gp-ref-row"><span className="gp-ref-k">Help</span><code>launcher-cli --help</code></div>
            </div>
          )}
        </div>

        {/* Coding Preferences */}
        <div className="gp-section">
          <SectionHead id="code" icon={BookOpen} label="Coding Preferences" defaultOpen={false} />
          {isOpen('code', false) && (
            <div className="gp-body">
              <p className="gp-hint">Default stack for exposed projects:</p>
              <div className="gp-ref" style={{ marginTop: 4 }}>
                <div className="gp-ref-row"><span className="gp-ref-k">Backend</span>Node.js + Express, single <code>server.js</code></div>
                <div className="gp-ref-row"><span className="gp-ref-k">Frontend</span>React via CDN + Babel standalone</div>
                <div className="gp-ref-row"><span className="gp-ref-k">Styling</span>Inline styles or single CSS file</div>
                <div className="gp-ref-row"><span className="gp-ref-k">Build</span>None — no bundlers, no TypeScript</div>
                <div className="gp-ref-row"><span className="gp-ref-k">Deps</span>Minimal — <code>express</code> is usually enough</div>
              </div>
            </div>
          )}
        </div>

        {/* Quick Reference */}
        <div className="gp-section">
          <SectionHead id="ref" icon={FileText} label="Quick Reference" defaultOpen={false} />
          {isOpen('ref', false) && (
            <div className="gp-body gp-ref">
              <div className="gp-ref-row"><span className="gp-ref-k">Projects</span><code>~/.openclaw/workspace/projects/</code></div>
              <div className="gp-ref-row"><span className="gp-ref-k">Ports</span><code>3001+</code> (3000 reserved)</div>
              <div className="gp-ref-row"><span className="gp-ref-k">URL</span><code>/open/&lt;slug&gt;/</code></div>
              <div className="gp-ref-row"><span className="gp-ref-k">PM2 name</span><code>user-&lt;slug&gt;</code></div>
              <div className="gp-ref-row"><span className="gp-ref-k">Config</span><code>~/.openclaw/exports.yaml</code></div>
              <div className="gp-ref-row"><span className="gp-ref-k">Auth</span>HTTP Basic Auth (auto-generated)</div>
            </div>
          )}
        </div>

        {/* Quick Start — only show when no exposures exist */}
        {!hasExposures && (
          <div className="gp-section">
            <SectionHead id="quickstart" icon={Rocket} label="Quick Start" defaultOpen={!hasExposures} />
            {isOpen('quickstart', !hasExposures) && (
              <div className="gp-body">
                {scaffoldPhase === 'idle' && (
                  <>
                    <p className="gp-hint">Scaffold a hello-world project with PM2 to get started.</p>
                    <button className="btn btn-primary btn-sm gp-install-btn" onClick={handleScaffold}><Rocket size={11} /> Create Hello World</button>
                  </>
                )}
                {scaffoldPhase === 'running' && (
                  <div className="qs-steps">{SCAFFOLD_STEPS.map((s, i) => {
                    const done = completedSteps.has(s.id); const active = activeStep === i;
                    return (<div key={s.id} className={`qs-step ${done ? 'qs-step-done' : active ? 'qs-step-active' : 'qs-step-waiting'}`}><span className="qs-step-icon">{done ? <CheckCircle size={13} /> : active ? <span className="spinner" style={{ width: 11, height: 11, borderWidth: 2 }} /> : <span className="qs-step-num">{i + 1}</span>}</span><span className="qs-step-label">{s.label}</span></div>);
                  })}</div>
                )}
                {scaffoldPhase === 'done' && scaffoldResult && (
                  <div><CheckCircle size={14} style={{ color: 'var(--badge-success-text)' }} /> Hello World created!
                    <a href={scaffoldResult.publicUrl || scaffoldResult.url} target="_blank" rel="noopener noreferrer" className="btn btn-primary btn-sm" style={{ marginLeft: 8 }}><ExternalLink size={12} /> Open</a>
                  </div>
                )}
                {scaffoldPhase === 'error' && <div className="expose-error">{scaffoldError} <button className="btn btn-sm" onClick={() => setScaffoldPhase('idle')} style={{ marginLeft: 8 }}>Retry</button></div>}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

/* ── Main page ───────────────────────────────────────────── */

export default function Exposures() {
  const [exposures, setExposures] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showAdd, setShowAdd] = useState(false);
  const [probeResults, setProbeResults] = useState({});
  const [stats, setStats] = useState({});
  const [pm2Statuses, setPm2Statuses] = useState({});
  const [toolsStatus, setToolsStatus] = useState(null);
  const [marketplaceEnabled, setMarketplaceEnabled] = useState(false);
  const [publicBaseUrl, setPublicBaseUrl] = useState(null);
  const [selectedSlug, setSelectedSlug] = useState(null);
  const probeTimer = useRef(null);

  const fetchExposures = useCallback(async () => {
    try {
      const res = await authFetch('/api/openclaw/exposures');
      if (!res.ok) throw new Error('Failed to load exposures');
      const data = await res.json();
      setExposures(data.exposures || []);
      if (data.publicBaseUrl) setPublicBaseUrl(data.publicBaseUrl);
      setError(null);
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  }, []);

  const fetchToolsStatus = useCallback(async () => {
    try {
      const res = await authFetch('/api/openclaw/exposures/tools-status');
      if (res.ok) { setToolsStatus(await res.json()); setMarketplaceEnabled(true); }
    } catch { }
  }, []);

  const runProbes = useCallback(async (list) => {
    const enabled = (list || exposures).filter(e => e.enabled);
    const results = {};
    await Promise.all(enabled.map(async (exp) => {
      try { const res = await authFetch(`/api/openclaw/exposures/probe/${exp.slug}`); if (res.ok) { const d = await res.json(); results[exp.slug] = d.reachable; } } catch { }
    }));
    setProbeResults(prev => ({ ...prev, ...results }));
  }, [exposures]);

  const fetchStats = useCallback(async () => {
    try { const res = await authFetch('/api/openclaw/exposures/stats'); if (res.ok) setStats(await res.json()); } catch { }
  }, []);

  const fetchPm2Status = useCallback(async () => {
    try { const res = await authFetch('/api/openclaw/exposures/pm2-status'); if (res.ok) setPm2Statuses(await res.json()); } catch { }
  }, []);

  const handlePm2Action = useCallback(async (slug, action) => {
    try {
      const res = await authFetch('/api/openclaw/exposures/pm2-control', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ slug, action }) });
      if (!res.ok) console.error('PM2 action failed');
      setTimeout(() => { fetchPm2Status(); runProbes(exposures); }, 1500);
    } catch (err) { console.error('PM2 action error:', err); }
  }, [exposures, fetchPm2Status, runProbes]);

  useEffect(() => { fetchExposures(); fetchToolsStatus(); }, [fetchExposures, fetchToolsStatus]);
  useEffect(() => {
    const handler = () => fetchToolsStatus();
    window.addEventListener('expose-tools-changed', handler);
    return () => window.removeEventListener('expose-tools-changed', handler);
  }, [fetchToolsStatus]);

  useEffect(() => {
    if (!exposures.length) return;
    runProbes(exposures); fetchStats(); fetchPm2Status();
    probeTimer.current = setInterval(() => { runProbes(exposures); fetchStats(); fetchPm2Status(); }, 15000);
    return () => clearInterval(probeTimer.current);
  }, [exposures, runProbes, fetchStats, fetchPm2Status]);

  const handleRefresh = () => { fetchExposures(); };

  // Auto-select when there's exactly one exposure
  const singleMode = exposures.length === 1;
  const effectiveSlug = singleMode ? exposures[0].slug : selectedSlug;
  const selectedExposure = exposures.find(e => e.slug === effectiveSlug) || null;
  const activeCount = exposures.filter(e => e.enabled).length;
  const onlineCount = Object.values(probeResults).filter(v => v === true).length;
  const showSidebar = exposures.length >= 2;

  return (
    <div style={{ height: '100vh', maxHeight: '100vh', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* Header */}
      <div className="page-header" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <h1 className="page-title">Web Apps</h1>
          <p className="page-subtitle">Manage your web apps and services</p>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          {!loading && exposures.length > 0 && (
            <div className="expose-stat-pills">
              <span className="expose-stat-pill"><Globe size={13} /> {activeCount} active</span>
              {activeCount > 0 && (
                <span className={`expose-stat-pill ${onlineCount === activeCount ? 'expose-stat-pill-ok' : 'expose-stat-pill-warn'}`}>{onlineCount}/{activeCount} online</span>
              )}
            </div>
          )}
          <button className="btn btn-primary btn-sm" onClick={() => setShowAdd(true)} title="New web app"><Plus size={14} /> New</button>
        </div>
      </div>

      {/* Add form dialog (rendered as overlay) */}
      {showAdd && <AddForm show onClose={() => setShowAdd(false)} onAdd={handleRefresh} />}

      <div className="exp-layout">
        {/* Sidebar: exposure list (only shown when 2+ projects) */}
        {showSidebar && (
          <div className="exp-sidebar">
            {loading && <div style={{ padding: 16 }}><div className="skeleton-row" style={{ marginBottom: 8 }} /><div className="skeleton-row" style={{ marginBottom: 8 }} /><div className="skeleton-row" /></div>}
            {error && <div className="expose-error" style={{ margin: 12 }}>{error}</div>}

            <div className="exp-list">
              {exposures.map(exp => (
                <ExposureListItem
                  key={exp.slug}
                  exposure={exp}
                  probeStatus={probeResults[exp.slug]}
                  stats={stats[exp.slug]}
                  selected={effectiveSlug === exp.slug}
                  onClick={() => setSelectedSlug(exp.slug)}
                />
              ))}
            </div>
          </div>
        )}

        {/* Main: detail panel or empty state */}
        <div className="exp-main">
          {!loading && exposures.length === 0 ? (
            <div className="exp-detail-empty">
              <Globe size={32} strokeWidth={1} style={{ color: 'var(--text-muted)' }} />
              <p>No web apps yet</p>
              <button className="btn btn-primary btn-sm" onClick={() => setShowAdd(true)} style={{ marginTop: 8 }}><Plus size={14} /> New Web App</button>
            </div>
          ) : (
            <DetailPanel
              exposure={selectedExposure}
              probeStatus={selectedExposure ? probeResults[selectedExposure.slug] : null}
              pm2Status={selectedExposure ? pm2Statuses[selectedExposure.slug] : null}
              stats={selectedExposure ? stats[selectedExposure.slug] : null}
              publicBaseUrl={publicBaseUrl}
              onPm2Action={handlePm2Action}
              onRefresh={handleRefresh}
              onDeselect={() => setSelectedSlug(null)}
            />
          )}
        </div>

        {/* Guide panel: always visible on the right */}
        <GuidePanel toolsStatus={toolsStatus} marketplaceEnabled={marketplaceEnabled} hasExposures={exposures.length > 0} onScaffoldDone={handleRefresh} />
      </div>
    </div>
  );
}

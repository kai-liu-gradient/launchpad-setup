import React, { useEffect, useState } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { setToken } from '../hooks/useAuth';

export default function AccessLink() {
  const [searchParams] = useSearchParams();
  const [status, setStatus] = useState('verifying');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const token = searchParams.get('token');
    if (!token) {
      setStatus('error');
      setError('No access token provided');
      return;
    }

    fetch('/api/openclaw/auth/verify?token=' + encodeURIComponent(token))
      .then(res => res.json().then(data => ({ ok: res.ok, data })))
      .then(({ ok, data }) => {
        if (ok && data.token) {
          setToken(data.token);
          const redirect = searchParams.get('redirect');
          const destination = (redirect && redirect.startsWith('/') && !redirect.startsWith('//')) ? redirect : '/';
          navigate(destination, { replace: true });
        } else {
          setStatus('error');
          setError(data.message || 'Invalid or expired access link');
        }
      })
      .catch(() => {
        setStatus('error');
        setError('Failed to verify access link');
      });
  }, [searchParams, navigate]);

  return (
    <div className="login-page">
      <div className="login-card">
        <div className="login-logo">
          <div className="login-logo-icon">&gt;_</div>
          <div className="login-logo-title">Open<span className="logo-highlight">Claw</span></div>
          <div className="login-logo-sub">Launcher</div>
        </div>

        {status === 'verifying' && (
          <div className="login-notice">Verifying access link...</div>
        )}

        {status === 'error' && (
          <>
            <div className="login-error" style={{ marginBottom: '1rem' }}>{error}</div>
            <Link to="/login" className="login-button" style={{ textDecoration: 'none', textAlign: 'center', display: 'block' }}>
              Go to Login
            </Link>
          </>
        )}
      </div>
    </div>
  );
}

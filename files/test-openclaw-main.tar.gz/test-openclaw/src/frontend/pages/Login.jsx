import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

function CopyHint({ text }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // fallback
    }
  };

  return (
    <div className="login-hint-row">
      <div className="login-notice-hint">{text}</div>
      <button type="button" className="login-hint-copy" onClick={handleCopy}>
        {copied ? 'Copied' : 'Copy'}
      </button>
    </div>
  );
}

export default function Login() {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [firstRun, setFirstRun] = useState(false);
  const [initialPassword, setInitialPassword] = useState('');
  const [copied, setCopied] = useState(false);
  const [showInitDialog, setShowInitDialog] = useState(true);
  const { login, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (isAuthenticated) {
      navigate('/', { replace: true });
    }
  }, [isAuthenticated, navigate]);

  useEffect(() => {
    fetch('/api/openclaw/auth/status')
      .then(res => res.json())
      .then(data => {
        if (data.firstRun && data.initialPassword) {
          // Fresh/reset deployment — clear stale localStorage so the wizard
          // shows correctly after login instead of jumping to settings.
          localStorage.removeItem('openclaw-wizard-completed');
          localStorage.removeItem('openclaw.control.settings.v1');
          setFirstRun(true);
          setInitialPassword(data.initialPassword);
        }
      })
      .catch(() => {});
  }, []);

  const handleCopyPassword = async () => {
    try {
      await navigator.clipboard.writeText(initialPassword);
      setPassword(initialPassword);
      setCopied(true);
      setTimeout(() => {
        setCopied(false);
        setShowInitDialog(false);
      }, 600);
    } catch {
      // fallback: still fill the input even if clipboard fails
      setPassword(initialPassword);
      setShowInitDialog(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await login(password);
      navigate('/', { replace: true });
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-card">
        <div className="login-logo">
          <div className="login-logo-icon">&gt;_</div>
          <div className="login-logo-title">Open<span className="logo-highlight">Claw</span></div>
          <div className="login-logo-sub">Launcher</div>
        </div>

        <form onSubmit={handleSubmit} className="login-form">
          <div className="login-field">
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter password"
              autoFocus
              disabled={loading}
              className="login-input"
            />
          </div>
          {error && <div className="login-error">{error}</div>}
          <button type="submit" disabled={loading || !password} className="login-button">
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>

        {!firstRun && (
          <div className="login-help">
            <button
              type="button"
              className="login-help-toggle"
              onClick={() => setShowHelp(true)}
            >
              Need help with your password?
            </button>
          </div>
        )}

        {firstRun && initialPassword && showInitDialog && (
          <div className="login-dialog-overlay" onClick={() => setShowInitDialog(false)}>
            <div className="login-dialog login-init-dialog" onClick={(e) => e.stopPropagation()}>
              <div className="login-init-title">Your login password</div>
              <div className="login-init-desc">This is your auto-generated password. Copy it and paste it into the login field to sign in.</div>
              <div className="login-init-password-row">
                <code className="login-init-password">{initialPassword}</code>
                <button type="button" className="login-init-copy" onClick={handleCopyPassword}>
                  {copied ? 'Copied' : 'Copy'}
                </button>
              </div>
            </div>
          </div>
        )}

        {showHelp && (
          <div className="login-dialog-overlay" onClick={() => setShowHelp(false)}>
            <div className="login-dialog" onClick={(e) => e.stopPropagation()}>
              <div className="login-dialog-header">
                <div className="login-dialog-title">Password Help</div>
                <button
                  type="button"
                  className="login-dialog-close"
                  onClick={() => setShowHelp(false)}
                >&times;</button>
              </div>
              <div className="login-dialog-body">
                <div className="login-help-section">
                  <div className="login-help-section-title">Find your password</div>
                  <p>The password is printed to the server logs on every startup.</p>
                  <div className="login-help-step">
                    <CopyHint text="pm2 logs web --lines 20" />
                  </div>
                </div>

                <div className="login-help-section">
                  <div className="login-help-section-title">Show password on login screen</div>
                  <p>Re-create the init flag and restart. The password will be shown on this screen.</p>
                  <div className="login-help-step">
                    <CopyHint text="touch ~/.openclaw/.launcher-init && pm2 restart web" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

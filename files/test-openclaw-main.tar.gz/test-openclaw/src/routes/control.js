const express = require('express');
const router = express.Router();
const { validateInstanceId } = require('../middleware/control-auth');
const { validateJsonBody } = require('../middleware/validation');
const { signToken } = require('../middleware/launcher-auth');
const instanceControl = require('../services/instance-control');
const openclawConfig = require('../services/openclaw-config');
const pm2Health = require('../services/pm2-health');
const credentialDiscovery = require('../services/credential-discovery');
const versionTracker = require('../services/version-tracker');
const marketplace = require('../services/marketplace');
const notices = require('../services/notices');
const telegramSetup = require('../services/telegram-setup');
const systemStats = require('../services/system-stats');
const { execFile, execFileSync } = require('child_process');
const feishuSetup = require('../services/feishu-setup');
const workspaceBrowser = require('../services/workspace-browser');
const fs = require('fs');
const path = require('path');
const os = require('os');
const http = require('http');
const https = require('https');

router.use(validateJsonBody);

// Resolve which provider owns a model by searching the configured providers' model lists,
// then falling back to well-known model-name patterns (matching the frontend logic in
// Credentials.jsx inferProviderFromModelName).
function inferProviderFromModel(modelName, config) {
  // First: check configured providers for an exact match
  const providers = config?.models?.providers;
  if (providers && typeof providers === 'object') {
    for (const [providerName, providerDef] of Object.entries(providers)) {
      const models = providerDef.models || [];
      for (const m of models) {
        const id = typeof m === 'string' ? m : m.id;
        if (id === modelName) return providerName;
      }
    }
  }
  // Second: infer provider from well-known model name prefixes
  if (/^glm/i.test(modelName)) return 'zai';
  if (/^claude/i.test(modelName)) return 'anthropic';
  if (/^(gpt|o[0-9]|dall-e|whisper)/i.test(modelName)) return 'openai';
  if (/^gemini/i.test(modelName)) return 'google';
  return null;
}

// Ensure model has a provider/ prefix
function normalizeModelWithProvider(aiModel, config) {
  if (aiModel.includes('/')) return aiModel;
  const provider = inferProviderFromModel(aiModel, config);
  return provider ? `${provider}/${aiModel}` : aiModel;
}

// Re-discover and write credentials for an existing provider from all known sources
// (ZAI config, Claude settings, environment variables).  Called on every /configure
// so that credential changes are always picked up even when the provider already exists.
function refreshProviderCredentials(providerName, config) {
  // 1. Try ZAI config
  const zaiConfig = credentialDiscovery.getZaiConfigRaw();
  if (zaiConfig && Array.isArray(zaiConfig.Providers)) {
    const zaiProvider = zaiConfig.Providers.find(p => p.name === providerName);
    if (zaiProvider?.api_key) {
      const authProfiles = credentialDiscovery.readAuthProfiles();
      authProfiles.profiles[`${providerName}:default`] = { type: 'api_key', provider: providerName, key: zaiProvider.api_key };
      credentialDiscovery.writeAuthProfiles(authProfiles);
      return;
    }
  }

  // 2. Well-known env vars and Claude settings
  let apiKey = null;
  if (providerName === 'anthropic') {
    const claudeSettings = credentialDiscovery.getClaudeSettingsRaw();
    apiKey = claudeSettings?.env?.ANTHROPIC_AUTH_TOKEN || process.env.ANTHROPIC_API_KEY || null;
  } else {
    const envEntry = Object.entries(credentialDiscovery.ENV_VAR_PROVIDERS)
      .find(([, meta]) => meta.provider === providerName);
    if (envEntry) apiKey = process.env[envEntry[0]] || null;
  }

  if (apiKey) {
    const authProfiles = credentialDiscovery.readAuthProfiles();
    authProfiles.profiles[`${providerName}:default`] = { type: 'api_key', provider: providerName, key: apiKey };
    credentialDiscovery.writeAuthProfiles(authProfiles);
  }
}

// Ensure the provider entry exists in config.models.providers for a given model.
// If the provider is missing, attempt to bootstrap it from ZAI config (same logic
// as the wizard's /apply-provider endpoint).  Returns the fully-prefixed model name.
function ensureProviderForModel(aiModel, config) {
  const hasPrefix = aiModel.includes('/');
  const providerName = hasPrefix ? aiModel.split('/')[0] : inferProviderFromModel(aiModel, config);
  const modelId = hasPrefix ? aiModel.split('/').slice(1).join('/') : aiModel;

  config.models = config.models || {};
  config.models.providers = config.models.providers || {};

  // Provider already exists — make sure the model is listed AND re-discover credentials
  if (providerName && config.models.providers[providerName]) {
    const provModels = config.models.providers[providerName].models || [];
    const alreadyListed = provModels.some(m => (typeof m === 'string' ? m : m.id) === modelId);
    if (!alreadyListed) {
      provModels.push({ id: modelId, name: modelId, reasoning: true, input: ['text'], cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 }, contextWindow: 128000, maxTokens: 8192 });
      config.models.providers[providerName].models = provModels;
    }
    // Always re-discover and write credentials so reconfiguring with the same model
    // still refreshes the API key from the latest source (ZAI config, env vars, etc.)
    refreshProviderCredentials(providerName, config);
    return `${providerName}/${modelId}`;
  }

  // Provider missing — try to bootstrap from ZAI config
  const zaiConfig = credentialDiscovery.getZaiConfigRaw();
  if (zaiConfig && Array.isArray(zaiConfig.Providers)) {
    // If we already know the provider name, look for that specific one first;
    // then fall back to scanning all ZAI providers for one that lists the model.
    const zaiProvider = (providerName && zaiConfig.Providers.find(p => p.name === providerName))
      || zaiConfig.Providers.find(p => (p.models || []).includes(modelId));

    if (zaiProvider) {
      const resolvedName = zaiProvider.name;
      let baseUrl = zaiProvider.api_base_url || '';
      baseUrl = baseUrl.replace(/\/(v1\/)?(messages|chat\/completions)\/?$/, '');

      const modelDefinitions = (zaiProvider.models || []).map(mid => ({
        id: mid, name: mid, reasoning: true, input: ['text'],
        cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
        contextWindow: 128000, maxTokens: 8192,
      }));

      // Ensure the requested model is in the list
      if (!modelDefinitions.some(m => m.id === modelId)) {
        modelDefinitions.push({ id: modelId, name: modelId, reasoning: true, input: ['text'], cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 }, contextWindow: 128000, maxTokens: 8192 });
      }

      config.models.providers[resolvedName] = {
        baseUrl,
        auth: 'api-key',
        api: 'anthropic-messages',
        models: modelDefinitions,
      };

      // Write ZAI API key to auth-profiles.json
      if (zaiProvider.api_key) {
        const authProfiles = credentialDiscovery.readAuthProfiles();
        authProfiles.profiles[`${resolvedName}:default`] = { type: 'api_key', provider: resolvedName, key: zaiProvider.api_key };
        credentialDiscovery.writeAuthProfiles(authProfiles);
      }

      return `${resolvedName}/${modelId}`;
    }
  }

  // Could not bootstrap from ZAI — create a stub provider entry for well-known providers
  // so the health endpoint can display them (fixes "No providers configured" when ZAI config is absent).
  if (providerName) {
    const wellKnownDefaults = {
      anthropic: { baseUrl: 'https://api.anthropic.com', api: 'anthropic-messages' },
      openai: { baseUrl: 'https://api.openai.com', api: 'openai-completions' },
      google: { baseUrl: 'https://generativelanguage.googleapis.com', api: 'openai-completions' },
    };
    const defaults = wellKnownDefaults[providerName];
    if (defaults) {
      // For anthropic, try to discover credentials from local Claude CLI settings
      // (same sources as the wizard's /credentials/apply endpoint)
      let discoveredBaseUrl = defaults.baseUrl;
      let apiKey = null;
      if (providerName === 'anthropic') {
        const claudeSettings = credentialDiscovery.getClaudeSettingsRaw();
        const envSection = claudeSettings?.env || {};
        if (envSection.ANTHROPIC_BASE_URL) {
          let bu = envSection.ANTHROPIC_BASE_URL;
          bu = bu.replace(/\/(v1\/)?(messages|chat\/completions)\/?$/, '');
          bu = bu.replace(/\/v1\/?$/, '');
          bu = bu.replace(/\/+$/, '');
          discoveredBaseUrl = bu;
        }
        // Discover API key: settings.json ANTHROPIC_AUTH_TOKEN > ANTHROPIC_API_KEY env var
        // OAuth tokens are NOT valid API keys — reject them explicitly
        apiKey = envSection.ANTHROPIC_AUTH_TOKEN || process.env.ANTHROPIC_API_KEY || null;
        if (!apiKey) {
          // Check if this is an OAuth-only setup
          const oauthRaw = credentialDiscovery.getClaudeOAuthRaw();
          if (oauthRaw && oauthRaw.accessToken) {
            const err = new Error(
              'Claude CLI is using OAuth authentication, which is not a valid API key for the Anthropic provider. ' +
              'Please set ANTHROPIC_AUTH_TOKEN in ~/.claude/settings.json env section, or set the ANTHROPIC_API_KEY environment variable, ' +
              'or generate a headless API key from console.anthropic.com.'
            );
            err.code = 'CREDENTIALS_MISSING';
            throw err;
          }
          // No credentials at all
          const err = new Error(
            `No API key found for provider "${providerName}". ` +
            'Set ANTHROPIC_AUTH_TOKEN in ~/.claude/settings.json env section, or set the ANTHROPIC_API_KEY environment variable.'
          );
          err.code = 'CREDENTIALS_MISSING';
          throw err;
        }
      } else if (providerName === 'openai') {
        apiKey = process.env.OPENAI_API_KEY || null;
        if (!apiKey) {
          const err = new Error(`No API key found for provider "${providerName}". Set the OPENAI_API_KEY environment variable.`);
          err.code = 'CREDENTIALS_MISSING';
          throw err;
        }
      }

      // Write discovered credentials to auth-profiles.json
      if (apiKey) {
        const authProfiles = credentialDiscovery.readAuthProfiles();
        authProfiles.profiles[`${providerName}:default`] = { type: 'api_key', provider: providerName, key: apiKey };
        credentialDiscovery.writeAuthProfiles(authProfiles);
      }

      config.models.providers[providerName] = {
        baseUrl: discoveredBaseUrl,
        auth: 'api-key',
        api: defaults.api,
        models: [{ id: modelId, name: modelId, reasoning: true, input: ['text'], cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 }, contextWindow: 128000, maxTokens: 8192 }],
      };
      // Also register auth profile reference in openclaw.json
      config.auth = config.auth || {};
      config.auth.profiles = config.auth.profiles || {};
      config.auth.profiles[`${providerName}:default`] = { provider: providerName, mode: 'api_key' };
      return `${providerName}/${modelId}`;
    }
  }

  // Could not bootstrap — return as-is (best effort)
  return aiModel;
}

// Check that an API key exists for a given provider.  Resolves from auth-profiles.json,
// provider.apiKey inline, or environment variables (same chain as openclaw.js resolveProviderApiKey).
// Throws with code CREDENTIALS_MISSING when the key cannot be found or only OAuth is available.
function requireProviderApiKey(providerName, config) {
  // 1. auth-profiles.json
  const authProfiles = credentialDiscovery.readAuthProfiles();
  const profile = authProfiles.profiles?.[`${providerName}:default`];
  if (profile?.key || profile?.token) return;

  // 2. Inline apiKey on the provider object
  const provider = config?.models?.providers?.[providerName];
  if (provider?.apiKey) return;

  // 3. Well-known env vars (ANTHROPIC_API_KEY, OPENAI_API_KEY, etc.)
  const envEntry = Object.entries(credentialDiscovery.ENV_VAR_PROVIDERS)
    .find(([, meta]) => meta.provider === providerName);
  if (envEntry && process.env[envEntry[0]]) return;

  // 4. For anthropic, also check ANTHROPIC_AUTH_TOKEN in Claude settings
  if (providerName === 'anthropic') {
    const claudeSettings = credentialDiscovery.getClaudeSettingsRaw();
    if (claudeSettings?.env?.ANTHROPIC_AUTH_TOKEN) return;
  }

  // No valid API key found — build a descriptive error
  const oauthRaw = providerName === 'anthropic' ? credentialDiscovery.getClaudeOAuthRaw() : null;
  const hint = oauthRaw?.accessToken
    ? `Claude CLI is using OAuth authentication, which is not a valid API key for the "${providerName}" provider. ` +
      'Please set ANTHROPIC_AUTH_TOKEN in ~/.claude/settings.json env section, set the ANTHROPIC_API_KEY environment variable, ' +
      'or generate a headless API key from console.anthropic.com.'
    : `No API key found for provider "${providerName}". Configure credentials via the launcher UI (Credentials page) or set the appropriate environment variable.`;
  const err = new Error(hint);
  err.code = 'CREDENTIALS_MISSING';
  throw err;
}

// ==========================================
// POST /control/v1/allocate (Task 4, 11)
// ==========================================
router.post('/allocate', (req, res) => {
  try {
    const { botToken, aiModel, userId, pairKey, allowedModels } = req.body || {};

    // Validate required fields (Task 27)
    if (!botToken || typeof botToken !== 'string') {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'botToken is required and must be a string', 400);
      return res.status(err.httpStatus).json(err.body);
    }
    if (aiModel !== undefined && typeof aiModel !== 'string') {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'aiModel must be a string when provided', 400);
      return res.status(err.httpStatus).json(err.body);
    }
    if (!userId || typeof userId !== 'string') {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'userId is required and must be a string', 400);
      return res.status(err.httpStatus).json(err.body);
    }
    if (allowedModels !== undefined && (!Array.isArray(allowedModels) || !allowedModels.every(m => typeof m === 'string'))) {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'allowedModels must be an array of strings when provided', 400);
      return res.status(err.httpStatus).json(err.body);
    }

    // Validate pairKey format when provided: must be "direct:{telegramChatId}"
    let pairedChatId = null;
    if (pairKey) {
      if (typeof pairKey !== 'string') {
        const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'pairKey must be a string', 400);
        return res.status(err.httpStatus).json(err.body);
      }
      const directMatch = pairKey.match(/^direct:(\d+)$/);
      if (!directMatch) {
        const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'pairKey must be in format "direct:{telegramChatId}"', 400);
        return res.status(err.httpStatus).json(err.body);
      }
      pairedChatId = directMatch[1];
    }

    // Verify adoption is complete before allowing allocation
    const adoptionPool = instanceControl.getManagedPoolConfig();
    if (!adoptionPool?.isAdopted) {
      instanceControl.recordFailure('allocate', 'NOT_ADOPTED', 'Allocation rejected — adoption not complete');
      const err = instanceControl.errorResponse('INVALID_STATE', 'Adoption is incomplete — token has not been consumed', 409);
      return res.status(err.httpStatus).json(err.body);
    }

    const currentStatus = instanceControl.getStatus();

    // Cannot allocate if already allocated
    if (currentStatus === instanceControl.STATES.ACTIVE ||
        currentStatus === instanceControl.STATES.PROVISIONING) {
      instanceControl.recordFailure('allocate', 'ALREADY_ALLOCATED', 'Instance is already allocated');
      const err = instanceControl.errorResponse('ALREADY_ALLOCATED', 'Instance is already allocated', 409);
      return res.status(err.httpStatus).json(err.body);
    }

    // Must be AVAILABLE to allocate
    if (currentStatus !== instanceControl.STATES.AVAILABLE) {
      instanceControl.recordFailure('allocate', 'INVALID_STATE', `Cannot allocate from state ${currentStatus}`);
      const err = instanceControl.errorResponse('INVALID_STATE', `Cannot allocate from state ${currentStatus}`, 409);
      return res.status(err.httpStatus).json(err.body);
    }

    // Transition to PROVISIONING
    const provResult = instanceControl.transitionState(instanceControl.STATES.PROVISIONING);
    if (!provResult.success) {
      const err = instanceControl.errorResponse('INVALID_STATE', `Cannot transition from ${provResult.from} to PROVISIONING`, 409);
      return res.status(err.httpStatus).json(err.body);
    }

    // Write bot config to openclaw.json
    const config = openclawConfig.readConfig();
    if (!config) {
      const err = instanceControl.errorResponse('INSTANCE_UNAVAILABLE', 'Instance configuration not found', 503);
      return res.status(err.httpStatus).json(err.body);
    }

    // Set up Telegram channel with botToken
    config.channels = config.channels || {};
    config.channels.telegram = config.channels.telegram || {};
    config.channels.telegram.accounts = config.channels.telegram.accounts || {};
    config.channels.telegram.accounts.default = config.channels.telegram.accounts.default || {};
    config.channels.telegram.accounts.default.botToken = botToken;
    config.channels.telegram.accounts.default.enabled = true;
    // Enable telegram plugin so health check detects it as fully configured
    config.plugins = config.plugins || {};
    config.plugins.entries = config.plugins.entries || {};
    config.plugins.entries.telegram = config.plugins.entries.telegram || {};
    config.plugins.entries.telegram.enabled = true;

    // Configure user pairing when pairKey is present
    if (pairedChatId) {
      const account = config.channels.telegram.accounts.default;
      // Set allowFrom with the paired user's Telegram chat ID
      const existingAllowFrom = Array.isArray(account.allowFrom) ? account.allowFrom.map(String) : [];
      if (!existingAllowFrom.includes(pairedChatId)) {
        account.allowFrom = [...existingAllowFrom, pairedChatId];
      }
      // Set dmPolicy to allowlist so the bot accepts messages from allowFrom users
      account.dmPolicy = 'allowlist';
    }

    // Set AI model in agents config (optional — preserves existing model if not provided)
    if (aiModel) {
      const normalizedModel = ensureProviderForModel(aiModel, config);
      // Verify credentials exist for the resolved provider before committing
      const resolvedProvider = normalizedModel.includes('/') ? normalizedModel.split('/')[0] : null;
      if (resolvedProvider) {
        requireProviderApiKey(resolvedProvider, config);
      }
      config.agents = config.agents || {};
      config.agents.defaults = config.agents.defaults || {};
      config.agents.defaults.model = config.agents.defaults.model || {};
      config.agents.defaults.model.primary = normalizedModel;
    }

    config.meta = config.meta || {};
    config.meta.lastTouchedAt = new Date().toISOString();
    openclawConfig.writeConfig(config);

    // Store userId, pairKey, and allowedModels in launcher.json (not openclaw.json)
    instanceControl.updateManagedPoolConfig({
      userId,
      ...(pairKey ? { pairKey } : {}),
    });
    if (allowedModels) {
      const launcherConfig = openclawConfig.readLauncherConfig() || {};
      launcherConfig.allowedModels = allowedModels;
      openclawConfig.writeLauncherConfig(launcherConfig);
    }

    // Write credentials to auth-profiles.json (Task 11 - following Goal 006 pattern)
    // Note: ensureProviderForModel already writes ZAI API keys when bootstrapping,
    // but we still create the profile entry for non-ZAI or already-configured providers.
    if (aiModel) {
      const normalizedModel = config.agents.defaults.model.primary;
      const authProfiles = credentialDiscovery.readAuthProfiles();
      const providerName = normalizedModel.includes('/') ? normalizedModel.split('/')[0] : 'default';
      authProfiles.profiles[`${providerName}:default`] = authProfiles.profiles[`${providerName}:default`] || {};
      credentialDiscovery.writeAuthProfiles(authProfiles);
    }

    // Restart gateway via PM2
    const restartResult = pm2Health.restartGateway();

    // Transition to ACTIVE
    instanceControl.transitionState(instanceControl.STATES.ACTIVE);

    // Clear failure tracking on successful allocation
    instanceControl.clearFailures();

    const pool = instanceControl.getManagedPoolConfig();
    res.json(instanceControl.successResponse({
      instanceId: pool.instanceId,
      status: 'PROVISIONING',
      controlUrl: `/control/v1`,
    }));
  } catch (err) {
    console.error('[Control API] allocate error:', err.message);
    if (err.code === 'CREDENTIALS_MISSING') {
      instanceControl.recordFailure('allocate', 'CREDENTIALS_MISSING', err.message);
      const errResp = instanceControl.errorResponse('CREDENTIALS_MISSING', err.message, 400);
      return res.status(errResp.httpStatus).json(errResp.body);
    }
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// ==========================================
// PUT /control/v1/instances/:id/configure (Task 4, 12)
// ==========================================
router.put('/instances/:id/configure', validateInstanceId, async (req, res) => {
  try {
    const { aiModel, botToken, pairKey, allowedModels, channel, feishuAppId, feishuAppSecret, feishuDomain, feishuPluginVersion } = req.body || {};

    // Must be ACTIVE, PROVISIONING, or AVAILABLE to configure
    const currentStatus = instanceControl.getStatus();
    if (currentStatus !== instanceControl.STATES.ACTIVE && currentStatus !== instanceControl.STATES.PROVISIONING && currentStatus !== instanceControl.STATES.AVAILABLE) {
      instanceControl.recordFailure('configure', 'INVALID_STATE', `Cannot configure in state ${currentStatus}`);
      const err = instanceControl.errorResponse('INVALID_STATE', `Cannot configure in state ${currentStatus}`, 409);
      return res.status(err.httpStatus).json(err.body);
    }

    // Validate allowedModels when provided
    if (allowedModels !== undefined && (!Array.isArray(allowedModels) || !allowedModels.every(m => typeof m === 'string'))) {
      instanceControl.recordFailure('configure', 'INVALID_PARAMETERS', 'allowedModels must be an array of strings');
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'allowedModels must be an array of strings', 400);
      return res.status(err.httpStatus).json(err.body);
    }

    // Validate channel when provided
    if (channel !== undefined && typeof channel !== 'string') {
      instanceControl.recordFailure('configure', 'INVALID_PARAMETERS', 'channel must be a string');
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'channel must be a string', 400);
      return res.status(err.httpStatus).json(err.body);
    }

    // When channel is "feishu", feishuAppId and feishuAppSecret are required
    const isFeishuChannel = channel === 'feishu';
    if (isFeishuChannel) {
      if (!feishuAppId || typeof feishuAppId !== 'string') {
        instanceControl.recordFailure('configure', 'INVALID_PARAMETERS', 'feishuAppId is required when channel is "feishu"');
        const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'feishuAppId is required when channel is "feishu"', 400);
        return res.status(err.httpStatus).json(err.body);
      }
      if (!feishuAppSecret || typeof feishuAppSecret !== 'string') {
        instanceControl.recordFailure('configure', 'INVALID_PARAMETERS', 'feishuAppSecret is required when channel is "feishu"');
        const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'feishuAppSecret is required when channel is "feishu"', 400);
        return res.status(err.httpStatus).json(err.body);
      }
      if (feishuDomain !== undefined && feishuDomain !== 'feishu' && feishuDomain !== 'lark') {
        instanceControl.recordFailure('configure', 'INVALID_PARAMETERS', 'feishuDomain must be "feishu" or "lark"');
        const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'feishuDomain must be "feishu" or "lark"', 400);
        return res.status(err.httpStatus).json(err.body);
      }
      if (feishuPluginVersion !== undefined && feishuPluginVersion !== null && feishuPluginVersion !== '' && feishuPluginVersion !== 'auto') {
        if (typeof feishuPluginVersion !== 'string' || !/^[a-zA-Z0-9._\-]+$/.test(feishuPluginVersion)) {
          instanceControl.recordFailure('configure', 'INVALID_PARAMETERS', 'feishuPluginVersion must contain only alphanumeric characters, dots, hyphens, and underscores');
          const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'feishuPluginVersion must contain only alphanumeric characters, dots, hyphens, and underscores', 400);
          return res.status(err.httpStatus).json(err.body);
        }
      }
    }

    // At least one field must be provided
    if (!aiModel && !botToken && !pairKey && !allowedModels && !isFeishuChannel) {
      instanceControl.recordFailure('configure', 'INVALID_PARAMETERS', 'At least one configuration field is required');
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'At least one configuration field is required', 400);
      return res.status(err.httpStatus).json(err.body);
    }

    let config = openclawConfig.readConfig();
    if (!config) {
      const err = instanceControl.errorResponse('INSTANCE_UNAVAILABLE', 'Instance configuration not found', 503);
      return res.status(err.httpStatus).json(err.body);
    }

    const appliedConfig = {};
    let needsRestart = false;

    if (aiModel) {
      const normalizedModel = ensureProviderForModel(aiModel, config);
      // Verify credentials exist for the resolved provider before committing
      const resolvedProvider = normalizedModel.includes('/') ? normalizedModel.split('/')[0] : null;
      if (resolvedProvider) {
        requireProviderApiKey(resolvedProvider, config);
      }
      config.agents = config.agents || {};
      config.agents.defaults = config.agents.defaults || {};
      config.agents.defaults.model = config.agents.defaults.model || {};
      config.agents.defaults.model.primary = normalizedModel;
      appliedConfig.aiModel = normalizedModel;
      needsRestart = true;
    }

    // Store allowedModels restriction in launcher.json (not openclaw.json)
    if (allowedModels) {
      const launcherConfig = openclawConfig.readLauncherConfig() || {};
      launcherConfig.allowedModels = allowedModels;
      openclawConfig.writeLauncherConfig(launcherConfig);
      appliedConfig.allowedModels = allowedModels;
    }

    if (botToken) {
      config.channels = config.channels || {};
      config.channels.telegram = config.channels.telegram || {};
      config.channels.telegram.accounts = config.channels.telegram.accounts || {};
      config.channels.telegram.accounts.default = config.channels.telegram.accounts.default || {};
      config.channels.telegram.accounts.default.botToken = botToken;
      // Enable telegram plugin so health check detects it as fully configured
      config.plugins = config.plugins || {};
      config.plugins.entries = config.plugins.entries || {};
      config.plugins.entries.telegram = config.plugins.entries.telegram || {};
      config.plugins.entries.telegram.enabled = true;
      appliedConfig.botToken = '***configured***';
      needsRestart = true;
    }

    // Configure Feishu channel when channel is "feishu"
    if (isFeishuChannel) {
      // Auto-shutdown any running Feishu WebSocket test probes
      feishuSetup.stopAllProbes();
      // Validate Feishu credentials against the API
      const domain = feishuDomain || 'feishu';
      const validation = await feishuSetup.validateCredentials(feishuAppId.trim(), feishuAppSecret.trim(), domain);
      if (!validation.valid) {
        instanceControl.recordFailure('configure', 'INVALID_PARAMETERS', 'Feishu credentials are invalid');
        const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'Feishu credentials are invalid', 400);
        return res.status(err.httpStatus).json(err.body);
      }

      // Install and enable feishu plugin if not already present
      // Use user-specified version, or try current openclaw version, or fall back to latest
      const pluginEnabled = !!config.plugins?.entries?.feishu?.enabled;
      if (!pluginEnabled) {
        let pluginInstalled = false;
        const effectiveVersion = (feishuPluginVersion && feishuPluginVersion !== 'auto') ? feishuPluginVersion : null;
        if (effectiveVersion) {
          try {
            execFileSync('openclaw', ['plugins', 'install', `@openclaw/feishu@${effectiveVersion}`], { timeout: 30000 });
            pluginInstalled = true;
          } catch {}
        }
        if (!pluginInstalled) {
          const currentVersion = versionTracker.detectInstalledVersion();
          if (currentVersion) {
            try {
              execFileSync('openclaw', ['plugins', 'install', `@openclaw/feishu@${currentVersion}`], { timeout: 30000 });
              pluginInstalled = true;
            } catch {}
          }
        }
        if (!pluginInstalled) {
          try { execFileSync('openclaw', ['plugins', 'install', '@openclaw/feishu'], { timeout: 30000 }); } catch {}
        }
        try { execFileSync('openclaw', ['plugins', 'enable', 'feishu'], { timeout: 10000 }); } catch {}
        config = openclawConfig.readConfig() || config;
      }

      const channelConfig = feishuSetup.buildChannelConfig(feishuAppId.trim(), feishuAppSecret.trim(), {
        connectionMode: 'websocket',
        domain: domain !== 'feishu' ? domain : undefined,
      });
      config = openclawConfig.mergeConfig(config, channelConfig);

      // Persist channel selection in launcher.json
      try {
        const lc = openclawConfig.readLauncherConfig() || {};
        lc.channels = lc.channels || {};
        lc.channels.feishu = true;
        openclawConfig.writeLauncherConfig(lc);
      } catch {}

      appliedConfig.channel = 'feishu';
      appliedConfig.feishuAppId = '***configured***';
      appliedConfig.feishuAppSecret = '***configured***';
      if (feishuDomain) appliedConfig.feishuDomain = feishuDomain;
      appliedConfig.feishuPluginVersion = config.plugins?.entries?.feishu?.version || null;
      needsRestart = true;
    }

    if (pairKey) {
      if (typeof pairKey !== 'string') {
        instanceControl.recordFailure('configure', 'INVALID_PARAMETERS', 'pairKey must be a string');
        const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'pairKey must be a string', 400);
        return res.status(err.httpStatus).json(err.body);
      }
      const directMatch = pairKey.match(/^direct:(\d+)$/);
      if (!directMatch) {
        instanceControl.recordFailure('configure', 'INVALID_PARAMETERS', 'pairKey must be in format "direct:{telegramChatId}"');
        const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'pairKey must be in format "direct:{telegramChatId}"', 400);
        return res.status(err.httpStatus).json(err.body);
      }
      const pairedChatId = directMatch[1];

      // Configure allowFrom on the Telegram account
      config.channels = config.channels || {};
      config.channels.telegram = config.channels.telegram || {};
      config.channels.telegram.accounts = config.channels.telegram.accounts || {};
      config.channels.telegram.accounts.default = config.channels.telegram.accounts.default || {};
      const account = config.channels.telegram.accounts.default;
      const existingAllowFrom = Array.isArray(account.allowFrom) ? account.allowFrom.map(String) : [];
      if (!existingAllowFrom.includes(pairedChatId)) {
        account.allowFrom = [...existingAllowFrom, pairedChatId];
      }
      account.dmPolicy = 'allowlist';

      // Store pairKey in launcher.json (not openclaw.json)
      instanceControl.updateManagedPoolConfig({ pairKey });
      appliedConfig.pairKey = '***configured***';
      needsRestart = true;
    }

    config.meta = config.meta || {};
    config.meta.lastTouchedAt = new Date().toISOString();
    openclawConfig.writeConfig(config);

    // Reload gateway if config changed
    if (needsRestart) {
      pm2Health.restartGateway();
    }

    res.json(instanceControl.successResponse({
      status: instanceControl.getStatus(),
      appliedConfig,
    }));
  } catch (err) {
    console.error('[Control API] configure error:', err.message);
    if (err.code === 'CREDENTIALS_MISSING') {
      instanceControl.recordFailure('configure', 'CREDENTIALS_MISSING', err.message);
      const errResp = instanceControl.errorResponse('CREDENTIALS_MISSING', err.message, 400);
      return res.status(errResp.httpStatus).json(errResp.body);
    }
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// ==========================================
// POST /control/v1/instances/:id/restart (Task 4, 14)
// ==========================================
router.post('/instances/:id/restart', validateInstanceId, (req, res) => {
  try {
    const currentStatus = instanceControl.getStatus();
    if (currentStatus !== instanceControl.STATES.ACTIVE && currentStatus !== instanceControl.STATES.PROVISIONING && currentStatus !== instanceControl.STATES.AVAILABLE) {
      instanceControl.recordFailure('restart', 'INVALID_STATE', `Cannot restart in state ${currentStatus}`);
      const err = instanceControl.errorResponse('INVALID_STATE',
        `Cannot restart in state ${currentStatus}`, 409);
      return res.status(err.httpStatus).json(err.body);
    }

    // Check if the gateway port is occupied by an unmanaged process
    const config = openclawConfig.readConfig();
    const gwPort = config?.gateway?.port || 18789;
    const mgmt = pm2Health.checkGatewayManagement(gwPort);
    if (mgmt.unmanagedDaemon) {
      const cmdHint = mgmt.portProcessCmd ? ` (${mgmt.portProcessCmd})` : '';
      instanceControl.recordFailure('restart', 'GATEWAY_NOT_MANAGED', 'Gateway is not managed by the launcher');
      const err = instanceControl.errorResponse('GATEWAY_NOT_MANAGED',
        `Gateway port ${gwPort} is currently occupied by an unmanaged process (PID ${mgmt.portPid})${cmdHint}. ` +
        `Please manually kill the process (kill ${mgmt.portPid}) and then restart the openclaw-gateway service, ` +
        `or use the doctor-fix endpoint which will attempt to reclaim the port automatically.`, 409);
      return res.status(err.httpStatus).json(err.body);
    }

    // Soft restart via PM2 — recycle process, preserve config
    const restartResult = pm2Health.restartGateway();
    if (!restartResult.success) {
      const err = instanceControl.errorResponse('INSTANCE_UNAVAILABLE',
        `Failed to restart gateway: ${restartResult.error}`, 503);
      return res.status(err.httpStatus).json(err.body);
    }

    res.json(instanceControl.successResponse({
      status: 'ACTIVE',
      restartedAt: new Date().toISOString(),
    }));
  } catch (err) {
    console.error('[Control API] restart error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// ==========================================
// POST /control/v1/instances/:id/reset (Task 4, 15)
// ==========================================
router.post('/instances/:id/reset', validateInstanceId, (req, res) => {
  try {
    const { confirm } = req.body || {};

    if (confirm !== true) {
      instanceControl.recordFailure('reset', 'INVALID_PARAMETERS', 'confirm must be true to perform a reset');
      const err = instanceControl.errorResponse('INVALID_PARAMETERS',
        'confirm must be true to perform a reset', 400);
      return res.status(err.httpStatus).json(err.body);
    }

    const currentStatus = instanceControl.getStatus();
    if (currentStatus !== instanceControl.STATES.ACTIVE) {
      instanceControl.recordFailure('reset', 'INVALID_STATE', `Cannot reset in state ${currentStatus}`);
      const err = instanceControl.errorResponse('INVALID_STATE',
        `Cannot reset in state ${currentStatus}`, 409);
      return res.status(err.httpStatus).json(err.body);
    }

    // Clear conversation history and runtime caches from ~/.openclaw/workspace
    // Preserve config files
    const workspacePath = openclawConfig.OPENCLAW_WORKSPACE;
    if (fs.existsSync(workspacePath)) {
      const entries = fs.readdirSync(workspacePath);
      for (const entry of entries) {
        const fullPath = path.join(workspacePath, entry);
        try {
          const stat = fs.statSync(fullPath);
          if (stat.isDirectory()) {
            fs.rmSync(fullPath, { recursive: true, force: true });
          } else {
            // Preserve config-like files at root level
            if (!entry.endsWith('.json')) {
              fs.unlinkSync(fullPath);
            }
          }
        } catch (rmErr) {
          console.error(`[Control API] Failed to remove ${fullPath}:`, rmErr.message);
        }
      }
    }

    // Restart gateway
    pm2Health.restartGateway();

    res.json(instanceControl.successResponse({
      status: 'ACTIVE',
      resetAt: new Date().toISOString(),
    }));
  } catch (err) {
    console.error('[Control API] reset error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// ==========================================
// POST /control/v1/instances/:id/resize (Task 4, 16)
// ==========================================
router.post('/instances/:id/resize', validateInstanceId, (req, res) => {
  try {
    const { modelId } = req.body || {};

    if (!modelId || typeof modelId !== 'string') {
      instanceControl.recordFailure('resize', 'INVALID_PARAMETERS', 'modelId is required');
      const err = instanceControl.errorResponse('INVALID_PARAMETERS',
        'modelId is required', 400);
      return res.status(err.httpStatus).json(err.body);
    }

    const currentStatus = instanceControl.getStatus();
    if (currentStatus !== instanceControl.STATES.ACTIVE && currentStatus !== instanceControl.STATES.PROVISIONING && currentStatus !== instanceControl.STATES.AVAILABLE) {
      instanceControl.recordFailure('resize', 'INVALID_STATE', `Cannot resize in state ${currentStatus}`);
      const err = instanceControl.errorResponse('INVALID_STATE',
        `Cannot resize in state ${currentStatus}`, 409);
      return res.status(err.httpStatus).json(err.body);
    }

    // Check if same model
    const pool = instanceControl.getManagedPoolConfig();
    if (pool?.modelId === modelId) {
      instanceControl.recordFailure('resize', 'SAME_TIER', `Instance is already using model ${modelId}`);
      const err = instanceControl.errorResponse('SAME_TIER',
        `Instance is already using model ${modelId}`, 409);
      return res.status(err.httpStatus).json(err.body);
    }

    // Store modelId in config
    instanceControl.updateManagedPoolConfig({ modelId });

    res.json(instanceControl.successResponse({
      status: 'ACTIVE',
      newModelId: modelId,
      resizedAt: new Date().toISOString(),
    }));
  } catch (err) {
    console.error('[Control API] resize error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// ==========================================
// GET /control/v1/instances/:id/status (Task 4, 17)
// ==========================================
router.get('/instances/:id/status', validateInstanceId, async (req, res) => {
  try {
    const pool = instanceControl.getManagedPoolConfig();
    const currentStatus = pool?.status;

    // Check for adoption token consumption (Task 9)
    const adoptionToken = req.query.token;
    if (adoptionToken) {
      if (pool?.isAdopted === true) {
        console.warn('[Control API] Ignoring adoption token for already-adopted instance');
      } else if (pool?.adoptionToken) {
        const consumed = instanceControl.consumeAdoptionToken(adoptionToken);
        if (consumed) {
          console.log('[Control API] Adoption token consumed successfully');
          instanceControl.clearFailures();
        } else {
          instanceControl.recordFailure('status', 'INVALID_TOKEN', 'Adoption token invalid or already consumed');
        }
      } else {
        instanceControl.recordFailure('status', 'INVALID_TOKEN', 'Adoption token invalid or already consumed');
      }
    }

    // Gather health data from pm2Health service
    const gatewayProcess = pm2Health.getOpenClawGatewayProcess();
    const config = openclawConfig.readConfig();
    const port = config?.gateway?.port || 18789;
    const probe = await pm2Health.probeGateway(port);

    // Determine health
    let health = 'unhealthy';
    let healthIssue = null;
    if (gatewayProcess && gatewayProcess.status === 'online' && probe.reachable) {
      health = 'healthy';
    } else if (gatewayProcess && gatewayProcess.status === 'online') {
      health = 'degraded';
    }

    // Detect crash-loop: high restart count + very low uptime
    // Skip during grace period after a user-triggered restart to avoid false positives.
    if (gatewayProcess && !pm2Health.isInRestartGracePeriod()) {
      const uptimeMs = gatewayProcess.uptime || 0;
      const restarts = gatewayProcess.restartCount || 0;
      const unstable = gatewayProcess.unstableRestarts || 0;
      if ((restarts >= 3 || unstable >= 2) && uptimeMs < 30000) {
        health = 'crash_loop';
        const configExists = openclawConfig.readConfig();
        if (!configExists) {
          healthIssue = `Gateway is not properly configured — openclaw.json not found. The gateway will be automatically stopped until configuration is complete and reprovisioning is done. Doctor Fix will not help in this case.`;
        } else {
          healthIssue = `Gateway keeps restarting (${restarts} restarts, uptime ${Math.floor(uptimeMs / 1000)}s). Configuration may have issues.`;
        }
        // When port is still reachable but the service is crash-looping,
        // stop the gateway to prevent resource waste and allow recovery.
        if (probe.reachable) {
          console.warn('[Control API] Crash-loop detected with port still reachable — stopping openclaw-gateway');
          pm2Health.stopGateway();
          healthIssue += ' Gateway has been automatically stopped because the port was still reachable during crash loop.';
        }
      }
    }

    if (!gatewayProcess) {
      healthIssue = 'Gateway process not found in PM2.';
    }

    // Calculate uptime in seconds
    const uptime = gatewayProcess?.uptime ? Math.floor(gatewayProcess.uptime / 1000) : 0;

    // Get current model
    const aiModel = config?.agents?.defaults?.model?.primary || null;

    const freshPool = instanceControl.getManagedPoolConfig();

    const openclawVersion = versionTracker.detectInstalledVersion();
    const launcherBuild = versionTracker.getLauncherBuildInfo();

    const responseData = {
      instanceId: freshPool?.instanceId || null,
      status: freshPool?.status || currentStatus || 'UNKNOWN',
      uptime,
      aiModel,
      health,
      openclawVersion,
      launcherVersion: launcherBuild.version,
      uiBuildVersion: launcherBuild.uiBuildVersion,
      lastActivity: new Date().toISOString(),
    };
    if (healthIssue) responseData.healthIssue = healthIssue;
    if (launcherBuild.version && launcherBuild.uiBuildVersion && launcherBuild.version !== launcherBuild.uiBuildVersion) {
      responseData.uiBuildStale = true;
      responseData.uiBuildHint = 'UI build is outdated — run npm install && pm2 restart web to sync.';
    }

    // Include instance identity (name + emoji + creature + vibe) from IDENTITY.md
    try {
      const idFile = workspaceBrowser.readWorkspaceFile('IDENTITY.md', 'workspace');
      const idContent = (idFile.content || '').split(/^---$/m)[0];
      const parseField = (key, maxLen = 80) => {
        const m = idContent.match(new RegExp(`^-\\s*\\**${key}:\\**\\s*(.+)`, 'mi'));
        if (!m) return null;
        let val = m[1].trim();
        if (/^\(.*\)$/.test(val)) return null;
        if (/pick\s+something/i.test(val)) return null;
        if (val.length > maxLen) val = val.slice(0, maxLen);
        return val;
      };
      const parseDisplayField = (key, maxLen = 80) => {
        const val = parseField(key, maxLen);
        if (!val) return null;
        const cleaned = val.replace(/\s*\([^)]*\)\s*$/, '').trim();
        return cleaned || null;
      };
      const emojiVal = parseDisplayField('Emoji', 10);
      responseData.instance = {
        name: parseDisplayField('Name', 40) || null,
        emoji: (emojiVal && [...emojiVal].length <= 2) ? emojiVal : null,
        creature: parseField('Creature') || null,
        vibe: parseField('Vibe') || null,
      };
    } catch (_) {
      responseData.instance = { name: null, emoji: null, creature: null, vibe: null };
    }

    res.json(instanceControl.successResponse(responseData));
  } catch (err) {
    console.error('[Control API] status error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// ==========================================
// POST /control/v1/instances/:id/terminate (Task 4, 18)
// ==========================================
router.post('/instances/:id/terminate', validateInstanceId, (req, res) => {
  try {
    const currentStatus = instanceControl.getStatus();

    // Can terminate from ACTIVE, SUSPENDED, or PROVISIONING
    if (currentStatus === instanceControl.STATES.TERMINATED) {
      instanceControl.recordFailure('terminate', 'INVALID_STATE', 'Instance is already terminated');
      const err = instanceControl.errorResponse('INVALID_STATE',
        'Instance is already terminated', 409);
      return res.status(err.httpStatus).json(err.body);
    }

    const transition = instanceControl.transitionState(instanceControl.STATES.TERMINATED);
    if (!transition.success) {
      instanceControl.recordFailure('terminate', 'INVALID_STATE', `Cannot terminate from state ${transition.from}`);
      const err = instanceControl.errorResponse('INVALID_STATE',
        `Cannot terminate from state ${transition.from}`, 409);
      return res.status(err.httpStatus).json(err.body);
    }

    // Stop the gateway PM2 process
    try {
      const { execSync } = require('child_process');
      execSync('pm2 stop openclaw-gateway', { encoding: 'utf-8', timeout: 10000 });
    } catch (stopErr) {
      console.error('[Control API] Failed to stop gateway on terminate:', stopErr.message);
    }

    // Mark as terminated
    instanceControl.updateManagedPoolConfig({
      terminatedAt: new Date().toISOString(),
    });

    res.json(instanceControl.successResponse({
      status: 'TERMINATED',
      terminatedAt: new Date().toISOString(),
    }));
  } catch (err) {
    console.error('[Control API] terminate error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// ==========================================
// POST /control/v1/instances/:id/pair (PairWithKey)
// ==========================================
router.post('/instances/:id/pair', validateInstanceId, (req, res) => {
  try {
    const { pairKey, channel } = req.body || {};

    if (!pairKey || typeof pairKey !== 'string') {
      instanceControl.recordFailure('pair', 'INVALID_PARAMETERS', 'pairKey is required and must be a string');
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'pairKey is required and must be a string', 400);
      return res.status(err.httpStatus).json(err.body);
    }

    // Sanitize: only allow alphanumeric pairing codes
    const sanitized = pairKey.trim().replace(/[^A-Za-z0-9]/g, '');
    if (!sanitized) {
      instanceControl.recordFailure('pair', 'INVALID_PARAMETERS', 'Invalid pairKey format');
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'Invalid pairKey format', 400);
      return res.status(err.httpStatus).json(err.body);
    }

    // Auto-detect channel from pairing files when not explicitly provided
    let resolvedChannel = channel || 'telegram';
    if (!channel) {
      try {
        const feishuPairingPath = path.join(os.homedir(), '.openclaw', 'credentials', 'feishu-pairing.json');
        const feishuData = JSON.parse(fs.readFileSync(feishuPairingPath, 'utf8'));
        const requests = Array.isArray(feishuData.requests) ? feishuData.requests : [];
        const hasPending = requests.some(r => !r.approvedAt && r.code === sanitized);
        if (hasPending) resolvedChannel = 'feishu';
      } catch {}
    }

    // Run: openclaw pairing approve {channel} {code}
    execFile('openclaw', ['pairing', 'approve', resolvedChannel, sanitized], { timeout: 10000 }, (execErr, stdout, stderr) => {
      if (execErr) {
        instanceControl.recordFailure('pair', 'PAIRING_FAILED', (stderr || execErr.message).trim());
        const err = instanceControl.errorResponse('PAIRING_FAILED', (stderr || execErr.message).trim(), 500);
        return res.status(err.httpStatus).json(err.body);
      }

      // Store pairKey and pairing-done flag in launcher.json
      instanceControl.updateManagedPoolConfig({ pairKey: sanitized });
      try {
        const lc = openclawConfig.readLauncherConfig() || {};
        if (resolvedChannel === 'feishu') {
          lc.feishuPairingDone = true;
        } else {
          lc.telegramPairingDone = true;
        }
        openclawConfig.writeLauncherConfig(lc);
      } catch {}

      res.json(instanceControl.successResponse({
        status: instanceControl.getStatus(),
        channel: resolvedChannel,
        message: (stdout || 'Pairing approved').trim(),
      }));
    });
  } catch (err) {
    console.error('[Control API] pair error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// ==========================================
// POST /control/v1/instances/:id/access-link
// ==========================================
router.post('/instances/:id/access-link', validateInstanceId, (req, res) => {
  try {
    const token = signToken({ type: 'access-link' }, '1h');
    if (!token) {
      const err = instanceControl.errorResponse('INTERNAL_ERROR', 'Failed to generate access link', 500);
      return res.status(err.httpStatus).json(err.body);
    }

    const protocol = req.protocol;
    const host = req.get('host');
    const { redirect } = req.body || {};
    let link = `${protocol}://${host}/auth/access?token=${token}`;
    if (redirect && typeof redirect === 'string' && redirect.startsWith('/') && !redirect.startsWith('//')) {
      link += `&redirect=${encodeURIComponent(redirect)}`;
    }

    res.json(instanceControl.successResponse({
      link,
      expiresIn: '1 hour',
    }));
  } catch (err) {
    console.error('[Control API] access-link error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// ==========================================
// Health Probe (full batch + individual replay)
// ==========================================

// Lightweight HEAD probe to a provider baseUrl
function probeProviderUrl(baseUrl, timeout = 5000) {
  return new Promise((resolve) => {
    try {
      const url = new URL(baseUrl);
      const mod = url.protocol === 'https:' ? https : http;
      const req = mod.request(url, { method: 'HEAD', timeout }, (res) => {
        res.resume();
        resolve(true);
      });
      req.on('error', () => resolve(false));
      req.on('timeout', () => { req.destroy(); resolve(false); });
      req.end();
    } catch {
      resolve(false);
    }
  });
}

// Resolve API key for a provider: auth-profiles > provider.apiKey > env var
function resolveProviderApiKey(providerName, provider) {
  const authProfiles = credentialDiscovery.readAuthProfiles();
  const profile = authProfiles.profiles?.[`${providerName}:default`];
  const profileKey = profile?.key || profile?.token || null;
  if (profileKey) return profileKey;
  if (provider?.apiKey) return provider.apiKey;
  const envProviders = credentialDiscovery.ENV_VAR_PROVIDERS;
  const envEntry = Object.entries(envProviders).find(([, meta]) => meta.provider === providerName);
  return envEntry ? process.env[envEntry[0]] || null : null;
}

// Individual health check functions — each returns a self-contained result object.
// These mirror the checks used by the frontend health page (/api/openclaw/health/batch).

async function healthCheckConfig() {
  return pm2Health.getConfigHealthChecks();
}

async function healthCheckModels() {
  const config = openclawConfig.readConfig();
  if (!config) return { providers: [] };
  const providers = config.models?.providers || {};
  const providerResults = [];
  const entries = Object.entries(providers);
  const probes = await Promise.allSettled(entries.map(([, provider]) => {
    if (provider.baseUrl) return probeProviderUrl(provider.baseUrl, 5000);
    return Promise.resolve(null);
  }));
  entries.forEach(([name, provider], i) => {
    const rawKey = resolveProviderApiKey(name, provider);
    const keyPrefix = rawKey ? rawKey.slice(0, 8) + '...' + rawKey.slice(-6) : null;
    const probeResult = probes[i];
    let reachable = null;
    let detail = '';
    if (provider.baseUrl) {
      reachable = probeResult.status === 'fulfilled' ? probeResult.value : false;
      detail = reachable ? 'Reachable' : (reachable === false ? 'Unreachable' : 'Connection failed');
    } else {
      detail = 'No baseUrl configured';
    }
    providerResults.push({
      name, configured: true, reachable,
      baseUrl: provider.baseUrl || null,
      apiFormat: provider.api || 'openai-completions',
      keyPrefix,
      models: (provider.models || []).map(m => typeof m === 'string' ? m : m.id || m.name),
      detail,
    });
  });
  let defaultModel = config.agents?.defaults?.model?.primary || null;
  // Normalize unprefixed model — resolve provider so consumers see a valid prefixed name
  if (defaultModel && !defaultModel.includes('/')) {
    const match = entries.find(([, provider]) =>
      (provider.models || []).some(m => (typeof m === 'string' ? m : m.id) === defaultModel)
    );
    if (match) {
      defaultModel = `${match[0]}/${defaultModel}`;
    } else {
      const inferred = inferProviderFromModel(defaultModel, config);
      if (inferred && config.models?.providers?.[inferred]) {
        defaultModel = `${inferred}/${defaultModel}`;
      } else {
        // Provider not configured — report as null so consumers detect model-missing state
        defaultModel = null;
      }
    }
  }
  return { providers: providerResults, defaultModel };
}

async function healthCheckTelegram() {
  const config = openclawConfig.readConfig();
  if (!config) return { configured: false, botValid: null, botUsername: null, pluginEnabled: false, detail: 'No config file' };
  const telegramConfig = config.channels?.telegram;
  const account = telegramConfig?.accounts?.default;
  const pluginEnabled = !!config.plugins?.entries?.telegram?.enabled;
  if (!account || !account.botToken) return { configured: false, botValid: null, botUsername: null, pluginEnabled, detail: 'Telegram not configured' };

  const telegramApiPromise = telegramSetup.telegramRequest(account.botToken, 'getMe', 5000);
  const dmPolicy = account.dmPolicy || null;
  const configAllowFrom = Array.isArray(account.allowFrom) ? account.allowFrom.map(String) : [];
  const userSources = new Map();
  for (const id of configAllowFrom) userSources.set(id, (userSources.get(id) || []).concat('openclaw.json'));
  for (const fname of ['telegram-allowFrom.json', 'telegram-default-allowFrom.json']) {
    try {
      const storeData = JSON.parse(fs.readFileSync(path.join(os.homedir(), '.openclaw', 'credentials', fname), 'utf8'));
      if (Array.isArray(storeData.allowFrom)) {
        for (const id of storeData.allowFrom.map(String)) userSources.set(id, (userSources.get(id) || []).concat(fname));
      }
    } catch {}
  }
  const allPairedUsers = [...userSources.keys()];
  const paired = allPairedUsers.length > 0;
  const pairedCount = allPairedUsers.length;

  let pairingRequests = [];
  if (dmPolicy === 'pairing') {
    try {
      const pairingData = JSON.parse(fs.readFileSync(path.join(os.homedir(), '.openclaw', 'credentials', 'telegram-pairing.json'), 'utf8'));
      const requests = Array.isArray(pairingData.requests) ? pairingData.requests : [];
      pairingRequests = requests.filter(r => !r.approvedAt);
    } catch {}
  }

  let botValid = false, botUsername = null, detail = '';
  try {
    const result = await telegramApiPromise;
    if (result.ok) { botValid = true; botUsername = result.result.username || null; detail = 'Bot token valid'; }
    else { detail = result.description || 'Bot token invalid'; }
  } catch (err) { detail = `Telegram API error: ${err.message}`; }

  return { configured: true, botValid, botUsername, pluginEnabled, detail, dmPolicy, pairingRequests, paired, pairedCount };
}

async function healthCheckFeishu() {
  const config = openclawConfig.readConfig();
  if (!config) return { configured: false, pluginEnabled: false, detail: 'No config file' };
  const feishuConfig = config.channels?.feishu;
  const pluginEnabled = !!config.plugins?.entries?.feishu?.enabled;
  if (!feishuConfig || !feishuConfig.appId) return { configured: false, pluginEnabled, detail: 'Feishu not configured' };

  const domain = feishuConfig.domain || 'feishu';
  const connectionMode = feishuConfig.connectionMode || 'websocket';
  const dmPolicy = feishuConfig.dmPolicy || null;

  let credentialsValid = false, botName = null, detail = '';
  try {
    const tenantToken = await feishuSetup.getTenantAccessToken(feishuConfig.appId, feishuConfig.appSecret, domain);
    credentialsValid = true;
    detail = 'Credentials valid';
    try {
      const botInfo = await feishuSetup.getBotInfo(tenantToken, domain);
      if (botInfo) botName = botInfo.app_name || null;
    } catch {}
  } catch (err) { detail = `Feishu API error: ${err.message}`; }

  // Check pairing status (always read — dmPolicy may not be set for feishu)
  let pairingRequests = [];
  try {
    const pairingData = JSON.parse(fs.readFileSync(path.join(os.homedir(), '.openclaw', 'credentials', 'feishu-pairing.json'), 'utf8'));
    const requests = Array.isArray(pairingData.requests) ? pairingData.requests : [];
    pairingRequests = requests.filter(r => !r.approvedAt);
  } catch {}

  // Check paired users from feishu allowFrom (config + store files, mirroring telegram pattern)
  const configAllowFrom = Array.isArray(feishuConfig.allowFrom) ? feishuConfig.allowFrom.map(String) : [];
  const userSources = new Map();
  for (const id of configAllowFrom) userSources.set(id, (userSources.get(id) || []).concat('openclaw.json'));
  for (const fname of ['feishu-allowFrom.json', 'feishu-default-allowFrom.json']) {
    try {
      const storeData = JSON.parse(fs.readFileSync(path.join(os.homedir(), '.openclaw', 'credentials', fname), 'utf8'));
      if (Array.isArray(storeData.allowFrom)) {
        for (const id of storeData.allowFrom.map(String)) userSources.set(id, (userSources.get(id) || []).concat(fname));
      }
    } catch {}
  }
  const allPairedUsers = [...userSources.keys()];
  const paired = allPairedUsers.length > 0;
  const pairedCount = allPairedUsers.length;

  return { configured: true, credentialsValid, pluginEnabled, domain, connectionMode, botName, detail, dmPolicy, pairingRequests, paired, pairedCount };
}

async function healthCheckGateway() {
  const gatewayProcess = pm2Health.getOpenClawGatewayProcess();
  const config = openclawConfig.readConfig();
  const port = config?.gateway?.port || 18789;
  const probe = await pm2Health.probeGateway(port);
  const tokenSync = pm2Health.checkTokenSync();
  const tokenHealth = pm2Health.checkTokenHealth();
  const management = pm2Health.checkGatewayManagement(port);
  const zombies = pm2Health.checkZombieProcesses();
  return { process: gatewayProcess, probe, security: { token: tokenHealth, tokenSync }, management, zombies, restartGracePeriod: pm2Health.isInRestartGracePeriod() };
}

async function healthCheckLogs() {
  return pm2Health.getGatewayLogInfo();
}

async function healthCheckVersion() {
  const info = await versionTracker.checkForUpdate();
  const lc = openclawConfig.readLauncherConfig();
  info.upgradePolicy = lc?.upgradePolicy || 'manual';
  return info;
}

const HEALTH_SECTIONS = {
  config: healthCheckConfig,
  models: healthCheckModels,
  telegram: healthCheckTelegram,
  feishu: healthCheckFeishu,
  gateway: healthCheckGateway,
  logs: healthCheckLogs,
  version: healthCheckVersion,
  resources: () => systemStats.getSummary(),
};

// GET /control/v1/instances/:id/health — full batch health probe (all sections in parallel)
router.get('/instances/:id/health', validateInstanceId, async (req, res) => {
  try {
    const batchStart = Date.now();

    // Prime PM2 cache once to avoid redundant execSync calls
    pm2Health.getPm2Processes();

    const entries = Object.entries(HEALTH_SECTIONS);
    const timings = {};
    const results = {};

    const settled = await Promise.allSettled(entries.map(async ([key, fn]) => {
      const t0 = Date.now();
      try {
        const result = await fn();
        timings[key] = Date.now() - t0;
        return result;
      } catch (err) {
        timings[key] = Date.now() - t0;
        throw err;
      }
    }));

    entries.forEach(([key], i) => {
      const r = settled[i];
      results[key] = r.status === 'fulfilled' ? r.value : { error: r.reason?.message || 'Failed' };
    });

    pm2Health.invalidatePm2Cache();

    results._timing = { ...timings, total: Date.now() - batchStart };

    res.json(instanceControl.successResponse(results));
  } catch (err) {
    console.error('[Control API] health batch error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// GET /control/v1/instances/:id/health/:section — individual section replay
router.get('/instances/:id/health/:section', validateInstanceId, async (req, res) => {
  try {
    const { section } = req.params;
    const fn = HEALTH_SECTIONS[section];
    if (!fn) {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS',
        `Unknown health section "${section}". Valid sections: ${Object.keys(HEALTH_SECTIONS).join(', ')}`, 400);
      return res.status(err.httpStatus).json(err.body);
    }

    const t0 = Date.now();
    const result = await fn();
    const durationMs = Date.now() - t0;

    res.json(instanceControl.successResponse({ ...result, _timing: { durationMs } }));
  } catch (err) {
    console.error(`[Control API] health/${req.params.section} error:`, err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// ==========================================
// System Stats (Goal 022)
// ==========================================

// GET /control/v1/instances/:id/system-stats — resource utilization metrics with windowed aggregations
router.get('/instances/:id/system-stats', validateInstanceId, (req, res) => {
  try {
    const summary = systemStats.getSummary();
    res.json(instanceControl.successResponse(summary));
  } catch (err) {
    console.error('[Control API] system-stats error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// ==========================================
// Feishu WebSocket Test (temporary WS connection for setup verification)
// ==========================================

// POST /control/v1/instances/:id/feishu/ws-test — enable a temporary WebSocket test connection (max 2 min)
router.post('/instances/:id/feishu/ws-test', validateInstanceId, async (req, res) => {
  try {
    // Stop any existing probes before starting a new one
    feishuSetup.stopAllProbes();

    const config = openclawConfig.readConfig();
    const feishuConfig = config?.channels?.feishu;
    if (!feishuConfig?.appId || !feishuConfig?.appSecret) {
      const err = instanceControl.errorResponse('INVALID_STATE', 'Feishu channel is not configured', 400);
      return res.status(err.httpStatus).json(err.body);
    }

    const domain = feishuConfig.domain || 'feishu';
    console.log(`[Control API] feishu ws-test: domain=${domain}, apiBase=${feishuSetup.getApiBase(domain)}`);
    const result = await feishuSetup.startWsProbe(feishuConfig.appId, feishuConfig.appSecret, domain, { maxDurationMs: 120000 });
    // If domain was auto-corrected, update the saved config
    if (result.domainCorrected && result.domain) {
      try {
        const cfg = openclawConfig.readConfig();
        if (cfg?.channels?.feishu) {
          cfg.channels.feishu.domain = result.domain;
          openclawConfig.writeConfig(cfg);
          console.log(`[Control API] feishu domain auto-corrected: ${domain} -> ${result.domain}, config updated`);
        }
      } catch (e) {
        console.error('[Control API] failed to persist domain correction:', e.message);
      }
    }
    res.json(instanceControl.successResponse(result));
  } catch (err) {
    console.error('[Control API] feishu ws-test enable error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// GET /control/v1/instances/:id/feishu/ws-test — get current WebSocket test status
router.get('/instances/:id/feishu/ws-test', validateInstanceId, (req, res) => {
  try {
    // Find the most recent active probe session
    const config = openclawConfig.readConfig();
    const feishuConfig = config?.channels?.feishu;
    if (!feishuConfig?.appId) {
      const err = instanceControl.errorResponse('INVALID_STATE', 'Feishu channel is not configured', 400);
      return res.status(err.httpStatus).json(err.body);
    }

    // Return status of all active probes (typically one)
    const { sessionId } = req.query;
    if (sessionId) {
      const status = feishuSetup.getProbeStatus(sessionId);
      if (!status) {
        return res.json(instanceControl.successResponse({ active: false, sessionId, message: 'Session not found or expired' }));
      }
      return res.json(instanceControl.successResponse({ active: status.status === 'connected', ...status }));
    }

    // No sessionId — report whether any probe is running
    res.json(instanceControl.successResponse({ active: false, message: 'Provide sessionId query parameter to check a specific test session' }));
  } catch (err) {
    console.error('[Control API] feishu ws-test status error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// DELETE /control/v1/instances/:id/feishu/ws-test — disable/stop all WebSocket test connections
router.delete('/instances/:id/feishu/ws-test', validateInstanceId, (req, res) => {
  try {
    const stopped = feishuSetup.stopAllProbes();
    res.json(instanceControl.successResponse({ stopped, message: stopped > 0 ? `Stopped ${stopped} active probe(s)` : 'No active probes to stop' }));
  } catch (err) {
    console.error('[Control API] feishu ws-test disable error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// ==========================================
// Upgrade Policy & Version Override
// ==========================================

// GET /control/v1/instances/:id/upgrade-policy — read current upgrade policy
router.get('/instances/:id/upgrade-policy', validateInstanceId, (req, res) => {
  try {
    const lc = openclawConfig.readLauncherConfig();
    const upgradePolicy = lc?.upgradePolicy || 'manual';
    res.json(instanceControl.successResponse({ upgradePolicy }));
  } catch (err) {
    console.error('[Control API] upgrade-policy read error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// PUT /control/v1/instances/:id/upgrade-policy — set upgrade policy to "manual" or "auto"
router.put('/instances/:id/upgrade-policy', validateInstanceId, (req, res) => {
  try {
    const { upgradePolicy } = req.body;
    if (!upgradePolicy) {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'upgradePolicy is required', 400);
      return res.status(err.httpStatus).json(err.body);
    }
    if (!['manual', 'auto'].includes(upgradePolicy)) {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'upgradePolicy must be "manual" or "auto"', 400);
      return res.status(err.httpStatus).json(err.body);
    }
    const lc = openclawConfig.readLauncherConfig() || {};
    lc.upgradePolicy = upgradePolicy;
    openclawConfig.writeLauncherConfig(lc);
    res.json(instanceControl.successResponse({ upgradePolicy }));
  } catch (err) {
    console.error('[Control API] upgrade-policy write error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// PUT /control/v1/instances/:id/version/override — set .installed-version file to a specific version
router.put('/instances/:id/version/override', validateInstanceId, (req, res) => {
  try {
    const { version } = req.body;
    if (!version || typeof version !== 'string') {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'version is required (string)', 400);
      return res.status(err.httpStatus).json(err.body);
    }
    if (!/^\d+(\.\d+)*$/.test(version.trim())) {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'Invalid version format — digits separated by dots expected (e.g. "2026.3.1")', 400);
      return res.status(err.httpStatus).json(err.body);
    }
    const trimmed = version.trim();
    versionTracker.persistVersion(trimmed);
    // Setting a version override implicitly switches to manual policy
    const lc = openclawConfig.readLauncherConfig() || {};
    lc.upgradePolicy = 'manual';
    openclawConfig.writeLauncherConfig(lc);
    res.json(instanceControl.successResponse({ version: trimmed, upgradePolicy: 'manual' }));
  } catch (err) {
    console.error('[Control API] version/override write error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// DELETE /control/v1/instances/:id/version/override — clear the .installed-version override
router.delete('/instances/:id/version/override', validateInstanceId, (req, res) => {
  try {
    const overridePath = path.join(os.homedir(), '.openclaw', '.installed-version');
    if (fs.existsSync(overridePath)) {
      fs.unlinkSync(overridePath);
    }
    res.json(instanceControl.successResponse({ cleared: true }));
  } catch (err) {
    console.error('[Control API] version/override delete error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// ==========================================
// Marketplace Catalog Management (Goal 019)
// ==========================================

// POST /control/v1/marketplace/sync-compare — compare a remote item list against local catalog
// Accepts { items: [{ id, type, version }] } and returns per-item comparison results.
router.post('/marketplace/sync-compare', (req, res) => {
  try {
    const { items } = req.body || {};
    if (!Array.isArray(items)) {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'items must be an array', 400);
      return res.status(err.httpStatus).json(err.body);
    }

    const localCatalog = marketplace.getCatalog();
    const localMap = new Map(localCatalog.map(i => [i.id, i]));
    const installRecords = marketplace.getCatalogInstallState();
    const installMap = new Map(installRecords.map(i => [i.id, i]));

    // Track which remote IDs we've seen (for detecting local-only items to delete)
    const remoteIds = new Set(items.map(i => i.id));

    const results = [];

    // Compare each remote item against local state
    for (const remoteItem of items) {
      if (!remoteItem.id || typeof remoteItem.id !== 'string') continue;

      const local = localMap.get(remoteItem.id);
      const installState = installMap.get(remoteItem.id);

      if (!local) {
        // New item — not in local catalog at all
        results.push({
          id: remoteItem.id,
          status: 'new',
          remoteVersion: remoteItem.version || null,
          remoteType: remoteItem.type || null,
          installed: false,
        });
        continue;
      }

      const installed = !!(installState && installState.installed);
      const entry = {
        id: remoteItem.id,
        localVersion: local.version,
        remoteVersion: remoteItem.version || null,
        localType: local.type,
        remoteType: remoteItem.type || null,
        installed,
        installedVersion: installState ? installState.installedVersion || null : null,
      };

      // Detect type mismatch
      if (remoteItem.type && remoteItem.type !== local.type) {
        entry.status = 'type_changed';
      } else if (remoteItem.version && remoteItem.version !== local.version) {
        entry.status = 'outdated';
      } else {
        entry.status = 'current';
      }

      results.push(entry);
    }

    // Find local external items NOT in the remote list (candidates for deletion)
    const toDelete = [];
    for (const local of localCatalog) {
      if (local.builtin) continue; // never suggest deleting builtins
      if (!remoteIds.has(local.id)) {
        const installState = installMap.get(local.id);
        toDelete.push({
          id: local.id,
          name: local.name,
          type: local.type,
          version: local.version,
          installed: !!(installState && installState.installed),
        });
      }
    }

    res.json(instanceControl.successResponse({ results, toDelete }));
  } catch (err) {
    console.error('[Control API] marketplace sync-compare error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// GET /control/v1/marketplace/catalog — return full catalog (external + built-in) with install state
router.get('/marketplace/catalog', (req, res) => {
  try {
    const catalog = marketplace.getCatalog();
    res.json(instanceControl.successResponse({ items: catalog }));
  } catch (err) {
    console.error('[Control API] marketplace catalog read error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// GET /control/v1/marketplace/install-state — return install state for all catalog items
router.get('/marketplace/install-state', (req, res) => {
  try {
    const state = marketplace.getCatalogInstallState();
    res.json(instanceControl.successResponse({ items: state }));
  } catch (err) {
    console.error('[Control API] marketplace install-state read error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// PUT /control/v1/marketplace/catalog — replace the entire external registry
// autoInstall (default: false) — when false, existing install state is preserved unchanged.
// When true, items are automatically installed/upgraded after writing.
router.put('/marketplace/catalog', (req, res) => {
  try {
    const { items, autoInstall } = req.body || {};
    if (!Array.isArray(items)) {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'items must be an array', 400);
      return res.status(err.httpStatus).json(err.body);
    }

    // Validate each item
    for (let i = 0; i < items.length; i++) {
      const errors = marketplace.validateRegistryItem(items[i]);
      if (errors.length > 0) {
        const err = instanceControl.errorResponse('INVALID_PARAMETERS', `Item ${i} validation failed: ${errors.join('; ')}`, 400);
        return res.status(err.httpStatus).json(err.body);
      }
    }

    // Deduplicate items by id (last occurrence wins) before writing
    const dedupMap = new Map();
    for (const item of items) dedupMap.set(item.id, item);
    const dedupedItems = [...dedupMap.values()];

    // Merge strategy: replace uninstalled items entirely with the new catalog,
    // but preserve installed items that are no longer in the new catalog.
    // This allows the admin to remove old catalog entries while keeping
    // installed items manageable (so users can still uninstall them).
    const newItemIds = new Set(dedupedItems.map(i => i.id));
    const newItemMap = new Map(dedupedItems.map(i => [i.id, i]));
    const installRecords = marketplace.getCatalogInstallState();
    const oldRegistry = marketplace.readExternalRegistryOnly();

    // Clean up install records when an item's type changes (same ID, different type).
    // This prevents stale install state from the old type persisting after catalog replacement.
    for (const oldItem of oldRegistry.items) {
      const newItem = newItemMap.get(oldItem.id);
      if (newItem && newItem.type !== oldItem.type) {
        try {
          const oldStatus = marketplace.getItemStatus(oldItem.id);
          if (oldStatus && (oldStatus.installed || oldStatus.status === 'broken')) {
            marketplace.uninstallItem(oldItem.id);
          }
        } catch { /* best effort cleanup */ }
        // Remove stale install record even if uninstall didn't run
        marketplace.removeInstallRecord(oldItem.id);
      }
    }

    const retainedItems = oldRegistry.items.filter(oldItem => {
      // Keep old items that are installed but NOT in the new catalog
      if (newItemIds.has(oldItem.id)) return false; // new catalog has it, use new version
      const state = installRecords.find(s => s.id === oldItem.id);
      return state && state.installed;
    });

    marketplace.writeExternalRegistry({ items: [...dedupedItems, ...retainedItems] });

    // Auto-enable marketplace feature when items are written
    if (items.length > 0) {
      const lc = openclawConfig.readLauncherConfig() || {};
      if (!lc.enableMarketplace) {
        lc.enableMarketplace = true;
        openclawConfig.writeLauncherConfig(lc);
        console.log('[Control API] Marketplace auto-enabled via catalog write');
      }
    }

    // Auto-install/upgrade: opt in with top-level autoInstall: true (applies to all items)
    // or per-item autoInstall: true (applies only to that item).
    // File-copy types (skill, mcp) are always reinstalled on sync when already installed,
    // regardless of autoInstall flag, to keep on-disk files in sync with the catalog manifest.
    const globalAutoInstall = autoInstall === true;
    const installResults = [];
    let anyAutoInstall = false;

    if (dedupedItems.length > 0) {
      for (const item of dedupedItems) {
        const itemAutoInstall = globalAutoInstall || item.autoInstall === true;
        const isFileCopyType = marketplace.FILE_COPY_TYPES.includes(item.type);

        try {
          const status = marketplace.getItemStatus(item.id);

          // File-copy types: always reinstall if already installed (sync refreshes on-disk files)
          if (isFileCopyType && status && status.installed) {
            anyAutoInstall = true;
            try { marketplace.uninstallItem(item.id); } catch {}
            const result = marketplace.installItem(item.id);
            if (result.requiresAction) {
              installResults.push({ id: item.id, action: 'prerequisites_required', prerequisites: result.prerequisites });
            } else {
              installResults.push({ id: item.id, action: 'reinstalled', ...result });
            }
            continue;
          }

          // For other types (exec, tool) and not-yet-installed file-copy items: respect autoInstall flag
          if (!itemAutoInstall) continue;
          anyAutoInstall = true;

          // Skip if already installed and up to date
          if (status && status.installed && !status.updateAvailable && status.status !== 'broken') {
            installResults.push({ id: item.id, action: 'none', message: 'already up to date' });
            continue;
          }

          // Clean up before update/repair
          if (status && (status.updateAvailable || status.status === 'broken')) {
            try { marketplace.uninstallItem(item.id); } catch {}
          }

          const result = marketplace.installItem(item.id);

          if (result.requiresAction) {
            installResults.push({ id: item.id, action: 'prerequisites_required', prerequisites: result.prerequisites });
          } else {
            const action = status && status.updateAvailable ? 'updated' : 'installed';
            installResults.push({ id: item.id, action, ...result });
          }
        } catch (installErr) {
          installResults.push({ id: item.id, action: 'error', message: installErr.message });
        }
      }
    }

    // Auto-configure launcher-cli if it was installed/reinstalled during sync
    const cliInstalled = installResults.some(r => r.id === 'openclaw-launcher-cli' && (r.action === 'installed' || r.action === 'reinstalled' || r.action === 'updated'));
    if (cliInstalled) {
      try {
        const toolConfigPath = path.join(os.homedir(), '.openclaw', 'tools', 'launcher-cli', 'config.json');
        if (fs.existsSync(path.dirname(toolConfigPath))) {
          const token = signToken({ type: 'cli-tool' }, '90d');
          if (token) {
            let cfg = {};
            try { cfg = JSON.parse(fs.readFileSync(toolConfigPath, 'utf-8')); } catch { /* fresh */ }
            cfg.url = cfg.url || 'http://localhost:3000';
            cfg.token = token;
            fs.writeFileSync(toolConfigPath, JSON.stringify(cfg, null, 2), { mode: 0o600 });
            console.log('[Control API] Auto-configured launcher-cli with fresh auth token');
          }
        }
      } catch (e) {
        console.warn('[Control API] Failed to auto-configure launcher-cli:', e.message);
      }
    }

    res.json(instanceControl.successResponse({
      items: dedupedItems,
      count: dedupedItems.length,
      ...(anyAutoInstall ? { installResults } : {}),
    }));
  } catch (err) {
    console.error('[Control API] marketplace catalog write error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// POST /control/v1/marketplace/items — add a single item to the external registry
// autoInstall (default: false) — when false, existing install state is preserved unchanged.
// When true, the item is automatically installed/upgraded after adding.
router.post('/marketplace/items', (req, res) => {
  try {
    const { item, autoInstall } = req.body || {};
    if (!item || typeof item !== 'object') {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'item is required and must be an object', 400);
      return res.status(err.httpStatus).json(err.body);
    }

    // Reject items that collide with builtin ids — builtins are managed in source
    if (marketplace.isBuiltinItem(item.id)) {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', `Item "${item.id}" is a built-in item and cannot be added externally`, 400);
      return res.status(err.httpStatus).json(err.body);
    }

    const errors = marketplace.validateRegistryItem(item);
    if (errors.length > 0) {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', `Validation failed: ${errors.join('; ')}`, 400);
      return res.status(err.httpStatus).json(err.body);
    }

    const registry = marketplace.readExternalRegistryOnly();

    // Replace if item with same ID exists, otherwise append
    const existingIdx = registry.items.findIndex(i => i.id === item.id);
    if (existingIdx >= 0) {
      // If the type changed, clean up old install record/artifacts from the previous type
      const oldItem = registry.items[existingIdx];
      if (oldItem.type !== item.type) {
        try {
          const oldStatus = marketplace.getItemStatus(item.id);
          if (oldStatus && (oldStatus.installed || oldStatus.status === 'broken')) {
            marketplace.uninstallItem(item.id);
          }
        } catch { /* best effort cleanup */ }
        // Remove stale install record even if uninstall didn't run (e.g. not formally installed)
        marketplace.removeInstallRecord(item.id);
      }
      registry.items[existingIdx] = item;
    } else {
      registry.items.push(item);
    }

    marketplace.writeExternalRegistry(registry);

    // Auto-enable marketplace feature when items are added
    const lc = openclawConfig.readLauncherConfig() || {};
    if (!lc.enableMarketplace) {
      lc.enableMarketplace = true;
      openclawConfig.writeLauncherConfig(lc);
      console.log('[Control API] Marketplace auto-enabled via item add');
    }

    // Auto-install/upgrade: opt in with top-level autoInstall: true or per-item autoInstall: true.
    // File-copy types (skill, mcp) are always reinstalled on sync when already installed,
    // regardless of autoInstall flag, to keep on-disk files in sync with the catalog manifest.
    const shouldAutoInstall = autoInstall === true || item.autoInstall === true;
    const isFileCopyType = marketplace.FILE_COPY_TYPES.includes(item.type);
    let installResult = null;
    let didInstallAction = false;

    try {
      const status = marketplace.getItemStatus(item.id);

      // File-copy types: always reinstall if already installed (sync refreshes on-disk files)
      if (isFileCopyType && status && status.installed) {
        didInstallAction = true;
        try { marketplace.uninstallItem(item.id); } catch {}
        const result = marketplace.installItem(item.id);
        if (result.requiresAction) {
          installResult = { action: 'prerequisites_required', prerequisites: result.prerequisites };
        } else {
          installResult = { action: 'reinstalled', ...result };
        }
      } else if (shouldAutoInstall) {
        didInstallAction = true;

        if (status && status.installed && !status.updateAvailable && status.status !== 'broken') {
          installResult = { action: 'none', message: 'already up to date' };
        } else {
          // Clean up before update/repair
          if (status && (status.updateAvailable || status.status === 'broken')) {
            try { marketplace.uninstallItem(item.id); } catch {}
          }

          const result = marketplace.installItem(item.id);

          if (result.requiresAction) {
            installResult = { action: 'prerequisites_required', prerequisites: result.prerequisites };
          } else {
            const action = status && status.updateAvailable ? 'updated' : 'installed';
            installResult = { action, ...result };
          }
        }
      }
    } catch (installErr) {
      didInstallAction = true;
      installResult = { action: 'error', message: installErr.message };
    }

    // Auto-configure launcher-cli if it was installed during this add
    if (didInstallAction && installResult && ['installed', 'reinstalled', 'updated'].includes(installResult.action)) {
      const installedIds = [item.id, ...(installResult.installedDeps || []).map(d => d.id)];
      if (installedIds.includes('openclaw-launcher-cli')) {
        try {
          const toolConfigPath = path.join(os.homedir(), '.openclaw', 'tools', 'launcher-cli', 'config.json');
          if (fs.existsSync(path.dirname(toolConfigPath))) {
            const token = signToken({ type: 'cli-tool' }, '90d');
            if (token) {
              let cfg = {};
              try { cfg = JSON.parse(fs.readFileSync(toolConfigPath, 'utf-8')); } catch { /* fresh */ }
              cfg.url = cfg.url || 'http://localhost:3000';
              cfg.token = token;
              fs.writeFileSync(toolConfigPath, JSON.stringify(cfg, null, 2), { mode: 0o600 });
              console.log('[Control API] Auto-configured launcher-cli with fresh auth token');
            }
          }
        } catch (e) {
          console.warn('[Control API] Failed to auto-configure launcher-cli:', e.message);
        }
      }
    }

    res.json(instanceControl.successResponse({
      item,
      replaced: existingIdx >= 0,
      ...(didInstallAction ? { installResult } : {}),
    }));
  } catch (err) {
    console.error('[Control API] marketplace item add error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// POST /control/v1/marketplace/install — install or upgrade a marketplace item
router.post('/marketplace/install', (req, res) => {
  try {
    const { itemId } = req.body || {};
    if (!itemId || typeof itemId !== 'string') {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'itemId is required and must be a string', 400);
      return res.status(err.httpStatus).json(err.body);
    }

    const item = marketplace.findItem(itemId);
    if (!item) {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', `Item "${itemId}" not found in registry`, 404);
      return res.status(err.httpStatus).json(err.body);
    }

    const status = marketplace.getItemStatus(itemId);

    // Already installed and up to date (not broken)
    if (status && status.installed && !status.updateAvailable && status.status !== 'broken') {
      return res.json(instanceControl.successResponse({
        itemId,
        action: 'none',
        message: `Item "${item.name}" is already installed and up to date`,
        installState: status,
      }));
    }

    // For updates or broken installs, clean up existing files first
    if (status && (status.updateAvailable || status.status === 'broken')) {
      try { marketplace.uninstallItem(itemId); } catch {}
    }

    const result = marketplace.installItem(itemId);

    if (result.requiresAction) {
      return res.status(202).json(instanceControl.successResponse({
        itemId,
        action: 'prerequisites_required',
        ...result,
      }));
    }

    // Auto-configure launcher-cli with fresh auth token after install
    const installedIds = [itemId, ...(result.installedDeps || []).map(d => d.id)];
    if (installedIds.includes('openclaw-launcher-cli')) {
      try {
        const toolConfigPath = path.join(os.homedir(), '.openclaw', 'tools', 'launcher-cli', 'config.json');
        if (fs.existsSync(path.dirname(toolConfigPath))) {
          const token = signToken({ type: 'cli-tool' }, '90d');
          if (token) {
            let cfg = {};
            try { cfg = JSON.parse(fs.readFileSync(toolConfigPath, 'utf-8')); } catch { /* fresh */ }
            cfg.url = cfg.url || 'http://localhost:3000';
            cfg.token = token;
            fs.writeFileSync(toolConfigPath, JSON.stringify(cfg, null, 2), { mode: 0o600 });
            console.log('[Control API] Auto-configured launcher-cli with fresh auth token');
          }
        }
      } catch (e) {
        console.warn('[Control API] Failed to auto-configure launcher-cli:', e.message);
      }
    }

    const action = status && status.updateAvailable ? 'updated' : 'installed';
    res.json(instanceControl.successResponse({
      itemId,
      action,
      message: `${item.name} ${action}`,
      ...result,
    }));
  } catch (err) {
    console.error('[Control API] marketplace install error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// POST /control/v1/marketplace/uninstall — uninstall a marketplace item
router.post('/marketplace/uninstall', (req, res) => {
  try {
    const { itemId } = req.body || {};
    if (!itemId || typeof itemId !== 'string') {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'itemId is required and must be a string', 400);
      return res.status(err.httpStatus).json(err.body);
    }

    const item = marketplace.findItem(itemId);
    if (!item) {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', `Item "${itemId}" not found in registry`, 404);
      return res.status(err.httpStatus).json(err.body);
    }

    const status = marketplace.getItemStatus(itemId);
    if (!status || (!status.installed && status.status !== 'broken')) {
      return res.json(instanceControl.successResponse({
        itemId,
        action: 'none',
        message: `Item "${item.name}" is not installed`,
      }));
    }

    const result = marketplace.uninstallItem(itemId);
    res.json(instanceControl.successResponse({
      itemId,
      action: 'uninstalled',
      message: `${item.name} uninstalled`,
      ...result,
    }));
  } catch (err) {
    console.error('[Control API] marketplace uninstall error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// DELETE /control/v1/marketplace/items/:itemId — remove a single item from the external registry
router.delete('/marketplace/items/:itemId', (req, res) => {
  try {
    const { itemId } = req.params;

    // Prevent deletion of hardcoded built-in items
    if (marketplace.isBuiltinItem(itemId)) {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', `Item "${itemId}" is a built-in item and cannot be deleted`, 400);
      return res.status(err.httpStatus).json(err.body);
    }

    const registry = marketplace.readExternalRegistryOnly();

    const idx = registry.items.findIndex(i => i.id === itemId);
    if (idx === -1) {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', `Item "${itemId}" not found in external registry`, 404);
      return res.status(err.httpStatus).json(err.body);
    }

    registry.items.splice(idx, 1);
    marketplace.writeExternalRegistry(registry);
    res.json(instanceControl.successResponse({ removed: itemId }));
  } catch (err) {
    console.error('[Control API] marketplace item delete error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// POST /control/v1/marketplace/items/batch — add or replace multiple items in the external registry
// Like POST /marketplace/items but for multiple items at once.
// Unlike PUT /marketplace/catalog, this does NOT replace the entire registry — it merges.
router.post('/marketplace/items/batch', (req, res) => {
  try {
    const { items, autoInstall } = req.body || {};
    if (!Array.isArray(items) || items.length === 0) {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'items must be a non-empty array', 400);
      return res.status(err.httpStatus).json(err.body);
    }

    // Validate all items first
    for (let i = 0; i < items.length; i++) {
      if (marketplace.isBuiltinItem(items[i].id)) {
        const err = instanceControl.errorResponse('INVALID_PARAMETERS', `Item "${items[i].id}" is a built-in item and cannot be added externally`, 400);
        return res.status(err.httpStatus).json(err.body);
      }
      const errors = marketplace.validateRegistryItem(items[i]);
      if (errors.length > 0) {
        const err = instanceControl.errorResponse('INVALID_PARAMETERS', `Item ${i} ("${items[i].id || 'unknown'}") validation failed: ${errors.join('; ')}`, 400);
        return res.status(err.httpStatus).json(err.body);
      }
    }

    const registry = marketplace.readExternalRegistryOnly();
    const results = [];

    for (const item of items) {
      const existingIdx = registry.items.findIndex(i => i.id === item.id);
      if (existingIdx >= 0) {
        // Type change cleanup
        const oldItem = registry.items[existingIdx];
        if (oldItem.type !== item.type) {
          try {
            const oldStatus = marketplace.getItemStatus(item.id);
            if (oldStatus && (oldStatus.installed || oldStatus.status === 'broken')) {
              marketplace.uninstallItem(item.id);
            }
          } catch { /* best effort cleanup */ }
          marketplace.removeInstallRecord(item.id);
        }
        registry.items[existingIdx] = item;
        results.push({ id: item.id, action: 'replaced' });
      } else {
        registry.items.push(item);
        results.push({ id: item.id, action: 'added' });
      }
    }

    marketplace.writeExternalRegistry(registry);

    // Auto-enable marketplace feature
    const lc = openclawConfig.readLauncherConfig() || {};
    if (!lc.enableMarketplace) {
      lc.enableMarketplace = true;
      openclawConfig.writeLauncherConfig(lc);
      console.log('[Control API] Marketplace auto-enabled via batch item add');
    }

    // Auto-install logic
    const globalAutoInstall = autoInstall === true;
    const installResults = [];
    let anyAutoInstall = false;

    for (const item of items) {
      const itemAutoInstall = globalAutoInstall || item.autoInstall === true;
      const isFileCopyType = marketplace.FILE_COPY_TYPES.includes(item.type);

      try {
        const status = marketplace.getItemStatus(item.id);

        if (isFileCopyType && status && status.installed) {
          anyAutoInstall = true;
          try { marketplace.uninstallItem(item.id); } catch {}
          const result = marketplace.installItem(item.id);
          if (result.requiresAction) {
            installResults.push({ id: item.id, action: 'prerequisites_required', prerequisites: result.prerequisites });
          } else {
            installResults.push({ id: item.id, action: 'reinstalled', ...result });
          }
          continue;
        }

        if (!itemAutoInstall) continue;
        anyAutoInstall = true;

        if (status && status.installed && !status.updateAvailable && status.status !== 'broken') {
          installResults.push({ id: item.id, action: 'none', message: 'already up to date' });
          continue;
        }

        if (status && (status.updateAvailable || status.status === 'broken')) {
          try { marketplace.uninstallItem(item.id); } catch {}
        }

        const result = marketplace.installItem(item.id);
        if (result.requiresAction) {
          installResults.push({ id: item.id, action: 'prerequisites_required', prerequisites: result.prerequisites });
        } else {
          const action = status && status.updateAvailable ? 'updated' : 'installed';
          installResults.push({ id: item.id, action, ...result });
        }
      } catch (installErr) {
        installResults.push({ id: item.id, action: 'error', message: installErr.message });
      }
    }

    res.json(instanceControl.successResponse({
      items: results,
      count: items.length,
      ...(anyAutoInstall ? { installResults } : {}),
    }));
  } catch (err) {
    console.error('[Control API] marketplace batch item add error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// DELETE /control/v1/marketplace/items — batch delete multiple items from the external registry
// Accepts { itemIds: ["id1", "id2", ...], uninstall?: boolean }
// When uninstall is true, installed items are uninstalled before removal.
router.delete('/marketplace/items', (req, res) => {
  try {
    const { itemIds, uninstall } = req.body || {};
    if (!Array.isArray(itemIds) || itemIds.length === 0) {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'itemIds must be a non-empty array of strings', 400);
      return res.status(err.httpStatus).json(err.body);
    }

    const registry = marketplace.readExternalRegistryOnly();
    const results = [];

    for (const itemId of itemIds) {
      if (typeof itemId !== 'string') continue;

      if (marketplace.isBuiltinItem(itemId)) {
        results.push({ id: itemId, action: 'skipped', reason: 'built-in item' });
        continue;
      }

      const idx = registry.items.findIndex(i => i.id === itemId);
      if (idx === -1) {
        results.push({ id: itemId, action: 'skipped', reason: 'not found' });
        continue;
      }

      // Optionally uninstall before removing from catalog
      if (uninstall) {
        try {
          const status = marketplace.getItemStatus(itemId);
          if (status && (status.installed || status.status === 'broken')) {
            marketplace.uninstallItem(itemId);
          }
        } catch { /* best effort */ }
        marketplace.removeInstallRecord(itemId);
      }

      registry.items.splice(idx, 1);
      results.push({ id: itemId, action: 'removed' });
    }

    marketplace.writeExternalRegistry(registry);
    res.json(instanceControl.successResponse({ results, removedCount: results.filter(r => r.action === 'removed').length }));
  } catch (err) {
    console.error('[Control API] marketplace batch item delete error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// ==========================================
// GET /control/v1/instances/:id/ai-config
// ==========================================
router.get('/instances/:id/ai-config', validateInstanceId, (req, res) => {
  try {
    const config = openclawConfig.readConfig();
    if (!config) {
      const err = instanceControl.errorResponse('INSTANCE_UNAVAILABLE', 'Config not found', 503);
      return res.status(err.httpStatus).json(err.body);
    }

    const aiModel = config.agents?.defaults?.model?.primary || null;

    // Resolve provider from the model
    let providerName = null;
    let endpoint = null;
    let apiKey = null;

    if (aiModel) {
      const hasPrefix = aiModel.includes('/');
      providerName = hasPrefix ? aiModel.split('/')[0] : inferProviderFromModel(aiModel, config);
    }

    if (providerName) {
      const provider = config.models?.providers?.[providerName];
      if (provider) {
        endpoint = provider.baseUrl || null;
        const rawKey = resolveProviderApiKey(providerName, provider);
        apiKey = rawKey || null;
      }
    }

    res.json(instanceControl.successResponse({ aiModel, provider: providerName, endpoint, apiKey }));
  } catch (err) {
    console.error('[Control API] ai-config error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// ==========================================
// GET /control/v1/instances/:id/config
// Full openclaw.json read (sanitized — secrets masked)
// ==========================================
router.get('/instances/:id/config', validateInstanceId, (req, res) => {
  try {
    const config = openclawConfig.readConfig();
    if (!config) {
      const err = instanceControl.errorResponse('INSTANCE_UNAVAILABLE', 'Config not found', 503);
      return res.status(err.httpStatus).json(err.body);
    }

    const sanitized = openclawConfig.sanitizeConfig(config);
    res.json(instanceControl.successResponse({ config: sanitized }));
  } catch (err) {
    console.error('[Control API] config read error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// ==========================================
// PUT /control/v1/instances/:id/config
// Full openclaw.json replacement with validation.
// Accepts a complete config object (or a partial patch merged onto current).
// ==========================================
router.put('/instances/:id/config', validateInstanceId, (req, res) => {
  try {
    const { config: newConfig, patch, restart } = req.body || {};

    if (!newConfig && !patch) {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'Either "config" (full replacement) or "patch" (merge onto current) is required', 400);
      return res.status(err.httpStatus).json(err.body);
    }

    if (newConfig && patch) {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'Provide either "config" or "patch", not both', 400);
      return res.status(err.httpStatus).json(err.body);
    }

    // Must be ACTIVE, PROVISIONING, or AVAILABLE to update config
    const currentStatus = instanceControl.getStatus();
    if (currentStatus !== instanceControl.STATES.ACTIVE && currentStatus !== instanceControl.STATES.PROVISIONING && currentStatus !== instanceControl.STATES.AVAILABLE) {
      instanceControl.recordFailure('config-update', 'INVALID_STATE', `Cannot update config in state ${currentStatus}`);
      const err = instanceControl.errorResponse('INVALID_STATE', `Cannot update config in state ${currentStatus}`, 409);
      return res.status(err.httpStatus).json(err.body);
    }

    let finalConfig;

    if (newConfig) {
      // Full replacement — validate the provided object
      if (typeof newConfig !== 'object' || Array.isArray(newConfig)) {
        const err = instanceControl.errorResponse('INVALID_PARAMETERS', '"config" must be a JSON object', 400);
        return res.status(err.httpStatus).json(err.body);
      }
      finalConfig = JSON.parse(JSON.stringify(newConfig));
    } else {
      // Patch mode — merge onto current config
      if (typeof patch !== 'object' || Array.isArray(patch)) {
        const err = instanceControl.errorResponse('INVALID_PARAMETERS', '"patch" must be a JSON object', 400);
        return res.status(err.httpStatus).json(err.body);
      }
      const existing = openclawConfig.readConfig();
      if (!existing) {
        const err = instanceControl.errorResponse('INSTANCE_UNAVAILABLE', 'Config not found — cannot patch', 503);
        return res.status(err.httpStatus).json(err.body);
      }
      finalConfig = openclawConfig.mergeConfig(existing, patch);
    }

    // Ensure hot reload mode
    finalConfig.meta = finalConfig.meta || {};
    finalConfig.meta.lastTouchedAt = new Date().toISOString();

    // Auto-generate gateway auth token if none exists
    if (!finalConfig.gateway?.auth?.token) {
      finalConfig.gateway = finalConfig.gateway || {};
      finalConfig.gateway.auth = finalConfig.gateway.auth || { mode: 'token' };
      finalConfig.gateway.auth.token = openclawConfig.generateSecureToken();
    }

    const validation = openclawConfig.validateConfig(finalConfig);
    if (!validation.valid) {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', `Validation failed: ${validation.errors.join('; ')}`, 400);
      return res.status(err.httpStatus).json(err.body);
    }

    openclawConfig.writeConfig(finalConfig);

    // Restart gateway unless explicitly suppressed
    let gatewayRestarted = false;
    if (restart !== false) {
      const restartResult = pm2Health.restartGateway();
      gatewayRestarted = restartResult.success;
    }

    res.json(instanceControl.successResponse({
      config: openclawConfig.sanitizeConfig(finalConfig),
      gatewayRestarted,
      warnings: validation.warnings.length > 0 ? validation.warnings : undefined,
    }));
  } catch (err) {
    console.error('[Control API] config update error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// ==========================================
// Notice Management (Goal 020)
// ==========================================

// GET /control/v1/notices — return all notices (platform sees everything)
router.get('/notices', (req, res) => {
  try {
    const data = notices.readNotices();
    res.json(instanceControl.successResponse({ notices: data.notices }));
  } catch (err) {
    console.error('[Control API] notices read error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// POST /control/v1/notices — create a single notice
router.post('/notices', (req, res) => {
  try {
    const { notice } = req.body || {};
    if (!notice || typeof notice !== 'object') {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'notice is required and must be an object', 400);
      return res.status(err.httpStatus).json(err.body);
    }

    const errors = notices.validateNotice(notice);
    if (errors.length > 0) {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', `Validation failed: ${errors.join('; ')}`, 400);
      return res.status(err.httpStatus).json(err.body);
    }

    const result = notices.addNotice(notice);
    if (result.error) {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', result.error, 400);
      return res.status(err.httpStatus).json(err.body);
    }

    res.json(instanceControl.successResponse({ notice: result.notice, replaced: result.replaced }));
  } catch (err) {
    console.error('[Control API] notice create error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// PUT /control/v1/notices — replace all notices (bulk sync)
router.put('/notices', (req, res) => {
  try {
    const { notices: noticeList } = req.body || {};
    if (!Array.isArray(noticeList)) {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', 'notices must be an array', 400);
      return res.status(err.httpStatus).json(err.body);
    }

    if (noticeList.length > notices.MAX_NOTICES) {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', `Maximum ${notices.MAX_NOTICES} notices allowed`, 400);
      return res.status(err.httpStatus).json(err.body);
    }

    // Validate each notice
    for (let i = 0; i < noticeList.length; i++) {
      const errors = notices.validateNotice(noticeList[i]);
      if (errors.length > 0) {
        const err = instanceControl.errorResponse('INVALID_PARAMETERS', `Notice ${i} validation failed: ${errors.join('; ')}`, 400);
        return res.status(err.httpStatus).json(err.body);
      }
    }

    // Enrich with createdAt and defaults
    const now = new Date().toISOString();
    const enriched = noticeList.map(n => ({
      ...n,
      createdAt: n.createdAt || now,
      dismissible: n.dismissible !== undefined ? n.dismissible : true,
    }));

    notices.writeNotices({ notices: enriched });
    res.json(instanceControl.successResponse({ notices: enriched, count: enriched.length }));
  } catch (err) {
    console.error('[Control API] notices bulk write error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// DELETE /control/v1/notices/:noticeId — remove a specific notice
router.delete('/notices/:noticeId', (req, res) => {
  try {
    const { noticeId } = req.params;
    const result = notices.removeNotice(noticeId);

    if (!result.found) {
      const err = instanceControl.errorResponse('INVALID_PARAMETERS', `Notice "${noticeId}" not found`, 404);
      return res.status(err.httpStatus).json(err.body);
    }

    res.json(instanceControl.successResponse({ removed: noticeId }));
  } catch (err) {
    console.error('[Control API] notice delete error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// ==========================================
// POST /control/v1/instances/:id/launcher-restart
// ================================================
router.post('/instances/:id/launcher-restart', validateInstanceId, (req, res) => {
  try {
    res.json(instanceControl.successResponse({
      restartedAt: new Date().toISOString(),
      message: 'Launcher restart initiated',
    }));

    // Restart after response is sent so the caller gets the 200
    setTimeout(() => {
      try {
        execFileSync('pm2', ['restart', 'web'], { timeout: 10000 });
      } catch (err) {
        console.error('[Control API] launcher-restart error:', err.message);
      }
    }, 500);
  } catch (err) {
    console.error('[Control API] launcher-restart error:', err.message);
    res.status(500).json({ success: false, data: null, error: { code: 'INTERNAL_ERROR', message: err.message } });
  }
});

// POST /control/v1/instances/:id/doctor-fix
// ==========================================
router.post('/instances/:id/doctor-fix', validateInstanceId, (req, res) => {
  const stripAnsi = (str) => str.replace(/\x1B\[[0-9;]*[A-Za-z]/g, '');

  // If the gateway port is occupied by an unmanaged process, kill it first
  // so that doctor-fix + pm2 restart can reclaim the port.
  let killedUnmanagedPid = null;
  try {
    const config = openclawConfig.readConfig();
    const gwPort = config?.gateway?.port || 18789;
    const mgmt = pm2Health.checkGatewayManagement(gwPort);
    if (mgmt.unmanagedDaemon && mgmt.portPid && mgmt.isOpenclawProcess) {
      console.warn(`[Control API] doctor-fix: killing unmanaged openclaw-gateway process PID ${mgmt.portPid} on port ${gwPort} (cmd: ${mgmt.portProcessCmd})`);
      try {
        process.kill(mgmt.portPid, 'SIGTERM');
        // Give it a moment to release the port
        require('child_process').execSync('sleep 1', { timeout: 3000 });
      } catch (killErr) {
        // ESRCH = process already gone, which is fine
        if (killErr.code !== 'ESRCH') {
          console.error(`[Control API] doctor-fix: failed to kill PID ${mgmt.portPid}:`, killErr.message);
        }
      }
      killedUnmanagedPid = mgmt.portPid;
    } else if (mgmt.unmanagedDaemon && mgmt.portPid && !mgmt.isOpenclawProcess) {
      console.warn(`[Control API] doctor-fix: port ${gwPort} occupied by non-openclaw process PID ${mgmt.portPid} (cmd: ${mgmt.portProcessCmd}) — skipping kill`);
    }
  } catch (mgmtErr) {
    console.error('[Control API] doctor-fix: management check error:', mgmtErr.message);
  }

  execFile('openclaw', ['doctor', '--fix', '--non-interactive'], { timeout: 30000 }, (err, stdout, stderr) => {
    const doctorOutput = stripAnsi((stdout || '') + (stderr || '')).trim();

    try {
      const restartResult = pm2Health.restartGateway();
      const responseData = {
        doctorOutput,
        doctorOk: !err,
        gateway: restartResult,
      };
      if (killedUnmanagedPid) responseData.killedUnmanagedPid = killedUnmanagedPid;
      res.json(instanceControl.successResponse(responseData));
    } catch (restartErr) {
      console.error('[Control API] doctor-fix restart error:', restartErr.message);
      const responseData = {
        doctorOutput,
        doctorOk: !err,
        gateway: { success: false, error: restartErr.message },
      };
      if (killedUnmanagedPid) responseData.killedUnmanagedPid = killedUnmanagedPid;
      res.json(instanceControl.successResponse(responseData));
    }
  });
});

module.exports = router;

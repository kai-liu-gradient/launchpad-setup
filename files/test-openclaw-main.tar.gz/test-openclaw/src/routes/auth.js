const express = require('express');
const crypto = require('crypto');
const router = express.Router();
const openclawConfig = require('../services/openclaw-config');
const { signToken, verifyToken, checkLoginRateLimit, recordLoginAttempt } = require('../middleware/launcher-auth');
const { hasInitFlag, removeInitFlag, createInitFlag } = require('../services/openclaw-config');
const gatewaySession = require('../services/gateway-session');

// POST /api/openclaw/auth/login
router.post('/login', (req, res) => {
  const ip = req.ip || req.socket.remoteAddress;

  if (!checkLoginRateLimit(ip)) {
    return res.status(429).json({ error: 'Too Many Requests', message: 'Too many login attempts. Try again in a minute.' });
  }

  recordLoginAttempt(ip);

  const { password } = req.body || {};
  if (!password || typeof password !== 'string') {
    return res.status(400).json({ error: 'Bad Request', message: 'password is required' });
  }

  const storedPassword = openclawConfig.getLauncherPassword();
  if (!storedPassword) {
    return res.status(500).json({ error: 'Internal Server Error', message: 'Launcher auth not configured' });
  }

  // Timing-safe comparison
  const inputBuf = Buffer.from(password);
  const storedBuf = Buffer.from(storedPassword);
  if (inputBuf.length !== storedBuf.length || !crypto.timingSafeEqual(inputBuf, storedBuf)) {
    return res.status(401).json({ error: 'unauthorized', message: 'Invalid password' });
  }

  const token = signToken({ type: 'session' });
  if (!token) {
    return res.status(500).json({ error: 'Internal Server Error', message: 'Failed to create session token' });
  }

  // Clear init flag after first successful login
  if (hasInitFlag()) {
    removeInitFlag();
  }

  // Set httpOnly cookie
  res.cookie('launcher_token', token, {
    httpOnly: true,
    sameSite: 'lax',
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    path: '/',
  });

  // Issue gateway WS session cookie for WebSocket upgrade authorization
  gatewaySession.setSessionCookie(res);

  res.json({ token });
});

// POST /api/openclaw/auth/generate-link (requires auth — protected by middleware)
router.post('/generate-link', (req, res) => {
  const token = signToken({ type: 'access-link' }, '1h');
  if (!token) {
    return res.status(500).json({ error: 'Internal Server Error', message: 'Failed to generate access link' });
  }

  const protocol = req.protocol;
  const host = req.get('host');
  const { redirect } = req.body || {};
  let link = `${protocol}://${host}/auth/access?token=${token}`;
  if (redirect && typeof redirect === 'string' && redirect.startsWith('/') && !redirect.startsWith('//')) {
    link += `&redirect=${encodeURIComponent(redirect)}`;
  }

  res.json({ link, expiresIn: '1 hour' });
});

// GET /api/openclaw/auth/verify — validates access link token, returns session JWT
router.get('/verify', (req, res) => {
  const { token } = req.query;
  if (!token) {
    return res.status(400).json({ error: 'Bad Request', message: 'token query parameter is required' });
  }

  const decoded = verifyToken(token);
  if (!decoded) {
    return res.status(401).json({ error: 'unauthorized', message: 'Invalid or expired access link' });
  }

  // Issue a temporary session token (1h, matching the access-link lifetime)
  const sessionToken = signToken({ type: 'temporary-session' }, '1h');
  if (!sessionToken) {
    return res.status(500).json({ error: 'Internal Server Error', message: 'Failed to create session token' });
  }

  // Set httpOnly cookie with 1h maxAge
  res.cookie('launcher_token', sessionToken, {
    httpOnly: true,
    sameSite: 'lax',
    maxAge: 60 * 60 * 1000,
    path: '/',
  });

  // Issue gateway WS session cookie for WebSocket upgrade authorization
  gatewaySession.setSessionCookie(res);

  res.json({ token: sessionToken });
});

// POST /api/openclaw/auth/reset-password (requires auth — protected by middleware)
router.post('/reset-password', (req, res) => {
  const newPassword = openclawConfig.generateLauncherPassword();
  openclawConfig.setLauncherPassword(newPassword);

  console.log(`[Auth] Launcher password reset. New password: ${newPassword}`);

  res.json({
    success: true,
    message: 'Password reset successfully. All existing sessions are now invalidated.',
    password: newPassword,
  });
});

// POST /api/openclaw/auth/reset-launcher-token (requires auth — protected by middleware)
router.post('/reset-launcher-token', (req, res) => {
  const newPassword = openclawConfig.generateLauncherPassword();
  openclawConfig.setLauncherPassword(newPassword);
  createInitFlag();

  console.log(`[Auth] Launcher token reset. New password generated, init flag created.`);

  // Clear the httpOnly cookies to invalidate the current session
  res.clearCookie('launcher_token', { path: '/' });
  res.clearCookie(gatewaySession.COOKIE_NAME, { path: '/' });

  res.json({
    success: true,
    message: 'Launcher token reset. All sessions invalidated. Redirecting to login.',
  });
});

// GET /api/openclaw/auth/status (public — no auth required)
router.get('/status', (req, res) => {
  const password = openclawConfig.getLauncherPassword();
  const hasPassword = !!password;
  const firstRun = hasInitFlag();

  const response = { authEnabled: hasPassword, firstRun };

  // Expose the raw password only during first run so the login page can display it
  if (firstRun && hasPassword) {
    response.initialPassword = password;
  }

  res.json(response);
});

module.exports = router;

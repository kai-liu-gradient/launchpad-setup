const express = require('express');
const { execFile, execFileSync, spawn } = require('child_process');
const crypto = require('crypto');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const os = require('os');
const router = express.Router();

const credentialDiscovery = require('../services/credential-discovery');
const telegramSetup = require('../services/telegram-setup');
const feishuSetup = require('../services/feishu-setup');
const openclawConfig = require('../services/openclaw-config');
const pm2Health = require('../services/pm2-health');
const workspaceBrowser = require('../services/workspace-browser');
const gatewayProxy = require('../services/gateway-proxy');
const versionTracker = require('../services/version-tracker');
const systemStats = require('../services/system-stats');
const apiCallHistory = require('../services/api-call-history');
const { validateJsonBody } = require('../middleware/validation');
const { signToken } = require('../middleware/launcher-auth');

const http = require('http');
const https = require('https');

// Multer config: memory storage, 10MB per file, 50MB total
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024, files: 20 },
});

router.use(validateJsonBody);

// Lightweight connectivity check — HEAD request to a provider's baseUrl with short timeout
function probeProviderUrl(baseUrl, timeout = 5000) {
  return new Promise((resolve) => {
    try {
      const url = new URL(baseUrl);
      const mod = url.protocol === 'https:' ? https : http;
      const req = mod.request(url, { method: 'HEAD', timeout }, (res) => {
        res.resume();
        resolve(true);
      });
      req.on('error', () => resolve(false));
      req.on('timeout', () => { req.destroy(); resolve(false); });
      req.end();
    } catch {
      resolve(false);
    }
  });
}

// Resolve the API key for a provider: auth-profiles.json > provider.apiKey > env var
function resolveProviderApiKey(providerName, provider) {
  const authProfiles = credentialDiscovery.readAuthProfiles();
  const profile = authProfiles.profiles?.[`${providerName}:default`];
  const profileKey = profile?.key || profile?.token || null;
  if (profileKey) return profileKey;
  if (provider?.apiKey) return provider.apiKey;
  const envProviders = credentialDiscovery.ENV_VAR_PROVIDERS;
  const envEntry = Object.entries(envProviders).find(([, meta]) => meta.provider === providerName);
  return envEntry ? process.env[envEntry[0]] || null : null;
}

// Build model definition objects from a list of model IDs
function buildModelDefinitions(modelIds) {
  return modelIds.map(modelId => ({
    id: modelId,
    name: modelId,
    reasoning: true,
    input: ['text'],
    cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
    contextWindow: 128000,
    maxTokens: 8192,
  }));
}

// syncTokenToGateway is no longer needed — writeConfig() already persists the
// token to ~/.openclaw/openclaw.json which is the same file the gateway reads
// on startup. The old implementation spawned `openclaw config set …` which
// could leave zombie/orphan Node processes inside the container, blocking
// future gateway commands.

// ==========================================
// Credential Discovery & Reuse (Tasks 1-3)
// ==========================================

// GET /api/openclaw/credentials/detect
router.get('/credentials/detect', (req, res) => {
  try {
    const result = credentialDiscovery.detectAllCredentials();
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// POST /api/openclaw/credentials/apply
router.post('/credentials/apply', (req, res) => {
  try {
    const { provider, model } = req.body;
    if (!provider) {
      return res.status(400).json({ error: 'Bad Request', message: 'provider is required' });
    }

    let config = openclawConfig.readConfig();
    if (!config) {
      config = openclawConfig.createDefaultConfig();
      openclawConfig.writeConfig(config);
    }

    if (provider === 'zai') {
      const zaiConfig = credentialDiscovery.getZaiConfigRaw();
      if (!zaiConfig || !zaiConfig.Providers) {
        return res.status(404).json({ error: 'Not Found', message: 'ZAI config not found' });
      }

      const zaiProvider = zaiConfig.Providers.find(p => p.name === 'zai');
      if (!zaiProvider) {
        return res.status(404).json({ error: 'Not Found', message: 'ZAI provider not found in config' });
      }

      const modelDefinitions = (zaiProvider.models || []).map(modelId => ({
        id: modelId,
        name: modelId,
        reasoning: true,
        input: ['text'],
        cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
        contextWindow: 128000,
        maxTokens: 8192,
      }));

      // Ensure glm-5 is always available as an option
      if (!modelDefinitions.some(m => m.id === 'glm-5')) {
        modelDefinitions.push({
          id: 'glm-5',
          name: 'glm-5',
          reasoning: true,
          input: ['text'],
          cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
          contextWindow: 128000,
          maxTokens: 8192,
        });
      }

      // Strip trailing path suffixes from api_base_url — baseUrl should be the root endpoint.
      // The Anthropic SDK appends /v1/messages itself, so we must also strip /v1 for anthropic-messages API.
      let baseUrl = zaiProvider.api_base_url || '';
      baseUrl = baseUrl.replace(/\/(v1\/)?(messages|chat\/completions)\/?$/, '');

      const patch = {
        models: {
          providers: {
            zai: {
              baseUrl,
              auth: 'api-key',
              api: 'anthropic-messages',
              models: modelDefinitions,
            },
          },
        },
        auth: {
          profiles: {
            ...(config.auth && config.auth.profiles || {}),
            'zai:default': {
              provider: 'zai',
              mode: 'api_key',
            },
          },
        },
      };

      // If a model was explicitly provided, ensure it's in the models list
      if (model) {
        const modelObj = {
          id: model,
          name: model,
          reasoning: true,
          input: ['text'],
          cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
          contextWindow: 128000,
          maxTokens: 8192,
        };
        if (!modelDefinitions.some(m => m.id === model)) {
          modelDefinitions.unshift(modelObj);
          patch.models.providers.zai.models = modelDefinitions;
        }
        patch.agents = {
          defaults: {
            model: { primary: `zai/${model}` },
            thinkingDefault: 'off',
          },
        };
      } else {
        // Default to glm-5
        const defaultZaiModel = 'glm-5';
        patch.agents = {
          defaults: {
            model: { primary: `zai/${defaultZaiModel}` },
            thinkingDefault: 'off',
          },
        };
      }

      config = openclawConfig.mergeConfig(config, patch);
      config.meta = config.meta || {};
      config.meta.lastTouchedAt = new Date().toISOString();
      openclawConfig.writeConfig(config);

      // Write ZAI API key to auth-profiles.json (separate secrets file)
      if (zaiProvider.api_key) {
        const authProfiles = credentialDiscovery.readAuthProfiles();
        authProfiles.profiles['zai:default'] = { type: 'api_key', provider: 'zai', key: zaiProvider.api_key };
        credentialDiscovery.writeAuthProfiles(authProfiles);
      }

      res.json({ success: true, message: 'ZAI provider applied', provider: 'zai' });

    } else if (provider === 'anthropic') {
      // Reject if Claude CLI is in OAuth mode (user should generate a headless API key)
      const detected = credentialDiscovery.detectClaudeSettings();
      if (detected && detected.authMode === 'oauth') {
        return res.status(400).json({
          error: 'Bad Request',
          message: 'Claude CLI is using OAuth authentication. Please generate a headless API key from your Claude subscription at console.anthropic.com and use manual configuration instead.',
        });
      }

      // Read credentials from ~/.claude/settings.json at apply time
      const claudeSettings = credentialDiscovery.getClaudeSettingsRaw();
      if (!claudeSettings) {
        return res.status(404).json({ error: 'Not Found', message: 'Claude settings not found' });
      }

      const envSection = claudeSettings.env || {};
      const { ANTHROPIC_AUTH_TOKEN, ANTHROPIC_BASE_URL, ANTHROPIC_MODEL } = envSection;
      const topLevelModel = claudeSettings.model || null;

      // Resolve model alias: request body > env ANTHROPIC_MODEL > top-level model
      const rawModelHint = model || ANTHROPIC_MODEL || topLevelModel;
      const resolvedModel = rawModelHint
        ? credentialDiscovery.resolveClaudeModelAlias(rawModelHint)
        : null;

      // Strip trailing path suffixes from base URL.
      // Store the root endpoint only — callers (health test, SDK) append /v1/messages themselves.
      let baseUrl = ANTHROPIC_BASE_URL || 'https://api.anthropic.com';
      baseUrl = baseUrl.replace(/\/(v1\/)?(messages|chat\/completions)\/?$/, '');
      baseUrl = baseUrl.replace(/\/v1\/?$/, '');
      baseUrl = baseUrl.replace(/\/+$/, '');

      // Always set default primary model — use resolved or fallback
      const defaultClaudeModel = resolvedModel || 'claude-sonnet-4-6';

      // Build provider models — always include the effective default model so the
      // Config page dropdown can match it (fixes "Custom" display bug).
      const providerModels = [buildModelDefinitions([defaultClaudeModel])[0]];

      const patch = {
        models: {
          providers: {
            anthropic: {
              baseUrl,
              auth: 'api-key',
              api: 'anthropic-messages',
              models: providerModels,
            },
          },
        },
        auth: {
          profiles: {
            ...(config.auth && config.auth.profiles || {}),
            'anthropic:default': {
              provider: 'anthropic',
              mode: 'api_key',
            },
          },
        },
      };

      patch.agents = {
        defaults: {
          model: { primary: `anthropic/${defaultClaudeModel}` },
          thinkingDefault: 'off',
        },
      };

      config = openclawConfig.mergeConfig(config, patch);
      config.meta = config.meta || {};
      config.meta.lastTouchedAt = new Date().toISOString();
      openclawConfig.writeConfig(config);

      // Write auth token to auth-profiles.json if available
      if (ANTHROPIC_AUTH_TOKEN) {
        const authProfiles = credentialDiscovery.readAuthProfiles();
        authProfiles.profiles['anthropic:default'] = {
          type: 'api_key',
          provider: 'anthropic',
          key: ANTHROPIC_AUTH_TOKEN,
        };
        credentialDiscovery.writeAuthProfiles(authProfiles);
      }

      res.json({ success: true, message: 'Anthropic provider applied', provider: 'anthropic' });

    } else {
      // Check if this is an env-var-detected provider
      const envMeta = credentialDiscovery.ENV_VAR_PROVIDERS;
      const envEntry = Object.entries(envMeta).find(([, meta]) => meta.provider === provider);

      if (envEntry) {
        const [envVar, meta] = envEntry;
        if (!process.env[envVar]) {
          return res.status(404).json({ error: 'Not Found', message: `Environment variable ${envVar} is not set` });
        }

        // Write provider config to openclaw.json — do NOT copy the env var value
        // OpenClaw resolves env vars at runtime (credential resolution step #4)
        // Only include the user-specified model (if any)
        const providerModels = model ? buildModelDefinitions([model]) : [];

        const patch = {
          models: {
            providers: {
              [provider]: {
                baseUrl: meta.baseUrl,
                auth: 'api-key',
                api: meta.api,
                models: providerModels,
              },
            },
          },
          auth: {
            profiles: {
              ...(config.auth && config.auth.profiles || {}),
              [`${provider}:default`]: {
                provider,
                mode: 'api_key',
              },
            },
          },
        };

        // Always set default primary model — use explicit choice or first known model
        const defaultEnvModel = model || (providerModels.length > 0 ? providerModels[0].id : null);
        if (defaultEnvModel) {
          patch.agents = {
            defaults: {
              model: { primary: `${provider}/${defaultEnvModel}` },
              thinkingDefault: 'off',
            },
          };
        }

        config = openclawConfig.mergeConfig(config, patch);
        config.meta = config.meta || {};
        config.meta.lastTouchedAt = new Date().toISOString();
        openclawConfig.writeConfig(config);
        res.json({ success: true, message: `Provider ${provider} configured (credentials from ${envVar})`, provider });

      } else {
        return res.status(400).json({ error: 'Bad Request', message: `Unknown provider: ${provider}. Supported: zai, anthropic, or any env-var-detected provider` });
      }
    }
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// Well-known provider defaults for apiFormat and baseUrl inference
const PROVIDER_DEFAULTS = {
  openai: { apiFormat: 'openai-completions', baseUrl: 'https://api.openai.com/v1' },
  anthropic: { apiFormat: 'anthropic-messages', baseUrl: 'https://api.anthropic.com' },
  google: { apiFormat: 'google-generative-ai', baseUrl: 'https://generativelanguage.googleapis.com/v1beta' },
  openrouter: { apiFormat: 'openai-completions', baseUrl: 'https://openrouter.ai/api/v1' },
};

const VALID_API_FORMATS = ['openai-completions', 'openai-responses', 'anthropic-messages', 'google-generative-ai'];

// POST /api/openclaw/credentials/manual
router.post('/credentials/manual', (req, res) => {
  try {
    const { provider, apiKey, baseUrl, models, apiFormat, credentialType } = req.body;
    if (!provider) {
      return res.status(400).json({ error: 'Bad Request', message: 'provider is required' });
    }
    if (!apiKey) {
      return res.status(400).json({ error: 'Bad Request', message: 'apiKey is required' });
    }

    // Validate apiFormat if explicitly provided
    if (apiFormat && !VALID_API_FORMATS.includes(apiFormat)) {
      return res.status(400).json({
        error: 'Bad Request',
        message: `Invalid apiFormat: ${apiFormat}. Supported: ${VALID_API_FORMATS.join(', ')}`,
      });
    }

    let config = openclawConfig.readConfig();
    if (!config) {
      config = openclawConfig.createDefaultConfig();
      openclawConfig.writeConfig(config);
    }

    const providerName = provider.toLowerCase().replace(/[^a-z0-9-]/g, '');
    const defaults = PROVIDER_DEFAULTS[providerName] || {};

    // Infer apiFormat: explicit > provider default > openai-completions fallback
    const resolvedApiFormat = apiFormat || defaults.apiFormat || 'openai-completions';

    // Infer baseUrl: explicit > provider default > empty
    const resolvedBaseUrl = baseUrl || defaults.baseUrl || '';

    // Determine auth mode: setup-token maps to 'token', default is 'api-key'
    const isSetupToken = credentialType === 'setup-token';
    const authMode = isSetupToken ? 'token' : 'api-key';

    // Build model list from user-supplied models only
    const modelIds = (models || []).map(m => typeof m === 'string' ? m : m.id).filter(Boolean);
    const providerModels = buildModelDefinitions(modelIds);

    // Strip API path suffixes from baseUrl — store the root endpoint only.
    // Callers (health test, SDK) append /v1/messages themselves.
    let cleanBaseUrl = resolvedBaseUrl.replace(/\/(v1\/)?(messages|chat\/completions)\/?$/, '');
    if (resolvedApiFormat === 'anthropic-messages') {
      cleanBaseUrl = cleanBaseUrl.replace(/\/v1\/?$/, '');
      cleanBaseUrl = cleanBaseUrl.replace(/\/+$/, '');
    }

    // Write provider config and profile declaration to openclaw.json (no secrets)
    const patch = {
      models: {
        providers: {
          [providerName]: {
            baseUrl: cleanBaseUrl,
            auth: authMode,
            api: resolvedApiFormat,
            models: providerModels,
          },
        },
      },
      auth: {
        profiles: {
          ...(config.auth && config.auth.profiles || {}),
          [`${providerName}:default`]: {
            provider: providerName,
            mode: isSetupToken ? 'token' : 'api_key',
          },
        },
      },
    };

    // Always set default primary model — user is actively choosing this provider
    if (providerModels.length > 0) {
      patch.agents = {
        defaults: {
          model: { primary: `${providerName}/${providerModels[0].id}` },
          thinkingDefault: 'off',
        },
      };
    }

    config = openclawConfig.mergeConfig(config, patch);
    config.meta = config.meta || {};
    config.meta.lastTouchedAt = new Date().toISOString();
    openclawConfig.writeConfig(config);

    // Write actual credential to auth-profiles.json (separate secrets file)
    const authProfiles = credentialDiscovery.readAuthProfiles();
    const profileId = `${providerName}:default`;
    authProfiles.profiles[profileId] = isSetupToken
      ? { type: 'token', provider: providerName, token: apiKey }
      : { type: 'api_key', provider: providerName, key: apiKey };
    credentialDiscovery.writeAuthProfiles(authProfiles);

    res.json({ success: true, message: `Provider ${providerName} configured with ${isSetupToken ? 'setup-token' : 'API key'}`, provider: providerName });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// ==========================================
// Telegram Bot Configuration (Tasks 4-7)
// ==========================================

// POST /api/openclaw/telegram/validate
router.post('/telegram/validate', async (req, res) => {
  try {
    const { token } = req.body;
    if (!token) {
      return res.status(400).json({ error: 'Bad Request', message: 'token is required' });
    }

    const result = await telegramSetup.validateBotToken(token);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: 'Validation Failed', message: err.message });
  }
});

// POST /api/openclaw/telegram/configure
router.post('/telegram/configure', async (req, res) => {
  try {
    const { token } = req.body;
    if (!token) {
      return res.status(400).json({ error: 'Bad Request', message: 'token is required' });
    }

    // Validate the token first
    const validation = await telegramSetup.validateBotToken(token);
    if (!validation.valid) {
      return res.status(400).json({ error: 'Validation Failed', message: 'Bot token is invalid' });
    }

    let config = openclawConfig.readConfig();
    if (!config) {
      config = openclawConfig.createDefaultConfig();
      openclawConfig.writeConfig(config);
    }

    const channelConfig = telegramSetup.buildTelegramChannelConfig(token, validation.bot);
    config = openclawConfig.mergeConfig(config, channelConfig);
    config.meta = config.meta || {};
    config.meta.lastTouchedAt = new Date().toISOString();
    openclawConfig.writeConfig(config);

    // Persist channel selection in launcher.json
    try {
      const lc = openclawConfig.readLauncherConfig() || {};
      lc.channels = lc.channels || {};
      lc.channels.telegram = true;
      openclawConfig.writeLauncherConfig(lc);
    } catch {}

    res.json({
      success: true,
      message: 'Telegram bot configured',
      bot: validation.bot,
    });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// GET /api/openclaw/telegram/pairing-status
router.get('/telegram/pairing-status', async (req, res) => {
  try {
    const config = openclawConfig.readConfig();
    if (!config) {
      return res.json({ configured: false, message: 'No openclaw.json found' });
    }

    const telegramConfig = config.channels && config.channels.telegram;
    if (!telegramConfig || !telegramConfig.accounts || !telegramConfig.accounts.default) {
      return res.json({ configured: false, message: 'No Telegram channel configured' });
    }

    const account = telegramConfig.accounts.default;

    // Try to probe the gateway and fetch bot info in parallel
    const gatewayProbe = await pm2Health.probeGateway();

    let botInfo = null;
    if (account.botToken) {
      try {
        const result = await telegramSetup.telegramRequest(account.botToken, 'getMe');
        if (result.ok) {
          botInfo = {
            id: result.result.id,
            username: result.result.username,
            firstName: result.result.first_name,
            canJoinGroups: result.result.can_join_groups,
          };
        }
      } catch {
        // Bot info is best-effort; continue without it
      }
    }

    res.json({
      configured: true,
      dmPolicy: account.dmPolicy || null,
      streamMode: account.streamMode || null,
      historyLimit: account.historyLimit || null,
      gatewayReachable: gatewayProbe.reachable,
      botInfo,
    });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// GET /api/openclaw/telegram/pairing-requests — list pending telegram pairing requests
router.get('/telegram/pairing-requests', (req, res) => {
  execFile('openclaw', ['pairing', 'list', 'telegram', '--json'], { timeout: 5000 }, (err, stdout, stderr) => {
    if (err) {
      return res.status(500).json({ error: 'Failed to list pairing requests', message: (stderr || err.message).trim() });
    }
    try {
      const data = JSON.parse(stdout);
      res.json(data);
    } catch {
      res.status(500).json({ error: 'Failed to parse pairing list output', raw: stdout });
    }
  });
});

// POST /api/openclaw/telegram/pairing-approve — approve a telegram pairing code
router.post('/telegram/pairing-approve', (req, res) => {
  const { code } = req.body;
  if (!code || typeof code !== 'string') {
    return res.status(400).json({ error: 'Bad Request', message: 'code is required' });
  }

  // Sanitize: only allow alphanumeric pairing codes
  const sanitized = code.trim().replace(/[^A-Za-z0-9]/g, '');
  if (!sanitized) {
    return res.status(400).json({ error: 'Bad Request', message: 'Invalid pairing code format' });
  }

  execFile('openclaw', ['pairing', 'approve', 'telegram', sanitized], { timeout: 10000 }, (err, stdout, stderr) => {
    if (err) {
      return res.status(500).json({ error: 'Pairing approval failed', message: (stderr || err.message).trim() });
    }
    // Persist pairing-done flag in launcher.json so the warning banner doesn't reappear
    try {
      const lc = openclawConfig.readLauncherConfig() || {};
      lc.telegramPairingDone = true;
      openclawConfig.writeLauncherConfig(lc);
    } catch {}
    res.json({ success: true, message: (stdout || 'Pairing approved').trim() });
  });
});

// POST /api/openclaw/channel/pairing-approve — approve a pairing code for any channel
router.post('/channel/pairing-approve', (req, res) => {
  const { code, channel } = req.body;
  const resolvedChannel = channel || 'telegram';

  if (!code || typeof code !== 'string') {
    return res.status(400).json({ error: 'Bad Request', message: 'code is required' });
  }

  // Sanitize: only allow alphanumeric pairing codes
  const sanitized = code.trim().replace(/[^A-Za-z0-9]/g, '');
  if (!sanitized) {
    return res.status(400).json({ error: 'Bad Request', message: 'Invalid pairing code format' });
  }

  execFile('openclaw', ['pairing', 'approve', resolvedChannel, sanitized], { timeout: 10000 }, (err, stdout, stderr) => {
    if (err) {
      return res.status(500).json({ error: 'Pairing approval failed', message: (stderr || err.message).trim() });
    }
    // Persist pairing-done flag in launcher.json so the warning banner doesn't reappear
    try {
      const lc = openclawConfig.readLauncherConfig() || {};
      if (resolvedChannel === 'feishu') {
        lc.feishuPairingDone = true;
      } else {
        lc.telegramPairingDone = true;
      }
      openclawConfig.writeLauncherConfig(lc);
    } catch {}
    res.json({ success: true, channel: resolvedChannel, message: (stdout || 'Pairing approved').trim() });
  });
});

// POST /api/openclaw/telegram/test — quick test using saved or provided token
router.post('/telegram/test', async (req, res) => {
  try {
    let { token } = req.body;
    if (!token) {
      const config = openclawConfig.readConfig();
      const account = config?.channels?.telegram?.accounts?.default;
      if (!account?.botToken) {
        return res.status(400).json({ error: 'Bad Request', message: 'No Telegram bot token provided or saved' });
      }
      token = account.botToken;
    }
    const result = await telegramSetup.validateBotToken(token);
    res.json({ success: true, message: 'Telegram bot token is valid', bot: result.bot });
  } catch (err) {
    res.status(400).json({ error: 'Test Failed', message: err.message });
  }
});

// ==========================================
// Feishu / Lark Channel Configuration
// ==========================================

// POST /api/openclaw/feishu/validate
router.post('/feishu/validate', async (req, res) => {
  try {
    const { appId, appSecret, domain } = req.body;
    if (!appId || !appSecret) {
      return res.status(400).json({ error: 'Bad Request', message: 'appId and appSecret are required' });
    }
    const result = await feishuSetup.validateCredentials(appId, appSecret, domain || 'feishu');
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: 'Validation Failed', message: err.message });
  }
});

// POST /api/openclaw/feishu/configure
router.post('/feishu/configure', async (req, res) => {
  try {
    // Auto-shutdown any running Feishu WebSocket test probes
    feishuSetup.stopAllProbes();

    const { appId, appSecret, domain, connectionMode, pluginVersion, encryptKey, verificationToken } = req.body;
    if (!appId || !appSecret) {
      return res.status(400).json({ error: 'Bad Request', message: 'appId and appSecret are required' });
    }

    // Validate pluginVersion if provided — must not contain shell-unsafe chars
    if (pluginVersion !== undefined && pluginVersion !== null && pluginVersion !== '') {
      if (typeof pluginVersion !== 'string' || !/^[a-zA-Z0-9._\-]+$/.test(pluginVersion)) {
        return res.status(400).json({ error: 'Bad Request', message: 'Invalid plugin version format. Only alphanumeric characters, dots, hyphens, and underscores are allowed.' });
      }
    }

    const validation = await feishuSetup.validateCredentials(appId, appSecret, domain || 'feishu');
    if (!validation.valid) {
      return res.status(400).json({ error: 'Validation Failed', message: 'Feishu credentials are invalid' });
    }

    let config = openclawConfig.readConfig();
    if (!config) {
      config = openclawConfig.createDefaultConfig();
      openclawConfig.writeConfig(config);
    }

    // Install and enable feishu plugin if not already present
    const pluginEnabled = !!config.plugins?.entries?.feishu?.enabled;
    if (!pluginEnabled) {
      // Use user-specified version, or try current openclaw version, or fall back to latest
      let pluginInstalled = false;
      if (pluginVersion) {
        try {
          execFileSync('openclaw', ['plugins', 'install', `@openclaw/feishu@${pluginVersion}`], { timeout: 30000 });
          pluginInstalled = true;
        } catch {}
      }
      if (!pluginInstalled) {
        const currentVersion = versionTracker.detectInstalledVersion();
        if (currentVersion) {
          try {
            execFileSync('openclaw', ['plugins', 'install', `@openclaw/feishu@${currentVersion}`], { timeout: 30000 });
            pluginInstalled = true;
          } catch {}
        }
      }
      if (!pluginInstalled) {
        try {
          execFileSync('openclaw', ['plugins', 'install', '@openclaw/feishu'], { timeout: 30000 });
        } catch {}
      }
      try {
        execFileSync('openclaw', ['plugins', 'enable', 'feishu'], { timeout: 10000 });
      } catch {}
      // Re-read config after plugin install/enable may have modified it
      config = openclawConfig.readConfig() || config;
    }

    const channelConfig = feishuSetup.buildChannelConfig(appId.trim(), appSecret.trim(), {
      connectionMode: connectionMode || 'websocket',
      domain: domain || undefined,
      encryptKey: encryptKey?.trim() || undefined,
      verificationToken: verificationToken?.trim() || undefined,
    });
    config = openclawConfig.mergeConfig(config, channelConfig);
    config.meta = config.meta || {};
    config.meta.lastTouchedAt = new Date().toISOString();
    openclawConfig.writeConfig(config);

    // Persist channel selection in launcher.json
    try {
      const lc = openclawConfig.readLauncherConfig() || {};
      lc.channels = lc.channels || {};
      lc.channels.feishu = true;
      openclawConfig.writeLauncherConfig(lc);
    } catch {}

    res.json({
      success: true,
      message: 'Feishu channel configured',
      bot: validation.bot,
      pluginVersion: config.plugins?.entries?.feishu?.version || null,
    });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// GET /api/openclaw/feishu/status
router.get('/feishu/status', async (req, res) => {
  try {
    const config = openclawConfig.readConfig();
    if (!config) {
      return res.json({ configured: false, message: 'No openclaw.json found' });
    }

    const feishuConfig = config.channels?.feishu;
    if (!feishuConfig || !feishuConfig.appId) {
      return res.json({ configured: false, message: 'No Feishu channel configured' });
    }

    const gatewayProbe = await pm2Health.probeGateway();

    let botInfo = null;
    if (feishuConfig.appId && feishuConfig.appSecret) {
      try {
        const tenantToken = await feishuSetup.getTenantAccessToken(feishuConfig.appId, feishuConfig.appSecret, feishuConfig.domain);
        botInfo = await feishuSetup.getBotInfo(tenantToken, feishuConfig.domain);
      } catch {
        // Bot info is best-effort
      }
    }

    res.json({
      configured: true,
      domain: feishuConfig.domain || 'feishu',
      connectionMode: feishuConfig.connectionMode || 'websocket',
      gatewayReachable: gatewayProbe.reachable,
      gatewayPort: config.gateway?.port || 18789,
      botInfo,
      pluginVersion: config.plugins?.entries?.feishu?.version || null,
      hasEncryptKey: !!feishuConfig.encryptKey,
      hasVerificationToken: !!feishuConfig.verificationToken,
    });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// POST /api/openclaw/feishu/test — quick test using saved or provided credentials
router.post('/feishu/test', async (req, res) => {
  try {
    let { appId, appSecret, domain } = req.body;
    if (!appId || !appSecret) {
      const config = openclawConfig.readConfig();
      const feishuConfig = config?.channels?.feishu;
      if (!feishuConfig?.appId || !feishuConfig?.appSecret) {
        return res.status(400).json({ error: 'Bad Request', message: 'No Feishu credentials provided or saved' });
      }
      appId = feishuConfig.appId;
      appSecret = feishuConfig.appSecret;
      domain = domain || feishuConfig.domain || 'feishu';
    }
    const result = await feishuSetup.validateCredentials(appId, appSecret, domain || 'feishu');
    res.json({ success: true, message: 'Feishu credentials are valid', bot: result.bot });
  } catch (err) {
    res.status(400).json({ error: 'Test Failed', message: err.message });
  }
});

// POST /api/openclaw/feishu/ws-probe — start a temporary WebSocket probe to validate event subscription
router.post('/feishu/ws-probe', async (req, res) => {
  try {
    let { appId, appSecret, domain } = req.body;
    if (!appId || !appSecret) {
      const config = openclawConfig.readConfig();
      const feishuConfig = config?.channels?.feishu;
      if (!feishuConfig?.appId || !feishuConfig?.appSecret) {
        return res.status(400).json({ error: 'Bad Request', message: 'No Feishu credentials provided or saved' });
      }
      appId = feishuConfig.appId;
      appSecret = feishuConfig.appSecret;
      domain = feishuConfig.domain || 'feishu';
    }
    domain = domain || 'feishu';
    console.log(`[ws-probe] domain=${domain}, apiBase=${feishuSetup.getApiBase(domain)}`);
    const result = await feishuSetup.startWsProbe(appId, appSecret, domain, { maxDurationMs: 300000 });
    // If domain was auto-corrected, update the saved config
    if (result.domainCorrected && result.domain) {
      try {
        const cfg = openclawConfig.readConfig();
        if (cfg?.channels?.feishu) {
          cfg.channels.feishu.domain = result.domain;
          openclawConfig.writeConfig(cfg);
          console.log(`[ws-probe] domain auto-corrected: ${domain} -> ${result.domain}, config updated`);
        }
      } catch (e) {
        console.error('[ws-probe] failed to persist domain correction:', e.message);
      }
    }
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: 'Probe Failed', message: err.message });
  }
});

// GET /api/openclaw/feishu/ws-probe/:sessionId — get probe status
router.get('/feishu/ws-probe/:sessionId', (req, res) => {
  const status = feishuSetup.getProbeStatus(req.params.sessionId);
  if (!status) {
    return res.status(404).json({ error: 'Not Found', message: 'Probe session not found or expired' });
  }
  res.json(status);
});

// DELETE /api/openclaw/feishu/ws-probe/:sessionId — stop a running probe
router.delete('/feishu/ws-probe/:sessionId', (req, res) => {
  const stopped = feishuSetup.stopProbe(req.params.sessionId);
  if (!stopped) {
    return res.status(404).json({ error: 'Not Found', message: 'Probe session not found' });
  }
  res.json({ success: true, message: 'Probe stopped' });
});

// ==========================================
// OpenClaw Configuration (Tasks 8-11)
// ==========================================

// GET /api/openclaw/config
router.get('/config', (req, res) => {
  try {
    const config = openclawConfig.readConfig();
    if (!config) {
      return res.status(404).json({ error: 'Not Found', message: 'openclaw.json not found' });
    }
    const sanitized = openclawConfig.sanitizeConfig(config);
    // Merge launcher-only settings (allowedModels) so the frontend can read them
    const launcherConfig = openclawConfig.readLauncherConfig();
    if (launcherConfig?.allowedModels) {
      sanitized._launcher = { allowedModels: launcherConfig.allowedModels };
    }
    res.json(sanitized);
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// POST /api/openclaw/config/init
router.post('/config/init', (req, res) => {
  try {
    const existingConfig = openclawConfig.readConfig();
    if (existingConfig && !req.body.force) {
      return res.status(409).json({
        error: 'Conflict',
        message: 'openclaw.json already exists. Send { "force": true } to overwrite.',
      });
    }

    // Detect available providers to use as default
    const detected = require('../services/credential-discovery').detectZaiProvider();
    const defaultProvider = detected && detected.length > 0 ? detected[0] : null;

    let config = openclawConfig.createDefaultConfig(defaultProvider);

    // Merge user-supplied values into the default config
    const userPatch = req.body;
    if (userPatch && typeof userPatch === 'object') {
      const { force, ...patch } = userPatch;
      if (Object.keys(patch).length > 0) {
        config = openclawConfig.mergeConfig(config, patch);
      }
    }

    const validation = openclawConfig.validateConfig(config);
    if (!validation.valid) {
      return res.status(400).json({ error: 'Validation Failed', message: validation.errors.join('; ') });
    }

    // Auto-generate a gateway auth token if none was provided
    if (!config.gateway?.auth?.token) {
      config.gateway = config.gateway || {};
      config.gateway.auth = config.gateway.auth || { mode: 'token' };
      config.gateway.auth.token = openclawConfig.generateSecureToken();
    }

    openclawConfig.writeConfig(config);

    const gatewayToken = config.gateway?.auth?.token;

    // Restart (or start) the gateway process with the new config
    const restartResult = pm2Health.restartGateway();

    res.json({
      success: true,
      message: 'openclaw.json initialized',
      config: openclawConfig.sanitizeConfig(config),
      gatewayRestarted: restartResult.success,
      generatedToken: gatewayToken || null,
      warnings: validation.warnings.length > 0 ? validation.warnings : undefined,
    });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// GET /api/openclaw/config/token-status
router.get('/config/token-status', (req, res) => {
  try {
    const config = openclawConfig.readConfig();
    if (!config) {
      return res.status(404).json({ error: 'Not Found', message: 'openclaw.json not found' });
    }
    const token = config.gateway?.auth?.token;
    const check = openclawConfig.checkTokenStrength(token);
    res.json({
      configured: !!token,
      strength: check.strength,
      warning: check.warning,
      length: token ? token.length : 0,
    });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// GET /api/openclaw/config/gateway-token — returns raw token for control UI localStorage injection
router.get('/config/gateway-token', (req, res) => {
  try {
    const config = openclawConfig.readConfig();
    if (!config) {
      return res.status(404).json({ error: 'Not Found', message: 'openclaw.json not found' });
    }
    const token = config.gateway?.auth?.token;
    if (!token) {
      return res.json({ token: '' });
    }
    res.json({ token });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// POST /api/openclaw/config/regenerate-token
router.post('/config/regenerate-token', (req, res) => {
  try {
    let config = openclawConfig.readConfig();
    if (!config) {
      return res.status(404).json({ error: 'Not Found', message: 'openclaw.json not found' });
    }

    const newToken = openclawConfig.generateSecureToken();
    config.gateway = config.gateway || {};
    config.gateway.mode = 'local';
    config.gateway.auth = config.gateway.auth || { mode: 'token' };
    config.gateway.auth.token = newToken;
    config.meta = config.meta || {};
    config.meta.lastTouchedAt = new Date().toISOString();
    openclawConfig.writeConfig(config);

    res.json({
      success: true,
      message: 'Gateway token regenerated',
      token: newToken,
    });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// PATCH /api/openclaw/config
router.patch('/config', (req, res) => {
  try {
    const config = openclawConfig.readConfig();
    if (!config) {
      return res.status(404).json({ error: 'Not Found', message: 'openclaw.json not found' });
    }

    const patch = req.body;
    if (!patch || typeof patch !== 'object' || Object.keys(patch).length === 0) {
      return res.status(400).json({ error: 'Bad Request', message: 'Request body must be a non-empty object' });
    }

    // Only allow patching specific sections
    const allowedSections = ['models', 'gateway', 'agents', 'channels', 'auth', 'messages', 'commands'];
    const invalidKeys = Object.keys(patch).filter(k => !allowedSections.includes(k));
    if (invalidKeys.length > 0) {
      return res.status(400).json({
        error: 'Bad Request',
        message: `Cannot patch sections: ${invalidKeys.join(', ')}. Allowed: ${allowedSections.join(', ')}`,
      });
    }

    const merged = openclawConfig.mergeConfig(config, patch);
    merged.meta = merged.meta || {};
    merged.meta.lastTouchedAt = new Date().toISOString();

    // If the primary model was changed, ensure it is registered in the provider's model list
    const newPrimary = patch.agents?.defaults?.model?.primary;
    if (newPrimary && newPrimary.includes('/')) {
      const [provName, modelId] = newPrimary.split('/', 2);
      if (merged.models?.providers?.[provName]) {
        let provModels = merged.models.providers[provName].models || [];

        // Ensure the selected model is in the list
        const alreadyListed = provModels.some(m => (typeof m === 'string' ? m : m.id) === modelId);
        if (!alreadyListed) {
          provModels.push({
            id: modelId,
            name: modelId,
            reasoning: true,
            input: ['text'],
            cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
            contextWindow: 128000,
            maxTokens: 8192,
          });
        }
        merged.models.providers[provName].models = provModels;
      }
    }

    // Auto-generate gateway auth token if none exists
    let autoGeneratedToken = null;
    if (!merged.gateway?.auth?.token) {
      merged.gateway = merged.gateway || {};
      merged.gateway.auth = merged.gateway.auth || { mode: 'token' };
      merged.gateway.auth.token = openclawConfig.generateSecureToken();
      autoGeneratedToken = merged.gateway.auth.token;
    }

    const validation = openclawConfig.validateConfig(merged);
    if (!validation.valid) {
      return res.status(400).json({ error: 'Validation Failed', message: validation.errors.join('; ') });
    }

    openclawConfig.writeConfig(merged);

    // Restart the gateway process so it picks up the new config
    const restartResult = pm2Health.restartGateway();

    res.json({
      success: true,
      message: 'Configuration updated',
      config: openclawConfig.sanitizeConfig(merged),
      gatewayRestarted: restartResult.success,
      generatedToken: autoGeneratedToken,
      warnings: validation.warnings.length > 0 ? validation.warnings : undefined,
    });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// ==========================================
// Health Status & PM2 Monitoring (Tasks 12-15)
// ==========================================

// GET /api/openclaw/health
router.get('/health', async (req, res) => {
  try {
    const health = await pm2Health.getComprehensiveHealth();
    // Add managed pool status to health response (Task 23)
    const poolInfo = instanceControl.getAdoptionInfo();
    health.managedPool = {
      enabled: poolInfo.enabled,
      status: poolInfo.status,
      adoptedAt: poolInfo.adoptedAt,
      failedAttempts: poolInfo.failedAttempts || 0,
      riskLevel: poolInfo.riskLevel || 'none',
    };
    // Add version info to health summary
    const versionInfo = versionTracker.getVersionInfo();
    const launcherCfg = openclawConfig.readLauncherConfig() || {};
    versionInfo.upgradePolicy = launcherCfg.upgradePolicy || 'manual';
    health.version = versionInfo;
    health.summary.version = versionInfo.updateAvailable ? 'info' : 'ok';
    // Feature flags — env var OR launcher.json
    health.features = {
      marketplace: process.env.ENABLE_MARKETPLACE === '1' || process.env.ENABLE_MARKETPLACE === 'true' || !!launcherCfg.enableMarketplace,
    };
    // Include instance identity (name + emoji + creature + vibe) from IDENTITY.md
    try {
      const idFile = workspaceBrowser.readWorkspaceFile('IDENTITY.md', 'workspace');
      const idContent = (idFile.content || '').split(/^---$/m)[0];
      const parseField = (key, maxLen = 80) => {
        const m = idContent.match(new RegExp(`^-\\s*\\**${key}:\\**\\s*(.+)`, 'mi'));
        if (!m) return null;
        let val = m[1].trim();
        if (/^\(.*\)$/.test(val)) return null;
        if (/pick\s+something/i.test(val)) return null;
        if (val.length > maxLen) val = val.slice(0, maxLen);
        return val;
      };
      const parseDisplayField = (key, maxLen = 80) => {
        const val = parseField(key, maxLen);
        if (!val) return null;
        const cleaned = val.replace(/\s*\([^)]*\)\s*$/, '').trim();
        return cleaned || null;
      };
      const emojiVal = parseDisplayField('Emoji', 10);
      health.instance = {
        name: parseDisplayField('Name', 40) || null,
        emoji: (emojiVal && [...emojiVal].length <= 2) ? emojiVal : null,
        creature: parseField('Creature') || null,
        vibe: parseField('Vibe') || null,
      };
    } catch (_) {
      health.instance = { name: null, emoji: null, creature: null, vibe: null };
    }
    res.json(health);
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// GET /api/openclaw/health/batch — fetch all health sections in parallel
router.get('/health/batch', async (req, res) => {
  const batchStart = Date.now();
  const results = {};

  // Prime the pm2 process cache once (avoids 8+ redundant execSync calls)
  pm2Health.getPm2Processes();

  const checks = {
    config: async () => pm2Health.getConfigHealthChecks(),

    models: async () => {
      const config = openclawConfig.readConfig();
      if (!config) return { providers: [] };
      const providers = config.models?.providers || {};
      const providerResults = [];
      // Probe all providers in parallel via HEAD request (5s timeout)
      const entries = Object.entries(providers);
      const probes = await Promise.allSettled(entries.map(([name, provider]) => {
        if (provider.baseUrl) return probeProviderUrl(provider.baseUrl, 5000);
        return Promise.resolve(null);
      }));
      entries.forEach(([name, provider], i) => {
        const rawKey = resolveProviderApiKey(name, provider);
        const keyPrefix = rawKey ? rawKey.slice(0, 8) + '...' + rawKey.slice(-6) : null;
        const probeResult = probes[i];
        let reachable = null;
        let detail = '';
        if (provider.baseUrl) {
          reachable = probeResult.status === 'fulfilled' ? probeResult.value : false;
          detail = reachable ? 'Reachable' : (reachable === false ? 'Unreachable' : 'Connection failed');
        } else {
          detail = 'No baseUrl configured';
        }
        providerResults.push({
          name, configured: true, reachable,
          baseUrl: provider.baseUrl || null,
          apiFormat: provider.api || 'openai-completions',
          authMode: provider.auth || 'api-key',
          keyPrefix,
          models: (provider.models || []).map(m => typeof m === 'string' ? m : m.id || m.name),
          detail,
        });
      });
      const defaultModel = config.agents?.defaults?.model?.primary || null;
      return { providers: providerResults, defaultModel };
    },

    telegram: async () => {
      const config = openclawConfig.readConfig();
      if (!config) return { configured: false, botValid: null, botUsername: null, pluginEnabled: false, detail: 'No config file' };
      const telegramConfig = config.channels?.telegram;
      const account = telegramConfig?.accounts?.default;
      const pluginEnabled = !!config.plugins?.entries?.telegram?.enabled;
      if (!account || !account.botToken) return { configured: false, botValid: null, botUsername: null, pluginEnabled, detail: 'Telegram not configured' };

      // Run Telegram API call and local file reads in parallel
      const telegramApiPromise = telegramSetup.telegramRequest(account.botToken, 'getMe', 5000);

      const dmPolicy = account.dmPolicy || null;
      const configAllowFrom = Array.isArray(account.allowFrom) ? account.allowFrom.map(String) : [];
      // Track which source each user ID comes from
      const userSources = new Map();
      for (const id of configAllowFrom) userSources.set(id, (userSources.get(id) || []).concat('openclaw.json'));
      // Read both generic and account-specific allowFrom files (gateway may write to either)
      for (const fname of ['telegram-allowFrom.json', 'telegram-default-allowFrom.json']) {
        try {
          const storeData = JSON.parse(fs.readFileSync(path.join(os.homedir(), '.openclaw', 'credentials', fname), 'utf8'));
          if (Array.isArray(storeData.allowFrom)) {
            for (const id of storeData.allowFrom.map(String)) userSources.set(id, (userSources.get(id) || []).concat(fname));
          }
        } catch {}
      }
      const allPairedUsers = [...userSources.keys()];
      const paired = allPairedUsers.length > 0;
      const pairedCount = allPairedUsers.length;

      let pairedDetails = [];
      try {
        const pairingData = JSON.parse(fs.readFileSync(path.join(os.homedir(), '.openclaw', 'credentials', 'telegram-pairing.json'), 'utf8'));
        const requests = Array.isArray(pairingData.requests) ? pairingData.requests : [];
        for (const userId of allPairedUsers) {
          const r = requests.find(r => String(r.id) === String(userId));
          const meta = r?.meta;
          pairedDetails.push({ userId: String(userId), name: meta ? [meta.firstName, meta.lastName].filter(Boolean).join(' ') || (meta.username ? `@${meta.username}` : null) : null, username: meta?.username || null, approvedAt: r?.approvedAt || r?.updatedAt || null, sources: [...new Set(userSources.get(userId) || [])] });
        }
      } catch { pairedDetails = allPairedUsers.map(userId => ({ userId: String(userId), name: null, approvedAt: null, sources: [...new Set(userSources.get(userId) || [])] })); }

      let pairingRequests = [];
      // Read pending pairing requests directly from the store file (avoids 3.5s subprocess)
      if (dmPolicy === 'pairing') {
        try {
          const pairingData = JSON.parse(fs.readFileSync(path.join(os.homedir(), '.openclaw', 'credentials', 'telegram-pairing.json'), 'utf8'));
          const requests = Array.isArray(pairingData.requests) ? pairingData.requests : [];
          pairingRequests = requests.filter(r => !r.approvedAt);
        } catch {}
      }

      // Await Telegram API
      let botValid = false, botUsername = null, detail = '';
      try {
        const result = await telegramApiPromise;
        if (result.ok) { botValid = true; botUsername = result.result.username || null; detail = 'Bot token valid'; }
        else { detail = result.description || 'Bot token invalid'; }
      } catch (err) { detail = `Telegram API error: ${err.message}`; }

      // Check launcher.json for persisted pairing-done flag
      const launcherPairingDone = !!(openclawConfig.readLauncherConfig() || {}).telegramPairingDone;

      return { configured: true, botValid, botUsername, pluginEnabled, detail, dmPolicy, pairingRequests, paired, pairedCount, pairedDetails, launcherPairingDone };
    },

    feishu: async () => {
      const config = openclawConfig.readConfig();
      if (!config) return { configured: false, detail: 'No config file' };
      const feishuConfig = config.channels?.feishu;
      const pluginEnabled = !!config.plugins?.entries?.feishu?.enabled;
      if (!feishuConfig || !feishuConfig.appId) return { configured: false, pluginEnabled, detail: 'Feishu not configured' };

      const domain = feishuConfig.domain || 'feishu';
      const connectionMode = feishuConfig.connectionMode || 'websocket';
      const dmPolicy = feishuConfig.dmPolicy || null;

      let credentialsValid = false, botName = null, detail = '';
      try {
        const tenantToken = await feishuSetup.getTenantAccessToken(feishuConfig.appId, feishuConfig.appSecret, domain);
        credentialsValid = true;
        detail = 'Credentials valid';
        try {
          const botInfo = await feishuSetup.getBotInfo(tenantToken, domain);
          if (botInfo) botName = botInfo.app_name || null;
        } catch {}
      } catch (err) { detail = `Feishu API error: ${err.message}`; }

      // Check pairing status for feishu (always read — dmPolicy may not be set for feishu)
      let pairingRequests = [];
      try {
        const pairingData = JSON.parse(fs.readFileSync(path.join(os.homedir(), '.openclaw', 'credentials', 'feishu-pairing.json'), 'utf8'));
        const requests = Array.isArray(pairingData.requests) ? pairingData.requests : [];
        pairingRequests = requests.filter(r => !r.approvedAt);
      } catch {}

      // Check paired users from feishu allowFrom (config + store files, mirroring telegram pattern)
      const configAllowFrom = Array.isArray(feishuConfig.allowFrom) ? feishuConfig.allowFrom.map(String) : [];
      const userSources = new Map();
      for (const id of configAllowFrom) userSources.set(id, (userSources.get(id) || []).concat('openclaw.json'));
      for (const fname of ['feishu-allowFrom.json', 'feishu-default-allowFrom.json']) {
        try {
          const storeData = JSON.parse(fs.readFileSync(path.join(os.homedir(), '.openclaw', 'credentials', fname), 'utf8'));
          if (Array.isArray(storeData.allowFrom)) {
            for (const id of storeData.allowFrom.map(String)) userSources.set(id, (userSources.get(id) || []).concat(fname));
          }
        } catch {}
      }
      const allPairedUsers = [...userSources.keys()];
      const paired = allPairedUsers.length > 0;
      const pairedCount = allPairedUsers.length;
      const launcherPairingDone = !!(openclawConfig.readLauncherConfig() || {}).feishuPairingDone;

      return { configured: true, credentialsValid, pluginEnabled, domain, connectionMode, botName, detail, dmPolicy, pairingRequests, paired, pairedCount, launcherPairingDone };
    },

    gateway: async () => {
      const gatewayProcess = pm2Health.getOpenClawGatewayProcess();
      const config = openclawConfig.readConfig();
      const port = config?.gateway?.port || 18789;
      const probe = await pm2Health.probeGateway(port);
      const tokenSync = pm2Health.checkTokenSync();
      const tokenHealth = pm2Health.checkTokenHealth();
      const management = pm2Health.checkGatewayManagement(port);
      const reloadMode = config?.gateway?.reload?.mode || null;
      const zombies = pm2Health.checkZombieProcesses();
      return { process: gatewayProcess, probe, tokenSync, security: { token: tokenHealth, tokenSync }, management, reloadMode, zombies, restartGracePeriod: pm2Health.isInRestartGracePeriod() };
    },

    logs: async () => pm2Health.getGatewayLogInfo(),

    managedPool: async () => instanceControl.getAdoptionInfo(),

    version: async () => {
      const info = await versionTracker.checkForUpdate();
      const lc = openclawConfig.readLauncherConfig();
      info.upgradePolicy = lc?.upgradePolicy || 'manual';
      return info;
    },

    resources: async () => systemStats.getSummary(),
  };

  const entries = Object.entries(checks);
  const timings = {};
  const settled = await Promise.allSettled(entries.map(async ([key, fn]) => {
    const t0 = Date.now();
    try {
      const result = await fn();
      timings[key] = Date.now() - t0;
      return result;
    } catch (err) {
      timings[key] = Date.now() - t0;
      throw err;
    }
  }));
  entries.forEach(([key], i) => {
    const r = settled[i];
    results[key] = r.status === 'fulfilled' ? r.value : { error: r.reason?.message || 'Failed' };
  });

  // Invalidate pm2 cache after batch completes
  pm2Health.invalidatePm2Cache();

  results._timing = { ...timings, total: Date.now() - batchStart };
  res.json(results);
});

// GET /api/openclaw/health/config
router.get('/health/config', (req, res) => {
  try {
    const result = pm2Health.getConfigHealthChecks();
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// GET /api/openclaw/health/models
router.get('/health/models', async (req, res) => {
  try {
    const config = openclawConfig.readConfig();
    if (!config) {
      return res.json({ providers: [] });
    }

    const providers = config.models?.providers || {};
    const results = [];

    for (const [name, provider] of Object.entries(providers)) {
      const rawKey = resolveProviderApiKey(name, provider);
      const keyPrefix = rawKey ? rawKey.slice(0, 8) + '...' + rawKey.slice(-6) : null;

      const entry = {
        name,
        configured: true,
        reachable: null,
        baseUrl: provider.baseUrl || null,
        apiFormat: provider.api || 'openai-completions',
        authMode: provider.auth || 'api-key',
        keyPrefix,
        models: (provider.models || []).map(m => typeof m === 'string' ? m : m.id || m.name),
        detail: '',
      };

      // Flag missing API key — show error status instead of a misleading "Reachable"
      if (!rawKey) {
        entry.reachable = false;
        entry.detail = 'API key missing';
        results.push(entry);
        continue;
      }

      // Attempt lightweight connectivity check to provider's baseUrl
      if (provider.baseUrl) {
        try {
          const reachable = await probeProviderUrl(provider.baseUrl);
          entry.reachable = reachable;
          entry.detail = reachable ? 'Reachable' : 'Unreachable';
        } catch {
          entry.reachable = false;
          entry.detail = 'Connection failed';
        }
      } else {
        entry.reachable = null;
        entry.detail = 'No baseUrl configured';
      }

      results.push(entry);
    }

    let defaultModel = config.agents?.defaults?.model?.primary || null;
    // Normalize legacy unprefixed model by resolving its provider
    if (defaultModel && !defaultModel.includes('/')) {
      // First try matching the model in a provider's model list
      const match = Object.entries(providers).find(([, p]) =>
        (p.models || []).some(m => (typeof m === 'string' ? m : m.id) === defaultModel)
      );
      if (match) {
        defaultModel = `${match[0]}/${defaultModel}`;
      } else {
        // Infer provider from well-known model name patterns
        const inferred = /^glm/i.test(defaultModel) ? 'zai'
          : /^claude/i.test(defaultModel) ? 'anthropic'
          : /^(gpt|o[0-9]|dall-e|whisper)/i.test(defaultModel) ? 'openai'
          : /^gemini/i.test(defaultModel) ? 'google'
          : null;
        if (inferred && providers[inferred]) {
          defaultModel = `${inferred}/${defaultModel}`;
        } else if (inferred) {
          // Provider inferred but not configured — auto-create a stub entry with well-known defaults
          // so the health page displays the provider instead of "No providers configured".
          // Note: credential discovery is NOT done here; that belongs in the configure flow.
          // The "API key missing" check in the main provider loop above will flag the issue.
          const wellKnownDefaults = {
            anthropic: { baseUrl: 'https://api.anthropic.com', api: 'anthropic-messages' },
            openai: { baseUrl: 'https://api.openai.com', api: 'openai-completions' },
            google: { baseUrl: 'https://generativelanguage.googleapis.com', api: 'openai-completions' },
          };
          const stubDefaults = wellKnownDefaults[inferred];
          if (stubDefaults) {
            const modelId = defaultModel;
            const stubProvider = {
              baseUrl: stubDefaults.baseUrl,
              auth: 'api-key',
              api: stubDefaults.api,
              models: [{ id: modelId, name: modelId, reasoning: true, input: ['text'], cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 }, contextWindow: 128000, maxTokens: 8192 }],
            };
            // Persist the stub into config so it shows up on refresh
            config.models = config.models || {};
            config.models.providers = config.models.providers || {};
            config.models.providers[inferred] = stubProvider;
            config.agents.defaults.model.primary = `${inferred}/${modelId}`;
            openclawConfig.writeConfig(config);
            // Add the provider to current results — keyPrefix will be null, triggering "API key missing"
            const rawKey = resolveProviderApiKey(inferred, stubProvider);
            const stubEntry = {
              name: inferred,
              configured: true,
              reachable: false,
              baseUrl: stubDefaults.baseUrl,
              apiFormat: stubDefaults.api,
              authMode: 'api-key',
              keyPrefix: rawKey ? rawKey.slice(0, 8) + '...' + rawKey.slice(-6) : null,
              models: [modelId],
              detail: rawKey ? '' : 'API key missing',
            };
            // Only probe connectivity if we have a key
            if (rawKey && stubProvider.baseUrl) {
              try {
                const reachable = await probeProviderUrl(stubDefaults.baseUrl);
                stubEntry.reachable = reachable;
                stubEntry.detail = reachable ? 'Reachable' : 'Unreachable';
              } catch {
                stubEntry.reachable = false;
                stubEntry.detail = 'Connection failed';
              }
            }
            results.push(stubEntry);
            defaultModel = `${inferred}/${modelId}`;
          } else {
            defaultModel = null;
          }
        } else {
          defaultModel = null;
        }
      }
    }
    res.json({ providers: results, defaultModel });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// GET /api/openclaw/health/telegram
router.get('/health/telegram', async (req, res) => {
  try {
    const config = openclawConfig.readConfig();
    if (!config) {
      return res.json({ configured: false, botValid: null, botUsername: null, pluginEnabled: false, detail: 'No config file' });
    }

    const telegramConfig = config.channels?.telegram;
    const account = telegramConfig?.accounts?.default;
    const pluginEnabled = !!config.plugins?.entries?.telegram?.enabled;

    if (!account || !account.botToken) {
      return res.json({ configured: false, botValid: null, botUsername: null, pluginEnabled, detail: 'Telegram not configured' });
    }

    // Probe the Telegram API with getMe
    let botValid = false;
    let botUsername = null;
    let detail = '';
    try {
      const result = await telegramSetup.telegramRequest(account.botToken, 'getMe');
      if (result.ok) {
        botValid = true;
        botUsername = result.result.username || null;
        detail = 'Bot token valid';
      } else {
        detail = result.description || 'Bot token invalid';
      }
    } catch (err) {
      detail = `Telegram API error: ${err.message}`;
    }

    const dmPolicy = account.dmPolicy || null;

    // Collect paired users from both config allowFrom and the gateway's pairing store file
    const configAllowFrom = Array.isArray(account.allowFrom) ? account.allowFrom.map(String) : [];
    // Track which source each user ID comes from
    const userSources = new Map();
    for (const id of configAllowFrom) userSources.set(id, (userSources.get(id) || []).concat('openclaw.json'));
    // Read both generic and account-specific allowFrom files (gateway may write to either)
    for (const fname of ['telegram-allowFrom.json', 'telegram-default-allowFrom.json']) {
      try {
        const storeData = JSON.parse(fs.readFileSync(path.join(os.homedir(), '.openclaw', 'credentials', fname), 'utf8'));
        if (Array.isArray(storeData.allowFrom)) {
          for (const id of storeData.allowFrom.map(String)) userSources.set(id, (userSources.get(id) || []).concat(fname));
        }
      } catch {
        // File may not exist if no one has been paired yet
      }
    }
    const allPairedUsers = [...userSources.keys()];
    const paired = allPairedUsers.length > 0;
    const pairedCount = allPairedUsers.length;

    // Read the pairing store for timestamps on paired users
    let pairedDetails = [];
    const pairingStorePath = path.join(os.homedir(), '.openclaw', 'credentials', 'telegram-pairing.json');
    try {
      const pairingData = JSON.parse(fs.readFileSync(pairingStorePath, 'utf8'));
      const requests = Array.isArray(pairingData.requests) ? pairingData.requests : [];
      // Build details for each paired user using approved request metadata
      for (const userId of allPairedUsers) {
        const req = requests.find(r => String(r.id) === String(userId));
        const meta = req?.meta;
        const displayName = meta
          ? [meta.firstName, meta.lastName].filter(Boolean).join(' ') || (meta.username ? `@${meta.username}` : null)
          : null;
        pairedDetails.push({
          userId: String(userId),
          name: displayName,
          username: meta?.username || null,
          approvedAt: req?.approvedAt || req?.updatedAt || null,
          sources: [...new Set(userSources.get(userId) || [])],
        });
      }
    } catch {
      // Fallback: just list user IDs without metadata
      pairedDetails = allPairedUsers.map(userId => ({ userId: String(userId), name: null, approvedAt: null, sources: [...new Set(userSources.get(userId) || [])] }));
    }

    // If dmPolicy is "pairing", read pending pairing requests from the store file
    let pairingRequests = [];
    if (dmPolicy === 'pairing') {
      try {
        // Read directly from pairing store file instead of spawning a 3.5s subprocess
        const pairingData = JSON.parse(fs.readFileSync(pairingStorePath, 'utf8'));
        const requests = Array.isArray(pairingData.requests) ? pairingData.requests : [];
        pairingRequests = requests.filter(r => !r.approvedAt);
      } catch {}
    }

    // Check launcher.json for persisted pairing-done flag
    const launcherPairingDone = !!(openclawConfig.readLauncherConfig() || {}).telegramPairingDone;

    res.json({ configured: true, botValid, botUsername, pluginEnabled, detail, dmPolicy, pairingRequests, paired, pairedCount, pairedDetails, launcherPairingDone });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// GET /api/openclaw/health/feishu
router.get('/health/feishu', async (req, res) => {
  try {
    const config = openclawConfig.readConfig();
    if (!config) {
      return res.json({ configured: false, detail: 'No config file' });
    }

    const feishuConfig = config.channels?.feishu;
    const pluginEnabled = !!config.plugins?.entries?.feishu?.enabled;

    if (!feishuConfig || !feishuConfig.appId) {
      return res.json({ configured: false, pluginEnabled, detail: 'Feishu not configured' });
    }

    const domain = feishuConfig.domain || 'feishu';
    const connectionMode = feishuConfig.connectionMode || 'websocket';
    const dmPolicy = feishuConfig.dmPolicy || null;

    let credentialsValid = false;
    let botName = null;
    let detail = '';
    try {
      const tenantToken = await feishuSetup.getTenantAccessToken(feishuConfig.appId, feishuConfig.appSecret, domain);
      credentialsValid = true;
      detail = 'Credentials valid';
      try {
        const botInfo = await feishuSetup.getBotInfo(tenantToken, domain);
        if (botInfo) botName = botInfo.app_name || null;
      } catch {}
    } catch (err) {
      detail = `Feishu API error: ${err.message}`;
    }

    // Pairing status (always read — dmPolicy may not be set for feishu)
    let pairingRequests = [];
    try {
      const pairingData = JSON.parse(fs.readFileSync(path.join(os.homedir(), '.openclaw', 'credentials', 'feishu-pairing.json'), 'utf8'));
      const requests = Array.isArray(pairingData.requests) ? pairingData.requests : [];
      pairingRequests = requests.filter(r => !r.approvedAt);
    } catch {}

    // Check paired users from feishu allowFrom (config + store files, mirroring telegram pattern)
    const configAllowFrom = Array.isArray(feishuConfig.allowFrom) ? feishuConfig.allowFrom.map(String) : [];
    const userSources = new Map();
    for (const id of configAllowFrom) userSources.set(id, (userSources.get(id) || []).concat('openclaw.json'));
    for (const fname of ['feishu-allowFrom.json', 'feishu-default-allowFrom.json']) {
      try {
        const storeData = JSON.parse(fs.readFileSync(path.join(os.homedir(), '.openclaw', 'credentials', fname), 'utf8'));
        if (Array.isArray(storeData.allowFrom)) {
          for (const id of storeData.allowFrom.map(String)) userSources.set(id, (userSources.get(id) || []).concat(fname));
        }
      } catch {}
    }
    const allPairedUsers = [...userSources.keys()];
    const paired = allPairedUsers.length > 0;
    const pairedCount = allPairedUsers.length;
    const launcherPairingDone = !!(openclawConfig.readLauncherConfig() || {}).feishuPairingDone;

    res.json({ configured: true, credentialsValid, pluginEnabled, domain, connectionMode, botName, detail, dmPolicy, pairingRequests, paired, pairedCount, launcherPairingDone });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// GET /api/openclaw/health/gateway
router.get('/health/gateway', async (req, res) => {
  try {
    const gatewayProcess = pm2Health.getOpenClawGatewayProcess();
    const config = openclawConfig.readConfig();
    const port = config?.gateway?.port || 18789;
    const probe = await pm2Health.probeGateway(port);
    const tokenSync = pm2Health.checkTokenSync();
    const tokenHealth = pm2Health.checkTokenHealth();
    const management = pm2Health.checkGatewayManagement(port);
    const reloadMode = config?.gateway?.reload?.mode || null;
    const zombies = pm2Health.checkZombieProcesses();

    res.json({
      process: gatewayProcess,
      probe,
      tokenSync,
      security: { token: tokenHealth, tokenSync },
      management,
      reloadMode,
      zombies,
      restartGracePeriod: pm2Health.isInRestartGracePeriod(),
    });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// GET /api/openclaw/health/gateway/ws
router.get('/health/gateway/ws', async (req, res) => {
  try {
    const result = await gatewayProxy.probeGatewayWebSocket();
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// GET /api/openclaw/health/logs — gateway log line counts
router.get('/health/logs', (req, res) => {
  try {
    const result = pm2Health.getGatewayLogInfo();
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// GET /api/openclaw/health/logs/tail — tail gateway logs
router.get('/health/logs/tail', (req, res) => {
  try {
    const lines = Math.min(parseInt(req.query.lines) || 50, 200);
    const result = pm2Health.getGatewayLogTail(lines);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// GET /api/openclaw/health/version — full version info including update availability (always fetches live)
router.get('/health/version', async (req, res) => {
  try {
    const info = await versionTracker.checkForUpdate();
    // Include upgradePolicy from launcher.json
    const launcherConfig = openclawConfig.readLauncherConfig();
    info.upgradePolicy = launcherConfig?.upgradePolicy || 'manual';
    res.json(info);
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// POST /api/openclaw/health/version/check — trigger an update check via npm registry
router.post('/health/version/check', async (req, res) => {
  try {
    const versionInfo = await versionTracker.checkForUpdate();
    res.json({ versionInfo });
  } catch (err) {
    res.status(500).json({ error: 'Update check failed', message: err.message });
  }
});

// GET /api/openclaw/version/persisted — persisted version for restore tooling
router.get('/version/persisted', (req, res) => {
  try {
    const info = versionTracker.getPersistedVersionInfo();
    res.json(info);
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// GET /api/openclaw/upgrade-policy — current upgrade policy from launcher.json
router.get('/upgrade-policy', (req, res) => {
  try {
    const launcherConfig = openclawConfig.readLauncherConfig();
    const upgradePolicy = launcherConfig?.upgradePolicy || 'manual';
    res.json({ upgradePolicy });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// PUT /api/openclaw/upgrade-policy — update upgrade policy in launcher.json
router.put('/upgrade-policy', (req, res) => {
  try {
    const { upgradePolicy } = req.body;
    if (!upgradePolicy) {
      return res.status(400).json({ error: 'Bad Request', message: 'upgradePolicy is required' });
    }
    if (!['manual', 'auto'].includes(upgradePolicy)) {
      return res.status(400).json({ error: 'Bad Request', message: 'upgradePolicy must be "manual" or "auto"' });
    }
    const launcherConfig = openclawConfig.readLauncherConfig() || {};
    launcherConfig.upgradePolicy = upgradePolicy;
    openclawConfig.writeLauncherConfig(launcherConfig);
    res.json({ upgradePolicy });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// GET /api/openclaw/admin/environment — get environment preset settings from launcher.json
router.get('/admin/environment', (req, res) => {
  try {
    const launcherConfig = openclawConfig.readLauncherConfig() || {};
    const env = launcherConfig.environment || {};
    res.json({
      stopAniCodeDaemon: env.stopAniCodeDaemon !== false, // default true
    });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// PUT /api/openclaw/admin/environment — update environment preset settings in launcher.json
router.put('/admin/environment', (req, res) => {
  try {
    const { stopAniCodeDaemon } = req.body;
    if (typeof stopAniCodeDaemon !== 'boolean') {
      return res.status(400).json({ error: 'Bad Request', message: 'stopAniCodeDaemon must be a boolean' });
    }
    const launcherConfig = openclawConfig.readLauncherConfig() || {};
    launcherConfig.environment = launcherConfig.environment || {};
    launcherConfig.environment.stopAniCodeDaemon = stopAniCodeDaemon;
    openclawConfig.writeLauncherConfig(launcherConfig);

    // Apply immediately: stop or restart the daemon based on the new setting
    try {
      const { execSync } = require('child_process');
      if (stopAniCodeDaemon) {
        execSync('pm2 stop ani-code-daemon 2>/dev/null || true', { encoding: 'utf-8', timeout: 10000 });
      } else {
        execSync('pm2 restart ani-code-daemon 2>/dev/null || true', { encoding: 'utf-8', timeout: 10000 });
      }
    } catch {}

    res.json({ stopAniCodeDaemon });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// PUT /api/openclaw/version/override — override .installed-version and set upgrade policy to manual
router.put('/version/override', (req, res) => {
  try {
    const { version } = req.body;
    if (!version || typeof version !== 'string') {
      return res.status(400).json({ error: 'Bad Request', message: 'version is required' });
    }
    // Validate version format (digits separated by dots)
    if (!/^\d+(\.\d+)*$/.test(version.trim())) {
      return res.status(400).json({ error: 'Bad Request', message: 'Invalid version format' });
    }
    // Write .installed-version file
    versionTracker.persistVersion(version.trim());
    // Set upgrade policy to manual
    const launcherConfig = openclawConfig.readLauncherConfig() || {};
    launcherConfig.upgradePolicy = 'manual';
    openclawConfig.writeLauncherConfig(launcherConfig);
    res.json({ version: version.trim(), upgradePolicy: 'manual' });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// POST /api/openclaw/gateway/auto-pair — approve all pending device pairing requests
router.post('/gateway/auto-pair', (req, res) => {
  // List pending devices, then approve each one
  execFile('openclaw', ['devices', 'list', '--json'], { timeout: 5000 }, (listErr, listStdout) => {
    let pending = [];
    try {
      const data = JSON.parse(listStdout || '{}');
      pending = data.pending || [];
    } catch {
      // If --json is not supported, fall back to parsing text output
    }

    if (pending.length === 0) {
      return res.json({ success: true, approved: 0, message: 'No pending pairing requests' });
    }

    let approved = 0;
    let errors = [];
    let completed = 0;

    for (const req_item of pending) {
      const requestId = req_item.requestId || req_item.id;
      if (!requestId) {
        completed++;
        if (completed === pending.length) {
          return res.json({ success: true, approved, errors });
        }
        continue;
      }

      execFile('openclaw', ['devices', 'approve', requestId], { timeout: 10000 }, (err, stdout, stderr) => {
        if (!err) {
          approved++;
        } else {
          errors.push({ requestId, error: (stderr || err.message).trim() });
        }
        completed++;
        if (completed === pending.length) {
          res.json({ success: true, approved, errors: errors.length ? errors : undefined });
        }
      });
    }
  });
});

// POST /api/openclaw/gateway/doctor-fix — run `openclaw doctor --fix` then restart gateway
router.post('/gateway/doctor-fix', (req, res) => {
  const stripAnsi = (str) => str.replace(/\x1B\[[0-9;]*[A-Za-z]/g, '');

  // If the gateway port is occupied by an unmanaged process, kill it first
  // so that doctor-fix + pm2 restart can reclaim the port.
  let killedUnmanagedPid = null;
  try {
    const config = openclawConfig.readConfig();
    const gwPort = config?.gateway?.port || 18789;
    const mgmt = pm2Health.checkGatewayManagement(gwPort);
    if (mgmt.unmanagedDaemon && mgmt.portPid && mgmt.isOpenclawProcess) {
      console.warn(`[Launcher API] doctor-fix: killing unmanaged openclaw-gateway process PID ${mgmt.portPid} on port ${gwPort} (cmd: ${mgmt.portProcessCmd})`);
      try {
        process.kill(mgmt.portPid, 'SIGTERM');
        require('child_process').execSync('sleep 1', { timeout: 3000 });
      } catch (killErr) {
        if (killErr.code !== 'ESRCH') {
          console.error(`[Launcher API] doctor-fix: failed to kill PID ${mgmt.portPid}:`, killErr.message);
        }
      }
      killedUnmanagedPid = mgmt.portPid;
    } else if (mgmt.unmanagedDaemon && mgmt.portPid && !mgmt.isOpenclawProcess) {
      console.warn(`[Launcher API] doctor-fix: port ${gwPort} occupied by non-openclaw process PID ${mgmt.portPid} (cmd: ${mgmt.portProcessCmd}) — skipping kill`);
    }
  } catch (mgmtErr) {
    console.error('[Launcher API] doctor-fix: management check error:', mgmtErr.message);
  }

  execFile('openclaw', ['doctor', '--fix', '--non-interactive'], { timeout: 30000 }, (err, stdout, stderr) => {
    const doctorOutput = stripAnsi((stdout || '') + (stderr || '')).trim();

    // After doctor --fix, restart the gateway
    try {
      const restartResult = pm2Health.restartGateway();
      const responseData = {
        success: true,
        doctorOutput,
        doctorOk: !err,
        gateway: restartResult,
      };
      if (killedUnmanagedPid) responseData.killedUnmanagedPid = killedUnmanagedPid;
      res.json(responseData);
    } catch (restartErr) {
      const responseData = {
        success: false,
        doctorOutput,
        doctorOk: !err,
        gateway: { success: false, error: restartErr.message },
      };
      if (killedUnmanagedPid) responseData.killedUnmanagedPid = killedUnmanagedPid;
      res.json(responseData);
    }
  });
});

// POST /api/openclaw/gateway/restart
router.post('/gateway/restart', (req, res) => {
  try {
    const result = pm2Health.restartGateway();
    if (result.success) {
      res.json(result);
    } else {
      res.status(500).json({ error: 'Restart Failed', message: result.error });
    }
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// POST /api/openclaw/launcher/restart — restart the launcher (pm2 restart web)
router.post('/launcher/restart', (req, res) => {
  try {
    const result = pm2Health.restartLauncher();
    if (result.success) {
      res.json({ success: true, message: 'Launcher restart initiated' });
    } else {
      res.status(500).json({ error: 'Restart Failed', message: result.error });
    }
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// POST /api/openclaw/gateway/control-ui-fix — fix control UI 404 caused by hardlink issues
// Copies control-ui files to /tmp and updates config to point there, then restarts gateway
router.post('/gateway/control-ui-fix', async (req, res) => {
  try {
    const config = openclawConfig.readConfig();
    const port = config?.gateway?.port || 18789;

    // Step 1: Verify gateway is running and returning 404
    const gatewayProcess = pm2Health.getOpenClawGatewayProcess();
    if (!gatewayProcess || gatewayProcess.status !== 'online') {
      return res.status(400).json({ error: 'Gateway Not Running', message: 'The openclaw-gateway process is not running. Start it first.' });
    }

    const probe = await pm2Health.probeGateway(port);
    if (!probe.reachable) {
      return res.status(400).json({ error: 'Gateway Unreachable', message: 'The gateway port is not reachable.' });
    }
    if (probe.statusCode !== 404) {
      return res.status(400).json({ error: 'Not a 404 Issue', message: `Gateway returned status ${probe.statusCode}, not 404. This fix only applies when the control UI returns 404.` });
    }

    // Step 2: Check source files exist
    const sourceIndex = '/opt/bun-global/node_modules/openclaw/dist/control-ui/index.html';
    if (!fs.existsSync(sourceIndex)) {
      return res.status(400).json({ error: 'Source Not Found', message: 'Control UI source files not found at /opt/bun-global/node_modules/openclaw/dist/control-ui/. Cannot apply fix.' });
    }

    // Step 3: Copy files to /tmp/control-ui
    const tmpDir = '/tmp/control-ui';
    try {
      execFileSync('rm', ['-rf', tmpDir], { timeout: 5000 });
      execFileSync('mkdir', ['-p', tmpDir], { timeout: 5000 });
      execFileSync('cp', ['-rf', '/opt/bun-global/node_modules/openclaw/dist/control-ui/.', tmpDir + '/'], { timeout: 10000 });
    } catch (copyErr) {
      return res.status(500).json({ error: 'Copy Failed', message: `Failed to copy control-ui files: ${copyErr.message}` });
    }

    // Verify copy succeeded
    if (!fs.existsSync(path.join(tmpDir, 'index.html'))) {
      return res.status(500).json({ error: 'Copy Verification Failed', message: 'Files were copied but index.html was not found in /tmp/control-ui/.' });
    }

    // Step 4: Update config with controlUi.root
    if (!config) {
      return res.status(400).json({ error: 'No Config', message: 'Cannot read openclaw.json config.' });
    }
    config.gateway = config.gateway || {};
    config.gateway.controlUi = config.gateway.controlUi || {};
    config.gateway.controlUi.root = tmpDir;
    openclawConfig.writeConfig(config);

    // Step 5: Restart gateway and poll for success
    const restartResult = pm2Health.restartGateway();
    if (!restartResult.success) {
      return res.status(500).json({ error: 'Restart Failed', message: restartResult.error, configUpdated: true });
    }

    // Poll every 5 seconds for up to 30 seconds
    let fixed = false;
    for (let attempt = 0; attempt < 6; attempt++) {
      await new Promise(r => setTimeout(r, 5000));
      const check = await pm2Health.probeGateway(port);
      if (check.reachable && check.statusCode === 200) {
        fixed = true;
        break;
      }
    }

    res.json({
      success: fixed,
      configUpdated: true,
      controlUiRoot: tmpDir,
      message: fixed
        ? 'Control UI fix applied successfully. The gateway is now serving the control UI.'
        : 'Config updated and gateway restarted, but the control UI is not yet returning 200. It may need more time to start.',
    });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// GET /api/openclaw/gateway/control-ui-check — check if control UI has loading issue (eligible for fix)
// Also detects stale tmp root from a previous fix whose files have been cleaned up
router.get('/gateway/control-ui-check', async (req, res) => {
  try {
    const config = openclawConfig.readConfig();
    const port = config?.gateway?.port || 18789;

    // Check if config points to a tmp-based controlUi.root
    const controlUiRoot = config?.gateway?.controlUi?.root;
    if (controlUiRoot && controlUiRoot.startsWith('/tmp/')) {
      const indexPath = path.join(controlUiRoot, 'index.html');
      if (!fs.existsSync(indexPath)) {
        // Tmp files cleaned up (e.g. after reboot) — stale fix
        return res.json({ status: 'stale_tmp', eligible: true, controlUiRoot });
      }
      // Tmp fix is active and files exist — report as active
      return res.json({ status: 'active_tmp', eligible: false, controlUiRoot });
    }

    const gatewayProcess = pm2Health.getOpenClawGatewayProcess();
    if (!gatewayProcess || gatewayProcess.status !== 'online') {
      return res.json({ status: 'gateway_offline', eligible: false });
    }

    const probe = await pm2Health.probeGateway(port);
    if (!probe.reachable) {
      return res.json({ status: 'unreachable', eligible: false });
    }

    if (probe.statusCode === 404 || probe.statusCode === 503) {
      const sourceExists = fs.existsSync('/opt/bun-global/node_modules/openclaw/dist/control-ui/index.html');
      return res.json({ status: 'error_page', statusCode: probe.statusCode, eligible: sourceExists, sourceExists });
    }

    return res.json({ status: 'ok', statusCode: probe.statusCode, eligible: false });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// POST /api/openclaw/gateway/control-ui-restore — remove the controlUi.root override and restart gateway
// Used when a previous tmp fix has expired and the user wants to test if the issue is resolved natively
router.post('/gateway/control-ui-restore', async (req, res) => {
  try {
    const config = openclawConfig.readConfig();
    if (!config) {
      return res.status(400).json({ error: 'No Config', message: 'Cannot read openclaw.json config.' });
    }

    const controlUiRoot = config?.gateway?.controlUi?.root;
    if (!controlUiRoot) {
      return res.status(400).json({ error: 'Nothing to Restore', message: 'Config does not have a controlUi.root override.' });
    }

    // Remove the controlUi.root (and controlUi section if empty)
    delete config.gateway.controlUi.root;
    if (Object.keys(config.gateway.controlUi).length === 0) {
      delete config.gateway.controlUi;
    }
    openclawConfig.writeConfig(config);

    // Restart gateway
    const restartResult = pm2Health.restartGateway();
    if (!restartResult.success) {
      return res.status(500).json({ error: 'Restart Failed', message: restartResult.error, configUpdated: true });
    }

    // Poll for gateway to come back up
    const port = config?.gateway?.port || 18789;
    let ready = false;
    for (let attempt = 0; attempt < 6; attempt++) {
      await new Promise(r => setTimeout(r, 5000));
      const check = await pm2Health.probeGateway(port);
      if (check.reachable) {
        ready = true;
        break;
      }
    }

    res.json({
      success: ready,
      configUpdated: true,
      message: ready
        ? 'Config restored and gateway restarted successfully.'
        : 'Config restored and gateway restarted, but it may need more time to come online.',
    });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// ==========================================
// Workspace Content Browser (Tasks 16-18)
// ==========================================

// GET /api/openclaw/workspace/identity — read and parse IDENTITY.md from workspace
router.get('/workspace/identity', (req, res) => {
  try {
    const file = workspaceBrowser.readWorkspaceFile('IDENTITY.md', 'workspace');
    // Parse markdown fields: "- Name: ...", "- Emoji: ...", etc.
    // Strip content after --- separator to ignore template notes
    const rawContent = file.content || '';
    const content = rawContent.split(/^---$/m)[0];
    const parse = (key, maxLen = 80) => {
      const m = content.match(new RegExp(`^-\\s*\\**${key}:\\**\\s*(.+)`, 'mi'));
      if (!m) return null;
      let val = m[1].trim();
      // Reject template hints — values that are just parenthetical placeholders like "(pick something you like)"
      if (/^\(.*\)$/.test(val)) return null;
      if (/pick\s+something/i.test(val)) return null;
      // Truncate overly long values
      if (val.length > maxLen) val = val.slice(0, maxLen);
      return val;
    };
    const parseDisplay = (key, maxLen = 80) => {
      const val = parse(key, maxLen);
      if (!val) return null;
      // Strip parenthetical suffixes (e.g. "小狗狗 (Xiao Gou Gou)" → "小狗狗")
      const cleaned = val.replace(/\s*\([^)]*\)\s*$/, '').trim();
      if (!cleaned) return null;
      return cleaned.length > maxLen ? cleaned.slice(0, maxLen) : cleaned;
    };
    const parseEmoji = () => {
      const val = parseDisplay('Emoji', 10);
      if (!val) return null;
      // Reject emoji text longer than 2 characters (allows single emoji including multi-byte)
      if ([...val].length > 2) return null;
      return val;
    };
    res.json({
      found: true,
      name: parseDisplay('Name', 40),
      creature: parse('Creature'),
      vibe: parse('Vibe'),
      emoji: parseEmoji(),
      avatar: parse('Avatar'),
      raw: rawContent,
    });
  } catch (err) {
    if (err.message.includes('not found')) {
      return res.json({ found: false });
    }
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// GET /api/openclaw/workspace/tree
router.get('/workspace/tree', (req, res) => {
  try {
    const { root } = req.query;
    const tree = workspaceBrowser.getWorkspaceTree(root);
    res.json(tree);
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// GET /api/openclaw/workspace/file — enhanced with MIME info and preview detection
router.get('/workspace/file', (req, res) => {
  try {
    const { path: filePath, root } = req.query;
    if (!filePath) {
      return res.status(400).json({ error: 'Bad Request', message: 'path query parameter is required' });
    }

    const rootDir = workspaceBrowser.resolveRoot(root);
    const mimeInfo = workspaceBrowser.getFileMimeInfo(filePath);

    // For non-previewable files, return metadata only (no content)
    if (!mimeInfo.isPreviewable) {
      const cleaned = require('path').normalize(filePath).replace(/^(\.\.(\/|\\|$))+/, '');
      const fullPath = require('path').resolve(rootDir, cleaned);
      if (!fullPath.startsWith(rootDir)) {
        return res.status(403).json({ error: 'Forbidden', message: 'Path traversal detected: access denied' });
      }
      const fs = require('fs');
      if (!fs.existsSync(fullPath)) {
        return res.status(404).json({ error: 'Not Found', message: 'File not found' });
      }
      const stat = fs.statSync(fullPath);
      return res.json({
        name: require('path').basename(fullPath),
        path: cleaned,
        size: stat.size,
        modified: stat.mtime.toISOString(),
        extension: require('path').extname(fullPath).toLowerCase(),
        isMarkdown: false,
        content: null,
        mimeType: mimeInfo.mimeType,
        isPreviewable: false,
        reason: 'binary',
      });
    }

    // For previewable files that exceed size limit, return metadata only
    try {
      const file = workspaceBrowser.readWorkspaceFile(filePath, root);
      res.json({
        ...file,
        mimeType: mimeInfo.mimeType,
        isPreviewable: true,
      });
    } catch (sizeErr) {
      if (sizeErr.message.includes('too large')) {
        const cleaned = require('path').normalize(filePath).replace(/^(\.\.(\/|\\|$))+/, '');
        const fullPath = require('path').resolve(rootDir, cleaned);
        const fs = require('fs');
        const stat = fs.statSync(fullPath);
        return res.json({
          name: require('path').basename(fullPath),
          path: cleaned,
          size: stat.size,
          modified: stat.mtime.toISOString(),
          extension: require('path').extname(fullPath).toLowerCase(),
          isMarkdown: require('path').extname(fullPath).toLowerCase() === '.md',
          content: null,
          mimeType: mimeInfo.mimeType,
          isPreviewable: false,
          reason: 'too_large',
        });
      }
      throw sizeErr;
    }
  } catch (err) {
    const status = err.message.includes('traversal') ? 403
      : err.message.includes('not found') ? 404
      : err.message.includes('too large') ? 413
      : 500;
    res.status(status).json({ error: 'Error', message: err.message });
  }
});

// GET /api/openclaw/workspace/download — download a file as attachment
router.get('/workspace/download', (req, res) => {
  try {
    const { path: filePath, root } = req.query;
    if (!filePath) {
      return res.status(400).json({ error: 'Bad Request', message: 'path query parameter is required' });
    }

    const file = workspaceBrowser.readWorkspaceFile(filePath, root);
    res.setHeader('Content-Disposition', `attachment; filename="${file.name}"`);
    res.setHeader('Content-Type', 'application/octet-stream');
    res.send(file.content);
  } catch (err) {
    const status = err.message.includes('traversal') ? 403
      : err.message.includes('not found') ? 404
      : err.message.includes('too large') ? 413
      : 500;
    res.status(status).json({ error: 'Error', message: err.message });
  }
});

// GET /api/openclaw/workspace/preview — serve HTML files for iframe preview
router.get('/workspace/preview', (req, res) => {
  try {
    const { path: filePath, root } = req.query;
    if (!filePath) {
      return res.status(400).json({ error: 'Bad Request', message: 'path query parameter is required' });
    }

    const file = workspaceBrowser.readWorkspaceFile(filePath, root);
    if (!/\.html?$/i.test(file.name)) {
      return res.status(400).json({ error: 'Bad Request', message: 'Only HTML files can be previewed' });
    }

    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.send(file.content);
  } catch (err) {
    const status = err.message.includes('traversal') ? 403
      : err.message.includes('not found') ? 404
      : err.message.includes('too large') ? 413
      : 500;
    res.status(status).json({ error: 'Error', message: err.message });
  }
});

// POST /api/openclaw/workspace/upload — multipart file upload with MD5 verification
router.post('/workspace/upload', upload.array('files[]', 20), (req, res) => {
  try {
    const files = req.files;
    if (!files || files.length === 0) {
      return res.status(400).json({ error: 'Bad Request', message: 'No files provided' });
    }

    const targetDir = req.body.targetDir || '';
    const root = req.body.root || 'workspace';
    const rootDir = workspaceBrowser.resolveRoot(root);
    const results = [];

    for (const file of files) {
      try {
        // Compute MD5 of the received buffer
        const receivedMd5 = crypto.createHash('md5').update(file.buffer).digest('hex');

        // Build relative path: targetDir/filename
        const relativePath = targetDir ? `${targetDir}/${file.originalname}` : file.originalname;

        // Save file atomically
        const saved = workspaceBrowser.saveUploadedFile(relativePath, file.buffer, root);

        // Verify MD5 integrity
        if (saved.md5 !== receivedMd5) {
          // Mismatch — delete the file
          const fullPath = require('path').resolve(rootDir, saved.path);
          require('fs').unlinkSync(fullPath);
          results.push({
            name: file.originalname,
            path: relativePath,
            size: file.size,
            md5: null,
            status: 'error',
            message: 'MD5 integrity check failed',
          });
          continue;
        }

        results.push({
          name: saved.name,
          path: saved.path,
          size: saved.size,
          md5: saved.md5,
          status: 'ok',
        });
      } catch (fileErr) {
        results.push({
          name: file.originalname,
          path: null,
          size: file.size,
          md5: null,
          status: 'error',
          message: fileErr.message,
        });
      }
    }

    res.json(results);
  } catch (err) {
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(413).json({ error: 'Payload Too Large', message: 'File exceeds 10MB size limit' });
    }
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// DELETE /api/openclaw/workspace/delete — delete a file or folder
router.delete('/workspace/delete', (req, res) => {
  try {
    const { path: itemPath, root } = req.query;
    if (!itemPath) {
      return res.status(400).json({ error: 'Bad Request', message: 'path query parameter is required' });
    }
    const result = workspaceBrowser.deleteWorkspaceItem(itemPath, root);
    res.json({ success: true, message: `Deleted ${result.type}: ${result.name}`, ...result });
  } catch (err) {
    const status = err.message.includes('traversal') ? 403
      : err.message.includes('not found') || err.message.includes('Not found') ? 404
      : err.message.includes('Cannot delete') ? 403
      : 500;
    res.status(status).json({ error: 'Error', message: err.message });
  }
});

// Multer error handling for the upload route
router.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(413).json({ error: 'Payload Too Large', message: 'File exceeds 10MB size limit' });
    }
    return res.status(400).json({ error: 'Upload Error', message: err.message });
  }
  next(err);
});

// ==========================================
// Agent Test — direct API call to configured model provider
// ==========================================

// POST /api/openclaw/health/agent-test — make a real API call to the default model provider
router.post('/health/agent-test', async (req, res) => {
  try {
    const config = openclawConfig.readConfig();
    if (!config) {
      return res.json({ ok: false, error: 'No openclaw.json config found' });
    }

    // Resolve default model: "provider/model-id"
    const primaryModel = config.agents?.defaults?.model?.primary;
    if (!primaryModel) {
      return res.json({ ok: false, error: 'No default model configured (agents.defaults.model.primary)' });
    }

    let providerName, modelId;
    const slashIdx = primaryModel.indexOf('/');
    if (slashIdx === -1) {
      // Legacy unprefixed model — find which provider has this model
      const providers = config.models?.providers || {};
      const match = Object.entries(providers).find(([, p]) =>
        (p.models || []).some(m => (typeof m === 'string' ? m : m.id) === primaryModel)
      );
      if (!match) {
        // Model not in any provider's list — use the first configured provider as fallback
        const providerNames = Object.keys(providers);
        if (providerNames.length === 0) {
          return res.json({ ok: false, error: `Cannot resolve provider for model "${primaryModel}". No providers configured.` });
        }
        providerName = providerNames[0];
      } else {
        providerName = match[0];
      }
      modelId = primaryModel;
    } else {
      providerName = primaryModel.slice(0, slashIdx);
      modelId = primaryModel.slice(slashIdx + 1);
    }
    const provider = config.models?.providers?.[providerName];

    if (!provider) {
      return res.json({ ok: false, error: `Provider "${providerName}" not found in config` });
    }
    if (!provider.baseUrl) {
      return res.json({ ok: false, error: `Provider "${providerName}" has no baseUrl` });
    }

    const apiKey = resolveProviderApiKey(providerName, provider);
    if (!apiKey) {
      return res.json({ ok: false, error: `No API key found for provider "${providerName}". Check credentials configuration.` });
    }

    return doApiTest(provider, providerName, modelId, apiKey, res);
  } catch (err) {
    res.json({ ok: false, error: err.message });
  }
});

function doApiTest(provider, providerName, modelId, apiKey, res) {
  const startMs = Date.now();
  const apiFormat = provider.api || 'openai-completions';
  const testPrompt = 'Say OK';

  let url, body, headers;

  if (apiFormat === 'anthropic-messages') {
    url = provider.baseUrl.replace(/\/+$/, '') + '/v1/messages';
    headers = {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    };
    body = JSON.stringify({
      model: modelId,
      max_tokens: 32,
      messages: [{ role: 'user', content: testPrompt }],
    });
  } else if (apiFormat === 'google-generative-ai') {
    url = `${provider.baseUrl.replace(/\/+$/, '')}/models/${modelId}:generateContent?key=${apiKey}`;
    headers = { 'Content-Type': 'application/json' };
    body = JSON.stringify({
      contents: [{ parts: [{ text: testPrompt }] }],
      generationConfig: { maxOutputTokens: 32 },
    });
  } else {
    // openai-completions (default)
    url = provider.baseUrl.replace(/\/+$/, '') + '/chat/completions';
    headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
    };
    body = JSON.stringify({
      model: modelId,
      max_tokens: 32,
      messages: [{ role: 'user', content: testPrompt }],
    });
  }

  const parsedUrl = new URL(url);
  const mod = parsedUrl.protocol === 'https:' ? https : http;

  const allHeaders = { ...headers, 'Content-Length': Buffer.byteLength(body) };

  const reqOptions = {
    method: 'POST',
    hostname: parsedUrl.hostname,
    port: parsedUrl.port || (parsedUrl.protocol === 'https:' ? 443 : 80),
    path: parsedUrl.pathname + parsedUrl.search,
    headers: allHeaders,
    timeout: 30000,
  };

  const apiReq = mod.request(reqOptions, (apiRes) => {
    let data = '';
    apiRes.on('data', (chunk) => { data += chunk; });
    apiRes.on('end', () => {
      const durationMs = Date.now() - startMs;

      if (apiRes.statusCode >= 400) {
        let errMsg = `HTTP ${apiRes.statusCode}`;
        try {
          const errBody = JSON.parse(data);
          errMsg += ': ' + (errBody.error?.message || errBody.error?.type || JSON.stringify(errBody.error) || data.slice(0, 200));
        } catch {
          errMsg += ': ' + data.slice(0, 200);
        }
        return res.json({
          ok: false, error: errMsg, provider: providerName, model: modelId, durationMs,
          debug: {
            requestUrl: url,
            requestHeaders: allHeaders,
            requestBody: JSON.parse(body),
            responseStatus: apiRes.statusCode,
            responseBody: data.slice(0, 2000),
          },
        });
      }

      // Extract response text
      let responseText = '';
      try {
        const parsed = JSON.parse(data);
        if (apiFormat === 'anthropic-messages') {
          responseText = (parsed.content || []).map(c => c.text).join('').trim();
        } else if (apiFormat === 'google-generative-ai') {
          responseText = (parsed.candidates?.[0]?.content?.parts || []).map(p => p.text).join('').trim();
        } else {
          responseText = parsed.choices?.[0]?.message?.content?.trim() || '';
        }
      } catch {
        responseText = data.slice(0, 200);
      }

      res.json({
        ok: true,
        response: responseText,
        provider: providerName,
        model: modelId,
        durationMs,
        debug: {
          requestUrl: url,
          requestHeaders: allHeaders,
          requestBody: JSON.parse(body),
          responseStatus: apiRes.statusCode,
          responseBody: data.slice(0, 2000),
        },
      });
    });
  });

  apiReq.on('error', (err) => {
    const durationMs = Date.now() - startMs;
    res.json({
      ok: false, error: `Connection error: ${err.message}`, provider: providerName, model: modelId, durationMs,
      debug: {
        requestUrl: url,
        requestHeaders: allHeaders,
        requestBody: JSON.parse(body),
      },
    });
  });

  apiReq.on('timeout', () => {
    apiReq.destroy();
    const durationMs = Date.now() - startMs;
    res.json({
      ok: false, error: 'Request timed out (30s)', provider: providerName, model: modelId, durationMs,
      debug: {
        requestUrl: url,
        requestHeaders: allHeaders,
        requestBody: JSON.parse(body),
      },
    });
  });

  apiReq.write(body);
  apiReq.end();
}

// ==========================================
// Doctor / Config Validation
// ==========================================

// GET /api/openclaw/doctor
router.get('/doctor', (req, res) => {
  const stripAnsi = (str) => str.replace(/\x1B\[[0-9;]*[A-Za-z]/g, '');

  execFile('openclaw', ['doctor', '--non-interactive'], { timeout: 5000 }, (err, stdout, stderr) => {
    const raw = stripAnsi((stdout || '') + (stderr || ''));

    // Parse sections by detecting `◇  Title ─` delimiters
    const sections = [];
    const lines = raw.split('\n');
    let currentSection = null;

    for (const line of lines) {
      const match = line.match(/^◇\s+(.+?)\s*─/);
      if (match) {
        if (currentSection) sections.push(currentSection);
        currentSection = { title: match[1].trim(), content: '' };
      } else if (currentSection) {
        currentSection.content += line + '\n';
      }
    }
    if (currentSection) sections.push(currentSection);

    // Trim trailing whitespace from each section's content
    for (const s of sections) {
      s.content = s.content.trimEnd();
    }

    if (err && !raw) {
      return res.status(500).json({ ok: false, error: err.message, raw: '', sections: [] });
    }

    res.json({ ok: !err, sections, raw });
  });
});

// ==========================================
// Managed Pool (Launcher-facing) — Task 22
// ==========================================
const instanceControl = require('../services/instance-control');
const marketplace = require('../services/marketplace');

/**
 * Auto-configure launcher-cli tool after install.
 * Generates a long-lived JWT token and writes it to the CLI config.
 */
function autoConfigureLauncherCli() {
  try {
    const toolConfigPath = path.join(os.homedir(), '.openclaw', 'tools', 'launcher-cli', 'config.json');
    if (!fs.existsSync(path.dirname(toolConfigPath))) return;

    // Generate a long-lived CLI token (90 days)
    const token = signToken({ type: 'cli-tool' }, '90d');
    if (!token) {
      console.warn('[Marketplace] Could not generate CLI token — launcher password may not be set');
      return;
    }

    let config = {};
    try {
      config = JSON.parse(fs.readFileSync(toolConfigPath, 'utf-8'));
    } catch { /* fresh config */ }

    config.url = config.url || 'http://localhost:3000';
    config.token = token;
    fs.writeFileSync(toolConfigPath, JSON.stringify(config, null, 2), { mode: 0o600 });
    console.log('[Marketplace] Auto-configured launcher-cli with fresh auth token');
  } catch (err) {
    console.warn('[Marketplace] Failed to auto-configure launcher-cli:', err.message);
  }
}

// POST /api/openclaw/admin/enable — generate keys, enable managed pool
router.post('/admin/enable', (req, res) => {
  try {
    const result = instanceControl.enableAdoption();
    const pool = result.managedPool;
    res.json({
      enabled: true,
      alreadyEnabled: result.alreadyEnabled,
      instanceId: pool.instanceId,
      controlKey: pool.controlKey,
      adoptionToken: pool.adoptionToken,
      status: pool.status,
    });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// POST /api/openclaw/admin/disable — revoke adoption, clear keys
router.post('/admin/disable', (req, res) => {
  try {
    instanceControl.disableAdoption();
    res.json({ enabled: false });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// POST /api/openclaw/admin/reset — reset adoption state, generate fresh token
router.post('/admin/reset', (req, res) => {
  try {
    const info = instanceControl.resetAdoption();
    const pool = instanceControl.getManagedPoolConfig();
    res.json({
      success: true,
      message: 'Adoption reset — instance is ready for re-adoption',
      adoptionToken: pool.adoptionToken,
      ...info,
    });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// GET /api/openclaw/admin/status — get current managed pool state
router.get('/admin/status', async (req, res) => {
  try {
    const info = await instanceControl.getAdoptionInfo({ includeHealth: true });
    res.json(info);
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// POST /api/openclaw/admin/adoption-url — retrieve adoption URL components when enabled but not consumed
router.post('/admin/adoption-url', async (req, res) => {
  try {
    const info = await instanceControl.getAdoptionInfo();
    if (!info.enabled) {
      return res.status(400).json({ error: 'Bad Request', message: 'Managed pool is not enabled' });
    }
    if (info.isAdopted || !info.hasAdoptionToken) {
      return res.status(400).json({ error: 'Bad Request', message: 'Adoption token has already been consumed' });
    }
    const pool = instanceControl.getManagedPoolConfig();
    res.json({
      adoptionToken: pool.adoptionToken,
      controlKey: pool.controlKey,
      instanceId: pool.instanceId,
    });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// POST /api/openclaw/admin/clear-failures — reset failure tracking data
router.post('/admin/clear-failures', (req, res) => {
  try {
    instanceControl.clearFailures();
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// ==========================================
// Admin — Backup & Data Management
// ==========================================

const OPENCLAW_DIR = path.join(os.homedir(), '.openclaw');

// GET /api/openclaw/admin/backup — download ~/.openclaw as a base64-encoded JSON response
router.get('/admin/backup', async (req, res) => {
  console.log('[admin] backup requested, auth user:', req.launcherUser);

  if (!fs.existsSync(OPENCLAW_DIR)) {
    console.log('[admin] backup: .openclaw directory not found');
    return res.status(404).json({ error: 'Not Found', message: 'No .openclaw directory found' });
  }

  const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const filename = `openclaw-backup-${timestamp}.tar.gz`;

  // Resolve OPENCLAW_DIR to its real path in case it's a symlink
  const realDir = fs.realpathSync(OPENCLAW_DIR);
  const dirName = path.basename(realDir);
  const parentDir = path.dirname(realDir);

  console.log('[admin] backup: realDir=', realDir, 'dirName=', dirName, 'parentDir=', parentDir);

  try {
    // Create tar archive to a temporary buffer
    const tar = spawn('tar', ['czf', '-', '-C', parentDir, dirName]);
    console.log('[admin] backup: tar spawned, pid:', tar.pid);

    const chunks = [];
    let totalSize = 0;

    // Collect all tar output
    tar.stdout.on('data', (chunk) => {
      chunks.push(chunk);
      totalSize += chunk.length;
    });

    // Handle errors
    tar.stderr.on('data', (data) => {
      console.error('[admin] backup tar stderr:', data.toString());
    });

    // Wait for tar to complete
    await new Promise((resolve, reject) => {
      tar.on('error', reject);
      tar.on('close', (code) => {
        if (code !== 0) {
          reject(new Error(`tar exited with code ${code}`));
        } else {
          resolve();
        }
      });
    });

    // Combine chunks and convert to base64
    const buffer = Buffer.concat(chunks);
    console.log('[admin] backup: tar completed, size:', buffer.length, 'bytes');

    // Convert to base64
    const base64Data = buffer.toString('base64');

    // Send as JSON response
    res.json({
      success: true,
      filename,
      size: buffer.length,
      data: base64Data,
      mimeType: 'application/gzip',
    });
    console.log('[admin] backup: sent', base64Data.length, 'bytes of base64 data');

  } catch (err) {
    console.error('[admin] backup error:', err.message);
    res.status(500).json({ error: 'Backup Failed', message: err.message });
  }
});

// POST /api/openclaw/admin/delete-data — permanently delete ~/.openclaw
router.post('/admin/delete-data', (req, res) => {
  try {
    if (!fs.existsSync(OPENCLAW_DIR)) {
      return res.status(404).json({ error: 'Not Found', message: 'No .openclaw directory found' });
    }

    // Stop the gateway process first
    try {
      execFileSync('pm2', ['stop', 'openclaw-gateway'], { timeout: 5000 });
    } catch {
      // Gateway may not be running — continue with deletion
    }

    // Delete contents inside ~/.openclaw/ but preserve the directory itself
    // (it may be a symlink that we don't want to destroy)
    const entries = fs.readdirSync(OPENCLAW_DIR);
    for (const entry of entries) {
      const fullPath = path.join(OPENCLAW_DIR, entry);
      try {
        fs.rmSync(fullPath, { recursive: true, force: true });
      } catch (rmErr) {
        console.error(`[admin] Failed to remove ${fullPath}:`, rmErr.message);
      }
    }

    // Re-create launcher password and init flag so the login screen appears
    const newPassword = openclawConfig.generateLauncherPassword();
    openclawConfig.setLauncherPassword(newPassword);
    openclawConfig.createInitFlag();

    res.json({ success: true, message: 'All OpenClaw data has been deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// ==========================================
// Marketplace — Skill & MCP Installer
// ==========================================

// Marketplace feature gate — requires ENABLE_MARKETPLACE env var or enableMarketplace in launcher.json
function requireMarketplace(req, res, next) {
  const envEnabled = process.env.ENABLE_MARKETPLACE === '1' || process.env.ENABLE_MARKETPLACE === 'true';
  const launcherEnabled = !!(openclawConfig.readLauncherConfig() || {}).enableMarketplace;
  if (!envEnabled && !launcherEnabled) {
    return res.status(404).json({ error: 'Not Found', message: 'Marketplace is not enabled' });
  }
  next();
}

// GET /api/openclaw/marketplace/catalog
router.get('/marketplace/catalog', requireMarketplace, (req, res) => {
  try {
    const catalog = marketplace.getCatalog();
    res.json({ items: catalog });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// GET /api/openclaw/marketplace/preview?itemId=...
router.get('/marketplace/preview', requireMarketplace, (req, res) => {
  try {
    const { itemId } = req.query;
    if (!itemId) {
      return res.status(400).json({ error: 'Bad Request', message: 'itemId query parameter is required' });
    }

    const item = marketplace.findItem(itemId);
    if (!item) {
      return res.status(404).json({ error: 'Not Found', message: `Unknown marketplace item: ${itemId}` });
    }

    const manifest = item.manifest || {};

    // For exec type, synthesize a preview from the command manifest
    if (item.type === 'exec') {
      const command = manifest.command || '';
      const args = Array.isArray(manifest.args) ? manifest.args : [];
      const timeout = manifest.timeout ? `${Math.round(manifest.timeout / 1000)}s` : '300s';
      const cwd = manifest.cwd || '(workspace)';
      const lines = [
        `# ${item.name}`,
        '',
        item.description || '',
        '',
        '## Command',
        '',
        '```',
        `${command} ${args.join(' ')}`.trim(),
        '```',
        '',
        `**Working directory:** \`${cwd}\``,
        `**Timeout:** ${timeout}`,
      ];
      if (manifest.overrides && manifest.overrides.config) {
        lines.push('', '## Config Overrides', '', '```json', JSON.stringify(manifest.overrides.config, null, 2), '```');
      }
      return res.json({ id: item.id, name: item.name, skillDir: null, content: lines.join('\n'), tree: null, fileCount: 0, itemType: 'exec' });
    }

    // Resolve files (handles both inline-content objects and sourcePath-based builtins)
    const files = marketplace.resolvePreviewFiles(item);

    // Build file tree for multi-file items
    let tree = null;
    if (files.length > 1) {
      tree = [];
      const dirMap = {};
      for (const file of files) {
        const parts = file.path.split('/');
        if (parts.length === 1) {
          tree.push({ name: parts[0], type: 'file', path: file.path });
        } else {
          let current = tree;
          let currentMap = dirMap;
          for (let i = 0; i < parts.length - 1; i++) {
            const dirName = parts[i];
            if (!currentMap[dirName]) {
              const dirNode = { name: dirName, type: 'directory', path: parts.slice(0, i + 1).join('/'), children: [] };
              current.push(dirNode);
              currentMap[dirName] = { node: dirNode, children: {} };
            }
            current = currentMap[dirName].node.children;
            currentMap = currentMap[dirName].children;
          }
          current.push({ name: parts[parts.length - 1], type: 'file', path: file.path });
        }
      }
    }

    const content = files.length > 0 && files[0].content ? files[0].content : '';
    res.json({ id: item.id, name: item.name, skillDir: item.skillDir || null, content, tree, fileCount: files.length, itemType: item.type });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// GET /api/openclaw/marketplace/preview/file?itemId=...&path=...
router.get('/marketplace/preview/file', requireMarketplace, (req, res) => {
  try {
    const { itemId, path: filePath } = req.query;
    if (!itemId || !filePath) {
      return res.status(400).json({ error: 'Bad Request', message: 'itemId and path query parameters are required' });
    }

    const item = marketplace.findItem(itemId);
    if (!item) {
      return res.status(404).json({ error: 'Not Found', message: `Unknown marketplace item: ${itemId}` });
    }

    // Resolve files (handles both inline-content objects and sourcePath-based builtins)
    const files = marketplace.resolvePreviewFiles(item);
    const file = files.find(f => f.path === filePath);
    if (!file) {
      return res.status(404).json({ error: 'Not Found', message: 'File not found in manifest' });
    }

    const ext = filePath.includes('.') ? '.' + filePath.split('.').pop().toLowerCase() : '';
    res.json({
      name: filePath.split('/').pop(),
      path: filePath,
      size: file.content ? file.content.length : 0,
      extension: ext,
      isMarkdown: ext === '.md',
      content: file.content || '',
    });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// POST /api/openclaw/marketplace/install
router.post('/marketplace/install', requireMarketplace, (req, res) => {
  try {
    const { itemId } = req.body;
    if (!itemId) {
      return res.status(400).json({ error: 'Bad Request', message: 'itemId is required' });
    }

    // Search both bundled and external catalogs
    const catalog = marketplace.getCatalog();
    const catalogItem = catalog.find(i => i.id === itemId);
    if (!catalogItem) {
      return res.status(404).json({ error: 'Not Found', message: `Unknown marketplace item: ${itemId}` });
    }

    const status = marketplace.getItemStatus(itemId);
    if (status && status.installed && !status.updateAvailable && status.status !== 'broken') {
      return res.status(409).json({ error: 'Conflict', message: `Item "${catalogItem.name}" is already installed` });
    }

    // For updates or broken installs, clean up existing files first
    if (status && (status.updateAvailable || status.status === 'broken')) {
      try { marketplace.uninstallItem(itemId); } catch {}
    }

    const result = marketplace.installItem(itemId);

    // If prerequisites are unmet, return HTTP 202 with action details
    if (result.requiresAction) {
      return res.status(202).json({ success: true, message: 'Prerequisites required', ...result });
    }

    // Auto-configure launcher-cli after install (itself or as a dependency)
    const installedIds = [itemId, ...(result.installedDeps || []).map(d => d.id)];
    if (installedIds.includes('openclaw-launcher-cli')) {
      autoConfigureLauncherCli();
    }

    const action = status && status.updateAvailable ? 'updated' : 'installed';
    const depNames = (result.installedDeps || []).map(d => d.name);
    const depMsg = depNames.length > 0 ? ` (also installed: ${depNames.join(', ')})` : '';
    res.json({ success: true, message: `${catalogItem.name} ${action}${depMsg}`, ...result });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// POST /api/openclaw/marketplace/acknowledge — acknowledge a prerequisite for an item
router.post('/marketplace/acknowledge', requireMarketplace, (req, res) => {
  try {
    const { itemId, prerequisiteId } = req.body;
    if (!itemId || !prerequisiteId) {
      return res.status(400).json({ error: 'Bad Request', message: 'itemId and prerequisiteId are required' });
    }

    const result = marketplace.acknowledgePrerequisite(itemId, prerequisiteId);
    res.json({ success: true, ...result });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// POST /api/openclaw/marketplace/uninstall
router.post('/marketplace/uninstall', requireMarketplace, (req, res) => {
  try {
    const { itemId } = req.body;
    if (!itemId) {
      return res.status(400).json({ error: 'Bad Request', message: 'itemId is required' });
    }

    // Search both bundled and external catalogs
    const catalog = marketplace.getCatalog();
    const catalogItem = catalog.find(i => i.id === itemId);
    if (!catalogItem) {
      return res.status(404).json({ error: 'Not Found', message: `Unknown marketplace item: ${itemId}` });
    }

    const status = marketplace.getItemStatus(itemId);
    if (!status || (!status.installed && status.status !== 'broken')) {
      return res.status(409).json({ error: 'Conflict', message: `Item "${catalogItem.name}" is not installed` });
    }

    const result = marketplace.uninstallItem(itemId);
    res.json({ success: true, message: `${catalogItem.name} uninstalled`, ...result });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// POST /api/openclaw/marketplace/reset-catalog — wipe all external catalog items, keep only installed & builtins
router.post('/marketplace/reset-catalog', (req, res) => {
  try {
    const installRecords = marketplace.getCatalogInstallState();
    const registry = marketplace.readExternalRegistryOnly();

    // Keep only external items that are currently installed
    const retained = registry.items.filter(item => {
      const state = installRecords.find(s => s.id === item.id);
      return state && state.installed;
    });

    marketplace.writeExternalRegistry({ items: retained });

    const removedCount = registry.items.length - retained.length;
    console.log(`[Marketplace] Reset catalog: removed ${removedCount} uninstalled external items, retained ${retained.length} installed items`);

    res.json({
      success: true,
      message: `Catalog reset. Removed ${removedCount} items, retained ${retained.length} installed items.`,
      removedCount,
      retainedCount: retained.length,
    });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// ==========================================
// Platform Notices (Goal 020)
// ==========================================
const noticesService = require('../services/notices');

// GET /api/openclaw/notices — active notices with dismissal status for launcher UI
router.get('/notices', (req, res) => {
  try {
    const result = noticesService.getNoticesForLauncher();
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// POST /api/openclaw/notices/dismiss-all — dismiss all dismissible notices
router.post('/notices/dismiss-all', (req, res) => {
  try {
    noticesService.dismissAllNotices();
    const updated = noticesService.getNoticesForLauncher();
    res.json({ success: true, unreadCount: updated.unreadCount });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// POST /api/openclaw/notices/:noticeId/dismiss — dismiss a notice
router.post('/notices/:noticeId/dismiss', (req, res) => {
  try {
    const { noticeId } = req.params;

    // Verify the notice exists and is active
    const active = noticesService.getActiveNotices();
    const notice = active.find(n => n.id === noticeId);
    if (!notice) {
      return res.status(404).json({ error: 'Not Found', message: `Notice "${noticeId}" not found or expired` });
    }

    if (notice.dismissible === false) {
      return res.status(400).json({ error: 'Bad Request', message: 'This notice cannot be dismissed' });
    }

    noticesService.dismissNotice(noticeId);

    // Return updated unread count
    const updated = noticesService.getNoticesForLauncher();
    res.json({ success: true, unreadCount: updated.unreadCount });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// ==========================================
// System Utilization Stats
// ==========================================

router.get('/system-stats', (req, res) => {
  try {
    const latest = systemStats.getLatest();
    const rangeMinutes = req.query.range ? parseInt(req.query.range, 10) : undefined;
    const history = systemStats.getHistory(rangeMinutes);
    res.json({ latest, history, count: history.length });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

router.get('/system-stats/latest', (req, res) => {
  try {
    const latest = systemStats.getLatest();
    if (!latest) {
      return res.json({ collecting: true, message: 'Stats collection starting...' });
    }
    res.json(latest);
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

router.get('/system-stats/summary', (req, res) => {
  try {
    res.json(systemStats.getSummary());
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

router.delete('/system-stats', (req, res) => {
  try {
    systemStats.resetHistory();
    res.json({ success: true, message: 'Stats history cleared' });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// ==========================================
// Control API Call History
// ==========================================

router.get('/api-calls', (req, res) => {
  try {
    const history = apiCallHistory.getHistory().reverse();
    res.json({ history, count: history.length });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

router.delete('/api-calls', (req, res) => {
  try {
    apiCallHistory.clearHistory();
    res.json({ success: true, message: 'API call history cleared' });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// ==========================================
// Expose Registry Management (CRUD)
// ==========================================

const exposeConfig = require('../services/expose-config');
const { reload: reloadExposeRegistry } = require('../middleware/expose-registry');

// Excluded PM2 process names that cannot be adopted
const SYSTEM_PM2_PROCESSES = ['web', 'ani-code-daemon', 'openclaw-gateway'];
const USER_PM2_PREFIX = 'user-';

// GET /api/openclaw/exposures — list all exposures (passwords masked)
router.get('/exposures', (req, res) => {
  try {
    const data = exposeConfig.readExports();
    const sanitized = exposeConfig.sanitizeExposures(data);
    sanitized.publicBaseUrl = exposeConfig.getPublicBaseUrl() || null;
    res.json(sanitized);
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// Generate random htaccess-style credentials
function generateCredentials() {
  const adjectives = ['swift', 'bold', 'calm', 'dark', 'fast', 'keen', 'warm', 'cool', 'wild', 'fair'];
  const nouns = ['fox', 'owl', 'hawk', 'bear', 'wolf', 'deer', 'lynx', 'pike', 'seal', 'crow'];
  const adj = adjectives[Math.floor(Math.random() * adjectives.length)];
  const noun = nouns[Math.floor(Math.random() * nouns.length)];
  const num = Math.floor(Math.random() * 900) + 100;
  const username = `${adj}-${noun}-${num}`;
  // Simple password — rate limiting on ingress protects against brute-force
  const adj2 = adjectives[Math.floor(Math.random() * adjectives.length)];
  const noun2 = nouns[Math.floor(Math.random() * nouns.length)];
  const pin = Math.floor(Math.random() * 9000) + 1000;
  const password = `${adj2}-${noun2}-${pin}`;
  return { username, password };
}

// POST /api/openclaw/exposures/add — add a new exposure
router.post('/exposures/add', async (req, res) => {
  try {
    const { slug, type, target, path: staticPath, password, description, pm2: pm2Config } = req.body;
    let hashedPassword = null;
    let authUser = null;
    let plaintextCredentials = null;
    if (password === true || (typeof password === 'string' && password)) {
      // Generate random credentials (htaccess-style)
      const creds = generateCredentials();
      authUser = creds.username;
      const { hashPassword } = require('../utils/password');
      hashedPassword = hashPassword(creds.password);
      plaintextCredentials = { username: creds.username, password: creds.password };
    }
    // If no PM2 config provided, try to auto-detect an existing PM2 process named user-{slug}
    let resolvedPm2 = pm2Config || null;
    if (!resolvedPm2 && slug) {
      const expectedName = `${USER_PM2_PREFIX}${slug}`;
      try {
        const pm2List = await new Promise((resolve, reject) => {
          execFile('pm2', ['jlist'], { timeout: 5000 }, (err, stdout) => {
            if (err) return reject(err);
            try { resolve(JSON.parse(stdout)); } catch { resolve([]); }
          });
        });
        const proc = pm2List.find(p => p.name === expectedName);
        if (proc) {
          const script = proc.pm2_env?.pm_exec_path || null;
          const cwd = script ? path.dirname(script) : (proc.pm2_env?.pm_cwd || proc.pm2_env?.cwd || null);
          const portEnv = proc.pm2_env?.PORT || proc.pm2_env?.env?.PORT || null;
          resolvedPm2 = {
            name: expectedName,
            script: script ? path.basename(script) : 'server.js',
            cwd: cwd || null,
            bootstrap: null,
            env: portEnv ? { PORT: String(portEnv) } : {},
          };
        }
      } catch { /* pm2 lookup failed — continue without pm2 config */ }
    }

    const entry = exposeConfig.addExposure({
      slug,
      type,
      target,
      path: staticPath,
      description: description || null,
      authUser,
      password: hashedPassword,
      pm2: resolvedPm2,
    });
    reloadExposeRegistry();
    // Return plaintext credentials ONCE so user can save them
    const response = { success: true, exposure: { ...entry, password: entry.password ? '***protected***' : null } };
    if (plaintextCredentials) response.credentials = plaintextCredentials;
    res.json(response);
  } catch (err) {
    const status = err.message.includes('already exists') ? 409 : 400;
    res.status(status).json({ error: 'Validation Error', message: err.message });
  }
});

// DELETE /api/openclaw/exposures/:slug — remove an exposure (also cleans up PM2 process if managed)
router.delete('/exposures/:slug', async (req, res) => {
  try {
    const data = exposeConfig.readExports();
    const exposure = data.exposures.find(e => e.slug === req.params.slug);

    const removed = exposeConfig.removeExposure(req.params.slug);
    reloadExposeRegistry();

    // Clean up PM2 process: use explicit pm2.name if available, otherwise try user-{slug} convention
    const pm2Name = (exposure && exposure.pm2 && exposure.pm2.name)
      ? exposure.pm2.name
      : `${USER_PM2_PREFIX}${req.params.slug}`;
    try {
      await new Promise((resolve) => {
        execFile('pm2', ['delete', pm2Name], { timeout: 5000 }, () => resolve());
      });
      await new Promise((resolve) => {
        execFile('pm2', ['save'], { timeout: 5000 }, () => resolve());
      });
    } catch { /* best-effort cleanup */ }

    res.json({ success: true, removed: { ...removed, password: removed.password ? '***protected***' : null } });
  } catch (err) {
    const status = err.message.includes('not found') ? 404 : 500;
    res.status(status).json({ error: 'Error', message: err.message });
  }
});

// PATCH /api/openclaw/exposures/:slug — update an exposure (enable/disable, change target/path/password)
router.patch('/exposures/:slug', async (req, res) => {
  try {
    const data = exposeConfig.readExports();
    const exposure = data.exposures.find(e => e.slug === req.params.slug);
    const patch = {};
    if (req.body.enabled !== undefined) patch.enabled = req.body.enabled;
    if (req.body.description !== undefined) patch.description = req.body.description;
    if (req.body.target !== undefined) patch.target = req.body.target;
    if (req.body.path !== undefined) patch.path = req.body.path;
    if (req.body.pm2 !== undefined) patch.pm2 = req.body.pm2;
    let plaintextCredentials = null;
    if (req.body.password !== undefined || req.body.customAuth) {
      if (req.body.password === null || req.body.password === '') {
        patch.password = null;
        patch.authUser = null;
      } else if (req.body.customAuth) {
        // Custom credentials provided by user
        const { hashPassword } = require('../utils/password');
        const customUser = req.body.authUser || exposure?.authUser || generateCredentials().username;
        const customPass = req.body.password || generateCredentials().password;
        patch.authUser = customUser;
        patch.password = hashPassword(customPass);
        plaintextCredentials = { username: customUser, password: customPass };
      } else {
        // Generate new random credentials
        const creds = generateCredentials();
        patch.authUser = creds.username;
        const { hashPassword } = require('../utils/password');
        patch.password = hashPassword(creds.password);
        plaintextCredentials = { username: creds.username, password: creds.password };
      }
    }
    const updated = exposeConfig.updateExposure(req.params.slug, patch);
    reloadExposeRegistry();
    const response = { success: true, exposure: { ...updated, password: updated.password ? '***protected***' : null } };
    if (plaintextCredentials) response.credentials = plaintextCredentials;
    res.json(response);
  } catch (err) {
    const status = err.message.includes('not found') ? 404 : 400;
    res.status(status).json({ error: 'Error', message: err.message });
  }
});

// POST /api/openclaw/exposures/:slug/rename — rename an exposure's slug
router.post('/exposures/:slug/rename', async (req, res) => {
  try {
    const { newSlug } = req.body;
    if (!newSlug) return res.status(400).json({ error: 'newSlug is required' });

    // If PM2-managed, rename the PM2 process too
    const data = exposeConfig.readExports();
    const exposure = data.exposures.find(e => e.slug === req.params.slug);
    const oldPm2Name = exposure && exposure.pm2 && exposure.pm2.name;

    const updated = exposeConfig.renameExposure(req.params.slug, newSlug);
    reloadExposeRegistry();

    // Rename PM2 process if managed (delete old, start new)
    if (oldPm2Name && updated.pm2 && updated.pm2.name && oldPm2Name !== updated.pm2.name) {
      const { execFile } = require('child_process');
      try {
        await new Promise((resolve) => {
          execFile('pm2', ['delete', oldPm2Name], { timeout: 5000 }, () => resolve());
        });
        if (updated.pm2.script) {
          const args = ['start', updated.pm2.script, '--name', updated.pm2.name];
          if (updated.pm2.cwd) args.push('--cwd', updated.pm2.cwd);
          const env = { ...process.env };
          if (updated.pm2.env) Object.assign(env, updated.pm2.env);
          await new Promise((resolve) => {
            execFile('pm2', args, { timeout: 10000, env }, () => resolve());
          });
        }
        await new Promise((resolve) => {
          execFile('pm2', ['save'], { timeout: 5000 }, () => resolve());
        });
      } catch { /* best-effort */ }
    }

    res.json({ success: true, exposure: { ...updated, password: updated.password ? '***protected***' : null } });
  } catch (err) {
    const status = err.message.includes('not found') ? 404 : err.message.includes('already exists') ? 409 : 400;
    res.status(status).json({ error: 'Error', message: err.message });
  }
});

// GET /api/openclaw/exposures/:slug/logs — recent PM2 logs for a managed exposure
router.get('/exposures/:slug/logs', async (req, res) => {
  try {
    const data = exposeConfig.readExports();
    const exposure = data.exposures.find(e => e.slug === req.params.slug);
    if (!exposure) return res.status(404).json({ error: 'Exposure not found' });
    if (!exposure.pm2 || !exposure.pm2.name) {
      return res.status(400).json({ error: 'Exposure is not PM2-managed' });
    }

    const lines = parseInt(req.query.lines) || 50;
    const clampedLines = Math.min(Math.max(lines, 1), 500);
    const { execFile } = require('child_process');

    const logs = await new Promise((resolve) => {
      execFile('pm2', ['logs', exposure.pm2.name, '--lines', String(clampedLines), '--nostream', '--raw'], { timeout: 5000 }, (err, stdout, stderr) => {
        if (err) return resolve({ out: '', error: stderr || err.message });
        resolve({ out: stdout || '', error: '' });
      });
    });

    res.json({ slug: req.params.slug, pm2Name: exposure.pm2.name, lines: clampedLines, logs: logs.out, error: logs.error || null });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/openclaw/exposures/:slug/access-log — recent access log entries for an exposure
router.get('/exposures/:slug/access-log', (req, res) => {
  try {
    const { getAccessLog } = require('../middleware/expose-registry');
    const log = getAccessLog ? getAccessLog(req.params.slug) : [];
    res.json({ slug: req.params.slug, entries: log });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/openclaw/exposures/reload — trigger hot-reload of the expose registry
router.post('/exposures/reload', (req, res) => {
  try {
    reloadExposeRegistry();
    const data = exposeConfig.readExports();
    const activeCount = data.exposures.filter(e => e.enabled).length;
    res.json({ success: true, message: 'Expose registry reloaded', activeExposures: activeCount });
  } catch (err) {
    res.status(500).json({ error: 'Internal Server Error', message: err.message });
  }
});

// GET /api/openclaw/exposures/probe/:slug — liveness check for proxy exposures
router.get('/exposures/probe/:slug', async (req, res) => {
  try {
    const data = exposeConfig.readExports();
    const exposure = data.exposures.find(e => e.slug === req.params.slug);
    if (!exposure) return res.status(404).json({ error: 'Not found' });
    if (exposure.type === 'static') {
      // For static, check if directory exists
      const resolvedPath = require('path').resolve(exposeConfig.WORKSPACE_ROOT, exposure.path);
      const exists = require('fs').existsSync(resolvedPath);
      return res.json({ slug: exposure.slug, reachable: exists, type: 'static' });
    }
    // For proxy, try to connect to the target
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 3000);
      await fetch(exposure.target, { method: 'HEAD', signal: controller.signal }).catch(() => {
        // fetch may throw on connection refused — that means unreachable
        throw new Error('unreachable');
      });
      clearTimeout(timeout);
      return res.json({ slug: exposure.slug, reachable: true, type: 'proxy' });
    } catch {
      return res.json({ slug: exposure.slug, reachable: false, type: 'proxy' });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/openclaw/exposures/stats — access counts from expose registry logs
router.get('/exposures/stats', (req, res) => {
  try {
    const { getAccessStats } = require('../middleware/expose-registry');
    res.json(getAccessStats());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/openclaw/exposures/pm2-status — PM2 status for all managed exposures
router.get('/exposures/pm2-status', async (req, res) => {
  try {
    const data = exposeConfig.readExports();
    const managed = data.exposures.filter(e => e.pm2 && e.pm2.name);
    const unmanaged = data.exposures.filter(e => !e.pm2 || !e.pm2.name);
    if (managed.length === 0 && unmanaged.length === 0) return res.json({});

    // Get pm2 jlist
    const { execFile } = require('child_process');
    const pm2List = await new Promise((resolve) => {
      execFile('pm2', ['jlist'], { timeout: 5000 }, (err, stdout) => {
        if (err) return resolve([]);
        try { return resolve(JSON.parse(stdout)); } catch { return resolve([]); }
      });
    });

    const result = {};
    for (const exp of managed) {
      const proc = pm2List.find(p => p.name === exp.pm2.name);
      if (proc) {
        result[exp.slug] = {
          name: proc.name,
          status: proc.pm2_env?.status || 'unknown',
          cpu: proc.monit?.cpu || 0,
          memory: proc.monit?.memory || 0,
          uptime: proc.pm2_env?.pm_uptime || null,
          restarts: proc.pm2_env?.restart_time || 0,
          pid: proc.pid || null,
        };
      } else {
        result[exp.slug] = { name: exp.pm2.name, status: 'not_found' };
      }
    }

    // Check for exposures without PM2 config that have a matching user-{slug} process
    for (const exp of unmanaged) {
      const expectedName = `${USER_PM2_PREFIX}${exp.slug}`;
      const proc = pm2List.find(p => p.name === expectedName);
      if (proc) {
        result[exp.slug] = {
          name: expectedName,
          status: proc.pm2_env?.status || 'unknown',
          cpu: proc.monit?.cpu || 0,
          memory: proc.monit?.memory || 0,
          uptime: proc.pm2_env?.pm_uptime || null,
          restarts: proc.pm2_env?.restart_time || 0,
          pid: proc.pid || null,
          recoverable: true,
        };
      }
    }
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/openclaw/exposures/summary — lightweight counts for sidebar badge
router.get('/exposures/summary', async (req, res) => {
  try {
    const data = exposeConfig.readExports();
    const enabled = data.exposures.filter(e => e.enabled);
    const total = enabled.length;
    const managed = enabled.filter(e => e.pm2 && e.pm2.name);
    const unmanaged = enabled.filter(e => !e.pm2 || !e.pm2.name);

    let running = 0;

    // Count PM2-managed exposures that are online
    if (managed.length > 0) {
      const { execFile } = require('child_process');
      const pm2List = await new Promise((resolve) => {
        execFile('pm2', ['jlist'], { timeout: 5000 }, (err, stdout) => {
          if (err) return resolve([]);
          try { return resolve(JSON.parse(stdout)); } catch { return resolve([]); }
        });
      });
      for (const exp of managed) {
        const proc = pm2List.find(p => p.name === exp.pm2.name);
        if (proc && proc.pm2_env?.status === 'online') running++;
      }
    }

    // Count non-PM2 exposures that are reachable
    await Promise.all(unmanaged.map(async (exp) => {
      try {
        if (exp.type === 'static') {
          const resolvedPath = require('path').resolve(exposeConfig.WORKSPACE_ROOT, exp.path);
          if (require('fs').existsSync(resolvedPath)) running++;
        } else if (exp.type === 'proxy' && exp.target) {
          const controller = new AbortController();
          const timeout = setTimeout(() => controller.abort(), 2000);
          await fetch(exp.target, { method: 'HEAD', signal: controller.signal });
          clearTimeout(timeout);
          running++;
        }
      } catch {
        // unreachable — not counted
      }
    }));

    res.json({ total, running });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/openclaw/exposures/:slug/backup — download project source as tar.gz (excludes node_modules etc, includes .git)
router.get('/exposures/:slug/backup', async (req, res) => {
  try {
    const data = exposeConfig.readExports();
    const exposure = data.exposures.find(e => e.slug === req.params.slug);
    if (!exposure) return res.status(404).json({ error: 'Not found', message: 'Exposure not found' });

    // Determine project directory from pm2.cwd or static path
    let projectDir = null;
    if (exposure.pm2 && exposure.pm2.cwd) {
      projectDir = exposure.pm2.cwd;
    } else if (exposure.path) {
      projectDir = path.resolve(exposeConfig.WORKSPACE_ROOT, exposure.path);
    }
    if (!projectDir || !fs.existsSync(projectDir)) {
      return res.status(400).json({ error: 'No project directory', message: 'Could not determine project directory for this exposure' });
    }

    const realDir = fs.realpathSync(projectDir);
    if (!fs.statSync(realDir).isDirectory()) {
      return res.status(400).json({ error: 'Not a directory', message: 'Project path is not a directory' });
    }

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const filename = `${exposure.slug}-backup-${timestamp}.tar.gz`;

    // Exclude package/dependency directories and build artifacts
    const excludes = [
      'node_modules', '.npm', '.yarn', '.pnp.*',
      'vendor', '__pycache__', '.venv', 'venv',
      '.gradle', 'build', 'target',
      '.cache', '.parcel-cache', '.next', '.nuxt',
      'dist', 'coverage',
      '.DS_Store', 'Thumbs.db',
    ];
    const tarArgs = ['czf', '-'];
    for (const ex of excludes) {
      tarArgs.push('--exclude', ex);
    }
    tarArgs.push('-C', path.dirname(realDir), path.basename(realDir));

    const tar = spawn('tar', tarArgs);
    const chunks = [];

    tar.stdout.on('data', (chunk) => chunks.push(chunk));
    tar.stderr.on('data', () => {}); // ignore warnings

    await new Promise((resolve, reject) => {
      tar.on('error', reject);
      tar.on('close', (code) => {
        if (code !== 0) reject(new Error(`tar exited with code ${code}`));
        else resolve();
      });
    });

    const buffer = Buffer.concat(chunks);
    const base64Data = buffer.toString('base64');

    res.json({
      success: true,
      filename,
      size: buffer.length,
      data: base64Data,
      mimeType: 'application/gzip',
    });
  } catch (err) {
    res.status(500).json({ error: 'Backup Failed', message: err.message });
  }
});

// POST /api/openclaw/exposures/pm2-control — start/stop/restart PM2 process for a managed exposure
router.post('/exposures/pm2-control', async (req, res) => {
  try {
    const { slug, action } = req.body;
    if (!slug || !action) return res.status(400).json({ error: 'slug and action required' });
    if (!['start', 'stop', 'restart', 'delete'].includes(action)) {
      return res.status(400).json({ error: 'action must be start, stop, restart, or delete' });
    }

    const data = exposeConfig.readExports();
    const exposure = data.exposures.find(e => e.slug === slug);
    if (!exposure) return res.status(404).json({ error: 'Exposure not found' });
    if (!exposure.pm2 || !exposure.pm2.name) {
      return res.status(400).json({ error: 'Exposure is not PM2-managed' });
    }

    const { execFile } = require('child_process');
    const os = require('os');

    // Helper: resolve ~ in paths to absolute home dir
    const resolvePath = (p) => p && p.startsWith('~') ? path.join(os.homedir(), p.slice(1)) : p;

    // Helper: check if PM2 process exists in current PM2 process list
    const pm2ProcessExists = async (name) => {
      const pm2List = await new Promise((resolve) => {
        execFile('pm2', ['jlist'], { timeout: 5000 }, (err, stdout) => {
          if (err) return resolve([]);
          try { resolve(JSON.parse(stdout)); } catch { resolve([]); }
        });
      });
      return pm2List.some(p => p.name === name);
    };

    // Helper: (re)create PM2 process from stored exposure config
    const recreateFromConfig = async () => {
      if (!exposure.pm2.script) {
        throw new Error('Cannot recreate PM2 process: no script configured for this exposure');
      }
      let resolvedCwd = resolvePath(exposure.pm2.cwd);
      const resolvedScript = resolvePath(exposure.pm2.script);

      // If script is relative and doesn't exist at resolvedCwd, try the project directory
      if (resolvedCwd && !path.isAbsolute(resolvedScript)) {
        const fullPath = path.join(resolvedCwd, resolvedScript);
        if (!fs.existsSync(fullPath)) {
          const projectCwd = path.join(exposeConfig.WORKSPACE_ROOT, 'projects', slug);
          if (fs.existsSync(path.join(projectCwd, resolvedScript))) {
            resolvedCwd = projectCwd;
            // Fix stored config so this doesn't recur
            exposure.pm2.cwd = projectCwd;
            try { exposeConfig.updateExposure(slug, { pm2: exposure.pm2 }); } catch {}
          }
        }
      }

      // Run bootstrap (e.g. npm install) if configured and node_modules is missing
      if (exposure.pm2.bootstrap && resolvedCwd) {
        const nodeModulesPath = path.join(resolvedCwd, 'node_modules');
        if (!fs.existsSync(nodeModulesPath)) {
          await new Promise((resolve, reject) => {
            execFile('sh', ['-c', exposure.pm2.bootstrap], { cwd: resolvedCwd, timeout: 60000 }, (err) => {
              if (err) return reject(new Error(`Bootstrap failed: ${err.message}`));
              resolve();
            });
          });
        }
      }

      const args = ['start', resolvedScript, '--name', exposure.pm2.name];
      if (resolvedCwd) args.push('--cwd', resolvedCwd);
      const env = { ...process.env };
      if (exposure.pm2.env) Object.assign(env, exposure.pm2.env);
      const output = await new Promise((resolve, reject) => {
        execFile('pm2', args, { timeout: 10000, env }, (err, stdout, stderr) => {
          if (err) return reject(new Error(stderr || err.message));
          resolve(stdout);
        });
      });
      await new Promise((resolve) => {
        execFile('pm2', ['save'], { timeout: 5000 }, () => resolve());
      });
      return output;
    };

    if (action === 'start') {
      // Check if PM2 process exists — if not (e.g. PM2 was reset), recreate from config
      const exists = await pm2ProcessExists(exposure.pm2.name);
      if (!exists && exposure.pm2.script) {
        const output = await recreateFromConfig();
        return res.json({ success: true, action, slug, recreated: true, output: output.trim() });
      }
      // Process exists (stopped) or no script — try pm2 start by name
      if (exists) {
        const result = await new Promise((resolve, reject) => {
          const env = { ...process.env };
          if (exposure.pm2.env) Object.assign(env, exposure.pm2.env);
          execFile('pm2', ['start', exposure.pm2.name], { timeout: 10000, env }, (err, stdout, stderr) => {
            if (err) return reject(new Error(stderr || err.message));
            resolve(stdout);
          });
        });
        await new Promise((resolve) => {
          execFile('pm2', ['save'], { timeout: 5000 }, () => resolve());
        });
        return res.json({ success: true, action, slug, output: result.trim() });
      }
      // No process and no script — cannot start
      return res.status(400).json({ error: 'PM2 process not found and no script configured to recreate it' });
    }

    if (action === 'restart') {
      // Check if PM2 process exists — if not (e.g. PM2 was reset), recreate from config
      const exists = await pm2ProcessExists(exposure.pm2.name);
      if (!exists && exposure.pm2.script) {
        const output = await recreateFromConfig();
        return res.json({ success: true, action, slug, recreated: true, output: output.trim() });
      }
    }

    // For stop/restart (when process exists)/delete, just use the pm2 name
    const result = await new Promise((resolve, reject) => {
      execFile('pm2', [action, exposure.pm2.name], { timeout: 10000 }, (err, stdout, stderr) => {
        if (err) return reject(new Error(stderr || err.message));
        resolve(stdout);
      });
    });

    await new Promise((resolve) => {
      execFile('pm2', ['save'], { timeout: 5000 }, () => resolve());
    });

    res.json({ success: true, action, slug, output: result.trim() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/openclaw/exposures/scaffold-hello — create a hello-world Node.js project, start via PM2, and register exposure
router.post('/exposures/scaffold-hello', async (req, res) => {
  try {
    const slug = 'hello-world';
    const port = 3001;
    const projectDir = path.join(exposeConfig.WORKSPACE_ROOT, 'projects', slug);

    // Check if already exists
    const data = exposeConfig.readExports();
    if (data.exposures.some(e => e.slug === slug)) {
      return res.status(409).json({ error: `Exposure "${slug}" already exists. Remove it first to re-scaffold.` });
    }

    // Create project directory
    fs.mkdirSync(path.join(projectDir, 'public'), { recursive: true });

    // Write server.js
    const serverJs = `const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || ${port};

app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/status', (req, res) => {
  res.json({ status: 'ok', uptime: process.uptime(), project: '${slug}' });
});

app.listen(PORT, () => console.log(\`Hello World running on port \${PORT}\`));
`;
    fs.writeFileSync(path.join(projectDir, 'server.js'), serverJs);

    // Write package.json
    const packageJson = {
      name: slug,
      version: '1.0.0',
      private: true,
      scripts: { start: 'node server.js' },
      dependencies: { express: '^4.21.0' },
    };
    fs.writeFileSync(path.join(projectDir, 'package.json'), JSON.stringify(packageJson, null, 2));

    // Write index.html — fully self-contained, no external CDN dependencies
    const indexHtml = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Hello World — OpenClaw</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); color: #e2e8f0; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
  .card { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 16px; padding: 48px; text-align: center; max-width: 480px; backdrop-filter: blur(10px); }
  h1 { font-size: 2rem; margin-bottom: 8px; }
  .subtitle { color: #94a3b8; margin-bottom: 24px; }
  .status { display: inline-flex; align-items: center; gap: 8px; background: rgba(34,197,94,0.15); border: 1px solid rgba(34,197,94,0.3); border-radius: 20px; padding: 6px 16px; font-size: 0.85rem; color: #4ade80; }
  .dot { width: 8px; height: 8px; border-radius: 50%; background: #4ade80; animation: pulse 2s infinite; }
  @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
  .info { margin-top: 24px; font-size: 0.8rem; color: #64748b; }
  .uptime { margin-top: 16px; font-size: 0.75rem; color: #475569; font-variant-numeric: tabular-nums; }
</style>
</head>
<body>
<div class="card">
  <h1>Hello World</h1>
  <p class="subtitle">Your first OpenClaw exposed project</p>
  <div class="status"><span class="dot"></span> Service Running</div>
  <p class="info">Express + PM2 managed &middot; Port ${port}</p>
  <p class="uptime" id="uptime"></p>
</div>
<script>
  function fmtUptime(s) {
    if (s < 60) return s + 's';
    if (s < 3600) return Math.floor(s/60) + 'm ' + (s%60) + 's';
    return Math.floor(s/3600) + 'h ' + Math.floor((s%3600)/60) + 'm';
  }
  function fetchStatus() {
    fetch('/open/${slug}/api/status')
      .then(function(r) { return r.json(); })
      .then(function(d) { document.getElementById('uptime').textContent = 'Uptime: ' + fmtUptime(Math.floor(d.uptime)); })
      .catch(function() {});
  }
  fetchStatus();
  setInterval(fetchStatus, 5000);
</script>
</body>
</html>`;
    fs.writeFileSync(path.join(projectDir, 'public', 'index.html'), indexHtml);

    // Run npm install
    const { execFile } = require('child_process');
    await new Promise((resolve, reject) => {
      execFile('npm', ['install', '--production'], { cwd: projectDir, timeout: 60000 }, (err, stdout, stderr) => {
        if (err) return reject(new Error('npm install failed: ' + (stderr || err.message)));
        resolve(stdout);
      });
    });

    // Start with PM2 (user- prefix for all user-created services)
    const pm2Name = `user-${slug}`;
    const pm2Env = { ...process.env, PORT: String(port) };
    await new Promise((resolve, reject) => {
      execFile('pm2', ['start', 'server.js', '--name', pm2Name, '--cwd', projectDir], { timeout: 10000, env: pm2Env }, (err, stdout, stderr) => {
        if (err) return reject(new Error('PM2 start failed: ' + (stderr || err.message)));
        resolve(stdout);
      });
    });

    // Save PM2 process list
    await new Promise((resolve) => {
      execFile('pm2', ['save'], { timeout: 5000 }, () => resolve());
    });

    // Register exposure
    const entry = exposeConfig.addExposure({
      slug,
      description: 'Demo project — Express + React via CDN, PM2 managed',
      type: 'proxy',
      target: `http://127.0.0.1:${port}`,
      password: null,
      pm2: {
        name: pm2Name,
        script: path.join(projectDir, 'server.js'),
        cwd: projectDir,
        bootstrap: 'npm install',
        env: { PORT: String(port) },
      },
    });
    reloadExposeRegistry();

    // Wait a moment then verify
    await new Promise(r => setTimeout(r, 1500));

    // Verify checks
    const checks = { portOpen: false, pm2Running: false, noErrors: true };
    // Check PM2 status
    const pm2Status = await new Promise((resolve) => {
      execFile('pm2', ['jlist'], { timeout: 5000 }, (err, stdout) => {
        if (err) return resolve(null);
        try { return resolve(JSON.parse(stdout)); } catch { return resolve(null); }
      });
    });
    if (pm2Status) {
      const proc = pm2Status.find(p => p.name === pm2Name);
      if (proc) {
        checks.pm2Running = proc.pm2_env?.status === 'online';
        checks.noErrors = (proc.pm2_env?.restart_time || 0) === 0;
      }
    }
    // Check port
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 3000);
      await fetch(`http://127.0.0.1:${port}`, { method: 'HEAD', signal: controller.signal });
      clearTimeout(timeout);
      checks.portOpen = true;
    } catch { checks.portOpen = false; }

    const publicBase = exposeConfig.getPublicBaseUrl();
    const relUrl = `/open/${slug}/`;
    res.json({
      success: true,
      slug,
      port,
      projectDir,
      url: relUrl,
      publicUrl: publicBase ? `${publicBase}${relUrl}` : null,
      checks,
      exposure: { ...entry, password: null },
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/openclaw/exposures/scaffold-new — create a new project from skill template, only name required
router.post('/exposures/scaffold-new', async (req, res) => {
  try {
    const { name, description, port: requestedPort, enableAuth } = req.body;
    if (!name || typeof name !== 'string') {
      return res.status(400).json({ error: 'name is required' });
    }
    const slug = name.trim().toLowerCase();

    // Check if already exists
    const data = exposeConfig.readExports();
    if (data.exposures.some(e => e.slug === slug)) {
      return res.status(409).json({ error: `Exposure "${slug}" already exists. Remove it first.` });
    }

    // Validate slug
    exposeConfig.validateSlug(slug);

    // Find an available port: scan existing exposures and PM2 processes
    const usedPorts = new Set([3000, 18789]); // launcher + gateway
    for (const exp of data.exposures) {
      if (exp.target) {
        try { usedPorts.add(Number(new URL(exp.target).port)); } catch {}
      }
      if (exp.pm2 && exp.pm2.env && exp.pm2.env.PORT) {
        usedPorts.add(Number(exp.pm2.env.PORT));
      }
    }
    let port = requestedPort ? Number(requestedPort) : 0;
    if (!port) {
      for (let p = 3001; p < 3100; p++) {
        if (!usedPorts.has(p)) { port = p; break; }
      }
      if (!port) return res.status(500).json({ error: 'No available port found in range 3001-3099' });
    }

    const projectDir = path.join(exposeConfig.WORKSPACE_ROOT, 'projects', slug);

    // Create project directory
    fs.mkdirSync(path.join(projectDir, 'public'), { recursive: true });

    // Write server.js from skill example template
    const serverJs = `const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || ${port};

app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/status', (req, res) => {
  res.json({ status: 'ok', uptime: process.uptime(), project: '${slug}' });
});

app.listen(PORT, () => console.log(\`${slug} running on port \${PORT}\`));
`;
    fs.writeFileSync(path.join(projectDir, 'server.js'), serverJs);

    // Write package.json
    const packageJson = {
      name: slug,
      version: '1.0.0',
      private: true,
      scripts: { start: 'node server.js' },
      dependencies: { express: '^4.21.0' },
    };
    fs.writeFileSync(path.join(projectDir, 'package.json'), JSON.stringify(packageJson, null, 2));

    // Write minimal public/index.html — fully self-contained, no external CDN dependencies
    const indexHtml = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${slug} — OpenClaw</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); color: #e2e8f0; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
  .card { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 16px; padding: 48px; text-align: center; max-width: 480px; backdrop-filter: blur(10px); }
  h1 { font-size: 2rem; margin-bottom: 8px; }
  .subtitle { color: #94a3b8; margin-bottom: 24px; }
  .status { display: inline-flex; align-items: center; gap: 8px; background: rgba(34,197,94,0.15); border: 1px solid rgba(34,197,94,0.3); border-radius: 20px; padding: 6px 16px; font-size: 0.85rem; color: #4ade80; }
  .dot { width: 8px; height: 8px; border-radius: 50%; background: #4ade80; animation: pulse 2s infinite; }
  @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
  .info { margin-top: 24px; font-size: 0.8rem; color: #64748b; }
</style>
</head>
<body>
<div class="card">
  <h1>${slug}</h1>
  <p class="subtitle">OpenClaw Web App</p>
  <div class="status"><span class="dot"></span> Service Running</div>
  <p class="info">Express + PM2 managed &middot; Port ${port}</p>
  <p id="uptime" style="margin-top:16px;font-size:0.75rem;color:#475569"></p>
</div>
<script>
  function fmtUptime(s) {
    if (s < 60) return s + 's';
    if (s < 3600) return Math.floor(s/60) + 'm ' + (s%60) + 's';
    return Math.floor(s/3600) + 'h ' + Math.floor((s%3600)/60) + 'm';
  }
  function fetchStatus() {
    fetch('/open/${slug}/api/status')
      .then(function(r) { return r.json(); })
      .then(function(d) { document.getElementById('uptime').textContent = 'Uptime: ' + fmtUptime(Math.floor(d.uptime)); })
      .catch(function() {});
  }
  fetchStatus();
  setInterval(fetchStatus, 5000);
</script>
</body>
</html>`;
    fs.writeFileSync(path.join(projectDir, 'public', 'index.html'), indexHtml);

    // Run npm install
    const { execFile } = require('child_process');
    await new Promise((resolve, reject) => {
      execFile('npm', ['install', '--production'], { cwd: projectDir, timeout: 60000 }, (err, stdout, stderr) => {
        if (err) return reject(new Error('npm install failed: ' + (stderr || err.message)));
        resolve(stdout);
      });
    });

    // Start with PM2
    const pm2Name = `user-${slug}`;
    const pm2Env = { ...process.env, PORT: String(port) };
    await new Promise((resolve, reject) => {
      execFile('pm2', ['start', 'server.js', '--name', pm2Name, '--cwd', projectDir], { timeout: 10000, env: pm2Env }, (err, stdout, stderr) => {
        if (err) return reject(new Error('PM2 start failed: ' + (stderr || err.message)));
        resolve(stdout);
      });
    });
    await new Promise((resolve) => {
      execFile('pm2', ['save'], { timeout: 5000 }, () => resolve());
    });

    // Handle auth
    let hashedPassword = null;
    let authUser = null;
    let plaintextCredentials = null;
    if (enableAuth) {
      const creds = generateCredentials();
      authUser = creds.username;
      const { hashPassword } = require('../utils/password');
      hashedPassword = hashPassword(creds.password);
      plaintextCredentials = { username: creds.username, password: creds.password };
    }

    // Register exposure
    const entry = exposeConfig.addExposure({
      slug,
      description: description || null,
      type: 'proxy',
      target: `http://127.0.0.1:${port}`,
      authUser,
      password: hashedPassword,
      pm2: {
        name: pm2Name,
        script: path.join(projectDir, 'server.js'),
        cwd: projectDir,
        bootstrap: 'npm install',
        env: { PORT: String(port) },
      },
    });
    reloadExposeRegistry();

    // Verify
    await new Promise(r => setTimeout(r, 1500));
    const checks = { portOpen: false, pm2Running: false };
    const pm2Status = await new Promise((resolve) => {
      execFile('pm2', ['jlist'], { timeout: 5000 }, (err, stdout) => {
        if (err) return resolve(null);
        try { return resolve(JSON.parse(stdout)); } catch { return resolve(null); }
      });
    });
    if (pm2Status) {
      const proc = pm2Status.find(p => p.name === pm2Name);
      if (proc) checks.pm2Running = proc.pm2_env?.status === 'online';
    }
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 3000);
      await fetch(`http://127.0.0.1:${port}`, { method: 'HEAD', signal: controller.signal });
      clearTimeout(timeout);
      checks.portOpen = true;
    } catch { checks.portOpen = false; }

    const publicBase = exposeConfig.getPublicBaseUrl();
    const relUrl = `/open/${slug}/`;
    const response = {
      success: true,
      slug,
      port,
      projectDir,
      url: relUrl,
      publicUrl: publicBase ? `${publicBase}${relUrl}` : null,
      checks,
      exposure: { ...entry, password: entry.password ? '***protected***' : null },
    };
    if (plaintextCredentials) response.credentials = plaintextCredentials;
    res.json(response);
  } catch (err) {
    const status = err.message.includes('already exists') ? 409 : 500;
    res.status(status).json({ error: err.message });
  }
});

// POST /api/openclaw/exposures/rename-pm2 — rename a PM2 process to add the user- prefix
router.post('/exposures/rename-pm2', async (req, res) => {
  try {
    const { oldName, newName } = req.body;
    if (!oldName || !newName) {
      return res.status(400).json({ error: 'oldName and newName are required' });
    }
    if (SYSTEM_PM2_PROCESSES.includes(oldName)) {
      return res.status(400).json({ error: `"${oldName}" is a system process and cannot be renamed` });
    }
    if (!newName.startsWith(USER_PM2_PREFIX)) {
      return res.status(400).json({ error: `New name must start with "${USER_PM2_PREFIX}"` });
    }

    const { execFile } = require('child_process');

    // Get current process info
    const pm2List = await new Promise((resolve, reject) => {
      execFile('pm2', ['jlist'], { timeout: 5000 }, (err, stdout) => {
        if (err) return reject(new Error('Failed to list PM2 processes'));
        try { resolve(JSON.parse(stdout)); } catch { resolve([]); }
      });
    });

    const proc = pm2List.find(p => p.name === oldName);
    if (!proc) {
      return res.status(404).json({ error: `PM2 process "${oldName}" not found` });
    }

    // Check new name doesn't already exist
    if (pm2List.some(p => p.name === newName)) {
      return res.status(409).json({ error: `PM2 process "${newName}" already exists` });
    }

    const script = proc.pm2_env?.pm_exec_path || null;
    const cwd = proc.pm2_env?.pm_cwd || proc.pm2_env?.cwd || null;
    const interpreter = proc.pm2_env?.exec_interpreter || 'node';
    const envVars = {};
    // Preserve PORT if set
    if (proc.pm2_env?.PORT) envVars.PORT = proc.pm2_env.PORT;
    if (proc.pm2_env?.env?.PORT) envVars.PORT = proc.pm2_env.env.PORT;

    if (!script) {
      return res.status(400).json({ error: 'Cannot determine script path for this process' });
    }

    // Verify the script file actually exists before attempting rename
    if (!fs.existsSync(script)) {
      // Script doesn't exist — this is a zombie/broken process, just clean it up
      await new Promise((resolve) => {
        execFile('pm2', ['delete', oldName], { timeout: 10000 }, () => resolve());
      });
      await new Promise((resolve) => {
        execFile('pm2', ['save'], { timeout: 5000 }, () => resolve());
      });
      return res.status(400).json({
        error: `Script not found at "${script}". The broken process "${oldName}" has been cleaned up.`,
        cleaned: true,
      });
    }

    // Delete old process
    await new Promise((resolve, reject) => {
      execFile('pm2', ['delete', oldName], { timeout: 10000 }, (err, stdout, stderr) => {
        if (err) return reject(new Error('Failed to delete old process: ' + (stderr || err.message)));
        resolve(stdout);
      });
    });

    // Start with new name
    const startArgs = ['start', script, '--name', newName];
    if (cwd) startArgs.push('--cwd', cwd);
    if (interpreter && interpreter !== 'node') startArgs.push('--interpreter', interpreter);

    const env = { ...process.env, ...envVars };
    await new Promise((resolve, reject) => {
      execFile('pm2', startArgs, { timeout: 10000, env }, (err, stdout, stderr) => {
        if (err) return reject(new Error('Failed to start renamed process: ' + (stderr || err.message)));
        resolve(stdout);
      });
    });

    // Save PM2 process list
    await new Promise((resolve) => {
      execFile('pm2', ['save'], { timeout: 5000 }, () => resolve());
    });

    res.json({ success: true, oldName, newName });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/openclaw/exposures/adoptable-pm2 — list PM2 processes that can be adopted as exposures
router.get('/exposures/adoptable-pm2', async (req, res) => {
  try {
    const { execFile } = require('child_process');
    const pm2List = await new Promise((resolve, reject) => {
      execFile('pm2', ['jlist'], { timeout: 5000 }, (err, stdout) => {
        if (err) return reject(new Error('Failed to list PM2 processes'));
        try { resolve(JSON.parse(stdout)); } catch { resolve([]); }
      });
    });

    // Get already-adopted PM2 names
    const data = exposeConfig.readExports();
    const adoptedNames = new Set(data.exposures.filter(e => e.pm2 && e.pm2.name).map(e => e.pm2.name));

    const adoptable = pm2List
      .filter(p => !SYSTEM_PM2_PROCESSES.includes(p.name))
      .filter(p => !adoptedNames.has(p.name))
      .map(p => {
        const hasPrefix = p.name.startsWith(USER_PM2_PREFIX);
        const cwd = p.pm2_env?.pm_cwd || p.pm2_env?.cwd || null;
        const script = p.pm2_env?.pm_exec_path || null;
        const portEnv = p.pm2_env?.PORT || p.pm2_env?.env?.PORT || null;
        const scriptExists = script ? fs.existsSync(script) : false;
        return {
          name: p.name,
          hasRequiredPrefix: hasPrefix,
          suggestedSlug: hasPrefix ? p.name.slice(USER_PM2_PREFIX.length) : null,
          status: p.pm2_env?.status || 'unknown',
          pid: p.pid,
          cwd,
          script,
          scriptExists,
          port: portEnv ? Number(portEnv) : null,
          memory: p.monit?.memory || 0,
        };
      })
      // Filter out broken processes whose script doesn't exist
      .filter(p => p.scriptExists);

    res.json({ success: true, processes: adoptable });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/openclaw/exposures/adopt-pm2 — adopt an existing PM2 process as an exposure
router.post('/exposures/adopt-pm2', async (req, res) => {
  try {
    const { pm2Name, port: requestedPort, description, enableAuth } = req.body;
    if (!pm2Name || typeof pm2Name !== 'string') {
      return res.status(400).json({ error: 'pm2Name is required' });
    }

    // Must not be a system process
    if (SYSTEM_PM2_PROCESSES.includes(pm2Name)) {
      return res.status(400).json({ error: `"${pm2Name}" is a system process and cannot be adopted` });
    }

    // Must have user- prefix
    if (!pm2Name.startsWith(USER_PM2_PREFIX)) {
      return res.status(400).json({
        error: `PM2 process "${pm2Name}" must be renamed with the "${USER_PM2_PREFIX}" prefix before adopting. Run: pm2 delete ${pm2Name} && pm2 start <script> --name ${USER_PM2_PREFIX}${pm2Name}`,
        needsRename: true,
        currentName: pm2Name,
        suggestedName: `${USER_PM2_PREFIX}${pm2Name}`,
      });
    }

    const slug = pm2Name.slice(USER_PM2_PREFIX.length);
    exposeConfig.validateSlug(slug);

    // Check if already adopted
    const data = exposeConfig.readExports();
    if (data.exposures.some(e => e.slug === slug)) {
      return res.status(409).json({ error: `Exposure "${slug}" already exists` });
    }

    // Get PM2 process info
    const { execFile } = require('child_process');
    const pm2List = await new Promise((resolve, reject) => {
      execFile('pm2', ['jlist'], { timeout: 5000 }, (err, stdout) => {
        if (err) return reject(new Error('Failed to list PM2 processes'));
        try { resolve(JSON.parse(stdout)); } catch { resolve([]); }
      });
    });

    const proc = pm2List.find(p => p.name === pm2Name);
    if (!proc) {
      return res.status(404).json({ error: `PM2 process "${pm2Name}" not found` });
    }

    const script = proc.pm2_env?.pm_exec_path || null;
    const cwd = script ? path.dirname(script) : (proc.pm2_env?.pm_cwd || proc.pm2_env?.cwd || null);
    const portEnv = proc.pm2_env?.PORT || proc.pm2_env?.env?.PORT || null;
    const port = requestedPort ? Number(requestedPort) : (portEnv ? Number(portEnv) : null);

    if (!port) {
      return res.status(400).json({ error: 'Could not detect port for this process. Please specify a port.' });
    }

    // Handle auth
    let hashedPassword = null;
    let authUser = null;
    let plaintextCredentials = null;
    if (enableAuth) {
      const creds = generateCredentials();
      authUser = creds.username;
      const { hashPassword } = require('../utils/password');
      hashedPassword = hashPassword(creds.password);
      plaintextCredentials = { username: creds.username, password: creds.password };
    }

    // Register exposure
    const entry = exposeConfig.addExposure({
      slug,
      description: description || null,
      type: 'proxy',
      target: `http://127.0.0.1:${port}`,
      authUser,
      password: hashedPassword,
      pm2: {
        name: pm2Name,
        script: script ? path.basename(script) : 'server.js',
        cwd: cwd || null,
        bootstrap: null,
        env: { PORT: String(port) },
      },
    });
    reloadExposeRegistry();

    const publicBase = exposeConfig.getPublicBaseUrl();
    const relUrl = `/open/${slug}/`;
    const response = {
      success: true,
      slug,
      port,
      url: relUrl,
      publicUrl: publicBase ? `${publicBase}${relUrl}` : null,
      exposure: { ...entry, password: entry.password ? '***protected***' : null },
    };
    if (plaintextCredentials) response.credentials = plaintextCredentials;
    res.json(response);
  } catch (err) {
    const status = err.message.includes('already exists') ? 409 : 400;
    res.status(status).json({ error: err.message });
  }
});

// POST /api/openclaw/exposures/:slug/recover-pm2 — detect and attach PM2 config for an exposure missing it
router.post('/exposures/:slug/recover-pm2', async (req, res) => {
  try {
    const { slug } = req.params;
    const data = exposeConfig.readExports();
    const exposure = data.exposures.find(e => e.slug === slug);
    if (!exposure) {
      return res.status(404).json({ error: `Exposure "${slug}" not found` });
    }
    if (exposure.pm2 && exposure.pm2.name) {
      return res.status(400).json({ error: 'Exposure already has PM2 configuration' });
    }

    const expectedName = `${USER_PM2_PREFIX}${slug}`;
    const { execFile } = require('child_process');
    const pm2List = await new Promise((resolve, reject) => {
      execFile('pm2', ['jlist'], { timeout: 5000 }, (err, stdout) => {
        if (err) return reject(new Error('Failed to list PM2 processes'));
        try { resolve(JSON.parse(stdout)); } catch { resolve([]); }
      });
    });

    const proc = pm2List.find(p => p.name === expectedName);
    if (!proc) {
      return res.status(404).json({ error: `No PM2 process named "${expectedName}" found` });
    }

    const script = proc.pm2_env?.pm_exec_path || null;
    const cwd = script ? path.dirname(script) : (proc.pm2_env?.pm_cwd || proc.pm2_env?.cwd || null);
    const portEnv = proc.pm2_env?.PORT || proc.pm2_env?.env?.PORT || null;

    const pm2Config = {
      name: expectedName,
      script: script ? path.basename(script) : 'server.js',
      cwd: cwd || null,
      bootstrap: null,
      env: portEnv ? { PORT: String(portEnv) } : {},
    };

    const updated = exposeConfig.updateExposure(slug, { pm2: pm2Config });
    reloadExposeRegistry();

    res.json({
      success: true,
      slug,
      pm2: pm2Config,
      exposure: { ...updated, password: updated.password ? '***protected***' : null },
    });
  } catch (err) {
    const status = err.message.includes('not found') ? 404 : 500;
    res.status(status).json({ error: err.message });
  }
});

// GET /api/openclaw/exposures/tools-status — check if CLI tool and webapp-projects skill are installed
router.get('/exposures/tools-status', (req, res) => {
  try {
    const marketplace = require('../services/marketplace');
    const cliStatus = marketplace.getItemStatus('openclaw-launcher-cli');
    const skillStatus = marketplace.getItemStatus('webapp-projects');
    res.json({
      cli: { id: 'openclaw-launcher-cli', ...cliStatus },
      skill: { id: 'webapp-projects', ...skillStatus },
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/openclaw/exposures/install-all-tools — install both CLI tool and webapp-projects skill in one call
router.post('/exposures/install-all-tools', async (req, res) => {
  try {
    const marketplace = require('../services/marketplace');
    const results = {};
    const items = ['openclaw-launcher-cli', 'webapp-projects'];
    let cliInstalled = false;
    for (const itemId of items) {
      try {
        const status = marketplace.getItemStatus(itemId);
        if (status.installed) {
          results[itemId] = { success: true, skipped: true };
        } else {
          marketplace.installItem(itemId);
          results[itemId] = { success: true };
          if (itemId === 'openclaw-launcher-cli') cliInstalled = true;
        }
      } catch (err) {
        results[itemId] = { success: false, error: err.message };
      }
    }
    // Auto-configure launcher-cli with fresh auth token after install
    if (cliInstalled) {
      autoConfigureLauncherCli();
    }
    res.json({ success: true, results });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;

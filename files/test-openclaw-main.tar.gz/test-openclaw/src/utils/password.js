const crypto = require('crypto');

const SALT_LENGTH = 16;
const KEY_LENGTH = 32;

function hashPassword(plaintext) {
  const salt = crypto.randomBytes(SALT_LENGTH).toString('hex');
  const hash = crypto.scryptSync(plaintext, salt, KEY_LENGTH).toString('hex');
  return `scrypt:${salt}:${hash}`;
}

function comparePassword(plaintext, stored) {
  if (!stored || !stored.startsWith('scrypt:')) return false;
  const parts = stored.split(':');
  if (parts.length !== 3) return false;
  const salt = parts[1];
  const storedHash = parts[2];
  const hash = crypto.scryptSync(plaintext, salt, KEY_LENGTH).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(hash), Buffer.from(storedHash));
}

module.exports = { hashPassword, comparePassword };

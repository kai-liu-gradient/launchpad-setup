const MAX_AGE_MS = 60 * 60 * 1000; // 1 hour
const MAX_ENTRIES = 5000;

let _history = [];

function _prune() {
  const cutoff = Date.now() - MAX_AGE_MS;
  _history = _history.filter(e => e.timestamp >= cutoff);
  if (_history.length > MAX_ENTRIES) {
    _history = _history.slice(-MAX_ENTRIES);
  }
}

function recordCall(entry) {
  _history.push(entry);
  _prune();
}

function getHistory() {
  _prune();
  return [..._history];
}

function clearHistory() {
  _history = [];
}

function getCount() {
  _prune();
  return _history.length;
}

module.exports = { recordCall, getHistory, clearHistory, getCount };

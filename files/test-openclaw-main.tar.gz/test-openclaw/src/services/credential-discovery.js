const fs = require('fs');
const path = require('path');
const os = require('os');

const CLAUDE_CREDENTIALS_PATH = path.join(os.homedir(), '.claude', '.credentials.json');
const CLAUDE_SETTINGS_PATH = path.join(os.homedir(), '.claude', 'settings.json');
const ZAI_CONFIG_PATH = path.join(os.homedir(), '.claude-code-router', 'config.json');
const OPENCLAW_DIR = path.join(os.homedir(), '.openclaw');
const AGENT_DIR = path.join(OPENCLAW_DIR, 'agents', 'main', 'agent');
const AUTH_PROFILES_PATH = path.join(AGENT_DIR, 'auth-profiles.json');

function maskKey(key) {
  if (!key || key.length < 8) return key ? '****' : null;
  return key.slice(0, 7) + '...' + key.slice(-4);
}

function readJsonFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(content);
  } catch (err) {
    return null;
  }
}

// Kept for reference but no longer included in detectAllCredentials()
// OpenClaw handles Claude CLI OAuth import via external-cli-sync at runtime
function detectClaudeOAuth() {
  const creds = readJsonFile(CLAUDE_CREDENTIALS_PATH);
  if (!creds || !creds.claudeAiOauth) return null;

  const oauth = creds.claudeAiOauth;
  return {
    provider: 'claude-oauth',
    available: true,
    tokenValid: oauth.expiresAt ? Date.now() < oauth.expiresAt : false,
    expiresAt: oauth.expiresAt || null,
    scopes: oauth.scopes || [],
    subscriptionType: oauth.subscriptionType || null,
    rateLimitTier: oauth.rateLimitTier || null,
  };
}

function detectZaiProvider() {
  const config = readJsonFile(ZAI_CONFIG_PATH);
  if (!config || !config.Providers || !Array.isArray(config.Providers)) return null;

  return config.Providers.map(provider => ({
    provider: provider.name,
    available: true,
    baseUrl: provider.api_base_url || null,
    models: provider.models || [],
    hasApiKey: !!provider.api_key,
    maskedKey: maskKey(provider.api_key),
    transformer: provider.transformer || null,
  }));
}

// Model alias mapping for ANTHROPIC_MODEL shorthand values
const CLAUDE_MODEL_ALIASES = {
  'opus': 'claude-opus-4-6',
  'sonnet': 'claude-sonnet-4-6',
  'haiku': 'claude-haiku-4-5-20251001',
};

function resolveClaudeModelAlias(modelHint) {
  if (!modelHint) return null;
  return CLAUDE_MODEL_ALIASES[modelHint.toLowerCase()] || modelHint;
}

function detectClaudeSettings() {
  const settings = readJsonFile(CLAUDE_SETTINGS_PATH);
  if (!settings) return null;

  // env section fields (custom endpoint / API key setups)
  const envSection = settings.env || {};
  const { ANTHROPIC_AUTH_TOKEN, ANTHROPIC_BASE_URL, ANTHROPIC_MODEL } = envSection;

  // Top-level model field (set by Claude Code's own config, e.g. {"model": "opus"})
  const topLevelModel = settings.model || null;

  // Resolve the model: prefer env ANTHROPIC_MODEL, fall back to top-level model
  const rawModelHint = ANTHROPIC_MODEL || topLevelModel;

  // Need at least one of: token, base URL, or model hint to be useful
  if (!ANTHROPIC_AUTH_TOKEN && !ANTHROPIC_BASE_URL && !rawModelHint) return null;

  // Determine auth mode: oauth (from `claude login`) vs api-key
  let authMode = 'api-key';
  const creds = readJsonFile(CLAUDE_CREDENTIALS_PATH);
  if (creds && creds.claudeAiOauth && creds.claudeAiOauth.accessToken) {
    authMode = 'oauth';
  }
  // If the token is explicitly an sk-ant- API key, override to api-key
  // even if stale OAuth data exists
  if (ANTHROPIC_AUTH_TOKEN && ANTHROPIC_AUTH_TOKEN.startsWith('sk-ant-')) {
    authMode = 'api-key';
  }

  // Derive display label from base URL hostname or fall back to generic label
  let sourceLabel;
  if (ANTHROPIC_BASE_URL) {
    try {
      const hostname = new URL(ANTHROPIC_BASE_URL).hostname;
      sourceLabel = `claude (${hostname})`;
    } catch {
      sourceLabel = 'claude (custom endpoint)';
    }
  } else {
    sourceLabel = 'claude (settings)';
  }

  const resolvedModel = resolveClaudeModelAlias(rawModelHint);

  return {
    provider: 'anthropic',
    source: sourceLabel,
    available: true,
    hasApiKey: !!ANTHROPIC_AUTH_TOKEN,
    maskedKey: maskKey(ANTHROPIC_AUTH_TOKEN),
    baseUrl: ANTHROPIC_BASE_URL || null,
    modelHint: resolvedModel,
    modelAlias: rawModelHint || null,
    api: 'anthropic-messages',
    authMode,
  };
}

// Environment variables that OpenClaw checks for provider API keys
const ENV_VAR_PROVIDERS = {
  ANTHROPIC_API_KEY: { provider: 'anthropic', api: 'anthropic-messages', baseUrl: 'https://api.anthropic.com/v1' },
  OPENAI_API_KEY: { provider: 'openai', api: 'openai-completions', baseUrl: 'https://api.openai.com/v1' },
  GEMINI_API_KEY: { provider: 'google', api: 'google-generative-ai', baseUrl: 'https://generativelanguage.googleapis.com/v1beta' },
  OPENROUTER_API_KEY: { provider: 'openrouter', api: 'openai-completions', baseUrl: 'https://openrouter.ai/api/v1' },
  XAI_API_KEY: { provider: 'xai', api: 'openai-completions', baseUrl: 'https://api.x.ai/v1' },
  GROQ_API_KEY: { provider: 'groq', api: 'openai-completions', baseUrl: 'https://api.groq.com/openai/v1' },
  MISTRAL_API_KEY: { provider: 'mistral', api: 'openai-completions', baseUrl: 'https://api.mistral.ai/v1' },
  TOGETHER_API_KEY: { provider: 'together', api: 'openai-completions', baseUrl: 'https://api.together.xyz/v1' },
};

function detectEnvVarProviders() {
  const detected = [];
  for (const [envVar, meta] of Object.entries(ENV_VAR_PROVIDERS)) {
    if (process.env[envVar]) {
      detected.push({
        provider: meta.provider,
        source: `env: ${envVar}`,
        envVar,
        available: true,
        maskedKey: maskKey(process.env[envVar]),
        api: meta.api,
        baseUrl: meta.baseUrl,
      });
    }
  }
  return detected;
}

function detectAllCredentials() {
  const sources = [];

  const zaiProviders = detectZaiProvider();
  if (zaiProviders) {
    zaiProviders.forEach(p => sources.push(p));
  }

  const claudeSettings = detectClaudeSettings();
  if (claudeSettings) {
    sources.push(claudeSettings);
  }

  const envProviders = detectEnvVarProviders();
  envProviders.forEach(p => sources.push(p));

  return {
    detected: sources,
    zaiConfigPath: ZAI_CONFIG_PATH,
    zaiConfigExists: fs.existsSync(ZAI_CONFIG_PATH),
  };
}

function readAuthProfiles() {
  return readJsonFile(AUTH_PROFILES_PATH) || { version: 1, profiles: {} };
}

function writeAuthProfiles(data) {
  if (!fs.existsSync(AGENT_DIR)) {
    fs.mkdirSync(AGENT_DIR, { recursive: true });
  }
  fs.writeFileSync(AUTH_PROFILES_PATH, JSON.stringify(data, null, 2), { mode: 0o600 });
}

function getClaudeOAuthRaw() {
  const creds = readJsonFile(CLAUDE_CREDENTIALS_PATH);
  if (!creds || !creds.claudeAiOauth) return null;
  return creds.claudeAiOauth;
}

function getZaiConfigRaw() {
  return readJsonFile(ZAI_CONFIG_PATH);
}

function getClaudeSettingsRaw() {
  return readJsonFile(CLAUDE_SETTINGS_PATH);
}

module.exports = {
  detectAllCredentials,
  detectClaudeOAuth,
  detectClaudeSettings,
  detectZaiProvider,
  detectEnvVarProviders,
  getClaudeOAuthRaw,
  getZaiConfigRaw,
  getClaudeSettingsRaw,
  resolveClaudeModelAlias,
  readJsonFile,
  readAuthProfiles,
  writeAuthProfiles,
  ENV_VAR_PROVIDERS,
  CLAUDE_MODEL_ALIASES,
  CLAUDE_CREDENTIALS_PATH,
  CLAUDE_SETTINGS_PATH,
  ZAI_CONFIG_PATH,
  AUTH_PROFILES_PATH,
};

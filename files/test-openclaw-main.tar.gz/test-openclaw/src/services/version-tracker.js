/**
 * Version Tracker Service
 *
 * Detects the installed OpenClaw gateway version, persists it to a flag file,
 * reads update-check data, and compares versions.
 *
 * Version Flag File:
 *   Path:        ~/.openclaw/.installed-version
 *   Format:      Plain text, single line, version string only (e.g., "2026.2.14")
 *   Permissions: 0o600
 *   Written by:  OpenClaw Launcher on startup when version changes
 *   Read by:     Restore/reinstall tooling (external)
 *
 * Upgrade Policy (launcher.json → upgradePolicy field):
 *   Values:      "manual" (default) | "auto"
 *   Written by:  Launcher on startup (initialized to "manual") or via PUT /api/openclaw/upgrade-policy
 *   Read by:     External bootstrap/reinstall tooling
 *
 * Bootstrap Decision Logic (for external reinstall/reset tooling):
 *   1. Read ~/.openclaw/.installed-version for the pinned version
 *   2. Read ~/.openclaw/launcher.json for upgradePolicy
 *   3. If .installed-version is missing OR upgradePolicy === "auto":
 *      → Install latest version (npm install openclaw@latest)
 *   4. If .installed-version has a version AND upgradePolicy === "manual":
 *      → Install pinned version (npm install openclaw@<version>)
 */

const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');
const https = require('https');
const http = require('http');
const openclawConfig = require('./openclaw-config');

const OPENCLAW_DIR = path.join(os.homedir(), '.openclaw');
const VERSION_FLAG_FILE = path.join(OPENCLAW_DIR, '.installed-version');
const UPDATE_CHECK_FILE = path.join(OPENCLAW_DIR, 'update-check.json');
const BUILD_INFO_FILE = path.join(__dirname, '..', '..', 'build-info.json');
const PACKAGE_JSON_FILE = path.join(__dirname, '..', '..', 'package.json');

// Cache installed version in memory — it won't change during process lifetime
let _cachedInstalledVersion = null;

// Cache launcher build info in memory — it won't change during process lifetime

/**
 * Compare version strings. Handles YYYY.M.DD format (e.g., "2026.2.14")
 * and semver-style (e.g., "1.0.0") as a fallback.
 * Returns true if `latest` is strictly newer than `current`.
 */
function isNewerVersion(latest, current) {
  if (!latest || !current) return false;
  if (latest === current) return false;

  const latestParts = latest.split('.').map(Number);
  const currentParts = current.split('.').map(Number);

  const maxLen = Math.max(latestParts.length, currentParts.length);
  for (let i = 0; i < maxLen; i++) {
    const l = latestParts[i] || 0;
    const c = currentParts[i] || 0;
    if (isNaN(l) || isNaN(c)) return false;
    if (l > c) return true;
    if (l < c) return false;
  }
  return false;
}

/**
 * Detect the installed OpenClaw version by running `openclaw --version`.
 * Returns the version string (e.g., "2026.2.14") or null on failure.
 */
function detectInstalledVersion() {
  if (_cachedInstalledVersion) return _cachedInstalledVersion;
  try {
    const output = execFileSync('openclaw', ['--version'], {
      encoding: 'utf-8',
      timeout: 5000,
    }).trim();

    // The output may be just a version string, or "openclaw vX.Y.Z", etc.
    // Extract the first version-like pattern: digits separated by dots
    const match = output.match(/(\d+\.\d+(?:\.\d+)*)/);
    if (match) _cachedInstalledVersion = match[1];
    return _cachedInstalledVersion;
  } catch {
    return null;
  }
}

/**
 * Read the persisted version from the flag file at ~/.openclaw/.installed-version.
 * Returns the version string or null if the file doesn't exist.
 */
function readPersistedVersion() {
  try {
    if (!fs.existsSync(VERSION_FLAG_FILE)) return null;
    return fs.readFileSync(VERSION_FLAG_FILE, 'utf-8').trim() || null;
  } catch {
    return null;
  }
}

/**
 * Persist the version string to ~/.openclaw/.installed-version with 0o600 permissions.
 */
function persistVersion(version) {
  if (!version) return;
  // Ensure ~/.openclaw directory exists
  if (!fs.existsSync(OPENCLAW_DIR)) {
    fs.mkdirSync(OPENCLAW_DIR, { recursive: true, mode: 0o700 });
  }
  fs.writeFileSync(VERSION_FLAG_FILE, version + '\n', { mode: 0o600 });
}

/**
 * Read and parse ~/.openclaw/update-check.json.
 * Returns { lastCheckedAt, lastNotifiedVersion, lastNotifiedTag, github } or null.
 */
function readUpdateCheck() {
  try {
    if (!fs.existsSync(UPDATE_CHECK_FILE)) return null;
    const raw = fs.readFileSync(UPDATE_CHECK_FILE, 'utf-8');
    const data = JSON.parse(raw);
    return {
      lastCheckedAt: data.lastCheckedAt || null,
      lastNotifiedVersion: data.lastNotifiedVersion || null,
      lastNotifiedTag: data.lastNotifiedTag || null,
      github: data.github || null,
    };
  } catch {
    return null;
  }
}

/**
 * Fetch the latest version from the npm registry directly.
 * Resolves the registry URL from npm config, falls back to npmjs.org.
 * Returns { latestVersion, latestTag } or null on failure.
 */
async function fetchLatestFromRegistry(timeoutMs = 8000) {
  // Always use official registry for version checks (mirrors may lag behind)
  const url = 'https://registry.npmjs.com/openclaw/latest';

  return new Promise((resolve) => {
    const proto = url.startsWith('https') ? https : http;
    const req = proto.get(url, { timeout: timeoutMs }, (res) => {
      let body = '';
      res.on('data', (chunk) => { body += chunk; });
      res.on('end', () => {
        try {
          const data = JSON.parse(body);
          const version = data.version || null;
          resolve(version ? { latestVersion: version, latestTag: 'latest' } : null);
        } catch {
          resolve(null);
        }
      });
    });
    req.on('error', () => resolve(null));
    req.on('timeout', () => { req.destroy(); resolve(null); });
  });
}

/**
 * Fetch the latest release version from GitHub releases API.
 * Uses https://api.github.com/repos/openclaw/openclaw/releases/latest
 * Returns { latestVersion, latestTag, htmlUrl } or null on failure.
 */
async function fetchLatestFromGitHub(timeoutMs = 8000) {
  const url = 'https://api.github.com/repos/openclaw/openclaw/releases/latest';

  return new Promise((resolve) => {
    const req = https.get(url, {
      timeout: timeoutMs,
      headers: {
        'User-Agent': 'openclaw-launcher',
        'Accept': 'application/vnd.github.v3+json',
      },
    }, (res) => {
      let body = '';
      res.on('data', (chunk) => { body += chunk; });
      res.on('end', () => {
        try {
          const data = JSON.parse(body);
          const tag = data.tag_name || null;
          if (!tag) { resolve(null); return; }
          // Strip leading 'v' if present (e.g. "v2026.2.15" -> "2026.2.15")
          const version = tag.replace(/^v/, '');
          resolve({
            latestVersion: version,
            latestTag: tag,
            htmlUrl: data.html_url || null,
          });
        } catch {
          resolve(null);
        }
      });
    });
    req.on('error', () => resolve(null));
    req.on('timeout', () => { req.destroy(); resolve(null); });
  });
}

/**
 * Write update-check.json with fresh data so subsequent reads are up-to-date.
 * @param {string} latestVersion - npm latest version
 * @param {string} latestTag - npm tag
 * @param {object} [githubResult] - { latestVersion, latestTag, htmlUrl } from GitHub
 */
function writeUpdateCheck(latestVersion, latestTag, githubResult) {
  if (!latestVersion && !githubResult) return;
  try {
    if (!fs.existsSync(OPENCLAW_DIR)) {
      fs.mkdirSync(OPENCLAW_DIR, { recursive: true, mode: 0o700 });
    }
    const data = {
      lastCheckedAt: new Date().toISOString(),
      lastNotifiedVersion: latestVersion || null,
      lastNotifiedTag: latestTag || 'latest',
    };
    if (githubResult) {
      data.github = {
        latestVersion: githubResult.latestVersion,
        latestTag: githubResult.latestTag,
        htmlUrl: githubResult.htmlUrl || null,
      };
    }
    fs.writeFileSync(UPDATE_CHECK_FILE, JSON.stringify(data, null, 2) + '\n', { mode: 0o600 });
  } catch {}
}

/**
 * Trigger an update check: query both npm registry and GitHub releases,
 * persist the results, and return aggregated version info.
 */
async function checkForUpdate() {
  const [registryResult, githubResult] = await Promise.all([
    fetchLatestFromRegistry(),
    fetchLatestFromGitHub(),
  ]);
  if (registryResult || githubResult) {
    writeUpdateCheck(
      registryResult?.latestVersion || null,
      registryResult?.latestTag || null,
      githubResult,
    );
  }
  return getVersionInfo();
}

/**
 * Read launcher build info (version from package.json and build timestamp).
 * Returns { version, buildTime, uiBuildVersion } or nulls for each field.
 * - version: current package.json version (source of truth)
 * - uiBuildVersion: version baked into the frontend at last Vite build (from build-info.json)
 * - buildTime: ISO timestamp of the last frontend build
 * When version !== uiBuildVersion, the UI was not rebuilt after a version bump.
 */
function getLauncherBuildInfo() {
  let version = null;
  let buildTime = null;
  let uiBuildVersion = null;

  // Always read version directly from package.json (source of truth)
  try {
    const pkg = JSON.parse(fs.readFileSync(PACKAGE_JSON_FILE, 'utf-8'));
    version = pkg.version || null;
  } catch {}

  // Read build timestamp and version from build-info.json (generated at build time)
  try {
    const data = JSON.parse(fs.readFileSync(BUILD_INFO_FILE, 'utf-8'));
    buildTime = data.buildTime || null;
    uiBuildVersion = data.version || null;
  } catch {}

  return { version, buildTime, uiBuildVersion };
}

/**
 * Aggregate version info for the API response.
 * Returns both npm and GitHub latest versions for comparison.
 */
function getVersionInfo() {
  const installedVersion = detectInstalledVersion();
  const persistedVersion = readPersistedVersion();
  const updateCheck = readUpdateCheck();

  const latestVersion = updateCheck?.lastNotifiedVersion || null;
  const latestTag = updateCheck?.lastNotifiedTag || null;
  const lastCheckedAt = updateCheck?.lastCheckedAt || null;

  // GitHub release info
  const github = updateCheck?.github || null;
  const githubLatestVersion = github?.latestVersion || null;
  const githubLatestTag = github?.latestTag || null;
  const githubHtmlUrl = github?.htmlUrl || null;

  // Update available if either source reports a newer version
  const npmUpdateAvailable = !!(installedVersion && latestVersion && isNewerVersion(latestVersion, installedVersion));
  const githubUpdateAvailable = !!(installedVersion && githubLatestVersion && isNewerVersion(githubLatestVersion, installedVersion));
  const updateAvailable = npmUpdateAvailable || githubUpdateAvailable;

  const launcher = getLauncherBuildInfo();
  const latestVersionOverride = readPersistedVersion();

  return {
    installedVersion,
    persistedVersion,
    latestVersionOverride,
    npm: latestVersion ? { latestVersion, latestTag } : null,
    github: githubLatestVersion ? { latestVersion: githubLatestVersion, latestTag: githubLatestTag, htmlUrl: githubHtmlUrl } : null,
    launcher,
    // Keep flat fields for backward compat
    latestVersion,
    latestTag,
    lastCheckedAt,
    updateAvailable,
  };
}

/**
 * Get the persisted version with its file modification timestamp.
 */
function getPersistedVersionInfo() {
  const version = readPersistedVersion();
  if (!version) return { version: null, persistedAt: null };

  let persistedAt = null;
  try {
    const stat = fs.statSync(VERSION_FLAG_FILE);
    persistedAt = stat.mtime.toISOString();
  } catch {}

  return { version, persistedAt };
}

/**
 * Auto-persist: detect the installed version and write the flag file if needed.
 * Called on server startup.
 */
function autoPersistVersion() {
  const installed = detectInstalledVersion();
  if (!installed) {
    console.log('[version-tracker] OpenClaw CLI not found or --version failed');
    return null;
  }

  const persisted = readPersistedVersion();
  if (!persisted || persisted !== installed) {
    persistVersion(installed);
    if (!persisted) {
      console.log(`[version-tracker] OpenClaw version: ${installed} (first persist)`);
    } else {
      console.log(`[version-tracker] OpenClaw version: ${installed} (upgraded from ${persisted})`);
    }
  } else {
    console.log(`[version-tracker] OpenClaw version: ${installed} (persisted)`);
  }

  // Initialize upgradePolicy in launcher.json if missing
  const launcherConfig = openclawConfig.readLauncherConfig() || {};
  if (!launcherConfig.upgradePolicy) {
    launcherConfig.upgradePolicy = 'manual';
    openclawConfig.writeLauncherConfig(launcherConfig);
    console.log('[version-tracker] Upgrade policy initialized: manual');
  }

  return installed;
}

module.exports = {
  detectInstalledVersion,
  readPersistedVersion,
  persistVersion,
  readUpdateCheck,
  getVersionInfo,
  getLauncherBuildInfo,
  getPersistedVersionInfo,
  isNewerVersion,
  autoPersistVersion,
  fetchLatestFromRegistry,
  fetchLatestFromGitHub,
  checkForUpdate,
};

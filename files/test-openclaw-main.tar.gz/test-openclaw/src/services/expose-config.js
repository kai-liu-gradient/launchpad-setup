const fs = require('fs');
const path = require('path');
const os = require('os');
const yaml = require('js-yaml');

const OPENCLAW_ROOT = path.join(os.homedir(), '.openclaw');
const EXPORTS_PATH = path.join(OPENCLAW_ROOT, 'exports.yaml');
const WORKSPACE_ROOT = path.join(OPENCLAW_ROOT, 'workspace');

// Discover the public base URL from the PM2 ecosystem config
let _cachedPublicBaseUrl = null;
function getPublicBaseUrl() {
  if (_cachedPublicBaseUrl !== null) return _cachedPublicBaseUrl;
  try {
    const ecoPath = path.join(os.homedir(), '.pm2', 'ecosystem.ani-code-daemon.config.js');
    if (fs.existsSync(ecoPath)) {
      // Read and evaluate the ecosystem config to extract PUBLIC_URL
      const content = fs.readFileSync(ecoPath, 'utf-8');
      const match = content.match(/"PUBLIC_URL"\s*:\s*"([^"]+)"/);
      if (match) {
        const publicUrl = new URL(match[1]);
        _cachedPublicBaseUrl = publicUrl.origin;
        return _cachedPublicBaseUrl;
      }
    }
  } catch { /* ignore — fallback to null */ }
  _cachedPublicBaseUrl = '';
  return '';
}

// Reserved route prefixes that cannot be used as slugs
const RESERVED_SLUGS = ['gateway', 'api', 'control', 'health', 'open', 'feishu'];

// Slug format: lowercase alphanumeric with hyphens
const SLUG_REGEX = /^[a-z0-9][a-z0-9-]*[a-z0-9]$|^[a-z0-9]$/;

// Allowed proxy target hosts (SSRF protection)
const ALLOWED_PROXY_HOSTS = ['127.0.0.1', 'localhost', '::1'];

function readExports() {
  try {
    const raw = fs.readFileSync(EXPORTS_PATH, 'utf-8');
    const data = yaml.load(raw);
    if (!data || !Array.isArray(data.exposures)) {
      return { exposures: [] };
    }
    return data;
  } catch (err) {
    if (err.code === 'ENOENT') {
      return { exposures: [] };
    }
    throw new Error(`Failed to read exports.yaml: ${err.message}`);
  }
}

function writeExports(data) {
  // Ensure directory exists
  if (!fs.existsSync(OPENCLAW_ROOT)) {
    fs.mkdirSync(OPENCLAW_ROOT, { recursive: true });
  }
  const content = yaml.dump(data, { lineWidth: 120, noRefs: true });
  const tmpPath = EXPORTS_PATH + '.tmp';
  fs.writeFileSync(tmpPath, content, { mode: 0o600 });
  fs.renameSync(tmpPath, EXPORTS_PATH);
}

function validateSlug(slug) {
  if (!slug || typeof slug !== 'string') {
    throw new Error('Slug is required');
  }
  if (!SLUG_REGEX.test(slug)) {
    throw new Error(`Invalid slug "${slug}": must be lowercase alphanumeric with hyphens (e.g., "my-service-1")`);
  }
  if (slug.length > 64) {
    throw new Error('Slug must be 64 characters or fewer');
  }
  if (RESERVED_SLUGS.includes(slug)) {
    throw new Error(`Slug "${slug}" is reserved and cannot be used`);
  }
}

function validateProxyTarget(target) {
  if (!target || typeof target !== 'string') {
    throw new Error('Proxy target URL is required');
  }
  let parsed;
  try {
    parsed = new URL(target);
  } catch {
    throw new Error(`Invalid proxy target URL: "${target}"`);
  }
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    throw new Error('Proxy target must use http:// or https:// protocol');
  }
  if (!ALLOWED_PROXY_HOSTS.includes(parsed.hostname)) {
    throw new Error(`Proxy target host "${parsed.hostname}" is not allowed. Only ${ALLOWED_PROXY_HOSTS.join(', ')} are permitted (SSRF protection)`);
  }
  if (!parsed.port) {
    throw new Error('Proxy target must include an explicit port (e.g., http://127.0.0.1:8080)');
  }
}

function validateStaticPath(relativePath) {
  if (!relativePath || typeof relativePath !== 'string') {
    throw new Error('Static path is required');
  }
  // Must not start with / or contain ..
  if (relativePath.startsWith('/') || relativePath.includes('..')) {
    throw new Error(`Invalid static path "${relativePath}": must be a relative path without ".." components`);
  }
  const resolved = path.resolve(WORKSPACE_ROOT, relativePath);
  if (!resolved.startsWith(WORKSPACE_ROOT)) {
    throw new Error(`Static path "${relativePath}" escapes workspace root (path traversal blocked)`);
  }
  return resolved;
}

function validateExposure(entry) {
  validateSlug(entry.slug);

  if (entry.type !== 'proxy' && entry.type !== 'static') {
    throw new Error(`Invalid exposure type "${entry.type}": must be "proxy" or "static"`);
  }

  if (entry.type === 'proxy') {
    validateProxyTarget(entry.target);
  } else if (entry.type === 'static') {
    validateStaticPath(entry.path);
  }
}

function addExposure(entry) {
  const data = readExports();

  // Check for duplicate slug
  if (data.exposures.some(e => e.slug === entry.slug)) {
    throw new Error(`Exposure with slug "${entry.slug}" already exists`);
  }

  validateExposure(entry);

  const newEntry = {
    slug: entry.slug,
    description: entry.description || null,
    type: entry.type,
    ...(entry.type === 'proxy' ? { target: entry.target } : { path: entry.path }),
    authUser: entry.authUser || null,
    password: entry.password || null,
    enabled: true,
    created: new Date().toISOString(),
    // PM2 management fields (optional)
    pm2: entry.pm2 || null,
  };

  data.exposures.push(newEntry);
  writeExports(data);
  return newEntry;
}

function removeExposure(slug) {
  const data = readExports();
  const index = data.exposures.findIndex(e => e.slug === slug);
  if (index === -1) {
    throw new Error(`Exposure with slug "${slug}" not found`);
  }
  const removed = data.exposures.splice(index, 1)[0];
  writeExports(data);
  return removed;
}

function toggleExposure(slug, enabled) {
  const data = readExports();
  const entry = data.exposures.find(e => e.slug === slug);
  if (!entry) {
    throw new Error(`Exposure with slug "${slug}" not found`);
  }
  entry.enabled = enabled;
  writeExports(data);
  return entry;
}

function updateExposure(slug, patch) {
  const data = readExports();
  const entry = data.exposures.find(e => e.slug === slug);
  if (!entry) {
    throw new Error(`Exposure with slug "${slug}" not found`);
  }

  // Apply allowed patches
  if (patch.enabled !== undefined) entry.enabled = patch.enabled;
  if (patch.description !== undefined) entry.description = patch.description || null;
  if (patch.authUser !== undefined) entry.authUser = patch.authUser;
  if (patch.password !== undefined) entry.password = patch.password;
  if (patch.target !== undefined && entry.type === 'proxy') {
    validateProxyTarget(patch.target);
    entry.target = patch.target;
  }
  if (patch.path !== undefined && entry.type === 'static') {
    validateStaticPath(patch.path);
    entry.path = patch.path;
  }
  if (patch.pm2 !== undefined) entry.pm2 = patch.pm2;

  writeExports(data);
  return entry;
}

function renameExposure(oldSlug, newSlug) {
  const data = readExports();
  const entry = data.exposures.find(e => e.slug === oldSlug);
  if (!entry) {
    throw new Error(`Exposure with slug "${oldSlug}" not found`);
  }
  if (oldSlug === newSlug) return entry;
  validateSlug(newSlug);
  if (data.exposures.some(e => e.slug === newSlug)) {
    throw new Error(`Exposure with slug "${newSlug}" already exists`);
  }
  entry.slug = newSlug;
  // Update PM2 process name if managed
  if (entry.pm2 && entry.pm2.name) {
    entry.pm2.name = `user-${newSlug}`;
  }
  writeExports(data);
  return entry;
}

function sanitizeExposures(data) {
  return {
    exposures: data.exposures.map(e => ({
      ...e,
      authUser: e.authUser || null,
      password: e.password ? '***protected***' : null,
      pm2: e.pm2 || null,
    })),
  };
}

module.exports = {
  readExports,
  writeExports,
  validateSlug,
  validateProxyTarget,
  validateStaticPath,
  validateExposure,
  addExposure,
  removeExposure,
  toggleExposure,
  updateExposure,
  renameExposure,
  sanitizeExposures,
  getPublicBaseUrl,
  EXPORTS_PATH,
  WORKSPACE_ROOT,
  RESERVED_SLUGS,
  ALLOWED_PROXY_HOSTS,
};

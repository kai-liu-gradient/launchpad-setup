const { createProxyMiddleware } = require('http-proxy-middleware');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const os = require('os');
const http = require('http');

const OPENCLAW_CONFIG_PATH = path.join(os.homedir(), '.openclaw', 'openclaw.json');
const DEFAULT_GATEWAY_PORT = 18789;
const DEFAULT_GATEWAY_HOST = '127.0.0.1';

function getGatewayTarget() {
  let port = DEFAULT_GATEWAY_PORT;
  try {
    const raw = fs.readFileSync(OPENCLAW_CONFIG_PATH, 'utf-8');
    const config = JSON.parse(raw);
    if (config.gateway && config.gateway.port) {
      port = config.gateway.port;
    }
  } catch {
    // Config not found or invalid — use default
  }
  return { host: DEFAULT_GATEWAY_HOST, port };
}

function createGatewayProxy() {
  const proxy = createProxyMiddleware({
    router: () => {
      const { host, port } = getGatewayTarget();
      return `http://${host}:${port}`;
    },
    changeOrigin: true,
    pathRewrite: { '^/gateway': '' },
    // ws: false — WebSocket upgrades are handled manually in server.js
    // to avoid conflicts with the shell terminal WebSocket server
    ws: false,
    on: {
      proxyReq: (proxyReq) => {
        // Rewrite headers so the gateway recognizes this as a local connection.
        // The gateway checks Host + absence of forwarded headers to determine isLocalClient.
        const { host, port } = getGatewayTarget();
        proxyReq.setHeader('origin', `http://${host}:${port}`);
        proxyReq.removeHeader('x-forwarded-for');
        proxyReq.removeHeader('x-forwarded-host');
        proxyReq.removeHeader('x-forwarded-proto');
        proxyReq.removeHeader('x-real-ip');
      },
      proxyReqWs: (proxyReq, req, socket) => {
        console.log(`[Gateway WS] Upgrade request: ${req.url}`);
        socket.on('error', (err) => {
          console.error(`[Gateway WS] Socket error: ${err.message}`);
        });
      },
      proxyRes: (proxyRes) => {
        // Strip restrictive headers so the Control UI can be served through the launcher
        delete proxyRes.headers['x-frame-options'];
        delete proxyRes.headers['X-Frame-Options'];

        // Rewrite CSP to remove frame-ancestors restriction
        const csp = proxyRes.headers['content-security-policy'];
        if (csp) {
          proxyRes.headers['content-security-policy'] = csp
            .replace(/frame-ancestors\s+[^;]+;?\s*/gi, '');
        }
      },
      error: (err, req, res) => {
        console.error(`[Gateway Proxy] Error: ${err.code || err.message}`);
        // Handle WebSocket upgrade errors — res may be a socket, not an HTTP response
        if (res && res.writeHead && !res.headersSent) {
          res.writeHead(502, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({
            error: 'Gateway Unreachable',
            message: 'Cannot connect to OpenClaw gateway. Is it running?',
          }));
        } else if (res && res.writable && !res.destroyed) {
          // WebSocket upgrade failure — write HTTP 502 to raw socket and close
          const body = 'HTTP/1.1 502 Bad Gateway\r\n\r\n';
          res.end(body);
        }
      },
    },
  });

  return proxy;
}

function probeGatewayWebSocket(timeout = 10000) {
  return new Promise((resolve) => {
    const { host, port } = getGatewayTarget();
    const req = http.request({
      host,
      port,
      path: '/',
      method: 'GET',
      headers: {
        'Connection': 'Upgrade',
        'Upgrade': 'websocket',
        'Sec-WebSocket-Key': crypto.randomBytes(16).toString('base64'),
        'Sec-WebSocket-Version': '13',
      },
      timeout,
    });

    req.on('upgrade', (res, socket) => {
      socket.destroy();
      resolve({ wsUpgrade: true, statusCode: 101 });
    });

    req.on('response', (res) => {
      // Gateway responded with HTTP, not upgrade — still reachable
      res.resume();
      resolve({ wsUpgrade: false, statusCode: res.statusCode });
    });

    req.on('error', () => {
      resolve({ wsUpgrade: false, statusCode: null, error: 'Connection refused' });
    });

    req.on('timeout', () => {
      req.destroy();
      resolve({ wsUpgrade: false, statusCode: null, error: 'Timeout' });
    });

    req.end();
  });
}

module.exports = {
  getGatewayTarget,
  createGatewayProxy,
  probeGatewayWebSocket,
  DEFAULT_GATEWAY_PORT,
  DEFAULT_GATEWAY_HOST,
};

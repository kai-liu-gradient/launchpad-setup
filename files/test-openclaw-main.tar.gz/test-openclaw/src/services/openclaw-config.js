const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

const OPENCLAW_DIR = path.join(os.homedir(), '.openclaw');
const OPENCLAW_CONFIG_PATH = path.join(OPENCLAW_DIR, 'openclaw.json');
const OPENCLAW_WORKSPACE = path.join(OPENCLAW_DIR, 'workspace');
const LAUNCHER_CONFIG_PATH = path.join(OPENCLAW_DIR, 'launcher.json');

const REQUIRED_SECTIONS = ['gateway', 'agents', 'auth'];

function ensureDir(dirPath) {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
}

function readConfig() {
  try {
    const content = fs.readFileSync(OPENCLAW_CONFIG_PATH, 'utf-8');
    return JSON.parse(content);
  } catch (err) {
    return null;
  }
}

function readLauncherConfig() {
  try {
    const content = fs.readFileSync(LAUNCHER_CONFIG_PATH, 'utf-8');
    return JSON.parse(content);
  } catch (err) {
    return null;
  }
}

function writeLauncherConfig(config) {
  ensureDir(OPENCLAW_DIR);
  fs.writeFileSync(LAUNCHER_CONFIG_PATH, JSON.stringify(config, null, 2), { mode: 0o600 });
}

function getLauncherPassword() {
  const launcherConfig = readLauncherConfig();
  return launcherConfig?.auth?.password || null;
}

function setLauncherPassword(password) {
  const launcherConfig = readLauncherConfig() || {};
  launcherConfig.auth = launcherConfig.auth || {};
  launcherConfig.auth.password = password;
  writeLauncherConfig(launcherConfig);
}

function writeConfig(config) {
  ensureDir(OPENCLAW_DIR);
  // Enforce hot reload mode so config file changes don't trigger the gateway
  // to auto-restart as a daemon (hybrid mode default).  The launcher manages
  // gateway restarts via PM2 explicitly when needed.
  if (config.gateway) {
    config.gateway.reload = { mode: 'hot' };
  }
  fs.writeFileSync(OPENCLAW_CONFIG_PATH, JSON.stringify(config, null, 2), { mode: 0o600 });
}

function validateConfig(config) {
  const errors = [];
  const warnings = [];

  if (!config || typeof config !== 'object') {
    return { valid: false, errors: ['Config must be a non-null object'], warnings };
  }

  if (config.gateway) {
    if (config.gateway.port && (typeof config.gateway.port !== 'number' || config.gateway.port < 1 || config.gateway.port > 65535)) {
      errors.push('gateway.port must be a number between 1 and 65535');
    }
    const validBindModes = ['auto', 'lan', 'loopback', 'custom', 'tailnet'];
    if (config.gateway.bind && !validBindModes.includes(config.gateway.bind)) {
      errors.push(`gateway.bind must be one of: ${validBindModes.join(', ')}`);
    }
  }

  if (config.agents && config.agents.defaults) {
    if (config.agents.defaults.maxConcurrent && typeof config.agents.defaults.maxConcurrent !== 'number') {
      errors.push('agents.defaults.maxConcurrent must be a number');
    }
    const validThinkingLevels = ['off', 'minimal', 'low', 'medium', 'high'];
    if (config.agents.defaults.thinkingDefault && !validThinkingLevels.includes(config.agents.defaults.thinkingDefault)) {
      errors.push(`agents.defaults.thinkingDefault must be one of: ${validThinkingLevels.join(', ')}`);
    }
  }

  // Validate telegram channel accounts — content checks are warnings only (non-blocking)
  if (config.channels && config.channels.telegram && config.channels.telegram.accounts) {
    const validAccountKeys = [
      'name', 'capabilities', 'markdown', 'enabled', 'commands', 'customCommands',
      'configWrites', 'dmPolicy', 'botToken', 'tokenFile', 'replyToMode', 'groups',
      'allowFrom', 'groupAllowFrom', 'groupPolicy', 'historyLimit', 'dmHistoryLimit',
      'dms', 'textChunkLimit', 'chunkMode', 'blockStreaming', 'draftChunk',
      'blockStreamingCoalesce', 'streamMode', 'streaming', 'mediaMaxMb', 'timeoutSeconds',
      'retry', 'network', 'proxy', 'webhookUrl', 'webhookSecret', 'webhookPath',
      'actions', 'reactionNotifications', 'reactionLevel', 'heartbeat', 'linkPreview',
      'responsePrefix',
    ];
    for (const accountName of Object.keys(config.channels.telegram.accounts)) {
      const account = config.channels.telegram.accounts[accountName];
      if (account && typeof account === 'object') {
        const unrecognized = Object.keys(account).filter(k => !validAccountKeys.includes(k));
        if (unrecognized.length > 0) {
          warnings.push(`channels.telegram.accounts.${accountName}: Unrecognized keys: ${unrecognized.map(k => `"${k}"`).join(', ')}`);
        }
        if (account.dmPolicy) {
          const validDmPolicies = ['pairing', 'allowlist', 'open', 'disabled'];
          if (!validDmPolicies.includes(account.dmPolicy)) {
            warnings.push(`channels.telegram.accounts.${accountName}.dmPolicy: unrecognized value "${account.dmPolicy}" (expected: ${validDmPolicies.join(', ')})`);
          }
        }
        if (account.streamMode) {
          const validStreamModes = ['off', 'partial', 'block'];
          if (!validStreamModes.includes(account.streamMode)) {
            warnings.push(`channels.telegram.accounts.${accountName}.streamMode: unrecognized value "${account.streamMode}" (expected: ${validStreamModes.join(', ')})`);
          }
        }
        if (account.historyLimit !== undefined && (typeof account.historyLimit !== 'number' || !Number.isInteger(account.historyLimit) || account.historyLimit < 0)) {
          warnings.push(`channels.telegram.accounts.${accountName}.historyLimit should be a non-negative integer`);
        }
      }
    }
  }

  return { valid: errors.length === 0, errors, warnings };
}

function sanitizeConfig(config) {
  if (!config) return null;

  const sanitized = JSON.parse(JSON.stringify(config));

  // Mask tokens in gateway auth
  if (sanitized.gateway && sanitized.gateway.auth && sanitized.gateway.auth.token) {
    sanitized.gateway.auth.token = '***masked***';
  }

  // Mask tokens in channel configs
  if (sanitized.channels) {
    for (const channelType of Object.keys(sanitized.channels)) {
      const channel = sanitized.channels[channelType];
      // Flat channel config (e.g. feishu)
      if (channel.appSecret) {
        channel.appSecret = '***masked***';
      }
      if (channel.botToken) {
        channel.botToken = '***masked***';
      }
      // Nested accounts config (e.g. telegram)
      if (channel.accounts) {
        for (const accountName of Object.keys(channel.accounts)) {
          if (channel.accounts[accountName].botToken) {
            channel.accounts[accountName].botToken = '***masked***';
          }
          if (channel.accounts[accountName].appSecret) {
            channel.accounts[accountName].appSecret = '***masked***';
          }
        }
      }
    }
  }

  // Mask auth profile credentials
  if (sanitized.auth && sanitized.auth.profiles) {
    for (const profileName of Object.keys(sanitized.auth.profiles)) {
      const profile = sanitized.auth.profiles[profileName];
      if (profile.apiKey) profile.apiKey = '***masked***';
      if (profile.token) profile.token = '***masked***';
      if (profile.accessToken) profile.accessToken = '***masked***';
      if (profile.refreshToken) profile.refreshToken = '***masked***';
    }
  }

  return sanitized;
}

const WEAK_TOKENS = ['dummy', 'change-me', 'test', 'token', 'changeme', 'password', 'secret'];

function generateSecureToken() {
  return crypto.randomBytes(24).toString('hex');
}

function generateLauncherPassword() {
  return crypto.randomBytes(24).toString('base64url');
}

const INIT_FLAG_PATH = path.join(OPENCLAW_DIR, '.launcher-init');

function hasInitFlag() {
  return fs.existsSync(INIT_FLAG_PATH);
}

function createInitFlag() {
  ensureDir(OPENCLAW_DIR);
  fs.writeFileSync(INIT_FLAG_PATH, new Date().toISOString(), { mode: 0o600 });
}

function removeInitFlag() {
  try {
    fs.unlinkSync(INIT_FLAG_PATH);
  } catch (err) {
    // ignore if already removed
  }
}

function checkTokenStrength(token) {
  if (!token) return { strength: 'missing', warning: 'No gateway auth token configured' };
  if (WEAK_TOKENS.includes(token.toLowerCase())) return { strength: 'weak', warning: `Gateway token is a known weak value ("${token}")` };
  if (token.length < 32) return { strength: 'weak', warning: `Gateway token is too short (${token.length} chars, minimum 32)` };
  return { strength: 'strong', warning: null };
}

function createDefaultConfig(detectedProvider) {
  const config = {
    meta: {
      lastTouchedVersion: '1.0.0',
      lastTouchedAt: new Date().toISOString(),
    },
    gateway: {
      mode: 'local',
      port: 18789,
      bind: 'loopback',
      reload: { mode: 'hot' },
      auth: {
        mode: 'token',
      },
    },
    agents: {
      defaults: {
        workspace: OPENCLAW_WORKSPACE,
        thinkingDefault: 'off',
        compaction: { mode: 'safeguard' },
        maxConcurrent: 4,
        subagents: { maxConcurrent: 8 },
      },
    },
    discovery: {
      mdns: { mode: 'off' },
    },
    auth: {
      profiles: {},
    },
  };

  if (detectedProvider) {
    if (detectedProvider.provider === 'zai') {
      // Only set the auth profile reference — model selection is handled
      // explicitly by credentials/apply or the Config page.
      config.auth.profiles['zai:default'] = {
        provider: 'zai',
        mode: 'api_key',
      };
    }
  }

  return config;
}

function mergeConfig(existing, patch) {
  const merged = JSON.parse(JSON.stringify(existing));

  for (const key of Object.keys(patch)) {
    if (Array.isArray(patch[key]) && Array.isArray(merged[key])) {
      // Additive array merge: union with dedup (preserves existing order, appends new)
      const set = new Set(merged[key]);
      for (const v of patch[key]) {
        if (!set.has(v)) {
          merged[key].push(v);
          set.add(v);
        }
      }
    } else if (patch[key] && typeof patch[key] === 'object' && !Array.isArray(patch[key]) && merged[key] && typeof merged[key] === 'object') {
      merged[key] = mergeConfig(merged[key], patch[key]);
    } else {
      merged[key] = JSON.parse(JSON.stringify(patch[key]));
    }
  }

  return merged;
}

/**
 * Reverse a previously-applied config patch.
 * - Arrays: removes items that were in the patch
 * - Objects: recurses; removes keys that become empty objects after un-merge
 * - Scalars: removes the key entirely (we can't know the previous value)
 */
function unmergeConfig(existing, patch) {
  const result = JSON.parse(JSON.stringify(existing));

  for (const key of Object.keys(patch)) {
    if (!(key in result)) continue;

    if (Array.isArray(patch[key]) && Array.isArray(result[key])) {
      // Remove items that the patch added
      const toRemove = new Set(patch[key]);
      result[key] = result[key].filter(v => !toRemove.has(v));
      // Clean up empty arrays
      if (result[key].length === 0) delete result[key];
    } else if (patch[key] && typeof patch[key] === 'object' && !Array.isArray(patch[key])
               && result[key] && typeof result[key] === 'object' && !Array.isArray(result[key])) {
      result[key] = unmergeConfig(result[key], patch[key]);
      // Clean up empty objects
      if (Object.keys(result[key]).length === 0) delete result[key];
    } else {
      // Scalar — remove the key (can't restore original value)
      delete result[key];
    }
  }

  return result;
}

module.exports = {
  readConfig,
  writeConfig,
  validateConfig,
  sanitizeConfig,
  createDefaultConfig,
  mergeConfig,
  unmergeConfig,
  generateSecureToken,
  generateLauncherPassword,
  checkTokenStrength,
  hasInitFlag,
  createInitFlag,
  removeInitFlag,
  readLauncherConfig,
  writeLauncherConfig,
  getLauncherPassword,
  setLauncherPassword,
  WEAK_TOKENS,
  OPENCLAW_DIR,
  OPENCLAW_CONFIG_PATH,
  OPENCLAW_WORKSPACE,
  LAUNCHER_CONFIG_PATH,
};

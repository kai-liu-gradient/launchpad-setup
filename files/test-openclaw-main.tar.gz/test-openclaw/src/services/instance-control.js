const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const openclawConfig = require('./openclaw-config');

// Instance state machine
const STATES = {
  AVAILABLE: 'AVAILABLE',
  PROVISIONING: 'PROVISIONING',
  ACTIVE: 'ACTIVE',
  TERMINATED: 'TERMINATED',
};

// Valid state transitions
const VALID_TRANSITIONS = {
  [STATES.AVAILABLE]: [STATES.PROVISIONING, STATES.TERMINATED],
  [STATES.PROVISIONING]: [STATES.ACTIVE, STATES.TERMINATED],
  [STATES.ACTIVE]: [STATES.TERMINATED],
  [STATES.TERMINATED]: [],
};
// Error codes per spec
const ERROR_CODES = {
  INVALID_PARAMETERS: 'INVALID_PARAMETERS',
  UNAUTHORIZED: 'UNAUTHORIZED',
  INSTANCE_NOT_FOUND: 'INSTANCE_NOT_FOUND',
  INVALID_STATE: 'INVALID_STATE',
  NO_CAPACITY: 'NO_CAPACITY',
  ALREADY_ALLOCATED: 'ALREADY_ALLOCATED',
  UNSUPPORTED_MODEL: 'UNSUPPORTED_MODEL',
  SAME_TIER: 'SAME_TIER',
  INSTANCE_UNAVAILABLE: 'INSTANCE_UNAVAILABLE',
};

function getManagedPoolConfig() {
  const launcher = openclawConfig.readLauncherConfig();
  return launcher?.managedPool || null;
}

function updateManagedPoolConfig(updates) {
  const launcher = openclawConfig.readLauncherConfig() || {};
  launcher.managedPool = { ...(launcher.managedPool || {}), ...updates };
  openclawConfig.writeLauncherConfig(launcher);
  return launcher.managedPool;
}

function getInstanceId() {
  const pool = getManagedPoolConfig();
  return pool?.instanceId || null;
}

function getStatus() {
  const pool = getManagedPoolConfig();
  return pool?.status || null;
}

function isEnabled() {
  const pool = getManagedPoolConfig();
  return pool?.enabled === true;
}

function canTransition(from, to) {
  if (!VALID_TRANSITIONS[from]) return false;
  return VALID_TRANSITIONS[from].includes(to);
}

function transitionState(targetState, { internal = false } = {}) {
  const current = getStatus();
  // Allow TERMINATED → AVAILABLE only for internal reset flows
  const allowed = canTransition(current, targetState) ||
    (internal && current === STATES.TERMINATED && targetState === STATES.AVAILABLE);
  if (!allowed) {
    return { success: false, code: ERROR_CODES.INVALID_STATE, from: current, to: targetState };
  }
  updateManagedPoolConfig({ status: targetState });
  return { success: true, from: current, to: targetState };
}

// Adoption key generation (Task 8)
function generateControlKey() {
  return crypto.randomBytes(32).toString('hex');
}

function generateAdoptionToken() {
  return crypto.randomBytes(24).toString('hex');
}

// Default failure tracking fields
const FAILURE_DEFAULTS = {
  failedAttempts: 0,
  lastFailure: null,
  failureLog: [],
};

function getEcosystemPublicUrl() {
  try {
    const ecosystemPath = path.join(os.homedir(), '.pm2', 'ecosystem.ani-code-daemon.config.js');
    const content = fs.readFileSync(ecosystemPath, 'utf-8');
    const match = content.match(/"PUBLIC_URL"\s*:\s*"([^"]+)"/);
    if (match) return match[1];
  } catch {}
  return null;
}

function generateInstanceId() {
  const publicUrl = process.env.PUBLIC_URL || getEcosystemPublicUrl();
  if (publicUrl) {
    try {
      const url = new URL(publicUrl);
      return url.hostname;
    } catch {}
  }
  const hostname = process.env.HOSTNAME || os.hostname();
  return hostname + '-' + crypto.randomBytes(2).toString('hex');
}

// Enable managed pool adoption (Task 8)
function enableAdoption() {
  const pool = getManagedPoolConfig();
  if (pool?.enabled) {
    return { alreadyEnabled: true, managedPool: pool };
  }

  const controlKey = generateControlKey();
  const adoptionToken = generateAdoptionToken();
  const instanceId = generateInstanceId();

  const managedPool = updateManagedPoolConfig({
    enabled: true,
    controlKey,
    adoptionToken,
    instanceId,
    isAdopted: false,
    status: null, // Not yet adopted
    adoptedAt: null,
    adoptionConsumedAt: null,
    modelId: null,
    userId: null,
    ...FAILURE_DEFAULTS,
  });

  return { alreadyEnabled: false, managedPool };
}

// Disable/revoke adoption (Task 10)
function disableAdoption() {
  const launcher = openclawConfig.readLauncherConfig() || {};

  // Warn and stop gateway if instance is actively serving a user
  const currentStatus = launcher.managedPool?.status;
  if (currentStatus === STATES.ACTIVE || currentStatus === STATES.PROVISIONING) {
    console.warn(`[Instance Control] Disabling adoption while instance is ${currentStatus} — stopping gateway`);
    try {
      const { execSync } = require('child_process');
      execSync('pm2 stop openclaw-gateway', { encoding: 'utf-8', timeout: 10000 });
    } catch (stopErr) {
      console.error('[Instance Control] Failed to stop gateway on disable:', stopErr.message);
    }
  }

  delete launcher.managedPool;
  openclawConfig.writeLauncherConfig(launcher);
}

// Consume adoption token (Task 9)
function consumeAdoptionToken(token) {
  const pool = getManagedPoolConfig();
  if (!pool?.enabled) return false;
  if (pool.isAdopted === true) return false;
  if (!pool.adoptionToken) return false;

  const expected = Buffer.from(pool.adoptionToken, 'utf-8');
  const provided = Buffer.from(token, 'utf-8');
  if (expected.length !== provided.length) return false;
  if (!crypto.timingSafeEqual(expected, provided)) return false;

  // Token is valid — consume it and mark as AVAILABLE
  const now = new Date().toISOString();
  updateManagedPoolConfig({
    adoptionToken: null,
    isAdopted: true,
    status: STATES.AVAILABLE,
    adoptedAt: now,
    adoptionConsumedAt: now,
  });
  return true;
}

// Derive risk level from failed attempt count
function getRiskLevel(failedAttempts) {
  if (!failedAttempts || failedAttempts === 0) return 'none';
  if (failedAttempts <= 3) return 'low';
  if (failedAttempts <= 9) return 'medium';
  return 'high';
}

// Get adoption info for display
// When opts.includeHealth is true, probes the gateway for live health status
async function getAdoptionInfo(opts = {}) {
  const pool = getManagedPoolConfig();
  if (!pool) return { enabled: false };

  const failedAttempts = pool.failedAttempts || 0;

  const info = {
    enabled: pool.enabled || false,
    isAdopted: pool.isAdopted || false,
    instanceId: pool.instanceId || null,
    status: pool.status || null,
    adoptedAt: pool.adoptedAt || null,
    adoptionConsumedAt: pool.adoptionConsumedAt || null,
    modelId: pool.modelId || null,
    userId: pool.userId || null,
    hasControlKey: !!pool.controlKey,
    hasAdoptionToken: !!pool.adoptionToken,
    failedAttempts,
    lastFailure: pool.lastFailure || null,
    riskLevel: getRiskLevel(failedAttempts),
  };

  // Include gateway model metadata
  const config = openclawConfig.readConfig();
  const agentDefaults = config?.agents?.defaults;
  if (agentDefaults) {
    info.gatewayModel = {
      primary: agentDefaults.model?.primary || null,
      available: agentDefaults.models ? Object.keys(agentDefaults.models) : [],
    };
  }

  // Only include failureLog when there are failures
  if (failedAttempts > 0) {
    info.failureLog = pool.failureLog || [];
  }

  // Live gateway health check when the instance claims to be active
  if (opts.includeHealth && pool.isAdopted && pool.status === 'ACTIVE') {
    try {
      const pm2Health = require('./pm2-health');
      const gatewayProcess = pm2Health.getOpenClawGatewayProcess();
      const port = config?.gateway?.port || 18789;
      const probe = await pm2Health.probeGateway(port);

      if (gatewayProcess && gatewayProcess.status === 'online' && probe.reachable) {
        info.gatewayHealth = 'healthy';
      } else if (gatewayProcess && gatewayProcess.status === 'online') {
        info.gatewayHealth = 'degraded';
      } else {
        info.gatewayHealth = 'unhealthy';
      }

      // Detect restart loop: high restart count with very low uptime suggests crash-looping
      // Skip during grace period after a user-triggered restart to avoid false positives.
      if (gatewayProcess && !pm2Health.isInRestartGracePeriod()) {
        const uptimeMs = gatewayProcess.uptime || 0;
        const restarts = gatewayProcess.restartCount || 0;
        const unstable = gatewayProcess.unstableRestarts || 0;
        // Gateway is crash-looping if it has restarted multiple times and uptime is under 30s
        if ((restarts >= 3 || unstable >= 2) && uptimeMs < 30000) {
          info.gatewayHealth = 'crash_loop';
          const configExists = openclawConfig.readConfig();
          if (!configExists) {
            info.gatewayIssue = `Gateway is not properly configured — openclaw.json not found. The gateway will be automatically stopped until configuration is complete and reprovisioning is done. Doctor Fix will not help in this case.`;
          } else {
            info.gatewayIssue = `Gateway keeps restarting (${restarts} restarts, uptime ${Math.floor(uptimeMs / 1000)}s). Configuration may have issues — check gateway logs or run diagnostics.`;
          }
        }
      }

      // No PM2 process at all
      if (!gatewayProcess) {
        info.gatewayHealth = 'unhealthy';
        info.gatewayIssue = 'Gateway process not found in PM2. It may need to be started or re-installed.';
      }
    } catch (healthErr) {
      console.error('[Instance Control] Health check error:', healthErr.message);
    }
  }

  return info;
}

// Reset adoption — clears adoption state and generates a fresh token
// Preserves controlKey and instanceId for re-adoption
function resetAdoption() {
  const pool = getManagedPoolConfig();
  if (!pool?.enabled) throw new Error('Managed pool is not enabled');

  const freshToken = generateAdoptionToken();

  updateManagedPoolConfig({
    isAdopted: false,
    adoptionToken: freshToken,
    adoptedAt: null,
    adoptionConsumedAt: null,
    userId: null,
    pairKey: null,
    status: null,
    ...FAILURE_DEFAULTS,
  });

  return getAdoptionInfo();
}

// Record a Control API failure
function recordFailure(endpoint, errorCode, errorMessage) {
  const pool = getManagedPoolConfig();
  if (!pool?.enabled) return;

  const entry = {
    timestamp: new Date().toISOString(),
    endpoint,
    errorCode,
    errorMessage,
  };

  const failureLog = [...(pool.failureLog || []), entry].slice(-20);

  updateManagedPoolConfig({
    failedAttempts: (pool.failedAttempts || 0) + 1,
    lastFailure: entry,
    failureLog,
  });
}

// Clear failure tracking (called on successful operations)
function clearFailures() {
  const pool = getManagedPoolConfig();
  if (!pool?.enabled) return;
  updateManagedPoolConfig(FAILURE_DEFAULTS);
}

// Build the response envelope per spec
function successResponse(data) {
  return { success: true, data, error: null };
}

function errorResponse(code, message, httpStatus = 400) {
  return {
    httpStatus,
    body: { success: false, data: null, error: { code, message } },
  };
}

module.exports = {
  STATES,
  VALID_TRANSITIONS,
  ERROR_CODES,
  getManagedPoolConfig,
  updateManagedPoolConfig,
  getInstanceId,
  getStatus,
  isEnabled,
  canTransition,
  transitionState,
  generateControlKey,
  generateAdoptionToken,
  enableAdoption,
  disableAdoption,
  consumeAdoptionToken,
  resetAdoption,
  getAdoptionInfo,
  recordFailure,
  clearFailures,
  getRiskLevel,
  successResponse,
  errorResponse,
};

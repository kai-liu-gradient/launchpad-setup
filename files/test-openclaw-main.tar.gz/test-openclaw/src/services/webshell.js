const pty = require('node-pty');
const os = require('os');

const MAX_SESSIONS = 5;
const DEFAULT_SHELL = process.env.SHELL || (os.platform() === 'win32' ? 'powershell.exe' : '/bin/bash');
const DEFAULT_CWD = os.homedir();

const sessions = new Map();

function createSession(sessionId, options = {}) {
  if (sessions.size >= MAX_SESSIONS) {
    throw new Error(`Maximum concurrent sessions (${MAX_SESSIONS}) reached`);
  }

  const shell = options.shell || DEFAULT_SHELL;
  const cwd = options.cwd || DEFAULT_CWD;
  const cols = options.cols || 80;
  const rows = options.rows || 24;

  const ptyProcess = pty.spawn(shell, [], {
    name: 'xterm-256color',
    cols,
    rows,
    cwd,
    env: { ...process.env, TERM: 'xterm-256color' },
  });

  const session = {
    id: sessionId,
    pty: ptyProcess,
    createdAt: Date.now(),
  };

  sessions.set(sessionId, session);
  return session;
}

function getSession(sessionId) {
  return sessions.get(sessionId) || null;
}

function destroySession(sessionId) {
  const session = sessions.get(sessionId);
  if (session) {
    try {
      session.pty.kill();
    } catch {
      // Process may already be dead
    }
    sessions.delete(sessionId);
  }
}

function resizeSession(sessionId, cols, rows) {
  const session = sessions.get(sessionId);
  if (session) {
    session.pty.resize(cols, rows);
  }
}

function getActiveSessions() {
  return Array.from(sessions.values()).map(s => ({
    id: s.id,
    createdAt: s.createdAt,
    pid: s.pty.pid,
  }));
}

function destroyAllSessions() {
  for (const [id] of sessions) {
    destroySession(id);
  }
}

module.exports = {
  createSession,
  getSession,
  destroySession,
  resizeSession,
  getActiveSessions,
  destroyAllSessions,
  MAX_SESSIONS,
};

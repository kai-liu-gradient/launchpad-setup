const https = require('https');
const WebSocket = require('ws');

const FEISHU_API_BASE = 'https://open.feishu.cn';
const LARK_API_BASE = 'https://open.larksuite.com';

function getApiBase(domain) {
  return String(domain || '').toLowerCase() === 'lark' ? LARK_API_BASE : FEISHU_API_BASE;
}

function platformLabel(domain) {
  return String(domain || '').toLowerCase() === 'lark' ? 'Lark' : 'Feishu';
}

function feishuRequest(url, options = {}, timeoutMs = 8000) {
  return new Promise((resolve, reject) => {
    const parsedUrl = new URL(url);
    const reqOptions = {
      hostname: parsedUrl.hostname,
      path: parsedUrl.pathname + parsedUrl.search,
      method: options.method || 'GET',
      headers: {
        'Content-Type': 'application/json; charset=utf-8',
        ...(options.headers || {}),
      },
      family: 4,
    };

    const req = https.request(reqOptions, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch {
          const preview = data.length > 200 ? data.slice(0, 200) + '...' : data;
          reject(new Error(`Invalid JSON response from Feishu API (HTTP ${res.statusCode} ${reqOptions.method} ${reqOptions.path}): ${preview}`));
        }
      });
    });

    req.on('error', (err) => {
      reject(new Error(err.message || `Network error connecting to Feishu API: ${err.code || 'unknown'}`));
    });
    req.setTimeout(timeoutMs, () => {
      req.destroy();
      reject(new Error('Feishu API request timed out'));
    });

    if (options.body) {
      const bodyStr = typeof options.body === 'string' ? options.body : JSON.stringify(options.body);
      req.write(bodyStr);
    }
    req.end();
  });
}

async function getTenantAccessToken(appId, appSecret, domain) {
  const apiBase = getApiBase(domain);
  const result = await feishuRequest(`${apiBase}/open-apis/auth/v3/tenant_access_token/internal`, {
    method: 'POST',
    body: { app_id: appId, app_secret: appSecret },
  });

  if (result.code !== 0) {
    throw new Error(result.msg || 'Failed to obtain tenant access token');
  }
  return result.tenant_access_token;
}

async function getBotInfo(tenantAccessToken, domain) {
  const apiBase = getApiBase(domain);
  const result = await feishuRequest(`${apiBase}/open-apis/bot/v3/info/`, {
    method: 'GET',
    headers: { Authorization: `Bearer ${tenantAccessToken}` },
  });

  if (result.code !== 0) {
    return null;
  }
  return result.bot || null;
}

async function validateCredentials(appId, appSecret, domain) {
  if (!appId || typeof appId !== 'string') {
    throw new Error('App ID is required and must be a string');
  }
  if (!appSecret || typeof appSecret !== 'string') {
    throw new Error('App Secret is required and must be a string');
  }

  if (!/^cli_[a-zA-Z0-9]+$/.test(appId.trim())) {
    throw new Error('Invalid App ID format. Expected format: cli_xxxxxxxxxx');
  }

  const tenantToken = await getTenantAccessToken(appId.trim(), appSecret.trim(), domain || 'feishu');

  let botInfo = null;
  try {
    botInfo = await getBotInfo(tenantToken, domain || 'feishu');
  } catch {
    // Bot info is best-effort
  }

  return {
    valid: true,
    bot: botInfo,
  };
}

function buildChannelConfig(appId, appSecret, options = {}) {
  const { connectionMode = 'websocket', domain, encryptKey, verificationToken } = options;

  const feishuConfig = {
    enabled: true,
    appId,
    appSecret,
    connectionMode,
    domain: domain || 'feishu',
    groupPolicy: 'open',
  };

  // Webhook callback mode supports optional encrypt key and verification token
  if (encryptKey) feishuConfig.encryptKey = encryptKey;
  if (verificationToken) feishuConfig.verificationToken = verificationToken;

  return {
    channels: {
      feishu: feishuConfig,
    },
  };
}

// Active WebSocket probe sessions keyed by a session ID
const activeProbes = new Map();

/**
 * Start a temporary WebSocket probe to Feishu's long-connection gateway.
 * Returns a session ID. Use getProbeStatus/stopProbe to manage.
 * The probe auto-closes after maxDurationMs (default 30s).
 */
async function startWsProbe(appId, appSecret, domain, { maxDurationMs = 300000 } = {}) {
  const effectiveDomain = String(domain || 'feishu').toLowerCase();
  const sessionId = `fswp_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const probe = {
    id: sessionId,
    status: 'connecting',
    domain: effectiveDomain,
    steps: [],
    startedAt: Date.now(),
    ws: null,
    timer: null,
  };
  activeProbes.set(sessionId, probe);

  const addStep = (msg, ok = true) => {
    probe.steps.push({ message: msg, ok, ts: Date.now() });
  };

  const label = platformLabel(effectiveDomain);

  try {
    // Step 1: Request WebSocket endpoint (using AppID/AppSecret directly, matching Feishu SDK)
    addStep(`Requesting WebSocket endpoint from ${label}...`);
    let apiBase = getApiBase(effectiveDomain);
    let endpointResult = await feishuRequest(`${apiBase}/callback/ws/endpoint`, {
      method: 'POST',
      headers: { locale: 'en' },
      body: { AppID: appId, AppSecret: appSecret },
    }, 15000);

    // If "Incorrect domain name", the app belongs to the other platform — auto-retry
    if (endpointResult.code !== 0 && /incorrect domain/i.test(endpointResult.msg || '')) {
      const altDomain = effectiveDomain === 'lark' ? 'feishu' : 'lark';
      const altLabel = platformLabel(altDomain);
      addStep(`App not found on ${label} platform, trying ${altLabel}...`);
      apiBase = getApiBase(altDomain);
      endpointResult = await feishuRequest(`${apiBase}/callback/ws/endpoint`, {
        method: 'POST',
        headers: { locale: 'en' },
        body: { AppID: appId, AppSecret: appSecret },
      }, 15000);
      if (endpointResult.code === 0) {
        // Update probe domain to reflect the actual platform
        probe.domain = altDomain;
        probe.domainCorrected = true;
        addStep(`Connected via ${altLabel} (domain auto-corrected)`);
      }
    }

    if (endpointResult.code !== 0) {
      const errMsg = endpointResult.msg || 'Failed to get WebSocket endpoint';
      addStep(errMsg, false);
      probe.status = 'failed';
      probe.error = errMsg;
      scheduleCleanup(sessionId, 60000);
      return { sessionId, domain: probe.domain, status: probe.status, steps: probe.steps, error: probe.error };
    }

    const wsData = endpointResult.data || endpointResult;
    const wsUrl = wsData.URL || wsData.url;
    if (!wsUrl) {
      addStep('No WebSocket URL returned — event subscription may not be configured', false);
      probe.status = 'failed';
      probe.error = `${platformLabel(probe.domain)} did not return a WebSocket URL. Ensure im.message.receive_v1 event subscription is added and the app is published.`;
      scheduleCleanup(sessionId, 60000);
      return { sessionId, domain: probe.domain, status: probe.status, steps: probe.steps, error: probe.error };
    }
    addStep('WebSocket endpoint received');

    // Step 3: Connect via WebSocket
    addStep('Establishing WebSocket connection...');
    const clientConfig = wsData.ClientConfig || wsData.client_config || {};

    await new Promise((resolve, reject) => {
      const ws = new WebSocket(wsUrl, {
        headers: {
          'locale': 'en',
        },
        handshakeTimeout: 10000,
      });
      probe.ws = ws;

      ws.on('open', () => {
        addStep('WebSocket connection established successfully');
        probe.status = 'connected';
        resolve();
      });

      ws.on('message', (data) => {
        try {
          const msg = JSON.parse(data.toString());
          if (msg.type === 'pong' || msg.type === 'server_hello') {
            addStep(`Received ${msg.type} from server`);
          }
        } catch {
          // ignore non-JSON messages
        }
      });

      ws.on('error', (err) => {
        const errMsg = err.message || 'WebSocket connection error';
        addStep(errMsg, false);
        probe.status = 'failed';
        probe.error = errMsg;
        reject(err);
      });

      ws.on('close', (code) => {
        if (probe.status === 'connected') {
          addStep(`WebSocket closed (code: ${code})`);
          probe.status = 'closed';
        }
      });

      // Timeout for connection
      setTimeout(() => {
        if (probe.status === 'connecting') {
          ws.terminate();
          addStep('WebSocket connection timed out', false);
          probe.status = 'failed';
          probe.error = 'Connection timed out';
          reject(new Error('Connection timed out'));
        }
      }, 10000);
    });

    // Auto-close after maxDurationMs
    probe.timer = setTimeout(() => {
      stopProbe(sessionId);
    }, maxDurationMs);

  } catch (err) {
    if (probe.status !== 'failed') {
      addStep(err.message || 'Unknown error', false);
      probe.status = 'failed';
      probe.error = err.message;
    }
    scheduleCleanup(sessionId, 60000);
  }

  return { sessionId, domain: probe.domain, status: probe.status, steps: probe.steps, error: probe.error || null };
}

function getProbeStatus(sessionId) {
  const probe = activeProbes.get(sessionId);
  if (!probe) return null;
  return {
    sessionId: probe.id,
    domain: probe.domain || 'feishu',
    domainCorrected: probe.domainCorrected || false,
    status: probe.status,
    steps: probe.steps,
    error: probe.error || null,
    elapsed: Date.now() - probe.startedAt,
  };
}

function stopProbe(sessionId) {
  const probe = activeProbes.get(sessionId);
  if (!probe) return false;
  if (probe.ws) {
    try { probe.ws.close(); } catch {}
    probe.ws = null;
  }
  if (probe.timer) {
    clearTimeout(probe.timer);
    probe.timer = null;
  }
  if (probe.status === 'connected' || probe.status === 'connecting') {
    probe.steps.push({ message: 'Probe stopped', ok: true, ts: Date.now() });
    probe.status = 'stopped';
  }
  scheduleCleanup(sessionId, 30000);
  return true;
}

function stopAllProbes() {
  let count = 0;
  for (const [sessionId, probe] of activeProbes) {
    if (probe.ws) {
      try { probe.ws.close(); } catch {}
      probe.ws = null;
    }
    if (probe.timer) {
      clearTimeout(probe.timer);
      probe.timer = null;
    }
    if (probe.status === 'connected' || probe.status === 'connecting') {
      probe.steps.push({ message: 'Probe stopped', ok: true, ts: Date.now() });
      probe.status = 'stopped';
      count++;
    }
    scheduleCleanup(sessionId, 30000);
  }
  return count;
}

function scheduleCleanup(sessionId, delayMs) {
  setTimeout(() => { activeProbes.delete(sessionId); }, delayMs);
}

module.exports = {
  validateCredentials,
  buildChannelConfig,
  getTenantAccessToken,
  getBotInfo,
  feishuRequest,
  getApiBase,
  platformLabel,
  startWsProbe,
  getProbeStatus,
  stopProbe,
  stopAllProbes,
};

const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

const OPENCLAW_ROOT = path.join(os.homedir(), '.openclaw');
const WORKSPACE_ROOT = path.join(OPENCLAW_ROOT, 'workspace');
const MAX_DEPTH = 5;
const MAX_FILE_SIZE = 1024 * 1024; // 1MB
const MAX_ENTRIES = 500;

// Allowed browsing roots
const ALLOWED_ROOTS = {
  workspace: WORKSPACE_ROOT,
  openclaw: OPENCLAW_ROOT,
};

function resolveRoot(rootKey) {
  const root = ALLOWED_ROOTS[rootKey || 'workspace'];
  if (!root) throw new Error(`Invalid root: ${rootKey}`);
  return root;
}

// Extension-to-MIME mapping for preview detection
const MIME_MAP = {
  '.txt': 'text/plain', '.md': 'text/markdown', '.markdown': 'text/markdown',
  '.js': 'application/javascript', '.mjs': 'application/javascript', '.cjs': 'application/javascript',
  '.ts': 'application/typescript', '.tsx': 'application/typescript',
  '.jsx': 'application/javascript',
  '.json': 'application/json', '.jsonl': 'application/json',
  '.xml': 'application/xml', '.svg': 'image/svg+xml',
  '.html': 'text/html', '.htm': 'text/html',
  '.css': 'text/css', '.scss': 'text/css', '.less': 'text/css',
  '.py': 'text/x-python', '.rb': 'text/x-ruby', '.go': 'text/x-go',
  '.rs': 'text/x-rust', '.java': 'text/x-java', '.c': 'text/x-c',
  '.cpp': 'text/x-c++', '.h': 'text/x-c', '.hpp': 'text/x-c++',
  '.sh': 'text/x-shellscript', '.bash': 'text/x-shellscript', '.zsh': 'text/x-shellscript',
  '.yaml': 'text/yaml', '.yml': 'text/yaml',
  '.toml': 'text/x-toml', '.ini': 'text/x-ini', '.cfg': 'text/x-ini',
  '.env': 'text/plain', '.gitignore': 'text/plain', '.dockerignore': 'text/plain',
  '.log': 'text/plain', '.csv': 'text/csv', '.tsv': 'text/tab-separated-values',
  '.sql': 'application/sql', '.graphql': 'application/graphql',
  '.dockerfile': 'text/x-dockerfile',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.gif': 'image/gif', '.webp': 'image/webp', '.ico': 'image/x-icon',
  '.pdf': 'application/pdf', '.zip': 'application/zip', '.gz': 'application/gzip',
  '.tar': 'application/x-tar', '.7z': 'application/x-7z-compressed',
  '.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.mp4': 'video/mp4',
  '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf',
  '.exe': 'application/octet-stream', '.bin': 'application/octet-stream',
};

// MIME types that are text-previewable
const PREVIEWABLE_PREFIXES = ['text/', 'application/json', 'application/javascript', 'application/typescript', 'application/xml', 'application/sql', 'application/graphql', 'image/svg+xml'];

function isPathSafe(requestedPath, rootKey) {
  const root = resolveRoot(rootKey);
  const resolved = path.resolve(root, requestedPath);
  return resolved.startsWith(root);
}

function buildDirectoryTree(dirPath, rootDir, currentDepth = 0) {
  if (currentDepth > MAX_DEPTH) return [];

  let entries;
  try {
    entries = fs.readdirSync(dirPath, { withFileTypes: true });
  } catch (err) {
    return [];
  }

  const results = [];
  let count = 0;

  for (const entry of entries) {
    if (count >= MAX_ENTRIES) break;

    const fullPath = path.join(dirPath, entry.name);
    const relativePath = path.relative(rootDir, fullPath);

    if (entry.name.startsWith('.')) continue;

    if (entry.isDirectory()) {
      const children = buildDirectoryTree(fullPath, rootDir, currentDepth + 1);
      results.push({
        name: entry.name,
        path: relativePath,
        type: 'directory',
        children,
      });
      count += 1 + children.length;
    } else if (entry.isFile()) {
      let stat;
      try {
        stat = fs.statSync(fullPath);
      } catch (err) {
        continue;
      }
      results.push({
        name: entry.name,
        path: relativePath,
        type: 'file',
        size: stat.size,
        modified: stat.mtime.toISOString(),
      });
      count++;
    }
  }

  return results;
}

function readWorkspaceFile(relativePath, rootKey) {
  if (!relativePath || typeof relativePath !== 'string') {
    throw new Error('Path parameter is required');
  }

  const root = resolveRoot(rootKey);

  // Normalize and prevent traversal
  const cleaned = path.normalize(relativePath).replace(/^(\.\.(\/|\\|$))+/, '');
  const fullPath = path.resolve(root, cleaned);

  if (!fullPath.startsWith(root)) {
    throw new Error('Path traversal detected: access denied');
  }

  if (!fs.existsSync(fullPath)) {
    throw new Error('File not found');
  }

  const stat = fs.statSync(fullPath);
  if (!stat.isFile()) {
    throw new Error('Path is not a file');
  }

  if (stat.size > MAX_FILE_SIZE) {
    throw new Error(`File too large (${stat.size} bytes). Maximum: ${MAX_FILE_SIZE} bytes`);
  }

  const content = fs.readFileSync(fullPath, 'utf-8');
  const ext = path.extname(fullPath).toLowerCase();

  return {
    name: path.basename(fullPath),
    path: cleaned,
    size: stat.size,
    modified: stat.mtime.toISOString(),
    extension: ext,
    isMarkdown: ext === '.md',
    content,
  };
}

function getWorkspaceTree(rootKey) {
  const root = resolveRoot(rootKey);

  if (!fs.existsSync(root)) {
    return { exists: false, root, tree: [] };
  }

  return {
    exists: true,
    root,
    tree: buildDirectoryTree(root, root),
  };
}

function getFileMimeInfo(relativePath) {
  const ext = path.extname(relativePath).toLowerCase();
  const mimeType = MIME_MAP[ext] || 'application/octet-stream';
  const isPreviewable = PREVIEWABLE_PREFIXES.some((prefix) => mimeType.startsWith(prefix));
  return { mimeType, isPreviewable };
}

function saveUploadedFile(relativePath, buffer, rootKey) {
  if (!relativePath || typeof relativePath !== 'string') {
    throw new Error('Path parameter is required');
  }

  const root = resolveRoot(rootKey);

  const cleaned = path.normalize(relativePath).replace(/^(\.\.(\/|\\|$))+/, '');
  const fullPath = path.resolve(root, cleaned);

  if (!fullPath.startsWith(root)) {
    throw new Error('Path traversal detected: access denied');
  }

  // Ensure parent directory exists
  const parentDir = path.dirname(fullPath);
  if (!fs.existsSync(parentDir)) {
    fs.mkdirSync(parentDir, { recursive: true });
  }

  // Atomic write: write to .tmp then rename
  const tmpPath = fullPath + '.tmp';
  fs.writeFileSync(tmpPath, buffer);
  fs.renameSync(tmpPath, fullPath);

  // Compute MD5 from written file
  const writtenData = fs.readFileSync(fullPath);
  const md5 = crypto.createHash('md5').update(writtenData).digest('hex');
  const stat = fs.statSync(fullPath);

  return {
    name: path.basename(fullPath),
    path: cleaned,
    size: stat.size,
    md5,
  };
}

function deleteWorkspaceItem(relativePath, rootKey) {
  if (!relativePath || typeof relativePath !== 'string') {
    throw new Error('Path parameter is required');
  }

  const root = resolveRoot(rootKey);

  const cleaned = path.normalize(relativePath).replace(/^(\.\.(\/|\\|$))+/, '');
  const fullPath = path.resolve(root, cleaned);

  if (!fullPath.startsWith(root + path.sep) && fullPath !== root) {
    throw new Error('Path traversal detected: access denied');
  }

  // Prevent deleting the root itself
  if (fullPath === root) {
    throw new Error('Cannot delete the root directory');
  }

  if (!fs.existsSync(fullPath)) {
    throw new Error('Path not found');
  }

  const stat = fs.statSync(fullPath);
  const isDir = stat.isDirectory();

  fs.rmSync(fullPath, { recursive: true, force: true });

  return {
    name: path.basename(fullPath),
    path: cleaned,
    type: isDir ? 'directory' : 'file',
  };
}

module.exports = {
  getWorkspaceTree,
  readWorkspaceFile,
  getFileMimeInfo,
  saveUploadedFile,
  deleteWorkspaceItem,
  isPathSafe,
  resolveRoot,
  WORKSPACE_ROOT,
  OPENCLAW_ROOT,
  ALLOWED_ROOTS,
  MAX_FILE_SIZE,
};

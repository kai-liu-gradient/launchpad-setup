const crypto = require('crypto');
const openclawConfig = require('./openclaw-config');

const COOKIE_NAME = 'gateway_ws_session';
const MAX_AGE_MS = 30 * 60 * 1000; // 30 minutes

/**
 * Derive an HMAC key from the launcher password for signing gateway WS session cookies.
 * Uses a different context string than the JWT secret to ensure key separation.
 */
function getSessionKey() {
  const password = openclawConfig.getLauncherPassword();
  if (!password) return null;
  return crypto.createHmac('sha256', password).update('gateway-ws-session-key').digest();
}

/**
 * Create a signed gateway WS session value: base64(timestamp) + '.' + hmac(timestamp)
 */
function createSessionValue() {
  const key = getSessionKey();
  if (!key) return null;
  const timestamp = Date.now().toString();
  const sig = crypto.createHmac('sha256', key).update(timestamp).digest('hex');
  return Buffer.from(timestamp).toString('base64') + '.' + sig;
}

/**
 * Validate a gateway WS session cookie value.
 * Returns true if the signature is valid and the timestamp is within MAX_AGE_MS.
 */
function validateSessionValue(value) {
  if (!value || typeof value !== 'string') return false;
  const key = getSessionKey();
  if (!key) return false;

  const parts = value.split('.');
  if (parts.length !== 2) return false;

  const [encodedTs, sig] = parts;
  let timestamp;
  try {
    timestamp = parseInt(Buffer.from(encodedTs, 'base64').toString(), 10);
  } catch {
    return false;
  }
  if (isNaN(timestamp)) return false;

  // Check expiry
  if (Date.now() - timestamp > MAX_AGE_MS) return false;

  // Verify HMAC signature
  const expectedSig = crypto.createHmac('sha256', key).update(timestamp.toString()).digest('hex');
  if (sig.length !== expectedSig.length) return false;
  return crypto.timingSafeEqual(Buffer.from(sig, 'hex'), Buffer.from(expectedSig, 'hex'));
}

/**
 * Parse a named cookie from a raw Cookie header string.
 */
function parseCookie(cookieHeader, name) {
  if (!cookieHeader) return null;
  const match = cookieHeader.match(new RegExp('(?:^|;\\s*)' + name + '=([^\\s;]+)'));
  return match ? match[1] : null;
}

/**
 * Set the gateway_ws_session cookie on an Express response.
 */
function setSessionCookie(res) {
  const value = createSessionValue();
  if (!value) return false;
  res.cookie(COOKIE_NAME, value, {
    httpOnly: true,
    sameSite: 'lax',
    maxAge: MAX_AGE_MS,
    path: '/',
  });
  return true;
}

/**
 * Validate the gateway_ws_session cookie from a raw Cookie header (for WebSocket upgrades).
 */
function validateFromCookieHeader(cookieHeader) {
  const value = parseCookie(cookieHeader, COOKIE_NAME);
  return validateSessionValue(value);
}

/**
 * Validate the launcher_token JWT from a raw Cookie header (for WebSocket upgrades).
 */
function validateLauncherTokenFromCookie(cookieHeader) {
  const { verifyToken } = require('../middleware/launcher-auth');
  const token = parseCookie(cookieHeader, 'launcher_token');
  if (!token) return false;
  return !!verifyToken(token);
}

module.exports = {
  COOKIE_NAME,
  MAX_AGE_MS,
  createSessionValue,
  validateSessionValue,
  setSessionCookie,
  validateFromCookieHeader,
  validateLauncherTokenFromCookie,
  parseCookie,
};

const { execSync } = require('child_process');
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');

const OPENCLAW_CONFIG_PATH = path.join(os.homedir(), '.openclaw', 'openclaw.json');
const OPENCLAW_WORKSPACE = path.join(os.homedir(), '.openclaw', 'workspace');
const openclawConfig = require('./openclaw-config');

// Simple per-request cache for pm2 jlist results to avoid redundant execSync calls
let _pm2Cache = null;
let _pm2CacheTs = 0;
const PM2_CACHE_TTL = 2000; // 2 seconds

// Track last user-triggered restart to suppress false crash-loop detection.
// After a manual restart the restart counter stays high and uptime is near zero,
// which would otherwise trigger the crash-loop heuristic.
let _lastUserRestartTs = 0;
const RESTART_GRACE_PERIOD = 60000; // 60 seconds

function getPm2Processes() {
  const now = Date.now();
  if (_pm2Cache !== null && (now - _pm2CacheTs) < PM2_CACHE_TTL) {
    return _pm2Cache;
  }
  try {
    const output = execSync('pm2 jlist', { encoding: 'utf-8', timeout: 10000 });
    _pm2Cache = JSON.parse(output);
    _pm2CacheTs = now;
    return _pm2Cache;
  } catch (err) {
    return null;
  }
}

function invalidatePm2Cache() {
  _pm2Cache = null;
  _pm2CacheTs = 0;
}

function getOpenClawGatewayProcess() {
  const processes = getPm2Processes();
  if (!processes) return null;

  const gateway = processes.find(p => p.name === 'openclaw-gateway');
  if (!gateway) return null;

  return {
    name: gateway.name,
    pid: gateway.pid,
    status: gateway.pm2_env.status,
    uptime: gateway.pm2_env.pm_uptime ? Date.now() - gateway.pm2_env.pm_uptime : null,
    memory: gateway.monit ? gateway.monit.memory : null,
    cpu: gateway.monit ? gateway.monit.cpu : null,
    restartCount: gateway.pm2_env.restart_time || 0,
    unstableRestarts: gateway.pm2_env.unstable_restarts || 0,
    createdAt: gateway.pm2_env.created_at || null,
    pmId: gateway.pm_id,
  };
}

function getAllProcesses() {
  const processes = getPm2Processes();
  if (!processes) return [];

  return processes.map(p => ({
    name: p.name,
    pid: p.pid,
    pmId: p.pm_id,
    status: p.pm2_env ? p.pm2_env.status : 'unknown',
    uptime: p.pm2_env && p.pm2_env.pm_uptime ? Date.now() - p.pm2_env.pm_uptime : null,
    memory: p.monit ? p.monit.memory : null,
    cpu: p.monit ? p.monit.cpu : null,
    restartCount: p.pm2_env ? (p.pm2_env.restart_time || 0) : 0,
  }));
}

function probeGateway(port = 18789, timeout = 10000) {
  return new Promise((resolve) => {
    const req = http.get(`http://127.0.0.1:${port}/`, { timeout }, (res) => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        resolve({
          reachable: true,
          statusCode: res.statusCode,
          headers: res.headers,
        });
      });
    });

    req.on('error', () => {
      resolve({ reachable: false, statusCode: null, headers: null });
    });

    req.on('timeout', () => {
      req.destroy();
      resolve({ reachable: false, statusCode: null, headers: null });
    });
  });
}

function checkTokenHealth() {
  const config = openclawConfig.readConfig();
  if (!config) return { status: 'missing', warning: 'No config file found' };
  const token = config.gateway?.auth?.token;
  return openclawConfig.checkTokenStrength(token);
}

function checkTokenSync() {
  const config = openclawConfig.readConfig();
  const configToken = config?.gateway?.auth?.token;

  if (!configToken) return { synced: false, reason: 'no_config_token' };

  // Check if the gateway process is actually running
  const gateway = getOpenClawGatewayProcess();
  if (!gateway || gateway.status !== 'online') {
    return { synced: false, reason: 'gateway_not_running' };
  }

  // Read the openclaw CLI config file directly (same ~/.openclaw/openclaw.json)
  // instead of spawning a subprocess — the gateway reads its token from this file on startup
  let cliToken = null;
  try {
    const raw = fs.readFileSync(OPENCLAW_CONFIG_PATH, 'utf-8');
    const cliConfig = JSON.parse(raw);
    cliToken = cliConfig?.gateway?.auth?.token || null;
  } catch (_) {}
  if (!cliToken) return { synced: false, reason: 'no_cli_token' };
  if (configToken !== cliToken) return { synced: false, reason: 'token_mismatch' };
  return { synced: true };
}

async function getComprehensiveHealth() {
  const gatewayProcess = getOpenClawGatewayProcess();
  const config = openclawConfig.readConfig();
  const port = config?.gateway?.port || 18789;
  const gatewayProbe = await probeGateway(port);
  const tokenHealth = checkTokenHealth();
  const tokenSync = checkTokenSync();
  const configHealth = getConfigHealthChecks();

  // Build per-section summary
  const gatewayOk = gatewayProcess && gatewayProcess.status === 'online' && gatewayProbe.reachable;
  const securityOk = tokenHealth.strength === 'strong' && tokenSync.synced;

  const summary = {
    config: configHealth.valid ? 'ok' : 'error',
    gateway: gatewayOk ? 'ok' : (gatewayProcess ? 'warn' : 'error'),
    security: securityOk ? 'ok' : (tokenHealth.strength === 'missing' ? 'error' : 'warn'),
  };

  return {
    pm2: {
      available: getPm2Processes() !== null,
      gateway: gatewayProcess,
      allProcesses: getAllProcesses(),
    },
    gateway: {
      portReachable: gatewayProbe.reachable,
      statusCode: gatewayProbe.statusCode,
      port,
    },
    config: {
      exists: fs.existsSync(OPENCLAW_CONFIG_PATH),
      path: OPENCLAW_CONFIG_PATH,
    },
    workspace: {
      exists: fs.existsSync(OPENCLAW_WORKSPACE),
      path: OPENCLAW_WORKSPACE,
    },
    security: {
      token: tokenHealth,
      tokenSync,
    },
    summary,
  };
}

function restartGateway() {
  try {
    invalidatePm2Cache();

    // Check if the process exists in PM2's process list
    const existing = getOpenClawGatewayProcess();
    if (!existing) {
      // Process was deleted from PM2 — recreate it from the ecosystem config
      const ecosystemPath = path.join(os.homedir(), '.pm2', 'ecosystem.openclaw-gateway.config.js');
      if (fs.existsSync(ecosystemPath)) {
        execSync(`pm2 start ${ecosystemPath}`, { encoding: 'utf-8', timeout: 15000 });
      } else {
        // Fallback: start directly with inline config matching the standard ecosystem
        execSync('pm2 start /bin/bash --name openclaw-gateway --interpreter none -- -c "openclaw gateway run"', {
          encoding: 'utf-8', timeout: 15000,
        });
      }
    } else {
      // Let PM2 handle the full restart — its built-in treekill ensures the
      // entire process tree is cleaned up before starting the new instance.
      // No manual kill/pkill needed.
      execSync('pm2 restart openclaw-gateway', { encoding: 'utf-8', timeout: 15000 });
    }

    // Record restart time so crash-loop detection is deferred during grace period
    _lastUserRestartTs = Date.now();

    // Brief pause to let the process come back online
    execSync('sleep 1', { timeout: 3000 });
    invalidatePm2Cache();
    return {
      success: true,
      process: getOpenClawGatewayProcess(),
    };
  } catch (err) {
    return {
      success: false,
      error: err.message,
    };
  }
}

function stopGateway() {
  try {
    invalidatePm2Cache();
    execSync('pm2 stop openclaw-gateway', { encoding: 'utf-8', timeout: 10000 });
    invalidatePm2Cache();
    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

function restartLauncher() {
  try {
    invalidatePm2Cache();
    // Fire-and-forget: spawn pm2 restart in a detached child so the response
    // can be sent before this process is killed.  A small delay gives the HTTP
    // response time to flush.
    const { spawn } = require('child_process');
    spawn('sh', ['-c', 'sleep 1 && pm2 restart web'], {
      detached: true,
      stdio: 'ignore',
    }).unref();
    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

function getConfigHealthChecks() {
  const checks = [];

  // Check 1: Config file exists
  const configExists = fs.existsSync(OPENCLAW_CONFIG_PATH);
  checks.push({
    name: 'Config File',
    ok: configExists,
    detail: configExists ? OPENCLAW_CONFIG_PATH : 'openclaw.json not found',
  });

  if (!configExists) {
    return { valid: false, checks };
  }

  // Check 2: Valid JSON
  const config = openclawConfig.readConfig();
  checks.push({
    name: 'Config Valid',
    ok: !!config,
    detail: config ? 'Valid JSON' : 'Failed to parse JSON',
  });

  if (!config) {
    return { valid: false, checks };
  }

  // Check 3: Workspace directory exists (created on first conversation)
  const workspaceExists = fs.existsSync(OPENCLAW_WORKSPACE);
  checks.push({
    name: 'Workspace',
    ok: workspaceExists,
    warn: !workspaceExists,
    detail: workspaceExists ? 'Exists' : 'Start a chat to initialize',
  });

  const allOk = checks.every(c => c.ok || c.warn);
  return { valid: allOk, checks };
}

function getGatewayLogInfo() {
  const processes = getPm2Processes();
  if (!processes) return { found: false };

  const gateway = processes.find(p => p.name === 'openclaw-gateway');
  if (!gateway) return { found: false };

  const outLog = gateway.pm2_env?.pm_out_log_path || null;
  const errLog = gateway.pm2_env?.pm_err_log_path || null;

  const countLines = (filePath) => {
    try {
      if (!filePath || !fs.existsSync(filePath)) return 0;
      const buf = fs.readFileSync(filePath, 'utf-8');
      return buf.split('\n').filter(l => l.length > 0).length;
    } catch { return 0; }
  };

  return {
    found: true,
    outLog,
    errLog,
    outLines: countLines(outLog),
    errLines: countLines(errLog),
  };
}

function getGatewayLogTail(lines = 50) {
  const info = getGatewayLogInfo();
  if (!info.found) return { found: false, lines: [] };

  const tailFile = (filePath, n) => {
    try {
      if (!filePath || !fs.existsSync(filePath)) return [];
      const buf = fs.readFileSync(filePath, 'utf-8');
      const allLines = buf.split('\n');
      return allLines.slice(-n).filter(l => l.length > 0).map(l =>
        // Strip PM2 timestamp prefix (e.g. "2026-02-13T14:35:36: ") to avoid duplicate timestamps
        l.replace(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}:\s*/, '')
      );
    } catch { return []; }
  };

  return {
    found: true,
    outTail: tailFile(info.outLog, lines),
    errTail: tailFile(info.errLog, lines),
  };
}

/**
 * Detect zombie (defunct) processes related to openclaw.
 * Returns { found: boolean, zombies: [{ pid, ppid, command }] }
 */
function checkZombieProcesses() {
  try {
    // List all zombie processes (state Z) and filter for openclaw-related ones
    const output = execSync(
      "ps aux 2>/dev/null | awk '$8 ~ /Z/ {print $0}'",
      { encoding: 'utf-8', timeout: 5000 }
    ).trim();
    if (!output) return { found: false, zombies: [] };

    const zombies = [];
    for (const line of output.split('\n')) {
      if (!line) continue;
      const lower = line.toLowerCase();
      if (lower.includes('openclaw') || lower.includes('claw')) {
        // Parse ps aux columns: USER PID %CPU %MEM VSZ RSS TTY STAT START TIME COMMAND
        const parts = line.trim().split(/\s+/);
        const pid = parts[1] || 'unknown';
        const command = parts.slice(10).join(' ') || parts[parts.length - 1] || 'unknown';
        // Try to get PPID
        let ppid = null;
        try {
          ppid = execSync(`ps -o ppid= -p ${pid} 2>/dev/null`, { encoding: 'utf-8', timeout: 2000 }).trim() || null;
        } catch {}
        zombies.push({ pid, ppid, command });
      }
    }
    return { found: zombies.length > 0, zombies };
  } catch {
    return { found: false, zombies: [] };
  }
}

/**
 * Detect the PID actually listening on the gateway port using lsof/ss,
 * then compare with PM2's tracked PID to determine management status.
 */
function checkGatewayManagement(port = 18789) {
  const pm2Process = getOpenClawGatewayProcess();
  const pm2Pid = pm2Process?.pid || null;

  // Try to find the PID listening on the gateway port.
  // Prefer lsof/ss but fall back to /proc/net/tcp for minimal containers.
  let portPid = null;
  try {
    const out = execSync(`lsof -ti :${port} 2>/dev/null || ss -tlnp sport = :${port} 2>/dev/null`, {
      encoding: 'utf-8', timeout: 3000,
    }).trim();
    const match = out.match(/\b(\d+)\b/);
    if (match) portPid = parseInt(match[1], 10);
  } catch {
    // lsof/ss unavailable
  }
  if (!portPid) {
    // Fallback: parse /proc/net/tcp + /proc/net/tcp6 to find the listening
    // socket inode, then scan /proc/*/fd to find the owning PID.
    try {
      const hexPort = port.toString(16).toUpperCase().padStart(4, '0');
      const listenState = '0A'; // TCP LISTEN
      let inode = null;
      for (const tcpFile of ['/proc/net/tcp', '/proc/net/tcp6']) {
        try {
          const lines = fs.readFileSync(tcpFile, 'utf-8').split('\n');
          for (const line of lines) {
            const cols = line.trim().split(/\s+/);
            if (cols.length >= 10 && cols[1]?.endsWith(':' + hexPort) && cols[3] === listenState) {
              inode = cols[9];
              break;
            }
          }
        } catch { /* file may not exist */ }
        if (inode) break;
      }
      if (inode) {
        const needle = `socket:[${inode}]`;
        const dirs = fs.readdirSync('/proc').filter(d => /^\d+$/.test(d));
        for (const pid of dirs) {
          try {
            const fds = fs.readdirSync(`/proc/${pid}/fd`);
            for (const fd of fds) {
              try {
                const target = fs.readlinkSync(`/proc/${pid}/fd/${fd}`);
                if (target === needle) { portPid = parseInt(pid, 10); break; }
              } catch { /* permission denied or gone */ }
            }
          } catch { /* permission denied or gone */ }
          if (portPid) break;
        }
      }
    } catch {
      // /proc not available
    }
  }

  // The PM2 process (e.g. `openclaw`) may spawn a child (`openclaw-gateway`)
  // that actually binds the port.  Walk up the portPid's parent chain to see
  // if it is a descendant of pm2Pid — that still counts as PM2-managed.
  let managed = false;
  if (pm2Pid && portPid) {
    if (pm2Pid === portPid) {
      managed = true;
    } else {
      try {
        let cursor = portPid;
        for (let i = 0; i < 5; i++) {  // max 5 levels deep
          const ppid = parseInt(
            execSync(`ps -o ppid= -p ${cursor} 2>/dev/null`, { encoding: 'utf-8', timeout: 1000 }).trim(),
            10,
          );
          if (!ppid || ppid <= 1) break;
          if (ppid === pm2Pid) { managed = true; break; }
          cursor = ppid;
        }
      } catch {
        // ps not available or PID gone
      }
    }
  }

  // PM2 restart-needed: process registered but not online
  const restartNeeded = pm2Process && pm2Process.status !== 'online';

  // Identify the command line of the port-holding process for safe kill decisions.
  let portProcessCmd = null;
  let isOpenclawProcess = false;
  if (portPid) {
    try {
      // /proc/<pid>/cmdline has null-separated args
      portProcessCmd = fs.readFileSync(`/proc/${portPid}/cmdline`, 'utf-8').replace(/\0/g, ' ').trim();
    } catch {
      try {
        portProcessCmd = execSync(`ps -o args= -p ${portPid} 2>/dev/null`, { encoding: 'utf-8', timeout: 2000 }).trim();
      } catch { /* ps unavailable or PID gone */ }
    }
    if (portProcessCmd) {
      const lower = portProcessCmd.toLowerCase();
      isOpenclawProcess = lower.includes('openclaw') || lower.includes('claw-gateway');
    }
  }

  return {
    pm2Pid,
    portPid,
    portProcessCmd,
    isOpenclawProcess,
    managed,
    unmanagedDaemon: !!(portPid && !managed),
    restartNeeded: !!restartNeeded,
  };
}

/**
 * Returns true if a user-triggered restart happened recently and crash-loop
 * detection should be suppressed to avoid a false positive.
 */
function isInRestartGracePeriod() {
  return _lastUserRestartTs > 0 && (Date.now() - _lastUserRestartTs) < RESTART_GRACE_PERIOD;
}

module.exports = {
  getPm2Processes,
  getOpenClawGatewayProcess,
  getAllProcesses,
  probeGateway,
  getComprehensiveHealth,
  checkTokenSync,
  checkTokenHealth,
  restartGateway,
  restartLauncher,
  getConfigHealthChecks,
  getGatewayLogInfo,
  getGatewayLogTail,
  checkZombieProcesses,
  invalidatePm2Cache,
  stopGateway,
  checkGatewayManagement,
  isInRestartGracePeriod,
};

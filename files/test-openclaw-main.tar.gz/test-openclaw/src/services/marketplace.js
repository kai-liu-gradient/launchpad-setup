const fs = require('fs');
const path = require('path');
const os = require('os');
const openclawConfig = require('./openclaw-config');

const SKILLS_ROOT = path.join(os.homedir(), '.openclaw', 'skills');
const TOOLS_ROOT = path.join(os.homedir(), '.openclaw', 'tools');
const WORKSPACE_ROOT = path.join(os.homedir(), '.openclaw', 'workspace');
const TOOLS_MD_PATH = path.join(WORKSPACE_ROOT, 'TOOLS.md');
const AGENTS_MD_PATH = path.join(WORKSPACE_ROOT, 'AGENTS.md');
const EXTERNAL_REGISTRY_PATH = path.join(os.homedir(), '.openclaw', 'marketplace-registry.json');
const AGREEMENTS_DIR = path.join(os.homedir(), '.openclaw', 'marketplace-agreements');

// ==========================================
// Registry — managed exclusively by Control API
// ==========================================

const VALID_ITEM_TYPES = ['skill', 'mcp', 'tool', 'exec', 'template'];
const FILE_COPY_TYPES = ['skill', 'mcp'];

// Built-in catalog items shipped with the launcher
const BUILTIN_ITEMS = [
  {
    id: 'openclaw-launcher-cli',
    name: 'Launcher CLI Tool',
    description: 'CLI tool for managing reverse proxy exposures and marketplace items. Allows AI agents and operators to add, remove, and manage service exposures, browse and install marketplace content via command line.',
    type: 'tool',
    version: '1.3.0',
    tags: ['cli', 'expose', 'marketplace', 'tools', 'hardcoded'],
    builtin: true,
    manifest: {
      sourcePath: path.join(__dirname, '..', '..', 'tools', 'openclaw-launcher-cli'),
      toolName: 'launcher-cli',
      toolsEntry: {
        keyword: 'launcher-cli',
        line: '- launcher-cli: Manage reverse proxy exposures — run `launcher-cli --help` for usage',
      },
    },
  },
  {
    id: 'webapp-projects',
    name: 'Web App Projects',
    description: 'Skill for building web pages, websites, web apps, games, dashboards, tools, and forms — and sharing them through Launcher. Quick-start with `launcher-cli init`. Covers project structure, PM2 service management, and port allocation.',
    type: 'skill',
    skillDir: 'webapp-projects',
    version: '1.2.0',
    tags: ['webapp', 'projects', 'pm2', 'web', 'website', 'page', 'game', 'dashboard', 'app', 'hardcoded'],
    builtin: true,
    dependencies: ['openclaw-launcher-cli'],
    manifest: {
      sourcePath: path.join(__dirname, '..', '..', 'skills', 'webapp-projects'),
      toolsEntry: {
        keyword: 'webapp-projects',
        line: '- webapp-projects: Build and share web projects (web pages, websites, web apps, games, dashboards, tools, forms, landing pages) via the Launcher reverse proxy. Activate when user wants to build/create/make any web page or web app. Projects live in ~/.openclaw/workspace/projects/ and run as PM2 services on ports 3001+. Use `launcher-cli init --slug <name>` to quick-start a project.',
      },
    },
  },
];

const BUILTIN_IDS = new Set(BUILTIN_ITEMS.map(i => i.id));

function isBuiltinItem(itemId) {
  return BUILTIN_IDS.has(itemId);
}

function validateRegistryItem(item) {
  const errors = [];
  if (!item || typeof item !== 'object') return ['Item must be an object'];
  if (!item.id || typeof item.id !== 'string') errors.push('id is required and must be a string');
  if (!item.name || typeof item.name !== 'string') errors.push('name is required and must be a string');
  if (!item.description || typeof item.description !== 'string') errors.push('description is required and must be a string');
  if (!item.type || !VALID_ITEM_TYPES.includes(item.type)) errors.push(`type must be one of: ${VALID_ITEM_TYPES.join(', ')}`);
  if (!item.version || typeof item.version !== 'string') errors.push('version is required and must be a string');
  if (item.type === 'skill' && (!item.skillDir || typeof item.skillDir !== 'string')) errors.push('skillDir is required for skill type items');
  if (!item.manifest || typeof item.manifest !== 'object') errors.push('manifest is required and must be an object');
  if ((item.type === 'tool' || item.type === 'template') && item.manifest && typeof item.manifest === 'object' && (!item.manifest.toolName || typeof item.manifest.toolName !== 'string')) errors.push('manifest.toolName is required for tool type items');
  if (item.type === 'exec') {
    if (!item.manifest || !item.manifest.command || typeof item.manifest.command !== 'string') {
      errors.push('manifest.command is required for exec type items');
    }
  }
  return errors;
}

// Read only externally-configured items (no builtins merged)
function readExternalRegistryOnly() {
  try {
    const data = fs.readFileSync(EXTERNAL_REGISTRY_PATH, 'utf-8');
    const parsed = JSON.parse(data);
    return { items: Array.isArray(parsed.items) ? parsed.items : [] };
  } catch {
    return { items: [] };
  }
}

function readExternalRegistry() {
  const { items: externalItems } = readExternalRegistryOnly();
  // Strip any external items that collide with builtin ids — builtins are the source of truth
  const filtered = externalItems.filter(i => !BUILTIN_IDS.has(i.id));
  // Deduplicate remaining external items by id (last occurrence wins)
  const deduped = [];
  const seen = new Map();
  for (const item of filtered) {
    if (seen.has(item.id)) {
      deduped[seen.get(item.id)] = item;
    } else {
      seen.set(item.id, deduped.length);
      deduped.push(item);
    }
  }
  // Builtins first, then external-only items
  return { items: [...BUILTIN_ITEMS, ...deduped] };
}

function writeExternalRegistry(registry) {
  const dir = path.dirname(EXTERNAL_REGISTRY_PATH);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  // Never persist builtin ids in the external file — they are hardcoded in source
  const cleaned = {
    ...registry,
    items: (registry.items || []).filter(i => !BUILTIN_IDS.has(i.id)),
  };
  fs.writeFileSync(EXTERNAL_REGISTRY_PATH, JSON.stringify(cleaned, null, 2), { mode: 0o600 });
}

// ==========================================
// Install State — persisted in launcher.json
// ==========================================

function readInstallRecords() {
  const lc = openclawConfig.readLauncherConfig() || {};
  return (lc.marketplace && lc.marketplace.installed) || {};
}

function writeInstallRecord(itemId, record) {
  const lc = openclawConfig.readLauncherConfig() || {};
  if (!lc.marketplace) lc.marketplace = {};
  if (!lc.marketplace.installed) lc.marketplace.installed = {};
  lc.marketplace.installed[itemId] = record;
  openclawConfig.writeLauncherConfig(lc);
}

function removeInstallRecord(itemId) {
  const lc = openclawConfig.readLauncherConfig() || {};
  if (lc.marketplace && lc.marketplace.installed && lc.marketplace.installed[itemId]) {
    delete lc.marketplace.installed[itemId];
    openclawConfig.writeLauncherConfig(lc);
  }
}

// ==========================================
// Service Functions
// ==========================================

function resolveSkillDir(skillDir) {
  const cleaned = path.normalize(skillDir).replace(/^(\.\.(\/|\\|$))+/, '');
  const fullPath = path.resolve(SKILLS_ROOT, cleaned);
  if (!fullPath.startsWith(SKILLS_ROOT)) {
    throw new Error('Path traversal detected: access denied');
  }
  return fullPath;
}

// ==========================================
// TOOLS.md management — inject/remove tool entries
// ==========================================

function applyToolsEntry(toolsEntry) {
  if (!toolsEntry || !toolsEntry.keyword || !toolsEntry.line) return;

  // Ensure workspace directory and TOOLS.md exist
  if (!fs.existsSync(WORKSPACE_ROOT)) {
    fs.mkdirSync(WORKSPACE_ROOT, { recursive: true });
  }

  let content = '';
  if (fs.existsSync(TOOLS_MD_PATH)) {
    content = fs.readFileSync(TOOLS_MD_PATH, 'utf-8');
  }

  // Remove existing lines containing the keyword, then append the new line
  const lines = content.split('\n').filter(line => !line.includes(toolsEntry.keyword));

  // Strip trailing empty lines
  while (lines.length > 0 && lines[lines.length - 1].trim() === '') {
    lines.pop();
  }

  // Append the new entry
  lines.push(toolsEntry.line);

  fs.writeFileSync(TOOLS_MD_PATH, lines.join('\n') + '\n', 'utf-8');
}

function removeToolsEntry(toolsEntry) {
  if (!toolsEntry || !toolsEntry.keyword) return;
  if (!fs.existsSync(TOOLS_MD_PATH)) return;

  const keyword = toolsEntry.keyword;
  const content = fs.readFileSync(TOOLS_MD_PATH, 'utf-8');
  const lines = content.split('\n');

  // Remove lines containing the keyword
  const filtered = lines.filter(line => !line.includes(keyword));

  // Clean up trailing empty lines
  while (filtered.length > 0 && filtered[filtered.length - 1].trim() === '') {
    filtered.pop();
  }

  const newContent = filtered.length > 0 ? filtered.join('\n') + '\n' : '';
  fs.writeFileSync(TOOLS_MD_PATH, newContent, 'utf-8');
}

// ==========================================
// AGENTS.md management — inject/remove agent entries
// ==========================================

function applyAgentsEntry(agentsEntry) {
  if (!agentsEntry || !agentsEntry.keyword || !agentsEntry.line) return;

  // Ensure workspace directory and AGENTS.md exist
  if (!fs.existsSync(WORKSPACE_ROOT)) {
    fs.mkdirSync(WORKSPACE_ROOT, { recursive: true });
  }

  let content = '';
  if (fs.existsSync(AGENTS_MD_PATH)) {
    content = fs.readFileSync(AGENTS_MD_PATH, 'utf-8');
  }

  // Remove existing lines containing the keyword, then append the new line
  const lines = content.split('\n').filter(line => !line.includes(agentsEntry.keyword));

  // Strip trailing empty lines
  while (lines.length > 0 && lines[lines.length - 1].trim() === '') {
    lines.pop();
  }

  // Append the new entry
  lines.push(agentsEntry.line);

  fs.writeFileSync(AGENTS_MD_PATH, lines.join('\n') + '\n', 'utf-8');
}

function removeAgentsEntry(agentsEntry) {
  if (!agentsEntry || !agentsEntry.keyword) return;
  if (!fs.existsSync(AGENTS_MD_PATH)) return;

  const keyword = agentsEntry.keyword;
  const content = fs.readFileSync(AGENTS_MD_PATH, 'utf-8');
  const lines = content.split('\n');

  // Remove lines containing the keyword
  const filtered = lines.filter(line => !line.includes(keyword));

  // Clean up trailing empty lines
  while (filtered.length > 0 && filtered[filtered.length - 1].trim() === '') {
    filtered.pop();
  }

  const newContent = filtered.length > 0 ? filtered.join('\n') + '\n' : '';
  fs.writeFileSync(AGENTS_MD_PATH, newContent, 'utf-8');
}

function findItem(itemId) {
  const registry = readExternalRegistry();
  return registry.items.find(i => i.id === itemId) || null;
}

function getItemStatus(itemId) {
  const item = findItem(itemId);
  if (!item) return null;

  const records = readInstallRecords();
  const record = records[itemId] || null;

  if (FILE_COPY_TYPES.includes(item.type) && item.skillDir) {
    const skillDirPath = resolveSkillDir(item.skillDir);
    const skillMdPath = path.join(skillDirPath, 'SKILL.md');
    const folderExists = fs.existsSync(skillDirPath);
    const skillMdExists = fs.existsSync(skillMdPath);

    // Installed = record exists AND folder exists on disk
    const installed = !!(record && folderExists);

    const result = { installed, folderExists };

    if (record) {
      result.installedVersion = record.version || null;
      result.installedAt = record.installedAt || null;
    }

    if (installed && record.version && item.version && record.version !== item.version) {
      result.updateAvailable = true;
      result.catalogVersion = item.version;
    }

    // Edge case: record exists but folder was deleted externally
    if (record && !folderExists) {
      result.status = 'broken';
    }

    return result;
  }

  if (item.type === 'exec') {
    if (record) {
      return {
        installed: true,
        installedVersion: record.version || null,
        installedAt: record.installedAt || null,
        updateAvailable: record.version && item.version && record.version !== item.version ? true : undefined,
        catalogVersion: record.version !== item.version ? item.version : undefined,
      };
    }
    return { installed: false };
  }

  // Tool type: check record + folder existence
  if ((item.type === 'tool' || item.type === 'template') && item.manifest && item.manifest.toolName) {
    const destPath = path.join(TOOLS_ROOT, item.manifest.toolName);
    const folderExists = fs.existsSync(destPath);
    const installed = !!(record && folderExists);

    const result = { installed, folderExists };

    if (record) {
      result.installedVersion = record.version || null;
      result.installedAt = record.installedAt || null;
    }

    if (installed && record.version && item.version && record.version !== item.version) {
      result.updateAvailable = true;
      result.catalogVersion = item.version;
    }

    if (record && !folderExists) {
      result.status = 'broken';
    }

    return result;
  }

  // Other types: check record only
  if (record) {
    return {
      installed: true,
      installedVersion: record.version || null,
      installedAt: record.installedAt || null,
      updateAvailable: record.version && item.version && record.version !== item.version ? true : undefined,
      catalogVersion: record.version !== item.version ? item.version : undefined,
    };
  }

  return { installed: false };
}

const DEFAULT_THEME_COLOR = '#6366f1';
const DEFAULT_ICON_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>';

function getCatalog() {
  const registry = readExternalRegistry();
  return registry.items.map(item => ({
    id: item.id,
    name: item.name,
    description: item.description,
    type: item.type,
    version: item.version,
    tags: item.tags || [],
    icon: item.icon || DEFAULT_ICON_SVG,
    themeColor: item.themeColor || DEFAULT_THEME_COLOR,
    builtin: !!item.builtin,
    dependencies: item.dependencies || [],
    hasToolsEntry: !!(item.manifest && item.manifest.toolsEntry && item.manifest.toolsEntry.keyword),
    hasAgentsEntry: !!(item.manifest && item.manifest.agentsEntry && item.manifest.agentsEntry.keyword),
    ...getItemStatus(item.id),
  }));
}

function getCatalogInstallState() {
  const registry = readExternalRegistry();
  const records = readInstallRecords();

  return registry.items.map(item => {
    const status = getItemStatus(item.id);
    return {
      id: item.id,
      name: item.name,
      type: item.type,
      catalogVersion: item.version,
      ...status,
    };
  });
}

/**
 * Create PATH-accessible bin symlinks for a tool package.
 * Reads the package.json `bin` field and creates symlinks in a PATH directory.
 * Tries ~/.local/bin first (user-writable, commonly in PATH), falls back to /usr/local/bin.
 * Each bin entry script is made executable and linked.
 */
function createBinLinks(sourcePath, destPath) {
  const binLinks = [];
  try {
    const pkgPath = path.join(sourcePath, 'package.json');
    if (!fs.existsSync(pkgPath)) return binLinks;
    const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf-8'));
    if (!pkg.bin || typeof pkg.bin !== 'object') return binLinks;

    // Try writable bin directories in preference order
    const BIN_CANDIDATES = [
      path.join(os.homedir(), '.local', 'bin'),
      '/usr/local/bin',
    ];

    // Find the first writable bin dir
    let binDir = null;
    for (const candidate of BIN_CANDIDATES) {
      try {
        fs.mkdirSync(candidate, { recursive: true });
        fs.accessSync(candidate, fs.constants.W_OK);
        binDir = candidate;
        break;
      } catch (e) {
        console.warn(`[Marketplace] bin dir "${candidate}" not writable: ${e.message}`);
      }
    }
    if (!binDir) {
      console.warn('[Marketplace] No writable bin directory found, skipping bin links');
      return binLinks;
    }

    for (const [name, relScript] of Object.entries(pkg.bin)) {
      // Resolve the script path through any symlinks to ensure it exists
      const scriptPath = path.join(destPath, relScript);
      const linkPath = path.join(binDir, name);
      try {
        // Verify the target script actually exists (resolve through symlinks)
        const realScriptPath = fs.realpathSync(scriptPath);
        // Ensure the script is executable
        fs.chmodSync(realScriptPath, 0o755);
        // Remove existing link if present
        try { fs.unlinkSync(linkPath); } catch { /* doesn't exist */ }
        fs.symlinkSync(scriptPath, linkPath);
        binLinks.push(linkPath);
      } catch (e) {
        console.warn(`[Marketplace] Failed to create bin link "${name}" -> "${scriptPath}": ${e.message}`);
      }
    }
  } catch (e) {
    console.warn(`[Marketplace] bin link creation error: ${e.message}`);
  }
  return binLinks;
}

/**
 * Remove bin symlinks that were created during install.
 */
function removeBinLinks(binLinks) {
  if (!Array.isArray(binLinks)) return;
  for (const linkPath of binLinks) {
    try {
      const stat = fs.lstatSync(linkPath);
      if (stat.isSymbolicLink()) {
        fs.unlinkSync(linkPath);
      }
    } catch {
      // Already gone or not writable
    }
  }
}

function installItem(itemId) {
  const item = findItem(itemId);

  if (!item) {
    throw new Error(`Unknown item: ${itemId}`);
  }

  if (!item.manifest) {
    throw new Error(`Item "${itemId}" has no manifest`);
  }

  // Check prerequisites first
  const prerequisites = item.manifest.prerequisites || [];
  if (prerequisites.length > 0) {
    const unmet = prerequisites.filter(p => !isPrerequisiteMet(p));
    if (unmet.length > 0) {
      return { requiresAction: true, prerequisites: unmet, manifest: item.manifest };
    }
  }

  // Auto-install dependencies if not already installed
  const dependencies = item.dependencies || [];
  const installedDeps = [];
  for (const depId of dependencies) {
    const depStatus = getItemStatus(depId);
    if (!depStatus || !depStatus.installed) {
      const depItem = findItem(depId);
      if (!depItem) {
        throw new Error(`Missing dependency: "${depId}" is not available in the catalog`);
      }
      const depResult = installItem(depId);
      installedDeps.push({ id: depId, name: depItem.name, result: depResult });
    }
  }

  // Install manifest files for file-copy types (skill, mcp)
  if (FILE_COPY_TYPES.includes(item.type) && item.skillDir) {
    const destDir = resolveSkillDir(item.skillDir);
    fs.mkdirSync(destDir, { recursive: true });

    const files = item.manifest.files || [];
    const sourcePath = item.manifest.sourcePath ? path.resolve(item.manifest.sourcePath) : null;

    if (files.length > 0) {
      // Explicit files list provided
      for (const file of files) {
        if (typeof file === 'string' && sourcePath) {
          // Built-in skill: copy file from source directory
          const srcFile = path.join(sourcePath, file);
          const destFile = path.join(destDir, file);
          if (!destFile.startsWith(destDir)) {
            throw new Error('Path traversal detected in manifest file path');
          }
          if (fs.existsSync(srcFile)) {
            const destFileDir = path.dirname(destFile);
            fs.mkdirSync(destFileDir, { recursive: true });
            fs.copyFileSync(srcFile, destFile);
          }
        } else if (file.content !== undefined && file.path) {
          // External skill: inline content
          const filePath = path.join(destDir, file.path);
          const fileDir = path.dirname(filePath);
          // Validate target path stays within skill directory
          if (!filePath.startsWith(destDir)) {
            throw new Error('Path traversal detected in manifest file path');
          }
          fs.mkdirSync(fileDir, { recursive: true });
          fs.writeFileSync(filePath, file.content, 'utf-8');
        }
      }
    } else if (sourcePath && fs.existsSync(sourcePath)) {
      // No explicit files list — copy entire source directory recursively
      const copyDir = (srcDir, destBase) => {
        const entries = fs.readdirSync(srcDir, { withFileTypes: true });
        for (const entry of entries) {
          if (entry.name.startsWith('.') || entry.name === 'node_modules') continue;
          const srcPath = path.join(srcDir, entry.name);
          const dstPath = path.join(destBase, entry.name);
          if (!dstPath.startsWith(destDir)) continue; // safety check
          if (entry.isDirectory()) {
            fs.mkdirSync(dstPath, { recursive: true });
            copyDir(srcPath, dstPath);
          } else {
            fs.copyFileSync(srcPath, dstPath);
          }
        }
      };
      copyDir(sourcePath, destDir);
    }

    // Record install state in launcher.json
    writeInstallRecord(itemId, {
      version: item.version,
      installedAt: new Date().toISOString(),
      type: item.type,
      skillDir: item.skillDir,
    });

    // Recompute merged config from ALL installed marketplace items
    reapplyAllMarketplaceOverrides();

    // Apply TOOLS.md entry if specified
    applyToolsEntry(item.manifest.toolsEntry);
    // Apply AGENTS.md entry if specified
    applyAgentsEntry(item.manifest.agentsEntry);

    return { installed: true, path: `~/.openclaw/skills/${item.skillDir}/`, installedDeps };
  }

  // File-copy type without skillDir — record-only install
  if (FILE_COPY_TYPES.includes(item.type)) {
    // Record install state in launcher.json
    writeInstallRecord(itemId, {
      version: item.version,
      installedAt: new Date().toISOString(),
      type: item.type,
    });

    // Recompute merged config from ALL installed marketplace items
    reapplyAllMarketplaceOverrides();

    // Apply TOOLS.md entry if specified
    applyToolsEntry(item.manifest.toolsEntry);
    // Apply AGENTS.md entry if specified
    applyAgentsEntry(item.manifest.agentsEntry);

    return { installed: true, installedDeps };
  }

  // Exec type — execute a shell command
  if (item.type === 'exec' && item.manifest.command) {
    const ALLOWED_COMMANDS = ['claude'];
    const command = item.manifest.command;

    if (!ALLOWED_COMMANDS.includes(command)) {
      throw new Error(`Command "${command}" is not in the allowed commands list: ${ALLOWED_COMMANDS.join(', ')}`);
    }

    const args = Array.isArray(item.manifest.args) ? item.manifest.args : [];
    const MAX_EXEC_TIMEOUT = 600000;
    const timeout = Math.min(item.manifest.timeout || 300000, MAX_EXEC_TIMEOUT);
    const cwd = item.manifest.cwd || process.env.WORKSPACE_ROOT || '/workspace/data/.openclaw/workspace';

    if (!fs.existsSync(cwd)) {
      throw new Error(`Working directory does not exist: ${cwd}`);
    }

    try {
      const { execFileSync } = require('child_process');
      const output = execFileSync(command, args, {
        timeout,
        cwd,
        encoding: 'utf-8',
        maxBuffer: 1024 * 1024,
      });

      // Record install state in launcher.json
      writeInstallRecord(itemId, {
        version: item.version,
        installedAt: new Date().toISOString(),
        type: item.type,
      });

      // Recompute merged config from ALL installed marketplace items
      reapplyAllMarketplaceOverrides();

      // Apply TOOLS.md entry if specified
      applyToolsEntry(item.manifest.toolsEntry);
      // Apply AGENTS.md entry if specified
      applyAgentsEntry(item.manifest.agentsEntry);

      return {
        installed: true,
        executed: true,
        command: `${command} ${args.join(' ')}`,
        output: output.substring(0, 2000),
        exitCode: 0,
      };
    } catch (execErr) {
      const output = execErr.stdout || execErr.stderr || execErr.message;
      throw new Error(`Exec failed (exit ${execErr.status || 'timeout'}): ${output.substring(0, 500)}`);
    }
  }

  // Tool type — copy a tool package to ~/.openclaw/tools/
  // Also accept legacy 'template' type for backwards compatibility
  if ((item.type === 'tool' || item.type === 'template') && item.manifest.sourcePath && item.manifest.toolName) {
    const sourcePath = path.resolve(item.manifest.sourcePath);
    const destPath = path.join(TOOLS_ROOT, item.manifest.toolName);

    if (!fs.existsSync(sourcePath)) {
      throw new Error(`Source path does not exist: ${sourcePath}`);
    }

    fs.mkdirSync(TOOLS_ROOT, { recursive: true });

    // Remove existing symlink or directory at destination
    try {
      const stat = fs.lstatSync(destPath);
      if (stat.isSymbolicLink()) {
        fs.unlinkSync(destPath);
      } else if (stat.isDirectory()) {
        fs.rmSync(destPath, { recursive: true });
      }
    } catch {
      // Does not exist, fine
    }

    fs.cpSync(sourcePath, destPath, { recursive: true });

    // Run npm install if package.json exists (always run — handles fresh installs and updates)
    try {
      const pkgPath = path.join(destPath, 'package.json');
      if (fs.existsSync(pkgPath)) {
        const { execFileSync } = require('child_process');
        execFileSync('npm', ['install', '--production'], { cwd: destPath, timeout: 60000 });
      }
    } catch (npmErr) {
      console.warn(`[Marketplace] ${itemId}: npm install failed: ${npmErr.message}`);
    }

    // Create PATH-accessible bin symlinks from package.json bin field
    const binLinks = createBinLinks(destPath, destPath);

    // Check if bin links were expected but failed
    let binWarning;
    try {
      const pkg = JSON.parse(fs.readFileSync(path.join(sourcePath, 'package.json'), 'utf-8'));
      if (pkg.bin && typeof pkg.bin === 'object' && Object.keys(pkg.bin).length > 0 && binLinks.length === 0) {
        binWarning = 'Bin links expected but could not be created — will retry on next server start';
        console.warn(`[Marketplace] ${itemId}: ${binWarning}`);
      }
    } catch { /* no package.json or no bin field */ }

    // Record install state in launcher.json
    writeInstallRecord(itemId, {
      version: item.version,
      installedAt: new Date().toISOString(),
      type: item.type,
      toolName: item.manifest.toolName,
      path: destPath,
      binLinks: binLinks.length > 0 ? binLinks : undefined,
    });

    // Recompute merged config from ALL installed marketplace items
    reapplyAllMarketplaceOverrides();

    // Apply TOOLS.md entry if specified
    applyToolsEntry(item.manifest.toolsEntry);
    // Apply AGENTS.md entry if specified
    applyAgentsEntry(item.manifest.agentsEntry);

    return { installed: true, path: destPath, copied: true, binLinks, binWarning };
  }

  throw new Error(`Install not supported for type: ${item.type}`);
}

function isPrerequisiteMet(prerequisite) {
  if (!prerequisite || !prerequisite.type) return true;
  if (prerequisite.type === 'billing' && prerequisite.agreementId) {
    const agreementFile = path.join(AGREEMENTS_DIR, `${prerequisite.agreementId}.json`);
    return fs.existsSync(agreementFile);
  }
  return true;
}

function acknowledgePrerequisite(itemId, prerequisiteId) {
  if (!itemId || typeof itemId !== 'string') {
    throw new Error('itemId is required');
  }
  if (!prerequisiteId || typeof prerequisiteId !== 'string') {
    throw new Error('prerequisiteId is required');
  }
  fs.mkdirSync(AGREEMENTS_DIR, { recursive: true });
  const agreementFile = path.join(AGREEMENTS_DIR, `${prerequisiteId}.json`);
  fs.writeFileSync(agreementFile, JSON.stringify({
    acknowledgedAt: new Date().toISOString(),
    itemId,
  }, null, 2), 'utf-8');
  return { acknowledged: true };
}

/**
 * Recompute the merged config from ALL currently-installed marketplace items.
 *
 * Instead of applying/reversing individual item overrides (which causes items
 * to override each other), this function:
 *   1. Unmerges ALL previously-applied overrides to recover the "base" config
 *   2. Re-merges overrides from every currently-installed item using fresh catalog data
 *   3. Writes the result and updates each install record's appliedOverrides
 *
 * @param {Object[]} extraOverridesToUnmerge - additional appliedOverrides objects
 *   to unmerge (e.g. from a record that was just deleted before calling this)
 */
function reapplyAllMarketplaceOverrides(extraOverridesToUnmerge = []) {
  const config = openclawConfig.readConfig();
  if (!config) return;

  const records = readInstallRecords();
  const registry = readExternalRegistry();

  // Step 1: Unmerge all previously-applied overrides to get "base" config
  let baseConfig = JSON.parse(JSON.stringify(config));
  for (const record of Object.values(records)) {
    if (record.appliedOverrides) {
      baseConfig = openclawConfig.unmergeConfig(baseConfig, record.appliedOverrides);
    }
  }
  for (const overrides of extraOverridesToUnmerge) {
    baseConfig = openclawConfig.unmergeConfig(baseConfig, overrides);
  }

  // Step 2: Re-merge overrides from all currently-installed items using catalog data
  let mergedConfig = JSON.parse(JSON.stringify(baseConfig));
  for (const itemId of Object.keys(records)) {
    const item = registry.items.find(i => i.id === itemId);
    if (item && item.manifest && item.manifest.overrides && item.manifest.overrides.config) {
      mergedConfig = openclawConfig.mergeConfig(mergedConfig, item.manifest.overrides.config);
    }
  }

  // Step 3: Write the merged config
  openclawConfig.writeConfig(mergedConfig);

  // Step 4: Update appliedOverrides in each install record to match current catalog
  const lc = openclawConfig.readLauncherConfig() || {};
  if (lc.marketplace && lc.marketplace.installed) {
    for (const itemId of Object.keys(records)) {
      if (!lc.marketplace.installed[itemId]) continue;
      const item = registry.items.find(i => i.id === itemId);
      if (item && item.manifest && item.manifest.overrides && item.manifest.overrides.config) {
        lc.marketplace.installed[itemId].appliedOverrides = item.manifest.overrides.config;
      } else if (lc.marketplace.installed[itemId].appliedOverrides) {
        delete lc.marketplace.installed[itemId].appliedOverrides;
      }
    }
    openclawConfig.writeLauncherConfig(lc);
  }
}

function uninstallItem(itemId) {
  const item = findItem(itemId);
  if (!item) {
    throw new Error(`Unknown item: ${itemId}`);
  }

  // Remove TOOLS.md entry if specified
  if (item.manifest) {
    removeToolsEntry(item.manifest.toolsEntry);
    removeAgentsEntry(item.manifest.agentsEntry);
  }

  // Save applied overrides and bin links before removing the record
  const records = readInstallRecords();
  const removedOverrides = records[itemId] && records[itemId].appliedOverrides
    ? [records[itemId].appliedOverrides] : [];

  // Clean up bin links if this was a template install
  if (records[itemId] && records[itemId].binLinks) {
    removeBinLinks(records[itemId].binLinks);
  }

  if (item.type === 'exec') {
    removeInstallRecord(itemId);
    // Recompute merged config from all remaining installed items
    reapplyAllMarketplaceOverrides(removedOverrides);
    return { installed: false };
  }

  if (FILE_COPY_TYPES.includes(item.type) && item.skillDir) {
    const skillDirPath = resolveSkillDir(item.skillDir);

    if (!fs.existsSync(skillDirPath)) {
      // Folder already gone — just clean up the record
      removeInstallRecord(itemId);
      reapplyAllMarketplaceOverrides(removedOverrides);
      return { installed: false };
    }

    // Remove the entire skill directory
    fs.rmSync(skillDirPath, { recursive: true, force: true });
    removeInstallRecord(itemId);
    // Recompute merged config from all remaining installed items
    reapplyAllMarketplaceOverrides(removedOverrides);
    return { installed: false };
  }

  // File-copy type without skillDir — just remove the record
  if (FILE_COPY_TYPES.includes(item.type)) {
    removeInstallRecord(itemId);
    reapplyAllMarketplaceOverrides(removedOverrides);
    return { installed: false };
  }

  // Tool type — remove copied tool at ~/.openclaw/tools/<toolName>/
  if ((item.type === 'tool' || item.type === 'template') && item.manifest && item.manifest.toolName) {
    const destPath = path.join(TOOLS_ROOT, item.manifest.toolName);
    try {
      const stat = fs.lstatSync(destPath);
      if (stat.isSymbolicLink()) {
        fs.unlinkSync(destPath);
      } else if (stat.isDirectory()) {
        fs.rmSync(destPath, { recursive: true, force: true });
      }
    } catch {
      // Already gone
    }
    removeInstallRecord(itemId);
    reapplyAllMarketplaceOverrides(removedOverrides);
    return { installed: false };
  }

  throw new Error(`Uninstall not supported for type: ${item.type}`);
}

/**
 * Resolve preview files for an item, handling both inline-content objects
 * and string file names that need to be read from sourcePath on disk.
 * Returns array of { path, content } objects.
 */
function resolvePreviewFiles(item) {
  const manifest = item.manifest || {};
  const rawFiles = manifest.files || [];
  const sourcePath = manifest.sourcePath ? path.resolve(manifest.sourcePath) : null;

  const resolved = [];
  for (const file of rawFiles) {
    if (typeof file === 'string') {
      // Built-in item: read file from sourcePath
      if (sourcePath) {
        const filePath = path.join(sourcePath, file);
        try {
          const content = fs.readFileSync(filePath, 'utf-8');
          resolved.push({ path: file, content });
        } catch {
          resolved.push({ path: file, content: `(File not found: ${file})` });
        }
      }
    } else if (file && file.path) {
      // External item: inline content object
      resolved.push(file);
    }
  }

  // For items with sourcePath and no explicit files array, scan directory
  if (resolved.length === 0 && sourcePath && fs.existsSync(sourcePath)) {
    const hasSkillMd = fs.existsSync(path.join(sourcePath, 'SKILL.md'));
    const scanFiles = (dir, prefix) => {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      for (const entry of entries) {
        if (entry.name.startsWith('.') || entry.name === 'node_modules') continue;
        // Skip lowercase skill.md if SKILL.md exists (avoid duplicates)
        if (entry.name === 'skill.md' && hasSkillMd && !prefix) continue;
        const relPath = prefix ? `${prefix}/${entry.name}` : entry.name;
        if (entry.isDirectory()) {
          scanFiles(path.join(dir, entry.name), relPath);
        } else {
          try {
            const content = fs.readFileSync(path.join(dir, entry.name), 'utf-8');
            resolved.push({ path: relPath, content });
          } catch {
            // Skip unreadable files
          }
        }
      }
    };
    scanFiles(sourcePath, '');
  }

  // Sort SKILL.md to front so it's the default preview content
  resolved.sort((a, b) => {
    const aIsSkill = a.path === 'SKILL.md';
    const bIsSkill = b.path === 'SKILL.md';
    if (aIsSkill && !bIsSkill) return -1;
    if (!aIsSkill && bIsSkill) return 1;
    return 0;
  });

  return resolved;
}

/**
 * Ensure bin links exist for all installed tool packages.
 * Called at server startup to repair missing bin links (e.g., after container restart).
 * Also migrates old 'template' type records to 'tool'.
 */
function ensureBinLinks() {
  const records = readInstallRecords();
  // Migrate old 'template' records to 'tool'
  let needsWrite = false;
  for (const [itemId, record] of Object.entries(records)) {
    if (record.type === 'template') {
      record.type = 'tool';
      needsWrite = true;
    }
  }
  if (needsWrite) {
    const lc = openclawConfig.readLauncherConfig() || {};
    if (lc.marketplace && lc.marketplace.installed) {
      for (const [itemId, record] of Object.entries(records)) {
        if (lc.marketplace.installed[itemId]) {
          lc.marketplace.installed[itemId].type = record.type;
        }
      }
      openclawConfig.writeLauncherConfig(lc);
    }
  }
  for (const [itemId, record] of Object.entries(records)) {
    if (record.type !== 'tool' || !record.toolName || !record.path) continue;
    const destPath = record.path;
    if (!fs.existsSync(destPath)) continue;
    const created = createBinLinks(destPath, destPath);
    if (created.length > 0 && !record.binLinks) {
      // Update record with bin links
      writeInstallRecord(itemId, { ...record, binLinks: created });
    }
  }
}

module.exports = {
  FILE_COPY_TYPES,
  getCatalog,
  getCatalogInstallState,
  findItem,
  installItem,
  uninstallItem,
  getItemStatus,
  acknowledgePrerequisite,
  isBuiltinItem,
  readExternalRegistry,
  readExternalRegistryOnly,
  writeExternalRegistry,
  validateRegistryItem,
  resolvePreviewFiles,
  ensureBinLinks,
  removeInstallRecord,
};

const https = require('https');

const TELEGRAM_API_BASE = 'https://api.telegram.org';

function telegramRequest(token, method, timeoutMs = 5000) {
  return new Promise((resolve, reject) => {
    const url = `${TELEGRAM_API_BASE}/bot${token}/${method}`;
    const req = https.get(url, { family: 4 }, (res) => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          resolve(parsed);
        } catch (err) {
          reject(new Error('Invalid JSON response from Telegram API'));
        }
      });
    });
    req.on('error', (err) => {
      reject(new Error(err.message || `Network error connecting to Telegram API: ${err.code || 'unknown'}`));
    });
    req.setTimeout(timeoutMs, () => {
      req.destroy();
      reject(new Error('Telegram API request timed out'));
    });
  });
}

async function validateBotToken(token) {
  if (!token || typeof token !== 'string') {
    throw new Error('Bot token is required and must be a string');
  }

  const tokenPattern = /^\d+:[A-Za-z0-9_-]+$/;
  if (!tokenPattern.test(token)) {
    throw new Error('Invalid bot token format. Expected format: 123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11');
  }

  const result = await telegramRequest(token, 'getMe');

  if (!result.ok) {
    throw new Error(result.description || 'Telegram API returned an error');
  }

  return {
    valid: true,
    bot: {
      id: result.result.id,
      isBot: result.result.is_bot,
      firstName: result.result.first_name,
      username: result.result.username,
      canJoinGroups: result.result.can_join_groups,
      canReadAllGroupMessages: result.result.can_read_all_group_messages,
      supportsInlineQueries: result.result.supports_inline_queries,
    },
  };
}

function buildTelegramChannelConfig(botToken, botInfo) {
  return {
    channels: {
      telegram: {
        accounts: {
          default: {
            botToken: botToken,
            dmPolicy: 'pairing',
            streamMode: 'partial',
            historyLimit: 20,
          },
        },
      },
    },
    plugins: {
      entries: {
        telegram: {
          enabled: true,
        },
      },
    },
  };
}

module.exports = {
  validateBotToken,
  buildTelegramChannelConfig,
  telegramRequest,
};

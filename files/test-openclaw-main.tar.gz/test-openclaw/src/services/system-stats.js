const { execSync } = require('child_process');
const os = require('os');
const fs = require('fs');

const STATS_FILE = '/tmp/openclaw-system-stats.json';
const MAX_ENTRIES = 1440; // 24 hours of 1-minute samples
const MAX_AGE_MS = 24 * 60 * 60 * 1000; // 24 hours in milliseconds

let _statsHistory = [];
let _collectorInterval = null;
let _gpuAvailable = null; // null = not yet probed
let _cgroupVersion = null; // null = not yet probed, 2, 1, or 0 (no cgroup)

function _probeGpu() {
  if (_gpuAvailable !== null) return _gpuAvailable;
  try {
    execSync('which nvidia-smi', { encoding: 'utf-8', timeout: 3000, stdio: 'pipe' });
    _gpuAvailable = true;
  } catch {
    _gpuAvailable = false;
  }
  return _gpuAvailable;
}

function _readFile(path) {
  try { return fs.readFileSync(path, 'utf-8').trim(); } catch { return null; }
}

function _detectCgroup() {
  if (_cgroupVersion !== null) return _cgroupVersion;
  if (_readFile('/sys/fs/cgroup/memory.max') !== null) {
    _cgroupVersion = 2;
  } else if (_readFile('/sys/fs/cgroup/memory/memory.limit_in_bytes') !== null) {
    _cgroupVersion = 1;
  } else {
    _cgroupVersion = 0;
  }
  return _cgroupVersion;
}

function _getProcessCount() {
  let total = 0;
  let zombie = 0;
  try {
    // Count PIDs in /proc (container-scoped via PID namespace)
    const pids = fs.readdirSync('/proc').filter(e => /^\d+$/.test(e));
    total = pids.length;
    // Count zombies by checking /proc/<pid>/status for State: Z
    for (const pid of pids) {
      try {
        const status = fs.readFileSync('/proc/' + pid + '/status', 'utf-8');
        const m = status.match(/^State:\s+Z/m);
        if (m) zombie++;
      } catch { /* process may have exited */ }
    }
  } catch {
    try {
      const out = execSync('ps -e --no-headers | wc -l', { encoding: 'utf-8', timeout: 3000, stdio: 'pipe' });
      total = parseInt(out.trim(), 10) || 0;
    } catch { /* ignore */ }
  }
  return { total, zombie };
}

function _getCgroupMemory() {
  const ver = _detectCgroup();

  if (ver === 2) {
    const maxRaw = _readFile('/sys/fs/cgroup/memory.max');
    const currentRaw = _readFile('/sys/fs/cgroup/memory.current');
    if (!currentRaw) return null;

    const current = parseInt(currentRaw, 10);
    // memory.max can be "max" (no limit) — fall back to os.totalmem()
    const limit = maxRaw === 'max' ? os.totalmem() : parseInt(maxRaw, 10);

    // Subtract inactive_file (reclaimable cache) for real usage
    let cache = 0;
    const stat = _readFile('/sys/fs/cgroup/memory.stat');
    if (stat) {
      const m = stat.match(/^inactive_file\s+(\d+)/m);
      if (m) cache = parseInt(m[1], 10);
    }
    const used = current - cache;
    return { totalBytes: limit, usedBytes: Math.max(used, 0) };
  }

  if (ver === 1) {
    const limitRaw = _readFile('/sys/fs/cgroup/memory/memory.limit_in_bytes');
    const usageRaw = _readFile('/sys/fs/cgroup/memory/memory.usage_in_bytes');
    if (!usageRaw) return null;

    const usage = parseInt(usageRaw, 10);
    // Absurdly large limit means no cap — fall back to os.totalmem()
    let limit = parseInt(limitRaw, 10);
    if (limit > os.totalmem() * 2) limit = os.totalmem();

    // Subtract cache for real usage
    let cache = 0;
    const stat = _readFile('/sys/fs/cgroup/memory/memory.stat');
    if (stat) {
      const m = stat.match(/^total_inactive_file\s+(\d+)/m) || stat.match(/^cache\s+(\d+)/m);
      if (m) cache = parseInt(m[1], 10);
    }
    const used = usage - cache;
    return { totalBytes: limit, usedBytes: Math.max(used, 0) };
  }

  return null;
}

function _getMemory() {
  const cg = _getCgroupMemory();
  let totalBytes, usedBytes;

  if (cg) {
    totalBytes = cg.totalBytes;
    usedBytes = cg.usedBytes;
  } else {
    totalBytes = os.totalmem();
    usedBytes = totalBytes - os.freemem();
  }

  const totalMB = Math.round(totalBytes / 1024 / 1024);
  const usedMB = Math.round(usedBytes / 1024 / 1024);
  const usedPercent = totalBytes > 0 ? parseFloat(((usedBytes / totalBytes) * 100).toFixed(1)) : 0;
  return { totalMB, usedMB, usedPercent, source: cg ? 'cgroup' : 'os' };
}

function _getHeap() {
  const mem = process.memoryUsage();
  return {
    rssMB: parseFloat((mem.rss / 1024 / 1024).toFixed(1)),
    heapUsedMB: parseFloat((mem.heapUsed / 1024 / 1024).toFixed(1)),
    heapTotalMB: parseFloat((mem.heapTotal / 1024 / 1024).toFixed(1)),
  };
}

function _getGpu() {
  if (!_probeGpu()) return null;
  try {
    const out = execSync(
      'nvidia-smi --query-gpu=name,memory.used,memory.total,utilization.gpu,temperature.gpu --format=csv,noheader,nounits',
      { encoding: 'utf-8', timeout: 5000, stdio: 'pipe' }
    );
    const parts = out.trim().split(',').map(s => s.trim());
    if (parts.length < 5) return null;
    return {
      name: parts[0],
      usedMB: parseInt(parts[1], 10) || 0,
      totalMB: parseInt(parts[2], 10) || 0,
      utilPercent: parseInt(parts[3], 10) || 0,
      tempC: parseInt(parts[4], 10) || 0,
    };
  } catch {
    return null;
  }
}

function _getStorage() {
  let workspaceMB = 0;
  try {
    const out = execSync('du -sm /workspace 2>/dev/null', { encoding: 'utf-8', timeout: 15000, stdio: 'pipe' });
    workspaceMB = parseInt(out.trim().split(/\s+/)[0], 10) || 0;
  } catch { /* ignore */ }
  return { workspaceMB };
}

let _prevCpuUsage = null; // { usageUsec, timestamp } for delta calc

function _getCpu() {
  const ver = _detectCgroup();
  const cpuCount = os.cpus().length;
  const result = { cores: cpuCount };

  // Read quota
  if (ver === 2) {
    const cpuMax = _readFile('/sys/fs/cgroup/cpu.max');
    if (cpuMax && cpuMax !== 'max') {
      const parts = cpuMax.split(/\s+/);
      if (parts[0] !== 'max') {
        const quota = parseInt(parts[0], 10);
        const period = parseInt(parts[1], 10) || 100000;
        result.quotaCores = parseFloat((quota / period).toFixed(2));
      }
    }
  } else if (ver === 1) {
    const quota = _readFile('/sys/fs/cgroup/cpu/cpu.cfs_quota_us');
    const period = _readFile('/sys/fs/cgroup/cpu/cpu.cfs_period_us');
    if (quota && parseInt(quota, 10) > 0) {
      result.quotaCores = parseFloat((parseInt(quota, 10) / (parseInt(period, 10) || 100000)).toFixed(2));
    }
  }

  // Read usage for utilization %
  let usageUsec = null;
  if (ver === 2) {
    const stat = _readFile('/sys/fs/cgroup/cpu.stat');
    if (stat) {
      const m = stat.match(/^usage_usec\s+(\d+)/m);
      if (m) usageUsec = parseInt(m[1], 10);
    }
  } else if (ver === 1) {
    const raw = _readFile('/sys/fs/cgroup/cpu/cpuacct.usage');
    if (raw) usageUsec = Math.floor(parseInt(raw, 10) / 1000); // ns -> us
  }

  if (usageUsec !== null) {
    const now = Date.now();
    if (_prevCpuUsage) {
      const deltaUsec = usageUsec - _prevCpuUsage.usageUsec;
      const deltaMs = now - _prevCpuUsage.timestamp;
      if (deltaMs > 0) {
        // deltaUsec is CPU time used, deltaMs*1000 is wall-clock in usec
        const effectiveCores = result.quotaCores || cpuCount;
        const pct = (deltaUsec / (deltaMs * 1000)) / effectiveCores * 100;
        const rounded = parseFloat(Math.min(pct, 100).toFixed(1));
        if (rounded > 0) result.usagePercent = rounded;
      }
    }
    _prevCpuUsage = { usageUsec, timestamp: now };
  }

  return result;
}

function collectSnapshot() {
  const [load1, load5, load15] = os.loadavg();
  return {
    timestamp: new Date().toISOString(),
    processes: _getProcessCount(),
    memory: _getMemory(),
    cpu: _getCpu(),
    heap: _getHeap(),
    gpu: _getGpu(),
    storage: _getStorage(),
    load: {
      load1: parseFloat(load1.toFixed(2)),
      load5: parseFloat(load5.toFixed(2)),
      load15: parseFloat(load15.toFixed(2)),
    },
  };
}

function _pruneOldEntries() {
  const cutoff = Date.now() - MAX_AGE_MS;
  _statsHistory = _statsHistory.filter(e => new Date(e.timestamp).getTime() >= cutoff);
}

function _persistToDisk() {
  try {
    fs.writeFileSync(STATS_FILE, JSON.stringify(_statsHistory), 'utf-8');
  } catch (err) {
    console.error('[SystemStats] Failed to persist:', err.message);
  }
}

function _loadFromDisk() {
  try {
    if (fs.existsSync(STATS_FILE)) {
      const raw = fs.readFileSync(STATS_FILE, 'utf-8');
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        _statsHistory = parsed.slice(-MAX_ENTRIES);
        _pruneOldEntries();
      }
    }
  } catch {
    _statsHistory = [];
  }
}

function _collect() {
  const snapshot = collectSnapshot();
  _statsHistory.push(snapshot);
  _pruneOldEntries();
  if (_statsHistory.length > MAX_ENTRIES) {
    _statsHistory = _statsHistory.slice(-MAX_ENTRIES);
  }
  _persistToDisk();
}

function startCollector(intervalMs = 60000) {
  if (_collectorInterval) return;
  _loadFromDisk();
  _collect(); // immediate first sample
  _collectorInterval = setInterval(_collect, intervalMs);
  console.log('[SystemStats] Collector started (interval: ' + (intervalMs / 1000) + 's)');
}

function stopCollector() {
  if (_collectorInterval) {
    clearInterval(_collectorInterval);
    _collectorInterval = null;
    console.log('[SystemStats] Collector stopped');
  }
}

function getHistory(rangeMinutes) {
  if (!rangeMinutes) return [..._statsHistory];
  const cutoff = Date.now() - rangeMinutes * 60 * 1000;
  return _statsHistory.filter(e => new Date(e.timestamp).getTime() >= cutoff);
}

function getLatest() {
  return _statsHistory.length > 0 ? _statsHistory[_statsHistory.length - 1] : null;
}

function resetHistory() {
  _statsHistory = [];
  _prevCpuUsage = null;
  try { fs.unlinkSync(STATS_FILE); } catch { /* ignore */ }
  // Collect a fresh first sample immediately
  _collect();
}

function _aggregateWindow(entries) {
  if (entries.length === 0) return null;
  let cpuSum = 0, cpuMax = 0, cpuCount = 0;
  let memPctSum = 0, memPctMax = 0;
  let memMbSum = 0, memMbMax = 0;

  for (const e of entries) {
    if (e.cpu && typeof e.cpu.usagePercent === 'number') {
      cpuSum += e.cpu.usagePercent;
      cpuMax = Math.max(cpuMax, e.cpu.usagePercent);
      cpuCount++;
    }
    if (e.memory) {
      memPctSum += e.memory.usedPercent;
      memPctMax = Math.max(memPctMax, e.memory.usedPercent);
      memMbSum += e.memory.usedMB;
      memMbMax = Math.max(memMbMax, e.memory.usedMB);
    }
  }

  return {
    samples: entries.length,
    cpu: {
      avgPercent: cpuCount > 0 ? parseFloat((cpuSum / cpuCount).toFixed(1)) : null,
      maxPercent: cpuCount > 0 ? cpuMax : null,
    },
    memory: {
      avgPercent: parseFloat((memPctSum / entries.length).toFixed(1)),
      maxPercent: memPctMax,
      avgMB: Math.round(memMbSum / entries.length),
      maxMB: memMbMax,
    },
  };
}

function getSummary() {
  const now = Date.now();
  const latest = getLatest();
  const last1m = _aggregateWindow(
    _statsHistory.filter(e => new Date(e.timestamp).getTime() >= now - 1 * 60 * 1000)
  );
  const last5m = _aggregateWindow(
    _statsHistory.filter(e => new Date(e.timestamp).getTime() >= now - 5 * 60 * 1000)
  );
  const last30m = _aggregateWindow(
    _statsHistory.filter(e => new Date(e.timestamp).getTime() >= now - 30 * 60 * 1000)
  );
  const last1h = _aggregateWindow(
    _statsHistory.filter(e => new Date(e.timestamp).getTime() >= now - 60 * 60 * 1000)
  );

  const [load1, load5, load15] = os.loadavg();

  return {
    latest,
    last1m,
    last5m,
    last30m,
    last1h,
    load: {
      load1: parseFloat(load1.toFixed(2)),
      load5: parseFloat(load5.toFixed(2)),
      load15: parseFloat(load15.toFixed(2)),
    },
  };
}

module.exports = { collectSnapshot, startCollector, stopCollector, getHistory, getLatest, resetHistory, getSummary };

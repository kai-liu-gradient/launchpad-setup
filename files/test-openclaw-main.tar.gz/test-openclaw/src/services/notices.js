const fs = require('fs');
const path = require('path');
const os = require('os');

const OPENCLAW_DIR = path.join(os.homedir(), '.openclaw');
const NOTICES_PATH = path.join(OPENCLAW_DIR, 'notices.json');
const DISMISSALS_PATH = path.join(OPENCLAW_DIR, 'notice-dismissals.json');

const MAX_NOTICES = 50;
const VALID_TYPES = ['banner', 'inbox', 'both'];
const VALID_PRIORITIES = ['info', 'warning', 'critical'];

// Priority sort order: critical > warning > info
const PRIORITY_ORDER = { critical: 0, warning: 1, info: 2 };

function ensureDir() {
  if (!fs.existsSync(OPENCLAW_DIR)) {
    fs.mkdirSync(OPENCLAW_DIR, { recursive: true });
  }
}

// ==========================================
// Notice Storage
// ==========================================

function readNotices() {
  try {
    const content = fs.readFileSync(NOTICES_PATH, 'utf-8');
    const parsed = JSON.parse(content);
    return { notices: Array.isArray(parsed.notices) ? parsed.notices : [] };
  } catch {
    return { notices: [] };
  }
}

function writeNotices(data) {
  ensureDir();
  fs.writeFileSync(NOTICES_PATH, JSON.stringify(data, null, 2), { mode: 0o600 });
}

function validateNotice(notice) {
  const errors = [];
  if (!notice || typeof notice !== 'object') return ['notice must be an object'];

  if (!notice.id || typeof notice.id !== 'string') errors.push('id is required and must be a string');
  if (!notice.type || !VALID_TYPES.includes(notice.type)) errors.push(`type must be one of: ${VALID_TYPES.join(', ')}`);
  if (!notice.priority || !VALID_PRIORITIES.includes(notice.priority)) errors.push(`priority must be one of: ${VALID_PRIORITIES.join(', ')}`);
  if (!notice.title || typeof notice.title !== 'string') errors.push('title is required and must be a string');
  else if (notice.title.length > 120) errors.push('title must be 120 characters or fewer');
  if (!notice.message || typeof notice.message !== 'string') errors.push('message is required and must be a string');
  else if (notice.message.length > 2000) errors.push('message must be 2000 characters or fewer');

  // Optional fields
  if (notice.actionUrl !== undefined && typeof notice.actionUrl !== 'string') errors.push('actionUrl must be a string');
  if (notice.actionLabel !== undefined && typeof notice.actionLabel !== 'string') errors.push('actionLabel must be a string');
  if (notice.expiresAt !== undefined) {
    if (typeof notice.expiresAt !== 'string') errors.push('expiresAt must be an ISO 8601 string');
    else if (isNaN(Date.parse(notice.expiresAt))) errors.push('expiresAt must be a valid ISO 8601 timestamp');
  }
  if (notice.dismissible !== undefined && typeof notice.dismissible !== 'boolean') errors.push('dismissible must be a boolean');

  return errors;
}

function addNotice(notice) {
  const data = readNotices();

  if (data.notices.length >= MAX_NOTICES) {
    return { error: `Maximum ${MAX_NOTICES} notices allowed. Remove old notices before adding new ones.` };
  }

  // Replace if notice with same ID exists
  const existingIdx = data.notices.findIndex(n => n.id === notice.id);

  const enriched = {
    ...notice,
    createdAt: new Date().toISOString(),
    dismissible: notice.dismissible !== undefined ? notice.dismissible : true,
  };

  if (existingIdx >= 0) {
    data.notices[existingIdx] = enriched;
  } else {
    data.notices.push(enriched);
  }

  writeNotices(data);
  return { notice: enriched, replaced: existingIdx >= 0 };
}

function removeNotice(noticeId) {
  const data = readNotices();
  const idx = data.notices.findIndex(n => n.id === noticeId);
  if (idx === -1) return { found: false };

  data.notices.splice(idx, 1);
  writeNotices(data);

  // Clean up dismissal for removed notice
  const dismissals = readDismissals();
  if (dismissals[noticeId]) {
    delete dismissals[noticeId];
    writeDismissals(dismissals);
  }

  return { found: true };
}

function getActiveNotices() {
  const data = readNotices();
  const now = new Date();

  return data.notices
    .filter(n => {
      if (n.expiresAt && new Date(n.expiresAt) < now) return false;
      return true;
    })
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

// ==========================================
// Dismissal Management
// ==========================================

function readDismissals() {
  try {
    const content = fs.readFileSync(DISMISSALS_PATH, 'utf-8');
    const parsed = JSON.parse(content);
    return typeof parsed === 'object' && parsed !== null ? parsed : {};
  } catch {
    return {};
  }
}

function writeDismissals(data) {
  ensureDir();
  fs.writeFileSync(DISMISSALS_PATH, JSON.stringify(data, null, 2), { mode: 0o600 });
}

function dismissNotice(noticeId) {
  const dismissals = readDismissals();
  dismissals[noticeId] = { dismissedAt: new Date().toISOString() };
  writeDismissals(dismissals);
}

function dismissAllNotices() {
  const active = getActiveNotices();
  const dismissals = readDismissals();
  const now = new Date().toISOString();

  for (const notice of active) {
    if (notice.dismissible !== false && !dismissals[notice.id]) {
      dismissals[notice.id] = { dismissedAt: now };
    }
  }

  writeDismissals(dismissals);
}

function isDismissed(noticeId) {
  const dismissals = readDismissals();
  return !!dismissals[noticeId];
}

function cleanupDismissals(activeNoticeIds) {
  const dismissals = readDismissals();
  const idSet = new Set(activeNoticeIds);
  let changed = false;

  for (const key of Object.keys(dismissals)) {
    if (!idSet.has(key)) {
      delete dismissals[key];
      changed = true;
    }
  }

  if (changed) {
    writeDismissals(dismissals);
  }
}

// ==========================================
// Combined Queries (for launcher API)
// ==========================================

function getNoticesForLauncher() {
  const active = getActiveNotices();
  const dismissals = readDismissals();

  // Clean up stale dismissals
  const activeIds = active.map(n => n.id);
  cleanupDismissals(activeIds);

  // Add dismissed flag and sort by priority then createdAt
  const notices = active
    .map(n => ({
      ...n,
      dismissed: !!dismissals[n.id],
    }))
    .sort((a, b) => {
      const pa = PRIORITY_ORDER[a.priority] ?? 3;
      const pb = PRIORITY_ORDER[b.priority] ?? 3;
      if (pa !== pb) return pa - pb;
      return new Date(b.createdAt) - new Date(a.createdAt);
    });

  const unreadCount = notices.filter(n => !n.dismissed).length;

  return { notices, unreadCount };
}

module.exports = {
  readNotices,
  writeNotices,
  validateNotice,
  addNotice,
  removeNotice,
  getActiveNotices,
  readDismissals,
  writeDismissals,
  dismissNotice,
  dismissAllNotices,
  isDismissed,
  cleanupDismissals,
  getNoticesForLauncher,
  MAX_NOTICES,
};

// Routes exempt from JSON content-type requirement (e.g. multipart/form-data uploads)
const JSON_EXEMPT_PATHS = ['/workspace/upload'];

function validateJsonBody(req, res, next) {
  if (req.method === 'POST' || req.method === 'PATCH' || req.method === 'PUT') {
    const isExempt = JSON_EXEMPT_PATHS.some((p) => req.path === p || req.path.endsWith(p));
    if (!isExempt && req.headers['content-type'] && !req.headers['content-type'].includes('application/json')) {
      return res.status(400).json({
        error: 'Bad Request',
        message: 'Content-Type must be application/json',
      });
    }
  }
  next();
}

function apiErrorHandler(err, req, res, _next) {
  console.error(`[API Error] ${req.method} ${req.path}:`, err.message);
  const status = err.statusCode || 500;
  res.status(status).json({
    error: status === 500 ? 'Internal Server Error' : 'Error',
    message: err.message,
  });
}

module.exports = {
  validateJsonBody,
  apiErrorHandler,
};

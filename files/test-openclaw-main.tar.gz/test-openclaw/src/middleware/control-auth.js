const crypto = require('crypto');
const openclawConfig = require('../services/openclaw-config');
const apiCallHistory = require('../services/api-call-history');

// Rate limiter for Control API requests
const requestCounts = new Map();
const RATE_LIMIT_WINDOW_MS = 60000; // 1 minute
const RATE_LIMIT_MAX = 60; // 60 requests per minute

function checkRateLimit(ip) {
  const now = Date.now();
  const entry = requestCounts.get(ip);
  if (!entry) return true;
  const valid = entry.filter(ts => now - ts < RATE_LIMIT_WINDOW_MS);
  if (valid.length === 0) {
    requestCounts.delete(ip);
    return true;
  }
  requestCounts.set(ip, valid);
  return valid.length < RATE_LIMIT_MAX;
}

function recordRequest(ip) {
  const now = Date.now();
  const entry = requestCounts.get(ip) || [];
  entry.push(now);
  requestCounts.set(ip, entry);
}

function sanitizeUrl(url) {
  try {
    const parsed = new URL(url, 'http://localhost');
    if (parsed.searchParams.has('token')) {
      parsed.searchParams.set('token', '***');
    }
    return parsed.pathname + parsed.search;
  } catch {
    return url;
  }
}

function controlAuth(req, res, next) {
  const requestId = req.headers['x-request-id'] || crypto.randomUUID();
  req.controlRequestId = requestId;
  res.setHeader('X-Request-Id', requestId);

  // Log all Control API requests (Task 29)
  const safeUrl = sanitizeUrl(req.originalUrl);
  console.log(`[Control API] ${req.method} ${safeUrl} requestId=${requestId} ip=${req.ip}`);

  // Intercept res.json to record modify calls (POST/PUT/DELETE) for troubleshooting
  const callStart = Date.now();
  if (req.method !== 'GET') {
    const originalJson = res.json.bind(res);
    res.json = function(body) {
      const sanitizedHeaders = { ...req.headers };
      if (sanitizedHeaders['x-control-key']) sanitizedHeaders['x-control-key'] = '***';
      if (sanitizedHeaders['authorization']) sanitizedHeaders['authorization'] = '***';
      apiCallHistory.recordCall({
        timestamp: callStart,
        requestId,
        source: 'control',
        method: req.method,
        path: sanitizeUrl(req.originalUrl),
        requestHeaders: sanitizedHeaders,
        requestBody: req.body || null,
        statusCode: res.statusCode,
        responseBody: body,
        durationMs: Date.now() - callStart,
        ip: req.ip,
      });
      return originalJson(body);
    };
  }

  // Rate limiting (Task 28)
  const ip = req.ip || req.socket.remoteAddress;
  if (!checkRateLimit(ip)) {
    return res.status(429).json({
      success: false,
      data: null,
      error: { code: 'RATE_LIMITED', message: 'Too many requests' },
    });
  }
  recordRequest(ip);

  // Check X-Control-Key header
  const controlKey = req.headers['x-control-key'];
  if (!controlKey) {
    return res.status(401).json({
      success: false,
      data: null,
      error: { code: 'UNAUTHORIZED', message: 'Missing X-Control-Key header' },
    });
  }

  // Read stored control key from launcher.json
  const launcher = openclawConfig.readLauncherConfig();
  const storedKey = launcher?.managedPool?.controlKey;
  if (!storedKey || !launcher?.managedPool?.enabled) {
    return res.status(401).json({
      success: false,
      data: null,
      error: { code: 'UNAUTHORIZED', message: 'Managed pool not enabled' },
    });
  }

  // Timing-safe comparison (Task 3)
  const expected = Buffer.from(storedKey, 'utf-8');
  const provided = Buffer.from(controlKey, 'utf-8');
  if (expected.length !== provided.length || !crypto.timingSafeEqual(expected, provided)) {
    return res.status(401).json({
      success: false,
      data: null,
      error: { code: 'UNAUTHORIZED', message: 'Invalid control key' },
    });
  }

  next();
}

// Instance ID validation middleware (Task 5)
function validateInstanceId(req, res, next) {
  const { id } = req.params;
  const launcher = openclawConfig.readLauncherConfig();
  const instanceId = launcher?.managedPool?.instanceId;

  if (!instanceId || id !== instanceId) {
    return res.status(404).json({
      success: false,
      data: null,
      error: { code: 'INSTANCE_NOT_FOUND', message: 'Instance not found' },
    });
  }

  next();
}

module.exports = {
  controlAuth,
  validateInstanceId,
};

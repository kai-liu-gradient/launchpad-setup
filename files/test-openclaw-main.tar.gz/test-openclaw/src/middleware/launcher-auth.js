const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const openclawConfig = require('../services/openclaw-config');

// In-memory rate limiter for login attempts
const loginAttempts = new Map();
const RATE_LIMIT_WINDOW_MS = 60000; // 1 minute
const RATE_LIMIT_MAX = 5;

function getJwtSecret() {
  const password = openclawConfig.getLauncherPassword();
  if (!password) return null;
  // Derive signing secret from the launcher password using HMAC
  return crypto.createHmac('sha256', password).update('launcher-jwt-secret').digest();
}

function verifyToken(token) {
  const secret = getJwtSecret();
  if (!secret) return null;
  try {
    return jwt.verify(token, secret);
  } catch {
    return null;
  }
}

function signToken(payload, expiresIn = '7d') {
  const secret = getJwtSecret();
  if (!secret) return null;
  return jwt.sign(payload, secret, { expiresIn });
}

// Paths that don't require authentication
const PUBLIC_PATHS = [
  '/auth/login',
  '/auth/verify',
  '/auth/status',
];

function isPublicPath(path) {
  return PUBLIC_PATHS.some(p => path === p || path === p + '/');
}

function launcherAuth(req, res, next) {
  // Allow public auth endpoints
  if (isPublicPath(req.path)) {
    return next();
  }

  // Check Authorization header
  let token = null;
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.slice(7);
  }

  // Fall back to cookie
  if (!token && req.headers.cookie) {
    const match = req.headers.cookie.match(/(?:^|;\s*)launcher_token=([^\s;]+)/);
    if (match) token = match[1];
  }

  if (!token) {
    return res.status(401).json({ error: 'unauthorized', message: 'Authentication required' });
  }

  const decoded = verifyToken(token);
  if (!decoded) {
    return res.status(401).json({ error: 'unauthorized', message: 'Authentication required' });
  }

  req.launcherUser = decoded;
  next();
}

function checkLoginRateLimit(ip) {
  const now = Date.now();
  const entry = loginAttempts.get(ip);
  if (!entry) return true;

  // Clean expired entries
  const validAttempts = entry.filter(ts => now - ts < RATE_LIMIT_WINDOW_MS);
  if (validAttempts.length === 0) {
    loginAttempts.delete(ip);
    return true;
  }
  loginAttempts.set(ip, validAttempts);
  return validAttempts.length < RATE_LIMIT_MAX;
}

function recordLoginAttempt(ip) {
  const now = Date.now();
  const entry = loginAttempts.get(ip) || [];
  entry.push(now);
  loginAttempts.set(ip, entry);
}

// Validate JWT from WebSocket upgrade query parameter
function verifyWebSocketToken(url) {
  const parsedUrl = new URL(url, 'http://localhost');
  const token = parsedUrl.searchParams.get('launcher_token');
  if (!token) return false;
  return !!verifyToken(token);
}

module.exports = {
  launcherAuth,
  verifyToken,
  signToken,
  getJwtSecret,
  checkLoginRateLimit,
  recordLoginAttempt,
  verifyWebSocketToken,
};

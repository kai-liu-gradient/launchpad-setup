const fs = require('fs');
const path = require('path');
const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const { comparePassword } = require('../utils/password');
const exposeConfig = require('../services/expose-config');

// In-memory route map: slug → { handler, wsProxy, exposure }
let routeMap = new Map();
let fileWatcher = null;

// Access tracking: circular buffer of { slug, ts } entries
const ACCESS_LOG_MAX = 10000;
const accessLog = [];
let accessLogIdx = 0;

// Rate limiting for failed auth attempts: ip → { count, resetAt }
const AUTH_RATE_LIMIT_WINDOW = 60 * 1000; // 1 minute window
const AUTH_RATE_LIMIT_MAX = 10;            // max 10 failed attempts per window
const authFailures = new Map();

// Clean up stale rate-limit entries every 5 minutes
setInterval(() => {
  const now = Date.now();
  for (const [ip, entry] of authFailures) {
    if (now > entry.resetAt) authFailures.delete(ip);
  }
}, 5 * 60 * 1000).unref();

function isRateLimited(ip) {
  const now = Date.now();
  const entry = authFailures.get(ip);
  if (!entry || now > entry.resetAt) return false;
  return entry.count >= AUTH_RATE_LIMIT_MAX;
}

function recordAuthFailure(ip) {
  const now = Date.now();
  const entry = authFailures.get(ip);
  if (!entry || now > entry.resetAt) {
    authFailures.set(ip, { count: 1, resetAt: now + AUTH_RATE_LIMIT_WINDOW });
  } else {
    entry.count++;
  }
}

/**
 * Build the route map from exports.yaml
 */
function buildRouteMap() {
  const oldMap = routeMap;
  routeMap = new Map();

  let data;
  try {
    data = exposeConfig.readExports();
  } catch (err) {
    console.error('[Expose] Failed to read exports.yaml:', err.message);
    return;
  }

  for (const exposure of data.exposures) {
    if (!exposure.enabled) continue;

    // Safety: skip exposures with reserved slugs
    if (exposeConfig.RESERVED_SLUGS.includes(exposure.slug)) {
      console.warn(`[Expose] Skipping reserved slug: "${exposure.slug}"`);
      continue;
    }

    try {
      if (exposure.type === 'proxy') {
        const proxyTarget = exposure.target;
        const proxy = createProxyMiddleware({
          target: proxyTarget,
          changeOrigin: true,
          pathRewrite: (reqPath) => {
            // Strip slug prefix — handles both /open/<slug> (direct) and /<slug> (mounted at /open)
            const fullPrefix = `/open/${exposure.slug}`;
            const shortPrefix = `/${exposure.slug}`;
            if (reqPath.startsWith(fullPrefix)) return reqPath.slice(fullPrefix.length) || '/';
            if (reqPath.startsWith(shortPrefix)) return reqPath.slice(shortPrefix.length) || '/';
            return reqPath;
          },
          ws: false, // WebSocket upgrades handled manually
          on: {
            error: (err, req, res) => {
              console.error(`[Expose] Proxy error for "${exposure.slug}": ${err.code || err.message}`);
              if (res && res.writeHead && !res.headersSent) {
                res.writeHead(502, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({
                  error: 'Target Unreachable',
                  message: `Cannot connect to ${proxyTarget}`,
                }));
              } else if (res && res.writable && !res.destroyed) {
                res.end('HTTP/1.1 502 Bad Gateway\r\n\r\n');
              }
            },
          },
        });
        routeMap.set(exposure.slug, { handler: proxy, wsProxy: proxy, exposure });
      } else if (exposure.type === 'static') {
        const resolvedPath = path.resolve(exposeConfig.WORKSPACE_ROOT, exposure.path);
        // Path traversal check
        if (!resolvedPath.startsWith(exposeConfig.WORKSPACE_ROOT)) {
          console.warn(`[Expose] Skipping static exposure "${exposure.slug}": path escapes workspace`);
          continue;
        }
        const handler = express.static(resolvedPath, {
          index: false,
          dotfiles: 'deny',
          fallthrough: false,
        });
        routeMap.set(exposure.slug, { handler, wsProxy: null, exposure });
      }
    } catch (err) {
      console.error(`[Expose] Failed to build route for "${exposure.slug}":`, err.message);
    }
  }

  // Close any old proxy instances that were removed
  for (const [slug, entry] of oldMap) {
    if (!routeMap.has(slug) && entry.wsProxy && typeof entry.wsProxy.close === 'function') {
      try { entry.wsProxy.close(); } catch {}
    }
  }

  const count = routeMap.size;
  if (count > 0) {
    console.log(`[Expose] Route map built: ${count} active exposure(s)`);
  }
}

/**
 * Password protection middleware using HTTP Basic Auth (htaccess-style)
 * Validates both username and password when authUser is set.
 */
function checkPassword(exposure, req, res, next) {
  if (!exposure.password) return next();

  const clientIp = req.ip || req.connection?.remoteAddress || 'unknown';

  // Rate limit check
  if (isRateLimited(clientIp)) {
    res.setHeader('Retry-After', '60');
    return res.status(429).json({ error: 'Too many failed attempts. Try again later.' });
  }

  const authHeader = req.headers['authorization'];
  if (!authHeader || !authHeader.startsWith('Basic ')) {
    res.setHeader('WWW-Authenticate', `Basic realm="Access to ${exposure.slug}"`);
    return res.status(401).json({ error: 'Authentication required' });
  }

  const credentials = Buffer.from(authHeader.slice(6), 'base64').toString();
  const colonIdx = credentials.indexOf(':');
  const username = colonIdx >= 0 ? credentials.slice(0, colonIdx) : '';
  const password = colonIdx >= 0 ? credentials.slice(colonIdx + 1) : credentials;

  // Check username if authUser is set
  if (exposure.authUser && username !== exposure.authUser) {
    recordAuthFailure(clientIp);
    res.setHeader('WWW-Authenticate', `Basic realm="Access to ${exposure.slug}"`);
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  try {
    if (!comparePassword(password, exposure.password)) {
      recordAuthFailure(clientIp);
      res.setHeader('WWW-Authenticate', `Basic realm="Access to ${exposure.slug}"`);
      return res.status(401).json({ error: 'Invalid credentials' });
    }
  } catch {
    if (password !== exposure.password) {
      recordAuthFailure(clientIp);
      res.setHeader('WWW-Authenticate', `Basic realm="Access to ${exposure.slug}"`);
      return res.status(401).json({ error: 'Invalid credentials' });
    }
  }

  next();
}

/**
 * Main expose registry middleware — handles all /open/* requests
 */
function exposeRegistry(req, res, next) {
  // Parse slug from path. When mounted at /open, req.path is /<slug>/...
  // When used directly, req.path is /open/<slug>/...
  // Support both by stripping optional /open prefix
  const pathToMatch = req.path.startsWith('/open/') ? req.path : '/open' + req.path;
  const match = pathToMatch.match(/^\/open\/([a-z0-9][a-z0-9-]*[a-z0-9]|[a-z0-9])(\/.*)?$/);
  if (!match) {
    return res.status(404).json({ error: 'Not Found', message: 'Invalid exposure path' });
  }

  const slug = match[1];
  const route = routeMap.get(slug);
  if (!route) {
    return res.status(404).json({ error: 'Not Found', message: `No exposure found for slug "${slug}"` });
  }

  // Track access
  const now = Date.now();
  const reqPath = match[2] || '/';
  const logEntry = { slug, ts: now, method: req.method, path: reqPath, ip: req.ip || req.connection?.remoteAddress };
  if (accessLog.length < ACCESS_LOG_MAX) {
    accessLog.push(logEntry);
  } else {
    accessLog[accessLogIdx] = logEntry;
    accessLogIdx = (accessLogIdx + 1) % ACCESS_LOG_MAX;
  }

  const startTime = now;
  const originalEnd = res.end;
  res.end = function (...args) {
    const duration = Date.now() - startTime;
    logEntry.status = res.statusCode;
    logEntry.duration = duration;
    console.log(`[Expose] ${req.method} /open/${slug}${reqPath} → ${res.statusCode} (${duration}ms)`);
    return originalEnd.apply(this, args);
  };

  // Password check
  checkPassword(route.exposure, req, res, (err) => {
    if (err) return next(err);

    if (route.exposure.type === 'static') {
      // Rewrite req.url to strip /open/<slug> prefix for express.static
      const subPath = match[2] || '/';
      req.url = subPath;
      route.handler(req, res, (staticErr) => {
        if (staticErr) {
          return res.status(404).json({ error: 'Not Found', message: 'File not found' });
        }
        // fallthrough from express.static means file not found (fallthrough: false handles this)
        next();
      });
    } else {
      route.handler(req, res, next);
    }
  });
}

/**
 * Handle WebSocket upgrade for proxy exposures
 */
function handleExposeUpgrade(req, socket, head) {
  const { pathname } = new URL(req.url, 'http://localhost');
  const match = pathname.match(/^\/open\/([a-z0-9][a-z0-9-]*[a-z0-9]|[a-z0-9])(\/.*)?$/);
  if (!match) return false;

  const slug = match[1];
  const route = routeMap.get(slug);
  if (!route || !route.wsProxy || route.exposure.type !== 'proxy') return false;

  // Password check for WebSocket upgrades via query parameter
  if (route.exposure.password) {
    const clientIp = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket?.remoteAddress || 'unknown';
    if (isRateLimited(clientIp)) {
      socket.write('HTTP/1.1 429 Too Many Requests\r\n\r\n');
      socket.destroy();
      return true;
    }
    const url = new URL(req.url, 'http://localhost');
    const token = url.searchParams.get('password');
    if (!token) {
      socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
      socket.destroy();
      return true;
    }
    try {
      if (!comparePassword(token, route.exposure.password)) {
        recordAuthFailure(clientIp);
        socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
        socket.destroy();
        return true;
      }
    } catch {
      if (token !== route.exposure.password) {
        recordAuthFailure(clientIp);
        socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
        socket.destroy();
        return true;
      }
    }
  }

  console.log(`[Expose] WebSocket upgrade: /open/${slug}${match[2] || ''}`);
  try {
    route.wsProxy.upgrade(req, socket, head);
  } catch (err) {
    console.error(`[Expose] WebSocket upgrade error for "${slug}": ${err.message}`);
    if (!socket.destroyed) {
      socket.end('HTTP/1.1 502 Bad Gateway\r\n\r\n');
    }
  }
  return true;
}

/**
 * Start watching exports.yaml for changes (hot-reload)
 */
function startWatcher() {
  stopWatcher();
  try {
    // Watch the directory since the file might not exist yet
    const dir = path.dirname(exposeConfig.EXPORTS_PATH);
    const filename = path.basename(exposeConfig.EXPORTS_PATH);

    if (!fs.existsSync(dir)) return;

    let debounceTimer = null;
    fileWatcher = fs.watch(dir, (eventType, changedFile) => {
      if (changedFile !== filename) return;
      // Debounce: rebuild after 300ms of no changes
      if (debounceTimer) clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        console.log('[Expose] Config change detected, rebuilding route map');
        buildRouteMap();
      }, 300);
    });

    // Don't let the watcher keep the process alive
    if (fileWatcher.unref) fileWatcher.unref();
  } catch (err) {
    console.error('[Expose] Failed to start file watcher:', err.message);
  }
}

function stopWatcher() {
  if (fileWatcher) {
    fileWatcher.close();
    fileWatcher = null;
  }
}

/**
 * Force reload the route map (called from API endpoint)
 */
function reload() {
  buildRouteMap();
}

/**
 * Initialize the expose registry: build route map and start watcher
 */
function init() {
  buildRouteMap();
  startWatcher();
}

/**
 * Get access stats per slug for the last 1m and 1h
 */
function getAccessStats() {
  const now = Date.now();
  const oneMinAgo = now - 60 * 1000;
  const oneHourAgo = now - 60 * 60 * 1000;
  const stats = {}; // slug → { lastMinute, lastHour }

  for (const entry of accessLog) {
    if (!entry || entry.ts < oneHourAgo) continue;
    if (!stats[entry.slug]) stats[entry.slug] = { lastMinute: 0, lastHour: 0 };
    stats[entry.slug].lastHour++;
    if (entry.ts >= oneMinAgo) stats[entry.slug].lastMinute++;
  }

  return stats;
}

/**
 * Get recent access log entries for a specific slug (most recent first)
 */
function getAccessLog(slug, limit = 100) {
  const entries = [];
  for (const entry of accessLog) {
    if (!entry) continue;
    if (slug && entry.slug !== slug) continue;
    entries.push(entry);
  }
  entries.sort((a, b) => b.ts - a.ts);
  return entries.slice(0, limit);
}

module.exports = {
  exposeRegistry,
  handleExposeUpgrade,
  init,
  reload,
  buildRouteMap,
  stopWatcher,
  getAccessStats,
  getAccessLog,
};

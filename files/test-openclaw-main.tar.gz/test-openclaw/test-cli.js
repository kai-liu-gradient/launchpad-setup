#!/usr/bin/env node
// End-to-end CLI test runner
const { execFileSync } = require('child_process');
const CLI = '/workspace/tools/openclaw-launcher-cli/bin/launcher-cli.js';

function run(args, label) {
  console.log(`\n=== ${label} ===`);
  console.log(`> launcher-cli ${args.join(' ')}`);
  try {
    const out = execFileSync('node', [CLI, ...args], { encoding: 'utf8', timeout: 30000 });
    console.log(out.trim());
    return { ok: true, out: out.trim() };
  } catch (err) {
    console.error('FAILED:', err.stderr || err.message);
    return { ok: false, err: err.message };
  }
}

async function main() {
  const results = [];

  // Test 1: Help
  results.push(run(['--help'], 'CLI Help'));

  // Test 2: Config show
  results.push(run(['config', 'show'], 'Config Show'));

  // Test 3: Expose list (empty)
  results.push(run(['expose', 'list'], 'List Exposures (empty)'));

  // Test 4: Scaffold hello-world
  results.push(run(['scaffold'], 'Scaffold Hello World'));

  // Test 5: Expose list (should have hello-world)
  results.push(run(['expose', 'list'], 'List Exposures (after scaffold)'));

  // Test 6: PM2 status
  results.push(run(['pm2', 'status'], 'PM2 Status'));

  // Test 7: PM2 control stop
  results.push(run(['pm2', 'control', '--slug', 'hello-world', '--action', 'stop'], 'PM2 Stop'));

  // Test 8: PM2 control restart
  results.push(run(['pm2', 'control', '--slug', 'hello-world', '--action', 'restart'], 'PM2 Restart'));

  // Test 9: Expose disable
  results.push(run(['expose', 'disable', '--slug', 'hello-world'], 'Disable Exposure'));

  // Test 10: Expose enable
  results.push(run(['expose', 'enable', '--slug', 'hello-world'], 'Enable Exposure'));

  // Test 11: Expose remove (should also clean PM2)
  results.push(run(['expose', 'remove', '--slug', 'hello-world'], 'Remove Exposure'));

  // Test 12: Expose list (empty again)
  results.push(run(['expose', 'list'], 'List Exposures (after remove)'));

  // Test 13: PM2 status (empty)
  results.push(run(['pm2', 'status'], 'PM2 Status (after remove)'));

  // Summary
  console.log('\n\n=== SUMMARY ===');
  const passed = results.filter(r => r.ok).length;
  const failed = results.filter(r => !r.ok).length;
  console.log(`Passed: ${passed}/${results.length}`);
  console.log(`Failed: ${failed}/${results.length}`);
  if (failed > 0) process.exit(1);
}

main();

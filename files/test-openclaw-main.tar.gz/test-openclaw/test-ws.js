const WebSocket = require('ws');
const ws = new WebSocket('ws://127.0.0.1:18789/');
ws.on('open', () => {
  console.log('open');
  ws.send(JSON.stringify({
    type: 'connect',
    payload: {
      role: 'operator',
      auth: { token: '5ee9749964a5d2e87ede4d058fbbfab9d746ede459a4346b' },
      capabilities: ['operator.admin']
    }
  }));
});
ws.on('message', (d) => console.log('msg:', String(d)));
ws.on('close', (c, r) => console.log('close:', c, String(r)));
ws.on('error', (e) => console.log('err:', e.message));
setTimeout(() => process.exit(), 3000);

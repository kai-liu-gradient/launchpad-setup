const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const os = require('os');
const { WebSocketServer } = require('ws');
const { createProxyMiddleware } = require('http-proxy-middleware');
const app = express();
const port = process.env.PORT || 3000;

// Generate a session-scoped terminal access token (regenerated on server restart)
const SHELL_ACCESS_TOKEN = crypto.randomBytes(16).toString('hex');

// Feishu webhook reverse proxy — must be mounted BEFORE body-parsing middleware
// so the gateway receives the raw request body for signature verification.
const { getGatewayTarget } = require('./src/services/gateway-proxy');
const feishuProxy = createProxyMiddleware({
  pathFilter: '/feishu',
  router: () => {
    const { host, port } = getGatewayTarget();
    return `http://${host}:${port}`;
  },
  changeOrigin: true,
  on: {
    error: (err, req, res) => {
      console.error(`[Feishu Proxy] Error: ${err.code || err.message}`);
      if (res && res.writeHead && !res.headersSent) {
        res.writeHead(502, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          error: 'Gateway Unreachable',
          message: 'Cannot connect to OpenClaw gateway for Feishu events.',
        }));
      }
    },
  },
});
app.use(feishuProxy);

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Security headers
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'same-origin');
  // Allow framing for /gateway/ route (used by Control UI iframe), deny for everything else
  if (!req.path.startsWith('/gateway')) {
    res.setHeader('X-Frame-Options', 'DENY');
  }
  next();
});

// Serve React SPA static assets from dist/
// Always mount the static middleware — dist/ may not exist yet at startup
// (the frontend build runs in parallel), but express.static handles this gracefully
const distPath = path.join(__dirname, 'dist');
app.use(express.static(distPath));

// Gateway reverse proxy — auth-guarded so only authenticated launcher sessions can access
const { createGatewayProxy } = require('./src/services/gateway-proxy');
const gatewayProxy = createGatewayProxy();
const { verifyToken: verifyLauncherJwt } = require('./src/middleware/launcher-auth');
const gatewaySession = require('./src/services/gateway-session');

// Gateway HTTP auth guard: validate launcher_token from Authorization header or cookie
app.use('/gateway', (req, res, next) => {
  let token = null;
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.slice(7);
  }
  if (!token && req.headers.cookie) {
    token = gatewaySession.parseCookie(req.headers.cookie, 'launcher_token');
  }
  if (!token || !verifyLauncherJwt(token)) {
    return res.status(401).json({ error: 'unauthorized', message: 'Authentication required for gateway access' });
  }
  next();
}, gatewayProxy);

// Expose registry — serves user-defined reverse proxies and static files under /open/*
// Mounted OUTSIDE launcher auth (exposed paths are for external sharing)
const { exposeRegistry, handleExposeUpgrade, init: initExposeRegistry } = require('./src/middleware/expose-registry');
initExposeRegistry();
app.use('/open', exposeRegistry);

// Ensure bin links exist for installed marketplace template tools (idempotent)
// Also refresh launcher-cli auth token if installed
try {
  const marketplace = require('./src/services/marketplace');
  marketplace.ensureBinLinks();

  // Auto-refresh launcher-cli config token on startup if installed
  const cliStatus = marketplace.getItemStatus('openclaw-launcher-cli');
  if (cliStatus && cliStatus.installed) {
    const { signToken } = require('./src/middleware/launcher-auth');
    const toolConfigPath = path.join(os.homedir(), '.openclaw', 'tools', 'launcher-cli', 'config.json');
    if (fs.existsSync(path.dirname(toolConfigPath))) {
      const token = signToken({ type: 'cli-tool' }, '90d');
      if (token) {
        let cfg = {};
        try { cfg = JSON.parse(fs.readFileSync(toolConfigPath, 'utf-8')); } catch { /* fresh */ }
        cfg.url = cfg.url || 'http://localhost:3000';
        cfg.token = token;
        fs.writeFileSync(toolConfigPath, JSON.stringify(cfg, null, 2), { mode: 0o600 });
      }
    }
  }
} catch { /* best-effort at startup */ }

// OpenClaw Launcher API routes
const openclawRoutes = require('./src/routes/openclaw');
const authRoutes = require('./src/routes/auth');
const controlRoutes = require('./src/routes/control');
const { apiErrorHandler } = require('./src/middleware/validation');
const { launcherAuth, verifyWebSocketToken } = require('./src/middleware/launcher-auth');
const { controlAuth } = require('./src/middleware/control-auth');

// Serve Control API llms.txt publicly (no auth — it's API documentation)
app.get('/control/v1/llms.txt', (req, res) => {
  const filePath = path.join(__dirname, 'public', 'openclaw-launcher-ctrl-llms.txt');
  if (!fs.existsSync(filePath)) {
    return res.status(404).send('Not found');
  }
  res.type('text/plain').sendFile(filePath);
});

// Control API routes — separate auth (X-Control-Key), separate namespace (Task 7)
app.use('/control/v1', controlAuth, controlRoutes);

// Auth routes (login, verify, status are public; generate-link, reset-password require auth)
app.use('/api/openclaw/auth', authRoutes);

// Gateway WS session cookie refresh — issues/refreshes the gateway_ws_session cookie
// Requires launcher auth; called by the frontend before loading Control UI or on navigation
app.post('/api/openclaw/gateway-ws-session', launcherAuth, (req, res) => {
  if (gatewaySession.setSessionCookie(res)) {
    res.json({ ok: true });
  } else {
    res.status(500).json({ error: 'Failed to create gateway session' });
  }
});

// Apply launcher auth middleware to all /api/openclaw/* routes (except auth paths above)
app.use('/api/openclaw', launcherAuth, openclawRoutes);

// Health check endpoint
app.get('/health', (req, res) => {
  const healthData = {
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    version: process.env.npm_package_version || '1.0.0'
  };

  const formatUptime = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    return hours + 'h ' + minutes + 'm ' + secs + 's';
  };

  res.send(
    '<!DOCTYPE html>' +
    '<html>' +
    '<head>' +
    '  <title>Health Status</title>' +
    '  <style>' +
    '    body {' +
    '      background-color: #121212;' +
    '      color: #ffffff;' +
    '      font-family: "Courier New", Consolas, monospace;' +
    '      margin: 0;' +
    '      padding: 0;' +
    '      height: 100vh;' +
    '      display: flex;' +
    '      justify-content: center;' +
    '      align-items: center;' +
    '    }' +
    '    .health-container {' +
    '      background: #1e1e1e;' +
    '      border: 1px solid #333;' +
    '      border-radius: 10px;' +
    '      padding: 40px;' +
    '      max-width: 500px;' +
    '      width: 90%;' +
    '      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);' +
    '    }' +
    '    .health-title {' +
    '      font-size: 2rem;' +
    '      font-weight: 300;' +
    '      text-align: center;' +
    '      margin: 0 0 30px 0;' +
    '      color: #4ade80;' +
    '    }' +
    '    .status-indicator {' +
    '      display: inline-flex;' +
    '      align-items: center;' +
    '      gap: 10px;' +
    '      background: #064e3b;' +
    '      color: #4ade80;' +
    '      padding: 8px 16px;' +
    '      border-radius: 20px;' +
    '      font-size: 0.9rem;' +
    '      font-weight: bold;' +
    '      margin-bottom: 20px;' +
    '    }' +
    '    .status-dot {' +
    '      width: 8px;' +
    '      height: 8px;' +
    '      background: #4ade80;' +
    '      border-radius: 50%;' +
    '      animation: pulse 2s infinite;' +
    '    }' +
    '    @keyframes pulse {' +
    '      0%, 100% { opacity: 1; }' +
    '      50% { opacity: 0.5; }' +
    '    }' +
    '    .health-item {' +
    '      display: flex;' +
    '      justify-content: space-between;' +
    '      align-items: center;' +
    '      padding: 12px 0;' +
    '      border-bottom: 1px solid #333;' +
    '    }' +
    '    .health-item:last-child {' +
    '      border-bottom: none;' +
    '    }' +
    '    .health-label {' +
    '      color: #888;' +
    '      font-size: 0.9rem;' +
    '    }' +
    '    .health-value {' +
    '      color: #fff;' +
    '      font-weight: bold;' +
    '      font-size: 0.9rem;' +
    '    }' +
    '    .back-link {' +
    '      display: block;' +
    '      text-align: center;' +
    '      margin-top: 30px;' +
    '      color: #6b7280;' +
    '      text-decoration: none;' +
    '      font-size: 0.9rem;' +
    '      transition: color 0.3s;' +
    '    }' +
    '    .back-link:hover {' +
    '      color: #9ca3af;' +
    '    }' +
    '  </style>' +
    '</head>' +
    '<body>' +
    '  <div class="health-container">' +
    '    <h1 class="health-title">Health Status</h1>' +
    '    <div style="text-align: center;">' +
    '      <div class="status-indicator">' +
    '        <span class="status-dot"></span>' +
    '        <span>' + healthData.status.toUpperCase() + '</span>' +
    '      </div>' +
    '    </div>' +
    '    <div class="health-item">' +
    '      <span class="health-label">Status</span>' +
    '      <span class="health-value">' + healthData.status + '</span>' +
    '    </div>' +
    '    <div class="health-item">' +
    '      <span class="health-label">Uptime</span>' +
    '      <span class="health-value">' + formatUptime(healthData.uptime) + '</span>' +
    '    </div>' +
    '    <div class="health-item">' +
    '      <span class="health-label">Version</span>' +
    '      <span class="health-value">' + healthData.version + '</span>' +
    '    </div>' +
    '    <div class="health-item">' +
    '      <span class="health-label">Timestamp</span>' +
    '      <span class="health-value">' + new Date(healthData.timestamp).toLocaleString() + '</span>' +
    '    </div>' +
    '    <a href="/" class="back-link">← Back to Home</a>' +
    '  </div>' +
    '</body>' +
    '</html>'
  );
});

// Note: The root endpoint '/' is now served by the React SPA from the dist/ directory.
// The old Hello World page has been replaced by the OpenClaw Launcher SPA.

// Health API endpoint for toast
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    version: process.env.npm_package_version || '1.0.0'
  });
});

// API example endpoint
app.get('/api/info', (req, res) => {
  res.json({
    message: 'AniLaunchpad Node.js Template',
    version: '1.0.0',
    node: process.version,
    platform: process.platform,
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    env: process.env.NODE_ENV || 'development'
  });
});

// Shell terminal access token (session-scoped, generated at server startup) — requires auth
app.get('/api/openclaw/shell/token', launcherAuth, (req, res) => {
  res.json({ token: SHELL_ACCESS_TOKEN });
});

// API error handler for OpenClaw routes
app.use('/api/openclaw', apiErrorHandler);

// SPA catch-all: serve index.html for client-side routing (non-API routes)
app.use((req, res, next) => {
  // API routes that don't match return 404 JSON
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'Not Found', path: req.path });
  }
  // Serve React SPA index.html for all other routes (client-side routing)
  const indexPath = path.join(__dirname, 'dist', 'index.html');
  if (fs.existsSync(indexPath)) {
    return res.sendFile(indexPath);
  }
  // Fallback: show a loading page while the frontend is building
  res.set('X-SPA-Building', '1').send(
    '<!DOCTYPE html>' +
    '<html lang="en">' +
    '<head>' +
    '  <meta charset="UTF-8" />' +
    '  <meta name="viewport" content="width=device-width, initial-scale=1.0" />' +
    '  <title>OpenClaw Launcher</title>' +
    '  <link rel="preconnect" href="https://fonts.googleapis.com" />' +
    '  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />' +
    '  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet" />' +
    '  <style>' +
    '    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }' +
    '    body {' +
    '      background-color: #f5f5f5;' +
    '      color: #1e1e1e;' +
    '      font-family: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;' +
    '      min-height: 100vh;' +
    '      display: flex;' +
    '      justify-content: center;' +
    '      align-items: center;' +
    '    }' +
    '    .loading-container {' +
    '      text-align: center;' +
    '      padding: 40px;' +
    '    }' +
    '    .spinner {' +
    '      width: 40px;' +
    '      height: 40px;' +
    '      border: 3px solid #e0e0e0;' +
    '      border-top-color: #1e1e1e;' +
    '      border-radius: 50%;' +
    '      animation: spin 0.8s linear infinite;' +
    '      margin: 0 auto 24px;' +
    '    }' +
    '    @keyframes spin { to { transform: rotate(360deg); } }' +
    '    h1 { font-size: 1.25rem; font-weight: 600; margin-bottom: 8px; }' +
    '    p { font-size: 0.875rem; color: #666; }' +
    '  </style>' +
    '</head>' +
    '<body>' +
    '  <div class="loading-container">' +
    '    <div class="spinner"></div>' +
    '    <h1>Building OpenClaw Launcher&hellip;</h1>' +
    '    <p>This page will refresh automatically when ready.</p>' +
    '  </div>' +
    '  <script>' +
    '    (function poll() {' +
    '      setTimeout(function() {' +
    '        fetch(window.location.href).then(function(r) {' +
    '          if (!r.headers.get("x-spa-building")) {' +
    '            window.location.reload();' +
    '          } else { poll(); }' +
    '        }).catch(function() { poll(); });' +
    '      }, 1500);' +
    '    })();' +
    '  </script>' +
    '</body>' +
    '</html>'
  );
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    error: 'Internal Server Error',
    message: err.message
  });
});

// Auto-persist OpenClaw CLI version on startup (only if openclaw.json exists)
const versionTracker = require('./src/services/version-tracker');
const openclawConfig = require('./src/services/openclaw-config');
if (openclawConfig.readConfig()) {
  versionTracker.autoPersistVersion();
}

// Ensure launcher auth password exists and log it on first run
let isFirstRunBoot = false;
(function ensureLauncherAuth() {
  // Migrate: if password was stored in openclaw.json (old location), move it to launcher.json
  const config = openclawConfig.readConfig();
  if (config && config.launcher && config.launcher.auth && config.launcher.auth.password) {
    const existingLauncher = openclawConfig.getLauncherPassword();
    if (!existingLauncher) {
      openclawConfig.setLauncherPassword(config.launcher.auth.password);
    }
    // Remove the launcher key from openclaw.json so openclaw CLI doesn't reject it
    delete config.launcher;
    config.meta = config.meta || {};
    config.meta.lastTouchedAt = new Date().toISOString();
    openclawConfig.writeConfig(config);
  }

  // Migrate: if managedPool was stored in openclaw.json (old location), move it to launcher.json
  if (config && config.managedPool) {
    const existingLauncher = openclawConfig.readLauncherConfig() || {};
    if (!existingLauncher.managedPool) {
      existingLauncher.managedPool = config.managedPool;
      openclawConfig.writeLauncherConfig(existingLauncher);
    }
    delete config.managedPool;
    openclawConfig.writeConfig(config);
  }

  let password = openclawConfig.getLauncherPassword();
  if (!password) {
    // First run — generate password and create init flag
    isFirstRunBoot = true;
    password = openclawConfig.generateLauncherPassword();
    openclawConfig.setLauncherPassword(password);
    openclawConfig.createInitFlag();
    console.log('========================================');
    console.log('Launcher login password: ' + password);
    console.log('(first-run password will be shown on the login page)');
    console.log('========================================');
  } else {
    console.log('========================================');
    console.log('Launcher login password: ' + password);
    console.log('(view anytime with: pm2 logs web)');
    console.log('========================================');
  }
})();

// Stop openclaw-gateway on first-run bootstrap to prevent restart looping.
// Only stops the gateway when this is a fresh launcher setup (no password existed).
// On subsequent boots, leave the gateway alone — it should keep its current state.
// Exception: managed pool ACTIVE/PROVISIONING always keeps the gateway running.
(function stopOpenclawGatewayOnBoot() {
  if (!isFirstRunBoot) {
    console.log('[bootstrap] Skipping openclaw-gateway stop (not first-run)');
    return;
  }
  const launcherConfig = openclawConfig.readLauncherConfig() || {};
  const poolStatus = launcherConfig.managedPool?.status;
  if (poolStatus === 'ACTIVE' || poolStatus === 'PROVISIONING') {
    console.log(`[bootstrap] Keeping openclaw-gateway running (managed pool status: ${poolStatus})`);
    return;
  }
  const { execSync } = require('child_process');
  try {
    execSync('pm2 stop openclaw-gateway 2>/dev/null || true', { encoding: 'utf-8', timeout: 10000 });
    console.log('[bootstrap] Stopped openclaw-gateway (first-run bootstrap)');
  } catch {
    // Process may not exist — that's fine
  }
})();

// Watchdog: periodically stop openclaw-gateway if openclaw.json does not exist.
// The one-shot stopOpenclawGatewayOnBoot() above only fires on first run, but PM2 may
// auto-restart the gateway immediately after. This timer ensures the gateway stays
// stopped until the user completes setup and openclaw.json is created.
(function startGatewayConfigWatchdog() {
  const WATCHDOG_INTERVAL = 30000; // 30 seconds
  const watchdog = setInterval(() => {
    try {
      const config = openclawConfig.readConfig();
      if (config) {
        // openclaw.json exists — watchdog no longer needed
        clearInterval(watchdog);
        console.log('[watchdog] openclaw.json found, gateway config watchdog stopped');
        return;
      }
      // Skip if managed pool is ACTIVE/PROVISIONING
      const launcherConfig = openclawConfig.readLauncherConfig() || {};
      const poolStatus = launcherConfig.managedPool?.status;
      if (poolStatus === 'ACTIVE' || poolStatus === 'PROVISIONING') {
        return;
      }
      // Check if openclaw-gateway is running and stop it
      const pm2Health = require('./src/services/pm2-health');
      const gateway = pm2Health.getOpenClawGatewayProcess();
      if (gateway && gateway.status === 'online') {
        const { execSync } = require('child_process');
        execSync('pm2 stop openclaw-gateway 2>/dev/null || true', { encoding: 'utf-8', timeout: 10000 });
        console.log('[watchdog] Stopped openclaw-gateway (openclaw.json not found)');
      }
    } catch (err) {
      // Watchdog should never crash the server
      console.error('[watchdog] Error:', err.message);
    }
  }, WATCHDOG_INTERVAL);
  // Don't let the watchdog timer keep the process alive
  if (watchdog.unref) watchdog.unref();
})();

// Stop ani-code-daemon PM2 process on bootstrap (default: true, configurable via launcher.json)
(function stopAniCodeDaemonOnBoot() {
  const { execSync } = require('child_process');
  try {
    const launcherConfig = openclawConfig.readLauncherConfig() || {};
    const shouldStop = (launcherConfig.environment?.stopAniCodeDaemon) !== false; // default true
    if (shouldStop) {
      try {
        execSync('pm2 stop ani-code-daemon 2>/dev/null || true', { encoding: 'utf-8', timeout: 10000 });
        console.log('[bootstrap] Stopped ani-code-daemon (managed by launcher)');
      } catch {
        // Process may not exist — that's fine
      }
    }
  } catch {
    // launcher.json may not exist yet — skip silently
  }
})();

// Start server
const server = app.listen(port, '0.0.0.0', () => {
  console.log('[' + new Date().toISOString() + '] Server started');
  console.log('Port: ' + port);
  console.log('Environment: ' + (process.env.NODE_ENV || 'development'));
  console.log('Node.js: ' + process.version);
  console.log('Ready to accept connections');

  // Start system stats collector (1-minute interval)
  const systemStats = require('./src/services/system-stats');
  systemStats.startCollector();
});

// WebSocket server for web shell terminal
const webshell = require('./src/services/webshell');

const shellWss = new WebSocketServer({ noServer: true });

// Ping/pong keepalive — every 45s, terminate stale connections after 30s
// (generous timeout to handle browser tab throttling in background tabs)
const PING_INTERVAL = 45000;
const PONG_TIMEOUT = 30000;

const pingInterval = setInterval(() => {
  shellWss.clients.forEach((ws) => {
    if (ws._isAlive === false) {
      console.log('[Shell WS] Terminating stale connection');
      return ws.terminate();
    }
    ws._isAlive = false;
    ws.ping();
    ws._pongTimeout = setTimeout(() => {
      if (ws._isAlive === false) {
        console.log('[Shell WS] Pong timeout, terminating');
        ws.terminate();
      }
    }, PONG_TIMEOUT);
  });
}, PING_INTERVAL);

shellWss.on('close', () => clearInterval(pingInterval));

shellWss.on('connection', (ws, req) => {
  ws._isAlive = true;
  ws.on('pong', () => {
    ws._isAlive = true;
    if (ws._pongTimeout) {
      clearTimeout(ws._pongTimeout);
      ws._pongTimeout = null;
    }
  });

  const sessionId = crypto.randomUUID();
  let session;
  try {
    session = webshell.createSession(sessionId);
  } catch (err) {
    ws.close(1013, err.message);
    return;
  }
  console.log(`[Shell WS] Session ${sessionId} created (PID ${session.pty.pid})`);

  session.pty.onData((data) => {
    if (ws.readyState === ws.OPEN) {
      ws.send(JSON.stringify({ type: 'output', data }));
    }
  });

  session.pty.onExit(() => {
    if (ws.readyState === ws.OPEN) {
      ws.close(1000, 'Shell process exited');
    }
    webshell.destroySession(sessionId);
  });

  ws.on('message', (raw) => {
    let msg;
    try {
      msg = JSON.parse(raw);
    } catch {
      return;
    }
    if (msg.type === 'input' && typeof msg.data === 'string') {
      session.pty.write(msg.data);
    } else if (msg.type === 'resize' && msg.cols && msg.rows) {
      webshell.resizeSession(sessionId, msg.cols, msg.rows);
    } else if (msg.type === 'ping') {
      // Application-level heartbeat — echo back immediately for latency measurement
      const systemStats = require('./src/services/system-stats');
      const latest = systemStats.getLatest();
      const resources = {};
      if (latest?.memory) {
        resources.memory = { usedPercent: latest.memory.usedPercent, usedMB: latest.memory.usedMB, totalMB: latest.memory.totalMB };
      }
      if (latest?.cpu) {
        resources.cpu = { usagePercent: latest.cpu.usagePercent ?? null, cores: latest.cpu.quotaCores || latest.cpu.cores };
      }
      ws.send(JSON.stringify({ type: 'pong', ts: msg.ts, resources }));
    }
  });

  ws.on('close', () => {
    console.log(`[Shell WS] Session ${sessionId} closed`);
    if (ws._pongTimeout) clearTimeout(ws._pongTimeout);
    webshell.destroySession(sessionId);
  });
});

// Handle WebSocket upgrade requests
server.on('upgrade', (req, socket, head) => {
  const { pathname } = new URL(req.url, 'http://localhost');

  if (pathname === '/api/openclaw/shell/ws') {
    // Validate launcher auth JWT from query parameter
    if (!verifyWebSocketToken(req.url)) {
      console.log(`[WebSocket] Launcher auth failed from ${req.socket.remoteAddress}`);
      socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
      socket.destroy();
      return;
    }
    // Validate shell access token from query parameter
    const url = new URL(req.url, 'http://localhost');
    const token = url.searchParams.get('token');
    if (token !== SHELL_ACCESS_TOKEN) {
      console.log(`[WebSocket] Shell token auth failed from ${req.socket.remoteAddress}`);
      socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
      socket.destroy();
      return;
    }
    console.log(`[WebSocket] Shell upgrade request from ${req.socket.remoteAddress}`);
    shellWss.handleUpgrade(req, socket, head, (ws) => {
      shellWss.emit('connection', ws, req);
    });
  } else if (pathname.startsWith('/open/')) {
    // Expose registry WebSocket upgrades — proxy exposures support WebSocket passthrough
    if (!handleExposeUpgrade(req, socket, head)) {
      socket.write('HTTP/1.1 404 Not Found\r\n\r\n');
      socket.destroy();
    }
  } else if (pathname.startsWith('/gateway') || pathname === '/' || !pathname.startsWith('/api/')) {
    // Gateway WebSocket connections — require launcher auth (launcher_token cookie)
    // and gateway_ws_session cookie to prevent unauthenticated WS tunneling to the gateway.
    const cookieHeader = req.headers.cookie || '';

    // Validate launcher JWT from cookie
    if (!gatewaySession.validateLauncherTokenFromCookie(cookieHeader)) {
      console.log(`[WebSocket] Gateway auth rejected (no valid launcher_token) from ${req.socket.remoteAddress} path=${pathname}`);
      socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
      socket.destroy();
      return;
    }

    // Validate gateway_ws_session cookie
    if (!gatewaySession.validateFromCookieHeader(cookieHeader)) {
      console.log(`[WebSocket] Gateway auth rejected (no valid gateway_ws_session) from ${req.socket.remoteAddress} path=${pathname}`);
      socket.write('HTTP/1.1 403 Forbidden\r\n\r\n');
      socket.destroy();
      return;
    }

    // Rewrite URL for non-/gateway paths (implicit fallback from Control UI iframe)
    if (!pathname.startsWith('/gateway')) {
      req.url = '/gateway' + req.url;
    }

    console.log(`[WebSocket] Gateway proxy upgrade: ${pathname}`);
    try {
      // Rewrite headers so the gateway recognizes this as a local connection.
      const { host, port } = getGatewayTarget();
      req.headers['host'] = `${host}:${port}`;
      req.headers['origin'] = `http://${host}:${port}`;
      delete req.headers['x-forwarded-for'];
      delete req.headers['x-forwarded-host'];
      delete req.headers['x-forwarded-proto'];
      delete req.headers['x-real-ip'];
      gatewayProxy.upgrade(req, socket, head);
    } catch (err) {
      console.error(`[WebSocket] Gateway proxy upgrade error: ${err.message}`);
      if (!socket.destroyed) {
        socket.end('HTTP/1.1 502 Bad Gateway\r\n\r\n');
      }
    }
  } else {
    // Unknown WebSocket upgrade path — reject
    console.log(`[WebSocket] Rejected unknown upgrade path: ${pathname} from ${req.socket.remoteAddress}`);
    socket.write('HTTP/1.1 404 Not Found\r\n\r\n');
    socket.destroy();
  }
});

// Graceful shutdown
const shutdown = (signal) => {
  console.log(`${signal} received, shutting down gracefully`);
  try { require('./src/services/system-stats').stopCollector(); } catch {}
  webshell.destroyAllSessions();
  shellWss.clients.forEach((ws) => {
    if (ws._pongTimeout) clearTimeout(ws._pongTimeout);
    ws.terminate();
  });
  server.close(() => process.exit(0));
  // Force exit after 3s if connections linger
  setTimeout(() => process.exit(0), 3000).unref();
};

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
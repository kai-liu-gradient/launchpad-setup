#!/usr/bin/env node
/**
 * Development startup script — replaces nodemon with native Node.js --watch.
 *
 * Spawns two child processes:
 *   1. node --watch server.js          (backend, restarts on .js/.json changes in src/)
 *   2. vite build --watch              (frontend, incremental rebuilds)
 *
 * All environment variables from the parent process (PM2, shell, etc.)
 * are inherited automatically — no env filtering like nodemon's env config.
 */
const { spawn, execSync } = require('child_process');
const path = require('path');

const ROOT = path.join(__dirname, '..');

// Generate build-info before first build
try {
  require('./generate-build-info');
} catch (err) {
  console.error('[dev] Warning: build-info generation failed:', err.message);
}

// --- Initial frontend build (synchronous) ------------------------------------
// Ensures dist/ is up-to-date BEFORE the server starts serving.
// Without this, the server serves stale dist/ files during the ~3-4s Vite build.
try {
  console.log('[dev] Running initial frontend build...');
  execSync('npx vite build --config vite.config.js', { cwd: ROOT, stdio: 'inherit' });
  console.log('[dev] Initial build complete.');
} catch (err) {
  console.error('[dev] Warning: initial frontend build failed:', err.message);
}

// --- Backend: node --watch ---------------------------------------------------
const serverArgs = [
  '--watch-path=./server.js',
  '--watch-path=./src/routes',
  '--watch-path=./src/services',
  '--watch-path=./src/middleware',
  'server.js',
];

const serverProc = spawn(process.execPath, serverArgs, {
  cwd: ROOT,
  stdio: 'inherit',
  env: { ...process.env },
});

// --- Frontend: vite build --watch --------------------------------------------
const viteBin = path.join(ROOT, 'node_modules', '.bin', 'vite');

const viteProc = spawn(viteBin, ['build', '--watch', '--config', 'vite.config.js'], {
  cwd: ROOT,
  stdio: 'inherit',
  env: { ...process.env },
});

// --- Lifecycle ---------------------------------------------------------------
function cleanup(code) {
  serverProc.kill();
  viteProc.kill();
  process.exit(code ?? 0);
}

serverProc.on('exit', (code) => {
  // node --watch restarts automatically on file changes (exit code 0),
  // only treat non-zero as fatal
  if (code && code !== 0) {
    console.error(`[dev] server exited with code ${code}`);
  }
});

viteProc.on('exit', (code) => {
  if (code && code !== 0) {
    console.error(`[dev] vite build --watch exited with code ${code}`);
  }
});

process.on('SIGTERM', () => cleanup());
process.on('SIGINT', () => cleanup());

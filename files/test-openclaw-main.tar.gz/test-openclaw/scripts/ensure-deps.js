#!/usr/bin/env node
/**
 * Pre-start dependency check — verifies all packages from package.json
 * are installed in node_modules. Runs `npm install` if any are missing.
 */
const { execSync } = require('child_process');
const path = require('path');
const fs = require('fs');

const ROOT = path.join(__dirname, '..');
const nodeModulesPath = path.join(ROOT, 'node_modules');
const pkgPath = path.join(ROOT, 'package.json');

let needsInstall = false;

if (!fs.existsSync(nodeModulesPath)) {
  console.log('[ensure-deps] node_modules not found — running npm install...');
  needsInstall = true;
} else {
  const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
  const allDeps = { ...pkg.dependencies, ...pkg.devDependencies };

  for (const dep of Object.keys(allDeps)) {
    const depPkgPath = path.join(nodeModulesPath, dep, 'package.json');
    if (!fs.existsSync(depPkgPath)) {
      console.log(`[ensure-deps] Missing package "${dep}" — running npm install...`);
      needsInstall = true;
      break;
    }
  }
}

if (needsInstall) {
  execSync('npm install', { cwd: ROOT, stdio: 'inherit' });
  console.log('[ensure-deps] Dependencies installed.');
} else {
  console.log('[ensure-deps] All dependencies present.');
}

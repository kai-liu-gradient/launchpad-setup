#!/usr/bin/env node
/**
 * Generates build-info.json with the current timestamp and package.json version.
 * Auto-updates the date portion of the version (MAJOR.MINOR.YYYYMMDD) if stale.
 * Run automatically as part of the build process.
 */
const fs = require('fs');
const path = require('path');

const pkgPath = path.join(__dirname, '..', 'package.json');
const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));

const now = new Date();
const todayStr = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;

// Version format: MAJOR.MINOR.YYYYMMDD — update the date portion if stale
const versionParts = pkg.version.split('.');
if (versionParts.length >= 3) {
  const datePart = versionParts[versionParts.length - 1];
  if (/^\d{8}$/.test(datePart) && datePart !== todayStr) {
    versionParts[versionParts.length - 1] = todayStr;
    const newVersion = versionParts.join('.');
    console.log(`[build-info] Updating package.json version: ${pkg.version} -> ${newVersion}`);
    pkg.version = newVersion;
    fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + '\n');
  }
}

const buildInfo = {
  version: pkg.version,
  buildTime: now.toISOString(),
};

fs.writeFileSync(
  path.join(__dirname, '..', 'build-info.json'),
  JSON.stringify(buildInfo, null, 2) + '\n'
);

console.log(`[build-info] version=${buildInfo.version} buildTime=${buildInfo.buildTime}`);

# Goal: OpenClaw Launcher React SPA Frontend

## Objective
Build a React-based single-page application (SPA) with client-side routing that serves as the OpenClaw Launcher UI. The SPA provides a multi-step setup wizard for first-time configuration, a health dashboard for monitoring the OpenClaw gateway daemon, and a markdown-capable file browser for the `~/.openclaw/workspace` directory. This frontend consumes the API endpoints defined in Goal #001 and is served from the existing Express server at port 3000.

## Tasks

### React SPA Scaffold
- [x] Task 1: Install React dependencies — `react`, `react-dom`, `react-router-dom` (v6+) for client-side routing, and a build tool (`vite` recommended for fast dev/build)
- [x] Task 2: Configure Vite with React plugin, output build to `public/` or `dist/` directory, and configure Express to serve the built SPA (with history API fallback for client-side routing)
- [x] Task 3: Create the React app entry point (`src/frontend/main.jsx`) and root component (`src/frontend/App.jsx`) with React Router configuration
- [x] Task 4: Set up the route structure:
  - `/` — Landing/home page (status overview + quick actions)
  - `/setup` — Setup wizard (multi-step)
  - `/setup/credentials` — Credential detection & selection step
  - `/setup/telegram` — Telegram bot configuration step
  - `/setup/config` — OpenClaw config initialization step
  - `/setup/complete` — Setup completion summary
  - `/health` — Health dashboard
  - `/workspace` — Workspace file browser
- [x] Task 5: Add npm scripts for frontend development: `build:frontend` (production build), `dev:frontend` (Vite dev server with API proxy to Express on port 3000)

### Setup Wizard Pages
- [x] Task 6: Build the **Credential Detection** page — calls `GET /api/openclaw/credentials/detect`, displays discovered providers (Claude OAuth, ZAI/GLM) with status badges, and a button to apply selected credentials via `POST /api/openclaw/credentials/apply`
- [x] Task 7: Build the **Telegram Configuration** page — provides step-by-step guide for creating a Telegram bot via @BotFather, an input field for the bot token, a "Validate" button calling `POST /api/openclaw/telegram/validate` that shows bot info on success, and a "Save" button calling `POST /api/openclaw/telegram/configure`
- [x] Task 8: Build the **Config Initialization** page — shows the current config preview (from `GET /api/openclaw/config`), allows editing key fields (gateway port, model selection, workspace path), and a "Initialize/Save" button calling `POST /api/openclaw/config/init` or `PATCH /api/openclaw/config`
- [x] Task 9: Build the **Setup Complete** page — summary of all configured items with status checks (credentials OK, Telegram connected, config valid, gateway running), with a "Go to Dashboard" link

### Wizard Navigation & State
- [x] Task 10: Implement a wizard stepper/progress bar component showing current step and completion status across the setup flow
- [x] Task 11: Implement wizard state management (React context or simple state lifting) to track which steps are completed and allow navigation between steps

### Health Dashboard
- [x] Task 12: Build the **Health Dashboard** page — polls `GET /api/openclaw/health` on an interval (every 10s) and displays: gateway process status (running/stopped), PID, uptime, memory usage, CPU, restart count
- [x] Task 13: Add a gateway connectivity indicator that probes `GET /api/openclaw/health/gateway` and shows live/offline status with last-checked timestamp
- [x] Task 14: Add a "Restart Gateway" button that calls `POST /api/openclaw/gateway/restart` with confirmation dialog and loading state
- [x] Task 15: Display PM2 log excerpts or link to log file paths for debugging

### Workspace File Browser
- [x] Task 16: Build the **Workspace Browser** page — calls `GET /api/openclaw/workspace/tree` and renders a collapsible folder/file tree view for `~/.openclaw/workspace`
- [x] Task 17: Implement file content viewer — clicking a file calls `GET /api/openclaw/workspace/file?path=<relative>` and displays content in a panel; markdown files (`.md`) rendered with a markdown renderer (e.g., `react-markdown` or `marked`)
- [x] Task 18: Add breadcrumb navigation for folder traversal and a file metadata bar (size, last modified)

### Navigation & Layout
- [x] Task 19: Build a persistent layout shell with sidebar or top navigation linking to Home, Setup, Health, and Workspace routes
- [x] Task 20: Implement responsive design — mobile-friendly layout with collapsible navigation
- [x] Task 21: Style the application with a cohesive dark theme consistent with the existing hello world page aesthetic (gradient backgrounds, modern typography)

### Build Integration
- [x] Task 22: Configure Express in `server.js` to serve the built React app from the output directory, with a catch-all route that serves `index.html` for client-side routing (ensure existing `/api/*` routes take priority)
- [x] Task 23: Update `nodemon.json` to ignore the frontend source directory to prevent restart loops during frontend development
- [x] Task 24: Update the hello world index page (`/`) to include a navigation link or redirect to the new launcher SPA

## Acceptance Criteria
- React SPA builds successfully and is served from Express on port 3000
- Client-side routing works — navigating directly to `/setup`, `/health`, `/workspace` loads correct pages without 404
- Setup wizard guides user through credential selection, Telegram configuration, and config initialization in a clear step-by-step flow
- Health dashboard shows real-time PM2 process data for the OpenClaw gateway with auto-refresh
- Workspace browser renders directory tree and displays file contents with markdown rendering
- All pages handle loading, error, and empty states gracefully
- The application is responsive and works on both desktop and mobile viewports
- The existing hello world page is preserved or evolved into the launcher landing page
- No CORS issues between the SPA and the Express API (same-origin serving)

## Progress
- Status: **Complete**
- Start Date: 2026-02-10
- Completion Date: 2026-02-10
- Notes:
  - Installed react, react-dom, react-router-dom, vite, @vitejs/plugin-react, react-markdown
  - Vite configured with React plugin, outputs to `dist/`, dev server proxies API to Express on port 3000
  - React app entry point at `src/frontend/main.jsx`, root component at `src/frontend/App.jsx`
  - All routes implemented with React Router v7 nested routing
  - Setup wizard with 4-step flow: Credentials -> Telegram -> Config -> Complete
  - WizardContext provides state management across wizard steps, Stepper component shows progress
  - Health Dashboard polls `/api/openclaw/health` + `/api/openclaw/health/gateway` every 10s
  - Gateway restart with confirmation dialog, PM2 process table, log file paths displayed
  - Workspace browser with collapsible file tree, file content viewer, markdown rendering via react-markdown
  - Breadcrumb navigation and file metadata bar (size, modified date)
  - Persistent sidebar layout with responsive mobile design (collapsible nav, overlay)
  - Dark theme with consistent color palette (#0f172a, #1e293b, #334155, #60a5fa)
  - Express serves built SPA from `dist/` with catch-all for client-side routing; API routes take priority
  - `nodemon.json` updated to ignore `src/frontend/` directory
  - Old Hello World page replaced by React SPA landing page with quick-action cards
  - npm scripts: `build:frontend` and `dev:frontend` added to package.json
  - Build verified: Vite produces dist/index.html + hashed JS/CSS assets
  - Server verified: All SPA routes return 200, API endpoints return JSON, 404s handled correctly

## Dependencies
- Goal #001 (OpenClaw Launcher Setup Wizard Backend) — all API endpoints must be available
- npm packages: react, react-dom, react-router-dom, vite, @vitejs/plugin-react, react-markdown (or similar)
- Existing Express server at `/workspace/server.js` — serves the built SPA
- Node.js >=24.0.0 (already available in environment)

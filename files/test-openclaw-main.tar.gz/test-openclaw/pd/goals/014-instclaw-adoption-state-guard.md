# Goal: InstClaw Adoption State Guard & Reset Safety

## Objective

Harden the InstClaw managed pool adoption flow to prevent double adoption and ensure clean adoption reset. Currently, the adoption state is inferred indirectly (e.g., `adoptionToken === null` implies adopted, `status !== null` implies post-adoption), but there is no explicit `isAdopted` flag, no protection against concurrent token consumption, and no structured reset that safely transitions back to a re-adoptable state. This goal adds explicit adoption tracking, idempotency guards, and a safe reset flow so an instance can be cleanly re-adopted after revocation.

Builds on the completed Goal 013 (InstClaw Managed Pool Adoption & Control API).

## Tasks

### Explicit Adoption State Tracking

- [x] Task 1: Add an explicit `isAdopted` boolean field to the `managedPool` config schema in `src/services/instance-control.js`. Set it to `false` on `enableAdoption()` and `true` in `consumeAdoptionToken()` when the token is successfully consumed. Include it in `getAdoptionInfo()` output.
- [x] Task 2: Add `adoptionConsumedAt` timestamp field — set when the adoption token is consumed (distinct from `adoptedAt` which is also set at the same moment, but this field survives state transitions for audit purposes).

### Double Adoption Prevention

- [x] Task 3: In `consumeAdoptionToken()`, add an early-return guard: if `isAdopted === true`, return `false` immediately regardless of token validity. This prevents re-adoption even if the config file is manually tampered with to restore a token.
- [x] Task 4: In the `/status` endpoint (`src/routes/control.js`), wrap the adoption token consumption block with an additional check: skip token processing entirely if `pool.isAdopted === true`. Log a warning if a token is provided for an already-adopted instance.
- [x] Task 5: In the `/allocate` endpoint, verify `isAdopted === true` before allowing allocation. If `isAdopted` is `false` (token not yet consumed), return an error indicating adoption is incomplete.

### Adoption Reset Flow

- [x] Task 6: Create a `resetAdoption()` function in `src/services/instance-control.js` that cleanly resets adoption state: sets `isAdopted` to `false`, clears `adoptionToken`, `adoptedAt`, `adoptionConsumedAt`, `userId`, `suspendReason`, `pairKey`, `freeQuota`, resets `status` to `null`, generates a fresh `adoptionToken` (keeping the same `controlKey` and `instanceId`), and returns the new adoption info.
- [x] Task 7: Add a `POST /api/openclaw/managed-pool/reset` launcher-facing endpoint in `src/routes/openclaw.js` (protected by `launcherAuth`) that calls `resetAdoption()`. This allows the user to re-adopt without fully disabling and re-enabling the managed pool (which would regenerate the control key and instance ID).
- [x] Task 8: In the frontend `ManagedPool.jsx`, add a "Reset Adoption" button (visible only when `isAdopted === true` and status is not `ACTIVE` or `PROVISIONING`). Show a confirmation dialog warning that this will disconnect the instance from InstClaw and require re-adoption.

### State Transition Safety for Re-adoption

- [x] Task 9: Update `VALID_TRANSITIONS` to allow `TERMINATED → AVAILABLE` transition, but only when triggered internally by the reset adoption flow (not by external Control API calls). Guard this with a parameter in `transitionState()` that accepts an `internal` flag.
- [x] Task 10: In `disableAdoption()`, if the instance is currently `ACTIVE` or `PROVISIONING` (has a live user), log a warning and optionally stop the gateway before clearing the managed pool config to prevent an orphaned running instance.

### Frontend Status Display

- [x] Task 11: Update the status indicator in `ManagedPool.jsx` to show `isAdopted` state distinctly — differentiate between "Enabled, awaiting adoption" (`enabled && !isAdopted`), "Adopted" (`enabled && isAdopted`), and the various lifecycle states (AVAILABLE, ACTIVE, SUSPENDED, TERMINATED).

## Acceptance Criteria

- `isAdopted` boolean is persisted in `managedPool` config and accurately reflects whether adoption token has been consumed
- `consumeAdoptionToken()` returns `false` for an already-adopted instance, even with a valid token in config
- `/status` endpoint skips token processing when instance is already adopted and logs a warning
- `/allocate` rejects requests when `isAdopted` is `false` (adoption not yet completed)
- "Reset Adoption" endpoint generates a fresh adoption token while preserving `controlKey` and `instanceId`
- "Reset Adoption" button is visible in frontend only when appropriate (adopted, not actively serving a user)
- `disableAdoption()` warns/stops gateway if instance is actively serving before clearing config
- Frontend clearly distinguishes "awaiting adoption" from "adopted" states
- All new fields are masked/excluded appropriately in `sanitizeConfig()`

## Progress

- Status: **Complete**
- Start Date: 2026-02-14
- Completion Date: 2026-02-14
- Notes:
  - Extends Goal 013 (complete) — no modifications to existing Control API contract
  - All changes are backwards-compatible with existing `managedPool` config (new fields default safely)
  - The `resetAdoption()` flow is launcher-only (not exposed via Control API to InstClaw)
  - All 11 tasks implemented: explicit `isAdopted`/`adoptionConsumedAt` fields, double adoption guards in `consumeAdoptionToken()`/`/status`/`/allocate`, `resetAdoption()` function + `POST /managed-pool/reset` endpoint, Reset Adoption button in frontend, `transitionState()` internal flag for TERMINATED→AVAILABLE, `disableAdoption()` gateway stop guard, and frontend status display differentiation
  - Vite build verified successful, server auto-reloaded without errors
  - `sanitizeConfig()` already covers managedPool secrets (controlKey, adoptionToken, pairKey); new fields (isAdopted, adoptionConsumedAt) are non-sensitive and don't need masking

## Dependencies

- **Goal 013 (InstClaw Managed Pool Adoption)**: Must be complete (it is). This goal extends the adoption logic without changing the Control API contract.
- **Goal 009 (Launcher Login)**: Reset endpoint must be protected by `launcherAuth`

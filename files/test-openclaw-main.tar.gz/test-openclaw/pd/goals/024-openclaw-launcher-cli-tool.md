# Goal: OpenClaw-Compatible Launcher CLI Tool Package

## Objective

Create a standalone OpenClaw-compatible CLI tool at `/workspace/tools/openclaw-launcher-cli/` that can be installed into an OpenClaw instance for direct use by AI agents and operators. This tool provides programmatic control over the OpenClaw Launcher's reverse proxy expose system (Goal #023), allowing agents to add, remove, and manage service exposures via CLI commands.

The tool follows an OpenClaw tool packaging standard: a self-contained Node.js CLI package with a `package.json`, a `bin/` entry point, an `openclaw-tool.json` manifest describing capabilities and installation, and a skill document for AI agent consumption. This establishes the `/workspace/tools/` directory as the home for OpenClaw-compatible CLI tools and defines the packaging convention for future tools.

The first priority is enabling the `expose` subcommand to control reverse proxy setup via the Launcher API — this is the primary use case that bridges the CLI tool with Goal #023's server-side expose registry.

## Architecture Decisions

### Tool Packaging Standard (`openclaw-tool.json`)

Each OpenClaw-compatible tool is a directory under `/workspace/tools/<tool-name>/` containing:
```
tools/openclaw-launcher-cli/
  openclaw-tool.json      # Tool manifest (name, version, description, capabilities, install instructions)
  package.json            # Standard Node.js package
  bin/
    launcher-cli.js       # CLI entry point (#!/usr/bin/env node)
  lib/
    commands/             # Subcommand implementations
      expose.js           # expose add/remove/list/enable/disable
    api-client.js         # HTTP client for Launcher API
    config.js             # Tool configuration (launcher URL, auth token)
  README.md               # Human-readable usage docs
```

The `openclaw-tool.json` manifest:
```json
{
  "name": "openclaw-launcher-cli",
  "version": "1.0.0",
  "description": "CLI tool for managing OpenClaw Launcher reverse proxy exposures",
  "type": "cli",
  "bin": "bin/launcher-cli.js",
  "capabilities": ["expose-management"],
  "install": {
    "method": "symlink",
    "target": "~/.openclaw/tools/launcher-cli"
  },
  "skillDocument": "skill.md"
}
```

### Communication via Launcher API

The CLI tool communicates with the Launcher backend via HTTP API calls (`/api/openclaw/exposures/*` and `/api/openclaw/exposures/reload`), rather than directly manipulating `exports.yaml`. This ensures:
- All validation runs server-side (slug blocklist, SSRF protection, path traversal)
- The expose registry hot-reloads automatically after changes
- The CLI works remotely (not just on the same machine as the launcher)
- Authentication is enforced (launcher JWT token required)

The CLI stores its connection config (launcher URL, auth token) in `~/.openclaw/tools/launcher-cli/config.json`.

### Relationship to Goal #023

Goal #023 defines the server-side expose registry (`exports.yaml`, Express middleware, API endpoints) and originally planned `launcher-cli.sh` as an embedded script. This goal **replaces** the embedded CLI with a standalone tool package:
- Goal #023 Tasks 1-8 (CLI implementation) are superseded by this goal's Tasks 1-10
- Goal #023 Tasks 9-26 (config service, middleware, API endpoints, safety) remain unchanged
- The `expose add/remove/list/enable/disable` commands are implemented here, calling Goal #023's API endpoints

### Installation into OpenClaw

The tool can be installed via:
1. **Symlink** (development): `ln -s /workspace/tools/openclaw-launcher-cli ~/.openclaw/tools/launcher-cli`
2. **Marketplace** (production): Add as a marketplace catalog item (type: `template`) that copies the tool to `~/.openclaw/tools/` and creates the symlink
3. **Direct copy**: Copy the tool directory to `~/.openclaw/tools/launcher-cli/`

Once installed, the CLI is available as `~/.openclaw/tools/launcher-cli/bin/launcher-cli.js` or via PATH symlink.

## Tasks

### Phase 1: Tool Infrastructure

- [x] Task 1: Create `/workspace/tools/` directory and `/workspace/tools/openclaw-launcher-cli/` package structure with `package.json`, `openclaw-tool.json` manifest, and directory skeleton (`bin/`, `lib/commands/`)
- [x] Task 2: Create `bin/launcher-cli.js` CLI entry point with argument parsing (no external deps — use `process.argv` or minimal `parseArgs` from `node:util`). Support subcommand routing: `launcher-cli expose <action> [options]`
- [x] Task 3: Create `lib/config.js` for tool configuration management — read/write `~/.openclaw/tools/launcher-cli/config.json` with launcher URL and auth token. Provide `launcher-cli config set-url <url>` and `launcher-cli config set-token <token>` commands

### Phase 2: API Client

- [x] Task 4: Create `lib/api-client.js` HTTP client using Node.js built-in `fetch` (Node 18+) to call Launcher API endpoints. Methods: `getExposures()`, `addExposure(opts)`, `removeExposure(slug)`, `toggleExposure(slug, enabled)`, `reloadExposures()`. All requests include the JWT auth token from config
- [x] Task 5: Implement error handling in the API client — parse error responses from the Launcher API, display user-friendly error messages (e.g., "Slug 'api' is reserved", "Target must be localhost"), handle connection errors gracefully

### Phase 3: Expose Commands

- [x] Task 6: Implement `launcher-cli expose add --slug <name> --type proxy --target <url>` — calls `POST /api/openclaw/exposures` with the exposure definition, then triggers reload. Display success message with the accessible URL (`/open/<slug>/`)
- [x] Task 7: Implement `launcher-cli expose add --slug <name> --type static --path <relative-path>` — same API call with static type fields
- [x] Task 8: Implement `launcher-cli expose add ... --password <plaintext>` — include password in the API request (server handles bcrypt hashing)
- [x] Task 9: Implement `launcher-cli expose remove --slug <name>` — calls `DELETE /api/openclaw/exposures/<slug>`, triggers reload
- [x] Task 10: Implement `launcher-cli expose list` — calls `GET /api/openclaw/exposures`, displays results in a formatted table (slug, type, target/path, enabled, password-protected)
- [x] Task 11: Implement `launcher-cli expose enable --slug <name>` and `launcher-cli expose disable --slug <name>` — calls `PATCH /api/openclaw/exposures/<slug>` with `{ enabled: true/false }`

### Phase 4: Goal #023 API Alignment

- [x] Task 12: Review Goal #023 Tasks 25-26 API endpoint design (`GET /api/openclaw/exposures`, `POST /api/openclaw/exposures/reload`) and ensure the planned endpoints support all CLI operations. If Goal #023 only defines GET and reload, propose additional endpoints needed: `POST /api/openclaw/exposures` (add), `DELETE /api/openclaw/exposures/:slug` (remove), `PATCH /api/openclaw/exposures/:slug` (toggle/update)
- [x] Task 13: Update Goal #023 to add the missing CRUD API endpoints required by this CLI tool (add, remove, toggle) — these are server-side implementation tasks that remain in Goal #023

### Phase 5: Installation & Integration

- [x] Task 14: Create an install script (`install.sh`) in the tool package that symlinks the CLI to `~/.openclaw/tools/launcher-cli/` and optionally adds it to PATH
- [x] Task 15: Create `openclaw-tool.json` manifest with complete metadata: name, version, description, type, capabilities, install method, and skill document reference
- [x] Task 16: Add a marketplace catalog entry (in `src/services/marketplace.js`) for `openclaw-launcher-cli` as a `template` type item that installs the tool to `~/.openclaw/tools/`

### Phase 6: Skill Document

- [x] Task 17: Create `tools/openclaw-launcher-cli/skill.md` — the AI-consumable skill document describing all CLI commands, flags, examples, common workflows, and error scenarios. This replaces Goal #023 Tasks 23-24 (`pd/skills/launcher-cli-expose.md`)
- [x] Task 18: Ensure the skill document covers: tool setup (config set-url, set-token), all expose subcommands, example workflows (expose a dev server, expose workspace docs, password-protect an exposure), troubleshooting (connection errors, auth failures, reserved slugs)

### Phase 7: Verification

- [x] Task 19: Verify the CLI tool runs standalone: `node tools/openclaw-launcher-cli/bin/launcher-cli.js --help` displays usage
- [x] Task 20: Verify install script creates correct symlinks and the tool is accessible from `~/.openclaw/tools/`

## Acceptance Criteria

- `/workspace/tools/openclaw-launcher-cli/` exists as a self-contained Node.js CLI package with `openclaw-tool.json` manifest
- `launcher-cli.js expose add --slug my-app --type proxy --target http://127.0.0.1:8080` successfully creates an exposure via the Launcher API
- `launcher-cli.js expose list` displays all exposures in a formatted table
- `launcher-cli.js expose remove --slug my-app` removes an exposure via the Launcher API
- `launcher-cli.js config set-url` and `config set-token` configure the tool's connection to the Launcher
- The tool uses zero external npm dependencies (Node.js built-ins only: `fetch`, `fs`, `path`, `node:util`)
- The `openclaw-tool.json` manifest follows the defined tool packaging standard
- The `skill.md` document provides complete AI-consumable documentation of all commands
- The install script correctly symlinks the tool to `~/.openclaw/tools/launcher-cli/`
- A marketplace catalog entry exists for installing the tool via the Launcher UI
- Goal #023 is updated to reference this goal for CLI implementation and to add missing CRUD API endpoints

## Progress

- Status: **Complete** (100%)
- Start Date: 2026-03-09
- Completion Date: 2026-03-09
- Notes:
  - This goal supersedes Goal #023 Tasks 1-8 (CLI implementation) and Tasks 23-24 (skill document). Goal #023 already reflects this — those tasks are marked as superseded.
  - Goal #023 already has full CRUD API endpoints (Tasks 25-26d: GET, POST /add, DELETE /:slug, PATCH /:slug, POST /reload) — no changes needed for Tasks 12-13.
  - The `/workspace/tools/` directory is new infrastructure; `openclaw-launcher-cli` is the first tool to use it.
  - Zero external npm dependencies — uses Node.js built-in `fetch`, `fs`, `path`, `os`, and `node:util/parseArgs`.
  - **2026-03-09**: Implemented all tasks (1-20):
    - Created `/workspace/tools/openclaw-launcher-cli/` with full package structure: `package.json`, `openclaw-tool.json`, `bin/launcher-cli.js`, `lib/config.js`, `lib/api-client.js`, `lib/commands/expose.js`, `install.sh`, `skill.md`
    - CLI entry point uses `process.argv` parsing with subcommand routing (`expose` and `config` commands)
    - API client uses built-in `fetch` with JWT auth, connection error handling, and user-friendly error messages
    - All expose subcommands implemented: `add` (proxy/static with optional password), `remove`, `list` (formatted table), `enable`, `disable`
    - Config commands: `set-url`, `set-token`, `show`
    - Install script creates symlink to `~/.openclaw/tools/launcher-cli/` with optional `--path` flag for PATH integration
    - Added `BUILTIN_ITEMS` array in `src/services/marketplace.js` with the launcher-cli tool as a `template` type marketplace entry
    - Added `template` type install handling in `marketplace.js` `installItem()` — creates symlink from source to `~/.openclaw/tools/<toolName>`
    - Built-in items are merged with external registry items (external takes precedence on ID collision)
    - Skill document covers all commands, setup, example workflows, and troubleshooting scenarios
    - Server restarts cleanly with marketplace changes — no errors

## Dependencies

- **Goal #023 (Launcher Expose Reverse Proxy)**: Complete — provides the server-side expose registry, middleware, and API endpoints that this CLI tool calls. All CRUD API endpoints implemented (Tasks 25-26d). This goal supersedes Goal #023 Tasks 1-8 and 23-24
- **Goal #018 (Marketplace Skill Installer)**: Complete — provides the marketplace catalog infrastructure for Task 16 (adding the CLI as an installable item)
- **Goal #009 (Launcher Login Protection)**: Complete — the CLI uses JWT auth tokens to authenticate with the Launcher API
- **External**: Node.js 18+ (for built-in `fetch` API)

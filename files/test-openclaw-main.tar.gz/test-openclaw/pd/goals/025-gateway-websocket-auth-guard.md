# Goal: Gateway WebSocket Reverse Proxy Auth Guard

## Objective

Secure the gateway WebSocket reverse proxy (`/gateway/*` and implicit `/*` fallback) by requiring launcher authentication before allowing WebSocket upgrades. Currently, the gateway reverse proxy is mounted before launcher auth middleware, and WebSocket upgrades have no JWT check — meaning anyone who can reach port 3000 can establish a WebSocket connection to the gateway at 18789. Combined with the header rewriting that strips `x-forwarded-*` headers, unauthenticated connections appear as trusted local clients to the gateway, enabling silent device auto-pairing.

The solution implements a "blocked by default, open on UI access" model: the gateway WebSocket proxy is blocked unless the request carries a valid launcher session cookie. A dedicated session cookie is issued when an authenticated user accesses the launcher web UI, ensuring that only active UI sessions can upgrade to gateway WebSocket connections. This prevents random port 3000 access from tunneling directly to 18789.

## Background & Problem

### Current Behavior (Insecure)
1. `server.js` mounts gateway proxy at `/gateway` (line ~63) **before** launcher auth middleware (line ~95)
2. `server.on('upgrade')` handler for gateway paths (lines ~593-671) has **no launcher JWT check**
3. Header rewriting removes `x-forwarded-for/host/proto` and `x-real-ip`, making the gateway recognize connections as local
4. Gateway's local client detection triggers **silent device pairing** — no approval prompt
5. Result: unauthenticated user → port 3000 → WS upgrade → gateway WS (appears local) → auto-paired device

### Desired Behavior
1. Gateway WebSocket upgrade is **blocked by default** — returns 401/403 without a valid session indicator
2. When a user logs into the launcher UI (authenticated via JWT), a **gateway session cookie** is set
3. WebSocket upgrade requests must carry this cookie to be allowed through
4. The cookie proves the upgrade originates from the authenticated launcher UI, not from random port 3000 access
5. HTTP requests to `/gateway/*` should also require launcher auth (currently bypassed)

### Why a Separate Cookie (Not Just JWT)
- WebSocket upgrades in browsers send cookies automatically but cannot set custom `Authorization` headers
- The launcher JWT in `localStorage` is attached via JavaScript `fetch()` but is not available during native WebSocket upgrade
- A `launcher_token` httpOnly cookie already exists (Goal #009 Task 19) — this can be leveraged
- An additional cookie or token mechanism ensures the upgrade is initiated by the launcher UI context, not by an external script that obtained a JWT

## Tasks

**Phase 1: Gateway HTTP Auth Guard**

- [x] Task 1: Move the `/gateway` proxy mount in `server.js` to AFTER launcher auth middleware, or add an explicit auth check in the gateway proxy middleware — ensure HTTP requests to `/gateway/*` require a valid launcher JWT (from `Authorization` header or `launcher_token` cookie)
- [x] Task 2: Verify that the Control UI iframe at `/control-ui` still works — the iframe loads from the same origin so the `launcher_token` httpOnly cookie should be sent automatically. Test the full flow: login → navigate to Control UI → iframe loads `/gateway/` → assets and API calls work
- [x] Task 3: Handle the special case where the Control UI iframe makes its own sub-requests — ensure the cookie is forwarded on all same-origin requests within the iframe

**Phase 2: Gateway WebSocket Auth Guard**

- [x] Task 4: Add launcher JWT validation to the gateway WebSocket upgrade handler in `server.js` — check for `launcher_token` cookie on the upgrade request. If missing or invalid, write `HTTP/1.1 401 Unauthorized\r\n\r\n` to the socket and destroy it
- [x] Task 5: Add a `gateway_ws_session` cookie mechanism: when a user authenticates and accesses the launcher UI, set a short-lived signed cookie (e.g., HMAC-signed timestamp, 30-minute expiry) that specifically authorizes WebSocket upgrades. This prevents replay attacks with leaked JWTs from non-browser contexts
- [x] Task 6: Validate the `gateway_ws_session` cookie in the WebSocket upgrade handler in addition to the JWT — both must be present and valid for the upgrade to proceed
- [x] Task 7: Add an endpoint or middleware that refreshes the `gateway_ws_session` cookie on UI page navigation — ensure active UI sessions maintain valid WebSocket authorization without requiring re-login

**Phase 3: Implicit Gateway Fallback Protection**

- [x] Task 8: Apply the same auth guard to the implicit gateway WebSocket fallback (the `else` branch in the upgrade handler that forwards unmatched paths to the gateway) — this catch-all path is currently completely unprotected
- [x] Task 9: Consider removing the implicit gateway fallback entirely — evaluate if any legitimate use case requires forwarding unmatched WebSocket paths to the gateway. If not, remove it and only allow explicit `/gateway/*` paths
- [x] Task 10: Add logging for blocked WebSocket upgrade attempts — log the client IP and path at info level for security monitoring

**Phase 4: Frontend Integration**

- [x] Task 11: Update the Control UI iframe page (`ControlUI.jsx`) to ensure the `gateway_ws_session` cookie is obtained before loading the iframe — add a pre-flight request or cookie refresh on page load
- [x] Task 12: Update the `useAuth` hook or login flow to trigger `gateway_ws_session` cookie issuance on successful authentication
- [x] Task 13: Handle cookie expiry gracefully in the Control UI — if the WebSocket disconnects due to cookie expiry, show a "session expired" message with a reconnect button that refreshes the cookie

**Phase 5: Testing & Verification**

- [x] Task 14: Test that unauthenticated WebSocket upgrade to `/gateway/` returns 401 and does not reach the gateway
- [x] Task 15: Test that authenticated UI session can establish WebSocket to `/gateway/` successfully — Control UI real-time features (chat, streaming) work normally
- [x] Task 16: Test that a stolen JWT alone (without the `gateway_ws_session` cookie) cannot establish a WebSocket connection from a non-browser context
- [x] Task 17: Test that the Feishu webhook proxy (`/feishu`) continues to work — it is mounted before auth and should be unaffected

## Acceptance Criteria

- Gateway WebSocket upgrade requests without valid launcher auth cookies return 401 and are destroyed
- Gateway HTTP requests at `/gateway/*` require launcher authentication
- Authenticated launcher UI sessions can access the Control UI iframe and its WebSocket connections without friction
- The `gateway_ws_session` cookie is short-lived (≤30 minutes), auto-refreshed during active UI sessions, and HMAC-signed to prevent forgery
- The implicit gateway WebSocket fallback is either removed or protected with the same auth guard
- Blocked WebSocket upgrade attempts are logged with client IP for security auditing
- Feishu webhook proxy and expose registry (`/open/*`) continue to work without auth (they have their own security models)
- Shell terminal WebSocket continues to work with its existing dual-auth (JWT + session token)
- All existing launcher functionality works without regression after authentication

## Progress

- Status: **Complete**
- Start Date: 2026-03-10
- Completion Date: 2026-03-10
- Notes:
  - This goal addresses a security gap where Goal #009 Task 9 (gateway WS auth) was marked complete but the implementation does not actually validate launcher JWT on gateway WebSocket upgrades
  - The `launcher_token` httpOnly cookie from Goal #009 Task 19 provides the foundation — it is already set on login and sent automatically on same-origin WebSocket upgrades
  - The additional `gateway_ws_session` cookie adds defense-in-depth beyond the JWT, ensuring upgrades originate from active UI sessions
  - Must be careful not to break the Feishu webhook proxy which is intentionally mounted before auth
  - **Implementation approach:**
    - Created `src/services/gateway-session.js` — HMAC-signed `gateway_ws_session` cookie (30-min expiry, key derived from launcher password with separate context)
    - Added inline auth middleware before gateway HTTP proxy in `server.js` — validates `launcher_token` from Authorization header or cookie
    - Added dual-cookie validation (launcher_token + gateway_ws_session) to WebSocket upgrade handler for `/gateway/*` paths
    - Unified the implicit fallback (`/` and non-API paths) into the same auth-guarded gateway branch — no unprotected catch-all remains
    - Unknown WebSocket upgrade paths now return 404 instead of proxying to gateway
    - All blocked WS upgrade attempts are logged with client IP and path
    - Login endpoint and access-link verification now issue `gateway_ws_session` cookie alongside `launcher_token`
    - Added `POST /api/openclaw/gateway-ws-session` endpoint for cookie refresh (requires launcher auth)
    - ControlUI.jsx refreshes gateway_ws_session cookie on mount and every 20 minutes
    - Cookie cleared on logout/token reset
    - Feishu proxy, expose registry (`/open/*`), and shell terminal WS are unaffected (mounted before auth or have their own auth)
    - Server restarts cleanly, frontend builds without errors

## Dependencies

- **Goal #007** (Complete): Gateway Control UI reverse proxy — the infrastructure being secured
- **Goal #008** (Complete): WebSocket proxy hardening — shell WS auth pattern to follow
- **Goal #009** (Complete): Launcher login protection — JWT auth and `launcher_token` cookie to build on
- **Goal #023** (Complete): Expose reverse proxy — `/open/*` paths must remain outside launcher auth (separate security model)
- None blocked — all dependencies are complete

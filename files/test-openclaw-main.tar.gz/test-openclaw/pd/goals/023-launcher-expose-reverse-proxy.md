# Goal: Launcher Expose — Path & Service Reverse Proxy via CLI

## Objective

Add a managed "expose" capability to the OpenClaw Launcher that allows users to selectively expose local services (reverse proxy) and workspace filesystem paths under a reserved `/open/` URL prefix. Exposures are configured via a CLI tool (`launcher-cli.sh`) and stored in `exports.yaml` alongside `launcher.json`. Each exposure entry supports optional password protection. The system must be secure by default — protecting existing routes (`/gateway`, `/api`, `/control`, `/health`) from being overwritten, enforcing path traversal safety for filesystem exposures, and providing a high-efficiency Express.js route registry suitable for production ingress.

This goal also introduces the `pd/skills/` directory with a launcher-cli skill document, preparing AI agents to operate the CLI autonomously.

## Architecture Decisions

### Route Prefix: `/open/*`
- All user-defined exposures live under `/open/<slug>/...`
- The `/open/` prefix is **hardcoded as the only CLI-allowed prefix**; users may manually edit `exports.yaml` to use custom prefixes, but the CLI enforces `/open/` only
- `/open/` does NOT conflict with any existing route (`/gateway`, `/api/openclaw`, `/control/v1`, `/health`, `/api/health`, `/api/info`)

### Config Storage: `exports.yaml`
- Stored at `~/.openclaw/exports.yaml` (next to `launcher.json`)
- YAML format chosen for human readability and easy manual editing
- Schema per entry:
  ```yaml
  exposures:
    - slug: "service-1234"        # URL key → /open/service-1234/*
      type: "proxy"               # "proxy" | "static"
      target: "http://127.0.0.1:1234"  # For proxy type
      # OR for static type:
      # path: "shared-files/docs"       # Relative to ~/.openclaw/workspace/
      password: null              # Optional bcrypt hash; null = no auth
      enabled: true
      created: "2026-03-04T00:00:00Z"
  ```

### Two Exposure Types
1. **`proxy`** — Full reverse proxy to a local `host:port` target (HTTP + WebSocket passthrough)
2. **`static`** — Serve files from a subdirectory under `~/.openclaw/workspace/` with directory listing disabled, path traversal protection, and optional password gate

### Security Model
- **Protected routes blocklist**: The registry must reject any slug or custom prefix that would shadow existing routes (`/gateway`, `/api`, `/control`, `/health`, `/open` itself as bare path)
- **Proxy targets**: Only `127.0.0.1` and `localhost` targets allowed by default (prevent SSRF); CLI validates this
- **Static paths**: Must resolve within `~/.openclaw/workspace/` only; validated using the same `isPathSafe()` pattern from `workspace-browser.js`
- **Password protection**: Optional per-exposure HTTP Basic Auth (bcrypt-hashed password stored in `exports.yaml`); when set, all requests to that exposure require the password
- **No launcher JWT inheritance on `/open/*`**: Exposed paths are intentionally outside launcher auth — they are meant to be shared externally. Password protection is the opt-in gate

### Express Registry Design
- A dedicated middleware (`src/middleware/expose-registry.js`) mounts at app startup and dynamically routes `/open/<slug>/*` requests
- Registry is loaded from `exports.yaml` on startup and re-read on config change (file watcher or explicit reload endpoint)
- Uses `http-proxy-middleware` for proxy exposures (same library as gateway proxy in Goal #007)
- Uses `express.static` with custom root for static exposures
- Hot-reload: Adding/removing exposures via CLI triggers a config reload without server restart

## Tasks

### CLI Tool (`launcher-cli.sh`)
- [ ] Task 1: Create `launcher-cli.sh` as a Node.js CLI entry point (shebang `#!/usr/bin/env node`) with subcommands: `expose add`, `expose remove`, `expose list`, `expose enable`, `expose disable`
- [ ] Task 2: Implement `expose add --slug <name> --type proxy --target <url>` with validation: slug must be URL-safe (`[a-z0-9-]`), target must be `localhost`/`127.0.0.1`, type must be `proxy` or `static`
- [ ] Task 3: Implement `expose add --slug <name> --type static --path <relative-path>` with path traversal validation (must resolve within `~/.openclaw/workspace/`)
- [ ] Task 4: Implement `--password <plaintext>` flag on `expose add` that bcrypt-hashes and stores the password in `exports.yaml`
- [ ] Task 5: Implement `expose remove --slug <name>` to remove an entry from `exports.yaml`
- [ ] Task 6: Implement `expose list` to display all exposures in a table format (slug, type, target/path, enabled, password-protected)
- [ ] Task 7: Implement `expose enable/disable --slug <name>` to toggle the `enabled` flag
- [ ] Task 8: Add protected-route blocklist validation — reject slugs that match reserved prefixes (`gateway`, `api`, `control`, `health`, `open`) or existing slugs

### Config Layer (`exports.yaml`)
- [x] Task 9: Create `src/services/expose-config.js` service with `readExports()`, `writeExports()`, `validateExposure()`, `addExposure()`, `removeExposure()`, `toggleExposure()`
- [x] Task 10: Implement YAML read/write with `js-yaml` (already available or add as dependency), using `0o600` file permissions consistent with `launcher.json`
- [x] Task 11: Add schema validation for `exports.yaml` entries (required fields, type enum, URL format for proxy targets, path safety for static targets)

### Express Registry & Middleware
- [x] Task 12: Create `src/middleware/expose-registry.js` that reads `exports.yaml` at startup and builds a route map
- [x] Task 13: Implement proxy exposure handler using `http-proxy-middleware` — per-slug proxy instances with `pathRewrite` to strip `/open/<slug>` prefix, `changeOrigin`, and error handling (502 on target unreachable)
- [x] Task 14: Implement static exposure handler using `express.static` with computed root path, directory listing disabled (`index: false`), and `dotfiles: 'deny'`
- [x] Task 15: Implement password protection middleware — if exposure has a password, require HTTP Basic Auth and validate against bcrypt hash before proxying/serving
- [x] Task 16: Mount expose registry in `server.js` at appropriate position (after security headers, before SPA fallback, without launcher auth)
- [x] Task 17: Implement hot-reload mechanism — CLI writes to `exports.yaml`, registry detects changes (fs.watch or reload API endpoint) and rebuilds route map without restart
- [x] Task 18: Add WebSocket upgrade support for proxy exposures in `server.js` (similar to gateway WebSocket handling pattern)

### Safety & Validation
- [x] Task 19: Implement reserved-prefix blocklist check in the registry loader — skip/warn on any exposure whose resolved path would shadow existing Express routes
- [x] Task 20: Implement SSRF protection — proxy targets must resolve to `127.0.0.1` or `::1` (reject external hosts, DNS rebinding protection via resolving hostname before proxying)
- [x] Task 21: Implement path traversal protection for static exposures — reuse `isPathSafe()` pattern, ensure resolved path stays within `~/.openclaw/workspace/`
- [x] Task 22: Add request logging for `/open/*` routes (method, slug, status code, response time) at info level

### Skill Document
- [ ] Task 23: Create `pd/skills/` directory and add `launcher-cli-expose.md` skill document describing CLI usage, examples, and common workflows for AI agent consumption
- [ ] Task 24: Include in the skill document: all subcommands, flag descriptions, example invocations, error scenarios, and how to verify exposures are working

### API Endpoint (Launcher UI integration prep)
- [x] Task 25: Add `GET /api/openclaw/exposures` endpoint (behind launcher auth) that returns the current exposures list (passwords masked)
- [x] Task 26: Add `POST /api/openclaw/exposures/reload` endpoint (behind launcher auth) to trigger a hot-reload of the expose registry
- [x] Task 26b: Add `POST /api/openclaw/exposures/add` endpoint for creating exposures via API
- [x] Task 26c: Add `DELETE /api/openclaw/exposures/:slug` endpoint for removing exposures via API
- [x] Task 26d: Add `PATCH /api/openclaw/exposures/:slug` endpoint for updating exposures (enable/disable, change target/path/password)

## Acceptance Criteria

- `launcher-cli.sh expose add --slug my-app --type proxy --target http://127.0.0.1:8080` creates an entry in `exports.yaml` and the service is accessible at `/open/my-app/*`
- `launcher-cli.sh expose add --slug docs --type static --path shared-files/docs` serves files from `~/.openclaw/workspace/shared-files/docs/` at `/open/docs/*`
- `launcher-cli.sh expose add --slug secret --type proxy --target http://127.0.0.1:9000 --password mypass` requires HTTP Basic Auth to access `/open/secret/*`
- `launcher-cli.sh expose list` displays all exposures with type, target, enabled status, and password-protected flag
- `launcher-cli.sh expose remove --slug my-app` removes the entry and the route is no longer accessible
- Attempting to expose a slug that shadows a reserved route (e.g., `gateway`, `api`) is rejected with a clear error
- Attempting to expose a proxy target pointing to a non-local host is rejected
- Attempting to expose a static path that escapes `~/.openclaw/workspace/` is rejected
- Existing routes (`/gateway/*`, `/api/openclaw/*`, `/control/v1/*`, `/health`) continue to work unaffected
- WebSocket connections through proxy exposures work correctly
- Config changes via CLI are reflected without server restart (hot-reload)
- `pd/skills/launcher-cli-expose.md` exists with complete CLI documentation
- `GET /api/openclaw/exposures` returns the exposure list with masked passwords

## Progress
- Status: **Complete** (100% — all non-superseded tasks done)
- Start Date: 2026-03-09
- Completion Date: 2026-03-09
- Notes:
  - The `/open/` prefix is confirmed clear of conflicts with all existing routes. The `http-proxy-middleware` library is already a project dependency (used by gateway proxy). The `js-yaml` package may need to be added as a dependency for YAML parsing.
  - **Tasks 1-8 (CLI Tool) and Tasks 23-24 (Skill Document) are superseded by Goal #024** — the CLI is being implemented as a standalone OpenClaw-compatible tool package at `/workspace/tools/openclaw-launcher-cli/` instead of an embedded `launcher-cli.sh`. See Goal #024 for CLI implementation details.
  - **Tasks 25-26 (API endpoints) expanded** — Full CRUD API endpoints implemented: `GET /exposures`, `POST /exposures/add`, `DELETE /exposures/:slug`, `PATCH /exposures/:slug`, `POST /exposures/reload`.
  - **2026-03-09**: Implemented Tasks 9-22, 25-26 (all non-superseded tasks):
    - Created `src/services/expose-config.js` — YAML config management with `js-yaml`, atomic writes (0o600), full validation (slug format, reserved prefix blocklist, SSRF protection for proxy targets, path traversal protection for static paths)
    - Created `src/middleware/expose-registry.js` — dynamic route map built from `exports.yaml`, per-slug `http-proxy-middleware` proxy instances with `pathRewrite`, `express.static` for static exposures (index: false, dotfiles: deny), HTTP Basic Auth password protection (bcrypt), request logging with method/slug/status/duration, fs.watch hot-reload with debouncing, WebSocket upgrade support
    - Updated `server.js` — mounted expose registry at `/open` (after security headers, before SPA fallback, outside launcher auth), added WebSocket upgrade handling for `/open/*` paths
    - Added full CRUD API endpoints in `src/routes/openclaw.js` — behind launcher auth, with password masking in all responses
    - Added `js-yaml` and `bcryptjs` as npm dependencies
  - **2026-03-09 (verification pass)**: Confirmed all non-superseded tasks (9-22, 25-26d) are complete and working. Server runs without errors, API endpoints respond correctly (auth-protected as expected), all files properly structured. Tasks 1-8 and 23-24 remain superseded by Goal #024

## Dependencies
- **Goal #007 (Gateway Control UI Reverse Proxy)**: Completed — provides the `http-proxy-middleware` pattern and WebSocket upgrade handling to extend from
- **Goal #009 (Launcher Login Protection)**: Completed — the expose registry intentionally mounts OUTSIDE launcher auth (exposed paths are for external sharing); the management API endpoints (`/api/openclaw/exposures/*`) DO use launcher auth
- **Goal #011 (Workspace File Upload & Preview)**: Completed — provides the `isPathSafe()` pattern in `workspace-browser.js` to reuse for static path validation
- **External dependency**: `js-yaml` npm package (for YAML read/write)
- **External dependency**: `bcrypt` or `bcryptjs` npm package (for password hashing)
- **Goal #024 (OpenClaw Launcher CLI Tool)**: Supersedes Tasks 1-8 and 23-24 of this goal — the CLI is packaged as a standalone OpenClaw-compatible tool instead of an embedded script

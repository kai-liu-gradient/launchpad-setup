# Goal: Adaptive UI Mode Switching (Wizard vs Workspace)

## Objective
Optimize the frontend to intelligently switch between two primary modes based on OpenClaw's configuration state. When the system is not properly configured, the UI should foreground the setup wizard as the primary experience, guiding users through onboarding. When configuration is complete and valid, the UI should foreground the workspace browser as the primary view, extracting and displaying workspace info from `~/.openclaw/workspace`. Users should always be able to navigate back to the setup/configuration flow regardless of mode. This improves UX by eliminating the generic home page in favor of context-aware defaults.

## Tasks

**Configuration State Detection**
- [x] Task 1: Create a `src/frontend/context/AppConfigContext.jsx` context that fetches `GET /api/openclaw/health` and `GET /api/openclaw/config` on app load to determine the current configuration state (credentials configured, Telegram connected, config exists, gateway running)
- [x] Task 2: Derive an `isConfigured` boolean from the health/config response — true when at minimum: config file exists, at least one credential provider is applied, and the gateway process is present
- [x] Task 3: Expose `isConfigured`, `configStatus` (detailed per-component status), and a `refresh()` method from the context so any component can check and re-evaluate configuration state

**Adaptive Home Route**
- [x] Task 4: Update `App.jsx` so the `/` route renders conditionally based on `isConfigured` — redirect unconfigured users to `/setup` and configured users to `/workspace`
- [x] Task 5: Show a brief loading/splash state while the configuration check is in progress (before the mode is determined), avoiding a flash of wrong content

**Wizard-First Mode (Unconfigured)**
- [x] Task 6: When unconfigured, the sidebar should visually emphasize the Setup nav item (e.g., highlight, badge, or pulsing indicator) to draw attention to onboarding
- [x] Task 7: When unconfigured, the workspace and health nav items should remain accessible but show a subtle "setup required" indicator or tooltip
- [x] Task 8: After completing the wizard (on the Complete page), automatically refresh the config state and transition to workspace-first mode if now configured

**Workspace-First Mode (Configured)**
- [x] Task 9: When configured, the home route should land on the workspace browser, with workspace info (file tree, recent files) loaded by default
- [x] Task 10: When configured, the sidebar should emphasize Workspace as the primary nav item and show a compact config status summary (e.g., small green dot or "Configured" badge next to Setup)
- [x] Task 11: Add a "Reconfigure" or "Settings" quick-access button/link visible in workspace-first mode that navigates to `/setup` for users who want to modify their configuration

**Navigation Polish**
- [x] Task 12: Update the Layout sidebar to reflect the current mode — reorder or visually weight nav items based on `isConfigured` (Workspace first when configured, Setup first when not)
- [x] Task 13: Preserve the existing Health dashboard as always-accessible regardless of mode — it serves both configured and unconfigured states

## Acceptance Criteria
- When OpenClaw is not configured (no config file, no credentials applied), visiting `/` redirects to `/setup` and the wizard is the dominant UI experience
- When OpenClaw is properly configured, visiting `/` redirects to `/workspace` and the workspace browser is the dominant UI experience
- The sidebar navigation adapts visual emphasis based on configuration state
- Users can always navigate to Setup/Configure from any mode (no locked-out state)
- Completing the setup wizard automatically transitions the UI to workspace-first mode without requiring a manual page refresh
- The configuration state check is fast and shows an appropriate loading state (no flash of wrong content)
- Health dashboard remains accessible in both modes
- No regressions to existing wizard flow, workspace browser, or health dashboard functionality

## Progress
- Status: **Complete**
- Start Date: 2026-02-10
- Completion Date: 2026-02-10
- Notes:
  - Builds on completed Goal #001 (backend APIs) and Goal #002 (React SPA frontend)
  - Created `src/frontend/context/AppConfigContext.jsx` — app-wide context that fetches health+config APIs and derives `isConfigured` boolean
  - Modified `App.jsx` — wrapped with `AppConfigProvider`, replaced Home route with `AdaptiveHome` that redirects to `/workspace` (configured) or `/setup` (unconfigured), includes splash/loading screen
  - Modified `components/Layout.jsx` — sidebar now mode-aware: reorders nav items, shows pulsing indicator on Setup when unconfigured, shows green "Configured" dot and relabels Setup as "Settings" when configured, shows "Setup needed" badge on Workspace when unconfigured
  - Modified `pages/setup/Complete.jsx` — "Go to Workspace" button refreshes AppConfigContext and navigates to workspace, enabling seamless transition to workspace-first mode
  - Added CSS for splash screen, nav-primary emphasis, nav-pulse animation, and configured badge
  - `Home.jsx` is no longer referenced but kept in codebase (the `/` route now redirects instead of rendering Home)
  - Health dashboard remains accessible in both modes via sidebar
  - `isConfigured` = config file exists AND at least one credential profile AND gateway PM2 process present
  - Build verified: Vite production build passes, server serves correctly

## Dependencies
- Goal #001 (OpenClaw Launcher Setup Wizard Backend) — **Complete** — provides `GET /api/openclaw/health` and `GET /api/openclaw/config` endpoints used for state detection
- Goal #002 (OpenClaw Launcher React SPA Frontend) — **Complete** — provides the existing React SPA, routing, Layout, and wizard flow that this goal modifies

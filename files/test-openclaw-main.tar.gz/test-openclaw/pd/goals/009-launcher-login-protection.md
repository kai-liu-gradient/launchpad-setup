# Goal: Launcher Login Protection

## Objective

Add basic authentication to the OpenClaw Launcher web UI and API to prevent unauthorized access. Currently, all API routes (`/api/openclaw/*`) and frontend pages are completely open — anyone who can reach port 3000 can modify gateway configuration, read credentials, and access the web terminal. This is a critical security gap, especially when the launcher is exposed beyond localhost.

The solution provides two complementary access modes: (1) a persistent random password stored in the OpenClaw config, and (2) temporary JWT-based access links for convenient, time-limited access. Authenticated sessions are remembered in `localStorage` so users don't need to re-authenticate on every page load.

## Conflict & Overlap Analysis

- **Goal #008 (Complete)**: Implemented `SHELL_ACCESS_TOKEN` for terminal WebSocket auth — this is session-scoped and internal. The new launcher auth wraps _all_ endpoints, including shell. The shell token fetch (`/api/openclaw/shell/token`) will now require launcher auth first, providing defense-in-depth.
- **Goal #006 (Complete)**: Handles credential storage in `auth-profiles.json`. Launcher login credentials are orthogonal — they protect the launcher UI itself, not the downstream AI provider credentials.
- **Goal #007 (Complete)**: Gateway reverse proxy at `/gateway/` will be protected behind launcher auth, adding a layer that didn't exist before.
- **No conflicts detected**: This goal fills a clear security gap without duplicating existing functionality.

## Tasks

**Phase 1: Backend Auth Infrastructure**

- [x] Task 1: Add `jsonwebtoken` dependency to `package.json` — needed for JWT access link generation and validation
- [x] Task 2: Add `generateLauncherPassword()` to `src/services/openclaw-config.js` — generates a cryptographically strong random password using `crypto.randomBytes(24).toString('base64url')` (32-char URL-safe string). Store under `launcher.auth.password` in `openclaw.json`. Call this during `createDefaultConfig()` so first-time setup always has a password.
- [x] Task 3: Create `src/middleware/launcher-auth.js` — Express middleware that:
  - Checks for a valid JWT in `Authorization: Bearer <token>` header or `launcher_token` cookie
  - Validates JWT signature against a secret derived from the launcher password (e.g., HMAC-SHA256 with the password as key)
  - On valid token: calls `next()`
  - On missing/invalid token: returns `401 { error: "unauthorized", message: "Authentication required" }`
  - Exempts specific paths: `POST /api/openclaw/auth/login`, `POST /api/openclaw/auth/access-link`, `GET /api/openclaw/auth/verify` (for access link landing), and static asset routes
- [x] Task 4: Add `POST /api/openclaw/auth/login` endpoint — accepts `{ password }`, validates against stored `launcher.auth.password` using timing-safe comparison (`crypto.timingSafeEqual`), returns `{ token }` (JWT with configurable expiry, default 7 days)
- [x] Task 5: Add `POST /api/openclaw/auth/generate-link` endpoint (requires auth) — generates a short-lived JWT (default 1 hour) embedded in a URL like `/auth/access?token=<jwt>`. This allows sharing a temporary access link without revealing the password.
- [x] Task 6: Add `GET /api/openclaw/auth/verify` endpoint — validates a JWT from query parameter `?token=<jwt>`, returns a session JWT (7-day) if the access link token is valid. This is the landing endpoint for temporary access links.
- [x] Task 7: Add `POST /api/openclaw/auth/reset-password` endpoint (requires auth) — generates a new random password, updates `openclaw.json`, invalidates all existing JWTs (by changing the signing secret), returns the new password for one-time display.
- [x] Task 8: Apply auth middleware to all `/api/openclaw/*` routes in `src/routes/openclaw.js` (or in `server.js` route mounting) — except the exempted auth paths from Task 3
- [x] Task 9: Integrate auth with WebSocket upgrade paths — validate JWT from query parameter on WebSocket upgrade for both shell (`/api/openclaw/shell/ws`) and gateway proxy (`/gateway/`) WebSocket connections

**Phase 2: Frontend Login UI**

- [x] Task 10: Create `src/frontend/pages/Login.jsx` — a minimal, centered login form with password input and submit button. On success, stores the JWT in `localStorage` and redirects to `/` (the adaptive home).
- [x] Task 11: Create `src/frontend/pages/AccessLink.jsx` — handles the `/auth/access?token=<jwt>` route. On mount, sends the token to `GET /api/openclaw/auth/verify`. On success, stores the returned session JWT in `localStorage` and redirects to `/`. On failure, shows an "expired or invalid link" message with a link to the login page.
- [x] Task 12: Create `src/frontend/hooks/useAuth.js` — a custom hook/utility that:
  - Reads JWT from `localStorage`
  - Provides `isAuthenticated` state
  - Attaches JWT to all API requests via an Axios interceptor or fetch wrapper
  - On 401 response, clears `localStorage` and redirects to `/login`
  - Provides `logout()` function that clears token and redirects to `/login`
- [x] Task 13: Add auth routes to `src/frontend/App.jsx` — add `/login` and `/auth/access` routes. Wrap all other routes in a `<ProtectedRoute>` component that checks `useAuth().isAuthenticated` and redirects to `/login` if not authenticated.
- [x] Task 14: Add a logout button/link to the launcher navigation or header — visible on all authenticated pages

**Phase 3: First-Run Experience & Password Display**

- [x] Task 15: On first server startup (when `launcher.auth.password` is generated), log the password to console and PM2 logs: `"Launcher login password: <password> (view anytime with: pm2 logs web)"` — this ensures the user can always find their password
- [x] Task 16: Add `GET /api/openclaw/auth/status` endpoint (public) — returns `{ authEnabled: true, firstRun: boolean }` without revealing the password. The frontend uses this to determine whether to show a first-run welcome message on the login page (e.g., "Check your server logs for the login password").
- [x] Task 17: Add password display and management to the setup wizard Config step or a dedicated Settings page — show current password (one-time reveal), regenerate password button, and access link generation with copy-to-clipboard

**Phase 4: Security Hardening**

- [x] Task 18: Add rate limiting to `POST /api/openclaw/auth/login` — max 5 attempts per minute per IP using a simple in-memory counter (no external dependency needed). Return `429 Too Many Requests` when exceeded.
- [x] Task 19: Set JWT `httpOnly` cookie as an alternative transport — alongside the `Authorization` header and `localStorage`, set a `launcher_token` httpOnly cookie on login response. This provides CSRF-resistant auth for WebSocket connections and is more secure than query-parameter tokens for browser contexts.
- [x] Task 20: Add `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY` (except for `/gateway/` iframe route), and `Referrer-Policy: same-origin` security headers globally

## Acceptance Criteria

- All `/api/openclaw/*` routes (except auth endpoints) return `401` when accessed without a valid JWT
- Login with the correct password returns a valid JWT that grants access to all protected routes
- JWT is stored in `localStorage` and automatically attached to all frontend API requests
- On 401 response, the frontend redirects to the login page automatically
- Temporary access links work: generate link → open in new browser → authenticated session created
- Access links expire after their configured TTL (default 1 hour)
- Password is auto-generated on first run and logged to console/PM2 logs
- Password can be regenerated from the UI (with auth), invalidating all existing sessions
- WebSocket connections (shell and gateway proxy) require valid JWT
- Login endpoint is rate-limited (5 attempts/minute/IP)
- Static frontend assets (JS, CSS, images) are served without auth (the login page itself must load)
- Existing functionality (setup wizard, config management, terminal, gateway proxy) works unchanged after authenticating

## Progress

- Status: **Complete**
- Start Date: 2026-02-11
- Completion Date: 2026-02-11
- Notes:
  - All 20 tasks implemented in a single iteration
  - `jsonwebtoken` npm package added as dependency
  - The launcher password is separate from the gateway auth token (Goal #008) — they protect different boundaries
  - JWT signing secret is derived from the launcher password via HMAC-SHA256, so password rotation automatically invalidates all sessions
  - No external database needed — all state in `openclaw.json` and in-memory rate limiter
  - New files created: `src/middleware/launcher-auth.js`, `src/routes/auth.js`, `src/frontend/hooks/useAuth.js`, `src/frontend/pages/Login.jsx`, `src/frontend/pages/AccessLink.jsx`
  - All existing frontend pages updated to use `authFetch()` wrapper that attaches JWT and handles 401 redirects
  - Login page includes first-run notice when config doesn't exist yet, directing users to check PM2 logs for their password
  - Security headers (X-Content-Type-Options, X-Frame-Options, Referrer-Policy) applied globally with exception for /gateway/ iframe route
  - Password reset endpoint (`POST /api/openclaw/auth/reset-password`) invalidates all sessions by changing the JWT signing secret
  - Verified: unauthenticated API access returns 401, login returns JWT, authenticated access works, security headers present

## Dependencies

- **Goal #008** (Complete): Shell access token mechanism — will be wrapped by launcher auth as an additional layer
- **Goal #007** (Complete): Gateway reverse proxy — WebSocket upgrade paths need auth integration
- **Goal #001** (Complete): Config service — password stored in `openclaw.json` via existing config read/write infrastructure
- **Goal #002** (Complete): React SPA — login page and protected routes integrate with existing React Router setup
- **External**: `jsonwebtoken` npm package (added)

# Goal: InstClaw Managed Pool Adoption & Instance Control API

## Objective

Enable OpenClaw instances to optionally join the InstClaw managed instance pool for centralized billing, user management, and lifecycle control. This involves implementing the Instance Control API specification (9 endpoints under `/control/v1`) and adding a "Managed Pool Adoption" toggle in the settings page. When enabled, the instance generates credentials and an adoption URL that the owner pastes into the InstClaw admin dashboard to complete adoption. Once adopted, InstClaw manages the instance lifecycle -- allocating users, enforcing billing (suspend on zero balance, resume on top-up), and monitoring health.

This is an opt-in capability that does not affect existing standalone functionality. The Control API is a separate route namespace (`/control/v1`) distinct from the existing `/api/openclaw` routes.

## Analysis & Conflict Review

### Architecture Decision: Separate Route Namespace

The Control API lives at `/control/v1/*` -- entirely outside the existing `/api/openclaw/*` namespace. This is intentional:
- **Different auth mechanism**: Control API uses `X-Control-Key` header auth, not the launcher's JWT-based `launcherAuth` middleware (Goal 009)
- **Different consumers**: Called by InstClaw backend, not by the launcher frontend
- **Different response envelope**: `{ success, data, error }` vs the launcher's `{ error, message }` pattern

This means the Control API routes must be mounted separately in `server.js`, bypassing `launcherAuth` but using their own `X-Control-Key` validation middleware.

### Overlap with Existing Goals

| Goal | Overlap | Resolution |
|------|---------|------------|
| **009 (Launcher Login)** | New `/control/v1` routes must NOT use `launcherAuth` middleware | Mount `/control/v1` routes separately in `server.js` with own auth middleware |
| **006 (Credential Alignment)** | Managed pool may push config changes (aiModel, botToken via `/configure`) that touch `openclaw.json` and `auth-profiles.json` | Reuse `openclaw-config.js` service for config reads/writes; follow `auth-profiles.json` pattern for credential storage |
| **008 (Token Security)** | Control API key generation parallels gateway token generation | Reuse `crypto.randomBytes()` pattern from Goal 008; store control key in `openclaw.json` under `managedPool` section |
| **010 (Health Page)** | Instance status/health exposed via Control API should align with health service data | Reuse `pm2Health` service for status endpoint; consider adding a "Managed Pool" health card |
| **007 (Gateway Proxy)** | Control API restart/reset actions interact with the gateway PM2 process | Reuse PM2 restart patterns from gateway proxy service |
| **004 (Adaptive UI)** | Managed pool state (adopted, suspended) may affect UI behavior | `isConfigured` definition unchanged; managed pool is an overlay, not a prerequisite |

### No Conflicts Identified

The Control API is additive -- no existing routes, services, or UI components need modification for the base implementation. Overlaps are resolved by reusing existing services and mounting routes in a separate namespace.

## Tasks

### Backend: Control API Service & State Machine

- [x] Task 1: Create `src/services/instance-control.js` service with instance state machine (`AVAILABLE` -> `PROVISIONING` -> `ACTIVE` -> `SUSPENDED` -> `TERMINATED`) and state transition validation
- [x] Task 2: Add `managedPool` section to `openclaw.json` schema (fields: `enabled`, `controlKey`, `adoptionToken`, `instanceId`, `status`, `adoptedAt`, `tier`, `userId`, `suspendReason`). Implement read/write via `openclaw-config.js`
- [x] Task 3: Implement `X-Control-Key` authentication middleware in `src/middleware/control-auth.js` -- validate header against stored control key with timing-safe comparison, return 401 on mismatch
- [x] Task 4: Create `src/routes/control.js` with all 9 Control API endpoints:
  - `POST /control/v1/allocate` -- provision instance for a user (set botToken, aiModel, userId; transition to PROVISIONING then ACTIVE)
  - `PUT /control/v1/instances/:id/configure` -- update running config (aiModel, botToken, pairKey, freeQuota) without downtime
  - `POST /control/v1/instances/:id/suspend` -- pause instance with reason (user_initiated, zero_balance, admin)
  - `POST /control/v1/instances/:id/resume` -- reactivate suspended instance with reason
  - `POST /control/v1/instances/:id/restart` -- soft restart via PM2 (recycle process, preserve config)
  - `POST /control/v1/instances/:id/reset` -- hard reset (wipe conversation history/caches, preserve config; requires `confirm: true`)
  - `POST /control/v1/instances/:id/resize` -- change resource tier (basic, standard, premium)
  - `GET /control/v1/instances/:id/status` -- query health, uptime, model, last activity
  - `POST /control/v1/instances/:id/terminate` -- permanent shutdown, transition to TERMINATED
- [x] Task 5: Implement instance ID validation middleware -- verify `:id` path parameter matches this instance's `instanceId` from config, return 404 on mismatch
- [x] Task 6: Implement response envelope (`{ success, data, error }`) and error codes (`INVALID_PARAMETERS`, `UNAUTHORIZED`, `INSTANCE_NOT_FOUND`, `INVALID_STATE`, `NO_CAPACITY`, `ALREADY_ALLOCATED`, `UNSUPPORTED_MODEL`, `SAME_TIER`, `INSTANCE_UNAVAILABLE`) per spec
- [x] Task 7: Mount `/control/v1` routes in `server.js` with control-auth middleware, separate from `/api/openclaw` routes

### Backend: Adoption Flow

- [x] Task 8: Implement adoption key generation -- `crypto.randomBytes(32)` for control API key, `crypto.randomBytes(24)` for one-time adoption token. Store in `managedPool` config section
- [x] Task 9: Implement adoption token validation and consumption -- on first successful status check from InstClaw with valid adoption token, mark token as consumed, set `poolStatus: AVAILABLE`
- [x] Task 10: Implement adoption revocation -- when managed pool is disabled, clear control key, adoption token, and managed pool config. Reject all subsequent Control API requests

### Backend: Endpoint Business Logic

- [x] Task 11: Implement `/allocate` -- write botToken and aiModel to `openclaw.json` and `auth-profiles.json` (following Goal 006 credential storage pattern), restart gateway via PM2, transition state to PROVISIONING then ACTIVE
- [x] Task 12: Implement `/configure` -- partial config update (only provided fields), write to config, reload gateway if botToken or aiModel changed
- [x] Task 13: Implement `/suspend` and `/resume` -- stop/start the `openclaw-gateway` PM2 process, record reason and timestamp
- [x] Task 14: Implement `/restart` -- PM2 restart of `openclaw-gateway` process (reuse existing restart logic from health routes)
- [x] Task 15: Implement `/reset` -- clear conversation history and runtime caches from `~/.openclaw/workspace` (preserve config files), restart gateway
- [x] Task 16: Implement `/resize` -- store tier in config (actual resource adjustment is informational for this single-instance deployment)
- [x] Task 17: Implement `/status` -- aggregate data from `pm2Health` service (uptime, process status), config (aiModel), and gateway probe (health/lastActivity)
- [x] Task 18: Implement `/terminate` -- stop gateway PM2 process, set state to TERMINATED, disable managed pool

### Frontend: Settings Page Integration

- [x] Task 19: Add "Managed Pool" tab to `SettingsTabs.jsx` (after "Health" tab) with route `/setup/managed-pool`
- [x] Task 20: Create `src/frontend/pages/setup/ManagedPool.jsx` component with:
  - Toggle switch for "Managed Pool Adoption" (disabled by default)
  - When enabled: display generated control API key (masked, with copy button) and adoption URL
  - Adoption URL format: `instclaw-adopt://<instance-host>/control/v1?token=<adoption-token>&key=<control-api-key>`
  - Status indicator showing current managed pool state (not adopted, available, active, suspended, terminated)
  - "Revoke Adoption" button to disable and clear credentials
  - Warning text explaining that enabling this allows external lifecycle management
- [x] Task 21: Add API integration endpoints in frontend:
  - `POST /api/openclaw/managed-pool/enable` -- generate keys, enable managed pool
  - `POST /api/openclaw/managed-pool/disable` -- revoke adoption, clear keys
  - `GET /api/openclaw/managed-pool/status` -- get current managed pool state and adoption info
- [x] Task 22: Add these launcher-facing managed pool endpoints to `src/routes/openclaw.js` (protected by existing `launcherAuth`)

### Health & Monitoring Integration

- [x] Task 23: Add managed pool status to the `/health` endpoint response -- include `managedPool: { enabled, status, adoptedAt }` in health summary
- [x] Task 24: Optionally add a "Managed Pool" health card to the Health Dashboard showing adoption status, current state, and last InstClaw communication timestamp

### Security Considerations

- [x] Task 25: Ensure control API key is masked in all config responses (extend `sanitizeConfig()`)
- [x] Task 26: Ensure adoption token is single-use and cleared after successful adoption
- [x] Task 27: Validate all Control API request bodies against expected schemas (reject unknown fields, enforce required fields, validate enum values for reason/tier)
- [x] Task 28: Add rate limiting to Control API endpoints (separate from launcher auth rate limiting)
- [x] Task 29: Log all Control API requests with `X-Request-Id` header for audit trail

## Acceptance Criteria

- All 9 Control API endpoints respond correctly per the Instance Control API specification
- `X-Control-Key` authentication rejects invalid/missing keys with 401
- State machine enforces valid transitions (e.g., cannot suspend an already-suspended instance -> 409)
- Response envelope matches spec format: `{ success: boolean, data: object|null, error: { code, message }|null }`
- "Managed Pool Adoption" toggle in settings is disabled by default
- Enabling adoption generates a control key and adoption token, displays copyable adoption URL
- Disabling adoption revokes all credentials and rejects future Control API requests
- Adoption token is single-use (consumed on first valid status check)
- Control API key and adoption token are masked in all frontend-facing config responses
- `/allocate` correctly writes credentials to both `openclaw.json` and `auth-profiles.json`
- `/suspend` stops the gateway PM2 process; `/resume` restarts it
- `/restart` recycles the gateway process without config changes
- `/status` returns accurate health, uptime, model, and activity data
- `/terminate` permanently stops the gateway and sets state to TERMINATED
- Control API routes are NOT protected by `launcherAuth` (they use their own `X-Control-Key` auth)
- Launcher-facing managed pool routes (`/api/openclaw/managed-pool/*`) ARE protected by `launcherAuth`
- All Control API requests are logged with request ID for auditing

## Progress

- Status: **Complete**
- Start Date: 2026-02-14
- Completion Date: 2026-02-14
- Notes:
  - All 29 tasks implemented in a single iteration
  - **New files created:**
    - `src/services/instance-control.js` — State machine, adoption logic, config management, response envelope helpers
    - `src/middleware/control-auth.js` — X-Control-Key header auth with timing-safe comparison, rate limiting (60 req/min), request ID logging
    - `src/routes/control.js` — All 9 Control API endpoints with full business logic, input validation, state transition enforcement
    - `src/frontend/pages/setup/ManagedPool.jsx` — Settings tab UI with enable/disable toggle, adoption URL display, status indicators
  - **Modified files:**
    - `server.js` — Mounted `/control/v1` routes with `controlAuth` middleware (separate from `launcherAuth`)
    - `src/routes/openclaw.js` — Added 3 launcher-facing managed pool endpoints (`enable`, `disable`, `status`) and managed pool data to health/batch endpoints
    - `src/services/openclaw-config.js` — Extended `sanitizeConfig()` to mask `managedPool.controlKey`, `adoptionToken`, `pairKey`
    - `src/frontend/App.jsx` — Added `/setup/managed-pool` route
    - `src/frontend/components/SettingsTabs.jsx` — Added "Managed Pool" tab after "Health"
  - Server auto-restarted via nodemon and is running without errors
  - Frontend build succeeds

## Dependencies

- **Goal 001 (Setup Wizard Backend)**: Reuses `openclaw-config.js` for config management, `pm2-health.js` for process monitoring
- **Goal 006 (Credential Alignment)**: Must follow `auth-profiles.json` pattern when `/allocate` or `/configure` writes credentials
- **Goal 008 (Token Security)**: Follows same `crypto.randomBytes()` pattern for key generation
- **Goal 009 (Launcher Login)**: Launcher-facing endpoints inherit `launcherAuth`; Control API endpoints are explicitly excluded
- **Goal 010 (Health Page)**: Health card integration for managed pool status display
- **External**: InstClaw Instance Control API specification (https://instclaw-c04dd2.404000000.xyz/instanceapi_llms.txt)

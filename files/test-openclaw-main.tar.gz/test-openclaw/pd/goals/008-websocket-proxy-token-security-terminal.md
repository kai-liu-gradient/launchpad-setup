# Goal: WebSocket Proxy Hardening, Gateway Token Security & Web Terminal Fixes

## Objective

Strengthen three interconnected areas of the OpenClaw Launcher that are currently incomplete or insecure:

1. **WebSocket proxy support** — The reverse proxy for the gateway Control UI (Goal #007) needs robust WebSocket handling. The gateway's UI uses a WebSocket-based protocol for all real-time features (chat, streaming, live updates, device pairing). While the basic `http-proxy-middleware` WebSocket proxy is wired up, it lacks proper error recovery, connection lifecycle management, and the Control UI iframe may have issues with WebSocket URL resolution when served through the proxy path (`/gateway/`).

2. **Gateway token security** — The gateway auth token is currently a hardcoded `"dummy"` string in `~/.openclaw/openclaw.json`, and the config init function (`createDefaultConfig()` in `openclaw-config.js`) defaults to `"change-me"`. OpenClaw's own onboarding uses `crypto.randomBytes(24).toString("hex")` for token generation (see `~/openclaw/src/commands/onboard-helpers.ts:68-70`). The launcher must generate cryptographically strong tokens and provide a UI for token management.

3. **Web terminal (TUI)** — The browser-based terminal (Shell.jsx + webshell.js) appears functionally complete but has reported issues that need investigation and fixing. Potential problems include: WebSocket connection failures through the Vite dev proxy, missing reconnection without full page reload, no ping/pong keepalive, and no authentication on the terminal WebSocket endpoint. ANSI color rendering is properly configured (xterm-256color PTY + xterm.js theme) but needs end-to-end testing.

## Context from OpenClaw Source

### Gateway WebSocket Protocol
- The gateway uses `ws` with `noServer: true` and handles upgrades on the root path (`/`)
- The Control UI connects via `new WebSocket(url)` at the root, then sends a `connect` method with auth token/device identity
- Authentication is done at the application layer (WebSocket `connect` frame), not at HTTP upgrade level
- Source: `~/openclaw/ui/src/ui/gateway.ts`, `~/openclaw/src/gateway/server-http.ts`

### Gateway Token Generation Pattern
- `crypto.randomBytes(24).toString("hex")` produces a 48-char hex token (192 bits of entropy)
- Source: `~/openclaw/src/commands/onboard-helpers.ts:68-70` (`randomToken()` function)
- Token is compared using `crypto.timingSafeEqual` in `~/openclaw/src/gateway/auth.ts`
- Token sources: config `gateway.auth.token` > env `OPENCLAW_GATEWAY_TOKEN` > env `CLAWDBOT_GATEWAY_TOKEN`

### Control UI WebSocket URL Construction
- The Control UI constructs its WebSocket URL from the page's current URL
- When served via iframe at `/gateway/`, the WebSocket URL may resolve differently than when served directly at the gateway root
- The gateway's WebSocket listener is at the root path — the proxy must rewrite `/gateway` to `/` for both HTTP and WebSocket

## Tasks

**Phase 1: Gateway Token Security**

- [x] Task 1: Add a `generateSecureToken()` function to `src/services/openclaw-config.js` using `crypto.randomBytes(24).toString('hex')` — matching OpenClaw's `randomToken()` pattern (48-char hex string, 192 bits entropy)
- [x] Task 2: Update `createDefaultConfig()` in `src/services/openclaw-config.js` to call `generateSecureToken()` instead of hardcoding `'change-me'` for `gateway.auth.token`
- [x] Task 3: Add a `POST /api/openclaw/config/regenerate-token` endpoint in `src/routes/openclaw.js` that generates a new token, writes it to `openclaw.json`, and returns a success response (with the new token masked in the response, but available for a one-time display)
- [x] Task 4: Add a token management section to the Config step in the setup wizard (`src/frontend/pages/setup/Config.jsx`) — show current token status (configured/default/weak), provide a "Generate Secure Token" button, and display the generated token once for the user to copy (with a copy-to-clipboard button)
- [x] Task 5: Add a token strength check in the health/doctor endpoint — flag tokens shorter than 32 characters or matching known weak values (`"dummy"`, `"change-me"`, `"test"`, `"token"`) as a warning
- [x] Task 6: Fix the existing live config — migrate the current `"dummy"` token to a cryptographically generated one (this can be done as part of a "doctor fix" action or prompted during the setup wizard)

**Phase 2: WebSocket Proxy Hardening**

- [x] Task 7: Verify and fix WebSocket upgrade handling in the gateway proxy — ensure `gatewayProxy.upgrade(req, socket, head)` correctly rewrites the path from `/gateway` to `/` before forwarding to the gateway (currently `pathRewrite` may only apply to HTTP requests, not WebSocket upgrades)
- [x] Task 8: Add WebSocket-specific error handling in the proxy — handle `ECONNREFUSED` and `ECONNRESET` on WebSocket upgrade gracefully (write a proper HTTP 502 response to the socket instead of letting it hang)
- [x] Task 9: Test the Control UI iframe WebSocket connectivity end-to-end — verify that when the Control UI is loaded at `/gateway/` in the iframe, its WebSocket connection correctly routes through `ws://host/gateway/` and gets proxied to `ws://127.0.0.1:18789/` (the gateway root)
- [x] Task 10: Add WebSocket connection logging — log WebSocket upgrade attempts and success/failure for both the shell and gateway proxy paths (at debug level to avoid noise)
- [x] Task 11: Add a proxy health check that verifies not just HTTP reachability (existing `GET /api/openclaw/health/gateway`) but also WebSocket upgrade capability to the gateway — this can be a quick upgrade-then-close test

**Phase 3: Web Terminal Fixes & Testing**

- [x] Task 12: Investigate and fix the reported terminal access issue — test the full connection flow: browser opens `ws://host/api/openclaw/shell/ws` -> server `upgrade` handler routes to `shellWss` -> PTY spawns -> data flows bidirectionally. Check PM2/nodemon logs for errors during this flow.
- [x] Task 13: Implement proper WebSocket reconnection in `Shell.jsx` — replace the `window.location.reload()` hack with a clean reconnect that tears down the old xterm instance, creates a new WebSocket connection, and re-attaches to a fresh PTY session without losing the terminal container
- [x] Task 14: Add WebSocket ping/pong keepalive to the shell WebSocket server — send periodic pings (every 30s) and terminate connections that fail to respond within a timeout (10s). This prevents stale connections from consuming PTY session slots.
- [x] Task 15: Add basic connection feedback to the terminal — show a "Connecting..." message in the terminal emulator when the WebSocket is opening, and a clear error message if the connection fails (e.g., "Failed to connect to terminal server. Is the launcher running?")
- [x] Task 16: Test ANSI color rendering end-to-end — run `ls --color=auto`, `htop` (if available), and custom ANSI escape sequences through the terminal to verify 256-color and cursor control work correctly through the WebSocket JSON protocol
- [x] Task 17: Add terminal authentication — require a session token or validate that the request originates from the same launcher session (e.g., check for a valid session cookie or generate a short-lived terminal access token) to prevent unauthorized PTY access if the launcher is exposed beyond localhost

**Phase 4: Integration Testing**

- [x] Task 18: Create a test script (`tests/websocket-proxy-test.js`) that verifies the gateway WebSocket proxy by opening a WebSocket to `ws://localhost:3000/gateway/` and checking that the gateway's challenge-response protocol initiates correctly
- [x] Task 19: Create a test script (`tests/webshell-test.js`) that verifies the terminal WebSocket by opening a connection to `ws://localhost:3000/api/openclaw/shell/ws`, sending an input command, and verifying output is received
- [x] Task 20: Rebuild frontend with `npm run build:frontend` and verify all pages (Control UI iframe, Terminal, Health dashboard) render correctly with the changes

## Acceptance Criteria

- Gateway auth token is generated using `crypto.randomBytes(24).toString('hex')` (192-bit entropy) — never defaults to a guessable string
- The setup wizard UI shows token status and allows one-click secure token generation with copy-to-clipboard
- The health/doctor system flags weak or default tokens as warnings
- WebSocket connections through the `/gateway/` reverse proxy work correctly — the Control UI's real-time chat, streaming, and live updates function when accessed through the launcher
- WebSocket upgrade errors are handled gracefully (502 response, not hung connections)
- The web terminal connects reliably, handles disconnection with clean reconnect (no full page reload), and includes ping/pong keepalive
- ANSI colors render correctly in the terminal (256-color support via xterm-256color)
- The terminal WebSocket has basic authentication to prevent unauthorized access
- Integration test scripts verify both WebSocket paths (gateway proxy and shell) are functional
- All existing launcher functionality continues to work without regression

## Progress

- Status: **Complete**
- Start Date: 2026-02-11
- Completion Date: 2026-02-11
- Notes:
  - **Phase 1 (Token Security)**: Implemented `generateSecureToken()` using `crypto.randomBytes(24).toString('hex')` (192-bit entropy, 48-char hex). Updated `createDefaultConfig()` to use it. Added `POST /api/openclaw/config/regenerate-token` endpoint, `GET /api/openclaw/config/token-status` endpoint, token strength checker (`checkTokenStrength()`), and token management UI in Config.jsx with strength indicator and one-time copy display. Health endpoint now includes `security.token` section. The live "dummy" token was migrated to a secure token via the regenerate endpoint.
  - **Phase 2 (WebSocket Proxy)**: Added `proxyReqWs` handler for WebSocket upgrade logging, enhanced error handler to properly write HTTP 502 to raw sockets on WebSocket upgrade failures, added `probeGatewayWebSocket()` function and `GET /api/openclaw/health/gateway/ws` endpoint, and added WebSocket upgrade logging in `server.js` for both shell and gateway paths.
  - **Phase 3 (Web Terminal)**: Rewrote `Shell.jsx` with clean reconnection (disposes old xterm, creates new WebSocket, no page reload), added "Connecting..." and error feedback messages in the terminal, added ping/pong keepalive (30s interval, 10s timeout) to shell WebSocket server, and implemented session-scoped terminal authentication via `SHELL_ACCESS_TOKEN` (generated at server startup, fetched by frontend, validated on WebSocket upgrade).
  - **Phase 4 (Integration Testing)**: Created `tests/websocket-proxy-test.js` (HTTP proxy, WebSocket upgrade, WS health endpoint) and `tests/webshell-test.js` (token fetch, auth rejection, authenticated session with command execution). Frontend rebuilt successfully with Vite.
  - All endpoints verified working: token-status, regenerate-token, shell/token, health/gateway/ws.

## Dependencies

- **Goal #007** (Complete): Gateway Control UI Reverse Proxy & Web Shell Integration — provides the proxy, WebSocket, and terminal infrastructure being hardened
- **Goal #001** (Complete): Backend service infrastructure — config management and health endpoints being extended
- **Goal #002** (Complete): React SPA frontend — UI pages being updated (Config.jsx, Shell.jsx)
- **Goal #004** (Complete): Adaptive UI mode — doctor/health integration
- **External**: OpenClaw gateway must be running for WebSocket proxy testing
- **External**: `node-pty` native module must be compiled for terminal functionality

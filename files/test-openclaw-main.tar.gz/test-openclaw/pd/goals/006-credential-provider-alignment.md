# Goal: Align Credential Provider Setup with OpenClaw Auth Architecture

## Objective
Overhaul the launcher's credential detection and provider setup to match how OpenClaw actually handles authentication. The current implementation has several misalignments discovered by cross-referencing the OpenClaw source (`~/openclaw`):

1. **Claude OAuth is presented as a selectable provider** — but OpenClaw's own onboarding does NOT expose raw OAuth import for Anthropic. It uses `setup-token` (stored as `type: "token"`) or `api-key`. The OAuth credentials in `~/.claude/.credentials.json` are Claude CLI's own tokens, not intended for third-party gateway use. Anthropic could restrict this at any time.
2. **The `claude-oauth` apply route writes `auth: 'oauth'`** — but OpenClaw's auth profile system expects OAuth credentials to live in `auth-profiles.json` with refresh token infrastructure (via pi-ai library). Our launcher doesn't write to `auth-profiles.json` at all, making the `oauth` mode non-functional.
3. **The `claude-oauth` provider sets `baseUrl` to `https://api.anthropic.com/v1/messages`** — but OpenClaw's `ModelProviderConfig.baseUrl` should be the base (e.g., `https://api.anthropic.com/v1`), with `/messages` appended by the API format handler.
4. **All manual providers hardcode `api: 'anthropic-messages'`** — incorrect for OpenAI, Google, OpenRouter, etc. (already tracked in Goal #005).
5. **Credentials (apiKey) are written directly into `openclaw.json` auth profiles** — but OpenClaw stores actual credentials in a separate `auth-profiles.json` file, not in the main config.

This goal focuses on making the credential flow **safe, correct, and aligned** with OpenClaw's actual architecture — specifically removing the problematic Claude OAuth auto-detection and replacing it with proper provider options.

## Context from OpenClaw Source

### Auth Modes (`~/openclaw/src/config/types.models.ts`)
```
ModelProviderAuthMode = "api-key" | "aws-sdk" | "oauth" | "token"
```

### Auth Profile Storage (`~/openclaw/src/agents/auth-profiles/types.ts`)
- `auth-profiles.json` — separate file storing actual credentials (keys, tokens, OAuth tokens)
- `openclaw.json` `auth.profiles` — only declares profile metadata (provider, mode, email), NOT secrets
- Profile ID format: `"provider:label"` (e.g., `"anthropic:default"`, `"zai:default"`)

### Anthropic Onboarding Choices (`~/openclaw/src/commands/auth-choice-options.ts`)
```
{ value: "anthropic", label: "Anthropic", hint: "setup-token + API key", choices: ["token", "apiKey"] }
```
- `"token"` / `"setup-token"` / `"oauth"` — all map to: paste a `claude setup-token`, stored as `type: "token"` (static, not refreshable)
- `"apiKey"` — paste an Anthropic API key from console.anthropic.com

### Credential Resolution Order (`~/openclaw/src/agents/model-auth.ts`)
1. Explicit profile ID
2. Auth override (e.g., `aws-sdk`)
3. Auth profile rotation (from `auth-profiles.json`)
4. Environment variable fallback (e.g., `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`)
5. Config `models.providers.<name>.apiKey` fallback

### External CLI Credential Sync (`~/openclaw/src/agents/auth-profiles/external-cli-sync.ts`)
- OpenClaw has its own sync mechanism that imports Claude CLI OAuth tokens at runtime
- The launcher should NOT duplicate this — let OpenClaw handle OAuth import itself

### Valid API Formats (`~/openclaw/src/config/types.models.ts`)
| Format | Providers |
|--------|-----------|
| `openai-completions` | OpenAI, OpenRouter, Together, Ollama, most compatible |
| `openai-responses` | OpenAI Responses API |
| `anthropic-messages` | Anthropic, Cloudflare AI Gateway |
| `google-generative-ai` | Google Gemini |
| `github-copilot` | GitHub Copilot |
| `bedrock-converse-stream` | AWS Bedrock |

## Tasks

**Phase 1: Remove Claude OAuth as Selectable Provider**

- [x] Task 1: Remove `detectClaudeOAuth()` from the `detectAllCredentials()` results in `src/services/credential-discovery.js` — stop presenting Claude CLI OAuth tokens as a selectable provider. Keep the function for reference but do not include it in detection results.
- [x] Task 2: Remove the `claude-oauth` branch from `POST /api/openclaw/credentials/apply` in `src/routes/openclaw.js` — this apply path writes an invalid config (OAuth mode without `auth-profiles.json` entry, wrong `baseUrl` with `/messages` suffix)
- [x] Task 3: Update the `POST /api/openclaw/credentials/apply` supported providers error message to reflect available auto-detected providers (currently says `"Supported: claude-oauth, zai"`)

**Phase 2: Add Anthropic Setup-Token and API Key as Proper Choices**

- [x] Task 4: Add Anthropic `setup-token` as a credential option — detect if `ANTHROPIC_OAUTH_TOKEN` env var is set or if a `claude setup-token` value could be provided manually. In the manual credential form, add guidance text: "For Anthropic, use an API key from console.anthropic.com or a setup-token from `claude setup-token`"
- [x] Task 5: When applying an Anthropic API key manually, write the provider config with `auth: 'api-key'`, `api: 'anthropic-messages'`, and `baseUrl: 'https://api.anthropic.com/v1'` (without `/messages` suffix — the API format handler appends it)
- [x] Task 6: When applying an Anthropic setup-token manually, write the auth profile with `mode: 'token'` (not `'oauth'`), matching OpenClaw's actual onboarding behavior

**Phase 3: Fix Auth Profile and Credential Storage**

- [x] Task 7: Stop writing `apiKey` directly into `openclaw.json` `auth.profiles` — the main config should only contain profile declarations (`{ provider, mode, email? }`), not secrets. Currently `POST /credentials/manual` writes `apiKey` into the auth profile object.
- [x] Task 8: Write actual credentials to `~/.openclaw/auth-profiles.json` following OpenClaw's `AuthProfileStore` schema: `{ version: 1, profiles: { "provider:default": { type: "api_key", provider: "...", key: "..." } } }`. Read existing file first and merge, don't overwrite.
- [x] Task 9: Set file permissions on `auth-profiles.json` to `0o600` (same as `openclaw.json`) since it contains secrets

**Phase 4: Fix Provider BaseUrl Format**

- [x] Task 10: Fix `baseUrl` for all providers to NOT include the API path suffix — `baseUrl` should be the root endpoint (e.g., `https://api.anthropic.com/v1` not `https://api.anthropic.com/v1/messages`). The API format handler (`anthropic-messages`, `openai-completions`, etc.) appends the correct path.
- [x] Task 11: Fix the ZAI apply route — currently strips `/messages` from the ZAI `api_base_url`, but should verify the resulting URL is a clean base URL

**Phase 5: Environment Variable Detection**

- [x] Task 12: Enhance `detectAllCredentials()` to scan for provider-specific environment variables matching OpenClaw's `resolveEnvApiKey()` pattern: `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, `GEMINI_API_KEY`, `OPENROUTER_API_KEY`, `XAI_API_KEY`, `GROQ_API_KEY`, `MISTRAL_API_KEY`, `TOGETHER_API_KEY`
- [x] Task 13: For each detected env var, return `{ provider, source: "env", envVar, available: true }` in the detection results — do NOT return the actual key value
- [x] Task 14: When applying an env-var-detected provider, write the provider config to `openclaw.json` with the correct `api` format and `baseUrl`, but do NOT copy the env var value into `auth-profiles.json` — OpenClaw's runtime will resolve it from the env var directly (this is resolution step #4 in the credential chain)

**Phase 6: Frontend Updates**

- [x] Task 15: Update `Credentials.jsx` to no longer show `claude-oauth` as a detected provider — it should show ZAI (if detected) and any env-var-detected providers
- [x] Task 16: In the manual credential form, add a note for Anthropic: "Use an API key from console.anthropic.com. Avoid using Claude CLI OAuth tokens directly — OpenClaw syncs those automatically at runtime."
- [x] Task 17: When an env-var provider is detected, show it with source label (e.g., "anthropic (env: ANTHROPIC_API_KEY)") and indicate that no manual key entry is needed — applying it just configures the provider routing in `openclaw.json`

**Phase 7: Build & Verify**

- [x] Task 18: Rebuild frontend with `npm run build:frontend` and verify the updated Credentials page renders correctly
- [x] Task 19: Test credential detection with current environment — verify ZAI is still detected, `claude-oauth` is no longer shown, and any available env vars are detected
- [x] Task 20: Test manual API key flow — apply a manual provider and verify `openclaw.json` has correct provider config (no apiKey in auth profiles) and `auth-profiles.json` has the credential
- [x] Task 21: Test env-var provider apply — verify `openclaw.json` gets correct provider config and NO credential is written to `auth-profiles.json`
- [x] Task 22: Verify the OpenClaw gateway can still resolve credentials after the changes — restart gateway and confirm it starts without auth errors

## Acceptance Criteria
- `claude-oauth` is no longer presented as a selectable credential provider in detection results
- Anthropic credentials are handled via `api-key` or `token` (setup-token) mode, not `oauth`
- API keys from manual entry are stored in `~/.openclaw/auth-profiles.json`, not in `openclaw.json`
- `openclaw.json` `auth.profiles` only contains profile declarations (provider, mode), not secrets
- `auth-profiles.json` follows OpenClaw's `AuthProfileStore` schema with `version: 1`
- Provider `baseUrl` values do not include API path suffixes (no `/messages`, no `/chat/completions`)
- Environment variable providers are detected and can be applied without copying the key
- The OpenClaw gateway can resolve credentials from `auth-profiles.json` and env vars after changes
- No regressions to ZAI auto-detection or the manual credential flow
- Existing wizard navigation (credentials -> telegram -> config -> complete) still works

## Progress
- Status: **Complete** (100% — All phases implemented and verified)
- Start Date: 2026-02-10
- Completion Date: 2026-02-10
- Notes:
  - Root cause analysis performed by cross-referencing OpenClaw source at `~/openclaw`
  - Key source files referenced: `src/config/types.models.ts`, `src/config/types.auth.ts`, `src/agents/auth-profiles/types.ts`, `src/commands/auth-choice-options.ts`, `src/commands/auth-choice.apply.anthropic.ts`, `src/agents/model-auth.ts`, `src/agents/auth-profiles/external-cli-sync.ts`, `src/agents/cli-credentials.ts`, `src/config/zod-schema.core.ts`
  - Goal #005 (manual API key provider presets) covers the frontend dropdown and `apiFormat` field — this goal can be implemented before or after #005, but the `api` format fix in Phase 2/Task 5 overlaps. Coordinate to avoid conflicts.
  - The `auth-profiles.json` write (Phase 3) is the most critical change — without it, any credentials written by the launcher are in the wrong file and may not be picked up by the gateway at runtime
  - Claude OAuth auto-import is handled by OpenClaw's own `external-cli-sync.ts` at runtime — the launcher does not need to replicate this
  - **Implementation notes (2026-02-10):**
    - `credential-discovery.js`: Removed claude-oauth from `detectAllCredentials()`, added `ENV_VAR_PROVIDERS` map for 8 provider env vars, added `detectEnvVarProviders()`, added `readAuthProfiles()`/`writeAuthProfiles()` for auth-profiles.json management
    - `openclaw.js` routes: Removed entire `claude-oauth` branch from `/credentials/apply`, added env-var provider apply path (writes provider config only, no credential copy), updated `/credentials/manual` to write secrets to `auth-profiles.json` (not `openclaw.json`), added `credentialType: 'setup-token'` support for token mode, enhanced baseUrl stripping to also handle `/chat/completions`
    - `Credentials.jsx`: Added Anthropic guidance note in manual form, added env-var provider display with source label and "no manual key needed" messaging, removed `subscriptionType` display (was only relevant for claude-oauth)
    - Frontend built successfully, backend server restarted clean, credential detection verified: ZAI detected, claude-oauth absent
  - **Verification notes (2026-02-10, Phase 7 completion):**
    - **Critical path fix**: `auth-profiles.json` was being written to `~/.openclaw/auth-profiles.json` but OpenClaw gateway expects it at `~/.openclaw/agents/main/agent/auth-profiles.json`. Fixed `AUTH_PROFILES_PATH` in `credential-discovery.js` to use correct `agents/main/agent/` subdirectory matching `resolveAuthStorePath()` in OpenClaw source.
    - **Data cleanup**: Removed stale `claude:oauth` profile and `claude-oauth` provider from existing `openclaw.json`. Migrated embedded `apiKey` values from `openai:default`/`google:default` auth profiles to `auth-profiles.json`.
    - **Task 20 verified**: Manual API key apply writes provider config (no secrets) to `openclaw.json` and credentials to `auth-profiles.json` at correct path. Setup-token variant correctly stores as `type: "token"`.
    - **Task 21 verified**: Env-var provider apply (tested with `OPENROUTER_API_KEY`) writes provider config to `openclaw.json` with correct `baseUrl`/`api`/`auth` — no credential written to `auth-profiles.json`.
    - **Task 22 verified**: Gateway restart shows zero auth/credential errors. Only error is pre-existing Telegram schema issue (`"token"`, `"botUsername"` unrecognized keys in Telegram account config — separate goal).
    - Schema confirmed against OpenClaw source: `AuthProfileStore { version: 1, profiles: Record<string, { type: "api_key" | "token" | "oauth", provider: string, key?: string, token?: string }> }` — our format matches.

## Dependencies
- Goal #001 (OpenClaw Launcher Setup Wizard Backend) — **Complete** — provides the routes and services being modified
- Goal #002 (OpenClaw Launcher React SPA Frontend) — **Complete** — provides the Credentials.jsx page being updated
- Goal #005 (Manual API Key Provider Presets) — **Not Started** — overlaps on `api` format fix for manual providers; coordinate to avoid conflicts
- OpenClaw source at `~/openclaw` — reference for auth architecture, schema types, and credential resolution
- OpenClaw gateway running via PM2 — needed for end-to-end verification (Task 22)

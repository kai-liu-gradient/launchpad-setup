# Goal: OpenClaw Launcher Setup Wizard & Health Dashboard Backend

## Objective
Build the backend services and API endpoints for the OpenClaw Launcher — a guided setup wizard and operational dashboard that simplifies OpenClaw onboarding and ongoing management. The launcher reuses credentials from the existing Claude (`~/.claude`) and ZAI/claude-code-router (`~/.claude-code-router`) environments, guides Telegram bot configuration, initializes `openclaw.json`, and provides real-time health monitoring of the OpenClaw gateway daemon (PM2 process). This goal handles all backend logic, API routes, and configuration management; the frontend SPA is covered in Goal #002.

## Tasks

### Credential Discovery & Reuse
- [x] Task 1: Create a `src/services/credential-discovery.js` module that reads and parses `~/.claude/.credentials.json` (Claude OAuth tokens) and `~/.claude-code-router/config.json` (ZAI provider endpoint, model list, base URL)
- [x] Task 2: Implement an endpoint `GET /api/openclaw/credentials/detect` that returns available credential sources (Claude OAuth, ZAI/GLM) without exposing raw secrets — return provider names, model lists, base URLs, and token validity status only
- [x] Task 3: Implement `POST /api/openclaw/credentials/apply` that writes selected provider config into `~/.openclaw/openclaw.json` under `models.providers`, mapping Claude OAuth or ZAI credentials to OpenClaw's expected format (referencing `src/agents/models-config.ts` and `src/agents/auth-profiles.ts` patterns from openclaw source)
### Telegram Bot Configuration Guide
- [x] Task 4: Create a `src/services/telegram-setup.js` module that validates a Telegram bot token via the Telegram Bot API (`getMe` endpoint) and returns bot info (username, display name, can_join_groups, etc.)
- [x] Task 5: Implement `POST /api/openclaw/telegram/validate` that accepts a bot token, validates it, and returns the bot metadata
- [x] Task 6: Implement `POST /api/openclaw/telegram/configure` that writes the validated token into `~/.openclaw/openclaw.json` under `channels.telegram.accounts.default` with sensible defaults (dmPolicy: "pairing", streamMode: "partial", historyLimit: 20)
- [x] Task 7: Implement `GET /api/openclaw/telegram/pairing-status` that checks the current Telegram channel status from the running gateway (via gateway API on port 18789 or config file)
### OpenClaw Configuration Initialization
- [x] Task 8: Create a `src/services/openclaw-config.js` module that reads/writes/validates `~/.openclaw/openclaw.json`, with schema validation against the expected format (gateway, agents, channels, models sections)
- [x] Task 9: Implement `GET /api/openclaw/config` that returns the current sanitized openclaw.json (tokens masked)
- [x] Task 10: Implement `POST /api/openclaw/config/init` that creates a fresh `~/.openclaw/openclaw.json` with sensible defaults (gateway port 18789, loopback bind, workspace at `~/.openclaw/workspace`, detected model provider)
- [x] Task 11: Implement `PATCH /api/openclaw/config` that allows partial updates to specific config sections (models, gateway, agents.defaults)
### Health Status & PM2 Monitoring
- [x] Task 12: Create a `src/services/pm2-health.js` module that shells out to `pm2 jlist` to get structured JSON status of all processes, with special focus on `openclaw-gateway`
- [x] Task 13: Implement `GET /api/openclaw/health` that returns comprehensive health data: PM2 process status (pid, uptime, memory, cpu, restart count), gateway port reachability (18789), config file existence, workspace directory status
- [x] Task 14: Implement `GET /api/openclaw/health/gateway` that probes the OpenClaw gateway WebSocket/HTTP endpoint on port 18789 for live status
- [x] Task 15: Implement `POST /api/openclaw/gateway/restart` that restarts the `openclaw-gateway` PM2 process and returns new status
### Workspace Content Browser
- [x] Task 16: Create a `src/services/workspace-browser.js` module that safely reads the `~/.openclaw/workspace` directory tree (with depth limit and file size guards)
- [x] Task 17: Implement `GET /api/openclaw/workspace/tree` that returns a directory tree of `~/.openclaw/workspace` (folders, files, sizes, modification dates)
- [x] Task 18: Implement `GET /api/openclaw/workspace/file?path=<relative>` that reads and returns a file from the workspace with markdown rendering support for `.md` files (sanitized to prevent path traversal outside workspace root)
### Express Route Organization
- [x] Task 19: Create `src/routes/openclaw.js` as an Express Router mounting all `/api/openclaw/*` endpoints, imported into `server.js`
- [x] Task 20: Add basic input validation middleware and error handling for all new endpoints

## Acceptance Criteria
- `GET /api/openclaw/credentials/detect` correctly identifies Claude OAuth and ZAI credentials from the environment
- Telegram bot token validation works against the live Telegram API
- `POST /api/openclaw/config/init` produces a valid `openclaw.json` that the real OpenClaw gateway can consume
- Health endpoint returns accurate PM2 process data for `openclaw-gateway` (status, uptime, memory, pid)
- Gateway health probe confirms whether port 18789 is responding
- Workspace browser lists files from `~/.openclaw/workspace` without allowing path traversal
- Markdown files from workspace are returned with raw content for frontend rendering
- All endpoints return proper JSON responses with consistent error format
- No raw secrets/tokens are exposed in any API response

## Progress
- Status: **Complete**
- Start Date: 2026-02-10
- Completion Date: 2026-02-10
- Completion: 100% (20/20 tasks)
- Notes:
  - All 20 tasks implemented in a single iteration
  - Created modular directory structure: `src/services/`, `src/routes/`, `src/middleware/`
  - **Services created:**
    - `src/services/credential-discovery.js` — reads Claude OAuth and ZAI/GLM credentials, returns sanitized detection info
    - `src/services/telegram-setup.js` — validates bot tokens via Telegram Bot API `getMe`, builds channel config
    - `src/services/openclaw-config.js` — CRUD for `~/.openclaw/openclaw.json` with schema validation, sanitization, and deep merge
    - `src/services/pm2-health.js` — shells out to `pm2 jlist`, probes gateway HTTP on port 18789, supports restart
    - `src/services/workspace-browser.js` — directory tree with depth/size limits, path traversal protection
  - **Route & middleware:**
    - `src/routes/openclaw.js` — Express Router mounting all `/api/openclaw/*` endpoints
    - `src/middleware/validation.js` — JSON body validation and API error handler
  - **server.js** updated to mount OpenClaw routes and error handler
  - All endpoints verified working via curl:
    - Credential detection finds Claude OAuth (max subscription, valid token) and ZAI (glm-4.7, glm-4.5-air)
    - Config returns sanitized data with tokens masked as `***masked***`
    - Health shows PM2 processes (openclaw-gateway online, pid, uptime, memory) and gateway port 18789 reachable
    - Workspace tree lists files from `~/.openclaw/workspace`
    - File reader returns markdown content with `isMarkdown` flag
    - Path traversal (`../../etc/passwd`) correctly blocked
  - Config schema patterns referenced from `~/openclaw/src/config/types.openclaw.ts`, `types.models.ts`, `types.auth.ts`

## Dependencies
- Goal #002 (OpenClaw Launcher React SPA Frontend) — consumes these API endpoints
- OpenClaw source at `~/openclaw` — reference for config schema and gateway API patterns
- PM2 runtime — must be available for health monitoring
- Telegram Bot API — external dependency for token validation
- Existing Express server at `/workspace/server.js` — mount point for new routes

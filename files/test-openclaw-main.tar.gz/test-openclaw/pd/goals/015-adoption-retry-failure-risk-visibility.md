# Goal: Adoption Retry Failure Tracking & Risk Visibility

## Objective

Add visibility into failed adoption and Control API request attempts so the user can see when things are going wrong. Currently, the adoption flow is "happy path only" — when InstClaw repeatedly polls `/control/v1/instances/:id/status` with an invalid or expired token, or when any Control API request fails, there is zero feedback to the user. The frontend shows a static "Awaiting adoption" state with no indication of problems.

This goal adds backend failure tracking (attempt counts, last error, timestamps) and frontend risk information display so the user understands when adoption is stalled, when requests are being rejected, and what's going wrong.

Builds on completed Goals 013 (InstClaw Managed Pool Adoption) and 014 (Adoption State Guard).

## Analysis & Conflict Review

### Overlap with Existing Goals

| Goal | Overlap | Resolution |
|------|---------|------------|
| **013 (Managed Pool Adoption)** | Extends the `managedPool` config schema with failure tracking fields | Additive — no changes to existing Control API contract |
| **014 (Adoption State Guard)** | Builds on `isAdopted` state and `consumeAdoptionToken()` guards | Additive — failure tracking wraps around existing guard logic |
| **010 (Health Page)** | Could display adoption failure risk info in health card | Reuse the managed pool health card added in Goal 013; extend with failure summary |

### No Conflicts Identified

All changes are additive. The Control API response format and authentication are unchanged. Failure tracking is internal bookkeeping that does not affect the external API contract with InstClaw.

## Tasks

### Backend: Failure Tracking State

- [x] Task 1: Add failure tracking fields to the `managedPool` config section in `src/services/instance-control.js`:
  - `failedAttempts` (number) — count of consecutive failed or rejected Control API requests
  - `lastFailure` (object|null) — `{ timestamp, endpoint, errorCode, errorMessage }` — details of the most recent failure
  - `failureLog` (array, max 20 entries) — rolling log of recent failures for diagnostic display, each entry: `{ timestamp, endpoint, errorCode, errorMessage }`
  - Initialize all to defaults (`0`, `null`, `[]`) in `enableAdoption()` and `resetAdoption()`

- [x] Task 2: Create a `recordFailure(endpoint, errorCode, errorMessage)` function in `src/services/instance-control.js` that:
  - Increments `failedAttempts`
  - Sets `lastFailure` with current timestamp and details
  - Appends to `failureLog` (cap at 20 entries, FIFO eviction)
  - Persists to `managedPool` config

- [x] Task 3: Create a `clearFailures()` function that resets `failedAttempts` to `0`, `lastFailure` to `null`, and `failureLog` to `[]`. Call this on any **successful** Control API request (successful adoption token consumption, successful allocate, etc.) to reset the counter when things recover.

### Backend: Failure Recording in Control API

- [x] Task 4: In `src/routes/control.js`, record failures in the following scenarios:
  - Invalid or expired adoption token on `/status` endpoint → `recordFailure('status', 'INVALID_TOKEN', 'Adoption token invalid or already consumed')`
  - Invalid state transition (409 responses) → `recordFailure(endpoint, 'INVALID_STATE', message)`
  - Allocation when not adopted (from Goal 014 guard) → `recordFailure('allocate', 'NOT_ADOPTED', 'Allocation rejected — adoption not complete')`
  - Any 400-level validation error on Control API endpoints → `recordFailure(endpoint, errorCode, message)`
  - Do NOT record 401 (auth failures) — those are external auth issues, not adoption problems

- [x] Task 5: In `src/routes/control.js`, call `clearFailures()` on successful adoption token consumption (in `/status`) and on successful `/allocate`.

### Backend: Expose Failure Info to Frontend

- [x] Task 6: Extend the `GET /api/openclaw/managed-pool/status` response in `src/routes/openclaw.js` to include failure tracking data:
  - `failedAttempts` (number)
  - `lastFailure` (object|null with timestamp, endpoint, errorCode, errorMessage)
  - `riskLevel` (string: `"none"` | `"low"` | `"medium"` | `"high"`) — derived from `failedAttempts`:
    - `none`: 0 failures
    - `low`: 1–3 failures
    - `medium`: 4–9 failures
    - `high`: 10+ failures

- [x] Task 7: Include `failureLog` in the status response only when `failedAttempts > 0` (avoid sending an empty array unnecessarily).

### Frontend: Risk Info Display

- [x] Task 8: In `ManagedPool.jsx`, add a risk information banner that appears when `failedAttempts > 0`. Style by risk level:
  - **Low** (1–3): Info-style banner (blue/gray) — "Some adoption requests have failed. This may resolve automatically."
  - **Medium** (4–9): Warning-style banner (yellow/amber) — "Multiple adoption requests are failing. Check your adoption URL and InstClaw connectivity."
  - **High** (10+): Error-style banner (red) — "Adoption requests are repeatedly failing. Review the failure log below or reset adoption."

- [x] Task 9: Display `lastFailure` details in the risk banner — show timestamp (relative, e.g., "2 minutes ago"), endpoint, and error message. Keep it concise but informative.

- [x] Task 10: Add a collapsible "Failure Log" section below the risk banner (visible when `failedAttempts > 0`) that shows the `failureLog` entries in reverse chronological order. Each entry displays: timestamp, endpoint, error code, and error message. Cap display at 20 entries (matching the backend cap).

- [x] Task 11: Add a "Clear Failures" button next to the risk banner that calls `clearFailures()` via a new `POST /api/openclaw/managed-pool/clear-failures` endpoint. This lets the user manually dismiss stale failure data.

- [x] Task 12: Add auto-refresh polling to the status fetch in `ManagedPool.jsx` — poll every 15 seconds when the page is visible and `enabled && !isAdopted` (waiting for adoption) so the user sees risk info update in near real-time. Stop polling once adopted or when the component unmounts.

### Backend: Clear Failures Endpoint

- [x] Task 13: Add `POST /api/openclaw/managed-pool/clear-failures` endpoint in `src/routes/openclaw.js` (protected by `launcherAuth`) that calls `clearFailures()` and returns `{ success: true }`.

### Health Integration

- [x] Task 14: Extend the managed pool health card data (added in Goal 013, Task 23/24) to include `failedAttempts` and `riskLevel` so the Health Dashboard also surfaces adoption risk at a glance.

## Acceptance Criteria

- Failed Control API requests (invalid tokens, invalid state transitions, allocation before adoption) increment `failedAttempts` and populate `lastFailure` and `failureLog`
- Successful adoption or allocation clears the failure counters
- `failureLog` caps at 20 entries with FIFO eviction
- Frontend displays a risk banner color-coded by severity (low/medium/high) when failures exist
- Risk banner shows the last failure's timestamp, endpoint, and error message
- Collapsible failure log displays all recent failures in reverse chronological order
- "Clear Failures" button resets failure tracking data
- Auto-refresh polling (15s) keeps risk info current while awaiting adoption
- Health card includes failure count and risk level
- 401 auth errors are NOT recorded as adoption failures (separate concern)
- Failure tracking fields are reset on adoption enable, adoption reset, and successful recovery
- All changes are additive — no modification to the Control API contract with InstClaw

## Progress

- Status: **Complete**
- Start Date: 2026-02-14
- Completion Date: 2026-02-14
- Notes:
  - All 14 tasks implemented in a single iteration
  - Backend: `FAILURE_DEFAULTS` constant, `recordFailure()`, `clearFailures()`, `getRiskLevel()` added to instance-control.js
  - Backend: Failure recording added to all Control API error responses (400/409) across allocate, configure, suspend, resume, restart, reset, resize, terminate, and status endpoints; 401 auth errors excluded per spec
  - Backend: `clearFailures()` called on successful token consumption and successful allocation
  - Backend: `getAdoptionInfo()` now includes `failedAttempts`, `lastFailure`, `riskLevel`, and conditionally `failureLog`
  - Backend: New `POST /api/openclaw/managed-pool/clear-failures` endpoint added
  - Backend: Health endpoint extended with `failedAttempts` and `riskLevel`
  - Frontend: Risk banner with 3-tier severity styling (low=blue, medium=amber, high=red), last failure details with relative timestamps
  - Frontend: Collapsible failure log showing entries in reverse chronological order
  - Frontend: "Clear" button to manually dismiss stale failure data
  - Frontend: 15-second auto-refresh polling when `enabled && !isAdopted`, respects `document.hidden` and cleans up on unmount
  - Failure tracking fields initialized in `enableAdoption()` and reset in `resetAdoption()`
  - All changes are additive — no modification to the Control API contract with InstClaw

## Dependencies

- **Goal 013 (InstClaw Managed Pool Adoption)**: Must be complete (it is). Extends `managedPool` config and Control API route handlers
- **Goal 014 (Adoption State Guard)**: Must be complete (it is). Failure recording wraps around existing guard logic (e.g., not-adopted rejection in `/allocate`)
- **Goal 009 (Launcher Login)**: New launcher endpoint (`clear-failures`) must be protected by `launcherAuth`
- **Goal 010 (Health Page)**: Health card extension for risk level display

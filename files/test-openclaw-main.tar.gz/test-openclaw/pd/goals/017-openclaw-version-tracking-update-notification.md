# Goal: OpenClaw Version Tracking, Persistence & Update Notification

## Objective

Record the currently installed OpenClaw gateway version to a persistent flag file so that the exact version can be restored after a project reset or reinstallation. Additionally, detect when a newer version is available and surface update notifications in the Health page and sidebar menu so the user is aware of pending updates. The actual reset-and-reinstall action is an external API (out of scope for this goal) — this goal focuses on version persistence, detection, comparison, and UI notification.

Currently, the codebase has zero version awareness: no code calls `openclaw --version`, the `update-check.json` file in `~/.openclaw/` is not wired into any backend or frontend logic, and the `meta.lastTouchedVersion` in `openclaw.json` is a static `'1.0.0'` placeholder. This goal closes that gap.

## Analysis & Conflict Review

### Overlap with Existing Goals

| Goal | Overlap | Resolution |
|------|---------|------------|
| **010 (Health Page)** | Complete. Version info and update notification should appear as a new check row or banner in an existing health card (e.g., Config Validation or a new "Version" card) | Additive — extends existing health card architecture; no modification to HealthCard component contract |
| **013 (InstClaw Managed Pool)** | Complete. InstClaw's `/control/v1/instances/:id/status` already reports health data; version info could be included in status response for remote monitoring | Additive — optionally extend status endpoint response |
| **007 (Gateway Proxy)** | Complete. The gateway itself may expose version info at its own endpoint; this goal reads version from the CLI, not the gateway HTTP API | No conflict — different data source |

### No Conflicts Identified

All changes are additive. No existing API contracts, services, or UI components need modification for the core implementation. The health page extension follows the existing per-section card pattern established in Goal 010.

### Key Discovery: `~/.openclaw/update-check.json` Already Exists

The file `~/.openclaw/update-check.json` already exists on disk with fields `lastCheckedAt`, `lastNotifiedVersion`, and `lastNotifiedTag`, but **no code in the codebase reads or writes it**. This goal will wire this file into the application, using it as the source for "latest available version" data. The OpenClaw CLI itself likely writes this file during its own update checks — we read it, not write it.

## Tasks

### Phase 1: Backend — Version Detection & Persistence

- [x] Task 1: Create a `src/services/version-tracker.js` service with the following functions:
  - `detectInstalledVersion()` — runs `openclaw --version` (or equivalent CLI command) via `execFileSync`, parses the output to extract the version string (e.g., `"2026.2.14"`), handles command not found or timeout errors gracefully
  - `readPersistedVersion()` — reads the persisted version from a flag file at `~/.openclaw/.installed-version` (plain text, just the version string)
  - `persistVersion(version)` — writes the version string to `~/.openclaw/.installed-version` with `0o600` permissions
  - `readUpdateCheck()` — reads and parses `~/.openclaw/update-check.json`, returns `{ lastCheckedAt, lastNotifiedVersion, lastNotifiedTag }` or `null` if file doesn't exist
  - `getVersionInfo()` — aggregates: `{ installedVersion, persistedVersion, latestVersion, latestTag, lastCheckedAt, updateAvailable }` where `updateAvailable` is `true` when `latestVersion` is newer than `installedVersion`

- [x] Task 2: Implement version comparison logic in `version-tracker.js`:
  - Handle the `YYYY.M.DD` version format used by OpenClaw (e.g., `2026.2.14`)
  - Compare by splitting on `.` and comparing each numeric segment
  - Also handle semver-style versions (e.g., `1.0.0`) as a fallback
  - `isNewerVersion(latest, current)` returns `true` if `latest` > `current`

- [x] Task 3: Auto-persist version on startup — in `server.js` (or called from the service initialization), detect the installed version and persist it to the flag file if:
  - The flag file doesn't exist yet (first run)
  - The detected version differs from the persisted version (upgrade detected)
  - Log version detection to console: `OpenClaw version: X.Y.Z (persisted)`

### Phase 2: Backend — API Endpoints

- [x] Task 4: Add `GET /api/openclaw/health/version` endpoint in `src/routes/openclaw.js` that returns the full version info from `getVersionInfo()`:
  ```json
  {
    "installedVersion": "2026.2.14",
    "persistedVersion": "2026.2.14",
    "latestVersion": "2026.2.15",
    "latestTag": "latest",
    "lastCheckedAt": "2026-02-15T17:58:30.308Z",
    "updateAvailable": true
  }
  ```
  - Protected by existing `launcherAuth` middleware (inherits from `/api/openclaw` mount)

- [x] Task 5: Extend the `GET /api/openclaw/health` summary response to include a `version` section in the summary roll-up:
  - `version: 'ok'` when installed version matches latest (or no update check data available)
  - `version: 'warn'` when an update is available
  - Include `installedVersion` and `latestVersion` in the health response for display

- [x] Task 6: Optionally extend the `GET /control/v1/instances/:id/status` response (from Goal 013) to include `openclawVersion` field so InstClaw can monitor the version of managed instances remotely

### Phase 3: Frontend — Health Page Integration

- [x] Task 7: Add a **Version & Updates** section to the Health page. This can be implemented as either:
  - A new row in the existing **Config Validation** card (simpler, since version is a config-adjacent concern), or
  - A small dedicated card/banner at the top of the Health page (more visible for update notifications)
  - Display: installed version, last update check time, and "Update Available: vX.Y.Z" badge when `updateAvailable` is true
  - Uses `GET /api/openclaw/health/version`

- [x] Task 8: Style the update notification:
  - When no update: show installed version in a neutral/green badge
  - When update available: show an amber/yellow "Update Available" badge with the new version number
  - Include a "What's new?" link placeholder (can link to changelog or release notes URL if available)

### Phase 4: Frontend — Sidebar Update Notification

- [x] Task 9: Add an update notification indicator to the sidebar in `Layout.jsx`:
  - When an update is available, show a small dot/badge on the "Settings" nav item (similar to the existing `nav-badge-configured` and `nav-badge-live` patterns)
  - Fetch version info from the health summary (which is already fetched by `AppConfigContext`) or add a lightweight version check to the context
  - The badge should be subtle (small amber dot) — not intrusive, just a visual cue

- [x] Task 10: Add the installed version number to the sidebar footer (below the theme toggle / sign out buttons):
  - Display as small muted text: `v2026.2.14`
  - When update available, append: `v2026.2.14 → v2026.2.15` or show a small "update" icon

### Phase 5: Version Restoration Support

- [x] Task 11: Add `GET /api/openclaw/version/persisted` endpoint that returns only the persisted version from the flag file:
  ```json
  { "version": "2026.2.14", "persistedAt": "2026-02-15T..." }
  ```
  - This endpoint is intended for restore/reinstall tooling to know which version to install
  - Include the file modification timestamp as `persistedAt`

- [x] Task 12: Document the version flag file format and location in the service file comments:
  - File: `~/.openclaw/.installed-version`
  - Format: plain text, single line, version string only (e.g., `2026.2.14`)
  - Permissions: `0o600`
  - Written by: OpenClaw Launcher on startup when version changes
  - Read by: restore/reinstall tooling (external)

### Phase 6: Integration & Polish

- [x] Task 13: Update `pd/rules/api-conventions.md` to document the new version endpoints (`/health/version`, `/version/persisted`)

- [x] Task 14: Rebuild frontend with `npm run build:frontend` and verify:
  - Health page shows version info
  - Sidebar shows version number in footer
  - Update notification badge appears when `updateAvailable` is true
  - All existing health cards continue to work

## Acceptance Criteria

- The installed OpenClaw version is detected via CLI (`openclaw --version`) and persisted to `~/.openclaw/.installed-version` on launcher startup
- The persisted version file survives project reset and can be read by external restore tooling to reinstall the same version
- `~/.openclaw/update-check.json` is read (not written) to determine the latest available version
- Version comparison correctly identifies when a newer version is available using the `YYYY.M.DD` format
- `GET /api/openclaw/health/version` returns complete version info including `updateAvailable` boolean
- The Health page displays the installed version and shows an "Update Available" notification when applicable
- The sidebar shows a subtle update notification badge on the Settings nav item when an update is available
- The sidebar footer displays the current installed version
- `GET /api/openclaw/version/persisted` returns the persisted version for restore tooling
- All new endpoints are protected by `launcherAuth`
- No existing health page functionality is broken

## Progress

- Status: **Complete**
- Start Date: 2026-02-16
- Completion Date: 2026-02-16
- Completion: 100%
- Notes:
  - Key discovery: `~/.openclaw/update-check.json` already exists on disk but is unused in the codebase — likely written by the OpenClaw CLI itself during self-update checks
  - `meta.lastTouchedVersion` in `openclaw.json` is a static `'1.0.0'` set during config creation — not useful for version tracking
  - The actual reinstall/reset API is out of scope (described as "another API we need from external") — this goal only handles detection, persistence, comparison, and notification
  - Version format observed: `"2026.2.14"` (YYYY.M.DD) in `update-check.json`
  - All 14 tasks completed in a single iteration
  - Backend: Created `src/services/version-tracker.js` with full version detection, persistence, comparison, and aggregation
  - Backend: Added `GET /health/version`, `GET /version/persisted` endpoints; extended `/health` summary and `/health/batch` with version data; added `openclawVersion` to InstClaw status endpoint
  - Frontend: Added "Version & Updates" HealthCard to Health page with installed version, last check time, and update-available badge
  - Frontend: Added amber update badge on Settings nav item and version footer in sidebar via AppConfigContext
  - CSS: Added `.nav-badge-update` (amber dot) and `.sidebar-version` / `.sidebar-version-update` styles
  - Server startup auto-persists version: confirmed `[version-tracker] OpenClaw version: 2026.2.12 (persisted)` in logs
  - Version flag file created at `~/.openclaw/.installed-version` with `0o600` permissions
  - Frontend build succeeded, server restarted cleanly with no errors

## Dependencies

- **Goal 010 (Health Page)**: Complete. New version info extends the existing health card architecture
- **Goal 013 (InstClaw Managed Pool)**: Complete. Optionally extends `/status` endpoint with version field
- **Goal 009 (Launcher Login)**: Complete. All new endpoints inherit `launcherAuth` protection
- **External**: OpenClaw CLI must be installed and accessible in PATH for `openclaw --version` to work
- **External**: `~/.openclaw/update-check.json` must be written by the OpenClaw CLI's update check mechanism (this goal reads it, not writes it)
- **External**: Reset/reinstall API is out of scope — provided by external tooling that reads the persisted version file

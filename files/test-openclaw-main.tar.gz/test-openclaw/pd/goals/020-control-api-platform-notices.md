# Goal: Control API — Platform Notices & User Messaging

## Objective

Add a platform notification system to the **Control API** (`/control/v1`) so that an external management platform (e.g., InstClaw) can push notices and messages to a launcher instance for display to the end user. This enables the platform to communicate billing information (balance warnings, invoice due, payment received), system maintenance schedules, feature announcements, and operational alerts directly through the launcher UI.

Currently, the launcher has no mechanism for receiving externally-authored messages. The only user-facing notifications are local concerns (adoption failure risk banners from Goal 015, update-available badges from Goal 017). This goal introduces a **remote notice system** — platform-authored notices stored in `~/.openclaw/notices.json`, managed via Control API CRUD endpoints, and displayed in the launcher frontend as page banners and/or an inbox panel.

The design follows the established Control API patterns: flat JSON file storage, CRUD endpoints under `/control/v1`, `X-Control-Key` authentication, and the standard `{ success, data, error }` response envelope.

## Analysis & Conflict Review

### Overlap with Existing Goals

| Goal | Overlap | Resolution |
|------|---------|------------|
| **013 (InstClaw Managed Pool)** | Complete. The Control API infrastructure (auth, rate limiting, error envelope, response helpers) is already in place. New endpoints follow the same patterns. | Reuse — same `X-Control-Key` auth, same response envelope, same route file (`src/routes/control.js`) |
| **015 (Failure Risk Visibility)** | Complete. Risk banners in the frontend are conceptually similar (displaying warnings to the user), but they are driven by local failure tracking, not external platform messages. | No conflict — notices are a separate data source displayed independently from risk banners. Could share banner styling conventions for visual consistency. |
| **017 (Version Tracking)** | Complete. Update-available badge is a notification concept, but driven by local version detection, not platform-pushed messages. | No conflict — different data source and display mechanism |
| **019 (Control API Marketplace)** | Not started. Similar Control API CRUD pattern (external platform writes data to a local JSON file, launcher reads it). | No conflict — marketplace manages catalog items, notices manage messages. Both use the same architectural pattern independently. |
| **016 (Admin Tab)** | Complete. The Admin page (formerly "Managed Pool") is where adoption management lives. Notice management could appear here or in a separate location. | Additive — notices display in a global banner (all pages) and optionally a dedicated inbox. No modification to Admin page needed. |

### No Conflicts Identified

All changes are additive. The existing Control API contract is unchanged. Notice storage uses a separate file (`~/.openclaw/notices.json`) that does not interfere with any existing config or registry files. Frontend display adds a new global banner component and optional inbox panel without modifying existing pages.

### Architecture Decisions

**1. Separate notices file, not extending openclaw.json or launcher.json**
Notices are transient platform-authored content, not instance configuration. Storing them in `~/.openclaw/notices.json` keeps them isolated, easy to wipe, and prevents config file bloat. File permissions `0o600` for consistency.

**2. Notice schema**
Each notice has:
- `id` (string, required) — unique identifier, platform-generated (e.g., `"billing-low-balance-2026-02"`)
- `type` (string, required) — `"banner"` | `"inbox"` | `"both"` — controls display location
- `priority` (string, required) — `"info"` | `"warning"` | `"critical"` — controls styling (blue/amber/red, matching Goal 015 risk banner conventions)
- `title` (string, required) — short headline (max 120 chars)
- `message` (string, required) — body text (max 2000 chars, plain text)
- `actionUrl` (string, optional) — URL the user can click for more details (e.g., billing page link)
- `actionLabel` (string, optional) — label for the action link (e.g., "View Invoice", "Top Up")
- `expiresAt` (string, optional) — ISO 8601 timestamp; notice auto-hides after this time
- `createdAt` (string, auto-set) — ISO 8601 timestamp when the notice was created
- `dismissible` (boolean, default `true`) — whether the user can dismiss this notice

**3. User dismissals tracked locally**
When a user dismisses a notice, the dismissal is recorded in `~/.openclaw/notice-dismissals.json` (keyed by notice ID). Dismissed notices are filtered out of the frontend response but remain in the notices file until the platform removes them. This lets the platform see that the notice was delivered while respecting the user's dismiss action.

**4. Notice limits**
Maximum 50 active notices at any time (platform should clean up old/expired notices). If the limit is hit, new notices are rejected with an error.

**5. Frontend display**
- **Banner notices**: Displayed at the top of the main layout (above page content, below header). Only the highest-priority non-dismissed notice of type `"banner"` or `"both"` is shown as a persistent banner. Additional banner notices are accessible via the inbox.
- **Inbox panel**: A notification bell icon in the sidebar/header showing unread count badge. Clicking opens a panel listing all non-expired, non-dismissed notices in reverse chronological order.

## Tasks

### Phase 1: Backend — Notice Storage Service

- [x] Task 1: Create notice management functions in `src/services/notices.js`:
  - `readNotices()` — reads and parses `~/.openclaw/notices.json`, returns `{ notices: [] }` if file doesn't exist
  - `writeNotices(data)` — validates and writes the notices file with `0o600` permissions
  - `validateNotice(notice)` — validates required fields: `id`, `type` (enum), `priority` (enum), `title` (string, max 120), `message` (string, max 2000); validates optional fields when present
  - `addNotice(notice)` — validates, auto-sets `createdAt`, appends to notices array, enforces 50-notice limit
  - `removeNotice(noticeId)` — removes a notice by ID, also cleans up its dismissal entry
  - `getActiveNotices()` — returns notices filtered by: not expired (`expiresAt` not passed), sorted by `createdAt` desc

- [x] Task 2: Create dismissal management functions:
  - `readDismissals()` — reads `~/.openclaw/notice-dismissals.json`, returns `{}` if file doesn't exist
  - `writeDismissals(data)` — writes dismissals file
  - `dismissNotice(noticeId)` — records `{ dismissedAt }` keyed by notice ID
  - `isDismissed(noticeId)` — checks if a notice has been dismissed
  - `cleanupDismissals(activeNoticeIds)` — removes dismissal entries for notices that no longer exist (garbage collection)

### Phase 2: Backend — Control API Endpoints

- [x] Task 3: Add notice management endpoints to `src/routes/control.js`:
  - `GET /control/v1/notices` — returns all notices (not filtered by dismissals — the platform sees everything it has posted)
  - `POST /control/v1/notices` — create a single notice; body: `{ notice: {...} }`; returns the created notice with `createdAt` set
  - `PUT /control/v1/notices` — replace all notices; body: `{ notices: [...] }`; useful for bulk sync from platform
  - `DELETE /control/v1/notices/:noticeId` — remove a specific notice by ID
  All endpoints use existing `controlAuth` middleware. Follow the standard `{ success, data, error }` response envelope.

- [x] Task 4: Add input validation for Control API notice endpoints:
  - `POST /notices`: validate `notice` object passes `validateNotice()`
  - `PUT /notices`: validate `notices` is an array, each passes `validateNotice()`, enforce 50-item limit
  - `DELETE /notices/:noticeId`: validate notice exists, return 404 if not found
  - Return `INVALID_PARAMETERS` error code for validation failures

### Phase 3: Launcher API — Frontend-Facing Endpoints

- [x] Task 5: Add notice retrieval endpoint to `src/routes/openclaw.js`:
  - `GET /api/openclaw/notices` — returns active, non-expired notices with dismissal status applied:
    - Each notice includes a `dismissed` boolean field
    - Filter out expired notices
    - Sort by priority (critical > warning > info), then by `createdAt` desc
    - Include summary: `{ notices: [...], unreadCount: <number of non-dismissed notices> }`
  - Protected by existing `launcherAuth` middleware

- [x] Task 6: Add notice dismissal endpoint to `src/routes/openclaw.js`:
  - `POST /api/openclaw/notices/:noticeId/dismiss` — dismisses a notice for the current user
  - Protected by `launcherAuth`
  - Returns `{ success: true, unreadCount: <updated count> }`

### Phase 4: Frontend — Banner Display

- [x] Task 7: Create a `NoticeBanner.jsx` component in `src/frontend/components/`:
  - Fetches notices from `GET /api/openclaw/notices` on mount
  - Displays the highest-priority non-dismissed banner-type notice (`type: "banner"` or `"both"`) as a persistent banner at the top of the layout
  - Styled by priority: info (blue), warning (amber), critical (red) — consistent with Goal 015 risk banner styling
  - Shows title, message (truncated if long), and action button if `actionUrl`/`actionLabel` are present
  - Shows a dismiss button (X) if `dismissible: true`; calls the dismiss endpoint on click
  - If multiple banner notices exist, show a "N more notices" link that opens the inbox

- [x] Task 8: Integrate `NoticeBanner` into the main layout:
  - Add `<NoticeBanner />` to `src/frontend/App.jsx` or the layout wrapper so it appears on all authenticated pages
  - Position above the main content area, below the header/navigation
  - The banner should not render if there are no active non-dismissed banner notices (no empty space)

### Phase 5: Frontend — Inbox Panel

- [x] Task 9: Create a `NoticeInbox.jsx` component in `src/frontend/components/`:
  - A slide-out panel or modal triggered by a bell icon in the sidebar or header
  - Lists all non-expired notices (both dismissed and non-dismissed, with dismissed ones visually muted)
  - Each notice shows: priority badge, title, message, timestamp (relative), action link, dismiss button
  - Empty state: "No notices" message

- [x] Task 10: Add notification bell indicator to the sidebar in `src/frontend/components/Layout.jsx`:
  - Show a small badge with unread count on the bell icon (similar to the update badge from Goal 017)
  - Badge appears only when `unreadCount > 0`
  - Clicking the bell opens the `NoticeInbox` panel
  - Fetch notice count from `GET /api/openclaw/notices` (can piggyback on existing AppConfigContext or use a lightweight poll)

### Phase 6: Documentation & Verification

- [x] Task 11: Update `public/openclaw-launcher-ctrl-llms.txt` with the new notice management endpoints:
  - Document `GET /control/v1/notices`
  - Document `POST /control/v1/notices` with the notice schema
  - Document `PUT /control/v1/notices` for bulk replacement
  - Document `DELETE /control/v1/notices/:noticeId`
  - Include the full notice schema with field descriptions and constraints
  - Include example notices (billing warning, maintenance schedule)

- [x] Task 12: Rebuild frontend with `npm run build:frontend` and verify:
  - Banner displays when a notice exists (test by using Control API to POST a notice)
  - Banner styling matches priority level (info/warning/critical)
  - Dismiss works and the banner disappears
  - Inbox panel lists all notices
  - Bell icon shows unread count
  - Expired notices are automatically hidden
  - All existing pages and functionality continue working

## Acceptance Criteria

- The Control API exposes CRUD endpoints for managing notices at `/control/v1/notices*`
- Notices are persisted in `~/.openclaw/notices.json` (separate from config files)
- Notice validation enforces required fields, type/priority enums, and string length limits
- Maximum 50 active notices enforced; bulk PUT rejects payloads exceeding the limit
- The launcher API (`GET /api/openclaw/notices`) returns active, non-expired notices with dismissal status
- User dismissals are tracked in `~/.openclaw/notice-dismissals.json` and survive page refreshes
- Dismissed notices are excluded from the banner but visible (muted) in the inbox
- The highest-priority non-dismissed banner notice displays at the top of all authenticated pages
- Banner styling follows priority conventions: info (blue), warning (amber), critical (red)
- Banner includes action button when `actionUrl`/`actionLabel` are present
- The inbox panel shows all non-expired notices with dismiss capability
- A notification bell with unread count badge appears in the sidebar/header
- Expired notices (past `expiresAt`) are automatically filtered out of frontend responses
- Stale dismissals are cleaned up when their corresponding notices are removed
- All Control API notice endpoints are protected by `controlAuth` (X-Control-Key)
- All launcher notice endpoints are protected by `launcherAuth`
- The `llms.txt` file documents all new Control API notice endpoints with schemas and examples
- Notice file uses `0o600` permissions for security consistency

## Progress

- Status: **Complete**
- Start Date: 2026-02-23
- Completion Date: 2026-02-23
- Notes:
  - All 12 tasks implemented in a single pass
  - Created `src/services/notices.js` as a standalone service (kept instance-control.js focused)
  - Notice storage: `~/.openclaw/notices.json`, dismissals: `~/.openclaw/notice-dismissals.json` (both 0o600 permissions)
  - Control API endpoints (GET/POST/PUT/DELETE) added to `src/routes/control.js` using existing `controlAuth` middleware and response envelope
  - Launcher API endpoints (GET notices + POST dismiss) added to `src/routes/openclaw.js` using existing `launcherAuth` middleware
  - `NoticeBanner.jsx` — displays highest-priority non-dismissed banner notice with priority-based styling (info=blue, warning=amber, critical=red); includes action URL support, dismiss button, and "N more notices" link to inbox
  - `NoticeInbox.jsx` — slide-out panel listing all non-expired notices with priority badges, relative timestamps, action links, and dismiss controls; dismissed notices shown visually muted
  - Bell icon with unread count badge added to Layout.jsx sidebar footer; `useNotices()` hook polls every 5 minutes
  - `llms.txt` updated with endpoints 14-17 (notice CRUD), full notice schema, display behavior description, and 3 example notices
  - Frontend builds cleanly, server starts without errors
  - Depends on Goal 013 (Complete) for Control API infrastructure (auth, rate limiting, response envelope)
  - Frontend banner styling consistent with Goal 015 risk banner conventions
  - The notification bell badge follows the same pattern as the update badge from Goal 017
  - The `actionUrl` in notices opens in a new tab (`target="_blank"`)
  - Future enhancement (out of scope): WebSocket push for real-time notice delivery; current design uses 5-minute polling

## Dependencies

- **Goal 013 (InstClaw Managed Pool Adoption)**: Complete. Provides the Control API infrastructure (`/control/v1`, `controlAuth`, `X-Control-Key`, response envelope, rate limiting)
- **Goal 009 (Launcher Login)**: Complete. Launcher-facing notice endpoints must be protected by `launcherAuth`
- **Goal 015 (Failure Risk Visibility)**: Complete. Banner styling conventions (blue/amber/red severity tiers) should be visually consistent
- **Goal 017 (Version Tracking)**: Complete. Notification badge pattern in sidebar can be reused
- **External**: Management platform (e.g., InstClaw) must have the control key to call notice management endpoints
- None of the existing goals conflict with this feature

# Goal: Auto-Detect Custom Anthropic Endpoint from Claude Settings

## Objective
Add auto-detection of custom Anthropic-compatible endpoints configured via `~/.claude/settings.json` to the credential discovery flow. Claude Code's `settings.json` can define environment overrides (`ANTHROPIC_AUTH_TOKEN`, `ANTHROPIC_BASE_URL`, `ANTHROPIC_MODEL`) that point to a proxy or custom Anthropic endpoint (e.g., an enterprise relay like `crs2-ie1-prod.anispark.ai`). This is analogous to how ZAI is detected from `~/.claude-code-router/config.json` — users who have a custom Anthropic endpoint configured in their Claude Code settings should see it auto-detected as a selectable provider in the launcher's Credentials page, without needing to re-enter keys manually.

## Context

### Source File: `~/.claude/settings.json`
```json
{
  "env": {
    "ANTHROPIC_AUTH_TOKEN": "sk-XXX",
    "ANTHROPIC_BASE_URL": "https://crs2-ie1-prod.example.ai",
    "ANTHROPIC_MODEL": "opus"
  }
}
```

### Key Fields
| Field | Purpose |
|-------|---------|
| `ANTHROPIC_AUTH_TOKEN` | API key / auth token for the custom endpoint |
| `ANTHROPIC_BASE_URL` | Base URL of the custom Anthropic-compatible proxy |
| `ANTHROPIC_MODEL` | Preferred model alias or ID |

### Relationship to Existing Providers
- This is NOT the same as a standard `ANTHROPIC_API_KEY` env var (already detected by Goal #006)
- This is a **Claude Code-specific** settings file that may configure a non-standard Anthropic-compatible endpoint (proxy, enterprise relay, etc.)
- The detection pattern mirrors ZAI: read a known config file, extract provider metadata, present as a selectable option

## Tasks

**Backend: Detection Logic**
- [x] Task 1: Add a `detectClaudeSettings()` function in `src/services/credential-discovery.js` that reads `~/.claude/settings.json`, checks for the `env` object containing `ANTHROPIC_AUTH_TOKEN` and/or `ANTHROPIC_BASE_URL`, and returns provider metadata (provider name, base URL, model hint, availability) — without exposing the raw token value
- [x] Task 2: Include `detectClaudeSettings()` results in `detectAllCredentials()` so they appear in the `/api/openclaw/credentials/detect` response alongside ZAI and env-var providers
- [x] Task 3: Derive a meaningful provider label — if `ANTHROPIC_BASE_URL` is set, extract the hostname as a display hint (e.g., `"claude-settings (crs2-ie1-prod.example.ai)"`); if only `ANTHROPIC_AUTH_TOKEN` is set without a custom base URL, label it as `"anthropic (claude-settings)"`

**Backend: Apply Logic**
- [x] Task 4: Add a `claude-settings` provider branch in `POST /api/openclaw/credentials/apply` that reads the actual credentials from `~/.claude/settings.json` at apply time and writes the provider config to `openclaw.json` with `api: 'anthropic-messages'`, the custom `baseUrl` (from `ANTHROPIC_BASE_URL`), and `auth: 'api-key'`
- [x] Task 5: Write the `ANTHROPIC_AUTH_TOKEN` credential to `auth-profiles.json` following the existing pattern from Goal #006 (using `writeAuthProfiles()`) — store as `type: "api_key"` under a profile ID like `"claude-settings:default"`
- [x] Task 6: If `ANTHROPIC_MODEL` is present in settings, use it as a model hint — map known aliases (e.g., `"opus"` → `"claude-opus-4-6"`, `"sonnet"` → `"claude-sonnet-4-5-20250929"`) or pass through as-is if it looks like a full model ID

**Frontend: Display**
- [x] Task 7: Update the detected providers list in `Credentials.jsx` to display the `claude-settings` provider with its source label and custom base URL, similar to how env-var providers are displayed
- [x] Task 8: When `claude-settings` is selected and applied, show the detected base URL and model hint in the provider card for user confirmation before apply

**Build & Verify**
- [x] Task 9: Rebuild frontend with `npm run build:frontend` and verify the Credentials page shows the claude-settings provider when `~/.claude/settings.json` exists with the expected env fields
- [x] Task 10: Test the apply flow end-to-end — verify `openclaw.json` gets the correct provider config with custom base URL and `auth-profiles.json` gets the credential
- [x] Task 11: Verify that existing ZAI detection, env-var detection, and manual credential flows are unaffected

## Acceptance Criteria
- When `~/.claude/settings.json` exists with `ANTHROPIC_AUTH_TOKEN` and/or `ANTHROPIC_BASE_URL` in the `env` object, a `claude-settings` provider appears in the detected providers list
- The detected provider shows the custom base URL hostname as a source hint
- Applying the `claude-settings` provider writes correct config to `openclaw.json` (custom `baseUrl`, `api: 'anthropic-messages'`, `auth: 'api-key'`)
- The auth token is stored in `auth-profiles.json` (not in `openclaw.json`), following Goal #006 patterns
- Model aliases from `ANTHROPIC_MODEL` are resolved to full model IDs where possible
- Raw token values are never exposed in API responses
- Existing detection flows (ZAI, env vars, manual) are unaffected
- The provider display is consistent with the existing dark theme card-based layout

## Progress
- Status: **Complete** (100%)
- Start Date: 2026-02-12
- Completion Date: 2026-02-12
- Notes:
  - Discovered from actual `~/.claude/settings.json` on the current environment containing `ANTHROPIC_AUTH_TOKEN`, `ANTHROPIC_BASE_URL` (pointing to `crs2-ie1-prod.anispark.ai`), and `ANTHROPIC_MODEL: "opus"`
  - Pattern closely mirrors ZAI detection in `credential-discovery.js` — read a known config file path, extract metadata, present in detection results
  - Must coordinate with Goal #006's `auth-profiles.json` write pattern and existing `ENV_VAR_PROVIDERS` detection to avoid double-detecting if both `~/.claude/settings.json` and `ANTHROPIC_API_KEY` env var are present
  - **2026-02-12 — Tasks 1-9 completed:**
    - Added `CLAUDE_SETTINGS_PATH`, `CLAUDE_MODEL_ALIASES`, `resolveClaudeModelAlias()`, `detectClaudeSettings()`, `getClaudeSettingsRaw()` to `credential-discovery.js`
    - Detection returns: provider name, source label with hostname, baseUrl, modelHint (resolved alias), modelAlias (raw), api format, hasApiKey flag — no raw token exposed
    - Integrated into `detectAllCredentials()` between ZAI and env-var detection
    - Added `claude-settings` branch in `/credentials/apply` route: reads settings at apply time, strips URL path suffixes, resolves model aliases, writes provider config to `openclaw.json` and token to `auth-profiles.json` under `claude-settings:default`
    - Frontend shows claude-settings card with endpoint URL and resolved model hint; auto-fills model input when selected
    - Frontend built successfully
    - Tasks 10-11 (end-to-end testing) deferred to next iteration for manual verification
  - **2026-02-12 — Tasks 10-11 completed (end-to-end verification):**
    - **Task 10 — Apply flow verified end-to-end:**
      - `POST /api/openclaw/credentials/apply` with `{provider: "claude-settings", model: "claude-opus-4-6"}` returns `{success: true}`
      - `openclaw.json` correctly updated: `models.providers.claude-settings` has `baseUrl: "https://crs2-ie1-prod.anispark.ai"`, `auth: "api-key"`, `api: "anthropic-messages"`, model entry for `claude-opus-4-6`
      - `auth.profiles.claude-settings:default` written with `{provider: "claude-settings", mode: "api_key"}` (no secrets in config)
      - `agents.defaults.model.primary` set to `"claude-settings/claude-opus-4-6"`
      - `auth-profiles.json` correctly updated: `profiles.claude-settings:default` has `{type: "api_key", provider: "claude-settings", key: "<actual-token>"}` with file permissions `0600`
    - **Task 11 — Existing flows verified unaffected:**
      - Detection endpoint returns both `zai` and `claude-settings` providers simultaneously; ZAI appears first with all fields intact
      - ZAI apply flow tested: `POST /credentials/apply {provider: "zai"}` succeeds, writes correct config with ZAI models and auth profile
      - Env-var detection code (`detectEnvVarProviders()`) operates independently in `detectAllCredentials()` — no interference from claude-settings branch
      - Config sanitization verified: `/api/openclaw/config` masks secrets (`botToken`, `gateway.auth.token` shown as `"***masked***"`)
      - No runtime errors in server logs related to the claude-settings implementation

## Dependencies
- Goal #001 (Setup Wizard Backend) — **Complete** — provides the routes and services being extended
- Goal #002 (React SPA Frontend) — **Complete** — provides the Credentials.jsx page being updated
- Goal #006 (Credential Provider Alignment) — **Complete** — provides `auth-profiles.json` write pattern, `writeAuthProfiles()` utility, and env-var detection that must not conflict
- `~/.claude/settings.json` — Claude Code settings file containing custom endpoint configuration

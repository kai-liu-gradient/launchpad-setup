# Goal: Launcher Upgrade Policy in launcher.json

## Objective

Add a configurable upgrade policy to `~/.openclaw/launcher.json` so the bootstrap/reinstall process can decide whether to install the latest OpenClaw version or pin to the currently installed one. The installed version itself is already tracked in `~/.openclaw/.installed-version` (Goal 017) — this goal reuses that file as the version source and only adds the `upgradePolicy` field to `launcher.json`.

Bootstrap decision logic: if `.installed-version` has no version or `upgradePolicy` is `"auto"`, install latest; if `.installed-version` has a version and `upgradePolicy` is `"manual"` (the default), reuse that pinned version. The upgrade policy toggle is surfaced on the Health page so users can control this behavior.

## Analysis & Conflict Review

### Overlap with Existing Goals

| Goal | Overlap | Resolution |
|------|---------|------------|
| **017 (Version Tracking)** | Complete. Goal 017 persists version to `~/.openclaw/.installed-version` and provides version detection, comparison, and update notification in the Health page and sidebar | Additive — this goal reuses `.installed-version` as the version source (no duplication) and only adds `upgradePolicy` to `launcher.json` |
| **010 (Health Page)** | Complete. Health page uses per-section card architecture with a Version card | Additive — extends the existing Version health card with an upgrade policy display and toggle. No changes to HealthCard component contract |

### No Conflicts Identified

All changes are additive. The existing version tracking (`version-tracker.js`), health endpoints, and frontend version display continue to function as-is. Version is NOT duplicated into launcher.json — the `.installed-version` file remains the single source of truth for the installed version.

### Key Design Decisions

- **No version duplication**: The installed version stays in `~/.openclaw/.installed-version` only (Goal 017). `launcher.json` stores only the `upgradePolicy` field. Bootstrap tooling reads both files.
- **Default upgrade policy**: `"manual"` (no auto-upgrade). This is the safe default — users must explicitly opt into auto-upgrade.
- **Bootstrap consumer**: The actual bootstrap/reinstall logic is external (admin scripts, instclaw controller). This goal ensures the upgrade policy is available in `launcher.json` for those consumers to read alongside the version from `.installed-version`.

## Tasks

### Phase 1: Backend — launcher.json Upgrade Policy Field

- [x] Task 1: Add `upgradePolicy` field to the `launcher.json` schema. The structure in launcher.json should be:
  ```json
  {
    "auth": { "password": "..." },
    "upgradePolicy": "manual"
  }
  ```
  - `upgradePolicy` (string): `"manual"` (default, pin to current version on reinstall) or `"auto"` (always install latest on bootstrap)
  - The installed version is NOT stored here — it remains in `~/.openclaw/.installed-version` (Goal 017)

- [x] Task 2: Extend `version-tracker.js` `autoPersistVersion()` to initialize `upgradePolicy` in `launcher.json` if the field doesn't exist yet:
  - Read the current launcher config via `readLauncherConfig()`
  - If `upgradePolicy` is missing, set it to `"manual"` via `writeLauncherConfig()`
  - Log: `[version-tracker] Upgrade policy initialized: manual`

### Phase 2: Backend — Upgrade Policy API

- [x] Task 3: Add `GET /api/openclaw/upgrade-policy` endpoint in `src/routes/openclaw.js` that returns the current upgrade policy from launcher.json:
  ```json
  {
    "upgradePolicy": "manual"
  }
  ```
  - Protected by existing `launcherAuth` middleware

- [x] Task 4: Add `PUT /api/openclaw/upgrade-policy` endpoint in `src/routes/openclaw.js` that updates the upgrade policy in launcher.json:
  - Request body: `{ "upgradePolicy": "auto" | "manual" }`
  - Validate that `upgradePolicy` is one of the two allowed values
  - Write to launcher.json via `writeLauncherConfig()`
  - Return the updated policy
  - Protected by existing `launcherAuth` middleware

- [x] Task 5: Extend the `GET /api/openclaw/health/version` response to include the upgrade policy:
  ```json
  {
    "installedVersion": "2026.2.14",
    "persistedVersion": "2026.2.14",
    "latestVersion": "2026.2.15",
    "updateAvailable": true,
    "upgradePolicy": "manual"
  }
  ```

### Phase 3: Frontend — Health Page Upgrade Policy Display & Toggle

- [x] Task 6: Add an **Upgrade Policy** row to the existing Version health card on the Health page (`src/frontend/pages/setup/Health.jsx`):
  - Display the current upgrade policy as a badge: `"Manual"` (neutral/blue) or `"Auto"` (green)
  - Include a toggle switch or button to switch between `manual` and `auto`
  - When toggled, call `PUT /api/openclaw/upgrade-policy` and update the display
  - Show a brief explanation: "Manual: pin to current version on reinstall. Auto: always install latest on reinstall."

- [x] Task 7: In the Version health card's collapsed summary (shown in the card header when collapsed), include the upgrade policy alongside the version info. For example: `"v2026.2.14 · Manual upgrade"` or `"v2026.2.14 · Auto upgrade"`

### Phase 4: Bootstrap Integration Documentation

- [x] Task 8: Add inline documentation in `version-tracker.js` describing the bootstrap decision logic that external consumers should follow:
  ```
  Bootstrap Decision Logic (for external reinstall/reset tooling):
  1. Read ~/.openclaw/.installed-version for the pinned version
  2. Read ~/.openclaw/launcher.json for upgradePolicy
  3. If .installed-version is missing OR upgradePolicy === "auto":
     → Install latest version (npm install openclaw@latest)
  4. If .installed-version has a version AND upgradePolicy === "manual":
     → Install pinned version (npm install openclaw@<version>)
  ```

- [x] Task 9: Update `pd/rules/api-conventions.md` to document the new upgrade policy endpoints (`GET /upgrade-policy`, `PUT /upgrade-policy`) and the extended `/health/version` response

### Phase 5: Build & Verify

- [x] Task 10: Rebuild frontend with `npm run build:frontend` and verify:
  - Health page Version card shows upgrade policy row with toggle
  - Toggle switches between "manual" and "auto" and persists to launcher.json
  - Collapsed version card summary includes upgrade policy
  - All existing version tracking functionality continues to work

## Acceptance Criteria

- `launcher.json` contains `upgradePolicy` field defaulting to `"manual"`, changeable to `"auto"` via API and Health page toggle
- Version is NOT duplicated into launcher.json — `~/.openclaw/.installed-version` (Goal 017) remains the single source of truth for the installed version
- `GET /api/openclaw/upgrade-policy` returns the current policy from launcher.json
- `PUT /api/openclaw/upgrade-policy` updates the policy in launcher.json (validates input to `"manual"` or `"auto"` only)
- `GET /api/openclaw/health/version` response includes `upgradePolicy` field
- Health page Version card displays the upgrade policy with a toggle to switch between manual and auto
- The collapsed Version card summary includes the upgrade policy
- Bootstrap decision logic is documented in code comments for external consumers (reads `.installed-version` for version + `launcher.json` for policy)
- Existing version tracking (`.installed-version` file, sidebar version display, update notifications) continues to work unchanged
- All new endpoints are protected by `launcherAuth`
- No existing health page functionality is broken

## Progress

- Status: **Complete**
- Start Date: 2026-02-27
- Completion Date: 2026-02-27
- Completion: 100%
- Notes:
  - All 10 tasks implemented and verified
  - `version-tracker.js`: imports `openclaw-config`, `autoPersistVersion()` now initializes `upgradePolicy: "manual"` in launcher.json if missing, bootstrap decision logic documented in file header
  - `src/routes/openclaw.js`: Added `GET /upgrade-policy` and `PUT /upgrade-policy` endpoints with validation; extended `GET /health/version` to include `upgradePolicy` from launcher.json
  - `src/frontend/pages/setup/Health.jsx`: Added "Upgrade Policy" section to Version card with badge display, toggle button ("Switch to Auto"/"Switch to Manual"), and contextual explanation text. Collapsed summary now shows "Manual upgrade" or "Auto upgrade" badge alongside version
  - `pd/rules/api-conventions.md`: Documented new upgrade policy endpoints
  - Frontend built successfully, server restarted and running, API endpoints tested (GET, PUT, validation of invalid values all working)
  - `launcher.json` confirmed to contain `upgradePolicy: "manual"` after server startup
  - No version duplication — `.installed-version` is the version source, `launcher.json` only stores the upgrade policy

## Dependencies

- **Goal 017 (Version Tracking)**: Complete. This goal extends the version persistence and Health page version display established in Goal 017
- **Goal 010 (Health Page)**: Complete. The upgrade policy toggle is added to the existing Version health card
- **Goal 009 (Launcher Login)**: Complete. All new endpoints inherit `launcherAuth` protection
- **External**: Bootstrap/reinstall tooling must be updated to read `launcher.json` for version and upgrade policy (out of scope for this goal)

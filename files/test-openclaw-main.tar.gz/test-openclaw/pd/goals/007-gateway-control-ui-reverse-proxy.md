# Goal: Gateway Control UI Reverse Proxy & Web Shell Integration

## Objective

Integrate the OpenClaw gateway's built-in **Control UI** (web dashboard at port 18789) and provide a **web-based terminal shell** into the OpenClaw Launcher (port 3000), allowing users to access both interfaces through a single unified web application. The gateway's Control UI is a Lit-based SPA with real-time chat, configuration, channel management, session management, and monitoring — currently only accessible directly at `http://localhost:18789/`. By reverse-proxying it through the launcher, users get a single entry point for all OpenClaw management tasks.

## Background & Research

### OpenClaw Gateway UI Architecture

The OpenClaw gateway (source: `~/openclaw`) ships with two first-class user interfaces:

1. **Control UI (Web)** — Browser-based dashboard served by the gateway HTTP server
   - **Technology**: Vite + Lit (Web Components), TypeScript
   - **Source**: `~/openclaw/ui/` (122 TypeScript files, compiled to `ui/dist/`)
   - **Server**: `~/openclaw/src/gateway/control-ui.ts` + `server-http.ts`
   - **Default URL**: `http://127.0.0.1:18789/`
   - **Features**: Real-time AI chat, channel management (WhatsApp/Telegram/Discord/Slack/Signal), session management, cron jobs, skill installation, model switching, config editor, health monitoring, event/gateway logs, device pairing, update/restart controls
   - **Security**: `X-Frame-Options: DENY`, `Content-Security-Policy: frame-ancestors 'none'`, device pairing required, token/password auth

2. **TUI (Terminal)** — Terminal-based interface via `openclaw tui`
   - **Technology**: `@mariozechner/pi-tui` framework, TypeScript
   - **Source**: `~/openclaw/src/tui/` (39 TypeScript files)
   - **Connection**: WebSocket to gateway (`ws://localhost:18789/`)
   - **Features**: Chat with streaming, agent/session switching, model picker, slash commands, local shell execution

### Key Technical Challenges

- **iframe blocking**: Control UI sets `X-Frame-Options: DENY` and `frame-ancestors 'none'` — cannot embed via iframe without header stripping
- **WebSocket proxying**: Control UI communicates via WebSocket on the same port (18789) — reverse proxy must handle HTTP upgrade
- **Authentication**: Control UI requires device pairing and token auth — proxy must pass through auth headers/cookies
- **Asset paths**: Control UI serves assets from `/` root — reverse proxy must rewrite paths if mounted on a sub-path (e.g., `/gateway/`)

## Tasks

**Phase 1: Reverse Proxy Infrastructure**

- [x] Task 1: Add `http-proxy-middleware` (or equivalent) dependency for reverse proxying HTTP and WebSocket traffic
- [x] Task 2: Create `src/services/gateway-proxy.js` service to manage proxy configuration and gateway URL resolution (reads gateway port from `~/.openclaw/openclaw.json` or defaults to 18789)
- [x] Task 3: Add reverse proxy route in `src/routes/openclaw.js` (or dedicated route file) that proxies all requests under `/gateway/*` to `http://127.0.0.1:18789/`
- [x] Task 4: Handle WebSocket upgrade on the proxy path so Control UI real-time features work (chat streaming, live updates)
- [x] Task 5: Strip/rewrite restrictive security headers (`X-Frame-Options`, `Content-Security-Policy` frame-ancestors) from proxied responses to allow embedding or direct serving through the launcher
- [x] Task 6: Ensure proxy correctly handles Control UI authentication flow (pass through cookies, auth tokens, device pairing handshake)

**Phase 2: Web Shell (Terminal in Browser)**

- [x] Task 7: Add `xterm.js` and `@xterm/addon-fit` frontend dependencies for browser-based terminal emulation
- [x] Task 8: Add `node-pty` backend dependency for spawning pseudo-terminal processes
- [x] Task 9: Create `src/services/webshell.js` service that manages PTY sessions (spawn, resize, input/output, cleanup)
- [x] Task 10: Add WebSocket endpoint (e.g., `/api/openclaw/shell/ws`) for bidirectional terminal I/O between xterm.js frontend and node-pty backend
- [x] Task 11: Create `src/frontend/pages/Shell.jsx` React page with xterm.js terminal component
- [x] Task 12: Implement session lifecycle management — auto-spawn shell on page load, clean up PTY on disconnect, handle reconnection

**Phase 3: Frontend Integration**

- [x] Task 13: Add "Control UI" navigation item to the sidebar in `src/frontend/components/Layout.jsx` — links to the proxied gateway UI (either as a full-page proxy view or an embedded frame)
- [x] Task 14: Add "Terminal" navigation item to the sidebar for the web shell page
- [x] Task 15: Create `src/frontend/pages/ControlUI.jsx` page that either renders the proxied Control UI in an iframe (if header stripping works) or provides a direct link/redirect to `/gateway/`
- [x] Task 16: Integrate with adaptive UI mode (Goal #004) — show Control UI and Terminal nav items only when gateway is running and healthy
- [x] Task 17: Add gateway proxy health indicator — show connection status to gateway UI in sidebar or page header

**Phase 4: Security & Configuration**

- [x] Task 18: Add proxy configuration options to launcher config or environment variables (gateway host, port, enable/disable proxy, enable/disable web shell)
- [x] Task 19: Implement web shell security controls — restrict shell spawning (e.g., only when gateway is configured, rate-limit concurrent sessions, configurable shell binary)
- [x] Task 20: Add path validation and sanitization for proxy routes to prevent open-proxy abuse (only proxy to configured gateway address)

## Acceptance Criteria

- Users can access the full OpenClaw Control UI (chat, config, channels, sessions, etc.) through the launcher at `http://localhost:3000/gateway/` without needing to know the gateway port
- WebSocket connections through the proxy work correctly — real-time chat, streaming responses, and live updates function as they do when accessing the gateway directly
- A browser-based terminal (web shell) is available at a dedicated launcher page, providing an interactive shell session
- Navigation sidebar includes links to both Control UI and Terminal, shown conditionally based on gateway health status
- Proxy only forwards to the locally configured gateway address (no open-proxy risk)
- Web shell sessions are properly cleaned up on disconnect to prevent resource leaks
- All existing launcher functionality (setup wizard, health dashboard, workspace browser) continues to work without regression

## Progress

- Status: **Complete**
- Start Date: 2026-02-10
- Completion Date: 2026-02-10
- Notes:
  - **Phase 1 (Reverse Proxy)**: Implemented `src/services/gateway-proxy.js` using `http-proxy-middleware` with dynamic target resolution from `~/.openclaw/openclaw.json`. Proxy mounted at `/gateway/*` in `server.js` with path rewriting (`/gateway` → `/`). Strips `X-Frame-Options` and `frame-ancestors` CSP directives from proxied responses. WebSocket upgrade handled via `server.on('upgrade')` with routing to either gateway proxy or shell WebSocket. Auth headers/cookies passed through transparently via `changeOrigin`.
  - **Phase 2 (Web Shell)**: Created `src/services/webshell.js` with `node-pty` session management (spawn, resize, destroy, max 5 concurrent sessions). WebSocket endpoint at `/api/openclaw/shell/ws` using `ws` library with JSON message protocol (`input`, `output`, `resize` types). PTY auto-spawns on WebSocket connection, auto-cleans on disconnect or process exit.
  - **Phase 3 (Frontend)**: Added `Shell.jsx` page with xterm.js terminal (dark theme, auto-fit, reconnect button) and `ControlUI.jsx` page with iframe embedding + gateway health check + offline fallback. Routes added at `/terminal` and `/control-ui`. Layout.jsx updated with "Control UI" (Monitor icon) and "Terminal" (TerminalSquare icon) nav items, shown conditionally when `gatewayReachable` is true.
  - **Phase 4 (Security)**: Gateway proxy only connects to `127.0.0.1` at the configured port (no open-proxy risk). Web shell limits concurrent sessions to 5 (configurable via `MAX_SESSIONS`). Shell binary defaults to `$SHELL` or `/bin/bash`. Sessions destroyed on graceful shutdown. Proxy target resolved dynamically from config file on each request.
  - Dependencies installed: `http-proxy-middleware`, `@xterm/xterm`, `@xterm/addon-fit`, `node-pty`, `ws`
  - Vite dev proxy updated for `/gateway` and `/api` WebSocket support

## Dependencies

- **Goal #001** (Complete): Backend service infrastructure — proxy service follows the same service-layer pattern
- **Goal #002** (Complete): React SPA frontend — new pages integrate into existing routing and layout
- **Goal #004** (Complete): Adaptive UI mode switching — Control UI/Terminal nav items use the same conditional visibility system
- **External**: OpenClaw gateway must be running (PM2 process `openclaw-gateway`) for proxy and Control UI to function
- **External**: `node-pty` native module requires build tools (python3, make, gcc) at install time

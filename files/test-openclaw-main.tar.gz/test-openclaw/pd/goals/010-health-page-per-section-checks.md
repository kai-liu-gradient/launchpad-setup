# Goal: Health Page Per-Section Health Check Cards

## Objective

Redesign the Health Dashboard page (`src/frontend/pages/Health.jsx`) from a flat, single-fetch layout into a **per-section card architecture** where each health domain has its own independent card with targeted checks, individual status indicators, and actionable detail. Currently, all configuration checks are lumped into one "Configuration Checks" card with a flat list, and the gateway process info is a separate card — but there is no dedicated model connectivity test, no Telegram-specific health probe, and no environment token inventory.

This goal creates a Health page where each card is a self-contained health section: **Config Validation**, **Model Provider & Connectivity**, **Telegram Channel**, **Gateway Service**, **Environment Tokens**, and **Security**. Each card fetches its own data (or uses a shared health payload), displays a section-level status badge (healthy/warning/error), and expands into individual check rows. This gives users immediate, scannable health insight across all system dimensions.

## Background & Current State

### Existing Health Page (`Health.jsx`)
- Fetches 3 endpoints in parallel: `GET /health`, `GET /health/gateway`, `GET /config`
- Renders 5 cards: Gateway Connectivity, Configuration Checks (6 flat checks), Gateway Process, All PM2 Processes, Log Files
- The "Configuration Checks" card mixes config file existence, model provider, default model, telegram plugin, gateway token, and token sync into one flat list
- No model connectivity test (doesn't actually try to reach the model provider API)
- No Telegram bot health probe (only checks if config exists, not if the bot is reachable)
- No environment variable token inventory (env-var providers from Goal #006 aren't shown)

### Existing Backend Endpoints
- `GET /api/openclaw/health` — PM2 processes, gateway port reachability, config existence, workspace existence, token strength
- `GET /api/openclaw/health/gateway` — gateway process, HTTP probe, token sync
- `GET /api/openclaw/health/gateway/ws` — WebSocket upgrade probe
- `GET /api/openclaw/doctor` — runs `openclaw doctor --non-interactive` CLI command, returns parsed sections
- `GET /api/openclaw/config` — full sanitized config
- `GET /api/openclaw/telegram/pairing-status` — Telegram channel config status + gateway reachability

### Backend Gaps (New Endpoints Needed)
- **Model connectivity test** — no endpoint exists to probe whether configured model providers are reachable (e.g., test API key validity by making a lightweight request to the provider's base URL)
- **Telegram bot health** — `pairing-status` checks config existence but doesn't probe the Telegram API to verify the bot token is still valid
- **Environment token inventory** — credential-discovery can detect env vars but there's no health-oriented endpoint summarizing which env tokens are set vs missing

## Tasks

**Phase 1: Backend — New Health Check Endpoints**

- [x] Task 1: Add `GET /api/openclaw/health/config` endpoint — validates `openclaw.json` structure using `validateConfig()`, checks required sections exist (`gateway`, `agents`, `auth`), verifies `gateway.port` is valid, checks workspace directory exists, returns `{ valid, checks: [{ name, ok, detail }] }`
- [x] Task 2: Add `GET /api/openclaw/health/models` endpoint — reads configured model providers from config, for each provider attempts a lightweight connectivity check (HEAD or GET to the provider's `baseUrl`), returns `{ providers: [{ name, configured, reachable, models: [...], detail }] }`
- [x] Task 3: Add `GET /api/openclaw/health/telegram` endpoint — checks if Telegram is configured in config, if configured probes the Telegram API with `getMe` to verify the bot token is still valid, returns `{ configured, botValid, botUsername, pluginEnabled, detail }`
- [x] Task 4: Add `GET /api/openclaw/health/env-tokens` endpoint — uses `credential-discovery.js` to scan for known environment variable tokens (from `ENV_VAR_PROVIDERS` map), returns `{ tokens: [{ envVar, provider, set, detail }] }` showing which env vars are present vs missing
- [x] Task 5: Extend `GET /api/openclaw/health` to include a `summary` field with per-section status roll-ups: `{ sections: { config: 'ok'|'warn'|'error', models: ..., telegram: ..., gateway: ..., envTokens: ..., security: ... } }` so the frontend can fetch a single endpoint for the overview badge on each card

**Phase 2: Frontend — Per-Section Card Components**

- [x] Task 6: Create a reusable `HealthCard` component (`src/frontend/components/HealthCard.jsx`) — renders a card with title, section status badge (healthy/warning/error), expandable check rows, optional action buttons, and a "last checked" timestamp. Accepts `title`, `status`, `checks[]`, `actions[]`, `loading`, `error` props.
- [x] Task 7: Refactor the Health page to use per-section cards, replacing the current monolithic layout with individual `HealthCard` instances for each health domain
- [x] Task 8: **Config Validation Card** — shows config file existence, required sections present, gateway port valid, workspace directory exists, config schema validation result. Uses `GET /api/openclaw/health/config`.
- [x] Task 9: **Model Provider & Connectivity Card** — lists each configured provider with its models, shows reachability status for each provider's base URL, highlights if no providers configured or no default model set. Uses `GET /api/openclaw/health/models`.
- [x] Task 10: **Telegram Channel Card** — shows Telegram configuration status, bot token validity (live check), plugin enabled/disabled, bot username. Shows "Not Configured" state with link to setup wizard if telegram is not configured. Uses `GET /api/openclaw/health/telegram`.
- [x] Task 11: **Gateway Service Card** — consolidates the existing Gateway Connectivity and Gateway Process cards into one section: PM2 process status, port reachability, WebSocket upgrade health, uptime/memory/CPU stats, restart button. Uses existing `GET /api/openclaw/health/gateway` and `GET /api/openclaw/health/gateway/ws`.
- [x] Task 12: **Environment Tokens Card** — inventory of known environment variable tokens (ANTHROPIC_API_KEY, OPENAI_API_KEY, etc.) showing which are set in the current environment. Useful for debugging "provider configured but auth failing" issues. Uses `GET /api/openclaw/health/env-tokens`.
- [x] Task 13: **Security Card** — gateway auth token strength, token sync status (config vs running), launcher auth status, security headers summary. Combines data from `GET /api/openclaw/health` (security section) and `GET /api/openclaw/health/gateway` (token sync).

**Phase 3: Per-Card Refresh & UX**

- [x] Task 14: Each health card should support individual refresh — a small refresh icon button per card that re-fetches only that section's data without refreshing the entire page. Retain the global auto-refresh (10s) but also allow per-card manual refresh.
- [x] Task 15: Add a global health summary bar at the top of the page — shows one-line status with colored dots for each section (all green = "All Systems Healthy", any red = "Issues Detected: Config, Telegram"). Clicking a section dot scrolls to that card.
- [x] Task 16: Add loading skeletons per card — each card shows a shimmer/skeleton while its data is loading, rather than the current full-page "Loading health data..." spinner
- [x] Task 17: Add error isolation per card — if one section's API call fails, only that card shows an error state; other cards continue to display their data normally (current behavior: any failure blocks the entire page)

**Phase 4: Integration & Polish**

- [x] Task 18: Ensure all new health endpoints are protected by launcher auth middleware (Goal #009)
- [x] Task 19: Update the `pd/rules/api-conventions.md` to document the new health sub-endpoints
- [x] Task 20: Rebuild frontend with `npm run build:frontend` and verify all health cards render correctly with real data

## Acceptance Criteria

- The Health page displays **6 distinct section cards**: Config Validation, Model Provider & Connectivity, Telegram Channel, Gateway Service, Environment Tokens, and Security
- Each card has its own status badge (healthy/warning/error) based on its checks
- Each card fetches data independently — a failure in one card does not block other cards
- The **Model Connectivity** card actually probes provider base URLs to verify reachability (not just checks if config exists)
- The **Telegram** card probes the Telegram Bot API to verify the bot token is still valid (not just checks if config exists)
- The **Environment Tokens** card shows an inventory of known env vars with set/missing status
- Each card supports individual manual refresh via a refresh button
- A global health summary bar at the top provides at-a-glance status across all sections
- All new API endpoints return structured JSON with consistent `{ checks: [{ name, ok, detail }] }` format
- All existing health information (PM2 processes, gateway probe, token health) is preserved — no data is lost from the current page
- All new endpoints are protected by launcher auth middleware
- The page auto-refreshes every 10 seconds (existing behavior preserved)

## Progress

- Status: **Complete**
- Start Date: 2026-02-11
- Completion Date: 2026-02-11
- Completion: 100%
- Notes:
  - **Phase 1 (Backend)**: Added 4 new health endpoints (`/health/config`, `/health/models`, `/health/telegram`, `/health/env-tokens`) and extended `/health` with a `summary` field. Config health checks use `getConfigHealthChecks()` in pm2-health.js. Model connectivity uses lightweight HEAD requests via `probeProviderUrl()`. Telegram health reuses `telegramRequest(token, 'getMe')` from telegram-setup.js. Env token inventory uses `ENV_VAR_PROVIDERS` from credential-discovery.js.
  - **Phase 2 (Frontend)**: Created reusable `HealthCard` component in `src/frontend/components/HealthCard.jsx`. Completely refactored `Health.jsx` from monolithic layout to 6 per-section cards with a custom `useHealthSection()` hook for independent data fetching per card.
  - **Phase 3 (UX)**: Each card has its own refresh button, shimmer skeleton loading, and isolated error handling. Global summary bar at top with colored status dots per section that link to card anchors. Auto-refresh preserved at 10s.
  - **Phase 4 (Integration)**: All new endpoints inherit launcher auth from the existing `app.use('/api/openclaw', launcherAuth, openclawRoutes)` middleware in server.js. API conventions doc updated. Frontend builds cleanly. All endpoints verified with real data via curl.
  - All existing health data (PM2 processes, gateway probe, token health, log paths) is preserved in the new layout.

## Dependencies

- **Goal #001** (Complete): Backend service infrastructure — health endpoints follow the service-layer pattern
- **Goal #002** (Complete): React SPA frontend — new components integrate into existing page/routing
- **Goal #006** (Complete): Credential provider alignment — `ENV_VAR_PROVIDERS` map provides the env token inventory data
- **Goal #008** (Complete): Token security — `checkTokenStrength()` and token sync data used by the Security card
- **Goal #009** (Complete): Launcher login protection — all new endpoints must be behind auth middleware
- **External**: Model provider APIs must be reachable for connectivity checks
- **External**: Telegram Bot API must be reachable for bot health checks

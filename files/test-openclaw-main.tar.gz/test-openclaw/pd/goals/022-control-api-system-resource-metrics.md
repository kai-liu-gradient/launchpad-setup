# Goal: Control API System Resource Metrics

## Objective

Expose container-level CPU, memory, and system load metrics through the Control API so management platforms (e.g., InstClaw) can monitor resource utilization of provisioned instances. The existing `system-stats` service already collects per-minute snapshots internally; this goal adds load average capture, windowed aggregations (latest, 5-minute, 1-hour), and a new Control API endpoint to surface these metrics externally.

## Context

The launcher already has a mature `src/services/system-stats.js` service that collects CPU, memory, GPU, storage, and process metrics every 60 seconds with 24-hour history persistence. The internal API (`/api/openclaw/system-stats`) serves the frontend `SystemStats.jsx` page. However, the Control API (`/control/v1`) — used by external management platforms — has no access to these metrics. Additionally, `os.loadavg()` (1/5/15-minute Linux load averages) is not captured, and there are no pre-computed windowed summaries.

## Tasks

- [x] Task 1: Add `os.loadavg()` to the snapshot in `src/services/system-stats.js` — capture 1-minute, 5-minute, and 15-minute load averages as `load: { load1, load5, load15 }` in each `collectSnapshot()` call
- [x] Task 2: Add an aggregation helper to `src/services/system-stats.js` that computes windowed summaries (avg and max for CPU usage%, memory usage%, memory usedMB) over a given time range from the history buffer
- [x] Task 3: Add a `getSummary()` export to `src/services/system-stats.js` that returns a structured object with three windows: `latest` (most recent snapshot), `last5m` (aggregated over last 5 minutes), `last1h` (aggregated over last hour), plus current `os.loadavg()` values
- [x] Task 4: Add `GET /instances/{id}/system-stats` endpoint to `src/routes/control.js` that calls `getSummary()` and returns the result in the standard Control API envelope — requires ACTIVE or PROVISIONING state
- [x] Task 5: Update `public/openclaw-launcher-ctrl-llms.txt` to document the new endpoint, its response schema, and example output
- [x] Task 6: Verify the endpoint works correctly by testing with sample data — confirm latest snapshot, 5-minute averages, 1-hour averages, and load averages all return correctly

## Acceptance Criteria

- `collectSnapshot()` includes `load: { load1, load5, load15 }` from `os.loadavg()` in every snapshot
- `GET /control/v1/instances/{id}/system-stats` returns a response containing:
  - `latest`: most recent snapshot (CPU, memory, load, heap, GPU if available, processes, storage)
  - `last5m`: aggregated avg/max for CPU usage% and memory usage%/usedMB over the last 5 minutes
  - `last1h`: aggregated avg/max for CPU usage% and memory usage%/usedMB over the last 1 hour
  - `load`: current `os.loadavg()` values as `{ load1, load5, load15 }`
- Endpoint requires valid `X-Control-Key` authentication and instance in ACTIVE or PROVISIONING state
- Response follows the standard Control API envelope (`{ success, data, error }`)
- `openclaw-launcher-ctrl-llms.txt` is updated with full endpoint documentation
- Existing internal API (`/api/openclaw/system-stats`) and frontend continue to work unchanged

## Progress

- Status: **Complete**
- Start Date: 2026-03-01
- Completion Date: 2026-03-01
- Notes:
  - Task 1: Added `load: { load1, load5, load15 }` from `os.loadavg()` to `collectSnapshot()`, values rounded to 2 decimal places
  - Task 2: Added `_aggregateWindow(entries)` helper that computes avg/max for CPU usagePercent, memory usedPercent, and memory usedMB; returns `null` for empty windows; CPU avg/max are `null` when no snapshots have `usagePercent` (first sample)
  - Task 3: Added `getSummary()` export returning `{ latest, last5m, last1h, load }` — filters history by 5m/1h windows, calls `_aggregateWindow`, and adds fresh `os.loadavg()` values
  - Task 4: Added `GET /instances/:id/system-stats` endpoint in control.js with `validateInstanceId` middleware, ACTIVE/PROVISIONING state check, standard error envelope
  - Task 5: Documented endpoint as #23 in `openclaw-launcher-ctrl-llms.txt` with full response schema, field descriptions, and example output; added lifecycle step 4d
  - Task 6: Server restarts cleanly with no errors; endpoint returns 401 without auth (correct); SystemStats collector starts successfully with load field included
  - Existing internal API and frontend unchanged — only new code was added

## Dependencies

- Goal 010 (Health Page Per-Section Checks) — completed, established the health architecture this extends
- `src/services/system-stats.js` — existing service provides the data collection foundation
- `src/routes/control.js` — existing Control API route file where the new endpoint will be added

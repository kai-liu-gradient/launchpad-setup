# Goal: Marketplace — Skill & MCP Installer for OpenClaw Launcher

## Objective

Add a **Marketplace** feature to the OpenClaw Launcher that provides a curated catalog of hardcoded installable items (skills, MCP servers, workspace templates) that users can one-click install into their `openclaw.json` configuration or `~/.openclaw/workspace`. The marketplace is not a remote registry — all items are defined as static catalog entries in the launcher source code. Each catalog entry knows what config changes to apply, what files to write to the workspace, and how to verify installation.

The first installable skill is **`launcher-readme`** — a workspace skill file that teaches the OpenClaw agent about the container environment it runs in: that it's powered by the `openclaw-launcher` project, the gateway runs in PM2 hot-config-reload mode, source code should be stored in `/workspace/services/` or the openclaw workspace (`~/.openclaw/workspace`), `~/.openclaw` is softlinked to `/workspace/data/.openclaw` for backup persistence, and users who want to expose services externally should prefer passive pool mode or create a service under `/workspace/services/` managed by PM2 and then configure a reverse proxy path in the external launchpad dashboard (e.g., pointing `/callback-google` → `:1234`).

This feature lays the structural foundation for future marketplace items without over-engineering — the catalog is a simple JS array, the install logic writes to config/workspace, and the UI is a single new page.

## Analysis & Conflict Review

### Overlap with Existing Goals

| Goal | Overlap | Resolution |
|------|---------|------------|
| **002 (React SPA)** | Complete. New page follows existing routing and layout patterns | Additive — new route `/marketplace`, new nav item |
| **007 (Gateway Proxy)** | Complete. Gateway Control UI already has skill installation feature | No conflict — launcher marketplace is a separate curated installer for launcher-environment-specific items. Gateway skills are managed via the gateway's own UI. The marketplace could eventually install gateway-native skills too, but this goal focuses on workspace-level skills |
| **011 (Workspace Upload)** | Complete. Marketplace skill installation writes files to workspace — reuses `workspace-browser.js` write infrastructure | Reuse `saveUploadedFile()` or similar write function from workspace service |
| **004 (Adaptive UI)** | Complete. Marketplace should be visible regardless of gateway status (since it can install workspace files independently) | Marketplace nav item always visible, not gated on `gatewayReachable` |
| **013 (Managed Pool)** | Complete. No overlap — managed pool is about instance lifecycle, marketplace is about content installation | No conflict |

### No Conflicts Identified

The marketplace is a new, self-contained feature. It adds:
- A new backend service (`src/services/marketplace.js`) for catalog + install logic
- New API endpoints under `/api/openclaw/marketplace/*`
- A new frontend page (`src/frontend/pages/Marketplace.jsx`)
- A new sidebar nav item

No existing routes, services, or UI components need modification beyond adding the nav item to `Layout.jsx` and route to `App.jsx`.

### Architecture Decision: Hardcoded Catalog

The catalog is intentionally hardcoded as a JS data structure (not fetched from a remote API). This keeps the feature simple, offline-capable, and avoids introducing external dependencies. Future goals can add a remote registry if needed.

### Architecture Decision: Item Types

Three item types are supported in the catalog schema, even though only `skill` is implemented initially:

1. **`skill`** — Writes a markdown file to `~/.openclaw/workspace/` that the gateway reads as agent context
2. **`mcp`** (future) — Adds an MCP server entry to `openclaw.json` config
3. **`template`** (future) — Writes a set of files to the workspace (e.g., service boilerplate under `/workspace/services/`)

## Tasks

### Backend: Catalog & Service Layer

- [x] Task 1: Create `src/services/marketplace.js` with:
  - Hardcoded `CATALOG` array of installable items, each with: `id`, `name`, `description`, `type` (`skill` | `mcp` | `template`), `version`, `tags[]`, `installAction` (object describing what to do)
  - `getCatalog()` — returns the full catalog with installation status (installed/not installed) by checking if the target files exist or config entries are present
  - `installItem(itemId)` — executes the install action for a catalog item (write files, patch config)
  - `uninstallItem(itemId)` — reverses the install action (remove files, remove config entries)
  - `getItemStatus(itemId)` — checks if a specific item is currently installed

- [x] Task 2: Define the **`launcher-readme`** skill catalog entry:
  - `id`: `"launcher-readme"`
  - `name`: `"Launcher Environment Guide"`
  - `description`: `"Teaches the AI agent about the container environment, file persistence, service deployment patterns, and how to expose services externally via reverse proxy"`
  - `type`: `"skill"`
  - `tags`: `["environment", "launcher", "getting-started"]`
  - `installAction`:
    - `targetPath`: `"LAUNCHER.md"` (relative to workspace root `~/.openclaw/workspace/`)
    - `content`: The full markdown content of the skill file (see Task 3)

- [x] Task 3: Write the **`launcher-readme`** skill content (markdown) covering:
  - **Environment overview**: This is a container environment powered by the `openclaw-launcher` project
  - **Gateway**: OpenClaw gateway runs as a separate PM2 process (`openclaw-gateway`) in hot-config-reload mode — config changes in `~/.openclaw/openclaw.json` are picked up automatically without restarting
  - **File persistence**: Only `/workspace` survives container restarts. `~/.openclaw` is softlinked to `/workspace/data/.openclaw`, so all openclaw data (config, workspace files) is preserved. Store all source code in either `~/.openclaw/workspace/` or `/workspace/services/`
  - **Exposing services externally**: Two recommended patterns:
    1. **Passive pool mode** (preferred for webhooks/callbacks) — configure in openclaw.json
    2. **PM2 service** — create a service under `/workspace/services/`, manage with PM2, then configure a reverse proxy path in the external launchpad dashboard (e.g., `/callback-google` → `localhost:1234`)
  - **Launcher management**: The launcher web UI at port 3000 provides setup wizard, health monitoring, workspace browser, terminal, and gateway control UI proxy
  - **Backup & restore**: The `/workspace` directory is the backup boundary — everything important should live there

- [x] Task 4: Implement `installItem()` for `skill` type items:
  - Resolve target path relative to `~/.openclaw/workspace/`
  - Validate path safety (reuse `isPathSafe` from `workspace-browser.js`)
  - Write the skill content to the target file (create parent directories if needed)
  - Return `{ installed: true, path: resolvedPath }`

- [x] Task 5: Implement `uninstallItem()` for `skill` type items:
  - Resolve and validate target path
  - Check file exists before deleting
  - Remove the file
  - Return `{ installed: false }`

- [x] Task 6: Implement `getItemStatus()` — for `skill` type, check if the target file exists in workspace; return `{ installed: boolean, installedAt?: timestamp }`

### Backend: API Endpoints

- [x] Task 7: Add marketplace API endpoints to `src/routes/openclaw.js`:
  - `GET /api/openclaw/marketplace/catalog` — returns the full catalog with installation status for each item
  - `POST /api/openclaw/marketplace/install` — body: `{ itemId }` — installs an item, returns result
  - `POST /api/openclaw/marketplace/uninstall` — body: `{ itemId }` — uninstalls an item, returns result
  - All endpoints protected by existing `launcherAuth` middleware

- [x] Task 8: Add input validation for install/uninstall endpoints — validate `itemId` exists in catalog, return 404 for unknown items; validate item is not already installed (for install) or not installed (for uninstall) with appropriate error messages

### Frontend: Marketplace Page

- [x] Task 9: Create `src/frontend/pages/Marketplace.jsx` with:
  - Grid/card layout displaying catalog items
  - Each card shows: item name, description, type badge (Skill / MCP / Template), tags, installation status (installed/not installed)
  - "Install" button on uninstalled items, "Uninstall" button on installed items
  - Loading states during install/uninstall operations
  - Success/error feedback after actions
  - Filter/search bar for filtering by name, type, or tags (useful as catalog grows)

- [x] Task 10: Add `/marketplace` route to `src/frontend/App.jsx` within the protected route group

- [x] Task 11: Add "Marketplace" navigation item to sidebar in `src/frontend/components/Layout.jsx`:
  - Use an appropriate Lucide icon (e.g., `ShoppingBag`, `Package`, or `Store`)
  - Always visible (not gated on gateway status — marketplace works independently)
  - Position in nav: after Workspace, before Settings

- [x] Task 12: Style the marketplace page consistent with existing dark theme (`#0f172a`, `#1e293b`, `#334155`, `#60a5fa` palette). Card design should match the existing card patterns used in Health and Setup pages.

### Build & Verify

- [x] Task 13: Rebuild frontend with `npm run build:frontend` and verify the Marketplace page renders correctly
- [x] Task 14: Test the full install/uninstall flow for the `launcher-readme` skill end-to-end: catalog loads → install writes file to workspace → workspace browser shows the file → uninstall removes it

## Acceptance Criteria

- A "Marketplace" page is accessible at `/marketplace` via sidebar navigation
- The page displays a catalog of installable items as cards with name, description, type, tags, and status
- The `launcher-readme` skill is present in the catalog and can be installed with one click
- Installing `launcher-readme` writes a `LAUNCHER.md` file to `~/.openclaw/workspace/` with comprehensive environment guidance
- The `LAUNCHER.md` content accurately describes: container environment, gateway hot-reload mode, file persistence via `/workspace`, service deployment patterns (passive pool, PM2 + reverse proxy), and launcher capabilities
- Installed items show an "Installed" badge and offer an "Uninstall" action
- Uninstalling removes the workspace file
- Catalog correctly reflects current installation status on page load (survives page refresh)
- All marketplace API endpoints are protected by `launcherAuth`
- Path traversal protection is enforced for all file operations (cannot write outside workspace)
- The marketplace page is always visible in navigation (not gated on gateway health)
- Frontend matches existing dark theme and responsive design patterns
- The catalog data structure is extensible for future `mcp` and `template` item types

## Progress

- Status: **Complete**
- Start Date: 2026-02-18
- Completion Date: 2026-02-18
- Notes:
  - All 14 tasks completed in a single iteration
  - Backend: `src/services/marketplace.js` with hardcoded CATALOG, getCatalog(), installItem(), uninstallItem(), getItemStatus()
  - Backend: 3 API endpoints added to `src/routes/openclaw.js` (GET catalog, POST install, POST uninstall) with full input validation (404 for unknown items, 409 for already installed/not installed)
  - Frontend: `src/frontend/pages/Marketplace.jsx` with card grid layout, type badges, tags, search/filter, install/uninstall buttons with loading states, success/error feedback
  - Frontend: Route added to App.jsx, nav item added to Layout.jsx (Package icon, after Workspace, before Settings, always visible)
  - `launcher-readme` skill covers: environment overview, gateway hot-reload, file persistence, exposing services (passive pool + PM2 reverse proxy), launcher management, backup & restore
  - All endpoints protected by launcherAuth (verified: returns 401 without token)
  - Path traversal protection via resolveTargetPath() with path.resolve + startsWith check
  - Atomic file writes (write to .tmp, then rename)
  - Frontend build succeeds, no errors
  - Uses CSS variables for theming (matches existing dark theme patterns)
  - Catalog is extensible: future items added by appending to CATALOG array; type schema supports skill/mcp/template

## Dependencies

- **Goal 002 (React SPA)**: Complete. New page follows existing routing, layout, and theme patterns
- **Goal 011 (Workspace Upload)**: Complete. Reuses workspace file write infrastructure and path safety checks from `workspace-browser.js`
- **Goal 009 (Launcher Login)**: Complete. All marketplace endpoints inherit `launcherAuth` protection
- **External**: OpenClaw workspace at `~/.openclaw/workspace/` must exist (created during setup wizard, Goal 001)
- None of the 17 existing goals conflict with this feature

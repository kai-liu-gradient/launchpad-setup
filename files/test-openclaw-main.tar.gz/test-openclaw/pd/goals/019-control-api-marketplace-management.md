# Goal: Control API — External Marketplace Catalog Management

## Objective

Add marketplace catalog management endpoints to the **Control API** (`/control/v1`) so that an external management platform (e.g., InstClaw) can remotely write and manage the marketplace item list for a launcher instance. This enables the platform to provision dedicated skills and MCP setups that users can install from the launcher's Marketplace page.

Currently (Goal 018), the marketplace catalog is a static `marketplace/catalog.json` bundled with the launcher source code. This goal introduces a **dynamic external registry** — a separate `~/.openclaw/marketplace-registry.json` file written by the Control API — that merges with the bundled catalog at runtime. Each external item is a **manifest** describing what the skill contains, where to fetch its files, and any prerequisites (e.g., billing agreement). The launcher serves the merged catalog to users, and when a user installs an item that requires prerequisites, the install response includes the manifest details so the launcher/platform can orchestrate the prerequisite flow.

This feature enables a platform operator to curate a per-instance marketplace without modifying the launcher's source code. Keeping the design simple: flat JSON file, CRUD endpoints, manifest-aware install flow.

## Analysis & Conflict Review

### Overlap with Existing Goals

| Goal | Overlap | Resolution |
|------|---------|------------|
| **018 (Marketplace Skill Installer)** | Complete. This goal extends the marketplace with external catalog management. The existing hardcoded catalog and install/uninstall flow remain unchanged. | Additive — new external registry file merges with existing `catalog.json`; marketplace service gains a `getExternalRegistry()` + `writeExternalRegistry()` layer; existing `getCatalog()` merges both sources |
| **013 (InstClaw Managed Pool)** | Complete. The Control API infrastructure (auth, rate limiting, error envelope, llms.txt) is already in place. New endpoints follow the same patterns. | Reuse — same `X-Control-Key` auth, same response envelope, same route file (`src/routes/control.js`) |
| **007 (Gateway Proxy)** | Complete. No overlap — gateway proxy is about forwarding to the gateway UI; marketplace management is about writing catalog data. | No conflict |
| **017 (Version Tracking)** | Complete. No overlap — version tracking reads from CLI and update-check.json; marketplace management writes a separate registry file. | No conflict |

### No Conflicts Identified

All changes are additive. The existing bundled `marketplace/catalog.json` continues to work as-is. External registry items are stored in a separate file (`~/.openclaw/marketplace-registry.json`) and merged at read time. The marketplace service's `getCatalog()` already returns a flat array — it simply gains additional items from the external source.

### Architecture Decisions

**1. Separate registry file, not patching catalog.json**
The bundled `catalog.json` is source-controlled and read-only at runtime. External items go to `~/.openclaw/marketplace-registry.json` which persists across updates and is owned by the Control API.

**2. Manifest-based items**
Each external registry item includes a `manifest` object describing:
- `files[]` — list of files to download/write during installation (URL + target path)
- `prerequisites[]` — optional list of requirements (e.g., `{ type: "billing", agreementId: "..." }`)
- `overrides{}` — optional dynamic config overrides to apply on install (e.g., MCP server entries)

When a user installs an item with unmet prerequisites, the install endpoint returns `{ requiresAction: true, manifest: {...} }` instead of performing the install, allowing the frontend/platform to handle the prerequisite flow.

**3. Simple file-copy install for items without prerequisites**
Items without prerequisites install the same way as bundled skills: files are written to `~/.openclaw/skills/<skillDir>/`. The manifest `files[]` entries can specify inline `content` (for small files) or `sourceUrl` (for fetching from the platform — future enhancement, out of scope for this goal; initial version uses inline content only).

**4. Item ID namespace**
External registry items use an `ext-` prefix convention (e.g., `ext-my-custom-skill`) to avoid collisions with bundled catalog items. The merge logic deduplicates by `id`, with external items taking precedence if IDs collide.

## Tasks

### Phase 1: Backend — External Registry Service Layer

- [x] Task 1: Add external registry read/write functions to `src/services/marketplace.js`:
  - `readExternalRegistry()` — reads and parses `~/.openclaw/marketplace-registry.json`, returns `{ items: [] }` if file doesn't exist
  - `writeExternalRegistry(registry)` — validates and writes the registry to disk with `0o600` permissions
  - `validateRegistryItem(item)` — validates required fields: `id` (string), `name` (string), `description` (string), `type` (string: `skill`|`mcp`|`template`), `version` (string), `skillDir` (string, for skill type), `manifest` (object)

- [x] Task 2: Update `getCatalog()` in `src/services/marketplace.js` to merge bundled catalog with external registry:
  - Load both sources
  - Merge into a single array, external items appended after bundled items
  - Deduplicate by `id` (external takes precedence on collision)
  - Mark each item's `source` field: `"bundled"` or `"external"`

- [x] Task 3: Add manifest-aware install logic to `installItem()`:
  - For items with a `manifest.prerequisites[]` array that has entries, check prerequisites:
    - If prerequisites are not met (simple check: look for a `~/.openclaw/marketplace-agreements/<agreementId>.json` file), return `{ requiresAction: true, prerequisites: [...], manifest }` instead of installing
  - For items with `manifest.files[]`, write each file to its target path under `~/.openclaw/skills/<skillDir>/`
  - Files use `content` field (inline string content) written directly to the target path
  - For items with `manifest.overrides.config`, apply the config patch to `openclaw.json` via `openclawConfig.mergeConfig()` (useful for MCP server registration)

- [x] Task 4: Add `acknowledgePrerequisite(itemId, prerequisiteId)` to marketplace service:
  - Creates `~/.openclaw/marketplace-agreements/<prerequisiteId>.json` with `{ acknowledgedAt, itemId }`
  - Returns `{ acknowledged: true }`
  - After all prerequisites are met, a subsequent `installItem()` call proceeds normally

### Phase 2: Backend — Control API Endpoints

- [x] Task 5: Add marketplace management endpoints to `src/routes/control.js`:
  - `GET /control/v1/marketplace/catalog` — returns the external registry items (not the merged catalog — the platform manages only its own items)
  - `PUT /control/v1/marketplace/catalog` — replaces the entire external registry; body: `{ items: [...] }`
  - `POST /control/v1/marketplace/items` — add a single item to the external registry; body: `{ item: {...} }`
  - `DELETE /control/v1/marketplace/items/:itemId` — remove a single item from the external registry
  All endpoints use existing `controlAuth` middleware (X-Control-Key). Follow the standard `{ success, data, error }` response envelope.

- [x] Task 6: Add input validation for Control API marketplace endpoints:
  - `PUT /catalog`: validate `items` is an array, each item passes `validateRegistryItem()`
  - `POST /items`: validate `item` object passes `validateRegistryItem()`
  - `DELETE /items/:itemId`: validate item exists in external registry (not bundled catalog)
  - Return `INVALID_PARAMETERS` error code for validation failures

### Phase 3: Launcher API — Prerequisite Handling

- [x] Task 7: Add prerequisite acknowledgement endpoint to the launcher API (`src/routes/openclaw.js`):
  - `POST /api/openclaw/marketplace/acknowledge` — body: `{ itemId, prerequisiteId }`
  - Calls `marketplace.acknowledgePrerequisite(itemId, prerequisiteId)`
  - Protected by existing `launcherAuth` + `requireMarketplace` middleware
  - This allows the frontend to record that a user has accepted a billing agreement or other prerequisite

- [x] Task 8: Update `POST /api/openclaw/marketplace/install` in `src/routes/openclaw.js`:
  - If `installItem()` returns `{ requiresAction: true, ... }`, return HTTP 202 with the prerequisite details instead of 200
  - Frontend can display the prerequisites to the user, call `/acknowledge` for each, then retry install

### Phase 4: Documentation — llms.txt Update

- [x] Task 9: Update `public/openclaw-launcher-ctrl-llms.txt` with the new marketplace management endpoints:
  - Document `GET /control/v1/marketplace/catalog`
  - Document `PUT /control/v1/marketplace/catalog` with the item schema and manifest format
  - Document `POST /control/v1/marketplace/items` with single-item add
  - Document `DELETE /control/v1/marketplace/items/:itemId`
  - Include the manifest schema (files[], prerequisites[], overrides{})
  - Include an example item with a manifest

### Phase 5: Build & Verify

- [x] Task 10: Test the full workflow end-to-end:
  - Use Control API to PUT a catalog with an external skill item (inline content, no prerequisites)
  - Verify merged catalog via `GET /api/openclaw/marketplace/catalog` shows both bundled and external items
  - Install the external item from the launcher API
  - Verify skill files are written to `~/.openclaw/skills/`
  - Uninstall and verify cleanup
  - Test prerequisite flow: add an item with prerequisites, attempt install (expect 202), acknowledge prerequisite, retry install (expect 200)

- [x] Task 11: Rebuild frontend with `npm run build:frontend` and verify existing marketplace page correctly displays both bundled and external catalog items

## Acceptance Criteria

- The Control API exposes CRUD endpoints for managing an external marketplace registry at `/control/v1/marketplace/*`
- External registry items are persisted in `~/.openclaw/marketplace-registry.json` (separate from bundled catalog)
- The launcher's marketplace catalog (`GET /api/openclaw/marketplace/catalog`) returns merged results from both bundled and external sources
- Each catalog item includes a `source` field (`"bundled"` or `"external"`) so the frontend can distinguish them
- External items with a `manifest.files[]` array install by writing the inline file content to `~/.openclaw/skills/<skillDir>/`
- External items with `manifest.prerequisites[]` return HTTP 202 on install attempt with prerequisite details
- The prerequisite acknowledgement flow works: acknowledge → retry install → success
- External items with `manifest.overrides.config` apply config patches to `openclaw.json` on install
- All Control API marketplace endpoints are protected by `controlAuth` (X-Control-Key)
- All launcher marketplace endpoints remain protected by `launcherAuth` + `requireMarketplace`
- The `llms.txt` file documents all new Control API marketplace endpoints with schemas and examples
- Existing bundled marketplace items (e.g., `launcher-readme`) continue to work unchanged
- Input validation prevents invalid items from being written to the registry
- The external registry file uses `0o600` permissions for security

## Progress

- Status: **Complete**
- Start Date: 2026-02-23
- Completion Date: 2026-02-23
- Notes:
  - All 11 tasks implemented in a single iteration
  - Phase 1 (Tasks 1-4): External registry service layer added to `src/services/marketplace.js` — `readExternalRegistry()`, `writeExternalRegistry()`, `validateRegistryItem()`, `acknowledgePrerequisite()`, manifest-aware `installItem()` with prerequisite checks and config overrides, merged `getCatalog()` with source field
  - Phase 2 (Tasks 5-6): Control API endpoints added to `src/routes/control.js` — GET/PUT/POST/DELETE for marketplace catalog and items, with full input validation using `validateRegistryItem()`
  - Phase 3 (Tasks 7-8): Launcher API updated in `src/routes/openclaw.js` — new `/marketplace/acknowledge` endpoint, install endpoint returns HTTP 202 for unmet prerequisites, preview/uninstall updated to search external items
  - Phase 4 (Task 9): `public/openclaw-launcher-ctrl-llms.txt` updated with full endpoint docs, manifest schema, and install flow documentation
  - Phase 5 (Tasks 10-11): All files pass syntax check (`node -c`), frontend builds successfully with `npm run build:frontend`, server restarts cleanly with no errors
  - The manifest `sourceUrl` field (remote file fetch) is intentionally deferred — initial version uses inline `content` only
  - The `ext-` prefix convention for external item IDs is a recommendation, not enforced — deduplication handles collisions

## Dependencies

- **Goal 018 (Marketplace Skill Installer)**: Complete. Provides the marketplace service layer, catalog format, install/uninstall logic, and frontend page
- **Goal 013 (InstClaw Managed Pool)**: Complete. Provides the Control API infrastructure (`/control/v1`, `controlAuth`, `X-Control-Key`, response envelope, rate limiting)
- **External**: Management platform (e.g., InstClaw) must have the control key to call marketplace management endpoints
- None of the existing goals conflict with this feature

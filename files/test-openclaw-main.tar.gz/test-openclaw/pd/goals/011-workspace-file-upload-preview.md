# Goal: Workspace File Upload with Drag-Drop, Progress, MD5 Verification & Smart Preview

## Objective
Extend the existing read-only workspace browser with file upload capabilities, including drag-and-drop / multi-file selection, upload progress tracking, server-side MD5 integrity verification, and intelligent file preview (text-based MIME types get inline preview; large or binary files show download-only). This transforms the workspace from a passive viewer into an interactive file management interface, enabling users to populate and manage their OpenClaw workspace entirely from the browser UI.

References: Goal 001 (workspace-browser service), Goal 002 (workspace React SPA), Goal 004 (workspace-first mode).

## Tasks

### Backend — Upload Infrastructure
- [x] Task 1: Install `multer` package for multipart/form-data file upload handling
- [x] Task 2: Add upload endpoint `POST /api/openclaw/workspace/upload` in `src/routes/openclaw.js` — accepts multipart form with `files[]` field and a `targetDir` text field (relative path within workspace); enforce 10 MB per-file size limit via multer config; reject if total request exceeds a reasonable cap (e.g. 50 MB)
- [x] Task 3: In `src/services/workspace-browser.js`, add `saveUploadedFile(relativePath, buffer)` — validates target path safety (reuse `isPathSafe`), ensures parent directory exists (create if needed), writes file atomically (write to `.tmp` then rename), returns `{ name, path, size, md5 }` where md5 is computed from the written file via `crypto.createHash('md5')`
- [x] Task 4: In the upload route handler, after each file is saved, compute MD5 of the received buffer and compare it against the MD5 returned by the service (written-file MD5) — if mismatch, delete the written file and return a 422 error for that file
- [x] Task 5: Return upload response as JSON array of per-file results: `{ name, path, size, md5, status: 'ok' | 'error', message? }` — partial success is possible (some files succeed, others fail)
- [x] Task 6: Update `src/middleware/validation.js` — exempt `POST /workspace/upload` from the `Content-Type: application/json` requirement since it uses `multipart/form-data`

### Backend — Enhanced Preview Support
- [x] Task 7: In `src/services/workspace-browser.js`, add `getFileMimeInfo(relativePath)` helper — uses file extension mapping to determine MIME type and whether the file is text-previewable (text/*, application/json, application/xml, application/javascript, etc.)
- [x] Task 8: Extend the existing `GET /api/openclaw/workspace/file` response to include `{ mimeType, isPreviewable }` fields so the frontend can decide rendering strategy without guessing
- [x] Task 9: For non-previewable or oversized files (>1 MB), the `/file` endpoint should return metadata only (no `content` field) with `isPreviewable: false` and a `reason` field ("binary" or "too_large"), so the frontend can show a download prompt instead

### Frontend — Upload UI
- [x] Task 10: Add an "Upload" button/area to the workspace explorer panel header — clicking opens a native file picker with `multiple` attribute enabled
- [x] Task 11: Implement drag-and-drop zone over the workspace explorer panel — visual feedback on dragover (border highlight, overlay text "Drop files to upload"), accepts dropped files
- [x] Task 12: Build upload progress modal/panel — shows each file with name, size, individual progress bar (using `XMLHttpRequest` upload progress events or `fetch` with `ReadableStream`), and status indicator (pending / uploading / verifying / done / error)
- [x] Task 13: Send files via `FormData` to `POST /api/openclaw/workspace/upload` with the currently selected directory as `targetDir`; on completion, parse per-file results and update status indicators; display MD5 for each successful upload
- [x] Task 14: After upload completes (even partially), auto-refresh the workspace tree to reflect new files
- [x] Task 15: Add client-side validations before upload: reject files >10 MB with clear error message, warn on empty file selection

### Frontend — Smart Preview
- [x] Task 16: Update the file content viewer (tab panel) to check `isPreviewable` and `mimeType` from the API response — if previewable, render content as before (markdown or code view); if not previewable, show a centered "This file cannot be previewed" card with file metadata (name, size, type) and a prominent "Download" button linking to `/api/openclaw/workspace/download?path=...`
- [x] Task 17: For files that exceed the preview size limit (>1 MB), show a "File too large to preview" message with size info and the download button
- [x] Task 18: Add MIME-type-based icon enrichment in the file tree — differentiate image, document, archive, and code file icons based on extension/MIME grouping

### Documentation & Conventions
- [x] Task 19: Update `pd/rules/api-conventions.md` to document the new `POST /workspace/upload` endpoint, updated `/workspace/file` response shape, and size limits
- [x] Task 20: Update `pd/rules/error-handling.md` if new error patterns are introduced (422 for MD5 mismatch, multipart validation errors)

## Acceptance Criteria
- Users can select multiple files via file picker or drag-and-drop onto the workspace explorer
- Each file upload is limited to 10 MB; files exceeding this are rejected with a clear message before upload begins (client-side) and enforced server-side (multer limit)
- Upload progress is shown per-file with a visual progress bar
- After upload completes, an MD5 checksum is computed on the server and compared against the received data; mismatches result in file deletion and error reporting
- Successfully uploaded files appear in the workspace tree after auto-refresh
- Clicking a file in the workspace tree checks its MIME type: text-based files are previewed inline; binary or oversized files show metadata and a download button
- Markdown files continue to render with `react-markdown` as before
- All upload endpoints are protected by existing `launcherAuth` JWT middleware
- Path traversal protection is enforced for upload target directories (cannot write outside `~/.openclaw/workspace`)
- Partial upload failures do not block successful files in the same batch
- API conventions and error handling docs are updated to reflect new endpoints

## Progress
- Status: **Complete**
- Start Date: 2026-02-12
- Completion Date: 2026-02-12
- Notes:
  - Installed `multer` for multipart file uploads (memory storage, 10MB per-file, 20 files max)
  - Added `saveUploadedFile()` with atomic write (.tmp → rename) and MD5 verification in `workspace-browser.js`
  - Added `getFileMimeInfo()` with comprehensive MIME map (50+ extensions) and previewable detection
  - Enhanced `/workspace/file` endpoint: returns `mimeType`, `isPreviewable`, `reason` fields; binary files return metadata only (no content)
  - Upload route with per-file results, MD5 integrity check, path traversal protection
  - Validation middleware exempts `/workspace/upload` from JSON content-type requirement
  - Frontend: Upload button in explorer header + hidden file input with `multiple`
  - Frontend: Drag-and-drop zone with visual overlay ("Drop files to upload")
  - Frontend: Upload progress modal with per-file progress bars via XHR upload events
  - Frontend: Client-side 10MB validation, auto-refresh tree after upload
  - Frontend: NonPreviewableCard component for binary/oversized files with download button
  - Frontend: Enriched file icons (15 types: TS, CSS, HTML, Python, config, image, archive, PDF, shell, SQL, etc.)
  - Updated `api-conventions.md` with all workspace routes including upload
  - Updated `error-handling.md` with 422 status code and upload security notes

## Dependencies
- **Goal 001** (complete): Workspace browser service — extends `workspace-browser.js` with write capabilities
- **Goal 002** (complete): React SPA frontend — extends `Workspace.jsx` with upload UI and smart preview
- **Goal 004** (complete): UI mode switching — workspace-first mode is the primary context for uploads
- **Goal 009** (complete): Login protection — upload endpoints inherit existing `launcherAuth` middleware
- **External**: `multer` npm package (installed)

# Goal: Manual API Key Configuration with Provider Presets

## Objective
Enhance the manual API key configuration in the setup wizard's Credentials step to offer a structured provider selector instead of a free-form text field. Users should be able to select from well-known providers (OpenAI, Anthropic, Google, OpenRouter) or choose a custom OpenAI-compatible endpoint, matching the API formats actually supported by OpenClaw's model configuration system (`openai-completions`, `anthropic-messages`, `google-generative-ai`, etc.). The current implementation hardcodes `api: 'anthropic-messages'` for all manual providers — this must be corrected so each provider uses the correct API format.

## Tasks

**Backend: API Format Support**
- [x] Task 1: Update `POST /api/openclaw/credentials/manual` in `src/routes/openclaw.js` to accept an optional `apiFormat` field (one of OpenClaw's `ModelApi` types: `openai-completions`, `openai-responses`, `anthropic-messages`, `google-generative-ai`) and use it instead of hardcoding `anthropic-messages`
- [x] Task 2: Add default `apiFormat` inference based on provider name — if `apiFormat` is not provided, infer from the provider name (e.g., `openai` → `openai-completions`, `anthropic` → `anthropic-messages`, `google` → `google-generative-ai`, `openrouter` → `openai-completions`)
- [x] Task 3: Add default `baseUrl` inference — if `baseUrl` is not provided, use the standard endpoint for well-known providers (e.g., `openai` → `https://api.openai.com/v1`, `anthropic` → `https://api.anthropic.com/v1`, `google` → `https://generativelanguage.googleapis.com/v1beta`, `openrouter` → `https://openrouter.ai/api/v1`)

**Frontend: Provider Preset Selector**
- [x] Task 4: Replace the free-form "Provider Name" text input in `src/frontend/pages/setup/Credentials.jsx` with a dropdown/select that offers preset options: OpenAI, Anthropic, Google, OpenRouter, and "Custom (OpenAI-compatible)"
- [x] Task 5: When a preset provider is selected, auto-fill the Base URL field with the provider's standard endpoint and set the API format automatically; the Base URL should remain editable for overrides
- [x] Task 6: For the "Custom (OpenAI-compatible)" option, show an additional API Format dropdown (`openai-completions`, `anthropic-messages`, `google-generative-ai`) with `openai-completions` as the default, and leave Base URL blank for user input
- [x] Task 7: Add the `apiFormat` field to the `handleManualApply` request body sent to `POST /api/openclaw/credentials/manual`
- [x] Task 8: Add a default models suggestion per provider preset (e.g., OpenAI → `gpt-4o, gpt-4o-mini`, Anthropic → `claude-sonnet-4-5-20250929`, Google → `gemini-2.0-flash`, OpenRouter → leave blank) as placeholder text in the models input

**Frontend: UI Polish**
- [x] Task 9: Style the provider selector consistently with the existing dark theme and card-based layout used in the Credentials page
- [x] Task 10: Show a brief help text below the provider dropdown explaining what each preset configures (base URL, API format)

**Build & Verify**
- [x] Task 11: Rebuild the frontend with `npm run build:frontend` and verify the updated Credentials page renders correctly
- [x] Task 12: Test the manual credential flow end-to-end for at least two providers (e.g., OpenAI and custom) to confirm the correct `api` format is written to `openclaw.json`

## Acceptance Criteria
- The manual API key form presents a provider dropdown with presets: OpenAI, Anthropic, Google, OpenRouter, Custom (OpenAI-compatible)
- Selecting a preset auto-fills the correct Base URL and API format for that provider
- The "Custom" option allows full control over Base URL and API format
- The backend writes the correct `api` field per provider to `openclaw.json` (not hardcoded `anthropic-messages`)
- Existing auto-detected credential flow (Claude OAuth, ZAI) is unaffected
- The provider selector matches the existing dark theme and responsive layout
- A round-trip test (select provider → enter API key → apply → check openclaw.json) confirms the correct config structure

## Progress
- Status: **Complete**
- Start Date: 2026-02-10
- Completion Date: 2026-02-10
- Notes:
  - **Backend changes** (`src/routes/openclaw.js`): Added `PROVIDER_DEFAULTS` map and `VALID_API_FORMATS` array. The `POST /credentials/manual` endpoint now accepts `apiFormat`, validates it against allowed values, and infers both `apiFormat` and `baseUrl` from the provider name when not explicitly provided. Fallback for unknown providers is `openai-completions`.
  - **Frontend changes** (`src/frontend/pages/setup/Credentials.jsx`): Replaced free-form provider text input with a `<select>` dropdown offering 5 presets (OpenAI, Anthropic, Google, OpenRouter, Custom). Selecting a preset auto-fills baseUrl and apiFormat. The "Custom" option shows an additional API Format dropdown. Model placeholder text is provider-specific. Help text below the provider dropdown shows what each preset configures.
  - **Verified**: `npm run build:frontend` succeeds. Round-trip tested with OpenAI (→ `openai-completions`, inferred baseUrl) and Google (→ `google-generative-ai`, inferred baseUrl). Both correctly written to `openclaw.json`.
  - Existing auto-detected flows (Claude OAuth, ZAI) are completely unaffected — no changes to `POST /credentials/apply`.

## Dependencies
- Goal #001 (OpenClaw Launcher Setup Wizard Backend) — **Complete** — provides `POST /api/openclaw/credentials/manual` endpoint to be updated
- Goal #002 (OpenClaw Launcher React SPA Frontend) — **Complete** — provides `Credentials.jsx` page to be updated
- OpenClaw source at `~/openclaw` — reference for `ModelApi` types and `ModelProviderConfig` schema (`src/config/types.models.ts`)
- None of the existing goals conflict — this is a targeted enhancement to the manual credential flow

# Goal: Admin Tab Rename, Adoption Button Fix & Launcher Token Reset

## Objective

Three related UI/UX improvements to the launcher settings area:

1. **Rename "Managed Pool" to "Admin"** — The "Managed Pool" tab and page title should be renamed to "Admin" for clarity and brevity, since this section is used for administrative control of the instance.

2. **Fix the "Enable Adoption" button display issue** — Currently the `Enable` button in `ManagedPool.jsx` has a display problem. The button text reads simply "Enable" (not "Enable Adoption"), and when adoption is already enabled but the user returns to the page after navigation, the adoption URL/credentials card disappears because `enableData` is stored only in component state and is lost on re-render. The button also doesn't clearly communicate what it does. Fix the button label, and ensure the adoption URL is retrievable when adoption is enabled but not yet consumed (the `hasAdoptionToken` field from status indicates the token still exists).

3. **Add a "Reset Launcher Token" button** — Add a button in the Admin page (or Config page) that resets the launcher login password and brings the user back to the login page with the initial "copy token" dialog shown — essentially recreating the first-run experience. This involves: calling the existing `POST /api/openclaw/auth/reset-password` endpoint, recreating the `.launcher-init` flag file so the login page shows the password, clearing the user's session, and redirecting to `/login`.

## Analysis & Conflict Review

### Overlap with Existing Goals

| Goal | Overlap | Resolution |
|------|---------|------------|
| **013 (Managed Pool Adoption)** | Renames the tab and page title created in Tasks 19-20 | Additive UI rename — no change to API or business logic |
| **014 (Adoption State Guard)** | The adoption URL display fix interacts with the `isAdopted` and `hasAdoptionToken` state from Goal 014 | Builds on existing state fields; no changes to state logic |
| **009 (Launcher Login)** | Reset launcher token reuses the `reset-password` endpoint and `.launcher-init` flag mechanism from Goal 009 | Reuses existing infrastructure; adds a frontend endpoint to recreate the init flag |

### No Conflicts Identified

All changes are additive UI improvements. No existing API contracts, state machines, or authentication flows are modified.

## Tasks

### Task Group 1: Rename "Managed Pool" to "Admin"

- [x] Task 1: In `src/frontend/components/SettingsTabs.jsx`, change the "Managed Pool" tab label to "Admin"
- [x] Task 2: In `src/frontend/pages/setup/ManagedPool.jsx`, change the page title `<h2>` from "Managed Pool" to "Admin" (keep the "Managed Pool Adoption" section title within the page as-is, since it accurately describes that specific feature)

### Task Group 2: Fix Enable Adoption Button Display

- [x] Task 3: In `ManagedPool.jsx`, change the button text from "Enable" to "Enable Adoption" for clarity
- [x] Task 4: Add a new `POST /api/openclaw/managed-pool/adoption-url` endpoint in `src/routes/openclaw.js` that returns the adoption URL components (adoptionToken, controlKey, instanceId) when adoption is enabled and the token has not been consumed (`hasAdoptionToken === true && isAdopted === false`). This allows the frontend to reconstruct the adoption URL on page revisit without storing sensitive data in component state
- [x] Task 5: In `ManagedPool.jsx`, when the page loads and adoption is enabled but not yet adopted (`status.enabled && !status.isAdopted && status.hasAdoptionToken`), fetch the adoption URL from the new endpoint and display the adoption credentials card — so the user can always see and copy the adoption URL until it is consumed
- [x] Task 6: Add a "Show Adoption URL" button visible when adoption is enabled, not adopted, and `hasAdoptionToken` is true — as a secondary way to reveal the adoption URL if it's not auto-displayed

### Task Group 3: Add Launcher Token Reset Button

- [x] Task 7: Add a `POST /api/openclaw/auth/reset-launcher-token` endpoint in `src/routes/auth.js` (or extend the existing `reset-password` endpoint) that: (a) generates a new launcher password, (b) saves it via `setLauncherPassword()`, (c) recreates the `.launcher-init` flag via `createInitFlag()` so the login page will show the new password in the first-run dialog, and (d) returns `{ success: true }`
- [x] Task 8: In the Admin page (`ManagedPool.jsx`), add a "Reset Launcher Token" card/section with a button. On click, show a confirmation dialog ("This will reset your launcher login password, invalidate all sessions, and redirect you to the login page. Continue?"), then call the endpoint, clear the local JWT token, and redirect to `/login`
- [x] Task 9: Ensure the login page correctly shows the new password in the first-run dialog after the reset (the existing `GET /api/openclaw/auth/status` endpoint already returns `initialPassword` when `firstRun` is true — verify this flow works end-to-end)

## Acceptance Criteria

- The settings tab reads "Admin" instead of "Managed Pool"
- The page title reads "Admin" instead of "Managed Pool"
- The enable button reads "Enable Adoption" instead of "Enable"
- When adoption is enabled but not yet consumed, the adoption URL card is visible on page load (not just immediately after clicking Enable)
- The adoption URL card disappears once the token has been consumed (adopted)
- A "Reset Launcher Token" button exists in the Admin page
- Clicking "Reset Launcher Token" shows a confirmation dialog
- After confirming, the user is logged out and redirected to `/login`
- The login page shows the new password in the first-run dialog
- All existing managed pool functionality remains unchanged

## Progress

- Status: **Complete**
- Start Date: 2026-02-15
- Completion Date: 2026-02-15
- Notes:
  - All 9 tasks implemented across 4 files
  - **Files modified:**
    - `src/frontend/components/SettingsTabs.jsx` — Tab label changed from "Managed Pool" to "Admin"
    - `src/frontend/pages/setup/ManagedPool.jsx` — Page title renamed, button text fixed, auto-fetch adoption URL on load via new `fetchAdoptionUrl()` callback + useEffect, "Show Adoption URL" button added as secondary trigger, "Reset Launcher Token" card added with confirmation dialog
    - `src/routes/openclaw.js` — Added `POST /managed-pool/adoption-url` endpoint returning adoption credentials when token not consumed
    - `src/routes/auth.js` — Added `POST /auth/reset-launcher-token` endpoint that generates new password, creates init flag, clears httpOnly cookie
  - Frontend build passes cleanly
  - Backend syntax verified
  - Login page first-run flow verified: auth/status returns initialPassword when init flag exists, Login.jsx shows the copy-password dialog

## Dependencies

- **Goal 009 (Launcher Login Protection)**: Complete. Reuses `reset-password` pattern, `.launcher-init` flag, and login page first-run dialog
- **Goal 013 (Managed Pool Adoption)**: Complete. Renames UI elements and fixes adoption URL display
- **Goal 014 (Adoption State Guard)**: Complete. Uses `isAdopted` and `hasAdoptionToken` fields for conditional display logic

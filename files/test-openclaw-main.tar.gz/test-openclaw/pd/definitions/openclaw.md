# OpenClaw - Technical Definition

## What is OpenClaw?

OpenClaw is an **AI agent gateway/daemon system** that provides a unified interface for managing and interacting with AI models through multiple channels (e.g., Telegram bots). This project (**OpenClaw Launcher**) is a web-based management interface that helps users configure, monitor, and interact with the OpenClaw gateway.

## Architecture Overview

```
┌─────────────────────────────────────────────────────┐
│                  OpenClaw Launcher                    │
│            (This Project - Port 3000)                │
│  ┌──────────────┐  ┌────────────────────────────┐   │
│  │  Express API  │  │  React SPA (Vite-built)    │   │
│  │  /api/openclaw│  │  Setup Wizard, Dashboard   │   │
│  └──────┬───────┘  └────────────────────────────┘   │
│         │                                            │
│  ┌──────┴──────────────────────────────────────┐    │
│  │  Services Layer                              │    │
│  │  - openclaw-config.js   (config management)  │    │
│  │  - credential-discovery.js (auto-detect)     │    │
│  │  - telegram-setup.js   (bot validation)      │    │
│  │  - pm2-health.js       (process monitoring)  │    │
│  │  - workspace-browser.js (file browsing)      │    │
│  └──────┬───────────────────────────────────────┘    │
└─────────┼────────────────────────────────────────────┘
          │
          ▼
┌─────────────────────────────────────┐
│  OpenClaw Gateway (PM2-managed)      │
│  Process: openclaw-gateway           │
│  Port: 18789 (default)               │
│  Config: ~/.openclaw/openclaw.json   │
│  Workspace: ~/.openclaw/workspace    │
└──────────────┬──────────────────────┘
               │
    ┌──────────┼──────────┐
    ▼          ▼          ▼
┌────────┐ ┌────────┐ ┌──────────┐
│ Claude │ │  ZAI   │ │ Custom   │
│ OAuth  │ │Provider│ │ API Keys │
└────────┘ └────────┘ └──────────┘
```

## Key Concepts

### Gateway Daemon
- Separate PM2-managed process (`openclaw-gateway`) running on port 18789
- Provides HTTP API for AI agent interactions and serves its own **Control UI** web dashboard
- This launcher monitors and manages it, but does not run it directly

### Gateway Control UI (Web)
- Built-in web dashboard served by the gateway at `http://127.0.0.1:18789/`
- **Technology**: Vite + Lit (Web Components), TypeScript — source at `~/openclaw/ui/`
- **Features**: Real-time AI chat, channel management (WhatsApp/Telegram/Discord/Slack/Signal), session management, cron jobs, skill installation, model switching, config editor, health/event logs, device pairing
- **Security**: `X-Frame-Options: DENY`, `frame-ancestors 'none'`, device pairing required, token/password auth
- **Connection**: Uses WebSocket on the same port (18789) for real-time communication

### Gateway TUI (Terminal)
- Terminal-based interface invoked via `openclaw tui` command
- **Technology**: `@mariozechner/pi-tui` framework, TypeScript — source at `~/openclaw/src/tui/`
- **Connection**: WebSocket to gateway (`ws://localhost:18789/`)
- **Features**: Chat with streaming, agent/session switching, model picker, slash commands, local shell execution

### Configuration (`~/.openclaw/openclaw.json`)
- Central config file for the entire OpenClaw system
- Sections: `gateway`, `models`/`providers`, `auth`, `channels`, `agents`, `messages`, `commands`
- Written with file permissions `0o600` for security
- Managed through the launcher's API and setup wizard

### Credential Providers
| Provider | Source | Auth Mode |
|----------|--------|-----------|
| Claude OAuth | `~/.claude/.credentials.json` | OAuth token (with expiry) |
| ZAI | `~/.claude-code-router/config.json` | API key |
| Manual | User-provided via setup wizard | API key + optional base URL |

### Channels
- **Telegram**: Primary interaction channel. Bot token validated against Telegram API, stored in config under `channels.telegram`

### Workspace (`~/.openclaw/workspace`)
- File storage for agent-generated content (markdown, data files, etc.)
- Browsable via the launcher's IDE-style file viewer
- Security: path traversal prevention, hidden file filtering, 1MB max file size

## Relationship to This Project

This project is the **launcher/management UI** for OpenClaw. It does NOT run the AI gateway itself. Its responsibilities are:
1. **Setup Wizard**: Guide users through initial configuration (credentials, Telegram, config init)
2. **Health Monitoring**: Track gateway process health, PM2 status, connectivity
3. **Workspace Browser**: View agent-generated files in an IDE-style interface
4. **Configuration Management**: Read, initialize, and update `openclaw.json`

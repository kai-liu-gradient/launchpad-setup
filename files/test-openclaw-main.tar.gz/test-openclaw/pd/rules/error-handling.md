# Error Handling Patterns

## Overview

Error handling follows a **layered approach** with consistent patterns across backend and frontend.

## Backend Error Handling

### Layer 1: Middleware (Pre-Route)

**JSON Body Validation** (`src/middleware/validation.js` - `validateJsonBody()`):
- Intercepts POST/PATCH/PUT requests missing `Content-Type: application/json`
- Returns `400 Bad Request` before the route handler executes

**API Error Handler** (`src/middleware/validation.js` - `apiErrorHandler()`):
- Express error-handling middleware (4 params: `err, req, res, next`)
- Catches any unhandled error thrown in `/api/openclaw` route handlers
- Logs: `API Error on [METHOD] [PATH]: [error message]`
- Returns: `{ error: err.message }` with `err.statusCode || 500`

### Layer 2: Route Handlers (`src/routes/openclaw.js`)

Every route handler wraps logic in `try/catch`:

```javascript
router.get('/path', async (req, res) => {
  try {
    // Business logic via service calls
    const result = await someService.doWork();
    res.json(result);
  } catch (error) {
    console.error('Context message:', error.message);
    res.status(500).json({ error: 'Error type', message: error.message });
  }
});
```

**Status Code Usage:**
| Code | Meaning | When Used |
|------|---------|-----------|
| 400 | Bad Request | Missing required fields, invalid input format, no files in upload |
| 403 | Forbidden | Path traversal attempt in workspace browser |
| 404 | Not Found | Config file doesn't exist, file not found |
| 409 | Conflict | Config already exists (without `force` flag) |
| 413 | Payload Too Large | Workspace file exceeds 1MB preview limit, or upload file exceeds 10MB |
| 422 | Unprocessable Entity | MD5 integrity mismatch on uploaded file (file deleted, error reported per-file) |
| 500 | Internal Server Error | Unexpected errors, service failures |

**Error Response Format:**
```json
{
  "error": "Short error type description",
  "message": "Human-readable detail about what went wrong"
}
```

### Layer 3: Services (`src/services/*.js`)

Services handle domain-specific validation and throw descriptive errors:
- `telegram-setup.js`: Validates token format, throws on invalid format or API failure
- `openclaw-config.js`: Validates config structure, throws on invalid values
- `workspace-browser.js`: Checks path safety, throws on traversal attempts

Services do NOT set HTTP status codes. Route handlers map service errors to appropriate HTTP responses.

### Layer 4: Global Error Handler (`server.js`)

Catch-all for any unhandled errors that escape route-level handling:
```javascript
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: err.message });
});
```

## Frontend Error Handling

### Async Operation Pattern
```javascript
try {
  setLoading(true);
  setError(null);
  const response = await fetch('/api/openclaw/...');
  const data = await response.json();
  if (!response.ok) throw new Error(data.message || data.error);
  // Handle success
} catch (err) {
  setError(err.message);
} finally {
  setLoading(false);
}
```

### State Management
- Components maintain `error` and `loading` state variables
- Errors displayed in `.error-container` styled elements
- Loading states show spinners or skeleton UI
- Errors are cleared before each new operation (`setError(null)`)

### Context-Level Error Handling
- `AppConfigContext` handles health/config fetch errors gracefully
- Sets `isConfigured: false` on error, allowing UI to degrade to setup mode
- No hard crashes from API failures

## Security-Related Error Handling

- **Path Traversal**: `workspace-browser.js` normalizes paths and rejects any path outside workspace root (403)
- **Secret Masking**: `sanitizeConfig()` replaces tokens/keys with `***` before sending to frontend
- **File Permissions**: Config written with `0o600` mode; errors if directory doesn't exist
- **Input Validation**: Token format checked with regex before making external API calls
- **Upload Integrity**: MD5 hash computed on received buffer vs written file; mismatch triggers file deletion and per-file error reporting
- **Upload Size Limits**: Multer enforces 10MB per-file server-side; client validates before upload; multer errors mapped to 413

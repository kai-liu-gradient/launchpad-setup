# API Conventions & Route Reference

## Base URL & Prefix

All OpenClaw API routes are mounted under `/api/openclaw` prefix, defined in `src/routes/openclaw.js` and attached in `server.js`.

## Route Organization

Routes are grouped by functional domain:

### Credential Routes (`/api/openclaw/credentials/*`)
| Method | Path | Purpose |
|--------|------|---------|
| GET | `/credentials/detect` | Auto-detect available credential providers |
| POST | `/credentials/apply` | Apply detected credentials to config |
| POST | `/credentials/manual` | Configure credentials manually with API key |

### Telegram Routes (`/api/openclaw/telegram/*`)
| Method | Path | Purpose |
|--------|------|---------|
| POST | `/telegram/validate` | Validate Telegram bot token via Telegram API |
| POST | `/telegram/configure` | Save validated Telegram bot to config |
| GET | `/telegram/pairing-status` | Check Telegram bot configuration status |

### Feishu Routes (`/api/openclaw/feishu/*`)
| Method | Path | Purpose |
|--------|------|---------|
| POST | `/feishu/validate` | Validate Feishu app credentials (appId, appSecret, domain) |
| POST | `/feishu/configure` | Save validated Feishu config (installs/enables plugin, merges channel config). Auto-stops any active WS probes. |
| GET | `/feishu/status` | Get Feishu configuration status (domain, connection mode, bot info, plugin version) |
| POST | `/feishu/test` | Quick credential test using saved or provided credentials |
| POST | `/feishu/ws-probe` | Start a temporary WebSocket probe to validate event subscription (5-min max) |
| GET | `/feishu/ws-probe/:sessionId` | Poll probe session status and steps |
| DELETE | `/feishu/ws-probe/:sessionId` | Stop a running probe session |

### Config Routes (`/api/openclaw/config*`)
| Method | Path | Purpose |
|--------|------|---------|
| GET | `/config` | Read current openclaw.json (sanitized) |
| POST | `/config/init` | Initialize new config with defaults |
| PATCH | `/config` | Update specific config sections |

### Health Routes (`/api/openclaw/health*`)
| Method | Path | Purpose |
|--------|------|---------|
| GET | `/health` | Comprehensive health check (PM2, gateway, config, summary) |
| GET | `/health/config` | Config validation checks (structure, sections, port, workspace) |
| GET | `/health/models` | Model provider connectivity probes (HEAD to baseUrl) |
| GET | `/health/telegram` | Telegram bot token validation (getMe API call) |
| GET | `/health/env-tokens` | Environment variable token inventory (set/missing) |
| GET | `/health/gateway` | Focused gateway health check (process, probe, token sync) |
| GET | `/health/gateway/ws` | Gateway WebSocket upgrade probe |
| GET | `/health/version` | Version info: installed, latest, update availability |
| POST | `/gateway/restart` | Restart openclaw-gateway PM2 process |

### Version Routes (`/api/openclaw/version/*`)
| Method | Path | Purpose |
|--------|------|---------|
| GET | `/version/persisted` | Persisted version for restore/reinstall tooling |

### Upgrade Policy Routes (`/api/openclaw/upgrade-policy`)
| Method | Path | Purpose |
|--------|------|---------|
| GET | `/upgrade-policy` | Current upgrade policy from launcher.json (`"manual"` or `"auto"`) |
| PUT | `/upgrade-policy` | Update upgrade policy in launcher.json. Body: `{ "upgradePolicy": "manual" \| "auto" }` |

Note: `GET /health/version` also includes `upgradePolicy` in its response alongside version info.

### Workspace Routes (`/api/openclaw/workspace/*`)
| Method | Path | Purpose |
|--------|------|---------|
| GET | `/workspace/tree` | Directory tree of workspace (max depth 5, max 500 entries) |
| GET | `/workspace/file?path=<rel>` | Read file content with MIME info (max 1MB for preview, path traversal protected). Returns `{ ..., mimeType, isPreviewable, reason? }`. Non-previewable or oversized files return `content: null` with `reason: "binary"` or `"too_large"` |
| GET | `/workspace/download?path=<rel>` | Download file as attachment (Content-Disposition: attachment) |
| GET | `/workspace/preview?path=<rel>` | HTML file preview (HTML/HTM only, served as text/html for iframe) |
| POST | `/workspace/upload` | Multipart file upload (`files[]` + `targetDir`). 10MB per-file limit, 20 files max. Returns per-file results with MD5 verification: `[{ name, path, size, md5, status, message? }]` |

### Server-Level Routes (in `server.js`)
| Method | Path | Purpose |
|--------|------|---------|
| GET | `/health` | HTML health status page |
| GET | `/api/health` | JSON health endpoint for frontend |
| GET | `/api/info` | Server info (version, platform, memory) |

## Control API (`/control/v1/*`)

Control API routes are defined in `src/routes/control.js` and authenticated via `X-Control-Key` header.

### Gateway Doctor Fix (`/control/v1/instances/:id/doctor-fix`)
| Method | Path | Purpose |
|--------|------|---------|
| POST | `/instances/:id/doctor-fix` | Run `openclaw doctor --fix --non-interactive` then restart gateway. Returns doctor output, exit status, and gateway restart result. 30s timeout. |

### Launcher Restart (`/control/v1/instances/:id/launcher-restart`)
| Method | Path | Purpose |
|--------|------|---------|
| POST | `/instances/:id/launcher-restart` | Restart the launcher PM2 `web` process. Response is sent before restart occurs. Gateway is unaffected. |

### Feishu WebSocket Test (`/control/v1/instances/:id/feishu/ws-test`)
| Method | Path | Purpose |
|--------|------|---------|
| POST | `/instances/:id/feishu/ws-test` | Enable a temporary WebSocket test connection using saved Feishu credentials (2-min max). Stops any existing probes first. Returns sessionId for status polling. |
| GET | `/instances/:id/feishu/ws-test?sessionId=<id>` | Get status of a WebSocket test session (active, steps, elapsed, error) |
| DELETE | `/instances/:id/feishu/ws-test` | Disable/stop all active WebSocket test connections |

**Auto-shutdown triggers:** The WS test is automatically stopped when:
- `DELETE .../feishu/ws-test` is called (explicit disable)
- `PUT .../configure` with `channel: "feishu"` is called (reconfigure)
- `POST /api/openclaw/feishu/configure` is called (launcher UI reconfigure)
- 2-minute timeout expires

## Request/Response Conventions

### Content-Type
- All POST/PATCH requests must include `Content-Type: application/json`
- Enforced by `validateJsonBody()` middleware; returns 400 if missing
- **Exception**: `POST /workspace/upload` uses `multipart/form-data` and is exempt from JSON validation

### Response Format
- **Success**: `{ <data fields> }` - varies by endpoint
- **Error**: `{ error: "<error type>", message: "<human-readable message>" }`
- Config responses always return sanitized data (secrets masked via `sanitizeConfig()`)

### PATCH Config Allowed Sections
Only these top-level keys can be updated via PATCH:
`models`, `gateway`, `agents`, `channels`, `auth`, `messages`, `commands`

## Middleware Stack

Applied to all `/api/openclaw` routes (defined in `server.js`):
1. `validateJsonBody()` - Validates Content-Type for write methods
2. `apiErrorHandler()` - Catches unhandled errors, returns JSON error response

## Service Layer Pattern

Each route delegates business logic to a dedicated service:
- Routes handle HTTP concerns (request parsing, status codes, response formatting)
- Services handle domain logic (file I/O, external API calls, validation)
- Services are imported at the top of the route file

```
Route Handler → Service Function → File System / External API
     ↓                                        ↓
HTTP Response ← Return Value / Throw Error ←──┘
```

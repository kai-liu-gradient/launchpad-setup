# Instance API: allocate must handle pairKey and direct-pair format

**Date:** 2026-02-22
**Priority:** High
**Context:** InstClaw now auto-pairs during provisioning — the instance API must handle the new payload.

## What Changed on InstClaw Side

Previously the hire flow was:

1. `POST /control/v1/allocate` with `{ botToken, userId }` — userId is InstClaw internal ID (e.g. `usr_tg_testuser_abc123`)
2. User manually clicks "Pair with current user"
3. `PUT /control/v1/instances/{id}/configure` with `{ pairKey: "direct:394977994" }` — where `394977994` is the Telegram chat ID

Now the flow is combined — provisioning sends everything in one go:

1. `POST /control/v1/allocate` with `{ botToken, userId, pairKey }` — pairKey is now included
2. If pairKey was NOT in the allocate payload, a follow-up `PUT /control/v1/instances/{id}/configure` with `{ pairKey: "direct:{telegramChatId}" }` is sent immediately after

## What the Instance API Needs to Handle

### 1. `POST /control/v1/allocate` — Accept `pairKey` field

The allocate endpoint now may receive `pairKey` alongside `botToken`:

```json
{
  "botToken": "8551142742:AAF1vY6UJpBFf61KCoiV0OzVocAhqma9T48",
  "userId": "usr_tg_testuser_abc123",
  "pairKey": "direct:394977994"
}
```

- `pairKey` is **optional** — it may or may not be present
- When present, the instance should configure both the bot channel AND the user pairing in a single allocate operation
- When absent, pairing will come later via a separate `configure` call

### 2. `pairKey` Format: `direct:{telegramChatId}`

The `pairKey` value uses the format `direct:{telegramChatId}`:

- `direct:394977994` means the owner's Telegram chat ID is `394977994`
- The instance should use this to:
  - Set the paired user identity
  - Know which Telegram user is the owner/admin of this bot instance
  - Allow the bot to send messages to this user (the chat ID is the private chat with the bot)

### 3. `PUT /control/v1/instances/{id}/configure` — No changes needed

This endpoint already accepts `pairKey`. No changes required. It will still be called:
- For re-pairing (user changes pair identity)
- For model/overage config changes
- As a fallback if allocate didn't include pairKey

### 4. Expected Behavior After Successful Allocate+Pair

After receiving an allocate with both `botToken` and `pairKey`, the instance should be in a fully configured state:

- Bot channel configured (using `botToken` to poll/webhook Telegram)
- User paired (using `pairKey` to identify the owner)
- Instance should report as **configured** in status checks

### 5. `POST /control/v1/allocate` Must NOT Silently Fail

InstClaw now treats allocate failures as fatal — if allocate returns an error or non-2xx, the instance will **not** be moved to PROVISIONING status. The user will see an error message.

Previously InstClaw silently swallowed allocate errors, so a failing allocate endpoint may have gone unnoticed. Now it must succeed for provisioning to proceed.

## Test Instance

- Domain: `lucky-pod-556-aa2d96.404000000.xyz`
- Bot token: `8551142742:AAF1vY6UJpBFf61KCoiV0OzVocAhqma9T48`
- User chat ID: `394977994`
- Expected allocate payload:
  ```json
  {
    "botToken": "8551142742:AAF1vY6UJpBFf61KCoiV0OzVocAhqma9T48",
    "userId": "usr_tg_config_test_user_...",
    "pairKey": "direct:394977994"
  }
  ```

## Summary Checklist for Instance API

- [ ] `POST /control/v1/allocate`: Accept optional `pairKey` field in request body
- [ ] When `pairKey` is present in allocate, configure user pairing in the same operation
- [ ] Parse `direct:{telegramChatId}` format to extract the Telegram chat ID
- [ ] After allocate with both `botToken` and `pairKey`, instance must report as fully configured
- [ ] Return proper error responses (4xx/5xx) on failure — do not return 200 if config failed

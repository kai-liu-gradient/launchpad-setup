# Register a service (proxy) exposure with PM2 management
launcher-cli expose add \
  --slug <name> \
  --type proxy \
  --target http://127.0.0.1:3001 \
  --pm2-script server.js \
  --pm2-cwd ~/.openclaw/workspace/projects/<name> \
  --pm2-bootstrap "npm install" \
  --pm2-port 3001 \
  --description "Brief description of what this project does"

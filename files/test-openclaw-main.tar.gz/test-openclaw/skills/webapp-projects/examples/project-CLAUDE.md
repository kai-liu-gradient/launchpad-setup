# Project: <name>

## Preview
- Port: <PORT>
- Public URL: <publicBaseUrl>/open/<slug>/

## Launcher Environment
This project runs under OpenClaw Launcher. Use `launcher-cli` for exposure management:
- `launcher-cli expose list` — list all exposures
- `launcher-cli expose update --slug <name> --description "..."` — update description
- `launcher-cli expose pm2-control --slug <name> --action restart` — restart service

## Stack
<describe the chosen stack and architecture>

## Reverse Proxy
This project runs behind a reverse proxy with a subpath (`/open/<slug>/`). **All resource references must use relative paths** — absolute paths bypass the subpath and break. This includes:
- API calls: `fetch("api/status")` not `fetch("/api/status")`
- CSS/JS links: `<link href="style.css">` not `<link href="/style.css">`
- Images: `<img src="images/logo.png">` not `<img src="/images/logo.png">`
- Anchor hrefs, form actions, and all other URL references — never prefix with `/`

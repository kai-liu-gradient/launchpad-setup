# Register a static file exposure (no PM2, no server needed)
launcher-cli expose add --slug <name> --type static --path projects/<name> \
  --description "Brief description of the static site"

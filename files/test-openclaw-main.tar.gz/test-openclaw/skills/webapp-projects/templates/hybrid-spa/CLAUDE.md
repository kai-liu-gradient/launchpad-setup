# Project: PROJECT_NAME

## Preview
- Port: PORT_NUMBER
- Public URL: PUBLIC_BASE_URL/open/PROJECT_NAME/

## Launcher Environment
This project runs under OpenClaw Launcher. Use `launcher-cli` for exposure management:
- `launcher-cli expose list` — list all exposures
- `launcher-cli expose update --slug PROJECT_NAME --description "..."` — update description
- `launcher-cli expose pm2-control --slug PROJECT_NAME --action restart` — restart service

## Stack
- Node.js + Express (unified backend + static frontend on one port)
- Plain HTML/CSS/JS frontend (self-contained, no external CDN)
- Tests: `node:test` + `node:assert` (run with `npm test`)

## Conventions
- Keep server logic in `server.js` unless complexity warrants splitting
- API routes under `/api/`; frontend served from `public/`
- **Reverse proxy subpath**: This project runs behind a reverse proxy with a subpath (`/open/PROJECT_NAME/`). **All resource references must use relative paths** — absolute paths bypass the subpath and break. This includes API calls (`fetch("api/status")`), CSS/JS links (`<link href="style.css">`), images (`<img src="images/logo.png">`), anchor hrefs, form actions, and any other URL references. Never prefix paths with `/`.
- SQLite via `better-sqlite3` if persistence is needed (store in `data/app.db`)
- No TypeScript, no bundlers — modify these defaults here if needed

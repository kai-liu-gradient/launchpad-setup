---
name: webapp-projects
description: |
  Build and share web projects via Launcher expose links. Activate when user wants to create any web page, app, game, or shareable web project. Uses Node.js + Express with self-contained HTML/CSS/JS frontend.
---

# Web App Projects

Build web projects and share them via the Launcher's reverse proxy. Projects run as PM2-managed services (recommended) or serve static files.

## Recommended Stack

- **Runtime**: Node.js
- **Backend**: Express.js (lightweight, fast setup)
- **Frontend**: Plain HTML/CSS/JS (self-contained, no external CDN dependencies)
- **Process Manager**: PM2 (auto-restart, monitoring, log management)

## Coding Preferences

Follow these conventions by default when building projects:

- **Single-file backend**: Keep the server in one `server.js` file. Only split into modules if the project genuinely grows complex.
- **Self-contained frontend**: All HTML/CSS/JS must be served from the project itself. **Never use external CDN scripts** (e.g., unpkg.com, cdnjs) — they break behind the reverse proxy due to CORS. Use plain vanilla JS, or install frontend libraries as npm dependencies and serve them from `public/`.
- **Inline styles or single CSS**: Use inline styles, a single `<style>` block, or one `style.css` file. Avoid CSS frameworks unless the user asks.
- **No TypeScript**: Use plain JavaScript. TypeScript adds build complexity with no benefit for small projects.
- **No bundlers**: No Webpack, Vite, Rollup, or similar. Use plain JS served directly — no build pipeline needed.
- **Minimal dependencies**: Only add npm packages that are truly needed (`express` is usually enough).
- **Self-contained HTML**: For frontend-only features, put everything in a single `index.html` with embedded `<style>` and `<script>` tags.
- **Responsive by default**: Add `<meta name="viewport" content="width=device-width, initial-scale=1">` and use responsive CSS patterns.
- **Error handling**: Add basic Express error middleware. Log errors to stdout (PM2 captures it).
- **CORS**: If the project serves an API, enable CORS with `app.use(require('cors')())` or manual headers.
- **Reverse proxy subpath — relative paths everywhere**: Projects run behind a reverse proxy with a subpath (e.g., `/open/<slug>/`). **All resource references must use relative paths** — absolute paths bypass the subpath and break. This applies to:
  - **API calls**: `fetch("api/status")` not `fetch("/api/status")`
  - **CSS/JS links**: `<link href="style.css">`, `<script src="app.js">` — never prefix with `/`
  - **Images/media**: `<img src="images/logo.png">` not `<img src="/images/logo.png">`
  - **Anchor hrefs**: `<a href="about">` not `<a href="/about">`
  - **Form actions**: `<form action="api/submit">` not `<form action="/api/submit">`
  - **XMLHttpRequest / fetch**: always use relative URLs
  - **WebSocket**: derive the WS URL from `window.location` rather than hardcoding a path
  - **Dynamic imports / lazy loading**: use relative paths for all dynamically loaded resources
- **Static files**: Serve frontend from `public/` directory via `express.static`.
- **Environment config**: Use `process.env.PORT` for the port. Avoid `.env` files — pass env vars via PM2.
- **Database**: When persistence is needed, prefer the **file system** (JSON files in `data/`) for simple key-value or config storage, or **SQLite** (via `better-sqlite3`) for queryable data. Store the DB file in the project directory (e.g., `data/app.db`). If the project requires **multiple related tables, structured/relational data, or PostgreSQL-like capabilities**, check whether the `db9` skill is available in the Marketplace by running `launcher-cli marketplace list`. If listed, suggest the user install it for managed PostgreSQL support. Do not assume it is available — always verify first.

### Overriding Coding Preferences

All coding preferences above are **defaults** and can be overridden per-project. If the project directory contains a **`CLAUDE.md`** file, its instructions take priority. Place at `~/.openclaw/workspace/projects/<name>/CLAUDE.md`.

For compatibility with multi-agent workflows that look for `AGENTS.md`, create a symlink:

```bash
cd ~/.openclaw/workspace/projects/<name>
ln -sf CLAUDE.md AGENTS.md
```

When generating `CLAUDE.md` (or `AGENTS.md`), **always include the reverse proxy subpath guidance** — document that all resource references (API calls, CSS/JS links, images, anchor hrefs, form actions) must use relative paths since the project runs behind a reverse proxy at `/open/<slug>/`.

When `CLAUDE.md` exists, read it before making any changes and follow its instructions. It may override stack choices, architecture patterns, or any other defaults.

### Complex Projects — Unified Frontend + Backend

For projects that need both a frontend SPA and a backend API, use a **hybrid single-port architecture** — one Express server serves both the API and the frontend static files. This is recommended because Launcher exposes one port per project.

A ready-to-use scaffold is at `skills/webapp-projects/templates/hybrid-spa/`. Copy it:

```bash
cp -r /workspace/skills/webapp-projects/templates/hybrid-spa ~/.openclaw/workspace/projects/<name>
```

### Complex Projects — AI Coding CLI (Recommended)

For non-trivial projects, suggest the user delegate implementation to a professional AI coding CLI running in headless mode. This gives the coding agent full autonomy to iterate, test, and fix issues within the project directory.

**Detect the active CLI tool** from the environment. Read `~/.pm2/ecosystem.ani-code-daemon.config.js` and check:

- `CLI_PROVIDER_ID` — the active provider (e.g., `"claude"`)
- `CLI_PROVIDER_ZAI_NAME` — the zai binary name (e.g., `"zai"`)

Use `CLI_PROVIDER_ID` to decide which CLI to invoke:
- If `"claude"` → use the `claude` CLI
- Otherwise → use the value from `CLI_PROVIDER_ZAI_NAME` (defaults to `zai`)

#### Setup for AI coding CLI

Before running the CLI, **initialize the project directory** with proper config:

1. Create `CLAUDE.md` in the project directory with build instructions — see `skills/webapp-projects/examples/project-CLAUDE.md`
2. Create `.claude/settings.json` with permissions so the coding agent can operate autonomously:

```bash
PROJECT_DIR=~/.openclaw/workspace/projects/<name>
mkdir -p "$PROJECT_DIR/.claude"
cp /workspace/skills/webapp-projects/examples/claude-settings.json "$PROJECT_DIR/.claude/settings.json"
```

The reference settings file (`skills/webapp-projects/examples/claude-settings.json`) grants broad file read/write/edit, common build tools (npm, git, pm2, etc.), and denies access to secrets and destructive commands.

#### Run in headless mode

**Important**: Always `cd` into the project directory first — the CLI must run from the project root so it picks up `CLAUDE.md` and `.claude/settings.json`.

```bash
cd ~/.openclaw/workspace/projects/<name>
<cli> --print --dangerously-skip-permissions "build the app as described in CLAUDE.md"
```

Replace `<cli>` with `claude` or the value from `CLI_PROVIDER_ZAI_NAME` based on `CLI_PROVIDER_ID` detection above.

The `--print` flag runs headless (no interactive UI). The `--dangerously-skip-permissions` flag allows full autonomy in trusted sandboxed environments — the coding agent can edit files, run npm commands, and test without prompting.

#### Requirement-Driven Workflow (Recommended)

For non-trivial projects dispatched to a coding CLI, create a **requirement description file** so both OpenClaw and the coding agent can track what needs to be done and what's been completed.

1. **Create the requirement file** at `pd/requirements/YYMMDD-<short-name>.md` (e.g., `pd/requirements/260310-snake-game.md`). Use the date prefix matching the current date and a short descriptive slug.

2. **Structure the file** with context, requirements, and a checklist:

```markdown
# <Project Name>: <Feature/Goal>

**Date:** YYYY-MM-DD
**Project:** ~/.openclaw/workspace/projects/<name>
**Public URL:** <publicBaseUrl>/open/<slug>/

## Overview
<1-2 sentences describing what needs to be built>

## Requirements
- <Requirement 1>
- <Requirement 2>
- ...

## Checklist
- [ ] Scaffold project structure
- [ ] Implement <feature A>
- [ ] Implement <feature B>
- [ ] Test and verify
- [ ] Update exposure description
```

3. **Dispatch the coding agent** with a prompt that references the requirement file and asks the agent to update it as work progresses:

```bash
cd ~/.openclaw/workspace/projects/<name>
<cli> --print --dangerously-skip-permissions \
  "Based on the requirement file /workspace/pd/requirements/YYMMDD-<short-name>.md, implement what is described. As you complete each checklist item, UPDATE the file to mark it as done (change [ ] to [x])."
```

This way OpenClaw can check the requirement file to see progress, and the coding agent has a clear spec to follow.

#### When to suggest AI coding CLI

- The project requires multiple files or non-trivial logic (games, dashboards, CRUD apps)
- The user asks for something complex that would take many iterative edits
- The project needs testing and debugging cycles

For simple single-page projects, editing files directly in the current session is fine.

## Public Access — IMPORTANT

Every Launcher instance has a public domain. All exposed projects are publicly accessible. **Always provide the full public URL to the user.**

**Find the public URL** by running `launcher-cli expose list` — it shows the full public URL for each exposure.

**Never say "localhost" or "no public domain" — the public domain always exists.**

## Descriptions — Always Set

When creating or updating an exposure, **always set a clear description** (e.g., "Snake game built with React and Canvas"). Use `launcher-cli expose update --slug <name> --description "..."`.

## Required Tool

This skill depends on the **Launcher CLI Tool** (`launcher-cli`). Install it from the Marketplace before using this skill:

1. Open Launcher UI → Marketplace → Install "Launcher CLI Tool"
2. Or via API: `POST /api/openclaw/control/marketplace/install` with `{"itemId": "openclaw-launcher-cli"}`

All exposure management commands below use `launcher-cli`. Run `launcher-cli --help` to verify installation.

## Workflow

### Quick Init (Recommended)

Create a fully initialized, running project with one command:

```bash
launcher-cli init --slug <name> --description "Brief description"
```

This auto-assigns a port, creates project files (Express + plain HTML/JS), runs `npm install`, starts PM2, and registers the exposure. Only `--slug` is required — all other options are optional.

### Manual Workflow

1. Create project at `~/.openclaw/workspace/projects/<name>/`
2. Write code using Node.js + Express
3. Register and start via `launcher-cli expose add` with PM2 options and a **description**
4. `launcher-cli` prints the full public URL — share it with the user

## Port Allocation

- **3000** — Reserved (Launcher). Never use.
- **3001+** — Available for projects. Check `pm2 jlist` before assigning.

## Service Project (Recommended)

### Create

```bash
mkdir -p ~/.openclaw/workspace/projects/<name>/public
```

Write `server.js` and `package.json` — see examples at `skills/expose-projects/examples/server.js` and `skills/expose-projects/examples/package.json`.

### Register, Bootstrap and Start

Use `launcher-cli` to register the exposure with PM2 management — it handles `npm install`, PM2 process creation, and exposure registration in one command:

```bash
launcher-cli expose add \
  --slug <name> --type proxy --target http://127.0.0.1:3001 \
  --pm2-script server.js \
  --pm2-cwd ~/.openclaw/workspace/projects/<name> \
  --pm2-bootstrap "npm install" \
  --pm2-port 3001 \
  --description "Brief description of what this project does"
```

The CLI prints the full public URL after creation.

## PM2 Service Management

```bash
launcher-cli pm2 status                              # Show all PM2-managed exposures
launcher-cli pm2 control --slug <name> --action restart  # restart|start|stop|delete
launcher-cli expose list                              # List all exposures with status
```

For direct PM2 access (debugging):

```bash
pm2 logs user-<name> --lines 50  # View logs
pm2 show user-<name>             # Detailed process info
```

## Static Project

Write `index.html` and assets at `~/.openclaw/workspace/projects/<name>/`. No PM2 or server needed.

Register via CLI:

```bash
launcher-cli expose add --slug <name> --type static --path projects/<name> \
  --description "Brief description of the static site"
```

## Project Structure

**Simple project:**
```
~/.openclaw/workspace/projects/<name>/
  server.js        # Express entry point
  package.json     # Dependencies
  public/          # Static assets
```

**Complex project (with Claude Code):**
```
~/.openclaw/workspace/projects/<name>/
  server.js        # Express: API + static serving on one port
  package.json     # Dependencies and scripts
  CLAUDE.md        # Project coding instructions (overrides skill defaults)
  AGENTS.md        # Symlink → CLAUDE.md
  .claude/
    settings.json  # Claude Code permissions
  public/          # Frontend SPA
  test/            # Tests using node:test
  data/            # SQLite DB files (if needed)
```

Starter template: `skills/expose-projects/templates/hybrid-spa/`

## Constraints

- Proxy targets: localhost only (`127.0.0.1`, `localhost`, `::1`)
- Static paths: must stay within `~/.openclaw/workspace/`
- Reserved slugs: `gateway`, `api`, `control`, `health`, `open`, `feishu`
- PM2 process name must use `user-` prefix: `user-<slug>`
- Add `--protect` flag to generate random HTTP Basic Auth credentials for sensitive content

## Dependencies

- **Launcher CLI Tool** (`openclaw-launcher-cli`) — required. Install via Marketplace before using this skill.

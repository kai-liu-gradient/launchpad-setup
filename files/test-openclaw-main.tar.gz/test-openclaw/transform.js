const fs = require('fs');
let c = fs.readFileSync('src/frontend/pages/setup/Channels.jsx', 'utf8');

// 1) Narrow the platform selector: add maxWidth and reduce padding
c = c.replace("display: 'flex', gap: 10 }", "display: 'flex', gap: 10, maxWidth: 280 }");

// Reduce padding on feishu button
c = c.replace(
  /setFsDomain\('feishu'\)\}[\s\S]*?padding: '12px 16px'/,
  function(m) { return m.replace("padding: '12px 16px'", "padding: '8px 14px'"); }
);

// Reduce padding on lark button
c = c.replace(
  /setFsDomain\('lark'\)\}[\s\S]*?padding: '12px 16px'/,
  function(m) { return m.replace("padding: '12px 16px'", "padding: '8px 14px'"); }
);

// 2) Wrap the info box and scopes/events sections into a flex row
// Identify the three sections
const infoMarker = '              <div style={infoBoxStyle}>';
const scopesMarker = '              {/* Required Scopes (collapsible) */}';
const eventMarker = '              {/* Required Event Subscription (collapsible) */}';
const afterMarker = '              {/* App ID */}';

const infoIdx = c.indexOf(infoMarker);
const scopesIdx = c.indexOf(scopesMarker);
const eventIdx = c.indexOf(eventMarker);
const afterIdx = c.indexOf(afterMarker);

if (infoIdx === -1 || scopesIdx === -1 || eventIdx === -1 || afterIdx === -1) {
  console.error('Could not find section markers', { infoIdx, scopesIdx, eventIdx, afterIdx });
  process.exit(1);
}

// Extract the three sections
const infoSection = c.substring(infoIdx, scopesIdx).trimEnd();
const scopesSection = c.substring(scopesIdx, eventIdx).trimEnd();
const eventSection = c.substring(eventIdx, afterIdx).trimEnd();

// Modify info section: use spread to remove marginBottom, remove "(see below)" references
let newInfo = infoSection
  .replace('<div style={infoBoxStyle}>', '<div style={{ ...infoBoxStyle, flex: 1, marginBottom: 0 }}>')
  .replace(" (see below)</li>\n                  <li>Add event subscription: <code style={{ background: 'var(--info-code-bg)', padding: '2px 6px', borderRadius: 4 }}>im.message.receive_v1</code> (see below)",
           "</li>\n                  <li>Add event subscription: <code style={{ background: 'var(--info-code-bg)', padding: '2px 6px', borderRadius: 4 }}>im.message.receive_v1</code>");

// Modify scopes section: remove marginBottom
let newScopes = scopesSection.replace('marginBottom: 12,\n', '');

// Modify event section: remove marginBottom
let newEvent = eventSection.replace('marginBottom: 16,\n', '');

// Build the new combined section
const newCombined = `              {/* Setup guide + scopes/events in a row */}
              <div style={{ display: 'flex', gap: 12, marginBottom: 16, alignItems: 'flex-start' }}>
                {/* Left: How to setup info box */}
  ${newInfo}

                {/* Right: Required Scopes + Event Subscription stacked */}
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 10 }}>
  ${newScopes}

  ${newEvent}
                </div>
              </div>

`;

c = c.substring(0, infoIdx) + newCombined + c.substring(afterIdx);

fs.writeFileSync('src/frontend/pages/setup/Channels.jsx', c);

console.log('Checks:');
console.log('  maxWidth:', c.includes('maxWidth: 280'));
console.log('  8px 14px:', c.includes("8px 14px"));
console.log('  flex row:', c.includes("display: 'flex', gap: 12, marginBottom: 16"));
console.log('  spread:', c.includes('...infoBoxStyle'));
console.log('Done!');

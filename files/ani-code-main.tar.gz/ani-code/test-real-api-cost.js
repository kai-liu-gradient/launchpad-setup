#!/usr/bin/env node

import { execSync } from 'child_process';
import Anthropic from '@anthropic-ai/sdk';

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY
});

async function testRealAPICall() {
  console.log('=== Testing Real API Call Cost Tracking ===\n');

  const today = new Date().toISOString().split('T')[0].replace(/-/g, '');

  // BEFORE snapshot
  console.log('1. Getting BEFORE snapshot...');
  const beforeOutput = execSync(`npx ccusage -j --offline --breakdown --since ${today}`, { encoding: 'utf8' });
  const beforeData = JSON.parse(beforeOutput);

  console.log('Before:', {
    cost: beforeData.totals.totalCost.toFixed(6),
    tokens: beforeData.totals.totalTokens
  });

  // Make a real API call
  console.log('\n2. Making real API call with Sonnet 4.5...');
  const startTime = Date.now();

  const response = await anthropic.messages.create({
    model: 'claude-sonnet-4-5-20250929',
    max_tokens: 100,
    messages: [{
      role: 'user',
      content: 'Say "hello" in exactly one word'
    }]
  });

  const apiDuration = Date.now() - startTime;
  console.log(`API call completed in ${apiDuration}ms`);
  console.log('Response:', response.content[0].text);
  console.log('Actual usage from API:', {
    inputTokens: response.usage.input_tokens,
    outputTokens: response.usage.output_tokens
  });

  // Wait for ccusage to process (try different delays)
  for (const delay of [500, 1000, 2000, 3000]) {
    console.log(`\n3. Waiting ${delay}ms for ccusage to process...`);
    await new Promise(resolve => setTimeout(resolve, delay));

    // AFTER snapshot
    const afterOutput = execSync(`npx ccusage -j --offline --breakdown --since ${today}`, { encoding: 'utf8' });
    const afterData = JSON.parse(afterOutput);

    const costDiff = afterData.totals.totalCost - beforeData.totals.totalCost;
    const tokenDiff = afterData.totals.totalTokens - beforeData.totals.totalTokens;

    console.log(`After (${delay}ms delay):`, {
      cost: afterData.totals.totalCost.toFixed(6),
      tokens: afterData.totals.totalTokens,
      diff: {
        cost: costDiff.toFixed(6),
        tokens: tokenDiff
      }
    });

    if (costDiff > 0) {
      console.log(`✅ Cost detected at ${delay}ms delay: $${costDiff.toFixed(6)}`);

      // Check model breakdown
      if (afterData.daily?.[0]?.modelBreakdowns) {
        const sonnetModel = afterData.daily[0].modelBreakdowns.find(m =>
          m.modelName.includes('sonnet-4-5')
        );
        if (sonnetModel) {
          console.log('Sonnet 4.5 in breakdown:', {
            cost: sonnetModel.cost.toFixed(6),
            inputTokens: sonnetModel.inputTokens,
            outputTokens: sonnetModel.outputTokens
          });
        }
      }
      break;
    } else if (delay === 3000) {
      console.log('❌ No cost detected even after 3 second delay');
    }
  }
}

testRealAPICall().catch(console.error);

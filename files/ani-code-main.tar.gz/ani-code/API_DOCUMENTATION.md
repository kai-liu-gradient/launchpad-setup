# AniCode REST API Documentation

## Base URL
```
http://localhost:6502
```

## Authentication
All API endpoints require authentication using a Bearer token in the Authorization header:

```http
Authorization: Bearer YOUR_WORKSPACE_TOKEN
```

### Getting a Token
```bash
# Create workspace and generate token
ani-code workspace create my-project
ani-code workspace token gen -n "API Client" -t api
```

---

## Endpoints

### 1. Submit Task
Create a new task in the queue.

**Endpoint:** `POST /api/task`

**Request Body:**
```json
{
  "name": "Task description",
  "command": "ani-code continue 'implement feature'",  // Optional
  "priority": "normal",  // Optional: low, normal, high
  "model": "sonnet",  // Optional: sonnet or opus (Claude model preference)
  "metadata": {  // Optional
    "source": "api",
    "requestId": "unique-id"
  }
}
```

**Response:**
```json
{
  "success": true,
  "taskId": "ac-20250906-example-7d139350",
  "status": "queued",
  "workspace": "my-project",
  "queuePosition": 1
}
```

**Example:**
```bash
curl -X POST http://localhost:6501/api/task \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name": "Build user dashboard"}'
```

---

### 2. Get Task Status
Retrieve the current status and details of a specific task.

**Endpoint:** `GET /api/task/{taskId}`

**Response:**
```json
{
  "id": "ac-20250906-example-7d139350",
  "name": "Build user dashboard",
  "status": "running",
  "progress": 45,
  "output": "Task output here...",
  "error": null,
  "startedAt": "2025-01-15T10:30:00Z",
  "completedAt": null,
  "workspace": "my-project",
  "queuePosition": null
}
```

**Status Values:**
- `queued` - Task is waiting in queue
- `running` - Task is currently executing
- `completed` - Task finished successfully
- `failed` - Task encountered an error
- `cancelled` - Task was cancelled

**Example:**
```bash
curl -X GET http://localhost:6501/api/task/ac-20250906-example-7d139350 \
  -H "Authorization: Bearer YOUR_TOKEN"
```

---

### 3. List Tasks
Get a list of tasks for the workspace with optional filtering.

**Endpoint:** `GET /api/tasks`

**Query Parameters:**
- `status` (optional) - Filter by status: queued, running, completed, failed
- `limit` (optional, default: 50) - Maximum number of tasks to return
- `offset` (optional, default: 0) - Pagination offset

**Response:**
```json
{
  "tasks": [
    {
      "id": "ac-20250906-example-7d139350",
      "name": "Build user dashboard",
      "status": "completed",
      "startedAt": "2025-01-15T10:30:00Z",
      "completedAt": "2025-01-15T10:45:00Z",
      "queuePosition": null
    }
  ],
  "total": 15,
  "hasMore": false
}
```

**Example:**
```bash
# Get all running tasks
curl -X GET "http://localhost:6501/api/tasks?status=running" \
  -H "Authorization: Bearer YOUR_TOKEN"

# Get latest 10 tasks
curl -X GET "http://localhost:6501/api/tasks?limit=10" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

---

### 4. Cancel Task
Cancel a queued or running task.

**Endpoint:** `DELETE /api/task/{taskId}`

**Response:**
```json
{
  "success": true,
  "message": "Task cancelled successfully"
}
```

**Example:**
```bash
curl -X DELETE http://localhost:6501/api/task/ac-20250906-example-7d139350 \
  -H "Authorization: Bearer YOUR_TOKEN"
```

---

### 5. Get Task Checklist Results
Retrieve completion checklist results for a finished task.

**Endpoint:** `GET /api/task/{taskId}/checklist`

**Response:**
```json
{
  "taskId": "ac-20250906-example-7d139350",
  "workspace": "my-project",
  "checklist": {
    "passed": ["Test 1", "Test 2"],
    "failed": [],
    "warnings": ["Consider adding more tests"]
  },
  "completedAt": "2025-01-15T10:45:00Z"
}
```

**Example:**
```bash
curl -X GET http://localhost:6501/api/task/ac-20250906-example-7d139350/checklist \
  -H "Authorization: Bearer YOUR_TOKEN"
```

---

## Plan Management API

### 6. Create Plan
Create a new plan with multiple steps to execute.

**Endpoint:** `POST /api/plan`

**Request Body:**
```json
{
  "title": "Deploy application to production",
  "description": "Complete deployment workflow",  // Optional
  "steps": [
    "Run all tests",
    "Build production bundle",
    "Deploy to staging",
    "Run smoke tests",
    "Deploy to production"
  ],
  "metadata": {  // Optional
    "category": "deployment",
    "version": "1.0"
  }
}
```

**Response:**
```json
{
  "success": true,
  "planId": "acp-0115-myproject-A51001",
  "workspace": "my-project",
  "status": "pending"
}
```

---

### 7. Get Plan Details
Retrieve details of a specific plan.

**Endpoint:** `GET /api/plan/{planId}`

**Response:**
```json
{
  "success": true,
  "plan": {
    "id": "acp-0115-myproject-A51001",
    "title": "Deploy application to production",
    "description": "Complete deployment workflow",
    "status": "pending",
    "steps": [
      "Run all tests",
      "Build production bundle",
      "Deploy to staging",
      "Run smoke tests",
      "Deploy to production"
    ],
    "currentStep": null,
    "createdAt": "2025-01-15T10:00:00Z",
    "updatedAt": "2025-01-15T10:00:00Z",
    "completedAt": null,
    "createdBy": "api",
    "metadata": {
      "category": "deployment",
      "version": "1.0"
    },
    "workspace": "my-project"
  }
}
```

---

### 8. Update Plan
Update plan details or status.

**Endpoint:** `PUT /api/plan/{planId}`

**Request Body:**
```json
{
  "title": "Updated title",  // Optional
  "description": "Updated description",  // Optional
  "steps": ["Updated", "Steps", "Array"],  // Optional
  "status": "paused",  // Optional: pending, in_progress, completed, paused, failed
  "currentStep": 2  // Optional: current step index when updating status
}
```

**Response:**
```json
{
  "success": true,
  "message": "Plan updated successfully"
}
```

---

### 9. Delete Plan
Delete a plan from the system.

**Endpoint:** `DELETE /api/plan/{planId}`

**Response:**
```json
{
  "success": true,
  "message": "Plan deleted successfully"
}
```

---

### 10. List Plans
Get all plans for the workspace with optional status filtering.

**Endpoint:** `GET /api/plans`

**Query Parameters:**
- `status` (optional) - Filter by status: pending, in_progress, completed, paused, failed
- `limit` (optional, default: 10) - Maximum number of plans to return
- `offset` (optional, default: 0) - Pagination offset

**Response:**
```json
{
  "success": true,
  "plans": [
    {
      "id": "acp-0115-myproject-A51001",
      "title": "Deploy application to production",
      "description": "Complete deployment workflow",
      "status": "pending",
      "stepsCount": 5,
      "currentStep": null,
      "createdAt": "2025-01-15T10:00:00Z",
      "updatedAt": "2025-01-15T10:00:00Z",
      "completedAt": null,
      "createdBy": "api",
      "workspace": "my-project"
    }
  ],
  "total": 3,
  "limit": 10,
  "offset": 0
}
```

---

### 11. Execute Plan
Start execution of a pending plan.

**Endpoint:** `POST /api/plan/execute`

**Request Body:**
```json
{
  "planId": "acp-0115-myproject-A51001",  // Optional: specific plan ID
  "priority": "high",  // Optional: low, normal, high
  "metadata": {  // Optional
    "trigger": "manual",
    "requestId": "unique-id"
  }
}
```

**Note:** If `planId` is not provided, the next pending plan (FIFO order) will be executed.

**Response:**
```json
{
  "success": true,
  "planId": "acp-0115-myproject-A51001",
  "taskId": "ac-20250115-myproject-7d139350",
  "title": "Deploy application to production",
  "status": "in_progress",
  "workspace": "my-project",
  "message": "Plan execution started"
}
```

---

### 12. Get Plans Summary
Get summary statistics for all plans in the workspace.

**Endpoint:** `GET /api/plans/summary`

**Response:**
```json
{
  "success": true,
  "summary": {
    "total": 10,
    "byStatus": {
      "pending": 3,
      "in_progress": 1,
      "completed": 5,
      "failed": 1
    },
    "progress": {
      "totalSteps": 45,
      "completedSteps": 28,
      "percentage": 62
    },
    "workspace": "my-project"
  }
}
```

---

### 13. List Goals
Get all goals from the pd/goals directory with optional filtering.

**Endpoint:** `GET /api/goals`

**Query Parameters:**
- `status` (optional) - Filter by status: not_started, in_progress, completed, abandoned, cancelled, on_hold
- `limit` (optional, default: 100) - Maximum number of goals to return
- `offset` (optional, default: 0) - Pagination offset

**Response:**
```json
{
  "goals": [
    {
      "id": "042",
      "goalNumber": 42,
      "title": "Goal Tracking Kanban System",
      "status": "completed",
      "stage": "Stage 11: Event Tracking & Analytics",
      "progress": 100,
      "startDate": "2025-09-26",
      "completionDate": "2025-09-27",
      "description": "Implement comprehensive goal tracking...",
      "objective": "Create kanban board for goal visualization...",
      "tasks": [
        { "text": "Design kanban board UI", "completed": true },
        { "text": "Implement drag-and-drop", "completed": true }
      ],
      "acceptanceCriteria": [
        "Kanban board displays all goals",
        "Drag-and-drop works smoothly"
      ],
      "dependencies": ["041"],
      "tags": ["ui", "tracking"],
      "priority": "high",
      "file": "042-goal-tracking-kanban-system.md",
      "filePath": "/workspace/pd/goals/042-goal-tracking-kanban-system.md",
      "createdAt": "2025-09-26T10:00:00Z",
      "updatedAt": "2025-09-27T15:30:00Z"
    }
  ],
  "total": 128,
  "limit": 100,
  "offset": 0
}
```

---

### 14. Get Goal Details
Get detailed information about a specific goal.

**Endpoint:** `GET /api/goals/{goalId}`

**Path Parameters:**
- `goalId` - Goal identifier (e.g., "042" or "042-goal-tracking-kanban-system")

**Response:**
```json
{
  "goal": {
    "id": "042",
    "goalNumber": 42,
    "title": "Goal Tracking Kanban System",
    "status": "completed",
    "stage": "Stage 11: Event Tracking & Analytics",
    "progress": 100,
    "content": "# Goal 042: Goal Tracking Kanban System\n\n## Objective\n...",
    "contentHtml": "<h1>Goal 042: Goal Tracking Kanban System</h1>...",
    "tasks": [
      { "text": "Design kanban board UI", "completed": true },
      { "text": "Implement drag-and-drop", "completed": true }
    ],
    "acceptanceCriteria": [
      "Kanban board displays all goals",
      "Drag-and-drop works smoothly"
    ],
    "dependencies": ["041"],
    "metadata": {
      "estimatedHours": 32,
      "actualHours": 28,
      "assignee": "Claude"
    }
  }
}
```

---

### 15. Create Goal
Create a new goal file in pd/goals directory.

**Endpoint:** `POST /api/goals`

**Request Body:**
```json
{
  "title": "Implement User Authentication",
  "objective": "Add JWT-based authentication to the API",
  "stage": "Stage 5: Authentication",
  "description": "Implement secure user authentication...",
  "tasks": [
    "Install JWT library",
    "Create auth middleware",
    "Add login endpoint",
    "Add token refresh endpoint"
  ],
  "acceptanceCriteria": [
    "Users can login with email/password",
    "JWT tokens expire after 24 hours",
    "Refresh tokens work correctly"
  ],
  "dependencies": ["004", "005"],
  "priority": "high",
  "estimatedHours": 16
}
```

**Response:**
```json
{
  "success": true,
  "goal": {
    "id": "129",
    "goalNumber": 129,
    "title": "Implement User Authentication",
    "file": "129-implement-user-authentication.md",
    "filePath": "/workspace/pd/goals/129-implement-user-authentication.md",
    "createdAt": "2025-11-17T12:00:00Z"
  }
}
```

---

### 16. Update Goal
Update an existing goal file.

**Endpoint:** `PUT /api/goals/{goalId}`

**Path Parameters:**
- `goalId` - Goal identifier

**Request Body:**
```json
{
  "status": "in_progress",
  "progress": 35,
  "tasks": [
    { "text": "Install JWT library", "completed": true },
    { "text": "Create auth middleware", "completed": false }
  ],
  "notes": "JWT library installed, working on middleware"
}
```

**Response:**
```json
{
  "success": true,
  "goal": {
    "id": "129",
    "status": "in_progress",
    "progress": 35,
    "updatedAt": "2025-11-17T14:30:00Z"
  }
}
```

---

### 17. Delete/Archive Goal
Delete or archive a goal file.

**Endpoint:** `DELETE /api/goals/{goalId}`

**Path Parameters:**
- `goalId` - Goal identifier

**Query Parameters:**
- `archive` (optional, default: true) - If true, moves to archive folder instead of deleting

**Response:**
```json
{
  "success": true,
  "action": "archived",
  "archivedPath": "/workspace/pd/goals/archive/129-implement-user-authentication.md"
}
```

---

### 18. Get Running Goals
Get all goals with "in_progress" status.

**Endpoint:** `GET /api/goals/running`

**Query Parameters:**
- `limit` (optional, default: 50) - Maximum number of results

**Response:**
```json
{
  "runningGoals": [
    {
      "id": "125",
      "title": "Admin User Impersonation",
      "status": "in_progress",
      "progress": 60,
      "startDate": "2025-11-15",
      "tasks": [
        { "text": "Create impersonation API", "completed": true },
        { "text": "Add UI controls", "completed": false }
      ]
    }
  ],
  "total": 3
}
```

---

### 19. Sync Goals
Synchronize goals from the pd/goals filesystem.

**Endpoint:** `POST /api/goals/sync`

**Request Body (optional):**
```json
{
  "force": false,
  "verbose": true
}
```

**Response:**
```json
{
  "success": true,
  "syncResult": {
    "goalsFound": 128,
    "goalsUpdated": 5,
    "goalsCreated": 2,
    "goalsDeleted": 0,
    "errors": [],
    "duration": "1.2s",
    "timestamp": "2025-11-17T12:00:00Z"
  }
}
```

---

## Error Responses

All error responses follow this format:

```json
{
  "success": false,
  "error": "Error message description"
}
```

**Common HTTP Status Codes:**
- `400` - Bad Request (invalid parameters)
- `401` - Unauthorized (missing or invalid token)
- `403` - Forbidden (access denied to resource)
- `404` - Not Found (task or endpoint not found)
- `500` - Internal Server Error

---

## WebSocket API

For real-time task updates, connect to the WebSocket endpoint:

**Endpoint:** `ws://localhost:6502/socket`

**Connection Example:**
```javascript
const ws = new WebSocket('ws://localhost:6502/socket', {
  headers: {
    'Authorization': 'Bearer YOUR_TOKEN'
  }
});

ws.on('message', (data) => {
  const message = JSON.parse(data);
  console.log('Task update:', message);
});
```

---

## Rate Limits

- Maximum 100 requests per minute per token
- Maximum 10 concurrent tasks per workspace
- WebSocket connections limited to 5 per token

---

## Client Libraries

### Python Example
```python
import requests

class AniCodeClient:
    def __init__(self, token):
        self.token = token
        self.base_url = "http://localhost:6501"
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
    
    def submit_task(self, name, command=None):
        response = requests.post(
            f"{self.base_url}/api/task",
            headers=self.headers,
            json={"name": name, "command": command}
        )
        return response.json()
    
    def get_task_status(self, task_id):
        response = requests.get(
            f"{self.base_url}/api/task/{task_id}",
            headers=self.headers
        )
        return response.json()

# Usage
client = AniCodeClient("YOUR_TOKEN")
task = client.submit_task("Build feature")
print(f"Task ID: {task['taskId']}")
```

### Node.js Example
```javascript
const axios = require('axios');

class AniCodeClient {
  constructor(token) {
    this.token = token;
    this.baseUrl = 'http://localhost:6501';
  }

  async submitTask(name, command = null) {
    const response = await axios.post(
      `${this.baseUrl}/api/task`,
      { name, command },
      {
        headers: {
          'Authorization': `Bearer ${this.token}`,
          'Content-Type': 'application/json'
        }
      }
    );
    return response.data;
  }

  async getTaskStatus(taskId) {
    const response = await axios.get(
      `${this.baseUrl}/api/task/${taskId}`,
      {
        headers: {
          'Authorization': `Bearer ${this.token}`
        }
      }
    );
    return response.data;
  }
}

// Usage
const client = new AniCodeClient('YOUR_TOKEN');
const task = await client.submitTask('Build feature');
console.log(`Task ID: ${task.taskId}`);
```

### cURL Examples
```bash
# Submit a task
curl -X POST http://localhost:6501/api/task \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name": "Deploy to staging"}'

# Check status
curl -X GET http://localhost:6501/api/task/TASK_ID \
  -H "Authorization: Bearer YOUR_TOKEN"

# List all tasks
curl -X GET http://localhost:6501/api/tasks \
  -H "Authorization: Bearer YOUR_TOKEN"

# Cancel a task
curl -X DELETE http://localhost:6501/api/task/TASK_ID \
  -H "Authorization: Bearer YOUR_TOKEN"
```

---

## Workspace Management

### Create Workspace
```bash
ani-code workspace create my-project
```

### Generate Token
```bash
# Generate API token (never expires)
ani-code workspace token gen -n "Production API" -t api

# Generate temporary token (30 days)
ani-code workspace token gen -n "Temp Access" -e 30
```

### List Tokens
```bash
ani-code workspace token list
```

### Revoke Token
```bash
ani-code workspace token revoke TOKEN_ID
```

---

## Model Preferences

You can specify which Claude model to use for tasks at multiple levels:

### 1. Task-Level Model (Highest Priority)
Specify model directly when creating a task:
```json
{
  "name": "Complex analysis task",
  "model": "opus"
}
```

### 2. Workspace-Level Model (Default)
Set a default model for all tasks in a workspace:
```bash
# Set workspace default to opus
ani-code workspace meta set model opus

# Set workspace default to sonnet
ani-code workspace meta set model sonnet

# View current workspace model setting
ani-code workspace meta get model
```

### Model Priority Order:
1. Task-specific model (if provided in API request)
2. Workspace default model (if set via `workspace meta set model`)
3. Prompt-based model detection (@@opus or @@sonnet in task name/command)
4. Claude default model

### 3. Prompt-Based Model Detection (Fallback)
If no task-level or workspace-level model is specified, ani-code will automatically detect model preferences from the task content:

```json
{
  "name": "Complex analysis @@opus task",
  "command": "analyze data"
}
```

**Detection Rules:**
- Looks for exact matches: `@@opus` or `@@sonnet`
- Case-sensitive (@@OPUS will not work)
- Searches both task name and command
- Only activates when no other model preference exists
- Logs detection for visibility

### Valid Models:
- `sonnet` - Claude 3.5 Sonnet (faster, cost-effective)
- `opus` - Claude 3 Opus (most capable, higher cost)

---

## Support

For issues or questions:
- GitHub Issues: https://github.com/anthropics/ani-code/issues
- Documentation: http://localhost:6501/api/docs

---

*Last updated: 2025-01-15*
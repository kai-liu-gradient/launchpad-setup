# Gateway Workspace Auto-Select & Registration

## Overview

When Telegram messages arrive through the gateway, the system now automatically:
1. Selects the workspace (if only one is available)
2. Registers the Telegram chat with the workspace manager
3. Saves the association for future use

This eliminates the need for users to manually run `/workdir` commands when using gateway-connected instances.

## Implementation

### 1. Auto-Select Logic (`src/http-server.js:10658-10694`)

When `createTelegramTask()` is called and no workdir is configured:

```javascript
if (!workdirName) {
  const workdirKeys = Object.keys(availableWorkdirs);

  if (workdirKeys.length === 1) {
    // Auto-select the only available workspace
    workdirName = workdirKeys[0];
    workdirPath = availableWorkdirs[workdirName];

    // Save to ChatSettings
    chatSettings.setWorkdir(fullChatId, workdirName);

    // Register with workspace manager (gateway mode only)
    if (config.gateway.enabled) {
      workspace = getOrCreateWorkspace(workdirPath);
      registerTelegramChat(chatId, workspace.id);
    }
  }
  else if (workdirKeys.length === 0) {
    // Error: No workspaces available
  }
  else {
    // Error: Multiple workspaces, user must choose
  }
}
```

### 2. Gateway Workspace Resolution (`src/http-server.js:64-69`)

In gateway mode, `getAvailableWorkdirs()` returns:

```javascript
if (config.gateway.enabled) {
  return { 'workspace': '/workspace' };
}
```

This ensures there's always exactly one workspace in gateway mode, triggering auto-select.

### 3. Workspace Manager Registration

The Telegram chat is registered in the workspace manager database:

```javascript
await workspaceManager.registerTelegramChat(chatId, workspace.id);
```

This creates a proper database association between:
- Telegram chat ID: `-4868224422`
- Workspace ID: `f42d18d8-d13c-4d54-be81-07d322b5673d`

## Benefits

### Clean Architecture
- **No wildcards**: Each chat is explicitly registered
- **Database-backed**: Associations stored in workspace manager DB
- **Type-safe**: Proper foreign key relationships

### Better Features
- **Workspace settings**: Per-workspace configuration applies to associated chats
- **Analytics**: Track which chats use which workspaces
- **Metadata**: Store chat-specific metadata in workspace context

### User Experience
- **Zero configuration**: Works immediately on first message
- **Transparent**: Users don't need to know about workdirs
- **Consistent**: Same behavior across all commands (`/add`, `/continue`, `/shell`)

## Flow Example

### First Message from Gateway

```
1. User sends: "/add hi" from Telegram chat -4868224422
2. Gateway forwards to ani-code daemon
3. ani-code checks: No workdir configured for this chat
4. ani-code queries: getAvailableWorkdirs()
   → Returns: {'workspace': '/workspace'}
5. Auto-select triggered (only one workspace)
6. Save to ChatSettings: telegram:-4868224422 → "workspace"
7. Get workspace from DB: getWorkspaceByPath('/workspace')
   → Returns: workspace_id = f42d18d8-...
8. Register chat: registerTelegramChat(-4868224422, f42d18d8-...)
9. Create task with workdir: /workspace
10. Success!
```

### Subsequent Messages

```
1. User sends: "/add another task"
2. ani-code checks: Workdir configured = "workspace"
3. Resolve path: /workspace
4. Create task immediately
```

## Error Cases

### No Workspaces Available

```
❌ No workspaces available

Please connect a workspace using /connect [token] first
```

### Multiple Workspaces Available

```
❌ No working directory selected

Available workspaces: workspace, project-a, project-b

Use /workdir [name] to select one
```

## Configuration

### Gateway Mode Detection

```javascript
config.gateway.enabled = !!process.env.GATEWAY_URL
```

### Default Workspace Path

```javascript
// In gateway mode, always uses /workspace
workdirs['workspace'] = '/workspace';
```

## Compatibility

### Non-Gateway Mode
- Uses workspace manager for chat-workspace associations
- Supports multiple workspaces per instance
- Requires explicit `/workdir` selection if multiple workspaces

### Gateway Mode
- Always has exactly one workspace: `/workspace`
- Auto-selects and registers on first use
- Stores association in both ChatSettings and workspace manager

## Database Schema

### telegram_chats Table
```sql
CREATE TABLE telegram_chats (
  id INTEGER PRIMARY KEY,
  chat_id TEXT UNIQUE NOT NULL,
  workspace_id TEXT,
  created_at TEXT,
  FOREIGN KEY (workspace_id) REFERENCES workspaces(id)
);
```

### workspaces Table
```sql
CREATE TABLE workspaces (
  id TEXT PRIMARY KEY,
  workspace_name TEXT,
  workspace_path TEXT UNIQUE,
  created_at TEXT
);
```

## Logging

### Auto-Select
```
INFO: [Gateway] Auto-selected workdir 'workspace' for chat -4868224422 (only one available)
```

### Registration
```
INFO: [Gateway] Registered Telegram chat -4868224422 with workspace f42d18d8-... (workspace)
```

### Errors
```
WARN: [Gateway] Failed to register Telegram chat with workspace: <error>
```

## Testing

### Manual Test
```bash
# Send from Telegram
/add hi

# Check logs
journalctl -u ani-code -f | grep -E "Auto-selected|Registered"

# Expected:
# INFO: [Gateway] Auto-selected workdir 'workspace' for chat -4868224422
# INFO: [Gateway] Registered Telegram chat -4868224422 with workspace ...
```

### Verify Database
```bash
# Check workspace
ani-code workspace ls

# Check chat registration (via WorkspaceManager)
sqlite3 ~/.ani-code/workspace.db "
  SELECT c.chat_id, w.workspace_name, w.workspace_path
  FROM telegram_chats c
  JOIN workspaces w ON c.workspace_id = w.id
  WHERE c.chat_id = '-4868224422';
"
```

## Rollback Plan

If issues occur:

```bash
# Revert to manual workdir selection
git revert aadeaf8  # Auto-registration commit
git revert 1e07766  # Auto-select commit

# Users will see:
# "❌ No working directory selected"
# "Use /workdir workspace to set a working directory first"
```

## Future Enhancements

### Potential Improvements
- Support workspace switching via `/workdir` even in gateway mode
- Sync workspace settings from gateway registration
- Auto-create workspace from gateway metadata
- Support multiple workspaces in gateway mode (for multi-project instances)

### Related Features
- Workspace-specific Claude provider selection
- Per-workspace usage quotas
- Workspace-level access control

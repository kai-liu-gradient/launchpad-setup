# Ani Code - Claude Task Manager

A CLI tool for managing Claude tasks with real-time monitoring and chat bot notifications (Lark & Telegram).

## Features

- **Task Management**: Add, monitor, and manage Claude tasks
- **Real-time Monitoring**: Watch live output from running tasks
- **Task Cancellation**: Cancel running tasks on demand
- **Chat Bot Integration**: 
  - **Lark/Feishu**: Full support with interactive cards
  - **Telegram**: Full support with inline keyboards (NEW!)
- **Concurrent Execution**: Run multiple tasks simultaneously
- **Task History**: View detailed task information and output

## Installation

```bash
npm install
npm link  # Make the command available globally
```

## Configuration

Create a `.env` file with your configuration:

```env
# Chat Bot Configuration (choose one or both)

## Lark/Feishu Configuration
LARK_WEBHOOK_URL=your_lark_webhook_url
LARK_APP_ID=your_app_id           # Optional: for API mode
LARK_APP_SECRET=your_app_secret   # Optional: for API mode
LARK_GROUP_CHAT_ID=your_chat_id   # Optional: for API mode
LARK_KEYWORD_PREFIX=1              # Optional: prefix messages with hostname

## Telegram Configuration (NEW!)
TELEGRAM_BOT_TOKEN=your_bot_token_from_botfather
TELEGRAM_USE_WEBHOOK=false        # false for polling, true for webhook
TELEGRAM_CHAT_ID=                 # Optional: default chat ID

# Daemon Configuration
ANI_CODE_DAEMON_PORT=6501         # Optional: daemon HTTP API port (default: 6501)
# Alternative: HTTP_CALLBACK_PORT=6501 or PORT=6501
ANICODE_WS_PORT=6502              # Optional: WebSocket service port (default: 6502)

# Task Configuration
MAX_CONCURRENT_TASKS=3  # Optional: max concurrent tasks (default: 3)
TASK_TIMEOUT_MS=300000  # Optional: task timeout in ms (default: 5 minutes)
LOG_LEVEL=info          # Optional: logging level

# S3 Configuration (for upload command)
S3_CACHE_BUCKET=your-bucket-name
S3_ENDPOINT=s3://ACCESS_KEY:SECRET_KEY@endpoint-url
S3_FORCE_PATH_STYLE=false  # Optional: Set to true for path-style URLs

# Gateway Mode Configuration (Optional)
GATEWAY_URL=http://gateway:6555    # Gateway base URL
GATEWAY_TOKEN=your-secure-token    # Authentication token for gateway
INSTANCE_ID=ani-code-instance-1    # Unique instance identifier (defaults to hostname)
GATEWAY_REGISTER=true              # Auto-register on startup (default: true)
```

### Gateway Mode

Ani-code can run under gateway management for centralized routing and scaling.

#### Configuration

```env
# Enable gateway mode
GATEWAY_URL=http://gateway:6555
GATEWAY_TOKEN=your-secure-token
INSTANCE_ID=ani-code-instance-1

# Optional: disable auto-registration
GATEWAY_REGISTER=false
```

#### How It Works

1. Gateway receives webhooks from Telegram/Lark
2. Gateway routes to appropriate ani-code instance
3. Ani-code trusts gateway (bypasses user auth)
4. Ani-code processes request
5. Ani-code sends response to gateway (not direct to platform)
6. Gateway routes response to correct platform

#### Security

- Gateway validates users before forwarding
- Ani-code trusts gateway via token verification
- All callbacks must include valid instance token
- Fallback to direct send if gateway unavailable

#### Documentation

See [docs/GATEWAY_INTEGRATION.md](docs/GATEWAY_INTEGRATION.md) for complete gateway integration guide.

### Daemon Port Configuration

The daemon HTTP API port can be configured using environment variables. The port selection follows this priority:

1. `ANI_CODE_DAEMON_PORT` - Primary daemon-specific variable
2. `HTTP_CALLBACK_PORT` - Legacy fallback
3. `PORT` - Standard Node.js convention
4. `6501` - Default if no environment variable is set

The WebSocket service uses a separate port configured via `ANICODE_WS_PORT` (default: `6502`).

**Example: Running daemon on custom port**
```bash
# Method 1: Using ANI_CODE_DAEMON_PORT
ANI_CODE_DAEMON_PORT=6556 node src/daemon-runner.js

# Method 2: Using standard PORT variable
PORT=6556 node src/daemon-runner.js

# Method 3: In .env file
ANI_CODE_DAEMON_PORT=6556
```

**Use Case**: When deploying ani-code in containers alongside other applications, you can avoid port conflicts by setting a custom daemon port.

### Setting up Telegram Bot

See [TELEGRAM_SETUP.md](TELEGRAM_SETUP.md) for detailed Telegram bot setup instructions.

## Usage

### Add a Task

```bash
ani-code add "My Task" "claude --help"
ani-code add "Long Task" "claude --model claude-3-sonnet-20240229 --max-tokens 4000" --timeout 600000
```

### Monitor Tasks

```bash
# View all tasks
ani-code status

# Watch real-time output of a running task
ani-code watch <taskId>

# Get detailed information about a specific task
ani-code task <taskId>
```

### Cancel Tasks

```bash
# Cancel a running task
ani-code cancel <taskId>
```

### Other Commands

```bash
# Run shell command or custom workdir command
ani-code run <command>

# Send message to related Lark chat
ani-code message "Hello from command line"

# Upload file to S3 and get downloadable URL
ani-code upload output.pdf

# Send a test notification
ani-code test-notification

# Generate and send daily usage report
ani-code usage-report

# Force send usage report (even if already sent today)
ani-code usage-report --force

# Unlink the global command
ani-code unlink
```

### Custom Workdir Commands

You can define custom commands for your project by creating markdown files in the `.ani-code` directory:

```bash
# Create a custom command file
echo "Your Claude prompt here" > .ani-code/build-and-fix-prompt.md

# Run the custom command
ani-code run build-and-fix
```

Example custom command (`.ani-code/build-and-fix-prompt.md`):
```markdown
Run the build command and fix any errors:
1. Run npm run build
2. Analyze build output for errors
3. Fix any compilation or type errors
4. Re-run build to verify fixes
```

## Real-time Monitoring

The `watch` command allows you to see live output from running tasks:

```bash
ani-code watch abc123-def456-ghi789
```

This will display:
- Real-time stdout output (prefixed with `OUT`)
- Real-time stderr output (prefixed with `ERR`)
- Press `Ctrl+C` to stop watching

## Task Cancellation

You can cancel any running task using the `cancel` command:

```bash
ani-code cancel abc123-def456-ghi789
```

Cancelled tasks will:
- Stop execution immediately
- Update status to "cancelled"
- Send a notification to Lark
- Free up a slot for other tasks

## Task Status

Tasks can have the following statuses:
- **Pending**: Waiting to start
- **Running**: Currently executing
- **Completed**: Finished successfully
- **Failed**: Finished with an error
- **Cancelled**: Stopped by user

## Notifications

The tool sends Lark notifications for:
- Task started
- Task completed successfully
- Task failed
- Task cancelled
- Daily usage reports (sent after first successful task completion each day)

## Daily Usage Reports

The tool automatically generates and sends daily usage reports using the `ccusage` command. Reports include:

- **Total Usage**: Input/output tokens, cache usage, and total cost
- **Project Breakdown**: Usage statistics per project/workspace
- **Model Information**: Which models were used and their costs

### Automatic Reports
Daily usage reports are automatically sent after the first successful task completion each day. The system ensures only one report is sent per day.

### Manual Reports
You can manually generate and send usage reports:

```bash
# Send daily usage report
ani-code usage-report

# Force send report (even if already sent today)
ani-code usage-report --force
```

### Report Format
Reports are sent via Lark and include:
- Total token usage and costs
- Breakdown by project/workspace
- Model usage information
- Formatted for easy reading

## Gateway Integration (Optional)

Ani-code can optionally integrate with ani-code-gateway for multi-instance routing.

### Standalone Mode (Default)
No configuration needed. Ani-code works independently as usual.

### Gateway Mode
Add the following to your `.env` file:
```env
# Gateway integration configuration
GATEWAY_URL=http://localhost:6555
ANI_CODE_URL=http://localhost:3000
GATEWAY_API_KEY=your-api-key  # Optional, if gateway requires auth
```

When configured:
- Workspace tokens auto-register with gateway
- Gateway provides multi-user routing
- Heartbeat maintains instance health status
- Users connect via gateway tokens for Telegram/Lark

### Usage
```bash
# Create workspace (auto-registers with gateway if configured)
ani-code workspace create my-project

# Gateway token will be displayed for Telegram/Lark users
# Example output:
Gateway Token: gw_abc123...
Telegram users: /start gw_abc123...
```

### Benefits
- **Multi-Instance Support**: Route users to different ani-code instances
- **Transparent Integration**: Works with existing workspaces
- **Non-Breaking**: Gateway failures don't affect token creation
- **Backward Compatible**: All existing features work unchanged

See `.env.gateway.example` for configuration details.

## Development

```bash
# Install dependencies
npm install

# Run locally
node src/index.js --help
```
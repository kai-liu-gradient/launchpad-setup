# Ani-Code Diagnosis Command

## Overview
The `diagnosis` command provides a comprehensive health check and status report for the ani-code system, including version compatibility, configuration validation, and endpoint verification.

## Usage

```bash
# Basic diagnosis
ani-code diagnosis

# Verbose mode with detailed information
ani-code diagnosis -v

# JSON output for programmatic use
ani-code diagnosis -j
```

## Alias
- `ani-code diagnose` - Alternative command name

## Options
- `-v, --verbose` - Show detailed information including file checks and configuration details
- `-j, --json` - Output diagnosis results in JSON format

## Diagnosis Checks

### 1. System Information
- Platform and architecture
- Node.js version
- Current user
- System hostname
- System uptime

### 2. Daemon Status
- Running status (with PID if running)
- Service installation status
- Service running state

### 3. Version Compatibility
- CLI version
- Daemon version
- Compatibility check (major/minor/patch)
- Warning for version mismatches

### 4. API Endpoints
Tests the following endpoints:
- **Health** (`http://127.0.0.1:6501/health`) - Basic daemon health
- **Version** (`http://127.0.0.1:6501/version`) - Version information
- **WebSocket** (`ws://127.0.0.1:6502`) - WebSocket service availability

### 5. Configuration Validation
- Configuration file validity
- Lark integration status
- Telegram integration status
- Task settings (concurrent limits, timeouts)
- Claude provider configuration

### 6. File System (verbose mode only)
- `package.json` existence and size
- `.env` file presence
- `CLAUDE.md` documentation file
- Daemon PID file status

## Output Formats

### Standard Output
Provides a human-readable report with color-coded status indicators:
- ✓ Green checkmarks for healthy/successful items
- ⚠ Yellow warnings for minor issues
- ✗ Red X marks for errors or failures

### JSON Output
Structured JSON object containing all diagnosis data:
```json
{
  "timestamp": "2024-01-01T00:00:00.000Z",
  "system": { ... },
  "daemon": { ... },
  "version": { ... },
  "configuration": { ... },
  "endpoints": { ... },
  "services": { ... },
  "files": { ... },
  "errors": []
}
```

## Example Output

```
🔍 Ani-Code System Diagnosis

System Information
──────────────────────────────────────────────────
Platform:     linux (x64)
Node Version: v20.11.0
User:         root
Hostname:     workspace

Daemon Status
──────────────────────────────────────────────────
✓ Daemon is running (PID: 12345)
Service:      user service installed
✓ Service is active

Version Information
──────────────────────────────────────────────────
CLI Version:    1.0.0
Daemon Version: 1.0.0
✓ Versions are compatible

API Endpoints
──────────────────────────────────────────────────
✓ Health: http://127.0.0.1:6501/health (ok)
✓ Version: http://127.0.0.1:6501/version (ok)
✓ WebSocket: ws://127.0.0.1:6502 (available)

Configuration
──────────────────────────────────────────────────
✓ Configuration is valid

📊 Summary
──────────────────────────────────────────────────
✓ System is healthy
```

## Troubleshooting

### Common Issues

1. **Daemon not running**
   ```bash
   ani-code daemon --start
   ```

2. **Version mismatch**
   ```bash
   # Stop daemon and update
   ani-code daemon --stop
   npm update -g ani-code
   ani-code daemon --start
   ```

3. **Service not installed**
   ```bash
   ani-code service install --user
   ```

4. **Configuration errors**
   - Check `.env` file exists
   - Verify configuration values
   - Run `ani-code init` to recreate config

## Use Cases

1. **Pre-deployment check**: Run before deploying to ensure system health
2. **Debugging**: Identify configuration or connectivity issues
3. **Monitoring**: Regular health checks via cron or monitoring systems
4. **CI/CD integration**: Validate installation in automated pipelines

## Integration

The JSON output can be integrated with monitoring tools:

```bash
# Example: Check if system is healthy
ani-code diagnosis -j | jq '.daemon.running and .version.compatible'

# Example: Get daemon PID
ani-code diagnosis -j | jq '.daemon.pid'

# Example: Check all endpoints are working
ani-code diagnosis -j | jq '.endpoints | to_entries | all(.value.status == "ok" or .value.status == "available")'
```

## Notes

- The diagnosis command is read-only and safe to run at any time
- No system modifications are made during diagnosis
- Version checking gracefully handles old daemons without the version endpoint
- Network timeouts are set to 2 seconds to avoid hanging
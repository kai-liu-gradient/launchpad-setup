#!/usr/bin/env node
import { execSync } from 'child_process';

const today = new Date().toISOString().split('T')[0].replace(/-/g, '');

// Test 1: With --since filter
console.log('=== TEST 1: WITH --since FILTER ===');
const command1 = `npx ccusage -j --offline --breakdown --since ${today}`;
console.log('Running:', command1);
try {
  const output1 = execSync(command1, { encoding: 'utf8' });
  const data1 = JSON.parse(output1);
  console.log('Totals:', JSON.stringify(data1.totals, null, 2));
  console.log(`Cost: $${data1.totals.totalCost}, Tokens: ${data1.totals.totalTokens}`);
} catch (error) {
  console.error('Error:', error.message);
}

// Test 2: Without --since filter
console.log('\n=== TEST 2: WITHOUT --since FILTER ===');
const command2 = `npx ccusage -j --offline --breakdown`;
console.log('Running:', command2);
try {
  const output2 = execSync(command2, { encoding: 'utf8' });
  const data2 = JSON.parse(output2);
  console.log('Totals:', JSON.stringify(data2.totals, null, 2));
  console.log(`Cost: $${data2.totals.totalCost}, Tokens: ${data2.totals.totalTokens}`);
} catch (error) {
  console.error('Error:', error.message);
}

// Test 3: Just -j --offline
console.log('\n=== TEST 3: BASIC -j --offline ===');
const command3 = `npx ccusage -j --offline`;
console.log('Running:', command3);
try {
  const output3 = execSync(command3, { encoding: 'utf8' });
  const data3 = JSON.parse(output3);
  console.log('Totals:', JSON.stringify(data3.totals, null, 2));
  console.log(`Cost: $${data3.totals.totalCost}, Tokens: ${data3.totals.totalTokens}`);
} catch (error) {
  console.error('Error:', error.message);
}
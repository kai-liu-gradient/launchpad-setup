# Provider Detection from Telegram Messages

## Summary
Implemented automatic provider detection from Telegram messages using `@@codex` and `@@deepseek` syntax.

## Changes Made

### 1. Model Utils (`src/model-utils.js`)
- Added `extractProviderFromPrompt()` function to detect provider patterns in prompts
- Supports `@@codex` and `@@deepseek` patterns
- Returns provider ID or null if no provider specified

### 2. HTTP Server (`src/http-server.js`)
- Modified `createTelegramTask()` to extract provider from prompt
- Passes `providerId` in task options when provider is detected
- Logs provider detection: `🎯 Detected provider from prompt: {providerId}`

### 3. Task Queue (`src/task-queue.js`)
- Modified `runClaudeCommand()` to check for `task.providerId`
- Uses task-specific provider if specified via `providerManager.getHandler(providerId)`
- Falls back to current handler if provider not found
- Logs provider usage: `🔄 Using provider: {providerId} for task {taskId}`

### 4. Provider Manager (`src/providers/providerManager.js`)
- Added `deepseek` as a built-in provider
- Uses `ClaudeCliHandler` with `/usr/bin/claude` binary
- DeepSeek provider now available alongside claude, cursor, and codex

## Usage

Users can now specify providers in Telegram messages:

```
/add @@codex fix the authentication bug
/continue @@deepseek optimize the database queries
```

The system will automatically:
1. Extract the provider pattern from the prompt
2. Create task with the specified provider
3. Execute the task using that provider's handler

## How It Works

1. **User sends message**: `/add @@codex fix the bug`
2. **createTelegramTask()**: Extracts `codex` as providerId
3. **addTask()**: Stores providerId in task options
4. **executeTask()**: Uses codex handler instead of default
5. **Task runs**: Using the codex CLI provider

## Provider Support

Currently supported providers via `@@pattern`:
- `@@codex` → Uses Codex CLI handler
- `@@deepseek` → Uses Claude CLI handler (configured for DeepSeek)

Additional providers can be added by:
1. Updating `extractProviderFromPrompt()` with new pattern
2. Ensuring provider is registered in `providerManager`

## Notes

- Provider patterns are case-sensitive (`@@codex`, not `@@Codex`)
- If provider not found, falls back to workspace default
- Works for both `/add` and `/continue` commands
- Provider specification is optional
#!/usr/bin/env node
/**
 * Test script for Goal API endpoints
 */

import http from 'http';
import { join } from 'path';

// API configuration
const API_HOST = 'localhost';
const API_PORT = 6502;
const WORKSPACE_PATH = '/root/workspace/ani-code';
const BEARER_TOKEN = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6ImY5ZGJjNDdjLWU3MjItNDk0YS04Njc4LWEzODBkMjM0M2FhNiIsIndvcmtzcGFjZV9pZCI6IjdhZGE1NmJmLTVhYTctNDE4MS1iMTgwLTExZGNlMDVhMzRmOCIsIndvcmtzcGFjZV9uYW1lIjoiYW5pLWNvZGUiLCJ0eXBlIjoiYXBpIiwicGVybWlzc2lvbnMiOlsicmVhZCIsIndyaXRlIl0sImlhdCI6MTc2MzM5NjcwNn0._Ott2w1HntDZzBjVpYIHG1R5OqTRSqukGGLcfxxDuSA';

// Helper function to make HTTP requests
function makeRequest(method, path, body = null) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: API_HOST,
      port: API_PORT,
      path: `/api/${path}`,
      method,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${BEARER_TOKEN}`
      }
    };

    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const result = {
            status: res.statusCode,
            headers: res.headers,
            body: data ? JSON.parse(data) : null
          };
          resolve(result);
        } catch (e) {
          resolve({
            status: res.statusCode,
            headers: res.headers,
            body: data
          });
        }
      });
    });

    req.on('error', reject);

    if (body) {
      req.write(JSON.stringify(body));
    }

    req.end();
  });
}

// Test functions
async function testEndpoints() {
  console.log('🧪 Testing Goal API Endpoints\n');
  console.log('=' .repeat(50));

  // Test 1: GET /api/goals - List all goals
  console.log('\n📝 Test 1: GET /api/goals');
  console.log('-'.repeat(40));
  try {
    const result = await makeRequest('GET', 'goals');
    console.log(`Status: ${result.status}`);
    if (result.status === 200) {
      console.log(`✅ Success! Found ${result.body.goals?.length || 0} goal(s)`);
      if (result.body.goals && result.body.goals.length > 0) {
        console.log('First goal:', JSON.stringify(result.body.goals[0], null, 2));
      }
    } else {
      console.log(`❌ Failed: ${JSON.stringify(result.body)}`);
    }
  } catch (error) {
    console.log(`❌ Error: ${error.message}`);
  }

  // Test 2: GET /api/goals/running - Get running goals
  console.log('\n📝 Test 2: GET /api/goals/running');
  console.log('-'.repeat(40));
  try {
    const result = await makeRequest('GET', 'goals/running');
    console.log(`Status: ${result.status}`);
    if (result.status === 200) {
      console.log(`✅ Success! Found ${result.body.runningGoals?.length || 0} running goal(s)`);
    } else {
      console.log(`❌ Failed: ${JSON.stringify(result.body)}`);
    }
  } catch (error) {
    console.log(`❌ Error: ${error.message}`);
  }

  // Test 3: GET /api/goals/001 - Get specific goal
  console.log('\n📝 Test 3: GET /api/goals/001');
  console.log('-'.repeat(40));
  try {
    const result = await makeRequest('GET', 'goals/001');
    console.log(`Status: ${result.status}`);
    if (result.status === 200) {
      console.log(`✅ Success! Goal title: ${result.body.goal?.title}`);
      console.log(`   Status: ${result.body.goal?.status}`);
      console.log(`   Progress: ${result.body.goal?.progress}%`);
    } else {
      console.log(`❌ Failed: ${JSON.stringify(result.body)}`);
    }
  } catch (error) {
    console.log(`❌ Error: ${error.message}`);
  }

  // Test 4: POST /api/goals/sync - Sync goals
  console.log('\n📝 Test 4: POST /api/goals/sync');
  console.log('-'.repeat(40));
  try {
    const result = await makeRequest('POST', 'goals/sync', {
      force: false,
      verbose: true
    });
    console.log(`Status: ${result.status}`);
    if (result.status === 200) {
      console.log(`✅ Success! Sync completed`);
      console.log(`   Goals found: ${result.body.syncResult?.goalsFound}`);
      console.log(`   Duration: ${result.body.syncResult?.duration}`);
    } else {
      console.log(`❌ Failed: ${JSON.stringify(result.body)}`);
    }
  } catch (error) {
    console.log(`❌ Error: ${error.message}`);
  }

  // Test 5: POST /api/goals - Create new goal
  console.log('\n📝 Test 5: POST /api/goals (Create)');
  console.log('-'.repeat(40));
  try {
    const result = await makeRequest('POST', 'goals', {
      title: 'Test API Goal',
      objective: 'Test the goal creation API endpoint',
      description: 'This is a test goal created via the API',
      tasks: [
        'Test goal creation',
        'Verify goal appears in list',
        'Check goal details'
      ],
      acceptanceCriteria: [
        'Goal is created successfully',
        'Goal appears in goals list',
        'Goal has correct metadata'
      ],
      priority: 'medium',
      estimatedHours: 2
    });
    console.log(`Status: ${result.status}`);
    if (result.status === 201 || result.status === 200) {
      console.log(`✅ Success! Created goal: ${result.body.goal?.id}`);
      console.log(`   File: ${result.body.goal?.file}`);

      // Test update on the newly created goal
      if (result.body.goal?.goalNumber) {
        console.log('\n📝 Test 6: PUT /api/goals/{id} (Update)');
        console.log('-'.repeat(40));

        const updateResult = await makeRequest('PUT', `goals/${result.body.goal.goalNumber}`, {
          status: 'In Progress',
          progress: 50,
          tasks: [
            { text: 'Test goal creation', completed: true },
            { text: 'Verify goal appears in list', completed: true },
            { text: 'Check goal details', completed: false }
          ],
          notes: 'Updated via API test'
        });

        console.log(`Status: ${updateResult.status}`);
        if (updateResult.status === 200) {
          console.log(`✅ Success! Updated goal ${result.body.goal.goalNumber}`);
        } else {
          console.log(`❌ Failed: ${JSON.stringify(updateResult.body)}`);
        }

        // Test delete/archive
        console.log('\n📝 Test 7: DELETE /api/goals/{id} (Archive)');
        console.log('-'.repeat(40));

        const deleteResult = await makeRequest('DELETE', `goals/${result.body.goal.goalNumber}?archive=true`);
        console.log(`Status: ${deleteResult.status}`);
        if (deleteResult.status === 200) {
          console.log(`✅ Success! Goal archived`);
          console.log(`   Action: ${deleteResult.body.action}`);
        } else {
          console.log(`❌ Failed: ${JSON.stringify(deleteResult.body)}`);
        }
      }
    } else {
      console.log(`❌ Failed: ${JSON.stringify(result.body)}`);
    }
  } catch (error) {
    console.log(`❌ Error: ${error.message}`);
  }

  console.log('\n' + '='.repeat(50));
  console.log('✨ API Testing Complete!');
}

// Run tests
testEndpoints().catch(console.error);
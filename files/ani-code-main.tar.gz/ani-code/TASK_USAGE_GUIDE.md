# AniCode Task Usage Guide

## Quick Start

### 1. Navigate to Workspace Directory
```bash
cd /path/to/your/workspace
```

### 2. Create and Configure Workspace
```bash
# Create workspace in current directory
ani-code workspace create my-project

# Generate a workspace token for API access
ani-code workspace token gen -n "API Client" -t api
# Save the generated token - you'll need it for API calls
```

### 3. Set Homepage URL (Optional)
```bash
# Set the homepage URL for quick access after task completion
ani-code workspace meta set homepage https://your-project.com
```

## Task Management Commands

### Adding Tasks via Command Line

#### Using the `/add` command (from Telegram)
```
/add [your task description]
```

#### Using the `task` command (CLI)
```bash
# Add a task directly from command line
ani-code task add "Build the React component for user profile"

# Add task with specific workspace
ani-code task add "Fix authentication bug" --workspace my-project

# Add task with priority
ani-code task add "Deploy to production" --priority high
```

### Checking Task Progress

#### From Telegram
```
/check
```
This runs the completion checklist for your workspace

#### From Command Line
```bash
# Check status of all running tasks
ani-code task status

# Check specific task
ani-code task status [task-id]

# View task history
ani-code task history

# Monitor task output in real-time
ani-code task monitor [task-id]
```

## REST API Usage

### Authentication
All API calls require a workspace token in the Authorization header:
```
Authorization: Bearer YOUR_WORKSPACE_TOKEN
```

### Submit Task via REST API

#### Endpoint
```
POST http://localhost:6502/api/task
```

#### Request Headers
```json
{
  "Authorization": "Bearer YOUR_WORKSPACE_TOKEN",
  "Content-Type": "application/json"
}
```

#### Request Body
```json
{
  "name": "Task description",
  "command": "ani-code continue 'implement user authentication'",
  "workspace": "my-project",
  "priority": "normal",
  "metadata": {
    "source": "api",
    "requestId": "unique-request-id"
  }
}
```

#### Response
```json
{
  "success": true,
  "taskId": "task-uuid-here",
  "status": "queued",
  "workspace": "my-project",
  "queuePosition": 1
}
```

### Get Task Status via REST API

#### Endpoint
```
GET http://localhost:6502/api/task/{taskId}
```

#### Response
```json
{
  "id": "task-uuid-here",
  "name": "Task description",
  "status": "running",
  "progress": 45,
  "output": "Task output here...",
  "startedAt": "2024-01-15T10:30:00Z",
  "workspace": "my-project"
}
```

### List Tasks via REST API

#### Endpoint
```
GET http://localhost:6502/api/tasks?workspace=my-project&status=running
```

#### Query Parameters
- `workspace` - Filter by workspace name
- `status` - Filter by status (queued, running, completed, failed)
- `limit` - Maximum number of tasks to return
- `offset` - Pagination offset

#### Response
```json
{
  "tasks": [
    {
      "id": "task-uuid-1",
      "name": "Task 1",
      "status": "running",
      "startedAt": "2024-01-15T10:30:00Z"
    },
    {
      "id": "task-uuid-2",
      "name": "Task 2",
      "status": "completed",
      "completedAt": "2024-01-15T10:45:00Z"
    }
  ],
  "total": 15,
  "hasMore": true
}
```

### Cancel Task via REST API

#### Endpoint
```
DELETE http://localhost:6502/api/task/{taskId}
```

#### Response
```json
{
  "success": true,
  "message": "Task cancelled successfully"
}
```

## WebSocket API Usage

### Connection
```javascript
const ws = new WebSocket('ws://localhost:6502/socket', {
  headers: {
    'Authorization': 'Bearer YOUR_WORKSPACE_TOKEN'
  }
});
```

### Submit Task via WebSocket
```javascript
ws.send(JSON.stringify({
  type: 'task',
  action: 'create',
  taskData: {
    name: 'Build user dashboard',
    command: 'ani-code continue "implement dashboard components"',
    cwd: '/path/to/workspace'
  }
}));
```

### Monitor Task Progress
```javascript
ws.on('message', (data) => {
  const message = JSON.parse(data);
  
  switch(message.type) {
    case 'task_created':
      console.log('Task created:', message.taskId);
      break;
    case 'task_progress':
      console.log('Progress:', message.progress);
      break;
    case 'task_completed':
      console.log('Task completed:', message.result);
      break;
  }
});
```

## Examples

### Example: Full Task Workflow via API

```bash
# 1. Create workspace and get token
ani-code workspace create my-app
ani-code workspace token gen -n "CI/CD Pipeline" -t api
# Token: ws_abcd1234...

# 2. Submit task via curl
curl -X POST http://localhost:6502/api/task \
  -H "Authorization: Bearer ws_abcd1234..." \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Run tests and deploy",
    "command": "ani-code continue \"run test suite and deploy to staging\"",
    "workspace": "my-app"
  }'

# 3. Check task status
curl http://localhost:6502/api/task/task-uuid-here \
  -H "Authorization: Bearer ws_abcd1234..."

# 4. View completion checklist results
curl http://localhost:6502/api/task/task-uuid-here/checklist \
  -H "Authorization: Bearer ws_abcd1234..."
```

### Example: Python Client

```python
import requests
import json

class AniCodeClient:
    def __init__(self, token, base_url="http://localhost:6502"):
        self.token = token
        self.base_url = base_url
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
    
    def submit_task(self, name, command, workspace):
        response = requests.post(
            f"{self.base_url}/api/task",
            headers=self.headers,
            json={
                "name": name,
                "command": command,
                "workspace": workspace
            }
        )
        return response.json()
    
    def get_task_status(self, task_id):
        response = requests.get(
            f"{self.base_url}/api/task/{task_id}",
            headers=self.headers
        )
        return response.json()

# Usage
client = AniCodeClient("ws_your_token_here")
task = client.submit_task(
    "Implement user authentication",
    "ani-code continue 'add OAuth2 login'",
    "my-app"
)
print(f"Task ID: {task['taskId']}")
```

### Example: Node.js Client

```javascript
const axios = require('axios');

class AniCodeClient {
  constructor(token, baseUrl = 'http://localhost:6502') {
    this.token = token;
    this.baseUrl = baseUrl;
    this.headers = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    };
  }

  async submitTask(name, command, workspace) {
    const response = await axios.post(
      `${this.baseUrl}/api/task`,
      { name, command, workspace },
      { headers: this.headers }
    );
    return response.data;
  }

  async getTaskStatus(taskId) {
    const response = await axios.get(
      `${this.baseUrl}/api/task/${taskId}`,
      { headers: this.headers }
    );
    return response.data;
  }
}

// Usage
const client = new AniCodeClient('ws_your_token_here');
const task = await client.submitTask(
  'Build dashboard',
  'ani-code continue "create React dashboard"',
  'my-app'
);
console.log(`Task ID: ${task.taskId}`);
```

## Best Practices

1. **Always use workspace tokens** for API access, not direct authentication
2. **Set appropriate task priorities** to manage queue order
3. **Use meaningful task names** for better tracking and history
4. **Monitor task progress** via WebSocket for real-time updates
5. **Implement retry logic** for failed tasks
6. **Set workspace homepage** for quick access after task completion
7. **Use custom checklists** for workspace-specific validation

## Troubleshooting

### Task not starting
- Check if workspace exists: `ani-code workspace list`
- Verify token is valid: `ani-code workspace token validate YOUR_TOKEN`
- Check daemon status: `ani-code daemon --status`

### API connection issues
- Verify service is running: `ani-code status`
- Check port availability: `netstat -an | grep 6502`
- Review logs: `journalctl -u ani-code -f`

### WebSocket connection drops
- Implement reconnection logic with exponential backoff
- Check token expiration
- Monitor network stability

## Security Notes

1. **Token Management**
   - Store tokens securely (use environment variables)
   - Rotate tokens regularly
   - Use token expiration for temporary access

2. **Network Security**
   - Use HTTPS/WSS in production
   - Implement rate limiting
   - Whitelist allowed IP addresses if needed

3. **Workspace Isolation**
   - Each workspace has isolated access
   - Tokens are workspace-specific
   - Cross-workspace access requires multiple tokens
#!/usr/bin/env node

import { readdirSync, existsSync } from 'fs';
import { join } from 'path';

function findGoalFiles(goalsDir) {
  if (!existsSync(goalsDir)) {
    console.log(`Directory does not exist: ${goalsDir}`);
    return [];
  }

  const allFiles = readdirSync(goalsDir);
  console.log(`\nAll files in ${goalsDir}:`);
  allFiles.forEach(f => console.log(`  - ${f}`));

  const files = readdirSync(goalsDir)
    .filter(file => {
      // Only include .md files that start with a digit
      const isMarkdown = file.endsWith('.md');
      const startsWithDigit = /^\d/.test(file);
      const shouldInclude = isMarkdown && startsWithDigit;

      if (!shouldInclude) {
        console.log(`  Excluded: ${file} (md: ${isMarkdown}, digit: ${startsWithDigit})`);
      }
      return shouldInclude;
    })
    .sort()
    .map(file => join(goalsDir, file));

  return files;
}

// Test with the ghisha-helix path
const goalsDir = '/root/workspace/ghisha-helix/pd/goals';
console.log(`Testing findGoalFiles with: ${goalsDir}`);

const goalFiles = findGoalFiles(goalsDir);
console.log(`\nFound ${goalFiles.length} goal files:`);
goalFiles.forEach(f => {
  const filename = f.split('/').pop();
  const match = filename.match(/^(\d+)/);
  const goalId = match ? parseInt(match[1]) : null;
  console.log(`  ID: ${String(goalId).padStart(3, ' ')} - ${filename}`);
});

// Check for specific goal 061
const has061 = goalFiles.some(f => f.includes('061'));
console.log(`\nGoal 061 found: ${has061}`);

// Look for any files with 061 in name
console.log('\nFiles containing "061":');
const allFilesInDir = readdirSync(goalsDir);
allFilesInDir.filter(f => f.includes('061')).forEach(f => {
  console.log(`  - ${f}`);
});
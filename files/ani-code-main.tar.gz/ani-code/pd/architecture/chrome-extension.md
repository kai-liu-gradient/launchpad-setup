# Chrome Extension Architecture

## Overview
The AniCode Chrome Extension provides a browser-based interface for interacting with the AniCode daemon through WebSocket connections. It enables task management, file operations, and code assistance directly from the browser.

## Components

### Background Service Worker (`src/background.js`)
- Manages WebSocket connections to the AniCode daemon
- Handles message routing between content scripts and the daemon
- Maintains connection state and authentication tokens
- Implements reconnection logic for connection failures

### WebSocket Bridge (`src/wsBridge.js`)
- Establishes and maintains WebSocket connections
- Handles authentication using connection tokens
- Implements message queuing for offline scenarios
- Manages connection lifecycle and error handling

### Message Router (`src/messageRouter.js`) - *New Component (2025-08-27)*
- Centralized message routing between components
- Handles message type dispatching
- Implements message validation and filtering
- Provides consistent message format across extension

### Token Manager (`src/tokenManager.js`)
- **Enhanced domain-specific storage** (Updated 2025-08-28)
  - Separate token storage per domain for multi-project support
  - Automatic token migration from legacy storage
  - Token validation with enhanced security checks
  - JWT-based authentication with workspace integration
- Implements secure token storage using Chrome's storage API
- Handles token expiration and rotation
- Improved isolation between different project domains

### Task Manager (`src/taskManager.js`)
- Creates and monitors tasks on the AniCode daemon
- Tracks task status and output
- Provides task cancellation and retry functionality
- Implements task queue management

### Popup Interface (`public/popup.html`, `public/popup.js`)
- **Mobile-style tabbed UI** (Updated 2025-08-27)
  - Home tab: Connection management and quick status
  - Chat tab: Interactive command interface with /add and /continue shortcuts
  - Tasks tab: Task monitoring and management
  - Settings tab: Token configuration and preferences
- Token input and validation with domain-specific storage
- Real-time connection status display
- Quick actions and task shortcuts
- Shift+Tab toggle for command input modes

### Content Scripts (`src/content.js`, `src/content-minimal.js`)
- Inject functionality into web pages
- Handle page-specific interactions
- Communicate with background service worker
- Minimal script for reduced page impact

### Edit Mode (`src/editMode.js`, `src/editModeInjected.js`)
- Special mode for interactive editing
- Injects editing capabilities into pages
- Handles user input and selections
- Communicates edits back to daemon

## Recent Improvements (2025-08-28)

### Authentication Enhancement
- Improved token validation with JWT support
- Enhanced security for WebSocket authentication
- Better error handling for invalid tokens
- Domain-specific token isolation improvements

### Workspace Integration
- Chrome extension now works with workspace management system
- Support for workspace-specific tokens
- Enhanced authentication flow with workspace validation
- Backward compatibility with legacy tokens maintained

## Previous Improvements (2025-08-27)

### UI Redesign
- Implemented mobile-style tabbed interface for better usability
- Organized features into logical tabs (Home, Chat, Tasks, Settings)
- Added command shortcuts for quick task creation (/add, /continue)
- Improved visual hierarchy and user flow

### Enhanced Token Management
- Domain-specific token storage for multi-project support
- Automatic token migration from legacy storage format
- Token validation endpoints for testing connections
- Better error handling and user feedback

### Message Routing
- New centralized message router component
- Consistent message format across all components
- Improved message validation and type safety
- Better separation of concerns between components

## Security Features

### Content Security Policy (CSP)
Recent updates (commit 529165b) fixed CSP issues for WebSocket connections:

```json
{
  "content_security_policy": {
    "extension_pages": "script-src 'self'; object-src 'self'; connect-src 'self' ws://localhost:* wss://tyosp.steadyhash.ai https://tyosp.steadyhash.ai wss://*.steadyhash.ai https://*.steadyhash.ai"
  }
}
```

This allows:
- WebSocket connections to localhost (development)
- Secure WebSocket connections to production servers
- HTTPS connections for API calls

### Token-Based Authentication
- Tokens are generated server-side with HMAC-SHA256 signatures
- Each token includes:
  - Project information
  - Server URL
  - Expiration timestamp
  - Unique identifier
- Tokens are stored per-domain for multi-project support
- Automatic token cleanup for expired entries

### Message Handling Security
Recent fixes (commit 529165b) addressed async message handling:
- Proper async/await usage in message handlers
- Error boundaries for message processing
- Validation of incoming messages
- Sanitization of user inputs

## Connection Flow

1. **Token Generation**
   - User runs `ani-code plugin new-token` in project
   - Server generates signed token with project details
   - Token includes WebSocket URL and expiration

2. **Extension Connection**
   - User enters token in extension popup
   - Extension validates token format
   - Token stored in Chrome storage (domain-specific)
   - WebSocket connection initiated

3. **Authentication**
   - Extension sends token to WebSocket server
   - Server validates signature and expiration
   - Connection established or rejected
   - Client receives connection confirmation

4. **Communication**
   - Bidirectional message exchange
   - Task creation and monitoring
   - File operations and git commands
   - Real-time output streaming

5. **Disconnection Handling**
   - Automatic reconnection attempts
   - Message queuing during disconnection
   - Token refresh on expiration
   - Graceful shutdown on extension disable

## Recent Improvements (2025-08-25)

### UI Optimization (commit 1b327d9)
- Enhanced token input handling with validation feedback
- Improved connection flow with step-by-step guidance
- Refined styling for better visual consistency
- Added loading states and error messages

### Domain-Based Token Storage
- Tokens now stored per-domain
- Automatic token selection based on current site
- Support for multiple projects simultaneously
- Token migration from old storage format

### ES6 Module Migration (commit e03f329)
- Converted from CommonJS to ES6 modules
- Fixed module loading issues
- Improved code organization
- Better tree-shaking support

### Token Revocation (commit 310e6a8)
- Added `revoke-all` command for security
- Bulk token invalidation
- Cleanup of stored tokens
- Security reset capability

## Message Protocol

### Client to Server
```javascript
// Task creation
{
  type: 'task',
  action: 'create',
  taskData: {
    name: 'Task name',
    command: 'npm test',
    cwd: '/project/path'
  }
}

// File operations
{
  type: 'file',
  action: 'read',
  filePath: './src/index.js'
}

// Git operations
{
  type: 'git',
  action: 'status'
}
```

### Server to Client
```javascript
// Connection success
{
  type: 'connection',
  status: 'connected',
  clientId: 'client-123',
  projectPath: '/project/path'
}

// Task updates
{
  type: 'task_update',
  task: {
    id: 'task-123',
    status: 'running',
    output: '...'
  }
}

// Command results
{
  type: 'execute_result',
  success: true,
  stdout: '...',
  stderr: '...'
}
```

## Development Guidelines

### Adding New Features
1. Update message handlers in `background.js`
2. Add protocol support in `wsBridge.js`
3. Update popup UI if user-facing
4. Add content script hooks if page-specific
5. Update CSP if new connections needed

### Testing
- Test WebSocket connections with mock server
- Verify token validation and expiration
- Check reconnection logic
- Test message queuing during disconnection
- Validate CSP compliance

### Debugging
- Use Chrome DevTools for extension
- Check background service worker logs
- Monitor WebSocket frames in Network tab
- Use `chrome.storage.local.get()` for token inspection
- Enable verbose logging in development

## Future Enhancements

- [ ] WebSocket compression support
- [ ] Offline mode with sync
- [ ] Multi-tab coordination
- [ ] Advanced task templates
- [ ] Browser notifications for task completion
- [ ] Keyboard shortcuts for common actions
- [ ] Theme customization
- [ ] Export/import connection profiles
# WebSocket Service Architecture

## Overview
The WebSocket service provides real-time bidirectional communication between the ani-code daemon and Chrome plugin clients. It has been separated into its own service module (`src/ws-service/`) for better modularity and maintainability.

## Directory Structure
```
src/ws-service/
├── index.js              # Main WebSocket service class
├── chromePluginHandler.js # Handles Chrome plugin specific logic
├── tokenAuthenticator.js  # Token-based authentication
└── simpleWebSocket.js     # Pure Node.js WebSocket implementation
```

## Components

### WSService (`index.js`)
- Main service class that integrates with the daemon
- Manages WebSocket server lifecycle
- Handles client connections and authentication
- Provides broadcasting and client management APIs

### ChromePluginHandler (`chromePluginHandler.js`)
- Processes Chrome plugin specific messages
- Handles task creation, execution, and monitoring
- Manages file operations and git commands
- Sends real-time task updates to clients

### TokenAuthenticator (`tokenAuthenticator.js`)
- Validates connection tokens
- Manages token lifecycle and expiration
- Loads tokens from `.anicode/plugin-tokens.json`

### SimpleWebSocket (`simpleWebSocket.js`)
- Pure Node.js WebSocket implementation (no external dependencies)
- Implements WebSocket protocol (RFC 6455)
- Handles frames, opcodes, and connection management

## Integration with Daemon

The WebSocket service is started automatically when the daemon starts:

```javascript
// In daemon.js
import { WSService } from './ws-service/index.js';

// During daemon initialization
this.wsService = new WSService(this.taskMonitor, this.chatSettings);

// During daemon start
const wsPort = await this.wsService.start();
```

## Configuration

Environment variables:
- `ANICODE_WS_PORT`: WebSocket service port (default: 6502)
- `ANICODE_PLUGIN_URL`: Full WebSocket URL for clients (default: ws://localhost:6502)

## Endpoints

- `ws://localhost:6502/ws` - WebSocket connection endpoint
- `http://localhost:6502/health` - Health check endpoint

## Authentication

Clients must provide a valid token via:
1. Query parameter: `?token=<token>`
2. Authorization header: `Bearer <token>`

Tokens are generated using:
```bash
ani-code plugin new-token
```

## Message Protocol

### Client to Server Messages

```javascript
// Execute command
{
  type: 'execute',
  command: 'ls -la',
  cwd: './src'  // Optional
}

// Create task
{
  type: 'task',
  action: 'create',
  taskData: {
    name: 'My Task',
    command: 'npm test',
    cwd: '/path/to/project'
  }
}

// Git operations
{
  type: 'git',
  action: 'status' // or 'diff', 'log', 'branch'
}

// File operations
{
  type: 'file',
  action: 'read', // or 'write', 'exists', 'list'
  filePath: './src/index.js',
  content: '...' // For write action
}
```

### Server to Client Messages

```javascript
// Connection success
{
  type: 'connection',
  status: 'connected',
  clientId: 'client-123...',
  projectPath: '/path/to/project'
}

// Task updates
{
  type: 'task_update',
  task: {
    id: 'task-123',
    status: 'running',
    output: '...',
    // ...
  }
}

// Command results
{
  type: 'execute_result',
  command: 'ls -la',
  stdout: '...',
  stderr: '...',
  success: true
}
```

## Security Features

1. **Token-based authentication**: All connections require valid tokens
2. **Path validation**: File operations are restricted to project directory
3. **Command timeout**: Commands have a 30-second timeout by default
4. **Connection limits**: Can be configured via environment variables
5. **Secure token generation**: Uses crypto.randomBytes for token generation

## Development

### Testing the WebSocket Service

```bash
# Run the test script
node test-ws-service.js

# Start daemon with WebSocket service
ani-code daemon --start

# Check service health
curl http://localhost:6502/health
```

### Adding New Message Types

1. Add handler in `chromePluginHandler.js`:
```javascript
async handleMessage(clientId, data) {
  switch (data.type) {
    case 'new_type':
      await this.handleNewType(ws, data, projectPath);
      break;
  }
}
```

2. Implement the handler method:
```javascript
async handleNewType(ws, data, projectPath) {
  // Implementation
  ws.send(JSON.stringify({
    type: 'new_type_result',
    // ...
  }));
}
```

## Benefits of Separate Service

1. **Modularity**: WebSocket logic is isolated from HTTP server
2. **Scalability**: Can be scaled independently
3. **Maintainability**: Clear separation of concerns
4. **Testability**: Easy to test in isolation
5. **Reusability**: Can be used by other services if needed

## Future Enhancements

- [ ] Add WebSocket compression support
- [ ] Implement rate limiting per client
- [ ] Add metrics and monitoring
- [ ] Support for WebSocket subprotocols
- [ ] Cluster mode for multiple workers
- [ ] SSL/TLS support for secure connections
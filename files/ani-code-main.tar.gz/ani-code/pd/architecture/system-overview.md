# System Architecture Overview

Ani-code is a daemon-based task execution system with multi-channel control interfaces.

## Recent Enhancements

### Goals Management System (2025-11-07)
- Structured project goal management in `pd/goals/`
- Markdown-based goal files with progress tracking
- Intelligent caching with workspace metadata integration
- Automated goal execution loops with Claude
- Task completion tracking and status management
- Manual flag for human-required tasks
- Cache sync with file change detection
- Goal selection by ID, filename, or description search

### Plan Management System (2025-09-17)
- Multi-step task planning and execution
- FIFO ordering for predictable execution with consistent sorting
- YOLO mode for automated plan completion with cost tracking
- Automatic commit generation with Claude Sonnet
- Plan persistence in workspace database
- Cancel progress command for in-progress plans
- Purge command for force resetting all plans
- Improved plan execution resilience and task validation
- Timeout protection and duplicate response prevention

### Git Status Integration (2025-08-21)
- Status command now includes git repository information
- Smart action buttons based on repository state
- Real-time git status with file counts
- Integration with AI commit workflow

### Message Deduplication (2025-08-21)
- Prevents duplicate webhook processing
- Filters stale messages (>10 seconds old)
- Automatic cache cleanup for memory efficiency
- Comprehensive logging for debugging

## Core Components

### 1. Daemon Process (`daemon.js`)
The central background service that manages all operations.

**Responsibilities**:
- Task queue management
- Process lifecycle control
- Service coordination
- Resource management

**Key Features**:
- Single instance enforcement
- Graceful shutdown handling
- Signal management (SIGTERM, SIGINT)
- PID file management

### 2. Task Monitor (`task-monitor.js`)
Manages task execution and monitoring.

**Features**:
- Concurrent task execution (default: 3 parallel)
- Task queuing and scheduling
- Output streaming and logging
- Status tracking and reporting
- Event emission for real-time updates

**Task Lifecycle**:
1. **Pending**: Queued for execution
2. **Running**: Currently executing
3. **Success**: Completed with exit code 0
4. **Failure**: Completed with non-zero exit code
5. **Cancelled**: Terminated by user request

### 3. Communication Layers

#### IPC Server (`ipc-server.js`)
Local inter-process communication for CLI commands.

- **Protocol**: TCP sockets on localhost
- **Port Discovery**: Via `.ani-code-ipc.port` file
- **Message Format**: Newline-delimited JSON
- **Security**: Localhost-only binding

#### HTTP Server (`http-server.js`)
Web server for external integrations.

- **Endpoints**: Health checks, Lark webhooks
- **CORS**: Enabled for cross-origin requests
- **Authentication**: Optional token verification
- **Port**: Configurable (default: 3456)

### 4. Integration Services

#### Lark Notifier (`lark-notifier.js`)
Sends notifications to Lark messenger.

**Capabilities**:
- Rich message formatting
- Interactive card messages
- Button actions
- Group chat support
- Emoji status indicators

#### Chat Settings Manager (`chat-settings.js`)
Persistent storage for chat configurations.

**Features**:
- Working directory per chat
- Settings persistence
- Statistics tracking
- Multi-chat support

#### Message Deduplication System
Prevents duplicate webhook processing.

**Components**:
- Message ID cache (in-memory Map)
- Timestamp validation (10-second threshold)
- Automatic cache cleanup (30-second interval)
- Detailed logging for debugging

### 5. CLI Interface (`index.js`)
Command-line interface for user interaction.

**Commands**:
- `daemon`: Start/stop/restart daemon
- `add`: Add and manage tasks
- `continue`: Continue conversations
- `goals`: Manage project goals
- `plan`: Create and manage task plans
- `next`: Execute next plan step
- `status`: View queue and plan status
- `doc`: Generate documentation
- `commit`: Git commit workflow
- `branch`: Git branch management
- `service`: System service setup

## Data Flow

```
User Input → CLI → IPC Client → IPC Server → Task Monitor → Task Queue
                                     ↑              ↓
                     Lark Bot → HTTP Server    Task Execution
                                     ↑              ↓
                              Webhook Events   Process Output
                                                    ↓
                                              Notifications
                                                    ↓
                                               Lark Users
```

## Communication Patterns

### CLI to Daemon
1. User runs CLI command
2. CLI reads IPC port from file
3. CLI connects to daemon via TCP
4. Sends JSON request
5. Receives JSON response
6. Displays result to user

### Lark to Daemon
1. User sends Lark message
2. Lark sends webhook to HTTP server
3. Server checks for duplicate message ID
4. Validates message age (<10 seconds)
5. Server validates token (if configured)
6. Parses command from message
7. Executes via Task Monitor
8. Sends notification back to Lark

### Task Execution
1. Task added to queue
2. Monitor checks concurrency limit
3. Spawns child process
4. Streams output to logs
5. Broadcasts events to clients
6. Updates task status
7. Sends completion notification

## File Structure

```
ani-code/
├── src/
│   ├── index.js           # CLI entry point
│   ├── daemon.js          # Daemon process
│   ├── daemon-client.js   # Daemon control client
│   ├── daemon-runner.js   # Daemon launcher
│   ├── task-monitor.js    # Task execution engine
│   ├── task-queue.js      # Queue management
│   ├── ipc-server.js      # Local IPC server
│   ├── ipc-client.js      # IPC client library
│   ├── http-server.js     # HTTP webhook server
│   ├── lark-notifier.js   # Lark integration
│   ├── chat-settings.js   # Chat configuration
│   ├── workspace-manager.js # Workspace management
│   ├── logger.js          # Logging utility
│   ├── config.js          # Configuration loader
│   ├── service-installer.js # System service setup
│   └── commands/
│       └── goals.js       # Goals management system
├── pd/                    # Project documentation
│   ├── api/              # API documentation
│   ├── architecture/     # Architecture docs
│   ├── changes/          # Daily change logs
│   ├── features/         # Feature documentation
│   └── goals/            # Project goals (managed by goals system)
├── logs/                 # Task execution logs
├── .ani-code/            # Runtime data
│   ├── workspaces.db     # Workspace metadata and goals cache
│   └── goals-cache.json  # Fallback goals cache
├── .env                  # Environment configuration
├── CLAUDE.md            # AI assistant instructions
└── package.json         # Node.js dependencies
```

## Configuration

### Environment Variables
Configuration is primarily through `.env` file:

- **Daemon**: Ports, concurrency, paths
- **Lark**: Credentials, webhooks, chat IDs
- **HTTP**: Server binding and ports
- **Logging**: Levels and output

### Runtime Files
- `.ani-code-daemon.pid`: Daemon process ID
- `.ani-code-ipc.port`: IPC server port
- `.chat-settings.json`: Persistent chat config
- `.ani-code/workspaces.db`: Workspace metadata and goals cache
- `.ani-code/goals-cache.json`: Fallback goals cache
- `logs/*.log`: Task execution logs

## Security Considerations

1. **Local Access**: IPC server binds to localhost only
2. **Token Validation**: Optional webhook verification
3. **Directory Restrictions**: Working directories limit access
4. **Process Isolation**: Tasks run as child processes
5. **Resource Limits**: Configurable concurrency and timeouts

## Scalability

### Current Limits
- Default 3 concurrent tasks
- Single daemon instance per system
- Memory-based task queue

### Extension Points
- Task queue can be backed by database
- HTTP server supports multiple workers
- Notification system is pluggable
- Command system is extensible

## Monitoring

### Health Checks
- `/health` endpoint for HTTP monitoring
- `ping` action for IPC health check
- Process status via PID file

### Logging
- Structured logging with timestamps
- Multiple log levels (debug, info, warn, error)
- Per-task log files
- Daemon activity logs

### Metrics
- Task execution counts
- Success/failure rates
- Execution durations
- Queue depths
- Chat usage statistics
- Goal completion rates
- Task progress tracking

## Goals Management System

### Architecture

The goals system provides structured project management with markdown-based goal files stored in `pd/goals/`. It integrates with workspace metadata for intelligent caching and automated execution.

**Key Components:**
1. **Goal Files**: Markdown files in `pd/goals/` with structured format
2. **Cache System**: Workspace metadata or fallback JSON cache
3. **Parser**: Extracts goals, tasks, progress from markdown
4. **Execution Loop**: Automated Claude-driven goal implementation
5. **Workspace Integration**: Per-workspace goal tracking

### Cache Architecture

**Storage Hierarchy:**
1. **Primary**: Workspace metadata in `~/.ani-code/workspaces.db`
2. **Fallback**: File-based cache in `.ani-code/goals-cache.json`

**Cache Invalidation:**
- Checks file modification times
- Auto-refreshes on file changes
- Manual refresh via `sync` command

**Cache Structure:**
```javascript
{
  lastUpdated: "ISO8601 timestamp",
  totalGoals: 15,
  summary: {
    notStarted: 5,
    inProgress: 3,
    completed: 7,
    totalTasks: 145,
    completedTasks: 87,
    overallPercentage: 60
  },
  goals: [/* parsed goal objects */]
}
```

### Goal Execution Flow

```
User → goals loop → Load PRD → Select Goal → Send to Claude
                         ↓
                    Implement Tasks
                         ↓
                  Update Goal File
                         ↓
                   Validate Changes
                         ↓
                   Sync Cache → Continue Loop
```

**Selection Priority:**
1. Non-[MANUAL] goals
2. In Progress status
3. Lowest completion percentage
4. Not Started goals

### Integration Points

**With Daemon:**
- Creates tasks via IPC
- Monitors task progress
- Handles completion/failure

**With Workspace Manager:**
- Stores cache in workspace metadata
- Multi-workspace support
- Isolated goal tracking

**With Claude:**
- Goal analysis and parsing
- Automated task implementation
- Progress validation

### See Also
- [Goals Feature Documentation](../features/goals.md)
- [Goals API Documentation](../api/goals.md)
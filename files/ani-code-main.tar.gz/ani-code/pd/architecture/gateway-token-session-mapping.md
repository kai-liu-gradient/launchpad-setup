# Gateway Token-Session Mapping Architecture

## Overview
This document describes the token-session mapping architecture that enables ani-code-gateway to route responses from ani-code daemon instances back to the correct communication channels (Telegram, Lark, etc.).

## Core Concept

The gateway maintains a bidirectional mapping between:
1. **Gateway Tokens** (`gw_xxx`): Unique tokens generated for each session
2. **Session Context**: Platform, chat ID, user ID, and routing information

## Token Lifecycle

### 1. Session Creation

When a user initiates communication through a platform (e.g., Telegram `/start` command):

```
User -> Platform -> Gateway -> Session Created -> Token Generated -> Ani-Code Daemon
```

**Example Flow:**
```javascript
// Telegram user sends: /start ws_abc123xyz
{
  "update_id": 12345,
  "message": {
    "chat": { "id": "-4868224422" },
    "from": { "id": "123456", "username": "john_doe" },
    "text": "/start ws_abc123xyz"
  }
}

// Gateway creates session:
{
  "gateway_token": "gw_7f8a9b2c3d4e5f6g",
  "platform": "telegram",
  "chat_id": "-4868224422",
  "user_id": "123456",
  "workspace_token": "ws_abc123xyz",
  "instance_url": "http://ani-code-1:6501",
  "created_at": "2025-11-22T10:00:00Z"
}

// Gateway forwards to ani-code with headers:
{
  "x-gateway-token": "gw_7f8a9b2c3d4e5f6g",
  "x-gateway-url": "https://gateway.example.com",
  "x-source-platform": "telegram",
  "x-chat-id": "-4868224422"
}
```

### 2. Token Usage

The ani-code daemon stores the gateway token and uses it for all responses:

```javascript
// Ani-code daemon sends response:
POST https://gateway.example.com/api/callback/message
Headers:
  x-gateway-token: gw_7f8a9b2c3d4e5f6g
  x-instance-id: ani-code-1

Body:
{
  "message": {
    "text": "Task completed successfully!",
    "reply_markup": { ... }
  }
}

// Gateway looks up session:
Session[gw_7f8a9b2c3d4e5f6g] -> {
  platform: "telegram",
  chat_id: "-4868224422"
}

// Gateway sends to Telegram:
POST https://api.telegram.org/botXXX/sendMessage
{
  "chat_id": "-4868224422",
  "text": "Task completed successfully!",
  "reply_markup": { ... }
}
```

### 3. Session Expiry

Sessions expire after a configurable timeout (default: 60 minutes) of inactivity:

```javascript
// Cleanup process runs every 10 minutes
SELECT * FROM gateway_sessions
WHERE last_activity < datetime('now', '-60 minutes')
OR expires_at < datetime('now')
```

## Token Format

Gateway tokens follow a specific format for security and debugging:

```
gw_[random_hex_string]

Example: gw_7f8a9b2c3d4e5f6g
```

- Prefix `gw_` identifies it as a gateway-generated token
- 16-character random hex string ensures uniqueness
- Cryptographically secure random generation

## Session State Management

### Session States

1. **Active**: Normal operational state
2. **Expired**: Past timeout, awaiting cleanup
3. **Revoked**: Manually terminated

### Session Data Structure

```typescript
interface GatewaySession {
  // Identifiers
  id: number;                    // Database primary key
  gateway_token: string;          // Unique token (gw_xxx)

  // Platform Information
  platform: 'telegram' | 'lark'; // Communication platform
  chat_id: string;               // Platform-specific chat ID
  user_id?: string;              // Platform-specific user ID

  // Workspace Information
  workspace_token: string;        // Original workspace token
  instance_url: string;          // Target ani-code instance

  // Metadata
  metadata?: {
    username?: string;           // User's display name
    language?: string;           // User's language preference
    timezone?: string;           // User's timezone
    [key: string]: any;         // Additional platform-specific data
  };

  // Timestamps
  created_at: Date;              // Session creation time
  last_activity: Date;           // Last message time
  expires_at?: Date;             // Optional explicit expiry
}
```

## Security Model

### Token Security

1. **Generation**: Uses crypto.randomBytes() for secure random generation
2. **Storage**: Tokens stored as hash in database (optional)
3. **Transmission**: Always over HTTPS in production
4. **Validation**: Constant-time comparison to prevent timing attacks

### Access Control

```javascript
// Token validation middleware
async function validateGatewayToken(req, res, next) {
  const token = req.headers['x-gateway-token'];

  if (!token) {
    return res.status(401).json({ error: 'Missing gateway token' });
  }

  const session = await sessionManager.getSession(token);

  if (!session) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }

  // Attach session to request
  req.session = session;
  next();
}
```

### Rate Limiting

Per-token rate limiting prevents abuse:

```javascript
const rateLimits = {
  'message_callback': {
    windowMs: 60000,      // 1 minute
    max: 60,             // 60 requests per minute
    keyGenerator: (req) => req.headers['x-gateway-token']
  }
};
```

## Platform-Specific Handling

### Telegram Sessions

```javascript
// Telegram session creation
async function createTelegramSession(update) {
  const chatId = update.message?.chat?.id;
  const userId = update.message?.from?.id;
  const text = update.message?.text;

  // Parse /start command
  const match = text?.match(/^\/start\s+(\S+)/);
  if (match) {
    const workspaceToken = match[1];

    return await sessionManager.createSession({
      platform: 'telegram',
      chatId: chatId.toString(),
      userId: userId?.toString(),
      workspaceToken,
      metadata: {
        username: update.message?.from?.username,
        first_name: update.message?.from?.first_name,
        language_code: update.message?.from?.language_code
      }
    });
  }
}
```

### Lark Sessions

```javascript
// Lark session creation
async function createLarkSession(event) {
  const chatId = event.message?.chat_id;
  const userId = event.sender?.sender_id?.user_id;

  return await sessionManager.createSession({
    platform: 'lark',
    chatId,
    userId,
    metadata: {
      tenant_key: event.tenant_key,
      app_id: event.app_id
    }
  });
}
```

## Database Design

### Indexes for Performance

```sql
-- Primary lookup index
CREATE UNIQUE INDEX idx_gateway_token ON gateway_sessions(gateway_token);

-- Platform-specific lookups
CREATE INDEX idx_platform_chat ON gateway_sessions(platform, chat_id);

-- Cleanup operations
CREATE INDEX idx_expires_at ON gateway_sessions(expires_at)
  WHERE expires_at IS NOT NULL;

CREATE INDEX idx_last_activity ON gateway_sessions(last_activity);
```

### Query Patterns

```sql
-- Get session by token (most common)
SELECT * FROM gateway_sessions WHERE gateway_token = ?;

-- Find existing session for chat
SELECT * FROM gateway_sessions
WHERE platform = ? AND chat_id = ?
AND last_activity > datetime('now', '-60 minutes');

-- Cleanup expired sessions
DELETE FROM gateway_sessions
WHERE last_activity < datetime('now', '-60 minutes')
OR (expires_at IS NOT NULL AND expires_at < datetime('now'));
```

## Caching Strategy

### In-Memory Cache

For performance, active sessions are cached in memory:

```javascript
class SessionCache {
  constructor(ttl = 300) { // 5 minute TTL
    this.cache = new Map();
    this.ttl = ttl * 1000;
  }

  set(token, session) {
    this.cache.set(token, {
      session,
      expires: Date.now() + this.ttl
    });
  }

  get(token) {
    const cached = this.cache.get(token);

    if (!cached) return null;

    if (Date.now() > cached.expires) {
      this.cache.delete(token);
      return null;
    }

    return cached.session;
  }

  invalidate(token) {
    this.cache.delete(token);
  }
}
```

### Cache Invalidation

Cache is invalidated on:
- Session update
- Session deletion
- TTL expiry

## Monitoring & Observability

### Key Metrics

```javascript
// Prometheus metrics
const metrics = {
  sessions_active: new Gauge({
    name: 'gateway_sessions_active_total',
    help: 'Number of active sessions',
    labelNames: ['platform']
  }),

  sessions_created: new Counter({
    name: 'gateway_sessions_created_total',
    help: 'Total sessions created',
    labelNames: ['platform']
  }),

  sessions_expired: new Counter({
    name: 'gateway_sessions_expired_total',
    help: 'Total sessions expired',
    labelNames: ['platform', 'reason']
  }),

  token_validations: new Counter({
    name: 'gateway_token_validations_total',
    help: 'Token validation attempts',
    labelNames: ['result']
  })
};
```

### Logging

```javascript
// Structured logging for session events
logger.info('Session created', {
  event: 'session.created',
  gateway_token: token,
  platform: session.platform,
  chat_id: session.chat_id,
  instance_url: session.instance_url
});

logger.warn('Session expired', {
  event: 'session.expired',
  gateway_token: token,
  reason: 'timeout',
  last_activity: session.last_activity
});
```

## Error Handling

### Common Error Scenarios

1. **Invalid Token**
   ```json
   {
     "error": "Invalid gateway token",
     "code": "INVALID_TOKEN",
     "status": 401
   }
   ```

2. **Expired Session**
   ```json
   {
     "error": "Session expired",
     "code": "SESSION_EXPIRED",
     "status": 401,
     "details": {
       "expired_at": "2025-11-22T11:00:00Z"
     }
   }
   ```

3. **Platform Error**
   ```json
   {
     "error": "Failed to send message",
     "code": "PLATFORM_ERROR",
     "status": 502,
     "details": {
       "platform": "telegram",
       "platform_error": "Bad Request: chat not found"
     }
   }
   ```

## Migration & Compatibility

### Backward Compatibility

The system maintains backward compatibility with direct sending:

```javascript
// Fallback logic in ani-code daemon
async function sendMessage(chatId, text, options) {
  if (config.gateway.enabled && config.gateway.token) {
    try {
      // Try gateway first
      return await sendViaGateway(chatId, text, options);
    } catch (error) {
      logger.warn('Gateway send failed, falling back to direct');
    }
  }

  // Fallback to direct send
  return await sendDirectToTelegram(chatId, text, options);
}
```

### Migration Path

1. **Phase 1**: Deploy gateway with session management
2. **Phase 2**: Update ani-code daemons to use callback API
3. **Phase 3**: Monitor and optimize
4. **Phase 4**: Deprecate direct sending

## Best Practices

### For Gateway Operators

1. **Session Timeout**: Set appropriate timeout based on usage patterns
2. **Cleanup Frequency**: Run cleanup frequently enough to prevent database bloat
3. **Cache TTL**: Balance between performance and consistency
4. **Monitoring**: Alert on high session creation rates or validation failures

### For Ani-Code Developers

1. **Token Storage**: Store gateway token securely in daemon state
2. **Error Handling**: Implement retry logic with exponential backoff
3. **Fallback**: Always have fallback to direct sending
4. **Logging**: Log all gateway interactions for debugging

## Troubleshooting Guide

### Session Not Found

**Symptom**: "Invalid gateway token" errors

**Causes**:
1. Session expired due to inactivity
2. Gateway restarted and lost in-memory state
3. Token corruption during transmission

**Resolution**:
1. Check session timeout settings
2. Verify token is being sent correctly
3. Check gateway logs for session creation
4. Ensure database persistence is working

### Message Not Delivered

**Symptom**: Messages not appearing in platform

**Causes**:
1. Invalid platform credentials
2. Platform API rate limiting
3. Network connectivity issues

**Resolution**:
1. Verify bot tokens/credentials
2. Check platform API status
3. Review gateway error logs
4. Test platform API directly

### High Memory Usage

**Symptom**: Gateway memory growing over time

**Causes**:
1. Session cache not expiring
2. Message history growing unbounded
3. Memory leaks in platform handlers

**Resolution**:
1. Review cache TTL settings
2. Enable message history cleanup
3. Monitor session counts
4. Profile memory usage
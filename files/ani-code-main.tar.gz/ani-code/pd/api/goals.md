# Goals API

## Overview

The Goals API provides programmatic access to goal management, cache operations, and goal file parsing. Used internally by CLI commands and HTTP endpoints.

## Core Functions

### Goal Discovery

#### `findGoalFiles(goalsDir: string): string[]`

Find all goal markdown files in directory.

**Parameters:**
- `goalsDir` - Path to goals directory (e.g., `pd/goals`)

**Returns:**
- Array of absolute file paths

**Behavior:**
- Scans for `*.md` files
- Sorts numerically by filename prefix
- Excludes non-goal files (README, templates)

**Example:**
```javascript
import { findGoalFiles } from './commands/goals.js';

const files = findGoalFiles('/path/to/pd/goals');
// Returns: [
//   '/path/to/pd/goals/001-foundation.md',
//   '/path/to/pd/goals/002-authentication.md',
//   ...
// ]
```

#### `extractGoalId(filename: string): number`

Extract numeric ID from goal filename.

**Parameters:**
- `filename` - Goal filename (e.g., `025-user-auth.md`)

**Returns:**
- Numeric ID (e.g., `25`)

**Example:**
```javascript
const id = extractGoalId('025-user-auth.md');
// Returns: 25
```

### Goal Parsing

#### `parseGoalFile(filePath: string): Object`

Parse goal markdown file into structured data.

**Parameters:**
- `filePath` - Absolute path to goal file

**Returns:**
```javascript
{
  id: 1,
  title: "Goal Title",
  path: "/absolute/path/to/file.md",
  objective: "Goal objective text",
  tasks: [
    { text: "Task description", completed: false },
    { text: "Completed task", completed: true }
  ],
  acceptanceCriteria: ["Criterion 1", "Criterion 2"],
  dependencies: ["Goal 5: User Auth", "External: API Access"],
  progress: {
    status: "In Progress",
    startDate: "2025-11-01",
    completionDate: "-",
    taskCompletion: {
      completed: 2,
      total: 5,
      percentage: 40
    },
    notes: "Progress notes"
  },
  technicalDetails: "Technical implementation notes",
  manual: false
}
```

**Parsing Rules:**
- `# Goal: [Title]` → `title`
- `## Objective` section → `objective`
- `## Tasks` section → `tasks[]`
- `- [ ]` → uncompleted task
- `- [x]` → completed task
- `## Acceptance Criteria` → `acceptanceCriteria[]`
- `## Progress` → `progress` object
- `[MANUAL]` in title → `manual: true`

**Status Extraction:**
- Searches for `**Status**: Value` or `Status: Value`
- Normalizes to standard values
- Falls back to task-based calculation

**Task Completion:**
- Counts `[x]` vs total tasks
- Calculates percentage
- Stores in `progress.taskCompletion`

### Cache Management

#### `loadCache(workspacePath?: string): Promise<Object|null>`

Load goals cache from workspace metadata or fallback file.

**Parameters:**
- `workspacePath` - Optional workspace path (defaults to `process.cwd()`)

**Returns:**
- Cache object or `null` if not found

**Storage Priority:**
1. Workspace metadata in `~/.ani-code/workspaces.db`
2. Fallback file `.ani-code/goals-cache.json`

**Cache Structure:**
```javascript
{
  lastUpdated: "2025-11-07T10:30:00Z",
  totalGoals: 15,
  summary: {
    notStarted: 5,
    inProgress: 3,
    completed: 7,
    totalTasks: 145,
    completedTasks: 87,
    overallPercentage: 60
  },
  goals: [
    // Array of parsed goal objects
  ]
}
```

#### `saveCache(data: Object, workspacePath?: string): Promise<void>`

Save goals cache to workspace metadata or fallback file.

**Parameters:**
- `data` - Cache object to save
- `workspacePath` - Optional workspace path

**Behavior:**
- Tries workspace metadata first
- Falls back to file if no workspace
- Creates `.ani-code/` directory if needed
- Timestamps update in `lastUpdated` field

#### `isCacheValid(goalsDir: string, cacheData: Object): Promise<boolean>`

Check if cache is still valid (no file changes).

**Parameters:**
- `goalsDir` - Goals directory path
- `cacheData` - Current cache object

**Returns:**
- `true` if cache is valid
- `false` if files changed or cache stale

**Validation Logic:**
1. Checks `cacheData.lastUpdated` exists
2. Compares cache timestamp to file mtimes
3. Returns `false` if any file newer than cache

#### `syncGoalsCache(goalsDir: string, fullResync: boolean): Promise<void>`

Sync goals cache with file system using Claude analysis.

**Parameters:**
- `goalsDir` - Goals directory path
- `fullResync` - Force full resync including completed goals

**Behavior:**
1. Scans goal files
2. Checks for changes
3. Sends to Claude for analysis
4. Updates cache with parsed data
5. Calculates summary statistics

**Triggers Full Resync:**
- `fullResync` flag set
- No cache exists
- Cache structure invalid

**Incremental Sync:**
- Only analyzes changed files
- Merges with existing cache
- Preserves completed goal data

### Progress Tracking

#### `generateProgressBar(percentage: number, width: number = 20): string`

Generate visual progress bar.

**Parameters:**
- `percentage` - Completion percentage (0-100)
- `width` - Character width of bar (default: 20)

**Returns:**
- String like `[████████░░░░░░░░░░░░]`

**Example:**
```javascript
const bar = generateProgressBar(60, 20);
console.log(bar);
// Output: [████████████░░░░░░░░]
```

#### `checkGoals(goalsDir: string, options: Object): Promise<void>`

Comprehensive goal completion check.

**Parameters:**
- `goalsDir` - Goals directory path
- `options.verbose` - Show detailed task breakdowns

**Output:**
- Overall statistics
- Goal-by-goal breakdown
- Task completion details
- Progress visualization

### Goal Selection

#### `parseGoalSelector(selector: string, allGoalFiles: string[]): Promise<Object>`

Parse goal selector into file list.

**Parameters:**
- `selector` - Goal selector string
- `allGoalFiles` - Array of all goal file paths

**Selector Formats:**
- `"5"` - Single goal by ID
- `"1-15"` - Range of goals
- `"1,3,5,7"` - Specific goal IDs
- `"025-user-auth"` - By filename
- `"user authentication"` - By description search

**Returns:**
```javascript
{
  files: [/* matched file paths */],
  displayName: "Goals 1-15" // or "Goal 5", etc.
}
```

## HTTP Endpoints

### `GET /goals`

List all goals with cache.

**Query Parameters:**
- `refresh` - Force cache refresh (optional)

**Response:**
```json
{
  "success": true,
  "data": {
    "lastUpdated": "2025-11-07T10:30:00Z",
    "totalGoals": 15,
    "summary": { ... },
    "goals": [ ... ]
  }
}
```

### `GET /goals/:id`

Get specific goal details.

**Parameters:**
- `id` - Goal ID, filename, or search term

**Response:**
```json
{
  "success": true,
  "data": {
    "id": 5,
    "title": "User Authentication",
    "objective": "...",
    "tasks": [ ... ],
    "progress": { ... }
  }
}
```

### `POST /goals/sync`

Trigger cache sync.

**Body:**
```json
{
  "full": true
}
```

**Response:**
```json
{
  "success": true,
  "message": "Cache synced successfully"
}
```

### `PUT /goals/:id/status`

Update goal status.

**Parameters:**
- `id` - Goal ID

**Body:**
```json
{
  "status": "In Progress"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Goal status updated"
}
```

### `POST /goals/loop`

Start automated goal loop.

**Body:**
```json
{
  "goalId": 5,
  "limit": 10,
  "skipValidation": false
}
```

**Response:**
```json
{
  "success": true,
  "taskId": "task-123",
  "message": "Goal loop started"
}
```

## Cache File Format

### Location

**Primary:** Workspace metadata
```
~/.ani-code/workspaces.db
→ workspace.metadata.goalsCache
```

**Fallback:** File-based
```
<workspace>/.ani-code/goals-cache.json
```

### Structure

```json
{
  "version": "1.0",
  "lastUpdated": "ISO8601 timestamp",
  "totalGoals": 15,
  "summary": {
    "notStarted": 5,
    "inProgress": 3,
    "completed": 7,
    "abandoned": 0,
    "cancelled": 0,
    "onHold": 0,
    "totalTasks": 145,
    "completedTasks": 87,
    "overallPercentage": 60
  },
  "goals": [
    {
      "id": 1,
      "title": "Foundation Setup",
      "path": "/absolute/path/to/001-foundation.md",
      "objective": "Set up project foundation...",
      "tasks": [
        {
          "text": "Initialize repository",
          "completed": true
        },
        {
          "text": "Configure build system",
          "completed": false
        }
      ],
      "acceptanceCriteria": [
        "Repository created with proper structure",
        "Build system configured and tested"
      ],
      "dependencies": [],
      "progress": {
        "status": "In Progress",
        "startDate": "2025-11-01",
        "completionDate": "-",
        "taskCompletion": {
          "completed": 5,
          "total": 10,
          "percentage": 50
        },
        "notes": "Build system configuration pending",
        "manualOverride": false
      },
      "technicalDetails": "Using Vite for build tooling...",
      "manual": false
    }
  ]
}
```

### Field Descriptions

**Root Level:**
- `version` - Cache format version
- `lastUpdated` - ISO8601 timestamp of last sync
- `totalGoals` - Total number of goals
- `summary` - Aggregate statistics
- `goals` - Array of goal objects

**Summary Object:**
- `notStarted` - Count of not started goals
- `inProgress` - Count of in-progress goals
- `completed` - Count of completed goals
- `abandoned` - Count of abandoned goals
- `cancelled` - Count of cancelled goals
- `onHold` - Count of on-hold goals
- `totalTasks` - Sum of all tasks
- `completedTasks` - Sum of completed tasks
- `overallPercentage` - Overall completion percentage

**Goal Object:**
- `id` - Numeric goal ID from filename
- `title` - Goal title without "Goal:" prefix
- `path` - Absolute path to goal file
- `objective` - Goal objective text
- `tasks` - Array of task objects
- `acceptanceCriteria` - Array of criteria strings
- `dependencies` - Array of dependency strings
- `progress` - Progress tracking object
- `technicalDetails` - Technical notes
- `manual` - Manual flag boolean

**Task Object:**
- `text` - Task description
- `completed` - Boolean completion status

**Progress Object:**
- `status` - Goal status string
- `startDate` - Start date (YYYY-MM-DD or "-")
- `completionDate` - Completion date (YYYY-MM-DD or "-")
- `taskCompletion` - Task completion stats
- `notes` - Progress notes
- `manualOverride` - Whether status was manually set

**Task Completion Object:**
- `completed` - Number of completed tasks
- `total` - Total number of tasks
- `percentage` - Completion percentage (0-100)

## Status Values

**Valid Statuses:**
- `Not Started` - Goal not yet begun
- `In Progress` - Currently working on goal
- `Completed` - Goal finished and verified
- `Abandoned` - Goal discontinued permanently
- `Cancelled` - Goal cancelled by decision
- `On Hold` - Goal paused temporarily

## Manual Override

**When Set:**
- User manually updates status via CLI
- Status differs from task-based calculation

**Behavior:**
- `progress.manualOverride = true`
- Status preserved across syncs
- Cleared with `clear-override` command

**Auto-Calculation:**
- When `manualOverride = false`
- Status derived from task completion:
  - 0% tasks → "Not Started"
  - 1-99% tasks → "In Progress"
  - 100% tasks → "Completed"

## Error Handling

**Cache Load Failures:**
- Returns `null` on error
- Logs warning to console
- Falls back to file parsing

**Parse Errors:**
- Skips malformed files
- Logs parsing errors
- Continues with valid files

**Sync Failures:**
- Preserves existing cache
- Reports errors to user
- Suggests manual fixes

## Performance Considerations

**Cache Optimization:**
- Only syncs changed files
- Stores in workspace metadata (SQLite)
- Incremental updates preserve completed goals

**File Parsing:**
- Lazy evaluation (parse on demand)
- Cached results
- Minimal regex operations

**Large Repositories:**
- Handles 100+ goals efficiently
- Parallel file reading
- Streaming analysis with Claude

## Integration Points

### Workspace Manager
```javascript
const workspace = await getCurrentWorkspace();
const cache = await workspaceManager.getWorkspaceMeta(
  workspace.id,
  'goalsCache'
);
```

### IPC Client
```javascript
const task = await ipcClient.addTask(
  `goal-${goalId}`,
  prompt,
  { cwd: workspacePath }
);
```

### Daemon Client
```javascript
const response = await daemonClient.sendCommand('ask', {
  prompt: validationPrompt,
  context: 'validation',
  timeout: 60000
});
```

## Migration

### From File Cache to Workspace Metadata

**Automatic Migration:**
1. Detects existing `.ani-code/goals-cache.json`
2. Loads data into memory
3. Saves to workspace metadata
4. Preserves fallback file

**Manual Migration:**
```bash
# Force full resync
ani-code goals sync --full

# Verify workspace integration
ani-code workspace list
```

## See Also

- [Goals Feature Documentation](../features/goals.md)
- [Workspace Management](../features/workspace-management.md)
- [IPC Protocol](ipc-protocol.md)

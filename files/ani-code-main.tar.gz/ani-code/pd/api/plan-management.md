# Plan Management API

## Overview
The plan management system allows users to create, execute, and track multi-step task plans through both CLI and messaging interfaces (Telegram/Lark).

## CLI Commands

### `ani-code plan [action] [args...]`
Manage task plans with various actions.

**Actions:**
- `create <steps>` - Create a new plan with specified steps
- `list` - List all plans for current workspace
- `reset [plan-id]` - Reset a plan's progress
- `delete <plan-id>` - Delete a specific plan

**Examples:**
```bash
# Create a plan with multiple steps
ani-code plan create "Fix login bug" "Add unit tests" "Update documentation"

# List all plans
ani-code plan list

# Reset a specific plan
ani-code plan reset plan_abc123

# Delete a plan
ani-code plan delete plan_abc123
```

### `ani-code next [plan-id]`
Execute the next pending step in a plan or specific plan.

**Examples:**
```bash
# Execute next step in any available plan (FIFO order)
ani-code next

# Execute next step in specific plan
ani-code next plan_abc123
```

## Messaging Commands

### Telegram/Lark Commands

#### `/plan`
Create a new plan with steps.

**Format:**
```
/plan
- Step 1 description
- Step 2 description
- Step 3 description
```

**Response:**
```
Plan created: plan_abc123
Steps: 3

Execute with: /next or /next plan_abc123
```

#### `/plans`
List all plans for the current workspace.

**Response:**
```
📋 Plans for workspace: my-project
━━━━━━━━━━━━━━━━━━━━
Plan ID: plan_abc123
Created: 2025-09-16 10:30
Status: 2/5 steps completed

📌 Steps:
✅ 1. Fix login bug
✅ 2. Add unit tests
⏳ 3. Update documentation
⬜ 4. Run integration tests
⬜ 5. Deploy to staging
```

#### `/next [plan-id]`
Execute the next pending step in a plan.

**Examples:**
```
# Execute next step in any plan
/next

# Execute specific plan
/next plan_abc123
```

#### `/yolo`
Execute all pending plans automatically with commits between each step.

**Features:**
- Executes plans in FIFO order
- Commits changes after each completed step
- Stops on failure or when all plans are complete
- Can be interrupted with `/stopyolo`

#### `/stopyolo`
Stop the ongoing YOLO execution.

## Plan Data Structure

Plans are stored with the following structure:

```json
{
  "planId": "plan_abc123",
  "workspaceId": 1,
  "workspaceName": "my-project",
  "title": "Fix authentication issues",
  "createdAt": "2025-09-16T10:30:00Z",
  "steps": [
    {
      "description": "Fix login bug",
      "status": "completed",
      "completedAt": "2025-09-16T11:00:00Z",
      "taskId": "task_xyz789"
    },
    {
      "description": "Add unit tests",
      "status": "pending"
    }
  ]
}
```

## Status Values

- `pending` - Step not yet started
- `in_progress` - Step currently being executed
- `completed` - Step successfully completed
- `failed` - Step execution failed

## Error Handling

Common error responses:

- `No workspace found` - User not connected to a workspace
- `Plan not found` - Specified plan ID doesn't exist
- `No pending steps` - All steps in plan are completed
- `Task already in progress` - Another task is currently running

## Implementation Details

The plan management system:
- Uses FIFO ordering for pending plan execution
- Stores plans in the workspace database
- Tracks task IDs for completed steps
- Supports both object and string formats for step definitions
- Automatically generates commit messages in yolo mode using Claude Sonnet
# Gateway Callback API Endpoints Specification

## Overview
Complete API specification for the gateway callback system that enables ani-code daemons to send messages back through the gateway to the original communication channels.

## Base URL
```
https://gateway.example.com
```

## Authentication
All callback endpoints require gateway token authentication via the `x-gateway-token` header.

---

## 1. Message Callback Endpoint

### POST /api/callback/message

Send a message back to the original communication channel.

#### Request Headers
```http
x-gateway-token: gw_7f8a9b2c3d4e5f6g
x-instance-id: ani-code-1
Content-Type: application/json
```

#### Request Body

##### Standard Message
```json
{
  "message": {
    "text": "Your task has been completed successfully!",
    "parse_mode": "Markdown",
    "reply_markup": {
      "inline_keyboard": [[
        {"text": "View Details", "callback_data": "view_details"},
        {"text": "Run Again", "callback_data": "run_again"}
      ]]
    }
  },
  "action": "send",
  "metadata": {
    "task_id": "task_123",
    "timestamp": "2025-11-22T10:00:00Z"
  }
}
```

##### Edit Existing Message
```json
{
  "message": {
    "text": "Updated: Task is now 75% complete",
    "parse_mode": "Markdown"
  },
  "action": "edit",
  "message_id": "msg_456",
  "metadata": {
    "task_id": "task_123",
    "progress": 75
  }
}
```

##### Delete Message
```json
{
  "action": "delete",
  "message_id": "msg_456"
}
```

##### Rich Media Message
```json
{
  "message": {
    "text": "Here's your generated image:",
    "photo": "https://example.com/image.png",
    "caption": "Generated using DALL-E",
    "parse_mode": "Markdown"
  },
  "action": "send"
}
```

#### Request Parameters

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| message | object | Yes* | Message content (required for send/edit) |
| message.text | string | Yes* | Message text content |
| message.parse_mode | string | No | Markdown or HTML (default: Markdown) |
| message.reply_markup | object | No | Telegram inline keyboard |
| message.photo | string | No | URL or file_id for photo |
| message.document | string | No | URL or file_id for document |
| message.caption | string | No | Caption for media |
| action | string | No | send (default), edit, or delete |
| message_id | string | Yes* | Required for edit/delete actions |
| metadata | object | No | Additional tracking data |

#### Success Response (200 OK)
```json
{
  "success": true,
  "message_id": "msg_789",
  "platform": "telegram",
  "chat_id": "-4868224422",
  "timestamp": "2025-11-22T10:00:01Z"
}
```

#### Error Responses

##### Invalid Token (401)
```json
{
  "error": {
    "code": "INVALID_TOKEN",
    "message": "Invalid or expired gateway token",
    "status": 401
  }
}
```

##### Platform Error (502)
```json
{
  "error": {
    "code": "PLATFORM_ERROR",
    "message": "Failed to send message to platform",
    "status": 502,
    "details": {
      "platform": "telegram",
      "platform_error": "Bad Request: message text is empty"
    }
  }
}
```

##### Rate Limit (429)
```json
{
  "error": {
    "code": "RATE_LIMIT",
    "message": "Rate limit exceeded",
    "status": 429,
    "retry_after": 30
  }
}
```

#### Example Usage

##### cURL
```bash
curl -X POST https://gateway.example.com/api/callback/message \
  -H "x-gateway-token: gw_7f8a9b2c3d4e5f6g" \
  -H "x-instance-id: ani-code-1" \
  -H "Content-Type: application/json" \
  -d '{
    "message": {
      "text": "Task completed!",
      "parse_mode": "Markdown"
    }
  }'
```

##### Node.js
```javascript
const axios = require('axios');

async function sendMessageViaGateway(text, options = {}) {
  const response = await axios.post(
    'https://gateway.example.com/api/callback/message',
    {
      message: {
        text,
        parse_mode: 'Markdown',
        ...options
      }
    },
    {
      headers: {
        'x-gateway-token': process.env.GATEWAY_TOKEN,
        'x-instance-id': process.env.INSTANCE_ID,
        'Content-Type': 'application/json'
      }
    }
  );
  return response.data;
}
```

---

## 2. Session Management Endpoints

### GET /api/sessions/:token

Get information about a specific session.

#### Request Headers
```http
x-api-key: your-admin-api-key
```

#### Response (200 OK)
```json
{
  "success": true,
  "session": {
    "gateway_token": "gw_7f8a9b2c3d4e5f6g",
    "platform": "telegram",
    "chat_id": "-4868224422",
    "user_id": "123456",
    "workspace_token": "ws_abc123xyz",
    "instance_url": "http://ani-code-1:6501",
    "created_at": "2025-11-22T09:00:00Z",
    "last_activity": "2025-11-22T09:55:00Z",
    "expires_at": "2025-11-22T10:00:00Z",
    "metadata": {
      "username": "john_doe",
      "language_code": "en"
    }
  }
}
```

---

### GET /api/sessions

List all active sessions.

#### Request Headers
```http
x-api-key: your-admin-api-key
```

#### Query Parameters
| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| platform | string | all | Filter by platform (telegram/lark) |
| limit | number | 100 | Maximum results to return |
| offset | number | 0 | Pagination offset |
| sort | string | created_at | Sort field |
| order | string | desc | Sort order (asc/desc) |

#### Response (200 OK)
```json
{
  "success": true,
  "sessions": [
    {
      "gateway_token": "gw_7f8a9b2c3d4e5f6g",
      "platform": "telegram",
      "chat_id": "-4868224422",
      "created_at": "2025-11-22T09:00:00Z",
      "last_activity": "2025-11-22T09:55:00Z"
    },
    {
      "gateway_token": "gw_8h9i0j1k2l3m4n5",
      "platform": "lark",
      "chat_id": "oc_a1b2c3d4",
      "created_at": "2025-11-22T08:00:00Z",
      "last_activity": "2025-11-22T09:30:00Z"
    }
  ],
  "pagination": {
    "total": 42,
    "limit": 100,
    "offset": 0,
    "has_more": false
  }
}
```

---

### POST /api/sessions/cleanup

Manually trigger cleanup of expired sessions.

#### Request Headers
```http
x-api-key: your-admin-api-key
```

#### Request Body (Optional)
```json
{
  "older_than_minutes": 60,
  "dry_run": false
}
```

#### Response (200 OK)
```json
{
  "success": true,
  "cleaned": 15,
  "remaining": 27,
  "duration_ms": 45
}
```

---

### DELETE /api/sessions/:token

Manually revoke a specific session.

#### Request Headers
```http
x-api-key: your-admin-api-key
```

#### Response (200 OK)
```json
{
  "success": true,
  "message": "Session revoked successfully"
}
```

---

## 3. Platform-Specific Endpoints

### POST /api/callback/telegram/answer

Answer a Telegram callback query.

#### Request Headers
```http
x-gateway-token: gw_7f8a9b2c3d4e5f6g
Content-Type: application/json
```

#### Request Body
```json
{
  "callback_query_id": "query_123",
  "text": "Action completed!",
  "show_alert": false
}
```

#### Response (200 OK)
```json
{
  "success": true,
  "answered": true
}
```

---

### POST /api/callback/lark/card

Send a Lark interactive card.

#### Request Headers
```http
x-gateway-token: gw_7f8a9b2c3d4e5f6g
Content-Type: application/json
```

#### Request Body
```json
{
  "card": {
    "config": {
      "wide_screen_mode": true
    },
    "header": {
      "title": {
        "content": "Task Status",
        "tag": "plain_text"
      }
    },
    "elements": [
      {
        "tag": "div",
        "text": {
          "content": "Your task is complete!",
          "tag": "plain_text"
        }
      }
    ]
  }
}
```

#### Response (200 OK)
```json
{
  "success": true,
  "message_id": "om_a1b2c3d4"
}
```

---

## 4. Monitoring Endpoints

### GET /api/sessions/stats

Get session statistics.

#### Request Headers
```http
x-api-key: your-admin-api-key
```

#### Response (200 OK)
```json
{
  "success": true,
  "stats": {
    "total_active": 42,
    "by_platform": {
      "telegram": 35,
      "lark": 7
    },
    "created_last_hour": 12,
    "expired_last_hour": 8,
    "average_duration_minutes": 25,
    "cache_hit_rate": 0.85
  }
}
```

---

### GET /api/callback/metrics

Get callback system metrics.

#### Request Headers
```http
x-api-key: your-admin-api-key
```

#### Response (200 OK)
```json
{
  "success": true,
  "metrics": {
    "messages_sent": {
      "total": 1250,
      "last_hour": 87,
      "by_platform": {
        "telegram": 1100,
        "lark": 150
      }
    },
    "errors": {
      "total": 23,
      "last_hour": 2,
      "by_type": {
        "INVALID_TOKEN": 10,
        "PLATFORM_ERROR": 8,
        "RATE_LIMIT": 5
      }
    },
    "performance": {
      "avg_latency_ms": 45,
      "p95_latency_ms": 120,
      "p99_latency_ms": 250
    }
  }
}
```

---

## Error Codes Reference

| Code | Status | Description |
|------|--------|-------------|
| INVALID_TOKEN | 401 | Gateway token is invalid or expired |
| SESSION_EXPIRED | 401 | Session has expired due to inactivity |
| MISSING_TOKEN | 401 | x-gateway-token header is missing |
| PLATFORM_ERROR | 502 | Platform API returned an error |
| PLATFORM_UNAVAILABLE | 503 | Platform API is unreachable |
| RATE_LIMIT | 429 | Rate limit exceeded |
| INVALID_REQUEST | 400 | Request body is invalid |
| MESSAGE_TOO_LARGE | 413 | Message exceeds platform limits |
| UNSUPPORTED_PLATFORM | 400 | Platform is not supported |
| INTERNAL_ERROR | 500 | Internal server error |

---

## Rate Limits

| Endpoint | Limit | Window |
|----------|-------|--------|
| /api/callback/message | 60 | 1 minute |
| /api/callback/telegram/answer | 30 | 1 minute |
| /api/callback/lark/card | 30 | 1 minute |
| /api/sessions/* | 100 | 1 minute |

---

## WebSocket Events

When callback messages are processed, the gateway broadcasts events via WebSocket:

### Connection
```javascript
const io = require('socket.io-client');
const socket = io('wss://gateway.example.com:6556');

socket.on('connect', () => {
  // Join workspace room
  socket.emit('join', { workspace_id: 'ws_abc123' });
});
```

### Message Events

#### message:sent
```json
{
  "event": "message:sent",
  "data": {
    "session_id": "gw_7f8a9b2c3d4e5f6g",
    "platform": "telegram",
    "chat_id": "-4868224422",
    "message_id": "msg_789",
    "timestamp": "2025-11-22T10:00:01Z"
  }
}
```

#### message:edited
```json
{
  "event": "message:edited",
  "data": {
    "session_id": "gw_7f8a9b2c3d4e5f6g",
    "platform": "telegram",
    "message_id": "msg_789",
    "timestamp": "2025-11-22T10:00:02Z"
  }
}
```

#### message:error
```json
{
  "event": "message:error",
  "data": {
    "session_id": "gw_7f8a9b2c3d4e5f6g",
    "error": "PLATFORM_ERROR",
    "details": "Bad Request: message not found",
    "timestamp": "2025-11-22T10:00:03Z"
  }
}
```

---

## SDK Examples

### JavaScript/TypeScript SDK

```typescript
class GatewayCallbackClient {
  constructor(private gatewayUrl: string, private gatewayToken: string) {}

  async sendMessage(text: string, options?: MessageOptions): Promise<MessageResponse> {
    const response = await fetch(`${this.gatewayUrl}/api/callback/message`, {
      method: 'POST',
      headers: {
        'x-gateway-token': this.gatewayToken,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        message: { text, ...options }
      })
    });

    if (!response.ok) {
      throw new Error(`Gateway error: ${response.status}`);
    }

    return response.json();
  }

  async editMessage(messageId: string, text: string): Promise<MessageResponse> {
    return this.sendMessage(text, {
      action: 'edit',
      message_id: messageId
    });
  }

  async deleteMessage(messageId: string): Promise<void> {
    await fetch(`${this.gatewayUrl}/api/callback/message`, {
      method: 'POST',
      headers: {
        'x-gateway-token': this.gatewayToken,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        action: 'delete',
        message_id: messageId
      })
    });
  }
}

// Usage
const client = new GatewayCallbackClient(
  'https://gateway.example.com',
  process.env.GATEWAY_TOKEN
);

await client.sendMessage('Hello from ani-code!', {
  parse_mode: 'Markdown',
  reply_markup: {
    inline_keyboard: [[
      { text: 'Button', callback_data: 'button_clicked' }
    ]]
  }
});
```

### Python SDK

```python
import requests
from typing import Optional, Dict, Any

class GatewayCallbackClient:
    def __init__(self, gateway_url: str, gateway_token: str):
        self.gateway_url = gateway_url
        self.gateway_token = gateway_token
        self.session = requests.Session()
        self.session.headers.update({
            'x-gateway-token': gateway_token,
            'Content-Type': 'application/json'
        })

    def send_message(
        self,
        text: str,
        parse_mode: str = 'Markdown',
        reply_markup: Optional[Dict] = None
    ) -> Dict[str, Any]:
        response = self.session.post(
            f'{self.gateway_url}/api/callback/message',
            json={
                'message': {
                    'text': text,
                    'parse_mode': parse_mode,
                    'reply_markup': reply_markup
                }
            }
        )
        response.raise_for_status()
        return response.json()

    def edit_message(
        self,
        message_id: str,
        text: str,
        parse_mode: str = 'Markdown'
    ) -> Dict[str, Any]:
        response = self.session.post(
            f'{self.gateway_url}/api/callback/message',
            json={
                'message': {
                    'text': text,
                    'parse_mode': parse_mode
                },
                'action': 'edit',
                'message_id': message_id
            }
        )
        response.raise_for_status()
        return response.json()

# Usage
client = GatewayCallbackClient(
    'https://gateway.example.com',
    os.environ['GATEWAY_TOKEN']
)

client.send_message(
    'Task completed!',
    reply_markup={
        'inline_keyboard': [[
            {'text': 'View Results', 'callback_data': 'view'}
        ]]
    }
)
```

---

## Testing Endpoints

### POST /api/callback/test

Test endpoint for development (only available in non-production).

#### Request Body
```json
{
  "gateway_token": "gw_test_token",
  "message": {
    "text": "Test message"
  }
}
```

#### Response (200 OK)
```json
{
  "success": true,
  "test_mode": true,
  "would_send_to": {
    "platform": "telegram",
    "chat_id": "-4868224422"
  }
}
```

---

## Migration Guide

### From Direct Sending to Gateway Callback

#### Before (Direct Telegram)
```javascript
// Old approach - direct telegram API
const TelegramBot = require('node-telegram-bot-api');
const bot = new TelegramBot(BOT_TOKEN);

await bot.sendMessage(chatId, 'Hello!');
```

#### After (Gateway Callback)
```javascript
// New approach - via gateway
const axios = require('axios');

await axios.post(
  `${GATEWAY_URL}/api/callback/message`,
  {
    message: {
      text: 'Hello!',
      parse_mode: 'Markdown'
    }
  },
  {
    headers: {
      'x-gateway-token': GATEWAY_TOKEN
    }
  }
);
```

### Gradual Migration

1. **Phase 1**: Implement fallback
```javascript
async function sendMessage(text, options) {
  try {
    // Try gateway first
    return await sendViaGateway(text, options);
  } catch (error) {
    // Fallback to direct
    return await sendDirectly(text, options);
  }
}
```

2. **Phase 2**: Monitor and optimize
3. **Phase 3**: Remove direct sending
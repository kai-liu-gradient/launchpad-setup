# Ani-Code Command Reference

Detailed API docs, command options, and JSON schemas moved from CLAUDE.md for performance.

## Healthcheck Command

```bash
ani-code healthcheck                        # Auto-detect and run
ani-code healthcheck --stack node           # Specific techstack
ani-code healthcheck --analyze              # Claude AI analysis
ani-code healthcheck --dry-run              # Preview only
ani-code healthcheck --output json|html     # Output format
ani-code healthcheck --workspace <path>     # Specific workspace
ani-code healthcheck --cleanup 30           # Remove old reports
```

Reports: `.ani-code/healthcheck/healthcheck-YYYY-MM-DD-HHMMSS.{json,html}`

Exit codes: 0=clean, 1=high severity, 2=critical severity

Supported: Node.js (full), Python/Go/Rust/Java (detection only)

## Projects Command

```bash
ani-code projects                           # Scan (default)
ani-code projects scan --depth 3 --force    # Rescan with options
ani-code projects list --json|--tree        # List projects
ani-code projects show <name> --json        # Project details
ani-code projects refresh                   # Refresh from manifests
ani-code projects set-version <name> <ver>  # Set version
ani-code projects burst <name>              # Increment patch
ani-code projects burst-all                 # Burst all versions
```

Registry: `.ani-code/projects/registry.json`

Supported manifests (by priority): package.json, pyproject.toml, setup.py, requirements.txt, Pipfile, go.mod, Cargo.toml, pom.xml, build.gradle, build.gradle.kts, composer.json

## Browser Automation - ani-browser

```bash
ani-browser console <url> --wait 2000       # Console logs
ani-browser screenshot <url> --wait 3000    # Screenshot
ani-browser snapshot <url> --wait 3000      # Full diagnostic
ani-browser dom <url>                       # DOM structure
ani-browser session:create <url>            # Stateful session
ani-browser session:list                    # List sessions
ani-browser session:close <id>             # Close session
```

Tips: Always use `--wait` for SPAs. Use `--upload` to share screenshots.

## Providers Command

```bash
ani-code providers                          # List (shows current)
ani-code providers copilot                  # Switch provider
ani-code providers opencode --save          # Switch and save default
ani-code providers --all                    # Include unavailable
```

Supported: claude (default), copilot, codex, gemini, cursor, opencode

Selection priority: `CLI_PROVIDER_ID` env > workspace meta > `claude`

Task targeting: `ani-code task "message @@copilot"` or `@@opencode`

## Providers REST API

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/providers` | List providers (`?all=true` for all) |
| `GET` | `/api/providers/:id` | Provider details |
| `GET` | `/api/providers/:id/models` | Models with pricing (`?enabled=true\|false`) |
| `PATCH` | `/api/providers/:id` | Enable/disable or set current: `{ enabled, current }` |
| `PATCH` | `/api/providers/:id/models/:modelId` | Enable/disable or set default: `{ enabled, default }` |

Env: `CLI_PROVIDER_<ID>_DEFAULT_MODEL` to set default model per provider.

## Here Command - Channel Redirection

```bash
/here                    # Redirect most recent task to current chat
/here ac-0118-B1234      # Redirect specific task
/here 1234               # Partial task ID
```

API: `PATCH /api/task/:taskId/channel` with `{ chatId, source }`

Sends `channel_redirected` callback to gateway with redirect info.

## Chat Display Mode - /chatui

| Mode | Description |
|------|-------------|
| `full` | Headers, git status, cost/tokens, footer (default) |
| `simple` | Task output + brief completion line only |

```bash
ani-code chatui              # Show current mode
ani-code chatui simple|full  # Switch mode
```

Priority: per-chat setting > `CHAT_DISPLAY_MODE` env > `full`

API: `GET /api/chatui?chatId=<id>`, `PATCH /api/chatui { chatId, mode }`, `GET /api/chatui/modes`

Completion callbacks include `structured.contentOnly` (raw text) and `metadata.displayMode`.

## Hint Command - Transient Context

```bash
ani-code hint "message"       # Create hint
ani-code hint -f file.txt     # From file
cat log | ani-code hint       # From pipe
ani-code hint --list          # List active
ani-code hint --ack <id>      # Acknowledge
ani-code hint --clear         # Clear all
```

Config: `HINT_TTL_HOURS=1`, `HINT_MAX_INJECT=5`, `HINT_MAX_LENGTH=10240`

API: `GET/POST/DELETE /api/hints`, `GET /api/hints/:id`, `POST /api/hints/:id/ack`

Injected into: /add, /continue, /yolo, goal loops. NOT injected for: /commit, /goalsync.

## Gateway Callback Signing

Env: `PROJECT_GATEWAY_KEY="<64-byte-hex>"` enables HMAC-SHA256 signing.

Headers added when key set: `X-Callback-Timestamp`, `X-Callback-Signature`, `X-Supports-Callback-Signing`, `X-Project-Id`

Payload format: `{timestamp}.{projectId}.{JSON.stringify(body)}`

Gateway validates: timestamp within 5min, HMAC match, project ID match.

## Task Stale Detection

Monitors for repeated output patterns. Kills tasks after 20+ consecutive identical outputs and 5+ minutes runtime.

Config:
- `TASK_STALE_DETECTION_ENABLED=true`
- `TASK_STALE_MIN_RUNTIME_MS=300000`
- `TASK_STALE_REPEAT_THRESHOLD=20`
- `TASK_STALE_CHECK_INTERVAL_MS=30000`

Skips: empty lines, progress dots, percentages, box chars, streaming indicators.

## Unmanaged Task Detection

Monitors `~/.claude/projects/` for JSONL sessions not tracked by ani-code.

Config:
- `UNMANAGED_TASK_DETECTION_ENABLED=false`
- `UNMANAGED_TASK_INSERT_STATS=false`
- `UNMANAGED_TASK_SCAN_INTERVAL_MS=60000`
- `UNMANAGED_TASK_SETTLE_TIME_MS=300000`

## Preset Templates for /remember

Available: `@coder.md`, `@api.md`, `@database.md`, `@security.md`, `@main.md`, `@web.md`

Usage: `ani-code remember "@coder.md the port is 3000"`

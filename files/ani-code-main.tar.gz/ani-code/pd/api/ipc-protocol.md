# IPC Protocol Documentation

The ani-code daemon uses TCP-based IPC (Inter-Process Communication) for local CLI-to-daemon communication.

## Connection Details

- **Protocol**: TCP Socket
- **Host**: `127.0.0.1` (localhost only)
- **Port**: Dynamic (written to `.ani-code-ipc.port` file)
- **Message Format**: Newline-delimited JSON

## Port Discovery

The daemon writes its IPC port to `.ani-code-ipc.port` in the project root directory. Clients read this file to discover the connection port.

## Message Protocol

All messages are JSON objects serialized as strings and terminated with a newline (`\n`).

### Request Format
```json
{
  "id": "unique-request-id",
  "action": "action_name",
  "data": {
    // Action-specific parameters
  }
}
```

### Response Format
```json
{
  "id": "matching-request-id",
  "success": true|false,
  "data": {
    // Response data
  },
  "error": "Error message if success is false"
}
```

## Actions

### `add_task`
Adds a new task to the execution queue.

**Request**:
```json
{
  "action": "add_task",
  "data": {
    "name": "Task display name",
    "command": "shell command to execute",
    "options": {
      "cwd": "/working/directory/path",
      "source": "cli|lark|api"
    }
  }
}
```

**Response**:
```json
{
  "success": true,
  "data": {
    "taskId": "uuid-of-created-task"
  }
}
```

### `get_status`
Gets the current status of the task queue.

**Request**:
```json
{
  "action": "get_status"
}
```

**Response**:
```json
{
  "success": true,
  "data": {
    "running": [
      {
        "id": "task-id",
        "name": "Task name",
        "status": "running",
        "command": "command",
        "startTime": "2025-08-20T12:00:00.000Z"
      }
    ],
    "pending": [
      {
        "id": "task-id",
        "name": "Task name",
        "status": "pending",
        "command": "command"
      }
    ],
    "completed": [
      {
        "id": "task-id",
        "name": "Task name",
        "status": "success|failure",
        "exitCode": 0,
        "duration": 1234
      }
    ]
  }
}
```

### `cancel_task`
Cancels a running or pending task.

**Request**:
```json
{
  "action": "cancel_task",
  "data": {
    "taskId": "task-id-to-cancel"
  }
}
```

**Response**:
```json
{
  "success": true,
  "data": {
    "cancelled": true
  }
}
```

### `get_task`
Gets detailed information about a specific task.

**Request**:
```json
{
  "action": "get_task",
  "data": {
    "taskId": "task-id"
  }
}
```

**Response**:
```json
{
  "success": true,
  "data": {
    "id": "task-id",
    "name": "Task name",
    "command": "command",
    "status": "pending|running|success|failure|cancelled",
    "output": "stdout output",
    "error": "stderr output",
    "exitCode": 0,
    "startTime": "2025-08-20T12:00:00.000Z",
    "endTime": "2025-08-20T12:01:00.000Z",
    "duration": 60000
  }
}
```

### `stream_output`
Requests real-time streaming of task output.

**Request**:
```json
{
  "action": "stream_output",
  "data": {
    "taskId": "task-id",
    "enable": true|false
  }
}
```

**Response**:
```json
{
  "success": true
}
```

When streaming is enabled, the client will receive output events:
```json
{
  "type": "task_output",
  "data": {
    "taskId": "task-id",
    "output": "stdout line",
    "error": "stderr line",
    "timestamp": "2025-08-20T12:00:00.000Z"
  }
}
```

### `ping`
Health check for the IPC connection.

**Request**:
```json
{
  "action": "ping"
}
```

**Response**:
```json
{
  "success": true,
  "data": {
    "pong": true,
    "timestamp": "2025-08-20T12:00:00.000Z"
  }
}
```

## Event Broadcasting

The IPC server broadcasts certain events to all connected clients:

### Task Output Event
Sent when a task produces output (if streaming is enabled).
```json
{
  "type": "task_output",
  "data": {
    "taskId": "task-id",
    "output": "stdout content",
    "error": "stderr content",
    "timestamp": "2025-08-20T12:00:00.000Z"
  }
}
```

### Task Status Event
Sent when a task changes status.
```json
{
  "type": "task_status",
  "data": {
    "taskId": "task-id",
    "status": "running|success|failure|cancelled",
    "exitCode": 0
  }
}
```

## Connection Lifecycle

1. **Client connects** to TCP port specified in `.ani-code-ipc.port`
2. **Client sends requests** as newline-delimited JSON
3. **Server processes** requests and sends responses with matching IDs
4. **Server broadcasts** events to all connected clients
5. **Client disconnects** when done

## Error Handling

- Invalid JSON: Connection is terminated
- Unknown action: Error response with `success: false`
- Missing required fields: Error response with details
- Server shutdown: All client connections are gracefully closed

## Security

- IPC server only binds to localhost (127.0.0.1)
- No authentication required (local access only)
- Port is dynamically assigned to avoid conflicts
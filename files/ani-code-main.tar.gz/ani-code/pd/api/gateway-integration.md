# Gateway Integration Guide

## Overview

This guide explains how to integrate `ani-code-gateway` with the `ani-code` daemon for remote task execution and bidirectional communication.

**Version**: 1.4.0 (Gateway Support Added)
**Last Updated**: 2025-11-11

---

## Architecture

```
┌─────────────────────┐         HTTP          ┌──────────────────┐
│                     │  ←─────────────────→   │                  │
│  ani-launchpad      │                        │  ani-code        │
│  Dashboard          │         Task           │  Gateway         │
│                     │  ────────────────────→  │                  │
└─────────────────────┘                        └────────┬─────────┘
                                                        │
                                                        │ HTTP/Callbacks
                                                        │
                                                        ▼
                                                ┌──────────────────┐
                                                │                  │
                                                │  ani-code        │
                                                │  Daemon          │
                                                │                  │
                                                └──────────────────┘
```

**Components**:

1. **ani-launchpad Dashboard**: Web UI where users create tasks
2. **ani-code-gateway**: Central API gateway for routing tasks
3. **ani-code Daemon**: Worker daemon executing Claude tasks

**Communication Flow**:

1. User creates task in dashboard → gateway receives task
2. Gateway sends task to daemon via `POST /api/task`
3. Daemon acknowledges and starts task execution
4. Daemon sends status updates to gateway via callbacks
5. Gateway forwards updates to dashboard

---

## Setup

### 1. Configure Gateway API Key

Generate a secure API key and configure it on both gateway and daemon:

```bash
# On daemon server
export GATEWAY_API_KEY="your-secure-api-key-here"

# On gateway server
export ANI_CODE_API_KEY="your-secure-api-key-here"  # Same key
```

**Security Best Practices**:
- Use a cryptographically random key (min 32 characters)
- Rotate keys regularly (recommended: monthly)
- Store in environment variables, never in code
- Use different keys for dev/staging/production

**Generate Secure Key**:
```bash
openssl rand -hex 32
```

### 2. Configure Gateway URL

Set the gateway callback URL on the daemon:

```bash
# On daemon server
export GATEWAY_URL="https://gateway.example.com"
export WORKSPACE_ID="workspace-uuid"
export PROJECT_ID="project-uuid"
```

### 3. Configure Daemon Endpoint

Set the daemon endpoint URL on the gateway:

```bash
# On gateway server
export ANI_CODE_DAEMON_URL="https://daemon.example.com:6501"
```

### 4. Verify Configuration

Test the connection:

```bash
# From gateway, test daemon health
curl https://daemon.example.com:6501/health

# From daemon, test gateway callback (if endpoint exists)
curl -X POST https://gateway.example.com/api/callback/task-status \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your-api-key" \
  -d '{"taskId":"test","status":"started"}'
```

---

## API Integration

### Gateway → Daemon: Task Submission

**Endpoint**: `POST /api/task`
**Authentication**: `X-API-Key` header

**Request**:
```javascript
const response = await fetch(`${DAEMON_URL}/api/task`, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'X-API-Key': process.env.ANI_CODE_API_KEY
  },
  body: JSON.stringify({
    taskId: 'task-uuid-123',
    command: 'Fix authentication bug in login module',
    data: {
      context: {
        files: {
          'src/auth.js': fileContent
        },
        projectInfo: {
          name: 'My Project'
        }
      },
      userId: 'user-uuid',
      projectId: 'project-uuid',
      workspaceId: 'workspace-uuid'
    },
    source: 'gateway',
    priority: 'normal',
    timeout: 300000  // 5 minutes
  })
});

const result = await response.json();
console.log('Task submitted:', result.taskId);
```

**Response** (201 Created):
```json
{
  "success": true,
  "taskId": "task-uuid-123",
  "status": "pending",
  "workspace": "my-workspace",
  "queuePosition": 0,
  "timestamp": "2025-11-11T10:00:00.000Z"
}
```

### Daemon → Gateway: Status Callbacks

**Endpoint**: `POST /api/callback/task-status`
**Authentication**: `X-API-Key` header (daemon sends same key)

**Callback Payload**:
```json
{
  "taskId": "task-uuid-123",
  "workspaceId": "workspace-uuid",
  "projectId": "project-uuid",
  "status": "completed",
  "progress": 100,
  "output": "Task completed successfully. Fixed authentication bug.",
  "error": null,
  "timestamp": "2025-11-11T10:05:00.000Z",
  "metadata": {
    "duration": 300000,
    "tokensUsed": 5000,
    "model": "claude-sonnet-4"
  }
}
```

**Gateway Implementation**:
```javascript
app.post('/api/callback/task-status', async (req, res) => {
  // Verify API key
  const apiKey = req.headers['x-api-key'];
  if (apiKey !== process.env.ANI_CODE_API_KEY) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const { taskId, status, progress, output, error, metadata } = req.body;

  // Update task in database
  await db.updateTask(taskId, {
    status,
    progress,
    output,
    error,
    completedAt: status === 'completed' ? new Date() : null,
    metadata
  });

  // Send real-time update to dashboard (WebSocket/SSE)
  dashboardSocket.emit('task:update', {
    taskId,
    status,
    progress
  });

  res.json({ success: true });
});
```

**Callback Lifecycle**:

| Status | Trigger | Progress | Output/Error |
|--------|---------|----------|--------------|
| `started` | Task begins execution | 0 | null / null |
| `running` | Periodic updates | 0-99 | null / null |
| `completed` | Task finishes successfully | 100 | output / null |
| `failed` | Task encounters error | 0-100 | null / error |

---

## Retry Logic & Error Handling

### Daemon Callback Retries

The daemon implements exponential backoff for failed callbacks:

**Retry Configuration**:
- **Max Attempts**: 3 (configurable via `GATEWAY_RETRY_ATTEMPTS`)
- **Base Delay**: 1000ms (configurable via `GATEWAY_RETRY_BASE_DELAY`)
- **Backoff**: Exponential (1s → 2s → 4s)

**Retry Sequence**:
1. **Attempt 1**: Immediate (0ms delay)
2. **Attempt 2**: After 1 second
3. **Attempt 3**: After 2 seconds
4. **Failed**: Log to `/var/log/ani-code/failed-callbacks.jsonl`

**Configuration**:
```bash
export GATEWAY_RETRY_ATTEMPTS=3
export GATEWAY_RETRY_BASE_DELAY=1000
```

### Failed Callback Recovery

When all retries fail, callbacks are logged to a file for manual recovery:

**Log Location**: `/var/log/ani-code/failed-callbacks.jsonl`

**Log Format** (JSON Lines):
```json
{"timestamp":"2025-11-11T10:05:00.000Z","payload":{"taskId":"task-123","status":"completed",...}}
{"timestamp":"2025-11-11T10:06:00.000Z","payload":{"taskId":"task-124","status":"failed",...}}
```

**Recovery Script**:
```bash
#!/bin/bash
# retry-failed-callbacks.sh

GATEWAY_URL="https://gateway.example.com"
API_KEY="${GATEWAY_API_KEY}"
LOG_FILE="/var/log/ani-code/failed-callbacks.jsonl"

while IFS= read -r line; do
  echo "Retrying callback: $line"

  payload=$(echo "$line" | jq -r '.payload')

  curl -X POST "${GATEWAY_URL}/api/callback/task-status" \
    -H "Content-Type: application/json" \
    -H "X-API-Key: ${API_KEY}" \
    -d "$payload"

  if [ $? -eq 0 ]; then
    echo "✓ Callback succeeded"
  else
    echo "✗ Callback still failing"
  fi
done < "$LOG_FILE"
```

### Gateway Error Handling

The gateway should handle various error scenarios:

```javascript
async function submitTaskToDaemon(task) {
  try {
    const response = await fetch(`${DAEMON_URL}/api/task`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-API-Key': process.env.ANI_CODE_API_KEY
      },
      body: JSON.stringify(task),
      timeout: 30000  // 30 second timeout
    });

    if (response.status === 429) {
      // Rate limited - exponential backoff
      const retryAfter = parseInt(response.headers.get('Retry-After') || '60');
      await sleep(retryAfter * 1000);
      return submitTaskToDaemon(task);  // Retry
    }

    if (response.status === 401) {
      // Authentication failed
      throw new Error('Invalid API key - check daemon configuration');
    }

    if (response.status === 503) {
      // Daemon unhealthy
      throw new Error('Daemon unhealthy - check daemon status');
    }

    if (!response.ok) {
      const error = await response.json();
      throw new Error(`Daemon error: ${error.error}`);
    }

    return await response.json();

  } catch (error) {
    if (error.code === 'ECONNREFUSED') {
      // Daemon down
      throw new Error('Daemon not reachable - check if service is running');
    }

    if (error.name === 'AbortError') {
      // Timeout
      throw new Error('Daemon request timeout - daemon may be overloaded');
    }

    throw error;
  }
}
```

---

## Health Monitoring

### Daemon Health Check

**Endpoint**: `GET /health`
**Authentication**: None required

**Usage**:
```javascript
async function checkDaemonHealth() {
  const response = await fetch(`${DAEMON_URL}/health`);
  const health = await response.json();

  if (health.status === 'unhealthy') {
    console.error('Daemon unhealthy:', health.reason);
    // Alert operations team
    alertOps({
      severity: 'critical',
      message: `Daemon unhealthy: ${health.reason}`,
      metrics: health
    });
  } else if (health.status === 'degraded') {
    console.warn('Daemon degraded:', health);
    // Monitor closely
    monitorDaemon(health);
  }

  return health;
}

// Poll every 30 seconds
setInterval(checkDaemonHealth, 30000);
```

### Kubernetes Integration

**Liveness Probe**:
```yaml
livenessProbe:
  httpGet:
    path: /health
    port: 6501
  initialDelaySeconds: 30
  periodSeconds: 10
  timeoutSeconds: 5
  failureThreshold: 3
```

**Readiness Probe**:
```yaml
readinessProbe:
  httpGet:
    path: /health
    port: 6501
  initialDelaySeconds: 10
  periodSeconds: 5
  timeoutSeconds: 3
  failureThreshold: 2
  successThreshold: 1
```

**Health Status Interpretation**:

| Status | HTTP Code | K8s Action |
|--------|-----------|------------|
| `healthy` | 200 | Ready, accept traffic |
| `degraded` | 200 | Ready, but monitor closely |
| `unhealthy` | 503 | Not ready, restart pod |

---

## Rate Limiting & Throttling

### Daemon Rate Limits

**Limits**:
- **10 requests/minute** per workspace
- Applies to `POST /api/task` only

**Gateway Handling**:
```javascript
async function submitWithRetry(task, maxRetries = 5) {
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      const response = await submitTaskToDaemon(task);
      return response;
    } catch (error) {
      if (error.status === 429 && attempt < maxRetries - 1) {
        const retryAfter = parseInt(error.headers['Retry-After'] || '60');
        console.log(`Rate limited, retrying in ${retryAfter}s...`);
        await sleep(retryAfter * 1000);
        continue;
      }
      throw error;
    }
  }
}
```

### Gateway Rate Limiting

Implement client-side rate limiting on gateway:

```javascript
class DaemonClient {
  constructor(url, apiKey) {
    this.url = url;
    this.apiKey = apiKey;
    this.rateLimiter = new RateLimiter({
      points: 10,      // 10 requests
      duration: 60      // per minute
    });
  }

  async submitTask(task) {
    try {
      await this.rateLimiter.consume(task.workspaceId || 'default');
      return await this.sendRequest('/api/task', task);
    } catch (error) {
      if (error instanceof RateLimiterRes) {
        // Client-side rate limit hit
        throw new Error(`Rate limit: retry after ${error.msBeforeNext}ms`);
      }
      throw error;
    }
  }
}
```

---

## Security Considerations

### API Key Security

1. **Transmission**: Use HTTPS only in production
2. **Storage**: Environment variables only, never in code/logs
3. **Rotation**: Monthly rotation recommended
4. **Scope**: One key per environment (dev/staging/prod)

### Input Validation

Gateway should validate inputs before sending to daemon:

```javascript
function validateTask(task) {
  // Required fields
  if (!task.command) {
    throw new Error('command is required');
  }

  // Length limits
  if (task.command.length > 10 * 1024) {
    throw new Error('command too long (max 10KB)');
  }

  // Context size
  const contextSize = JSON.stringify(task.data?.context || {}).length;
  if (contextSize > 10 * 1024 * 1024) {
    throw new Error('context too large (max 10MB)');
  }

  // Prevent command injection
  if (task.command.startsWith('/')) {
    throw new Error('command cannot start with "/"');
  }

  return true;
}
```

### Network Security

**Production Checklist**:
- [ ] HTTPS/TLS enabled
- [ ] API keys rotated regularly
- [ ] Firewall rules restrict daemon access
- [ ] VPN/private network for inter-service communication
- [ ] Request signing (HMAC) for added security
- [ ] Audit logs enabled

---

## Troubleshooting

### Common Issues

#### 1. Callbacks Not Received

**Symptoms**: Tasks complete but gateway doesn't get updates

**Debug Steps**:
```bash
# 1. Check daemon logs
journalctl -u ani-code -f | grep Gateway

# 2. Verify gateway URL
echo $GATEWAY_URL

# 3. Test callback endpoint manually
curl -X POST https://gateway.example.com/api/callback/task-status \
  -H "Content-Type: application/json" \
  -H "X-API-Key: $GATEWAY_API_KEY" \
  -d '{"taskId":"test","status":"started"}'

# 4. Check failed callbacks log
tail -f /var/log/ani-code/failed-callbacks.jsonl
```

**Solutions**:
- Verify `GATEWAY_URL` is set correctly
- Check gateway firewall allows daemon IP
- Verify API key matches on both sides
- Check gateway endpoint is running and accessible

#### 2. 401 Unauthorized Errors

**Symptoms**: All requests fail with 401

**Debug Steps**:
```bash
# Check daemon config
echo $GATEWAY_API_KEY

# Check gateway config
echo $ANI_CODE_API_KEY

# Verify they match
[ "$GATEWAY_API_KEY" = "$ANI_CODE_API_KEY" ] && echo "Match" || echo "Mismatch"
```

**Solutions**:
- Ensure API keys match exactly (no whitespace)
- Restart daemon after changing `GATEWAY_API_KEY`
- Check API key is being sent in request headers

#### 3. 429 Rate Limit Errors

**Symptoms**: Frequent 429 responses

**Solutions**:
- Implement exponential backoff in gateway
- Reduce request rate (max 10/min per workspace)
- Queue tasks on gateway side
- Check for duplicate task submissions

#### 4. 503 Service Unavailable

**Symptoms**: Health check returns 503

**Debug Steps**:
```bash
# Check health status
curl http://daemon:6501/health | jq

# Check task queue
ani-code status

# Check daemon status
systemctl status ani-code
```

**Solutions**:
- Wait for queue to drain (queue > 50)
- Check daemon resource usage
- Verify daemon hasn't crashed
- Check logs for errors

---

## Performance Optimization

### Connection Pooling

Use HTTP keep-alive for better performance:

```javascript
const http = require('http');
const https = require('https');

const agent = new https.Agent({
  keepAlive: true,
  maxSockets: 50,
  maxFreeSockets: 10,
  timeout: 60000,
  keepAliveMsecs: 1000
});

const daemonClient = {
  async request(path, options) {
    return fetch(`${DAEMON_URL}${path}`, {
      ...options,
      agent
    });
  }
};
```

### Request Batching

Batch multiple task submissions:

```javascript
async function submitTaskBatch(tasks) {
  // Submit tasks with rate limiting
  const results = [];

  for (const task of tasks) {
    try {
      const result = await submitTaskToDaemon(task);
      results.push({ success: true, task: result });
    } catch (error) {
      results.push({ success: false, error: error.message });
    }

    // Respect rate limits - 10/min = ~6s between requests
    await sleep(6000);
  }

  return results;
}
```

### Caching Health Status

Cache health checks to reduce load:

```javascript
class DaemonHealthMonitor {
  constructor(url, cacheTtl = 30000) {
    this.url = url;
    this.cacheTtl = cacheTtl;
    this.cache = null;
    this.cacheTime = 0;
  }

  async getHealth(force = false) {
    const now = Date.now();

    if (!force && this.cache && (now - this.cacheTime) < this.cacheTtl) {
      return this.cache;
    }

    const response = await fetch(`${this.url}/health`);
    this.cache = await response.json();
    this.cacheTime = now;

    return this.cache;
  }
}
```

---

## Monitoring & Metrics

### Metrics to Track

**Gateway Side**:
- Task submission rate
- Task success/failure rate
- Average task duration
- API errors (by status code)
- Rate limit hits

**Daemon Side**:
- Queue depth
- Active tasks
- Task throughput
- Callback success rate
- Failed callback count
- Resource usage (CPU, memory)

### Prometheus Integration

Example Prometheus metrics:

```javascript
const prometheus = require('prom-client');

const taskSubmissionCounter = new prometheus.Counter({
  name: 'gateway_task_submissions_total',
  help: 'Total task submissions to daemon',
  labelNames: ['workspace_id', 'status']
});

const taskDurationHistogram = new prometheus.Histogram({
  name: 'gateway_task_duration_seconds',
  help: 'Task execution duration',
  labelNames: ['workspace_id', 'status']
});

const callbackCounter = new prometheus.Counter({
  name: 'gateway_callbacks_received_total',
  help: 'Total callbacks received from daemon',
  labelNames: ['status', 'success']
});
```

---

## Related Documentation

- [HTTP API Endpoints](./http-endpoints.md) - Detailed API reference
- [Task Monitor Architecture](../architecture/task-monitor.md)
- [Authentication System](../architecture/authentication.md)
- [Gateway Callback Spec](../../ani-code-gateway/docs/callback-api.md)

---

## Support

For integration issues:
1. Check daemon logs: `journalctl -u ani-code -f`
2. Check failed callbacks: `tail -f /var/log/ani-code/failed-callbacks.jsonl`
3. Verify health: `curl http://daemon:6501/health`
4. Test connectivity: `curl -X POST http://daemon:6501/api/task -H "X-API-Key: key" -d '{...}'`

Report issues: [GitHub Issues](https://github.com/your-org/ani-code/issues)

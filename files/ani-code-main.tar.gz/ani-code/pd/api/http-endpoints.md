# HTTP Server API Documentation

The ani-code daemon provides an HTTP server for webhook callbacks, health monitoring, and bot integrations.

## Server Configuration

- **Host**: Configurable via `HTTP_HOST` environment variable (default: `0.0.0.0`)
- **Port**: Configurable via `HTTP_PORT` environment variable (default: `3456`)
- **Verification Token**: Optional token for Lark webhooks via `LARK_VERIFICATION_TOKEN`
- **Telegram Bot Token**: Configured via `config.telegram.botToken` for Telegram integration
- **Parent Chat ID**: Inherited via `ANICODE_PARENT_CHAT_ID` environment variable for child processes

## Message Processing Features

### Message Deduplication
- Uses message IDs to prevent processing duplicate webhooks
- Maintains an in-memory cache with automatic cleanup
- Cache entries expire after 60 seconds

### Stale Message Filtering
- Rejects messages older than 10 seconds
- Prevents processing of delayed webhook deliveries
- Logs detailed timestamps for debugging

## Endpoints

### `/health` - Health Check
**Method**: GET

Returns the current health status of the daemon, task queue information, and running task details.

**Response**:
```json
{
  "status": "healthy",
  "uptime": 237391.690846863,
  "daemon": {
    "activeTasks": 1,
    "queuedTasks": 0
  },
  "runningTasks": [
    {
      "taskId": "task-abc123",
      "startedAt": "2025-12-05T10:00:00Z",
      "prompt": "First 100-150 chars of prompt...",
      "provider": "anthropic"
    }
  ],
  "tasks": {
    "active": 1,
    "queued": 0,
    "total": 10,
    "completed": 8,
    "failed": 1
  },
  "gateway": {
    "connected": true,
    "instanceId": "instance-123",
    "gatewayUrl": "https://gateway.example.com",
    "heartbeatActive": true
  },
  "resources": {
    "cpuUsage": 4.132638,
    "memoryUsage": 30,
    "diskUsage": 0
  },
  "timestamp": "2025-12-06T12:00:00.000Z"
}
```

**Response Fields**:
- `status`: Health status (`healthy`, `degraded`, `unhealthy`)
- `uptime`: Daemon uptime in seconds
- `daemon`: Summary of active and queued tasks
- `runningTasks`: Array of currently running tasks with:
  - `taskId`: Unique task identifier
  - `startedAt`: ISO 8601 timestamp when task started
  - `prompt`: First 100-150 characters of the task prompt
  - `provider`: Provider slug (`anthropic`, `openai`, `fireworks`, `google`, `mistral`, `groq`, `together`, `cohere`, `deepseek`)
- `tasks`: Detailed task statistics
- `gateway`: Gateway connection status (if enabled)
- `resources`: System resource usage

### `/callback/lark` - Lark Bot Webhook
**Method**: POST

Handles incoming webhooks from Lark bot for various events and commands.

#### Supported Event Types

##### URL Verification
Used by Lark to verify the webhook endpoint.

**Request Body**:
```json
{
  "type": "url_verification",
  "challenge": "challenge_string",
  "token": "verification_token"
}
```

**Response**:
```json
{
  "challenge": "challenge_string"
}
```

##### Message Events (v2.0)
Handles incoming messages from Lark users.

**Request Body**:
```json
{
  "schema": "2.0",
  "header": {
    "event_type": "im.message.receive_v1",
    "token": "verification_token"
  },
  "event": {
    "message": {
      "chat_id": "oc_xxxxx",
      "chat_type": "p2p|group",
      "content": "{\"text\":\"/help\"}",
      "message_type": "text"
    },
    "sender": {
      "sender_id": "user_id"
    }
  }
}
```

##### Card Action Events
Handles interactive card button clicks.

**Request Body**:
```json
{
  "action": {
    "value": "{\"action\":\"set_workdir\",\"workdir\":\"project-name\"}"
  },
  "open_chat_id": "oc_xxxxx"
}
```

## Lark Bot Commands

Commands can be sent via Lark messages to control the daemon:

### `/add [prompt]`
Creates a new Claude task with the provided prompt.
- Requires a working directory to be set
- Example: `/add fix the bug in the login function`

### `/continue [message]`
Continues from a previous Claude task context.
- Uses `-c` flag to maintain conversation continuity
- Default message is "continue" if not provided

### `/help`
Shows help message with available commands and interactive buttons.

### `/workdir [name]` or `/wd [name]`
Lists available working directories or sets the active directory.
- Without arguments: Shows current and available directories
- With name: Sets the working directory for the chat
- Supports parent directory matching for hierarchical project structures

### `/shell <command>` or `/task <command>` or `/run <command>`
Creates a new task to execute the specified shell command.
- Requires a working directory to be set first
- Example: `/shell npm test`

### `/shell! <command>` or `/task! <command>` or `/run! <command>`
Force runs a shell command using the daemon's default working directory.

### `/status`
Shows current running and pending tasks with git repository status.
- Displays file counts for staged, modified, and untracked files
- Shows smart action buttons based on git state
- Includes refresh button for real-time updates

### `/cancel <task-id>`
Cancels a specific task by its ID.

### `/stats`
Shows chat settings statistics and workdir usage.

## Card Actions

Interactive buttons in Lark messages trigger these actions:

### `set_workdir`
Sets the working directory for the current chat.

**Parameters**:
- `workdir`: Name of the directory to set

### `show_status`
Displays current task queue status with git repository information.
- Shows running and pending tasks
- Includes git status with file counts
- Provides context-aware git action buttons

### `list_workdirs`
Lists all available working directories.

### `claude_add`
Creates a new Claude task with a default or provided prompt.

**Parameters**:
- `prompt` (optional): The prompt for Claude

### `claude_continue`
Creates a Claude continue task to resume from previous context.

### `run_task`
Executes a command directly (synchronous, 30-second timeout).

**Parameters**:
- `command`: Shell command to execute

### `cancel_task`
Cancels a running task.

**Parameters**:
- `taskId`: ID of the task to cancel

### `retry_task`
Retries a previously failed task.

**Parameters**:
- `taskId`: ID of the task to retry

### `view_logs`
Shows the output logs of a task.

**Parameters**:
- `taskId`: ID of the task to view logs for

## CORS Headers

All endpoints include CORS headers for cross-origin requests:
- `Access-Control-Allow-Origin: *`
- `Access-Control-Allow-Methods: GET, POST, OPTIONS`
- `Access-Control-Allow-Headers: Content-Type, Authorization`

## Telegram Bot Integration

### `/webhook/telegram` - Telegram Bot Webhook
**Method**: POST

Handles incoming webhooks from Telegram bot for messages and callback queries.

#### Telegram Bot Commands

##### Task Management
- `/add [prompt]` - Add a new Claude task (prompts for input if no prompt provided)
- `/continue [message]` - Continue Claude conversation with context
- `/plan [action]` - Manage execution plans
  - `/plan list` - List all plans
  - `/plan reset` - Clear workspace plans
  - `/plan show <id>` - Show plan details
  - `/plan delete <id>` - Delete specific plan
  - `/plan purge` - Force reset all plans
- `/next [id]` - Execute next pending plan or specific plan
- `/yolo` - Execute all pending plans sequentially with cost tracking
- `/stopyolo` - Stop yolo mode execution
- `/cancel <id>` - Cancel a running task

##### Information Commands
- `/start` - Initialize bot and show welcome message
- `/help` - Display available commands
- `/status` - Show current task status and queue
- `/process` - Get detailed process information
- `/rank` - Display task queue with priorities
- `/progress <id>` - Track task progress with real-time updates

##### Workspace Management
- `/workdir [name]` - List or set working directory
- `/connect` - Connect Telegram chat to workspace
- `/disconnect` - Disconnect from workspace
- `/shell <command>` - Execute shell command in workspace

##### Utilities
- `/url` - Process most recent image in chat
- `/check` - Validate webhook configuration

## Error Responses

Standard HTTP error codes are returned for various error conditions:

- **400 Bad Request**: Invalid request format or parameters
- **401 Unauthorized**: Invalid verification token or bot token
- **404 Not Found**: Unknown endpoint
- **405 Method Not Allowed**: Wrong HTTP method for endpoint
- **500 Internal Server Error**: Server processing error
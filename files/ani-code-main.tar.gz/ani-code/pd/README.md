# Project Documentation

This folder contains comprehensive documentation for the project.

## Structure

- **`/api/`** - API endpoint documentation
- **`/changes/`** - Daily change logs (format: YYYY-MM-DD.md)
- **`/architecture/`** - System architecture documentation
- **`/features/`** - Feature documentation

## Auto-generation

Documentation is auto-updated using: `ani-code doc -y`

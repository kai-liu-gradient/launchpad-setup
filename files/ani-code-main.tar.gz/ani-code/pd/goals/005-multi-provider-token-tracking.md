# Goal: Multi-Provider Token Consumption Tracking

## Objective
Implement comprehensive token consumption tracking for non-Claude providers (Gemini, Codex, Cursor) by running test tasks, analyzing their output, extracting token usage, and storing it in the same statistics structure used for Claude tasks. This enables unified cost monitoring and usage analytics across all AI providers.

Currently, Claude tasks use the `ccusage` API for detailed token tracking, but other providers (Gemini, Codex) output token usage in their CLI response. This goal ensures consistent token tracking across all providers by:
1. Verifying token extraction from Gemini and Codex outputs
2. Ensuring tokens are properly stored in `task_stats` and `task_usage_v2` tables
3. Storing provider and model information with each task record

**Priority**: Medium
**Related Goals**: Goal 001 (HTTP Endpoints) - Uses same stats infrastructure

## Tasks

### Phase 1: Research & Analysis (2 hours)
- [x] Run test task with Gemini CLI and capture raw output
- [x] Run test task with Codex CLI and capture raw output
- [x] Analyze token output format from each provider
- [x] Document token extraction patterns for each provider
- [x] Verify `extractProviderTokens()` functions work correctly

### Phase 2: Token Extraction Verification (3 hours)
- [x] Test `extractCodexTokens()` with real Codex output
- [x] Test `extractGeminiTokens()` with real Gemini output
- [x] Add new extraction patterns if current ones miss tokens
- [x] Handle edge cases (no tokens reported, partial output)
- [x] Add unit tests for token extraction functions

### Phase 3: Stats Storage Integration (3 hours)
- [x] Verify `recordTaskCompletion()` correctly stores provider_id
- [x] Verify tokens are stored in `task_stats.total_tokens` field
- [x] Verify `task_usage_v2` records provider_id correctly
- [x] Create stats query helpers for multi-provider reporting
- [x] Add provider filter to `getModelUsageStats()` and `getDailyModelUsage()`

### Phase 4: Model Name Handling (2 hours)
- [x] Extract model name from Gemini output (if available)
- [x] Extract model name from Codex output (e.g., "gpt-4o", "o3-mini")
- [x] If no model detected, store provider name as model name
- [x] Add model extraction to `outputExtractor.js`
- [x] Update task completion flow to include model from provider output

### Phase 5: Cost Estimation (Optional) (2 hours)
- [x] Define token cost rates for Gemini models
- [x] Define token cost rates for Codex/OpenAI models
- [x] Implement cost calculation based on provider and model
- [x] Store estimated cost in `task_stats.cost_usd` field

### Phase 6: Testing & Validation (3 hours)
- [x] Run end-to-end test with Gemini task
- [x] Run end-to-end test with Codex task
- [x] Verify stats appear in `ani-code stats` command
- [x] Verify stats appear in `getDailyModelUsage()` API
- [x] Test multi-provider stats aggregation
- [x] Document provider-specific token output formats

## Acceptance Criteria

### Functional Requirements
- Gemini tasks record token consumption in `task_stats` table
- Codex tasks record token consumption in `task_stats` table
- Provider ID is recorded for all tasks (claude, gemini, codex, cursor)
- Model name is recorded (or provider name if model unavailable)
- Token counts appear in daily/monthly stats queries
- Stats can be filtered by provider

### Quality Requirements
- Token extraction works for all known output formats
- No tokens lost due to parsing errors
- Graceful handling when tokens not available
- Unit tests cover extraction edge cases

### Data Schema Requirements
Token records should follow existing schema:
```javascript
// task_stats table
{
  task_id: 'uuid',
  provider_id: 'gemini' | 'codex' | 'cursor' | 'claude',
  model: 'gemini-2.0-flash' | 'o3-mini' | 'gpt-4o' | 'claude-opus-4-5',
  input_tokens: 0,  // May be 0 if not parsed separately
  output_tokens: 0, // May be 0 if not parsed separately
  total_tokens: 197255, // Total from provider output
  cost_usd: 0.05,  // Estimated or 0 if unknown
  // ... other existing fields
}

// task_usage_v2 table (detailed per-model tracking)
{
  task_id: 'uuid',
  model_id: 'gemini-2.0-flash',
  provider_id: 'gemini',
  input_tokens: 0,
  input_cached_tokens: 0,
  output_tokens: 0,
  cost_usd: 0,
  created_at: timestamp
}
```

## Technical Specifications

### Current Token Extraction Patterns

**Codex CLI Output Format:**
```
[2026-01-05T10:00:00] OpenAI Codex v1.0.0
--------
workdir: /path/to/project
model: o3-mini
...
--------
[2026-01-05T10:00:05] User instructions: ...
[2026-01-05T10:00:10] thinking...
[2026-01-05T10:00:15] codex

<assistant response>

[2026-01-05T10:00:30] tokens used: 197,255
```

Pattern: `/\[\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\]\s+tokens\s+used:\s*([\d,]+)/i`

**Gemini CLI Output Format (JSON with -o json flag):**
```json
Loaded cached credentials.
{
  "session_id": "5a93a5eb-8a0b-425d-a4d9-1558d3498626",
  "response": "2 + 2 is 4.",
  "stats": {
    "models": {
      "gemini-2.5-flash-lite": {
        "api": {
          "totalRequests": 1,
          "totalErrors": 0,
          "totalLatencyMs": 993
        },
        "tokens": {
          "input": 3130,
          "prompt": 3130,
          "candidates": 58,
          "total": 3229,
          "cached": 0,
          "thoughts": 41,
          "tool": 0
        }
      }
    }
  }
}
```

Extraction:
- Response: `parsed.response`
- Model: Primary model from `Object.keys(parsed.stats.models)` (highest token count)
- Total tokens: Sum of `parsed.stats.models[model].tokens.total` for all models

### Stats Database Schema

Existing tables already support multi-provider:
- `task_stats.provider_id` - TEXT column for provider identification
- `task_stats.model` - TEXT column for model name
- `task_usage_v2.provider_id` - TEXT column for provider tracking

### Token Flow in Task Queue

Current flow in `task-queue.js`:
1. Task starts with `createTask()`
2. Provider CLI spawned via handler
3. Output collected in `handleTaskOutput()`
4. `extractProviderTokens()` called to parse tokens
5. Tokens stored in `task.parsedTokens`
6. `recordTaskStats()` saves to database with provider_id

## Progress
- Status: **Complete**
- Start Date: 2026-01-06
- Completion Date: 2026-01-06
- Completion: 100%
- Notes:
  - Phase 1-4 completed: Token and model extraction implemented for Gemini and Codex
  - Token extraction infrastructure exists in `src/providers/outputExtractor.js`
  - Stats DB already supports provider_id column
  - Gemini handler updated to use `-o json` output format for token stats
  - New functions added: `extractGeminiModel()`, `extractCodexModel()`, `extractProviderModel()`
  - `task-queue.js` updated to extract and store model from provider output
  - usageV2 records created for non-Claude providers
  - Manual tests in `tests/manual/test-output-extraction.js` all pass
  - **2026-01-06**: Phase 3 completed - Added provider filtering to stats queries
    - `getModelUsageStats()` now accepts optional `providerId` parameter (single or array)
    - `getDailyModelUsage()` now accepts optional `providerId` parameter (single or array)
    - New helper: `getProviderStats()` - Aggregated stats grouped by provider
    - New helper: `getProviderSummary()` - Complete provider breakdown with models
    - New helper: `getActiveProviders()` - List of providers with usage data
  - **2026-01-06**: Phase 6 completed - Testing & Validation
    - End-to-end tests run for both Gemini (`@@gemini`) and Codex (`@@codex`) tasks
    - Tasks execute successfully and show correct provider in API responses
    - Stats APIs verified: `/api/stats/usage-v2` shows multi-provider data
    - `getProviderStats()`, `getProviderSummary()`, `getDailyModelUsage()` all work with provider filters
    - **Bug fixes applied**:
      1. `task-queue.js`: Added provider extraction from `@@provider` syntax in `addTask()`
      2. `geminiCliHandler.js`: Set `supportsCcusage: false` (Gemini uses own token tracking, not ccusage API)
    - **Note**: Code changes require daemon restart to take effect (daemon is running old code)
  - **2026-01-06**: Phase 5 completed - Cost Estimation
    - Created `src/providers/costCalculator.js` with comprehensive pricing data
    - Supports Gemini models (gemini-2.5-pro, gemini-2.5-flash, gemini-2.0-flash, etc.)
    - Supports Codex/OpenAI models (o3-mini, o3, o1, gpt-4o, gpt-4o-mini, etc.)
    - Supports Cursor and Claude models for completeness
    - Cost calculation integrated into task-queue.js usageV2 creation
    - Uses 30/70 input/output ratio estimation when only total tokens available
    - Unit tests added in `tests/cost-calculator.test.js` (22 passing tests)
    - Manual tests updated in `tests/manual/test-output-extraction.js`

## Dependencies

### Internal Dependencies
- `src/providers/outputExtractor.js` - Token extraction functions
- `src/stats-db.js` - Database storage
- `src/task-queue.js` - Task completion handling
- `src/providers/geminiCliHandler.js` - Gemini provider
- `src/providers/codexCliHandler.js` - Codex provider

### External Dependencies
- Gemini CLI (`gemini` binary)
- Codex CLI (`codex` binary)
- Both must be installed and configured

### Related Goals
- Goal 001 (HTTP Endpoints): Uses same stats infrastructure for API reporting
- Goal 004 (Project Discovery): Can correlate token usage with projects

### Blocking Dependencies
- None (infrastructure already exists)

## Files Modified

**Primary Files**:
- `src/providers/outputExtractor.js` - Token and model extraction patterns
- `src/providers/costCalculator.js` - **NEW** Cost estimation based on provider/model pricing
- `src/task-queue.js` - Token merge logic and cost calculation integration
- `src/stats-db.js` - Provider-filtered query helpers

**Test Files**:
- `tests/cost-calculator.test.js` - **NEW** Unit tests for cost calculator (22 tests)
- `tests/task-queue.test.js` - Updated mocks for new dependencies
- `tests/manual/test-output-extraction.js` - Added cost calculator integration tests

**Documentation**:
- `pd/goals/005-multi-provider-token-tracking.md` - This file

## Version Compatibility

**Version Impact**: This is a **PATCH** version update
- Bug fix/enhancement to existing functionality
- No API changes
- Backward compatible
- Token tracking already exists, this improves accuracy

## Test Plan

### Manual Test: Gemini Task
```bash
# Run a simple task with Gemini
ani-code test -p gemini "What is 2+2?"

# Check logs for token extraction
tail -f /var/log/ani-code/daemon.log | grep -i token

# Query stats database
sqlite3 data/stats.db "SELECT task_id, provider_id, model, total_tokens FROM task_stats ORDER BY created_at DESC LIMIT 5"
```

### Manual Test: Codex Task
```bash
# Run a simple task with Codex
ani-code test -p codex "What is 2+2?"

# Check logs for token extraction
tail -f /var/log/ani-code/daemon.log | grep -i token

# Query stats database
sqlite3 data/stats.db "SELECT task_id, provider_id, model, total_tokens FROM task_stats ORDER BY created_at DESC LIMIT 5"
```

### Automated Tests
```javascript
// tests/output-extractor.test.js
describe('extractCodexTokens', () => {
  it('should extract tokens from Codex output', () => {
    const output = '[2026-01-05T10:00:00] tokens used: 197,255';
    expect(extractCodexTokens(output)).toBe(197255);
  });
});

describe('extractGeminiTokens', () => {
  it('should extract tokens from Gemini output', () => {
    // Add test based on actual Gemini output format
  });
});
```

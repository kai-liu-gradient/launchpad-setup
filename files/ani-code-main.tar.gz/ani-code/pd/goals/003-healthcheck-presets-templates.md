# Goal: Healthcheck Presets and Prompt Templates

## Objective
Create a modular preset system for healthcheck prompts that enables Claude to perform intelligent health analysis across different techstacks. Each preset defines the analysis strategy, command execution, and output format for its respective techstack. This separation allows easy maintenance and extension of healthcheck capabilities without modifying core command logic.

The preset system follows the existing `src/presets/` pattern used by the `/remember` command, ensuring consistency across ani-code features.

**Priority**: Medium
**Estimated Effort**: 1-2 days (12 hours)

## Tasks

### Phase 1: Preset Directory Structure (2 hours)
- [x] Create `src/presets/healthcheck/` directory for healthcheck-specific presets
- [x] Create `src/presets/healthcheck/README.md` with preset development guide
- [x] Define preset file naming convention (techstack.md pattern)
- [x] Create preset loader utility for healthcheck command integration

### Phase 2: Core Preset Template (3 hours)
- [x] Create `src/presets/healthcheck/_schema.md` defining JSON output schema v1.0.0
- [x] Define common sections: summary, vulnerabilities, recommendations
- [x] Document required fields vs optional fields
- [x] Include example outputs for reference

### Phase 3: Auto-Detection Preset (2 hours)
- [x] Create `src/presets/healthcheck/auto.md` for multi-stack detection
- [x] Define project structure detection rules (package.json, requirements.txt, go.mod, Cargo.toml)
- [x] Implement priority ordering for overlapping stacks (monorepo support)
- [x] Add instructions for aggregating results across multiple stacks

### Phase 4: Node.js Preset (3 hours)
- [x] Create `src/presets/healthcheck/node.md` for Node.js/npm analysis
- [x] Include npm audit command execution and parsing instructions
- [x] Add npm outdated analysis for dependency health
- [x] Define package.json health checks (engines, scripts, license)
- [x] Include security best practices (lockfile, private registry, etc.)
- [x] Add .nvmrc and Node version compatibility checks

### Phase 5: HTML Report Template (2 hours)
- [x] Create `src/presets/healthcheck/report-template.html` base template
- [x] Define CSS styles for severity color coding
- [x] Create collapsible sections for detailed vulnerability info
- [x] Add print-friendly styles for report export

### Phase 6: Future Stack Placeholder Presets (2 hours)
- [x] Create `src/presets/healthcheck/python.md` placeholder (pip, safety, bandit)
- [x] Create `src/presets/healthcheck/go.md` placeholder (go mod, govulncheck)
- [x] Create `src/presets/healthcheck/rust.md` placeholder (cargo audit)
- [x] Mark placeholders with NOT_IMPLEMENTED status for future work

## Acceptance Criteria

### Functional Requirements
- Presets stored in `src/presets/healthcheck/` directory
- Each preset is self-contained markdown with clear instructions
- Auto preset detects and routes to appropriate techstack presets
- Node.js preset produces accurate vulnerability analysis
- JSON output matches schema v1.0.0 specification
- HTML report is readable and professionally styled

### Quality Requirements
- Preset documentation is clear for future contributors
- Schema is versioned for backward compatibility
- Example outputs provided for validation
- Placeholder presets clearly indicate future implementation

### Maintainability Requirements
- Presets can be modified without code changes
- New techstacks can be added by creating new preset files
- Schema versioning allows report format evolution

## Technical Specifications

### Preset Directory Structure
```
src/presets/healthcheck/
├── README.md              # Development guide
├── _schema.md             # JSON output schema definition
├── auto.md                # Auto-detection preset
├── node.md                # Node.js/npm preset
├── python.md              # Python placeholder
├── go.md                  # Go placeholder
├── rust.md                # Rust placeholder
└── report-template.html   # HTML report template
```

### Node.js Preset Content Structure

```markdown
# Node.js Healthcheck Preset

## Detection
Detect Node.js projects by presence of:
- package.json (required)
- package-lock.json or yarn.lock or pnpm-lock.yaml (optional)

## Commands to Execute
1. `npm audit --json` - Security vulnerability scan
2. `npm outdated --json` - Dependency freshness check
3. `node -v` - Runtime version detection

## Analysis Instructions
[Claude analysis instructions for interpreting results]

## Output Mapping
[Instructions for mapping command outputs to JSON schema]

## Recommendations
[Template for generating fix recommendations]
```

### JSON Schema v1.0.0 Key Fields

```json
{
  "version": "1.0.0",          // Required - schema version
  "timestamp": "ISO 8601",     // Required - generation time
  "lastUpdate": "ISO 8601",    // Required - last content update
  "projectPath": "string",     // Required - analyzed path
  "detectedStacks": ["node"],  // Required - detected techstacks
  "summary": {
    "healthScore": 0-100,      // Required - overall score
    "status": "pass|warning|critical", // Required
    "totalIssues": number,     // Required
    "critical": number,        // Required
    "high": number,            // Required
    "medium": number,          // Required
    "low": number              // Required
  },
  "stacks": {
    "[stackName]": {           // One per detected stack
      "audit": {},             // Stack-specific audit results
      "dependencies": {},      // Dependency analysis
      "config": {}             // Configuration health
    }
  },
  "recommendations": []        // Prioritized fix actions
}
```

### HTML Report Template Features
- Bootstrap 5 or Tailwind CSS for styling
- Severity badges with color coding:
  - Critical: Red (#dc3545)
  - High: Orange (#fd7e14)
  - Medium: Yellow (#ffc107)
  - Low: Blue (#0d6efd)
- Collapsible vulnerability details
- Summary dashboard at top
- Responsive design for all screen sizes
- Print-friendly stylesheet

## Progress
- Status: **Completed**
- Start Date: 2025-01-05
- Completion Date: 2025-01-05
- Completion: 100%
- Notes:
  - All preset files created in `src/presets/healthcheck/` directory
  - README.md provides comprehensive development guide for future contributors
  - _schema.md defines JSON output schema v1.0.0 with validation examples
  - auto.md and node.md presets already existed - verified they meet requirements
  - python.md, go.md, rust.md placeholders created with NOT_IMPLEMENTED status
  - report-template.html created with Bootstrap-like styling, severity color coding, collapsible sections, print-friendly styles
  - src/presets/README.md updated with healthcheck preset documentation
  - Node.js preset is the priority for initial release
  - Python, Go, Rust presets are placeholders for future development
  - HTML template is reusable across all techstacks

## Dependencies

### Internal Dependencies
- Goal 002: Healthcheck Command Infrastructure (parallel development possible)
- `src/presets/` existing structure and patterns

### External Dependencies
- None (presets are markdown files with no external requirements)

### Blocking Dependencies
- None (can be developed independently, integrated with Goal 002)

## Version Compatibility

**Version Impact**: No version change
- Adding preset files does not change CLI version
- Presets are internal implementation details

## Files to Create

**New Files**:
- `src/presets/healthcheck/README.md` - Preset development guide
- `src/presets/healthcheck/_schema.md` - JSON schema definition
- `src/presets/healthcheck/auto.md` - Auto-detection preset
- `src/presets/healthcheck/node.md` - Node.js/npm preset
- `src/presets/healthcheck/python.md` - Python placeholder
- `src/presets/healthcheck/go.md` - Go placeholder
- `src/presets/healthcheck/rust.md` - Rust placeholder
- `src/presets/healthcheck/report-template.html` - HTML template

**Modified Files**:
- `src/presets/README.md` - Add healthcheck presets documentation
- `CLAUDE.md` - Document healthcheck presets

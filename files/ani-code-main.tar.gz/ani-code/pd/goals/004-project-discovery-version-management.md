# Goal: Project Discovery and Version Management

## Objective
Implement a `/projects` command that scans the current workspace to discover project manifests (package.json, pyproject.toml, etc.) and caches project metadata in `.ani-code/projects/` for quick retrieval by other features. Additionally, provide version management capabilities to easily bump project versions across the workspace.

This feature enables:
1. **Project Discovery**: Automatically detect and catalog all projects in a workspace/monorepo
2. **Fast Retrieval**: Cached project tree allows other commands (healthcheck, build, deploy) to quickly access project info
3. **Version Management**: Bulk or targeted version updates with `--set-version` or `--burst` options

**Priority**: Medium
**Related Goals**: Goal 002 (Healthcheck) - Can leverage project registry for techstack detection

## Tasks

### Phase 1: Command Infrastructure (4 hours)
- [x] Create `src/commands/projects.js` with Commander.js command structure
- [x] Implement `projects scan` as the default subcommand
- [x] Add `--workspace <path>` option to specify target directory (default: cwd)
- [x] Add `--exclude <patterns>` option for additional exclusion patterns
- [x] Add `--depth <number>` option to limit scan depth (default: 5)
- [x] Register projects command in `src/index.js`

### Phase 2: Project Scanner (6 hours)
- [x] Implement recursive directory scanner with exclusion patterns
- [x] Default exclusions: `node_modules`, `.git`, `dist`, `build`, `.ani-code`, `vendor`, `__pycache__`
- [x] Detect project manifests:
  - `package.json` (Node.js/npm)
  - `pyproject.toml` / `requirements.txt` / `setup.py` / `Pipfile` (Python)
  - `go.mod` (Go)
  - `Cargo.toml` (Rust)
  - `pom.xml` / `build.gradle` / `build.gradle.kts` (Java)
  - `composer.json` (PHP)
- [x] Extract metadata from each manifest:
  - File path (relative to workspace)
  - Project name
  - Project description
  - Version
  - Techstack type
- [x] Handle monorepo structures (multiple projects in subdirectories)

### Phase 3: Project Registry Storage (4 hours)
- [x] Create `.ani-code/projects/` directory structure
- [x] Define JSON schema for project registry (v1.0.0)
- [x] Implement `registry.json` file with all discovered projects
- [x] Add individual project files: `projects/{project-name}.json` for detailed info
- [x] Include scan timestamp and metadata in registry
- [x] Add `--force` flag to rescan even if cache exists

### Phase 4: Version Management Commands (4 hours)
- [x] Implement `projects set-version <name> <version>` to set exact version
- [x] Implement `projects burst <name>` to increment patch version (1.2.3 → 1.2.4)
- [x] Implement `projects burst-all` to burst all project versions
- [x] Add `--dry-run` flag to preview version changes
- [x] Update manifest file with new version (write back to package.json, etc.)
- [x] Support version formats: semver for npm, PEP 440 for Python

### Phase 5: Query and List Commands (3 hours)
- [x] Implement `projects list` to show all discovered projects
- [x] Implement `projects show <name>` to display project details
- [x] Add `--json` flag for machine-readable output
- [x] Add `--tree` flag to show project hierarchy
- [x] Implement `projects refresh` to update registry without full rescan

### Phase 6: Testing & Documentation (3 hours)
- [x] Write unit tests for project scanner
- [x] Test version bump logic with various manifest types
- [x] Test exclusion patterns work correctly
- [x] Add projects documentation to CLAUDE.md
- [x] Create example registry files for documentation

## Acceptance Criteria

### Functional Requirements
- `ani-code projects scan` discovers all projects in workspace
- Registry stored in `.ani-code/projects/registry.json` with valid JSON schema
- Exclusion patterns prevent scanning of build artifacts and dependencies
- `--set-version` correctly updates manifest files
- `--burst` increments the patch version correctly
- `projects list` displays all discovered projects with key info
- Monorepo support: correctly handles nested project structures

### Quality Requirements
- Scan completes in <10 seconds for typical workspaces
- All unit tests pass
- Registry JSON validates against schema
- No modification to source files during scan (read-only)
- Version updates are atomic (no partial writes)

### Integration Requirements
- Registry can be used by healthcheck command for techstack detection
- Project info accessible via daemon API for other tools
- `.ani-code/projects/` added to `.gitignore`

## Technical Specifications

### Command Structure
```bash
# Scan and discover projects
ani-code projects scan
ani-code projects scan --workspace /path/to/workspace
ani-code projects scan --depth 3
ani-code projects scan --exclude "temp,cache"

# List discovered projects
ani-code projects list
ani-code projects list --json
ani-code projects list --tree

# Show project details
ani-code projects show my-package

# Version management
ani-code projects my-package --set-version 2.0.0
ani-code projects my-package --burst
ani-code projects --burst-all
ani-code projects my-package --burst --dry-run
```

### Registry JSON Schema (v1.0.0)
```json
{
  "version": "1.0.0",
  "lastScan": "2026-01-05T10:00:00Z",
  "workspacePath": "/path/to/workspace",
  "scanDepth": 5,
  "exclusions": ["node_modules", ".git", "dist", "build"],
  "projectCount": 5,
  "projects": [
    {
      "id": "my-package",
      "name": "my-package",
      "description": "A sample package",
      "version": "1.2.3",
      "path": "packages/my-package",
      "manifestPath": "packages/my-package/package.json",
      "manifestType": "package.json",
      "techstack": "node",
      "lastModified": "2026-01-04T15:30:00Z",
      "metadata": {
        "hasLockFile": true,
        "dependencies": 25,
        "devDependencies": 10
      }
    }
  ]
}
```

### Individual Project File (projects/{name}.json)
```json
{
  "id": "my-package",
  "name": "my-package",
  "description": "A sample package",
  "version": "1.2.3",
  "path": "packages/my-package",
  "manifestPath": "packages/my-package/package.json",
  "manifestType": "package.json",
  "techstack": "node",
  "lastModified": "2026-01-04T15:30:00Z",
  "manifest": {
    "name": "my-package",
    "version": "1.2.3",
    "description": "A sample package",
    "main": "index.js",
    "scripts": {
      "build": "tsc",
      "test": "jest"
    },
    "dependencies": {},
    "devDependencies": {}
  },
  "versionHistory": [
    {
      "version": "1.2.2",
      "timestamp": "2026-01-01T10:00:00Z",
      "source": "manual"
    }
  ]
}
```

### Directory Structure
```
.ani-code/
├── projects/
│   ├── registry.json           # Master registry of all projects
│   ├── my-package.json         # Individual project details
│   ├── another-project.json
│   └── ...
├── healthcheck/
└── logs/
```

### Manifest Type Detection Priority
1. `package.json` → Node.js (npm/yarn/pnpm)
2. `pyproject.toml` → Python (modern)
3. `setup.py` → Python (legacy)
4. `requirements.txt` → Python (minimal)
5. `Pipfile` → Python (Pipenv)
6. `go.mod` → Go
7. `Cargo.toml` → Rust
8. `pom.xml` → Java (Maven)
9. `build.gradle` / `build.gradle.kts` → Java (Gradle)
10. `composer.json` → PHP

## Progress
- Status: **Complete** (100%)
- Start Date: 2026-01-05
- Completion Date: 2026-01-05
- Notes:
  - Initial goal created from implementation request
  - Synergies with healthcheck command (both detect techstacks)
  - Consider adding API endpoint for project registry in future
  - **2026-01-05**: Implemented core functionality (Phases 1-5):
    - Created `src/commands/projects.js` with full command structure
    - Implemented recursive scanner with 18 default exclusion patterns
    - Added manifest parsers for 11 different manifest types
    - Created registry storage with JSON schema v1.0.0
    - Implemented all version management commands (set-version, burst, burst-all)
    - Added list, show, and refresh commands with JSON and tree output modes
    - Registered command in `src/index.js`
    - Tested with current workspace: found 3 projects in 6ms
  - **2026-01-05**: Completed Phase 6 (Testing & Documentation):
    - Created comprehensive unit tests in `tests/projects.test.js` (49 tests)
    - Tests cover: manifest detection, version bumping, exclusion patterns, monorepo support
    - Added full documentation to CLAUDE.md with usage examples and schema reference
    - Created example registry files in `pd/examples/projects/`:
      - `registry-example.json` - Monorepo with 5 Node.js projects
      - `project-detail-example.json` - Individual project with version history
      - `multi-techstack-example.json` - Full-stack project with Node, Python, Go, Rust

## Dependencies

### Internal Dependencies
- `src/index.js` - Command registration
- `src/config.js` - Configuration options
- Potentially reuse techstack detection from healthcheck

### External Dependencies
- Node.js built-in `fs` and `path` modules
- `toml` or similar package for pyproject.toml parsing (optional)

### Related Goals
- Goal 002 (Healthcheck Command Infrastructure): Can share techstack detection logic
- Goal 003 (Healthcheck Presets): Similar manifest detection patterns

### Blocking Dependencies
- None (independent feature)

## Version Compatibility

**Version Impact**: This is a **MINOR** version update
- Adding new feature without breaking existing functionality
- New command does not affect existing commands
- Backward compatible

## Files to Create/Modify

**New Files** (Created):
- `src/commands/projects.js` - Main command implementation (1293 lines)
- `tests/projects.test.js` - Unit tests (49 tests covering all functionality)
- `pd/examples/projects/registry-example.json` - Example monorepo registry
- `pd/examples/projects/project-detail-example.json` - Example project with version history
- `pd/examples/projects/multi-techstack-example.json` - Multi-language project example

**Modified Files** (Updated):
- `src/index.js` - Register projects command
- `CLAUDE.md` - Add projects documentation (comprehensive usage guide)

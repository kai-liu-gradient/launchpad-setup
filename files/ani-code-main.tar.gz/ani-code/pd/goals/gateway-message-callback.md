# Goal: Gateway Message Callback System

## Overview
Implement a complete message callback system in ani-code-gateway to properly route responses from ani-code daemon instances back to the original communication channels (Telegram, Lark, etc.).

## Problem Statement
Currently, when ani-code daemon tries to send responses back through the gateway:
1. The daemon calls `/api/callback/message` endpoint which doesn't exist
2. The gateway has no way to map responses back to original sessions
3. Responses fall back to direct sending, bypassing the gateway routing

## Solution Architecture

### Token-Session Mapping Flow

```mermaid
sequenceDiagram
    participant User
    participant Telegram
    participant Gateway
    participant AniCode as Ani-Code Daemon

    User->>Telegram: /start workspace_token
    Telegram->>Gateway: Webhook with chat_id, user_id
    Gateway->>Gateway: Create session mapping
    Note over Gateway: Map: gateway_token -> {chatId, platform, userId}
    Gateway->>AniCode: Forward request + x-gateway-token
    AniCode->>AniCode: Process request
    AniCode->>Gateway: POST /api/callback/message<br/>with gateway_token
    Gateway->>Gateway: Lookup session by token
    Gateway->>Telegram: Send message to chatId
    Telegram->>User: Display response
```

### Key Components

#### 1. Session Manager Service
- Maintains mapping: `gateway_token -> session_info`
- Session info includes:
  - `platform`: "telegram" or "lark"
  - `chatId`: Platform-specific chat identifier
  - `userId`: User identifier
  - `instanceUrl`: Target ani-code instance
  - `createdAt`: Session creation timestamp
  - `lastActivity`: Last activity timestamp

#### 2. Message Callback Endpoint
- `POST /api/callback/message`
- Accepts messages from ani-code daemons
- Validates gateway token
- Routes to appropriate platform handler

#### 3. Platform Handlers
- **TelegramHandler**: Sends messages via Telegram Bot API
- **LarkHandler**: Sends messages via Lark Bot API
- Extensible for future platforms

## Implementation Requirements

### Gateway Side

#### New Endpoints
```javascript
// Message callback from ani-code daemon
POST /api/callback/message
{
  "platform": "telegram",     // Platform hint (optional, can be derived from token)
  "chatId": "123456",         // Chat identifier
  "message": {
    "text": "Response text",
    "reply_markup": {         // Telegram inline keyboard
      "inline_keyboard": [[]]
    },
    "parse_mode": "Markdown"
  },
  "messageId": "msg_123",     // For editing existing messages
  "action": "send",           // "send", "edit", or "delete"
  "instanceId": "hostname",
  "timestamp": "2025-11-22T..."
}

Headers:
- x-gateway-token: gw_xxx  // Gateway token for validation
- x-instance-id: hostname   // Instance identifier
```

#### Session Management Endpoints
```javascript
// Get session info (for debugging)
GET /api/sessions/:token

// List active sessions
GET /api/sessions

// Clear expired sessions
POST /api/sessions/cleanup
```

### Database Schema
```sql
-- Session mappings table
CREATE TABLE gateway_sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  gateway_token TEXT UNIQUE NOT NULL,
  platform TEXT NOT NULL,              -- 'telegram' or 'lark'
  chat_id TEXT NOT NULL,                -- Platform-specific chat ID
  user_id TEXT,                         -- User identifier
  workspace_token TEXT,                 -- Original workspace token
  instance_url TEXT,                    -- Target ani-code instance
  metadata TEXT,                        -- JSON metadata
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  last_activity DATETIME DEFAULT CURRENT_TIMESTAMP,
  expires_at DATETIME,

  INDEX idx_gateway_token (gateway_token),
  INDEX idx_chat_id (chat_id),
  INDEX idx_expires_at (expires_at)
);

-- Message history (optional, for debugging)
CREATE TABLE message_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id INTEGER,
  direction TEXT,                       -- 'inbound' or 'outbound'
  platform TEXT,
  chat_id TEXT,
  message_data TEXT,                    -- JSON message content
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (session_id) REFERENCES gateway_sessions(id)
);
```

### Configuration
```yaml
# Gateway environment variables
TELEGRAM_BOT_TOKEN=xxx              # Telegram bot token
LARK_APP_ID=xxx                     # Lark app credentials
LARK_APP_SECRET=xxx

SESSION_TIMEOUT_MINUTES=60           # Session expiry time
SESSION_CLEANUP_INTERVAL_MINUTES=10  # Cleanup interval
MESSAGE_HISTORY_ENABLED=true         # Enable message history
MESSAGE_HISTORY_RETENTION_DAYS=7     # History retention
```

## API Integration Points

### 1. Telegram Webhook Handler Update
When receiving Telegram webhook:
```javascript
async handleTelegramWebhook(update) {
  const chatId = update.message?.chat?.id;
  const userId = update.message?.from?.id;
  const text = update.message?.text;

  // Parse /start command with token
  if (text?.startsWith('/start ')) {
    const workspaceToken = text.substring(7);

    // Create or update session
    const gatewayToken = await sessionManager.createSession({
      platform: 'telegram',
      chatId,
      userId,
      workspaceToken
    });

    // Forward to ani-code with gateway token
    await forwardToAniCode({
      headers: {
        'x-gateway-token': gatewayToken,
        'x-gateway-url': config.GATEWAY_URL,
        'x-source-platform': 'telegram',
        'x-chat-id': chatId
      }
    });
  }
}
```

### 2. Message Callback Handler
```javascript
async handleMessageCallback(req, res) {
  const gatewayToken = req.headers['x-gateway-token'];
  const { message, action = 'send', messageId } = req.body;

  // Validate token and get session
  const session = await sessionManager.getSession(gatewayToken);
  if (!session) {
    return res.status(401).json({ error: 'Invalid gateway token' });
  }

  // Update last activity
  await sessionManager.touchSession(gatewayToken);

  // Route to platform handler
  const handler = platformHandlers[session.platform];
  if (!handler) {
    return res.status(400).json({ error: 'Unsupported platform' });
  }

  // Send message through platform
  const result = await handler[action]({
    chatId: session.chatId,
    message,
    messageId
  });

  // Store in history if enabled
  if (config.MESSAGE_HISTORY_ENABLED) {
    await messageHistory.store({
      sessionId: session.id,
      direction: 'outbound',
      platform: session.platform,
      chatId: session.chatId,
      messageData: message
    });
  }

  return res.json({ success: true, result });
}
```

### 3. Platform Handlers

#### Telegram Handler
```javascript
class TelegramHandler {
  constructor(botToken) {
    this.botToken = botToken;
    this.apiUrl = `https://api.telegram.org/bot${botToken}`;
  }

  async send({ chatId, message }) {
    const response = await axios.post(`${this.apiUrl}/sendMessage`, {
      chat_id: chatId,
      text: message.text,
      parse_mode: message.parse_mode || 'Markdown',
      reply_markup: message.reply_markup
    });
    return response.data;
  }

  async edit({ chatId, message, messageId }) {
    const response = await axios.post(`${this.apiUrl}/editMessageText`, {
      chat_id: chatId,
      message_id: messageId,
      text: message.text,
      parse_mode: message.parse_mode || 'Markdown',
      reply_markup: message.reply_markup
    });
    return response.data;
  }

  async delete({ chatId, messageId }) {
    const response = await axios.post(`${this.apiUrl}/deleteMessage`, {
      chat_id: chatId,
      message_id: messageId
    });
    return response.data;
  }
}
```

## Testing Strategy

### Unit Tests
1. Session manager CRUD operations
2. Token validation and expiry
3. Platform handler message formatting
4. Database operations

### Integration Tests
1. End-to-end message flow
2. Session timeout handling
3. Multi-platform routing
4. Error recovery scenarios

### Load Tests
1. Concurrent session handling
2. Message throughput
3. Database performance
4. Memory usage under load

## Security Considerations

1. **Token Security**
   - Use cryptographically secure token generation
   - Implement token rotation for long sessions
   - Rate limit token validation attempts

2. **Input Validation**
   - Sanitize all message content
   - Validate platform-specific formats
   - Prevent injection attacks

3. **Session Management**
   - Automatic session expiry
   - Secure session storage
   - Activity-based timeout

4. **Audit Logging**
   - Log all message routing decisions
   - Track token usage patterns
   - Monitor for suspicious activity

## Migration Plan

### Phase 1: Core Implementation
1. Implement session manager service
2. Add database tables
3. Create message callback endpoint
4. Implement Telegram handler

### Phase 2: Integration
1. Update Telegram webhook handler
2. Test with ani-code daemon
3. Add session management endpoints
4. Implement cleanup service

### Phase 3: Enhancement
1. Add Lark handler
2. Implement message history
3. Add monitoring metrics
4. Create admin dashboard

## Success Criteria

1. **Functional**
   - Messages route correctly to original channels
   - Session state maintained across requests
   - Support for multiple concurrent sessions

2. **Performance**
   - Message routing latency < 100ms
   - Support 1000+ active sessions
   - Database queries < 10ms

3. **Reliability**
   - No message loss
   - Automatic session recovery
   - Graceful error handling

## Monitoring Metrics

1. **Session Metrics**
   - Active sessions count
   - Session creation rate
   - Session expiry rate
   - Average session duration

2. **Message Metrics**
   - Messages routed per minute
   - Platform distribution
   - Success/failure rates
   - Average routing latency

3. **Error Metrics**
   - Invalid token attempts
   - Platform send failures
   - Database errors
   - Timeout occurrences

## Future Enhancements

1. **Advanced Features**
   - Message queuing for reliability
   - Batch message sending
   - Rich media support
   - Voice/video message handling

2. **Platform Support**
   - Discord integration
   - Slack integration
   - WhatsApp Business API
   - Custom webhook support

3. **Analytics**
   - User activity tracking
   - Message analytics dashboard
   - Usage patterns analysis
   - Cost optimization insights
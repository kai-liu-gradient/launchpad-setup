# Goal: Chat Display Mode (/chatui) for Focused Task Output

## Objective
Implement a configurable chat display mode system that allows users to switch between different output verbosity levels when receiving task updates via Telegram, Lark, or gateway. By default, tasks emit full output (headers, footers, metadata, git status, cost lines). A new `/chatui` command (or `ani-code chatui`) enables switching to simpler modes that focus on progress text and result content, reducing visual noise for users who want concise updates.

This addresses the need for a cleaner, distraction-free task monitoring experience. Users monitoring many tasks or working on focused workflows often only need the progress update and final result, not the full metadata envelope (footer, provider info, git status, etc.).

**Priority**: Medium
**Related Goals**: Goal 001 (HTTP Endpoints/Gateway Integration - message formatting), Gateway Message Callback (message routing)

## Analysis Summary

### Conflicts with Existing Goals
**None identified.** This feature is orthogonal to all existing goals:
- Goals 001-004: Infrastructure and tooling (no overlap)
- Goals 005-008: Provider support and token tracking (no overlap)
- Goal 009: Hint injection (complementary - hints are injected into prompts, not output formatting)
- Goal 010: Unmanaged task detection (no overlap)
- Gateway Message Callback: **Complementary** - display modes control how messages are formatted before being sent through existing message routing

### Dependencies on Existing Goals
**Goal 001 (HTTP Endpoints)**: Uses same API handler patterns for new `/api/chatui` endpoint.
**Gateway Message Callback**: Display mode settings need to be respected when formatting messages routed through the gateway.

### Integration Points
The display mode system integrates with the notification layer:
- `telegram-notifier-base.js` - Base formatting (footer, task summaries) needs mode-aware behavior
- `telegram-notifier.js` - Full Telegram notifier needs mode-aware message formatting
- `lark-notifier.js` - Lark notifier needs mode-aware formatting
- `dummy-telegram-notifier.js` - Gateway dummy notifier needs mode-aware formatting
- `task-monitor.js` - Task lifecycle events reference notifier methods
- `chat-settings.js` - Existing chat-to-workspace mapping can store display mode preference

## Display Modes

### `full` (Default)
Current behavior - all output included:
- Task started/queued notification with emoji header
- Progress updates with full context
- Completion message with:
  - Duration, exit code
  - Full task output (with truncation rules)
  - Git status (branch, dirty files, diff stats)
  - Cost/token line (model, input/output tokens, cached)
  - Footer (hostname, time, workspace path, provider)

### `simple`
Streamlined output focused on content:
- Task started: Brief one-line notification (task name/ID only)
- Progress updates: Raw progress text only (edited in-place)
- Completion message:
  - Task output/result content
  - Duration (inline, not block)
  - No git status block
  - No cost/token line
  - Minimal footer (task ID only)

### `default`
Alias for `full` mode. Exists for clarity in configuration.

## Tasks

**Phase 1: Display Mode Configuration (3 hours)**
- [x] Create `src/display-mode.js` module with `DisplayModeManager` class
- [x] Define mode constants: `full`, `simple`, `default` (alias for `full`)
- [x] Implement per-chat mode storage in `chat-settings.js` (add `displayMode` field)
- [x] Add `CHAT_DISPLAY_MODE` environment variable for global default override
- [x] Add `getDisplayMode(chatId)` method that checks: per-chat setting > env var > `full`
- [x] Add `setDisplayMode(chatId, mode)` method to persist per-chat preference
- [x] Document `.env` configuration: `CHAT_DISPLAY_MODE=full|simple`

**Phase 2: CLI Command Implementation (2 hours)**
- [x] Add `chatui` command to `src/index.js` CLI registration
- [x] Create `src/commands/chatui.js` command handler
- [x] Support `ani-code chatui` - Show current mode
- [x] Support `ani-code chatui simple` - Switch to simple mode
- [x] Support `ani-code chatui full` - Switch to full mode
- [x] Support `ani-code chatui default` - Reset to default (full)
- [x] Display confirmation message with current mode after switching

**Phase 3: Telegram Bot Command (2 hours)**
- [x] Add `/chatui` handler in Telegram bot command routing
- [x] Support `/chatui` - Show current mode for this chat
- [x] Support `/chatui simple` - Switch chat to simple mode
- [x] Support `/chatui full` - Switch chat to full mode
- [x] Support `/chatui default` - Reset to default
- [x] Send inline keyboard with mode options when no argument provided
- [x] Store mode preference per Telegram chat ID

**Phase 4: Notifier Formatting - Simple Mode (4 hours)**
- [x] Update `telegram-notifier-base.js`:
  - [x] Add `formatSimpleFooter()` - return minimal footer in simple mode (task ID only)
  - Add `formatSimpleTaskUpdateMessage()` - one-line format: `Task {id} started`
  - Add `formatSimpleTaskSummaryMessage()` - content + duration + task ID only
  - Create `formatSimpleTaskUpdate(task)` - one-line format: `Task {id} started`
  - Create `formatSimpleTaskSummary(task, output)` - content + duration + task ID
- [x] Update `telegram-notifier.js`:
  - Accept `displayMode` parameter on `sendTaskUpdate()` and `sendTaskSummary()`
  - Pass mode to base formatting methods (simple vs full)
  - Apply mode to `sendTaskUpdate()`, `sendTaskSummary()`, progress edit messages
- [x] Update `lark-notifier.js` with same mode-aware formatting
- [x] Update `dummy-telegram-notifier.js` with same mode-aware formatting

**Phase 5: Progress Message Formatting (2 hours)**
- [x] Update progress message editing logic in `http-server.js` / `task-monitor.js`
- [x] In simple mode: edit message with raw progress text only (no wrapper)
- [x] In full mode: keep existing progress formatting behavior
- [x] Ensure message edit (Telegram `editMessageText`) works correctly in both modes
- [x] Handle mode-specific truncation rules for progress text

**Phase 6: Structured Data Emission (2 hours)**
- [x] Add structured metadata to completion callbacks (for gateway consumers):
  - Include `displayMode` field in callback payload metadata
  - Include `taskName` / `taskId` as top-level structured fields
  - Include `contentOnly` field with just the result text (no formatting)
  - Include `duration` and `exitCode` as structured fields
- [x] Update gateway callback format in `task-monitor.js` `notifyGateway()` to include structured fields
- [x] Document structured data format for gateway consumers

**Phase 7: HTTP API Endpoint (1 hour)**
- [x] Add `GET /api/chatui` endpoint - returns current mode for a chat
- [x] Add `PATCH /api/chatui` endpoint - sets mode for a chat `{ chatId, mode }`
- [x] Add `GET /api/chatui/modes` endpoint - lists available modes
- [x] Validate mode parameter against allowed values
- [x] Follow existing API patterns from `http-server.js`

**Phase 8: Testing & Validation (3 hours)**
- [x] Write unit tests for `DisplayModeManager` class
- [x] Test mode persistence and retrieval
- [x] Test message formatting in each mode (full, simple)
- [x] Test CLI command argument parsing
- [x] Test Telegram bot command handling
- [x] Test API endpoints (GET, PATCH)
- [x] Test environment variable override behavior
- [x] Syntax validation of all modified files
- [x] Run existing test suite to verify no regressions

**Phase 9: Documentation (1 hour)**
- [x] Update CLAUDE.md with `/chatui` command documentation
- [x] Document display modes and their differences
- [x] Document `.env` configuration (`CHAT_DISPLAY_MODE`)
- [x] Document REST API endpoints
- [x] Add usage examples for CLI and Telegram

## Technical Specifications

### Display Mode Storage

**Per-chat storage** (in existing chat-settings system):
```javascript
// chat-settings.js - add displayMode field
{
  chatId: "telegram:123456",
  workspacePath: "/root/workspace/project",
  displayMode: "simple"  // NEW FIELD
}
```

**Global default** (environment variable):
```bash
# .env
CHAT_DISPLAY_MODE=full    # Global default: full | simple
```

**Priority chain**: Per-chat setting > `CHAT_DISPLAY_MODE` env var > `full`

### CLI Interface

```bash
# Show current mode
ani-code chatui
# Output: Current display mode: full

# Switch mode
ani-code chatui simple
# Output: Display mode set to: simple

ani-code chatui full
# Output: Display mode set to: full

# Reset to default
ani-code chatui default
# Output: Display mode reset to default: full
```

### Telegram Bot Commands

```
/chatui         → Shows current mode with inline keyboard to switch
/chatui simple  → Switches to simple mode
/chatui full    → Switches to full mode
/chatui default → Resets to default
```

### Message Format Comparison

**Full mode (current):**
```
✅ *Task Completed*

*Task ID:* ac-0210-xyz-B1234
*Duration:* 2m 34s

\`\`\`
[full task output here, up to 20 lines]
\`\`\`

📊 *Git Status:*
Branch: feature/xyz
+15 -3 across 2 files

💰 $0.0847 (claude-sonnet-4) • In: 12.5k (3.2k cached) • Out: 4.1k

🖥 my-host • ⏰ 14:32 • 📁 /workspace/project • 🤖 claude
```

**Simple mode:**
```
[full task output here, up to 20 lines]

✅ Done (2m 34s) • ac-0210-B1234
```

### API Endpoints

**GET /api/chatui?chatId=telegram:123456**
```json
{
  "success": true,
  "chatId": "telegram:123456",
  "mode": "simple",
  "availableModes": ["full", "simple", "default"]
}
```

**PATCH /api/chatui**
```json
{
  "chatId": "telegram:123456",
  "mode": "simple"
}
```
Response:
```json
{
  "success": true,
  "chatId": "telegram:123456",
  "mode": "simple",
  "previousMode": "full"
}
```

### Gateway Callback Structured Data

When `displayMode` is set, completion callbacks include additional structured fields:

```json
{
  "taskId": "ac-0210-xyz-B1234",
  "status": "completed",
  "progress": 100,
  "output": "formatted output per display mode",
  "metadata": {
    "model": "claude-sonnet-4",
    "displayMode": "simple",
    "duration": 154000,
    "hasImages": false
  },
  "structured": {
    "taskId": "ac-0210-xyz-B1234",
    "taskName": "implement feature X",
    "contentOnly": "raw result text without any formatting",
    "footer": "my-host • 14:32 • /workspace/project • claude",
    "duration": "2m 34s",
    "exitCode": 0
  }
}
```

## Acceptance Criteria

### Functional Requirements
- `/chatui` command (CLI and Telegram) switches between display modes
- `simple` mode shows only task output + brief completion line
- `full` mode preserves all current formatting behavior (no regressions)
- Mode preference persists per chat across sessions
- `CHAT_DISPLAY_MODE` env var sets global default
- Per-chat setting overrides env var
- Gateway callbacks include structured data fields regardless of mode

### Quality Requirements
- No regressions in existing full-mode message formatting
- Simple mode messages remain readable and informative
- All unit tests pass with > 80% coverage for new code
- Existing test suite passes without regressions
- Mode switching is instantaneous (no restart required)

### Integration Requirements
- Works with Telegram, Lark, and gateway message routing
- Compatible with all CLI providers (Claude, Copilot, OpenCode, etc.)
- API endpoints follow existing patterns from `api-handlers.js`
- Structured callback data is backward-compatible (additive fields only)

## Progress
- Status: **Complete** (100%)
- Start Date: 2026-02-10
- Completion Date: 2026-02-10
- Notes:
  - No conflicts with existing goals 001-010
  - Integrates at the notification/formatting layer, orthogonal to task execution
  - Per-chat storage leverages existing `chat-settings.js` infrastructure
  - Backward compatible - default mode is `full` (current behavior)
  - **Phase 1-7 complete**: Core implementation done, all files pass syntax validation
  - **Phase 8 complete**: All unit tests written and verified passing:
    - `tests/display-mode.test.js` - DisplayModeManager class tests (30 tests passing)
    - `tests/display-mode-formatting.test.js` - Simple mode formatting tests (21 tests passing)
    - `tests/chat-settings.test.js` - Chat settings with displayMode tests (updated, all passing)
    - `tests/chatui-cli.test.js` - CLI command argument parsing tests (15 tests passing)
    - `tests/chatui-telegram.test.js` - Telegram bot /chatui command handling tests (18 tests passing)
    - `tests/chatui-api.test.js` - REST API endpoint tests (GET, PATCH, modes) (27 tests passing)
  - **Phase 9 complete**: CLAUDE.md updated with comprehensive /chatui documentation
  - All 9 phases complete, all tests passing, no regressions
  - Files modified: `display-mode.js` (new), `chat-settings.js`, `commands/chatui.js` (new), `telegram-notifier-base.js`, `telegram-notifier.js`, `lark-notifier.js`, `dummy-telegram-notifier.js`, `task-monitor.js`, `http-server.js`, `index.js`, `CLAUDE.md`

## Dependencies

### Internal Dependencies
- `src/telegram-notifier-base.js` - Base formatting methods to make mode-aware
- `src/telegram-notifier.js` - Full notifier needs mode parameter threading
- `src/lark-notifier.js` - Lark notifier needs mode parameter threading
- `src/chat-settings.js` - Storage for per-chat display mode preference
- `src/task-monitor.js` - Gateway callback structured data emission
- `src/http-server.js` - Progress message formatting
- `src/api-handlers.js` - New API endpoint registration

### External Dependencies
- None (uses existing infrastructure)

### Related Goals
- Goal 001 (HTTP Endpoints): Uses same API patterns
- Gateway Message Callback: Display modes applied before message routing

### Blocking Dependencies
- None (standalone feature, additive only)

## Version Compatibility

**Version Impact**: This is a **MINOR** version update
- Adds new feature (`/chatui` command and display modes)
- Backward compatible with existing functionality
- Default behavior unchanged (`full` mode)
- No breaking changes to existing APIs (additive structured fields only)

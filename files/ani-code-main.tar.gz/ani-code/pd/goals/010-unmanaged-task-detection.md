# Goal: Unmanaged Task Detection from .claude JSONL Files

## Objective
Implement a daemon feature that monitors the `.claude/projects/` folder for new JSONL session files that are **not** associated with any currently tracked ani-code task. When an unmanaged JSONL file is detected (e.g., a user ran `claude` directly outside ani-code), the daemon logs the discovery. Optionally (disabled by default), once the file stabilizes (no writes for a configurable period), the daemon can insert a summary record into the corresponding project's stats DB.

This addresses a visibility gap: when developers use Claude Code directly (not through ani-code), those sessions are invisible to the project's usage tracking and cost reporting. Detecting these "unmanaged" sessions enables better audit trails and usage accounting.

**Priority**: Low
**Related Goals**: Goal 001 (Gateway Integration - task lifecycle), Goal 004 (Project Discovery - project registry), Goal 005 (Multi-Provider Token Tracking - stats DB)

## Tasks

### Phase 1: JSONL Folder Watcher (4 hours)
- [x] Create `src/unmanaged-task-watcher.js` module
- [x] Use `fs.watch` or polling-based approach to monitor `~/.claude/projects/` for new `.jsonl` files
- [x] Track known JSONL files associated with active/completed ani-code tasks (cross-reference with `ClaudeHistoryViewer.findLatestSession()` and task-queue task IDs)
- [x] Detect new JSONL files that don't match any known task
- [x] Decode project path from folder name (reverse of `-root-workspace-project` → `/root/workspace/project`)
- [x] Filter out `agent-*.jsonl` sub-session files (already excluded in history viewer)
- [x] Configurable scan interval (default: 60 seconds) via `UNMANAGED_TASK_SCAN_INTERVAL_MS`

### Phase 2: File Stability Detection (2 hours)
- [x] Track file mtime for detected unmanaged JSONL files
- [x] Consider a file "completed" when mtime hasn't changed for configurable duration (default: 5 minutes)
- [x] Use `UNMANAGED_TASK_SETTLE_TIME_MS` env var for settle duration
- [x] Maintain an in-memory map of detected files with their last-seen mtime

### Phase 3: Logging & Notification (2 hours)
- [x] Log discovery of unmanaged JSONL files with project path, filename, and file size
- [x] Log format: `[UNMANAGED] Detected unmanaged Claude session: {filename} for project {projectPath}`
- [x] Log when file stabilizes: `[UNMANAGED] Session stabilized (no writes for {settleTime}): {filename}`
- [x] Include basic session metadata in log (file size, creation time, line count if feasible)
- [x] Respect existing daemon log infrastructure (use same logger/format)

### Phase 4: Optional Stats DB Insertion (3 hours)
- [x] Add `UNMANAGED_TASK_INSERT_STATS` env var (default: `false`)
- [x] When enabled and file stabilizes, parse JSONL to extract basic metrics:
  - Approximate token usage from conversation length
  - Session duration (first line timestamp to last line timestamp)
  - Model used (if available in session metadata)
- [x] Insert record into stats DB via `StatsDB.recordTaskCreation()` + `recordTaskCompletion()` with source marker `unmanaged`
- [x] Use project path from folder name to determine workspace
- [x] Generate synthetic task ID with `unmanaged-` prefix to distinguish from real tasks
- [x] Cross-reference with project registry (Goal 004) to resolve project name if available

### Phase 5: Feature Toggle & Configuration (1 hour)
- [x] Add `UNMANAGED_TASK_DETECTION_ENABLED` env var (default: `false` - entire feature disabled by default)
- [x] Add `UNMANAGED_TASK_INSERT_STATS` env var (default: `false` - stats insertion disabled even when detection enabled)
- [x] Add `UNMANAGED_TASK_SCAN_INTERVAL_MS` env var (default: `60000`)
- [x] Add `UNMANAGED_TASK_SETTLE_TIME_MS` env var (default: `300000` / 5 minutes)
- [x] Document all env vars in CLAUDE.md
- [x] Log feature status on daemon startup: enabled/disabled and configuration values

### Phase 6: Integration with Daemon Lifecycle (2 hours)
- [x] Initialize watcher in `src/http-server.js` or `src/daemon-runner.js` during startup (only when enabled)
- [x] Register known task JSONL files from active tasks in task-queue on startup
- [x] Clean up watcher on daemon shutdown
- [x] Handle edge cases: file deleted mid-scan, permission errors, symlinks
- [x] Ensure watcher does not interfere with existing task monitoring

### Phase 7: Testing (3 hours)
- [x] Unit tests for path decoding (folder name → project path)
- [x] Unit tests for file stability detection logic
- [x] Unit tests for filtering known vs unmanaged JSONL files
- [x] Integration test: create a JSONL file outside ani-code and verify detection log
- [x] Test that feature is fully inactive when `UNMANAGED_TASK_DETECTION_ENABLED=false`
- [x] Test stats insertion when both flags enabled

## Acceptance Criteria

### Functional Requirements
- Daemon detects new JSONL files in `~/.claude/projects/` not linked to any ani-code task
- Detection logged with project path and filename
- Feature is completely disabled by default (no filesystem watching unless explicitly enabled)
- When stats insertion enabled, stabilized sessions appear in stats DB with `unmanaged` source marker
- Known ani-code task sessions are never flagged as unmanaged

### Quality Requirements
- Watcher has minimal performance impact (polling, not recursive inotify on large trees)
- No false positives for agent sub-sessions (`agent-*.jsonl`)
- No false positives for active task sessions
- Graceful handling of permission errors and missing directories
- Unit tests cover core detection logic

### Configuration Requirements
- All behavior controlled via environment variables
- Feature fully off by default (both detection and insertion)
- Scan interval and settle time are configurable
- Startup log clearly indicates feature status

## Progress
- Status: **Complete**
- Start Date: 2026-02-09
- Completion Date: 2026-02-09
- Completion: 100%
- Notes:
  - This is a low-priority observability feature
  - Core detection (logging) and stats insertion are independently toggleable
  - Built on existing infrastructure: ClaudeHistoryViewer for path encoding, StatsDB for storage, project registry for project resolution
  - **2026-02-09**: Implemented all core phases (1-7):
    - Created `src/unmanaged-task-watcher.js` with full polling-based detection, stability tracking, logging, and optional stats insertion
    - Integrated with daemon lifecycle in `src/daemon.js` (init in start(), cleanup in shutdown())
    - Added config entries in `src/config.js` under `unmanagedTaskDetection`
    - Created comprehensive test suite in `tests/unmanaged-task-watcher.test.js` (25 tests covering config, path decoding, start/stop, managed file registration, active task association, stability detection, folder scanning, stats insertion, and metrics parsing)
    - Used `prompt_preview` field with `unmanaged:` prefix for source marking (matching existing `shell:` pattern, no schema migration needed)
  - **2026-02-09 (iteration 2)**: Completed all remaining tasks:
    - Added project registry cross-reference via `_resolveProjectName()` method importing `loadRegistry` from `src/commands/projects.js`
    - Detection logs and stats records now include project name when registry is available
    - Documented all env vars (`UNMANAGED_TASK_DETECTION_ENABLED`, `UNMANAGED_TASK_INSERT_STATS`, `UNMANAGED_TASK_SCAN_INTERVAL_MS`, `UNMANAGED_TASK_SETTLE_TIME_MS`) in CLAUDE.md under "Unmanaged Task Detection" section
    - Added integration test exercising full scan pipeline: detection → stabilization → stats insertion with metrics parsing
    - Added project registry cross-reference tests (5 tests: root project, fallback, null registry, empty registry, error handling)
    - Added `getStatus()` test for projectName field inclusion
    - All 44 tests pass (`npm test -- tests/unmanaged-task-watcher.test.js`)

## Dependencies

### Internal Dependencies
- `src/claude-history-viewer.js` - Path encoding logic and JSONL discovery patterns
- `src/stats-db.js` - Stats insertion (Goal 005 infrastructure)
- `src/task-queue.js` - Active task list for cross-referencing
- `.ani-code/projects/registry.json` - Project name resolution (Goal 004)

### External Dependencies
- Node.js `fs` module (watch/stat)
- `~/.claude/projects/` directory structure (Claude Code convention)

### Related Goals
- Goal 001 (HTTP Endpoints): Task lifecycle patterns and gateway integration
- Goal 004 (Project Discovery): Project registry for resolving project paths to names
- Goal 005 (Multi-Provider Token Tracking): Stats DB schema and recording methods

### Blocking Dependencies
- None (all required infrastructure already exists)

## Conflict Analysis
- **No conflicts** with existing goals detected
- Builds on completed infrastructure from Goals 001, 004, and 005
- Does not modify any existing task monitoring behavior
- Additive feature with independent toggle - zero impact when disabled
- Stats DB records use distinct `unmanaged` source marker to avoid confusion with real tasks

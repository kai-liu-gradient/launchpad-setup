# Goal: Healthcheck Command Infrastructure

## Objective
Implement a comprehensive `/healthcheck` command that automatically analyzes project health based on techstack detection (starting with Node.js/npm). The command generates structured health reports in both HTML and JSON formats, enabling both human review and programmatic access to project health status.

This feature provides developers with actionable insights about their project's health, including security vulnerabilities (npm audit), dependency status, and code quality metrics. The modular preset system allows easy extension to support additional techstacks (Python, Go, Rust, etc.) in the future.

**Priority**: Medium
**Estimated Effort**: 2-3 days (20 hours)

## Tasks

### Phase 1: Command Infrastructure (6 hours)
- [x] Create `src/commands/healthcheck.js` with Commander.js command structure
- [x] Implement `healthcheck auto` subcommand as default mode
- [x] Add `--stack <techstack>` option to specify single techstack (node, python, etc.)
- [x] Add `--output <format>` option (json, html, all - default: all)
- [x] Add `--workspace <path>` option to specify target directory
- [x] Register healthcheck command in `src/index.js`
- [x] Implement project structure detection (package.json for Node, requirements.txt for Python, etc.)

### Phase 2: Output Directory Setup (2 hours)
- [x] Create `.ani-code/healthcheck/` output directory structure
- [x] Add `.ani-code/healthcheck/` to `.gitignore`
- [x] Implement timestamped filename generation (format: `healthcheck-YYYY-MM-DD-HHMMSS`)
- [x] Create output file writer utility with JSON and HTML support
- [x] Add cleanup command option `--cleanup <days>` to remove old reports

### Phase 3: Prompt-Based Analysis (6 hours)
- [x] Create healthcheck prompt template in `src/presets/healthcheck/` folder
- [x] Define JSON output schema version (v1.0.0) for structured reports
- [x] Implement task submission to daemon for Claude-based analysis
- [x] Parse and validate Claude's JSON response against schema
- [x] Handle analysis timeouts and errors gracefully
- [x] Add `--dry-run` flag to preview commands without execution

### Phase 4: Node.js/npm Support (4 hours)
- [x] Implement `npm audit --json` execution and parsing
- [x] Implement `npm outdated --json` for dependency status
- [x] Detect and report package-lock.json presence
- [x] Check for common configuration files (.npmrc, .nvmrc, engines field)
- [x] Aggregate npm-specific metrics into report structure

### Phase 5: Report Generation (4 hours)
- [x] Implement JSON report structure with version, timestamp, summary
- [x] Create HTML template with Bootstrap/Tailwind for readable reports
- [x] Add severity-based color coding (critical, high, medium, low)
- [x] Include actionable fix suggestions in reports
- [x] Generate summary section with pass/fail counts and overall health score

### Phase 6: Testing & Documentation (4 hours)
- [x] Write unit tests for healthcheck command structure
- [x] Test npm audit parsing with various vulnerability scenarios
- [x] Test output file generation (JSON and HTML)
- [x] Add healthcheck documentation to CLAUDE.md
- [x] Create example reports for documentation

## Acceptance Criteria

### Functional Requirements
- `ani-code healthcheck auto` detects project techstack and runs appropriate audits
- `ani-code healthcheck --stack node` runs Node.js-specific health checks
- Reports generated in `.ani-code/healthcheck/` with timestamped filenames
- JSON output follows versioned schema (v1.0.0) for programmatic access
- HTML output is human-readable with color-coded severity levels
- Command exits with non-zero code when critical vulnerabilities found

### Quality Requirements
- All unit tests pass
- Reports accurately reflect npm audit output
- HTML reports render correctly in modern browsers
- JSON reports validate against defined schema
- Command completes within reasonable timeout (60 seconds for audit)

### Integration Requirements
- Healthcheck output directory ignored by git
- Command integrates with daemon task system for Claude analysis
- Presets stored in `src/presets/healthcheck/` for maintainability

## Technical Specifications

### Command Structure
```bash
# Auto-detect and run all applicable healthchecks
ani-code healthcheck auto

# Specify single techstack
ani-code healthcheck --stack node

# Custom output format
ani-code healthcheck auto --output json

# Specify workspace
ani-code healthcheck auto --workspace /path/to/project

# Cleanup old reports
ani-code healthcheck --cleanup 30

# Dry run to preview
ani-code healthcheck auto --dry-run
```

### JSON Output Schema (v1.0.0)
```json
{
  "version": "1.0.0",
  "timestamp": "2025-01-05T10:00:00Z",
  "lastUpdate": "2025-01-05T10:00:00Z",
  "projectPath": "/path/to/project",
  "detectedStacks": ["node"],
  "summary": {
    "healthScore": 85,
    "status": "warning",
    "totalIssues": 10,
    "critical": 0,
    "high": 2,
    "medium": 5,
    "low": 3
  },
  "stacks": {
    "node": {
      "audit": {
        "vulnerabilities": [...],
        "metadata": {...}
      },
      "dependencies": {
        "outdated": [...],
        "total": 150,
        "upToDate": 140
      },
      "config": {
        "hasLockFile": true,
        "nodeVersion": "18.x",
        "enginesDefined": true
      }
    }
  },
  "recommendations": [
    {
      "priority": "high",
      "action": "Run npm audit fix",
      "reason": "2 high severity vulnerabilities found"
    }
  ]
}
```

### Directory Structure
```
.ani-code/
├── healthcheck/
│   ├── healthcheck-2025-01-05-100000.json
│   ├── healthcheck-2025-01-05-100000.html
│   └── ...
├── logs/
└── prompts/
```

## Progress
- Status: **COMPLETE**
- Start Date: 2026-01-05
- Completion Date: 2026-01-05
- Notes:
  - Phase 1 (Command Infrastructure): COMPLETE - Created healthcheck.js with Commander.js, implemented all options
  - Phase 2 (Output Directory Setup): COMPLETE - Implemented directory creation, timestamped filenames, cleanup
  - Phase 3 (Prompt-Based Analysis): COMPLETE - Created prompt templates (node.md, auto.md), implemented Claude task submission, JSON parsing/validation, error handling
  - Phase 4 (Node.js/npm Support): COMPLETE - npm audit/outdated parsing, config detection all working
  - Phase 5 (Report Generation): COMPLETE - JSON and HTML reports with color-coded severity levels
  - Phase 6 (Testing & Documentation): COMPLETE - 47 unit tests passing, CLAUDE.md documentation added
  - Example reports created in pd/examples/healthcheck/ (JSON and HTML)
  - Additional techstacks (Python, Go, Rust) will be added in follow-up goals
  - Claude analysis provides intelligent recommendations beyond raw audit data via --analyze flag
  - New files created: src/presets/healthcheck/node.md, src/presets/healthcheck/auto.md, tests/healthcheck.test.js, pd/examples/healthcheck/example-report.json, pd/examples/healthcheck/example-report.html

## Dependencies

### Internal Dependencies
- `src/daemon-client.js` - For task submission to Claude
- `src/presets/` - For healthcheck prompt templates
- `src/config.js` - For configuration options

### External Dependencies
- npm CLI (for npm audit, npm outdated commands)
- Node.js built-in fs/path modules

### Related Goals
- Goal 003: Healthcheck Presets and Templates (must be completed for full functionality)

## Version Compatibility

**Version Impact**: This is a **MINOR** version update
- Adding new feature without breaking existing functionality
- New command does not affect existing commands
- Backward compatible

## Files to Create/Modify

**New Files**:
- `src/commands/healthcheck.js` - Main command implementation
- `src/presets/healthcheck/node.md` - Node.js healthcheck prompt template
- `src/presets/healthcheck/auto.md` - Auto-detection prompt template
- `tests/healthcheck.test.js` - Unit tests

**Modified Files**:
- `src/index.js` - Register healthcheck command
- `.gitignore` - Add `.ani-code/healthcheck/` entry
- `CLAUDE.md` - Add healthcheck documentation

# Lark Notification Enhancements - 2025-08-20

## Overview
Enhanced Lark notifications to include detailed task information matching the CLI status command output.

## Changes Made

### 1. Task Start Notifications
**File**: `src/lark-notifier.js:94-147`

Now includes:
- **Task ID**: Full UUID for task identification
- **PID**: Process ID when available (after spawn)
- **Prompt**: Full or truncated command/prompt text
- **Working Directory**: In footer

### 2. Task Completion Notifications  
**File**: `src/lark-notifier.js:216-233`

Now includes:
- **Task ID**: Full UUID for reference
- **Duration**: Task execution time
- **PID**: Process ID if it was captured
- **Exit Code**: For failed tasks
- **Output**: Last 20 lines of output
- **Error**: Error message if failed

### 3. Process ID Updates
**Files**: 
- `src/task-queue.js:244-263` - Emit update when PID available
- `src/task-monitor.js:32-40` - Handle PID update event

The system now:
1. Captures PID when process spawns
2. Emits a `taskUpdated` event with PID
3. Sends an updated Lark notification with PID info

## Example Notification Format

### Task Started
```
🚀 Task Started - project-task-1234
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Task ID: abc123-def456-789012
PID: 45678
Prompt:
You are a git commit message generator...

---
🖥️ hostname • ⏰ 15:34 • 📁 project
```

### Task Completed
```
✅ Task Completed - project-task-1234
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Task ID: abc123-def456-789012
Duration: 45s
PID: 45678

[Task output here...]

💰 $0.0234 • 🔤 15.2k
📅 today: $1.45 • 45.6k, month: $23.67 • 1.2m

---
🖥️ hostname • ⏰ 15:35 • 📁 project
```

## Benefits
1. **Better Tracking**: Task ID allows correlation between CLI and Lark
2. **Process Monitoring**: PID enables system-level debugging
3. **Clear Context**: All relevant info in one notification
4. **Consistent Format**: Matches CLI status command output

## Technical Implementation
- Task object enriched with PID on process spawn
- Event-driven updates when process info becomes available
- Structured message format with clear sections
- Automatic truncation for long prompts/outputs
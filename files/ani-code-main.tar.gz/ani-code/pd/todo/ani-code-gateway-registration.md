# TODO: Implement Gateway Registration in ani-code

## Context

The ani-code-gateway has dynamic instance registration built-in. When ani-code instances run in K8s pods, they need to register with the gateway at startup so the gateway can route tasks to them.

**⚠️ IMPORTANT: Backward Compatibility**
- This feature is **100% optional and backward compatible**
- ani-code continues to work standalone (current behavior)
- Gateway registration ONLY happens when `GATEWAY_URL` env var is set
- If gateway is unavailable, ani-code continues in standalone mode
- No breaking changes to existing usage

## Current Gateway API

Gateway already provides registration endpoints:

```bash
# Register instance
POST http://localhost:6555/registry/instance
Headers: x-api-key: dev-key-1
Body: {
  "url": "http://pod-ip:8080",
  "metadata": {
    "projectId": "proj-123",
    "workspaceId": "ws-456",
    "podName": "ani-code-proj-123"
  }
}

# Deregister instance
DELETE http://localhost:6555/registry/instance/{instance-id}
Headers: x-api-key: dev-key-1
```

## Required Implementation in ani-code

### 1. Add Optional Gateway Registration on Startup

**File**: `src/server.js` or new `src/gateway-client.js`

**IMPORTANT: Gateway registration is OPTIONAL**
- If `GATEWAY_URL` is not set, skip registration entirely
- ani-code should work standalone without any gateway
- Only register when running in K8s pod environment

**Implement:**
- Check if gateway URL from env exists: `GATEWAY_URL`
- If exists, read gateway API key from env: `GATEWAY_API_KEY`
- Read pod metadata from env: `PROJECT_ID`, `WORKSPACE_ID`, `POD_NAME`
- On server start, attempt registration (with error handling)
- Store instance ID if registration succeeds
- Implement graceful shutdown handler to deregister

**Pseudo-code:**
```javascript
let registeredWithGateway = false;
let instanceId = null;

const registerWithGateway = async () => {
  const gatewayUrl = process.env.GATEWAY_URL;

  // Skip if no gateway configured
  if (!gatewayUrl) {
    console.log('No GATEWAY_URL configured, running in standalone mode');
    return null;
  }

  const apiKey = process.env.GATEWAY_API_KEY;
  const myUrl = `http://${POD_IP}:${PORT}`;

  try {
    const response = await axios.post(`${gatewayUrl}/registry/instance`, {
      url: myUrl,
      metadata: {
        projectId: process.env.PROJECT_ID,
        workspaceId: process.env.WORKSPACE_ID,
        podName: process.env.POD_NAME
      }
    }, {
      headers: { 'x-api-key': apiKey },
      timeout: 5000  // 5 second timeout
    });

    console.log('Registered with gateway:', response.data.id);
    registeredWithGateway = true;
    return response.data.id;
  } catch (error) {
    console.warn('Failed to register with gateway (continuing in standalone mode):', error.message);
    return null;
  }
};

const deregisterFromGateway = async (instanceId) => {
  if (!registeredWithGateway || !instanceId) {
    return;  // Not registered, nothing to do
  }

  const gatewayUrl = process.env.GATEWAY_URL;
  const apiKey = process.env.GATEWAY_API_KEY;

  try {
    await axios.delete(`${gatewayUrl}/registry/instance/${instanceId}`, {
      headers: { 'x-api-key': apiKey },
      timeout: 3000
    });
    console.log('Deregistered from gateway');
  } catch (error) {
    console.warn('Failed to deregister from gateway:', error.message);
    // Continue shutdown anyway
  }
};

// On startup (non-blocking)
registerWithGateway()
  .then(id => { instanceId = id; })
  .catch(err => console.warn('Gateway registration failed:', err));

// On shutdown
process.on('SIGTERM', async () => {
  if (instanceId) {
    await deregisterFromGateway(instanceId);
  }
  process.exit(0);
});

process.on('SIGINT', async () => {
  if (instanceId) {
    await deregisterFromGateway(instanceId);
  }
  process.exit(0);
});
```

### 2. Add Health Check Endpoint

Gateway will health-check registered instances. Ensure ani-code has:

```javascript
app.get('/health', (req, res) => {
  res.json({ status: 'ok', ready: true });
});
```

### 3. Add Heartbeat (Optional)

Update lastSeen by calling registration endpoint periodically:

```javascript
setInterval(async () => {
  await registerWithGateway(); // Re-registration updates lastSeen
}, 30000); // Every 30 seconds
```

## Environment Variables (Optional)

**These are ONLY needed when running in K8s pod mode:**

Add to ani-code's `.env` (or set in K8s pod spec):
```env
# Gateway integration (optional - leave empty for standalone mode)
GATEWAY_URL=http://localhost:6555
GATEWAY_API_KEY=dev-key-1

# Pod metadata (only in K8s environment)
PROJECT_ID=
WORKSPACE_ID=
POD_NAME=
```

**Default behavior (no env vars):**
- ani-code runs in standalone mode
- No gateway registration attempted
- Works exactly as before

## Testing

### Test 1: Standalone Mode (Default)
```bash
# Start ani-code WITHOUT gateway env vars
npm start

# Expected output:
# "No GATEWAY_URL configured, running in standalone mode"

# Verify it works normally
curl http://localhost:8080/health
```

### Test 2: Gateway Mode
```bash
# Start ani-code with gateway env vars
GATEWAY_URL=http://localhost:6555 \
GATEWAY_API_KEY=dev-key-1 \
PROJECT_ID=test-proj \
WORKSPACE_ID=test-ws \
POD_NAME=test-pod \
npm start

# Expected output:
# "Registered with gateway: <instance-id>"

# Check if registered
curl -H "x-api-key: dev-key-1" http://localhost:6555/registry/instances | jq

# Stop ani-code (Ctrl+C), verify deregistration
# Expected output:
# "Deregistered from gateway"
```

### Test 3: Gateway Unavailable (Graceful Fallback)
```bash
# Start with gateway URL but gateway not running
GATEWAY_URL=http://localhost:9999 \
GATEWAY_API_KEY=dev-key-1 \
npm start

# Expected output:
# "Failed to register with gateway (continuing in standalone mode): ..."

# Verify ani-code still works
curl http://localhost:8080/health
```

## Acceptance Criteria

- [ ] ani-code works in standalone mode (no env vars) - **CRITICAL**
- [ ] ani-code registers with gateway when GATEWAY_URL is set
- [ ] Registration includes pod metadata (projectId, workspaceId)
- [ ] Health check endpoint available at `/health`
- [ ] Graceful shutdown deregisters from gateway
- [ ] Works in both local and K8s environments
- [ ] Handles gateway unavailability gracefully (no crash, continues running)
- [ ] Registration is non-blocking (doesn't delay startup)
- [ ] No changes to existing standalone behavior

## Notes

- Gateway auto-cleans stale instances after 1 hour
- Gateway connection pool integrates registered instances automatically
- Use existing gateway at http://localhost:6555 (running as systemd service)

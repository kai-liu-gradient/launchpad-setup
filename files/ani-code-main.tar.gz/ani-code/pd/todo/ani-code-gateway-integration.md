# Ani-Code Gateway Integration Implementation Plan

## Problem Statement

When users create workspace tokens in ani-code CLI (`ani-code workspace token gen`), the gateway has no knowledge of:
1. Which workspace token was created
2. Which ani-code instance (hostname) owns that token
3. How to route requests for that token

This breaks the multi-instance routing feature of ani-code-gateway.

## Solution: Optional Gateway Registration

Add **optional** gateway registration to ani-code that:
- ✅ Works standalone (no gateway) - existing behavior unchanged
- ✅ Auto-registers with gateway when configured
- ✅ No breaking changes to existing deployments
- ✅ Backward compatible with all existing features

---

## Implementation Tasks

### Task 1: Add Gateway Configuration

**File**: `.env.example` (and user's `.env`)

**Add these optional variables**:
```env
# Optional: Gateway integration (leave empty for standalone mode)
GATEWAY_URL=
ANI_CODE_URL=

# Example for gateway mode:
# GATEWAY_URL=http://localhost:6555
# ANI_CODE_URL=http://localhost:3000
```

**Behavior**:
- If `GATEWAY_URL` is empty → standalone mode (current behavior)
- If `GATEWAY_URL` is set → auto-register with gateway

---

### Task 2: Create Gateway Registration Service

**File**: `src/services/gatewayRegistration.js` (NEW FILE)

```javascript
import axios from 'axios';
import { logger } from '../logger.js';

/**
 * Gateway Registration Service
 * Handles optional registration with ani-code-gateway
 */
class GatewayRegistrationService {
  constructor() {
    this.gatewayUrl = process.env.GATEWAY_URL;
    this.aniCodeUrl = process.env.ANI_CODE_URL || 'http://localhost:3000';
    this.enabled = !!this.gatewayUrl;
  }

  /**
   * Check if gateway integration is enabled
   */
  isEnabled() {
    return this.enabled;
  }

  /**
   * Register workspace token with gateway
   * @param {string} workspaceToken - The workspace token to register
   * @param {string} workspaceName - Name of the workspace
   * @param {object} metadata - Additional metadata
   * @returns {Promise<object|null>} Gateway response or null if disabled
   */
  async registerToken(workspaceToken, workspaceName, metadata = {}) {
    if (!this.enabled) {
      logger.debug('Gateway integration disabled, skipping token registration');
      return null;
    }

    try {
      const response = await axios.post(
        `${this.gatewayUrl}/api/tokens/register`,
        {
          instanceUrl: this.aniCodeUrl,
          workspaceToken: workspaceToken,
          projectName: workspaceName,
          description: metadata.description || '',
          owner: metadata.owner || ''
        },
        {
          timeout: 5000,
          headers: {
            'Content-Type': 'application/json',
            'X-API-Key': process.env.GATEWAY_API_KEY || ''
          }
        }
      );

      logger.info('Token registered with gateway', {
        workspaceName,
        gatewayToken: response.data.gatewayToken?.substring(0, 8) + '...'
      });

      return response.data;
    } catch (error) {
      logger.error('Failed to register token with gateway', {
        error: error.message,
        workspaceName
      });
      // Don't throw - gateway registration failure shouldn't break token creation
      return null;
    }
  }

  /**
   * Send heartbeat to gateway
   * Updates last_seen timestamp for this instance
   */
  async sendHeartbeat() {
    if (!this.enabled) {
      return;
    }

    try {
      await axios.post(
        `${this.gatewayUrl}/api/registry/instance`,
        {
          url: this.aniCodeUrl,
          metadata: {
            version: '1.0.0',
            capabilities: ['telegram', 'lark', 'cli'],
            lastHeartbeat: new Date().toISOString()
          }
        },
        {
          timeout: 5000,
          headers: {
            'Content-Type': 'application/json',
            'X-API-Key': process.env.GATEWAY_API_KEY || ''
          }
        }
      );

      logger.debug('Heartbeat sent to gateway');
    } catch (error) {
      logger.debug('Heartbeat failed', { error: error.message });
      // Silently fail - heartbeat is not critical
    }
  }

  /**
   * Start periodic heartbeat
   */
  startHeartbeat() {
    if (!this.enabled) {
      return;
    }

    // Send initial heartbeat
    this.sendHeartbeat();

    // Send heartbeat every 30 seconds
    this.heartbeatInterval = setInterval(() => {
      this.sendHeartbeat();
    }, 30000);

    logger.info('Gateway heartbeat started', {
      gatewayUrl: this.gatewayUrl,
      aniCodeUrl: this.aniCodeUrl
    });
  }

  /**
   * Stop heartbeat
   */
  stopHeartbeat() {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
      logger.info('Gateway heartbeat stopped');
    }
  }
}

export const gatewayRegistration = new GatewayRegistrationService();
```

---

### Task 3: Integrate Gateway Registration in Workspace Command

**File**: `src/commands/workspace.js`

**Modify**: Line 181-193 (token generation section)

**Change from**:
```javascript
// Generate initial token
console.log(chalk.yellow('\nGenerating access token...'));
const tokenData = await manager.generateToken(
  workspace.id,
  'Initial token',
  'api',
  ['read', 'write'],
  null // No expiration
);

console.log(chalk.green('\n✓ Access token generated:'));
console.log(chalk.cyan(`  ${tokenData.token}`));
console.log(chalk.gray('\n  Save this token securely. It won\'t be shown again.'));
```

**Change to**:
```javascript
// Generate initial token
console.log(chalk.yellow('\nGenerating access token...'));
const tokenData = await manager.generateToken(
  workspace.id,
  'Initial token',
  'api',
  ['read', 'write'],
  null // No expiration
);

console.log(chalk.green('\n✓ Access token generated:'));
console.log(chalk.cyan(`  ${tokenData.token}`));
console.log(chalk.gray('\n  Save this token securely. It won\'t be shown again.'));

// Register with gateway if enabled
const { gatewayRegistration } = await import('../services/gatewayRegistration.js');
if (gatewayRegistration.isEnabled()) {
  console.log(chalk.yellow('\nRegistering with gateway...'));
  const gatewayResult = await gatewayRegistration.registerToken(
    tokenData.token,
    workspace.name,
    { description: options.description }
  );

  if (gatewayResult) {
    console.log(chalk.green('✓ Registered with gateway'));
    console.log(chalk.cyan(`  Gateway Token: ${gatewayResult.gatewayToken}`));
    console.log(chalk.gray('\n  Telegram users should use: /start ' + gatewayResult.gatewayToken));
  } else {
    console.log(chalk.yellow('⚠ Gateway registration failed (non-critical)'));
  }
}
```

**Also modify**: Line 467-486 (token generate command)

**Change from**:
```javascript
const tokenData = await manager.generateToken(
  workspace,
  options.name,
  options.type,
  permissions,
  expiresInDays
);

console.log(chalk.green('\n✓ Token generated successfully:'));
console.log(chalk.cyan(`  ${tokenData.token}`));
console.log(chalk.gray('\n  Token details:'));
console.log(chalk.gray(`    ID: ${tokenData.id}`));
console.log(chalk.gray(`    Workspace: ${tokenData.workspace_name}`));
console.log(chalk.gray(`    Type: ${tokenData.type}`));
console.log(chalk.gray(`    Permissions: ${tokenData.permissions.join(', ')}`));
if (tokenData.expires_at) {
  console.log(chalk.gray(`    Expires: ${formatDate(tokenData.expires_at)}`));
}
console.log(chalk.yellow('\n  Save this token securely. It won\'t be shown again.'));
```

**Change to**:
```javascript
const tokenData = await manager.generateToken(
  workspace,
  options.name,
  options.type,
  permissions,
  expiresInDays
);

console.log(chalk.green('\n✓ Token generated successfully:'));
console.log(chalk.cyan(`  ${tokenData.token}`));
console.log(chalk.gray('\n  Token details:'));
console.log(chalk.gray(`    ID: ${tokenData.id}`));
console.log(chalk.gray(`    Workspace: ${tokenData.workspace_name}`));
console.log(chalk.gray(`    Type: ${tokenData.type}`));
console.log(chalk.gray(`    Permissions: ${tokenData.permissions.join(', ')}`));
if (tokenData.expires_at) {
  console.log(chalk.gray(`    Expires: ${formatDate(tokenData.expires_at)}`));
}
console.log(chalk.yellow('\n  Save this token securely. It won\'t be shown again.'));

// Register with gateway if enabled
const { gatewayRegistration } = await import('../services/gatewayRegistration.js');
if (gatewayRegistration.isEnabled()) {
  console.log(chalk.yellow('\nRegistering with gateway...'));
  const gatewayResult = await gatewayRegistration.registerToken(
    tokenData.token,
    tokenData.workspace_name,
    {
      description: options.name,
      owner: options.type
    }
  );

  if (gatewayResult) {
    console.log(chalk.green('✓ Registered with gateway'));
    console.log(chalk.cyan(`  Gateway Token: ${gatewayResult.gatewayToken}`));
    console.log(chalk.gray('\n  For Telegram: /start ' + gatewayResult.gatewayToken));
    console.log(chalk.gray(`  Webhook URL: ${gatewayResult.webhookUrl}`));
  } else {
    console.log(chalk.yellow('⚠ Gateway registration failed (non-critical)'));
    console.log(chalk.gray('  Token is still valid for direct connections'));
  }
}
```

---

### Task 4: Start Heartbeat on Daemon Start

**File**: `src/daemon.js` or `src/index.js` (wherever server starts)

**Add at server startup**:
```javascript
import { gatewayRegistration } from './services/gatewayRegistration.js';

// Existing server startup code...

// Start gateway heartbeat if enabled
if (gatewayRegistration.isEnabled()) {
  gatewayRegistration.startHeartbeat();

  // Cleanup on process exit
  process.on('SIGTERM', () => {
    gatewayRegistration.stopHeartbeat();
  });

  process.on('SIGINT', () => {
    gatewayRegistration.stopHeartbeat();
  });
}
```

---

### Task 5: Update Package Dependencies

**File**: `package.json`

**Verify axios is installed**:
```json
{
  "dependencies": {
    "axios": "^1.6.0"
  }
}
```

If not present, run: `npm install axios`

---

### Task 6: Add Gateway Configuration to README

**File**: `README.md`

**Add section**:
```markdown
## Gateway Integration (Optional)

Ani-code can optionally integrate with ani-code-gateway for multi-instance routing.

### Standalone Mode (Default)
No configuration needed. Ani-code works independently.

### Gateway Mode
Add to `.env`:
```env
GATEWAY_URL=http://localhost:6555
ANI_CODE_URL=http://localhost:3000
GATEWAY_API_KEY=your-api-key  # Optional, if gateway requires auth
```

When configured:
- Workspace tokens auto-register with gateway
- Gateway provides multi-user routing
- Heartbeat maintains instance health status
- Users connect via gateway tokens

### Usage
```bash
# Create workspace (auto-registers with gateway if configured)
ani-code workspace create my-project

# Gateway token will be displayed for Telegram/Lark users
Gateway Token: gw_abc123...
Telegram users: /start gw_abc123...
```
```

---

## Testing Checklist

### Standalone Mode (No Gateway)
- [ ] `ani-code workspace create` works without `GATEWAY_URL`
- [ ] `ani-code workspace token gen` works without `GATEWAY_URL`
- [ ] No errors or warnings about gateway
- [ ] All existing features work unchanged

### Gateway Mode (With Gateway)
- [ ] Set `GATEWAY_URL` and `ANI_CODE_URL` in `.env`
- [ ] `ani-code workspace create` auto-registers token
- [ ] Gateway token displayed in output
- [ ] `ani-code workspace token gen` auto-registers token
- [ ] Heartbeat starts on daemon start
- [ ] Gateway shows instance as healthy
- [ ] Telegram users can connect with gateway token

### Error Handling
- [ ] Gateway offline → token creation still works
- [ ] Gateway registration fails → warning shown, continues
- [ ] Invalid `GATEWAY_URL` → graceful failure
- [ ] Network timeout → non-blocking, logs error

---

## Rollback Plan

If issues occur:
1. Remove `GATEWAY_URL` from `.env`
2. Ani-code reverts to standalone mode
3. No data loss - all workspace tokens still valid locally

---

## Files to Modify

### New Files
- `src/services/gatewayRegistration.js` (NEW)

### Modified Files
- `.env.example` (add GATEWAY_URL, ANI_CODE_URL)
- `src/commands/workspace.js` (add gateway registration calls)
- `src/daemon.js` or `src/index.js` (start heartbeat)
- `README.md` (add gateway integration docs)
- `package.json` (verify axios dependency)

### No Changes Required
- All existing ani-code functionality
- Database schemas
- API endpoints
- Workspace management
- Token validation

---

## Benefits

✅ **Backward Compatible**: Existing deployments unaffected
✅ **Optional**: Users opt-in via environment variables
✅ **Non-Breaking**: Gateway failures don't break token creation
✅ **Simple**: Minimal code changes, clear separation of concerns
✅ **Maintainable**: Gateway logic isolated in one service file

---

## Future Enhancements

After basic integration works:
1. Store gateway token in workspace metadata
2. Show gateway connection status in `workspace info`
3. Add `workspace gateway status` command
4. Support gateway token refresh/rotation
5. Batch token registration for existing workspaces

# Gateway Message Callback Implementation Todo

## Overview
Step-by-step implementation plan for adding message callback functionality to ani-code-gateway to properly route responses from ani-code daemons back to original communication channels.

## Prerequisites
- [ ] Gateway has access to Telegram Bot Token (`TELEGRAM_BOT_TOKEN`)
- [ ] Gateway has access to Lark App credentials (`LARK_APP_ID`, `LARK_APP_SECRET`)
- [ ] Database migrations support in gateway
- [ ] API authentication middleware configured

## Implementation Tasks

### Phase 1: Database & Core Services [Priority: HIGH]

#### 1.1 Database Setup
- [ ] Create migration file `004_gateway_sessions.js`
  ```javascript
  // deps/ani-code-gateway/api/src/db/migrations/004_gateway_sessions.js
  - Create gateway_sessions table
  - Create message_history table
  - Add necessary indexes
  ```

#### 1.2 Session Manager Service
- [ ] Create `sessionManager.js` service
  ```javascript
  // deps/ani-code-gateway/api/src/services/sessionManager.js
  - createSession(platform, chatId, userId, workspaceToken)
  - getSession(gatewayToken)
  - updateSession(gatewayToken, data)
  - deleteSession(gatewayToken)
  - touchSession(gatewayToken) // Update last_activity
  - cleanupExpiredSessions()
  - generateSecureToken() // Generate gw_ prefixed tokens
  ```

#### 1.3 Message History Service
- [ ] Create `messageHistoryService.js`
  ```javascript
  // deps/ani-code-gateway/api/src/services/messageHistoryService.js
  - storeMessage(sessionId, direction, platform, chatId, messageData)
  - getMessageHistory(sessionId, limit)
  - cleanupOldMessages(retentionDays)
  ```

### Phase 2: Platform Handlers [Priority: HIGH]

#### 2.1 Telegram Handler
- [ ] Create `telegramHandler.js`
  ```javascript
  // deps/ani-code-gateway/api/src/handlers/telegramHandler.js
  - sendMessage(chatId, message)
  - editMessage(chatId, messageId, message)
  - deleteMessage(chatId, messageId)
  - sendWithKeyboard(chatId, text, keyboard)
  - answerCallbackQuery(callbackQueryId, text)
  ```

#### 2.2 Lark Handler
- [ ] Create `larkHandler.js`
  ```javascript
  // deps/ani-code-gateway/api/src/handlers/larkHandler.js
  - sendMessage(chatId, message)
  - sendCard(chatId, card)
  - updateCard(messageId, card)
  ```

#### 2.3 Platform Handler Factory
- [ ] Create `platformHandlerFactory.js`
  ```javascript
  // deps/ani-code-gateway/api/src/handlers/platformHandlerFactory.js
  - getHandler(platform)
  - registerHandler(platform, handler)
  - isSupported(platform)
  ```

### Phase 3: API Endpoints [Priority: HIGH]

#### 3.1 Message Callback Controller
- [ ] Create `messageCallbackController.js`
  ```javascript
  // deps/ani-code-gateway/api/src/controllers/messageCallbackController.js
  - handleMessageCallback(req, res)
  - validateGatewayToken(token)
  - routeMessage(session, message)
  ```

#### 3.2 Session Management Controller
- [ ] Create `sessionController.js`
  ```javascript
  // deps/ani-code-gateway/api/src/controllers/sessionController.js
  - getSession(req, res)
  - listSessions(req, res)
  - cleanupSessions(req, res)
  - getSessionStats(req, res)
  ```

#### 3.3 Routes Configuration
- [ ] Update `callback.js` routes
  ```javascript
  // deps/ani-code-gateway/api/src/routes/callback.js
  - POST /api/callback/message
  - GET /api/sessions/:token
  - GET /api/sessions
  - POST /api/sessions/cleanup
  ```

### Phase 4: Webhook Integration [Priority: HIGH]

#### 4.1 Update Telegram Webhook Handler
- [ ] Modify `telegramWebhookHandler.js`
  ```javascript
  // deps/ani-code-gateway/api/src/handlers/telegramWebhookHandler.js
  - Parse /start command with workspace token
  - Create session on /start
  - Store gateway token in session
  - Add x-gateway-token header when forwarding
  ```

#### 4.2 Update Lark Webhook Handler
- [ ] Modify `larkWebhookHandler.js`
  ```javascript
  // deps/ani-code-gateway/api/src/handlers/larkWebhookHandler.js
  - Create session on first interaction
  - Store gateway token in session
  - Add x-gateway-token header when forwarding
  ```

### Phase 5: Configuration & Environment [Priority: MEDIUM]

#### 5.1 Environment Variables
- [ ] Update `.env.example`
  ```bash
  # Platform Credentials
  TELEGRAM_BOT_TOKEN=
  LARK_APP_ID=
  LARK_APP_SECRET=

  # Session Configuration
  SESSION_TIMEOUT_MINUTES=60
  SESSION_CLEANUP_INTERVAL_MINUTES=10
  MESSAGE_HISTORY_ENABLED=true
  MESSAGE_HISTORY_RETENTION_DAYS=7
  ```

#### 5.2 Configuration Service Update
- [ ] Update `config.js`
  ```javascript
  - Add telegram bot configuration
  - Add lark app configuration
  - Add session management settings
  - Add message history settings
  ```

### Phase 6: Testing [Priority: HIGH]

#### 6.1 Unit Tests
- [ ] Test session manager
  ```javascript
  // deps/ani-code-gateway/api/tests/services/sessionManager.test.js
  - Test session creation
  - Test token generation
  - Test session expiry
  - Test cleanup
  ```

- [ ] Test platform handlers
  ```javascript
  // deps/ani-code-gateway/api/tests/handlers/telegramHandler.test.js
  - Test message sending
  - Test message editing
  - Test keyboard handling
  ```

#### 6.2 Integration Tests
- [ ] Test message callback flow
  ```javascript
  // deps/ani-code-gateway/api/tests/integration/messageCallback.test.js
  - Test end-to-end flow
  - Test token validation
  - Test platform routing
  ```

#### 6.3 Load Tests
- [ ] Create load test scenarios
  ```javascript
  // deps/ani-code-gateway/api/tests/load/callback-load-test.js
  - Test concurrent sessions
  - Test message throughput
  - Test database performance
  ```

### Phase 7: Monitoring & Metrics [Priority: MEDIUM]

#### 7.1 Metrics Collection
- [ ] Add callback metrics
  ```javascript
  // deps/ani-code-gateway/api/src/services/metricsCollector.js
  - Track message callback count
  - Track platform distribution
  - Track session metrics
  - Track error rates
  ```

#### 7.2 Health Checks
- [ ] Update health check endpoints
  ```javascript
  - Add session count to health status
  - Add platform handler status
  - Add database connectivity check
  ```

### Phase 8: Documentation [Priority: MEDIUM]

#### 8.1 API Documentation
- [ ] Create callback API documentation
  ```markdown
  // deps/ani-code-gateway/api/docs/message-callback-api.md
  - Endpoint specifications
  - Request/response formats
  - Error codes
  - Examples
  ```

#### 8.2 Integration Guide
- [ ] Create integration guide
  ```markdown
  // deps/ani-code-gateway/docs/callback-integration-guide.md
  - How to integrate from ani-code daemon
  - Session lifecycle
  - Best practices
  - Troubleshooting
  ```

### Phase 9: Deployment [Priority: LOW]

#### 9.1 Database Migration
- [ ] Run migration scripts
- [ ] Verify table creation
- [ ] Test rollback procedure

#### 9.2 Service Deployment
- [ ] Deploy updated gateway service
- [ ] Verify environment variables
- [ ] Test platform connections

#### 9.3 Monitoring Setup
- [ ] Configure alerts for callback failures
- [ ] Set up dashboard for session metrics
- [ ] Create runbook for common issues

## Testing Checklist

### Functional Testing
- [ ] Telegram message sending works
- [ ] Lark message sending works
- [ ] Session creation from /start command
- [ ] Token validation and routing
- [ ] Message history recording
- [ ] Session cleanup after timeout

### Error Scenarios
- [ ] Invalid gateway token handling
- [ ] Expired session handling
- [ ] Platform send failure recovery
- [ ] Database connection issues
- [ ] Rate limit handling

### Performance Testing
- [ ] 1000 concurrent sessions
- [ ] 100 messages/second throughput
- [ ] Database query optimization
- [ ] Memory usage monitoring

## Rollback Plan

1. **Database Rollback**
   ```sql
   DROP TABLE IF EXISTS message_history;
   DROP TABLE IF EXISTS gateway_sessions;
   ```

2. **Code Rollback**
   - Revert to previous gateway version
   - Restore original webhook handlers
   - Remove new endpoints

3. **Configuration Rollback**
   - Remove new environment variables
   - Restore original configuration

## Success Metrics

- [ ] Zero message loss during routing
- [ ] < 100ms message routing latency
- [ ] 99.9% success rate for message delivery
- [ ] Proper session cleanup (no memory leaks)
- [ ] All tests passing

## Notes for Implementation

### Security Considerations
1. Always validate gateway tokens before processing
2. Sanitize message content to prevent injection
3. Use HTTPS for all external API calls
4. Implement rate limiting on callback endpoint
5. Log all security-relevant events

### Performance Optimization
1. Use connection pooling for database
2. Implement caching for active sessions
3. Batch cleanup operations
4. Use async/await properly to avoid blocking

### Error Handling
1. Always return appropriate HTTP status codes
2. Log errors with context for debugging
3. Implement exponential backoff for retries
4. Provide meaningful error messages

### Monitoring
1. Track session lifecycle events
2. Monitor platform API response times
3. Alert on high error rates
4. Track token validation failures

## Implementation Order

1. **Week 1**: Database setup, core services, platform handlers
2. **Week 2**: API endpoints, webhook integration
3. **Week 3**: Testing, monitoring, documentation
4. **Week 4**: Deployment, monitoring, optimization

## Contact Points

- **Gateway Team**: For gateway-specific questions
- **Ani-Code Team**: For daemon integration questions
- **Platform Teams**: For Telegram/Lark API questions
- **DevOps**: For deployment and monitoring setup
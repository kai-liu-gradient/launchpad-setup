# Gateway Support for Telegram answerCallbackQuery

## Issue Summary
When using gateway mode, clicking inline keyboard buttons fails with error:
```
🔴 ERROR: [Gateway] Answer callback query failed with HTTP 400
Missing required fields: platform, chatId
```

## Root Causes
1. **Missing chatId parameter**: The gateway validates that `chatId` is present, but initial implementation sent `chatId: null`
2. **Missing gateway handler**: The gateway controller doesn't handle the `answerCallback` message type

## Changes Made in ani-code

### 1. Added Gateway Support in dummy-telegram-notifier.js
**File**: `src/dummy-telegram-notifier.js`

Added new method `answerCallbackQueryViaGateway()` that sends answerCallback requests through the gateway:

```javascript
async answerCallbackQueryViaGateway(chatId, callbackQueryId, options = {}) {
  const payload = {
    platform: 'telegram',
    chatId: String(chatId), // Gateway requires chatId for validation
    message: {
      type: 'answerCallback',
      callbackQueryId,
      ...options
    },
    instanceId: config.gateway.instanceId,
    timestamp: new Date().toISOString()
  };
  // ... sends to ${config.gateway.url}/api/callback/message
}
```

### 2. Updated http-server.js
**File**: `src/http-server.js`

- Added helper method `answerTelegramCallbackQuery(chatId, callbackId, options)` that automatically routes through gateway when enabled
- Updated both answerCallbackQuery calls to pass `chatId` as first parameter
- Removed direct Telegram API calls that were failing with `botundefined`

**Method signature (line 7335)**:
```javascript
async answerTelegramCallbackQuery(chatId, callbackId, options = {})
```

**Call sites updated (lines 7488, 7496)**:
```javascript
// Was: await this.answerTelegramCallbackQuery(callbackId, {...})
// Now: await this.answerTelegramCallbackQuery(chatId, callbackId, {...})
```

## Required Changes in ani-code-gateway

**IMPORTANT**: The following changes need to be made in the separate `ani-code-gateway` project.

### Update callbackController.js

**File**: `deps/ani-code-gateway/api/src/controllers/callbackController.js`

In the `handleMessage()` method, add support for the `answerCallback` action type:

```javascript
// Around line 244, after the 'delete' action handler:
} else if (action === 'answerCallback') {
  // Handle callback query answer
  const callbackQueryId = message.callbackQueryId;
  const text = message.text || '';
  const showAlert = message.show_alert || false;

  if (!callbackQueryId) {
    logger.error('AnswerCallback request missing callbackQueryId', {
      instanceId,
      message: JSON.stringify(message)
    });
    metricsCollector.recordCallback(platform, instanceId, Date.now() - startTime, false);
    return res.status(400).json({
      success: false,
      error: 'AnswerCallback request missing callbackQueryId'
    });
  }

  const result = await telegramService.answerCallbackQuery(callbackQueryId, text, showAlert);
  success = result.success;
  if (!result.success) {
    logger.error('Telegram answerCallback failed', {
      instanceId,
      callbackQueryId,
      error: result.error
    });
  }
} else {
  // Handle new message (existing code)
  ...
}
```

### Update telegramService.js (if needed)

**File**: `deps/ani-code-gateway/api/src/services/telegramService.js`

Ensure the service has an `answerCallbackQuery` method that wraps the handler:

```javascript
async answerCallbackQuery(callbackQueryId, text = '', showAlert = false) {
  try {
    const result = await this.telegramHandler.answerCallbackQuery(callbackQueryId, text, showAlert);
    return { success: true, result };
  } catch (error) {
    logger.error('Failed to answer callback query', {
      callbackQueryId,
      error: error.message
    });
    return { success: false, error: error.message };
  }
}
```

## Testing

After making the gateway changes:

1. Start gateway service with proper `TELEGRAM_BOT_TOKEN`
2. Send a task from Telegram that creates buttons (e.g., `/add hi`)
3. Click the "View Output" button
4. Verify no `botundefined` errors in logs
5. Verify button responds correctly

## Additional Notes

- The ani-code changes are backward compatible (work with and without gateway)
- Gateway mode is detected via `config.gateway.enabled`
- The payload format matches existing gateway message patterns
- Errors are logged but don't block execution (returns dummy success response)
- **deleteMessage already has full gateway support** via `deleteViaGateway()` method (line 782)

## Related Files

### ani-code project:
- src/dummy-telegram-notifier.js
- src/http-server.js

### ani-code-gateway project:
- ✅ api/src/controllers/callbackController.js - answerCallback action handler implemented
- ✅ api/src/services/telegramService.js - answerCallbackQuery method implemented
- ✅ api/src/handlers/telegramHandler.js - answerCallbackQuery method implemented

## Status

- ✅ **ani-code side**: Implemented
- ✅ **Gateway side**: Implemented
- ⏳ **Testing**: Ready for testing

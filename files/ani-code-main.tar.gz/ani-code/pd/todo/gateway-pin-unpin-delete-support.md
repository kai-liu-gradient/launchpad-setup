# Gateway Support for PIN, UNPIN, and DELETE Message Operations

## Overview

This document outlines the required changes to the `ani-code-gateway` to support Telegram message pinning, unpinning, and deletion operations. These operations are currently missing in gateway mode, which breaks the auto-pin progress tracking feature when ani-code daemons are running in gateway mode.

## Issue Summary

When ani-code runs in gateway mode, the following message operations fail silently:
- ❌ **PIN messages** - Messages cannot be pinned to keep them visible at the top of chats
- ❌ **UNPIN messages** - Messages remain pinned even after tasks complete
- ⚠️ **DELETE messages** - Partially working but not properly routed through gateway callback

### Impact

The auto-pin progress feature (`showprogress: autopin`) doesn't work in gateway mode:
1. Progress messages are not pinned when tasks start
2. Old progress messages are not unpinned when recalling (every 5 minutes)
3. Progress messages remain pinned after task completion
4. Message deletion during recall may fail

## Required Changes

### 1. Message Callback Controller

**File:** `api/src/controllers/messageCallbackController.js`

Add support for `pin`, `unpin`, and `delete` message types in the `routeMessage()` function:

```javascript
async function routeMessage(session, messageData) {
  const handler = platformHandlerFactory.getHandler(session.platform);

  const { type, content, options = {} } = messageData;

  // Route based on message type
  switch (type) {
    case 'text':
      return await handler.sendMessage(session.chat_id, content, options);

    case 'edit':
      if (!options.messageId) {
        throw new Error('messageId required for edit operation');
      }
      return await handler.editMessage(session.chat_id, options.messageId, content, options);

    case 'delete':
      if (!options.messageId) {
        throw new Error('messageId required for delete operation');
      }
      return await handler.deleteMessage(session.chat_id, options.messageId);

    // NEW: Add pin support
    case 'pin':
      if (!options.messageId) {
        throw new Error('messageId required for pin operation');
      }
      return await handler.pinChatMessage(session.chat_id, options.messageId, options);

    // NEW: Add unpin support
    case 'unpin':
      // messageId is optional - if not provided, unpins the most recent message
      return await handler.unpinChatMessage(session.chat_id, options.messageId, options);

    case 'keyboard':
      return await handler.sendWithKeyboard(session.chat_id, content, options.keyboard);

    case 'card':
      // Lark-specific card message
      if (session.platform === 'lark') {
        return await handler.sendCard(session.chat_id, content, options);
      }
      throw new Error('Card messages only supported on Lark platform');

    default:
      // Default to text message
      return await handler.sendMessage(session.chat_id, content, options);
  }
}
```

### 2. Telegram Handler

**File:** `api/src/handlers/telegramHandler.js`

Add the following methods to the TelegramHandler class:

```javascript
/**
 * Pin a message in chat
 * @param {string} chatId - Telegram chat ID
 * @param {number} messageId - Message ID to pin
 * @param {object} options - Pin options
 * @returns {Promise<object>} - Telegram API response
 */
async pinChatMessage(chatId, messageId, options = {}) {
  const { disable_notification = true } = options;

  try {
    const response = await axios.post(`${this.apiUrl}/pinChatMessage`, {
      chat_id: chatId,
      message_id: messageId,
      disable_notification
    });

    console.log(`[TelegramHandler] Message ${messageId} pinned in chat ${chatId}`);
    return response.data;
  } catch (error) {
    console.error('[TelegramHandler] Pin message error:', error.response?.data || error.message);
    throw error;
  }
}

/**
 * Unpin a message in chat
 * @param {string} chatId - Telegram chat ID
 * @param {number} messageId - Message ID to unpin (optional, unpins latest if not provided)
 * @param {object} options - Unpin options
 * @returns {Promise<object>} - Telegram API response
 */
async unpinChatMessage(chatId, messageId = null, options = {}) {
  try {
    const payload = { chat_id: chatId };
    if (messageId) {
      payload.message_id = messageId;
    }

    const response = await axios.post(`${this.apiUrl}/unpinChatMessage`, payload);

    console.log(`[TelegramHandler] Message ${messageId || 'latest'} unpinned in chat ${chatId}`);
    return response.data;
  } catch (error) {
    console.error('[TelegramHandler] Unpin message error:', error.response?.data || error.message);
    throw error;
  }
}
```

### 3. Update Existing Delete Method (if needed)

Verify that the existing `deleteMessage()` method in `telegramHandler.js` is properly implemented:

```javascript
/**
 * Delete a message
 * @param {string} chatId - Telegram chat ID
 * @param {number} messageId - Message ID to delete
 * @returns {Promise<object>} - Telegram API response
 */
async deleteMessage(chatId, messageId) {
  try {
    const response = await axios.post(`${this.apiUrl}/deleteMessage`, {
      chat_id: chatId,
      message_id: messageId
    });

    console.log(`[TelegramHandler] Message ${messageId} deleted from chat ${chatId}`);
    return response.data;
  } catch (error) {
    console.error('[TelegramHandler] Delete message error:', error.response?.data || error.message);
    throw error;
  }
}
```

## Testing

### Test Cases

#### 1. PIN Message Test
```bash
# From ani-code daemon in gateway mode
curl -X POST http://gateway:3000/api/callback/message \
  -H "Content-Type: application/json" \
  -H "x-gateway-token: gw_xxxxx..." \
  -d '{
    "message": {
      "type": "pin",
      "options": {
        "messageId": 12345,
        "disable_notification": true
      }
    }
  }'
```

**Expected response:**
```json
{
  "success": true,
  "platform": "telegram",
  "chat_id": "123456789",
  "platform_response": {
    "ok": true,
    "result": true
  }
}
```

#### 2. UNPIN Message Test
```bash
curl -X POST http://gateway:3000/api/callback/message \
  -H "Content-Type: application/json" \
  -H "x-gateway-token: gw_xxxxx..." \
  -d '{
    "message": {
      "type": "unpin",
      "options": {
        "messageId": 12345
      }
    }
  }'
```

#### 3. DELETE Message Test
```bash
curl -X POST http://gateway:3000/api/callback/message \
  -H "Content-Type: application/json" \
  -H "x-gateway-token: gw_xxxxx..." \
  -d '{
    "message": {
      "type": "delete",
      "options": {
        "messageId": 12345
      }
    }
  }'
```

### Integration Test

To test the complete auto-pin feature flow:

1. **Enable autopin for a workspace:**
   ```bash
   ani-code workspace meta set showprogress autopin
   ```

2. **Create a task from Telegram:**
   ```
   /add do something that takes a while
   ```

3. **Verify behavior:**
   - ✅ Progress message appears after 5 seconds
   - ✅ Progress message is pinned to top of chat
   - ✅ Progress message updates every 10 seconds
   - ✅ After 5 minutes, old message is unpinned and deleted, new message sent and pinned
   - ✅ When task completes, progress message is unpinned

## Error Handling

All three operations should handle these error cases gracefully:

1. **Message not found** (already deleted or never existed)
   - Return success with a warning log
   - Don't throw an error

2. **Bot lacks permissions** (not admin in group)
   - Log warning: "Bot needs admin permissions to pin/unpin messages"
   - Return failure but don't crash

3. **Rate limiting**
   - Implement retry with exponential backoff
   - Maximum 3 retries

4. **Invalid messageId**
   - Return 400 error with clear message
   - "messageId required for pin/unpin/delete operation"

## API Contract

### Request Format

The ani-code daemon will send requests in this format:

```javascript
{
  "message": {
    "type": "pin" | "unpin" | "delete",
    "content": null,  // Not used for these operations
    "options": {
      "messageId": 12345,  // Required for pin/delete, optional for unpin
      "disable_notification": true  // Only for pin
    }
  }
}
```

### Response Format

Expected response from gateway:

```javascript
{
  "success": true,
  "platform": "telegram",
  "chat_id": "123456789",
  "platform_response": {
    "ok": true,
    "result": true
  }
}
```

## Implementation Priority

1. **HIGH**: Add pin/unpin/delete support to messageCallbackController
2. **HIGH**: Implement pinChatMessage() in telegramHandler
3. **HIGH**: Implement unpinChatMessage() in telegramHandler
4. **MEDIUM**: Verify deleteMessage() works correctly
5. **MEDIUM**: Add comprehensive error handling
6. **LOW**: Add integration tests

## Notes

- Bot must have administrator privileges in Telegram groups to pin/unpin messages
- Private chats don't require special permissions
- Telegram allows only one pinned message per chat (latest pin replaces previous)
- The `disable_notification: true` option prevents spamming users with pin notifications

## Related Documentation

- Telegram Bot API: https://core.telegram.org/bots/api#pinchatmessage
- Telegram Bot API: https://core.telegram.org/bots/api#unpinchatmessage
- Telegram Bot API: https://core.telegram.org/bots/api#deletemessage
- ani-code auto-pin feature: `/root/workspace/ani-code/pd/features/autopin-progress.md`

## Status

- ✅ **ani-code side**: Implemented (wrapper methods with gateway routing)
- ✅ **Gateway side**: Implemented (pin/unpin/delete in callbackController, telegramHandler, telegramService)
- ⏳ **Testing**: Ready for testing

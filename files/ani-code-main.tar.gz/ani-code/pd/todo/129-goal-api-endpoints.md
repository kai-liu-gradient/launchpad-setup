# Ani-Code Goal Management API Endpoints

**Target Project**: ani-code
**Related Launchpad Goal**: 129-ani-code-goal-cli-ui-integration.md
**Priority**: High
**Estimated Effort**: 8-12 hours

## Objective

Expose ani-code's goal management CLI commands (`goal add`, `goal list`, `goal running`, `goal sync`) through HTTP API endpoints in the ani-code daemon. This enables AniLaunchpad UI to interact with ani-code's goal system programmatically.

## Required Endpoints

### 1. List All Goals
**Endpoint**: `GET /api/goals`

**Description**: Return all goals found in project's `pd/goals` folder

**Query Parameters**:
- `status` (optional): Filter by status (not_started, in_progress, completed, blocked)
- `limit` (optional): Number of results (default: 100)
- `offset` (optional): Pagination offset (default: 0)

**Response**:
```json
{
  "goals": [
    {
      "id": "042",
      "goalNumber": 42,
      "title": "Goal Tracking Kanban System",
      "status": "completed",
      "stage": "Stage 11: Event Tracking & Analytics",
      "progress": 100,
      "startDate": "2025-09-26",
      "completionDate": "2025-09-27",
      "description": "Implement comprehensive goal tracking...",
      "objective": "Create kanban board for goal visualization...",
      "tasks": [
        {
          "text": "Design kanban board UI",
          "completed": true
        },
        {
          "text": "Implement drag-and-drop",
          "completed": true
        }
      ],
      "acceptanceCriteria": [
        "Kanban board displays all goals",
        "Drag-and-drop works smoothly"
      ],
      "dependencies": ["041"],
      "tags": ["ui", "tracking"],
      "priority": "high",
      "file": "042-goal-tracking-kanban-system.md",
      "filePath": "/workspace/pd/goals/042-goal-tracking-kanban-system.md",
      "createdAt": "2025-09-26T10:00:00Z",
      "updatedAt": "2025-09-27T15:30:00Z"
    }
  ],
  "total": 128,
  "limit": 100,
  "offset": 0
}
```

**Status Codes**:
- 200: Success
- 404: pd/goals folder not found
- 500: Error reading goals

---

### 2. Get Goal Details
**Endpoint**: `GET /api/goals/:goalId`

**Description**: Return detailed information for a specific goal

**Path Parameters**:
- `goalId`: Goal identifier (e.g., "042" or "042-goal-tracking-kanban-system")

**Response**:
```json
{
  "goal": {
    "id": "042",
    "goalNumber": 42,
    "title": "Goal Tracking Kanban System",
    "status": "completed",
    "stage": "Stage 11: Event Tracking & Analytics",
    "progress": 100,
    "content": "# Goal 042: Goal Tracking Kanban System\n\n## Objective\n...",
    "contentHtml": "<h1>Goal 042: Goal Tracking Kanban System</h1>...",
    "tasks": [...],
    "acceptanceCriteria": [...],
    "dependencies": [...],
    "metadata": {
      "estimatedHours": 32,
      "actualHours": 28,
      "assignee": "Claude"
    }
  }
}
```

**Status Codes**:
- 200: Success
- 404: Goal not found
- 500: Error reading goal

---

### 3. Create New Goal
**Endpoint**: `POST /api/goals`

**Description**: Create new goal file in pd/goals folder (executes `goal add` logic)

**Request Body**:
```json
{
  "title": "Implement User Authentication",
  "objective": "Add JWT-based authentication to the API",
  "stage": "Stage 5: Authentication",
  "description": "Implement secure user authentication...",
  "tasks": [
    "Install JWT library",
    "Create auth middleware",
    "Add login endpoint",
    "Add token refresh endpoint"
  ],
  "acceptanceCriteria": [
    "Users can login with email/password",
    "JWT tokens expire after 24 hours",
    "Refresh tokens work correctly"
  ],
  "dependencies": ["004", "005"],
  "priority": "high",
  "estimatedHours": 16
}
```

**Response**:
```json
{
  "success": true,
  "goal": {
    "id": "129",
    "goalNumber": 129,
    "title": "Implement User Authentication",
    "file": "129-implement-user-authentication.md",
    "filePath": "/workspace/pd/goals/129-implement-user-authentication.md",
    "createdAt": "2025-11-17T12:00:00Z"
  }
}
```

**Status Codes**:
- 201: Goal created successfully
- 400: Invalid request body
- 409: Goal already exists
- 500: Error creating goal

---

### 4. Update Existing Goal
**Endpoint**: `PUT /api/goals/:goalId`

**Description**: Update existing goal file (modify status, progress, tasks, etc.)

**Path Parameters**:
- `goalId`: Goal identifier

**Request Body**:
```json
{
  "status": "in_progress",
  "progress": 35,
  "tasks": [
    {
      "text": "Install JWT library",
      "completed": true
    },
    {
      "text": "Create auth middleware",
      "completed": false
    }
  ],
  "notes": "JWT library installed, working on middleware"
}
```

**Response**:
```json
{
  "success": true,
  "goal": {
    "id": "129",
    "status": "in_progress",
    "progress": 35,
    "updatedAt": "2025-11-17T14:30:00Z"
  }
}
```

**Status Codes**:
- 200: Goal updated successfully
- 404: Goal not found
- 400: Invalid update data
- 500: Error updating goal

---

### 5. Get Running Goals
**Endpoint**: `GET /api/goals/running`

**Description**: Return goals with status "in_progress" (implements `goal running` logic)

**Query Parameters**:
- `limit` (optional): Number of results (default: 50)

**Response**:
```json
{
  "runningGoals": [
    {
      "id": "125",
      "title": "Admin User Impersonation",
      "status": "in_progress",
      "progress": 60,
      "startDate": "2025-11-15",
      "tasks": [
        { "text": "Create impersonation API", "completed": true },
        { "text": "Add UI controls", "completed": false }
      ]
    }
  ],
  "total": 3
}
```

**Status Codes**:
- 200: Success
- 500: Error fetching running goals

---

### 6. Sync Goals from Filesystem
**Endpoint**: `POST /api/goals/sync`

**Description**: Trigger full sync of pd/goals folder (implements `goal sync` logic)

**Request Body** (optional):
```json
{
  "force": false,
  "verbose": true
}
```

**Response**:
```json
{
  "success": true,
  "syncResult": {
    "goalsFound": 128,
    "goalsUpdated": 5,
    "goalsCreated": 2,
    "goalsDeleted": 0,
    "errors": [],
    "duration": "1.2s",
    "timestamp": "2025-11-17T12:00:00Z"
  }
}
```

**Status Codes**:
- 200: Sync completed successfully
- 207: Partial sync (some goals failed)
- 500: Sync failed completely

---

### 7. Delete Goal
**Endpoint**: `DELETE /api/goals/:goalId`

**Description**: Archive or delete goal file

**Path Parameters**:
- `goalId`: Goal identifier

**Query Parameters**:
- `archive` (optional): Archive instead of delete (default: true)

**Response**:
```json
{
  "success": true,
  "action": "archived",
  "archivedPath": "/workspace/pd/goals/archive/129-implement-user-authentication.md"
}
```

**Status Codes**:
- 200: Goal deleted/archived
- 404: Goal not found
- 500: Error deleting goal

---

## Implementation Guidelines

### 1. File Parsing
- Use existing markdown parsing logic from `goal` CLI commands
- Support YAML frontmatter for metadata:
  ```yaml
  ---
  title: "Goal Title"
  status: in_progress
  progress: 50
  ---
  ```
- Parse task checkboxes: `- [ ]` (unchecked) and `- [x]` (checked)
- Extract sections: Objective, Tasks, Acceptance Criteria, Dependencies, Progress

### 2. Goal Numbering
- Auto-increment goal number based on highest existing number
- Format: 3-digit zero-padded (001, 002, ..., 128, 129)
- Filename format: `{number}-{kebab-case-title}.md`

### 3. Error Handling
- Return 404 if pd/goals folder doesn't exist
- Return 400 for invalid markdown structure
- Return 409 for duplicate goal numbers
- Log all errors for debugging

### 4. Validation
- Validate required fields: title, objective
- Validate status enum: not_started, in_progress, blocked, completed, archived
- Validate progress range: 0-100
- Validate dependencies exist before creating goal

### 5. Performance
- Cache goal list for 30 seconds
- Use file watcher to invalidate cache on changes
- Support pagination for large goal lists
- Return 304 Not Modified if no changes since last fetch

### 6. Security
- Authenticate all requests with workspace token
- Validate file paths to prevent directory traversal
- Sanitize user input before writing to files
- Rate limit to prevent abuse (100 requests/minute)

## Testing Requirements

### Unit Tests
- [ ] Test goal file parsing (valid and invalid markdown)
- [ ] Test goal number generation and collision handling
- [ ] Test task checkbox parsing
- [ ] Test YAML frontmatter extraction
- [ ] Test error handling for missing files

### Integration Tests
- [ ] Test full CRUD operations on goals
- [ ] Test sync operation with 100+ goal files
- [ ] Test running goals filter accuracy
- [ ] Test concurrent goal updates
- [ ] Test pagination and filtering

### Edge Cases
- [ ] Handle goals without frontmatter
- [ ] Handle malformed markdown
- [ ] Handle missing pd/goals folder
- [ ] Handle write permission errors
- [ ] Handle very large goal files (>1MB)

## Example Goal File Format

```markdown
---
title: "Implement User Authentication"
status: in_progress
progress: 35
startDate: 2025-11-15
targetDate: 2025-11-20
priority: high
tags: [auth, security, backend]
---

# Goal 129: Implement User Authentication

## Objective
Add JWT-based authentication to the API to secure endpoints and manage user sessions. This provides foundational security for the application.

## Tasks
- [x] Install JWT library (jsonwebtoken)
- [ ] Create auth middleware
- [ ] Add login endpoint
- [ ] Add token refresh endpoint
- [ ] Add password hashing with bcrypt
- [ ] Write unit tests for auth flow

## Acceptance Criteria
- Users can login with email/password
- JWT tokens expire after 24 hours
- Refresh tokens work correctly
- Passwords are hashed and salted
- Protected endpoints require valid JWT
- Unit tests achieve >90% coverage

## Progress
- Status: **In Progress**
- Start Date: 2025-11-15
- Completion Date: -
- Notes: JWT library installed, working on middleware implementation

## Dependencies
- Goal 004: Initialize Node.js Backend
- Goal 005: Implement JWT Authentication
```

## API Client Example (for Launchpad)

```javascript
// launchpad-api/src/services/aniCodeGoalService.js
class AniCodeGoalService {
  constructor(aniCodeDaemonUrl, workspaceToken) {
    this.baseUrl = aniCodeDaemonUrl;
    this.token = workspaceToken;
  }

  async listGoals(filters = {}) {
    const params = new URLSearchParams(filters);
    const response = await fetch(`${this.baseUrl}/api/goals?${params}`, {
      headers: { 'Authorization': `Bearer ${this.token}` }
    });
    return await response.json();
  }

  async createGoal(goalData) {
    const response = await fetch(`${this.baseUrl}/api/goals`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.token}`
      },
      body: JSON.stringify(goalData)
    });
    return await response.json();
  }

  async getRunningGoals() {
    const response = await fetch(`${this.baseUrl}/api/goals/running`, {
      headers: { 'Authorization': `Bearer ${this.token}` }
    });
    return await response.json();
  }

  async syncGoals() {
    const response = await fetch(`${this.baseUrl}/api/goals/sync`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${this.token}` }
    });
    return await response.json();
  }
}
```

## Documentation Requirements
- [ ] API endpoint documentation (OpenAPI/Swagger)
- [ ] Goal file format specification
- [ ] Integration guide for Launchpad
- [ ] Error code reference
- [ ] Example requests and responses

## Deliverables
1. Fully functional API endpoints in ani-code daemon
2. Unit and integration tests (>90% coverage)
3. API documentation (OpenAPI spec)
4. Integration guide for Launchpad developers
5. Migration script for existing goal files (if format changes)

---

**Next Steps**:
1. Review this specification with ani-code team
2. Implement endpoints in ani-code daemon
3. Write tests for all endpoints
4. Update ani-code documentation
5. Notify AniLaunchpad team when ready for integration

**Questions for ani-code Team**:
1. Does ani-code daemon already have any goal management endpoints?
2. What is the preferred method for executing CLI commands from daemon?
3. Should goal sync be automatic or manual only?
4. What authentication mechanism does daemon use?
5. Are there rate limits on daemon API requests?

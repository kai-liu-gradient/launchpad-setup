# Goals System

## Overview

The Goals system provides structured project management with markdown-based goal files, intelligent caching, automated execution loops, and progress tracking. Goals are stored in `pd/goals/` as markdown files.

## Commands

### Core Commands

#### `ani-code goals list` (alias: `ls`)
List all goals with summary from cache.

```bash
ani-code goals list
ani-code goals list --refresh  # Force refresh from files
```

**Output:**
- Goal ID and title
- Status (Not Started, In Progress, Completed)
- Task completion (e.g., 3/10 tasks)
- Progress percentage
- Manual override indicators

#### `ani-code goals show <goal-id>` (alias: `view`)
Show detailed information about a specific goal.

```bash
ani-code goals show 5
ani-code goals show 025-user-auth
ani-code goals show "user authentication"
```

**Accepts:**
- Index number (5)
- Filename (025-user-auth.md)
- Description search ("user auth")

#### `ani-code goals progress` (alias: `status`)
Show progress statistics across all goals.

```bash
ani-code goals progress
```

**Output:**
- Total goals by status
- Overall task completion
- Progress bar visualization
- Currently in-progress goals

### Goal Management

#### `ani-code goals add [description]`
Create or update goals with Claude's help.

```bash
ani-code goals add "implement user authentication"
ani-code goals add --update 5 "add OAuth support"
ani-code goals add --update 5 --merge
```

**Options:**
- `--update <goal-id>`: Update existing goal
- `--merge`: Merge with existing content

**Workflow:**
1. Claude analyzes description and PRD
2. Creates structured goal file
3. Generates tasks and acceptance criteria
4. Saves to pd/goals/ directory

#### `ani-code goals update <goal-id> <status>`
Manually update goal status.

```bash
ani-code goals update 5 "In Progress"
ani-code goals update 12 "Completed"
ani-code goals update 8 "On Hold"
```

**Valid statuses:**
- Not Started
- In Progress
- Completed
- Abandoned
- Cancelled
- On Hold

#### `ani-code goals bulk-update <range> <status>`
Update multiple goals with confirmation.

```bash
ani-code goals bulk-update "1-15" "Not Started"
ani-code goals bulk-update "1,3,5,7" "Completed"
```

**Range formats:**
- `1-15`: Range from 1 to 15
- `1,3,5,7`: Specific goal IDs

#### `ani-code goals clear-override <goal-id>`
Remove manual status override (allows auto-calculation).

```bash
ani-code goals clear-override 5
```

### Automated Execution

#### `ani-code goals loop`
Automated goal implementation loop.

```bash
ani-code goals loop
ani-code goals loop --goal 5
ani-code goals loop --limit 10
ani-code goals loop --skip-validation
```

**Options:**
- `--goal <id>`: Focus on specific goal
- `--limit <n>`: Max iterations (default: 5)
- `--skip-validation`: Skip validation checks

**Workflow:**
1. Loads PRD from pd/ directory
2. Analyzes goals and selects next task
3. Implements tasks autonomously
4. Updates goal file progress
5. Validates implementation
6. Continues to next goal/task

**Selection priority:**
1. Non-[MANUAL] goals only
2. In Progress goals first
3. Not Started goals next
4. Goals with lowest completion percentage

#### `ani-code goals check`
Check completion status across all goals.

```bash
ani-code goals check
ani-code goals check --verbose
```

**Options:**
- `--verbose`: Show detailed task breakdowns

### Cache Management

#### `ani-code goals sync` (alias: `refresh`)
Analyze goal files with Claude and update cache.

```bash
ani-code goals sync
ani-code goals sync --full
```

**Options:**
- `--full`: Force full resync (includes completed goals)

**Auto-syncs when:**
- Goal files are newer than cache
- Cache doesn't exist
- Manual refresh requested

### Maintenance Commands

#### `ani-code goals fix-format [goal-selector]`
Auto-fix goal file formats.

```bash
ani-code goals fix-format
ani-code goals fix-format 5
ani-code goals fix-format "1-15"
ani-code goals fix-format "user auth"
```

**Fixes:**
- Missing Progress sections
- Malformed task lists
- Incorrect status formats
- Missing metadata

#### `ani-code goals clean-status [goal-selector]`
Clean malformed status fields.

```bash
ani-code goals clean-status
ani-code goals clean-status 7
ani-code goals clean-status "1-15"
```

#### `ani-code goals add-progress`
Add missing Progress sections using Claude.

```bash
ani-code goals add-progress
```

#### `ani-code goals export`
Export goals data to JSON.

```bash
ani-code goals export
ani-code goals export --output goals.json
```

## Manual Flag

### What is [MANUAL]?

The `[MANUAL]` flag marks goals requiring human intervention. Goals with this flag are **skipped** during automated loops.

**Use cases:**
- Decisions requiring human judgment
- External actions (DNS, payments, approvals)
- Manual testing/QA reviews
- User-specific configurations

### Toggling Manual Flag

```bash
# Mark as manual
ani-code goals update 5 --manual

# Remove manual flag
ani-code goals update 5 --manual=false
```

**In goal loop:**
- [MANUAL] goals are automatically skipped
- Selection moves to next non-manual goal
- Manual status shown in goal list

## Goal File Format

### Standard Structure

```markdown
# Goal: [Title]

## Objective
Clear description of what this goal achieves.

## Tasks
- [ ] Task 1 description
- [x] Task 2 completed
- [ ] Task 3 description

## Acceptance Criteria
- Criterion 1
- Criterion 2
- Criterion 3

## Dependencies
- Goal 5: User Authentication
- External: API access approved

## Progress
- **Status**: In Progress
- **Start Date**: 2025-11-01
- **Completion Date**: -
- **Task Completion**: 2/5 (40%)
- **Notes**: OAuth integration in progress

## Technical Details
Implementation notes, architecture decisions, etc.
```

### Required Sections
- `# Goal: [Title]`
- `## Objective`
- `## Tasks`
- `## Acceptance Criteria`
- `## Progress`

### Task Format
```markdown
- [ ] Incomplete task
- [x] Completed task
- [ ] Another task with details
```

### Progress Section
```markdown
## Progress
- **Status**: Not Started | In Progress | Completed | Abandoned | Cancelled | On Hold
- **Start Date**: YYYY-MM-DD or -
- **Completion Date**: YYYY-MM-DD or -
- **Task Completion**: X/Y (Z%)
- **Notes**: Optional notes about blockers or changes
```

## Cache Architecture

### Storage Location

**Primary:** Workspace metadata (`~/.ani-code/workspaces.db`)
**Fallback:** File-based (`.ani-code/goals-cache.json`)

### Cache Structure

```json
{
  "lastUpdated": "2025-11-07T10:30:00Z",
  "totalGoals": 15,
  "summary": {
    "notStarted": 5,
    "inProgress": 3,
    "completed": 7,
    "totalTasks": 145,
    "completedTasks": 87,
    "overallPercentage": 60
  },
  "goals": [
    {
      "id": 1,
      "title": "User Authentication",
      "path": "/path/to/pd/goals/001-user-auth.md",
      "objective": "Implement secure user authentication...",
      "tasks": [
        { "text": "Create login form", "completed": true },
        { "text": "Add password hashing", "completed": false }
      ],
      "acceptanceCriteria": [...],
      "progress": {
        "status": "In Progress",
        "startDate": "2025-11-01",
        "completionDate": "-",
        "taskCompletion": {
          "completed": 3,
          "total": 5,
          "percentage": 60
        },
        "notes": "OAuth integration pending"
      },
      "manual": false
    }
  ]
}
```

### Cache Invalidation

**Triggers:**
- Goal file modification time > cache time
- Goal file added/removed
- Manual refresh requested

**Validation:**
- Checks file mtimes on every read
- Auto-refreshes if stale
- Validates structure integrity

## Integration

### With Claude Loop

Goals loop integrates with ani-code daemon:
1. Creates task via IPC
2. Monitors live progress
3. Handles task completion/failure
4. Updates cache automatically

### With PRD

Loop reads PRD files from pd/ directory:
- `pd/prd.md` - Product requirements
- `pd/architecture.md` - Architecture docs
- Context provided to Claude during execution

### With Workspace Manager

Goals cache stored per workspace:
- Multi-workspace support
- Isolated goal tracking
- Workspace-aware commands

## Best Practices

### Goal Creation
- Clear, actionable objectives
- Specific acceptance criteria
- Reasonable task breakdown (5-15 tasks per goal)
- Dependencies documented

### Task Management
- One action per task
- Testable completion criteria
- Logical ordering
- Regular progress updates

### Status Updates
- Update after significant progress
- Document blockers immediately
- Mark manual goals appropriately
- Clear override when auto-sync works

### Loop Execution
- Run with specific goal for focused work
- Use limits to prevent runaway execution
- Review validation output
- Check logs for errors

## Examples

### Create and Execute Goal

```bash
# Create new goal
ani-code goals add "implement payment processing"

# Check goal was created
ani-code goals list

# Start automated implementation
ani-code goals loop --goal 10 --limit 3

# Check progress
ani-code goals progress

# View details
ani-code goals show 10
```

### Mark Goal as Manual

```bash
# Set manual flag
ani-code goals update 5 --manual

# Verify in list
ani-code goals list
# Shows: [MANUAL] 5. Configure DNS

# Remove flag when ready
ani-code goals update 5 --manual=false
```

### Bulk Operations

```bash
# Reset multiple goals
ani-code goals bulk-update "1-5" "Not Started"

# Fix formatting issues
ani-code goals fix-format "1-20"

# Clean malformed status
ani-code goals clean-status
```

### Export and Backup

```bash
# Export to JSON
ani-code goals export --output backup.json

# Sync cache
ani-code goals sync --full
```

## Troubleshooting

### Cache Out of Sync
```bash
ani-code goals sync --full
```

### Goal Not Found
- Check goal ID with `ani-code goals list`
- Verify file exists in pd/goals/
- Try filename or description search

### Loop Skipping Goals
- Check for [MANUAL] flag
- Verify goal status (completed goals skipped)
- Check task completion (100% = completed)

### Progress Not Updating
- Ensure Progress section exists
- Run `ani-code goals fix-format`
- Check file permissions
- Verify cache validity

## See Also

- [Goals API Documentation](../api/goals.md)
- [System Architecture](../architecture/system-overview.md)
- [Workspace Management](workspace-management.md)

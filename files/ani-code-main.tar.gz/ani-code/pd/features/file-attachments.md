# File Attachments Feature

## Overview
Added support for sending file attachments to workspace-connected Telegram chats using `@filename` syntax in messages.

## Features
- **@filename Syntax**: Reference local files in messages using `@filename.ext`
- **Automatic Type Detection**: Images are sent as photos, other files as documents
- **Multiple Attachments**: Support for multiple file attachments in a single message
- **Path Resolution**: Supports both absolute and relative file paths
- **Graceful Handling**: Missing files are logged but don't stop message sending

## Usage

### Command Line
```bash
# Send a message with a file attachment
ani-code message "Here's the report: @report.pdf"

# Send multiple attachments
ani-code message "Files: @image.png @document.pdf @data.csv"

# With markdown formatting
ani-code message -m "**Important**: Review @presentation.pptx"
```

### Programmatic API
```javascript
import { TelegramNotifier } from './telegram-notifier.js';

const notifier = new TelegramNotifier();

// Send message with attachments to a workspace
await notifier.sendMessageToWorkspace(
  'workspace-name',
  'Check out @screenshot.png and @logs.txt',
  { parse_mode: 'Markdown' }
);
```

## Implementation Details

### File Detection Pattern
- Regex pattern: `/@([^\s]+\.[^\s]+)/g`
- Matches: `@filename.extension` in message text
- Requires: File extension to distinguish from email addresses

### File Type Detection
Images (sent as photos):
- `.jpg`, `.jpeg`, `.png`, `.gif`, `.bmp`, `.webp`

Documents (sent as files):
- All other file types including `.pdf`, `.txt`, `.md`, `.doc`, etc.

### Path Resolution
1. If absolute path: Use as-is
2. If relative path: Resolve relative to workspace directory
3. File existence is verified before sending

### Message Processing
1. Parse message for `@filename` patterns
2. Verify file existence and collect valid attachments
3. Send each attachment (images as photos, others as documents)
4. Send main message with `@filename` references replaced with `[filename]`

## Components Modified

### 1. `src/telegram-notifier.js`
- Added `sendDocument()` method for document attachments
- Added `sendMessageToWorkspace()` method with attachment support
- Handles file parsing, validation, and sending

### 2. `src/telegram-api.js`
- Updated `sendPhoto()` to handle file streams
- Updated `sendDocument()` to handle file streams
- Added proper FormData handling for Node.js

### 3. `src/index.js`
- Updated `message` command to support attachments
- Added file parsing and sending logic for CLI usage
- Updated command description to mention attachment feature

## Error Handling
- **File Not Found**: Logged as warning, message still sent without that attachment
- **Send Failure**: Individual attachment failures don't stop other attachments
- **No Workspace**: Clear error message if workspace not found
- **No Chat Mapping**: Warning if workspace has no associated Telegram chat

## Testing
Test script available at: `tests/manual/test-file-attachments.js`

Run tests:
```bash
node tests/manual/test-file-attachments.js
```

## Examples

### Send a screenshot
```bash
ani-code message "Bug found: @screenshot.png"
```

### Send multiple files
```bash
ani-code message "Project files: @README.md @package.json @config.yaml"
```

### Send with description
```bash
ani-code message "Please review the attached report @report.pdf and provide feedback"
```

## Limitations
- File size limits apply (Telegram's 50MB for documents, 10MB for photos)
- Binary file streams are created for each attachment
- Requires file system access permissions

## Future Enhancements
- Support for Lark file attachments
- Batch upload optimization for multiple files
- Progress indicators for large file uploads
- Support for directories/archives
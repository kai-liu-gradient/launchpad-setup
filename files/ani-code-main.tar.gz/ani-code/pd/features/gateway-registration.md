# Gateway Registration Feature

## Overview

Implemented dynamic instance registration for ani-code instances running in Kubernetes pods. This feature enables ani-code instances to automatically register with the ani-code-gateway for centralized task routing and management.

## Implementation Date
November 3, 2025

## Key Features

### 1. **100% Backward Compatible**
- Feature is completely optional
- Only activates when `GATEWAY_URL` environment variable is set
- No changes to existing standalone behavior
- Zero breaking changes

### 2. **Automatic Registration**
- Instances register on startup when gateway URL is configured
- Sends pod metadata (projectId, workspaceId, podName)
- Includes instance capabilities in metadata
- Non-blocking registration (5-second timeout)

### 3. **Graceful Degradation**
- Continues in standalone mode if gateway is unavailable
- Handles network failures without crashing
- Logs warnings but doesn't interrupt service

### 4. **Health Monitoring**
- Health endpoint at `/health` returns status and readiness
- Gateway can health-check registered instances
- Heartbeat mechanism updates lastSeen timestamp every 30 seconds

### 5. **Clean Shutdown**
- Automatic deregistration on SIGTERM/SIGINT
- Removes instance from gateway registry before shutdown
- Prevents stale instances in gateway

## Files Modified

1. **src/gateway-client.js** (NEW)
   - Core gateway registration client
   - Handles registration, deregistration, and heartbeat
   - Manages instance lifecycle

2. **src/daemon.js**
   - Integrated gateway client into startup sequence
   - Added shutdown handlers for deregistration
   - Imports and uses gateway client

3. **src/http-server.js**
   - Updated health endpoint to include `ready` field
   - Returns `status: "ok"` for gateway compatibility

## Environment Variables

### Optional (for K8s pod mode only)

```env
# Gateway integration
GATEWAY_URL=http://gateway-service:6555    # Gateway service URL
GATEWAY_API_KEY=your-api-key              # API key for authentication

# Pod metadata (auto-populated in K8s)
PROJECT_ID=project-123                    # Project identifier
WORKSPACE_ID=workspace-456                # Workspace identifier
POD_NAME=ani-code-pod-xyz                 # Pod name
POD_IP=10.0.0.100                        # Pod IP address
```

### Default Behavior

When no environment variables are set:
- ani-code runs in standalone mode
- No gateway registration attempted
- Works exactly as before

## API Endpoints

### Registration
```bash
POST http://gateway:6555/api/registry/instance
Headers: x-api-key: <api-key>
Body: {
  "url": "http://pod-ip:6501",
  "metadata": {
    "projectId": "proj-123",
    "workspaceId": "ws-456",
    "podName": "ani-code-pod",
    "version": "1.2.0",
    "capabilities": ["telegram", "lark", "cli", "http", "websocket"]
  }
}
```

### Deregistration
```bash
DELETE http://gateway:6555/api/registry/instance/{instance-id}
Headers: x-api-key: <api-key>
```

### Health Check
```bash
GET http://ani-code:6501/health
Response: {
  "status": "ok",
  "ready": true,
  "healthy": true,
  "timestamp": "2025-11-03T07:00:00.000Z",
  "tasks": {
    "running": 0,
    "pending": 0
  }
}
```

## Testing

### Test Files
- `test-gateway-registration.js` - Basic functionality tests
- `test-gateway-with-api.js` - API integration tests
- `test-gateway-final.js` - Acceptance criteria validation

### Test Results

All acceptance criteria met:
- ✅ Works in standalone mode (no env vars) - CRITICAL
- ✅ Registers with gateway when GATEWAY_URL is set
- ✅ Registration includes pod metadata
- ✅ Health check endpoint available
- ✅ Graceful shutdown deregisters from gateway
- ✅ Works in both local and K8s environments
- ✅ Handles gateway unavailability gracefully
- ✅ Registration is non-blocking
- ✅ No changes to existing standalone behavior

## Usage Examples

### Standalone Mode (Default)
```bash
# Start ani-code without gateway configuration
ani-code daemon --start

# Output: "No GATEWAY_URL configured, running in standalone mode"
```

### K8s Pod Mode
```bash
# Set environment variables in pod spec
export GATEWAY_URL=http://gateway-service:6555
export GATEWAY_API_KEY=prod-key
export PROJECT_ID=my-project
export WORKSPACE_ID=workspace-1

# Start ani-code
ani-code daemon --start

# Output: "Gateway instance registration enabled - heartbeat started"
```

### Gateway Unavailable (Graceful Fallback)
```bash
# Set gateway URL to non-existent service
export GATEWAY_URL=http://invalid:9999

# Start ani-code
ani-code daemon --start

# Output: "Gateway unavailable at http://invalid:9999 (continuing in standalone mode)"
```

## Architecture Benefits

1. **Scalability**: Multiple ani-code instances can register with a single gateway
2. **Discovery**: Gateway maintains registry of available instances
3. **Load Balancing**: Gateway can route tasks to appropriate instances
4. **High Availability**: Instances can be added/removed dynamically
5. **Zero Downtime**: Rolling deployments with automatic registration

## Security Considerations

- API key authentication for registration
- Instance URLs validated before registration
- Automatic cleanup of stale instances (1-hour timeout)
- No sensitive data in registration metadata

## Future Enhancements

1. **Metrics Collection**: Report instance metrics to gateway
2. **Capability-based Routing**: Route tasks based on instance capabilities
3. **Health Score**: Include resource utilization in health checks
4. **Regional Registration**: Support multi-region deployments
5. **Certificate-based Auth**: Use mTLS for secure registration

## Monitoring

### Logs to Watch
```bash
# Registration success
INFO: Registered with gateway: {instanceId: "abc123"}

# Registration failure (non-fatal)
WARN: Gateway unavailable at http://gateway:6555 (continuing in standalone mode)

# Deregistration
INFO: Deregistered from gateway: {instanceId: "abc123"}
```

### Metrics
- Registration success/failure count
- Heartbeat latency
- Instance uptime
- Active instance count (gateway side)

## Rollback Plan

If issues arise:
1. Remove `GATEWAY_URL` environment variable
2. Instances automatically revert to standalone mode
3. No code changes required
4. Feature is completely optional

## Conclusion

The gateway registration feature successfully enables ani-code to work in both standalone and distributed K8s environments without any breaking changes. The implementation prioritizes reliability, backward compatibility, and graceful degradation, ensuring zero impact on existing deployments while enabling new cloud-native capabilities.
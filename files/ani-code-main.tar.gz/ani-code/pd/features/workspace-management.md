# Workspace Management System

## Overview

The workspace management system provides a secure, token-based approach to managing multiple workspaces in ani-code. It replaces the simple configuration-based approach with a SQLite database and JWT tokens for better security and flexibility.

## Features

### 1. SQLite Database Storage
- Persistent workspace configurations
- Token management with expiration
- Chat-to-workspace mappings
- WebSocket connection tracking
- Audit trail for workspace access

### 2. JWT Token Authentication
- Secure token generation with customizable permissions
- Token validation with expiration checking
- Support for different token types (api, websocket, plugin)
- Backward compatibility with legacy tokens

### 3. Workspace Commands

#### Creating a Workspace
```bash
ani-code workspace create <name> -p <path> -d <description>
```
Creates a new workspace and generates an initial access token.

#### Listing Workspaces
```bash
ani-code workspace list [-a] [-v]
```
Lists all active workspaces. Use `-a` to include inactive, `-v` for detailed view.

#### Workspace Information
```bash
ani-code workspace info <name-or-id>
```
Shows detailed information about a workspace including active tokens and connections.

#### Token Management
```bash
# Generate a new token
ani-code workspace token generate <workspace> [-n <name>] [-t <type>] [-p <permissions>] [-e <days>]

# List tokens
ani-code workspace token list [workspace]

# Validate a token
ani-code workspace token validate <token>

# Revoke a token
ani-code workspace token revoke <token-id>
```

#### Chat Mapping
```bash
# Map a Lark chat to a workspace
ani-code workspace chat map <chat-id> <workspace>

# List all chat mappings
ani-code workspace chat list
```

### 4. Lark Integration

Users can now link their Lark chat to a workspace using a JWT token:

```
/token <jwt-token>
```

This provides better security than the previous approach as:
- Tokens can have specific permissions
- Tokens can expire
- Tokens can be revoked if compromised
- Each chat can have its own token

### 5. WebSocket Integration

The WebSocket server now supports both:
- Legacy token format (backward compatibility)
- New JWT workspace tokens

When a client connects with a workspace token, the connection is:
- Validated against the workspace database
- Tracked in the connections table
- Associated with specific workspace permissions

## Database Schema

### Tables

1. **workspaces** - Stores workspace configurations
   - id, name, description, path, created_at, updated_at, is_active, settings

2. **workspace_tokens** - Manages access tokens
   - id, workspace_id, token_hash, name, type, permissions, created_at, expires_at, last_used_at, is_revoked

3. **chat_workspace_mappings** - Links Lark chats to workspaces
   - id, chat_id, workspace_id, created_at, updated_at, is_active

4. **ws_connections** - Tracks active WebSocket connections
   - id, workspace_id, token_id, client_info, connected_at, disconnected_at, is_active

## Security Features

1. **Token Security**
   - Tokens are hashed before storage (bcrypt)
   - JWT secret is stored securely with 0600 permissions
   - Tokens can have expiration dates
   - Tokens can be revoked immediately

2. **Permission System**
   - Fine-grained permissions (read, write, admin)
   - Different token types for different use cases
   - Permission validation at connection time

3. **Audit Trail**
   - All token usage is logged
   - Connection history is maintained
   - Last used timestamps for tokens

## Migration from Legacy System

The system supports automatic migration from the old `.ani-code-chat-settings.json` file:

```bash
ani-code workspace migrate [-f <path-to-settings-file>]
```

This will:
1. Read the existing chat settings
2. Create workspaces for each unique workdir
3. Map chats to their corresponding workspaces
4. Preserve all existing relationships

## Usage Examples

### Admin Setup
```bash
# Create a workspace for a project
ani-code workspace create my-project -p /home/user/projects/my-project -d "My main project"

# Generate a token for a developer
ani-code workspace token generate my-project -n "Developer Token" -p read,write -e 30

# Share the token with the developer
# They can use it in Lark: /token <token>
```

### Developer Usage
```bash
# In Lark chat
/token eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

# Now all commands run in the linked workspace
/add Fix the bug in the login function
/status
/shell npm test
```

### Monitoring
```bash
# Check active connections
ani-code workspace info my-project

# List all tokens
ani-code workspace token list

# Revoke a compromised token
ani-code workspace token revoke <token-id>
```

## Benefits

1. **Better Security**: JWT tokens with expiration and revocation
2. **Multi-tenancy**: Support for multiple isolated workspaces
3. **Audit Trail**: Track who accessed what and when
4. **Flexibility**: Different permissions for different users
5. **Scalability**: SQLite database can handle many workspaces and tokens
6. **Backward Compatibility**: Still supports legacy token format

## Implementation Details

- **Database**: SQLite with proper indices for performance
- **Token Format**: JWT with HS256 signing
- **Password Hashing**: bcrypt with salt rounds of 10
- **File Permissions**: Secure storage of JWT secret (0600)
- **Connection Tracking**: Real-time monitoring of active connections

## Future Enhancements

1. Token refresh mechanism
2. Role-based access control (RBAC)
3. Workspace resource limits
4. Usage analytics per workspace
5. Webhook notifications for workspace events
6. Web UI for workspace management
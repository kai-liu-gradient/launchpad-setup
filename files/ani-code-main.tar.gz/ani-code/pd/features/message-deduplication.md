# Message Deduplication and Filtering

Ani-code implements robust message deduplication and filtering to ensure reliable webhook processing and prevent duplicate task creation.

## Overview

The system prevents processing of duplicate and stale messages from Lark webhooks, ensuring each user command is processed exactly once, even if webhooks are delivered multiple times or with delays.

## Key Features

### Message ID Tracking
- Every incoming Lark message has a unique `message_id`
- IDs are stored in an in-memory cache
- Duplicate messages are immediately rejected
- Prevents multiple task creation from same command

### Timestamp Validation
- Messages include `create_time` timestamp
- System compares message age against current time
- Stale messages (>10 seconds old) are rejected
- Prevents processing of delayed webhook deliveries

### Automatic Cache Cleanup
- Background cleanup runs every 30 seconds
- Removes message IDs older than 60 seconds
- Prevents memory growth from long-running daemons
- Maintains optimal performance

## Implementation Details

### Message Processing Flow

1. **Message Received**
   - Extract message_id and create_time
   - Log receipt with full timestamp details

2. **Deduplication Check**
   - Check if message_id exists in cache
   - If found, reject as duplicate
   - If new, add to cache with timestamp

3. **Age Validation**
   - Calculate message age in milliseconds
   - Compare against MAX_MESSAGE_AGE_MS (10000ms)
   - Reject if message is too old

4. **Process Command**
   - Parse and execute command
   - Create task or perform action
   - Return success response

### Logging Format

#### Successful Processing
```
📨 V2.0 Message received:
  Message ID: msg_xxxxx
  Chat ID: oc_xxxxx
  Create Time: 1629300000000 (2021-08-18T12:00:00.000Z)
  Current Time: 1629300005000 (2021-08-18T12:00:05.000Z)
  Message Text: /status
✅ Message age check passed: 5s old (within 10s threshold)
```

#### Duplicate Detection
```
📨 V2.0 Message received:
  Message ID: msg_xxxxx
  ...
✋ Duplicate message detected (v2.0): msg_xxxxx, ignoring
```

#### Stale Message Rejection
```
⏰ STALE MESSAGE REJECTED (v2.0):
  Message ID: msg_xxxxx
  Chat ID: oc_xxxxx
  Message Age: 15 seconds (>10s threshold)
  Create Time: 2021-08-18T11:59:45.000Z
  Current Time: 2021-08-18T12:00:00.000Z
  Message Text: /task npm test
```

## Configuration

### Thresholds
- **MAX_MESSAGE_AGE_MS**: 10000 (10 seconds)
- **Cache Expiry**: 60000 (60 seconds)
- **Cleanup Interval**: 30000 (30 seconds)

These values are currently hardcoded but could be made configurable if needed.

## Benefits

### Reliability
- Prevents duplicate task execution
- Handles webhook retry scenarios
- Maintains command idempotency

### Performance
- Reduces unnecessary processing
- Prevents queue overflow from duplicates
- Optimizes resource usage

### Debugging
- Detailed timestamp logging
- Clear rejection reasons
- Message flow traceability

## Use Cases

### Webhook Retries
When Lark retries webhook delivery:
1. First delivery processed normally
2. Retry detected as duplicate
3. Returns success without reprocessing

### Network Delays
When webhooks arrive late:
1. Message timestamp checked
2. Old messages rejected
3. User notified if interactive

### Rapid Commands
When user sends multiple commands quickly:
1. Each command gets unique message_id
2. All commands processed in order
3. No commands lost or duplicated

## Troubleshooting

### "Duplicate message detected"
**Cause**: Lark retried webhook delivery
**Resolution**: Normal behavior, no action needed

### "Stale message rejected"
**Cause**: Message delivered after 10-second threshold
**Resolution**: Check network latency, consider increasing threshold if persistent

### Messages Not Processing
1. Check daemon logs for rejection reasons
2. Verify webhook URL is accessible
3. Ensure Lark bot has proper permissions
4. Check system time synchronization

## Implementation Code Structure

### Key Components

#### HTTPServer Class
- `processedMessages`: Map storing message IDs
- `cleanupInterval`: Periodic cleanup timer
- `MAX_MESSAGE_AGE_MS`: Age threshold constant

#### Message Handlers
- `processLarkEvent()`: v1.0 message handling
- `processLarkV2Event()`: v2.0 message handling
- Both implement deduplication logic

#### Cleanup Process
```javascript
// Runs every 30 seconds
for (const [messageId, timestamp] of this.processedMessages) {
  if (now - timestamp > expiryTime) {
    this.processedMessages.delete(messageId);
  }
}
```

## Best Practices

1. **Monitor Logs**: Watch for patterns in rejected messages
2. **Time Sync**: Ensure server time is synchronized
3. **Threshold Tuning**: Adjust if seeing valid messages rejected
4. **Cache Monitoring**: Check memory usage in long-running daemons

## Future Enhancements

Potential improvements:
- Configurable thresholds via environment variables
- Persistent cache using Redis for multi-instance setups
- Metrics collection for duplicate/stale message rates
- Automatic threshold adjustment based on network conditions
- Message replay capability for debugging
# Documentation Generation Command

The `doc` command automatically generates and updates project documentation using Claude AI.

## Usage

```bash
ani-code doc [options]
```

## Options

- `-y, --yolo`: Auto-accept and execute documentation updates without prompting
- `-c, --changes-only`: Only update the daily change log
- `-a, --api-only`: Only update API documentation

## What It Does

The `doc` command performs the following tasks:

### 1. Daily Change Log
- Creates or updates `/pd/changes/YYYY-MM-DD.md`
- Fetches today's git commits
- Groups related changes together
- Includes commit hashes for reference

### 2. API Documentation
- Scans source files for API endpoints and protocols
- Updates `/pd/api/` documentation:
  - HTTP endpoints documentation
  - IPC protocol documentation
  - CLI commands documentation

### 3. Feature Documentation
- Documents new commands and capabilities
- Updates existing feature docs when behavior changes
- Creates new documentation files as needed

### 4. Architecture Documentation
- Documents system components and services
- Updates data flow documentation
- Maintains architecture diagrams

## Prerequisites

1. **Daemon Running**: The ani-code daemon must be running
   ```bash
   ani-code daemon --start
   ```

2. **CLAUDE.md File**: Project must have a CLAUDE.md configuration file with:
   - Documentation structure definition
   - Permissions for pd/ folder access
   - Instructions for documentation format

3. **pd/ Folder**: Documentation folder structure:
   ```
   pd/
   ├── README.md
   ├── api/
   ├── architecture/
   ├── changes/
   └── features/
   ```

## How It Works

1. **Checks Prerequisites**: Ensures daemon is running and structure exists
2. **Reads Git History**: Gets recent commits for change tracking
3. **Analyzes Source Code**: Scans for API changes and new features
4. **Generates Documentation**: Uses Claude to create well-formatted docs
5. **Updates Files**: Writes documentation to appropriate locations

## Examples

### Generate All Documentation
```bash
ani-code doc
```

### Auto-Accept Updates (YOLO Mode)
```bash
ani-code doc --yolo
```

### Update Only Daily Changes
```bash
ani-code doc --changes-only
```

### Update Only API Documentation
```bash
ani-code doc --api-only
```

## Integration with CI/CD

The doc command can be integrated into CI/CD pipelines:

```yaml
# Example GitHub Actions workflow
- name: Update Documentation
  run: |
    ani-code daemon --start
    ani-code doc --yolo
    git add pd/
    git commit -m "docs: auto-update documentation"
```

## Configuration

The documentation generation is configured via CLAUDE.md:

```markdown
## Documentation Structure
- `/pd/` - Project documentation root
  - `/pd/api/` - API documentation
  - `/pd/changes/` - Daily change logs (format: YYYY-MM-DD.md)
  - `/pd/architecture/` - Architecture documentation
  - `/pd/features/` - Feature documentation
```

## Best Practices

1. **Run Daily**: Execute the doc command daily to keep change logs current
2. **Review Output**: Even in YOLO mode, review generated documentation
3. **Commit Changes**: Remember to commit documentation updates to git
4. **Customize CLAUDE.md**: Tailor instructions for your project's needs

## Troubleshooting

### "Daemon is not running"
Start the daemon first:
```bash
ani-code daemon --start
```

### "pd folder not found"
Create the documentation structure:
```bash
mkdir -p pd/{api,architecture,changes,features}
```

### "CLAUDE.md not found"
Create a CLAUDE.md file with documentation instructions.
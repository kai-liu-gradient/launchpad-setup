# Daemon Management

## Overview

The ani-code daemon management system provides safe and controlled ways to manage the daemon service lifecycle. The system includes safeguards to prevent accidental interruption of running tasks.

## Safe Restart Mechanism

### Using ani-code daemon command (RECOMMENDED)

The built-in daemon restart command provides safety checks:

```bash
ani-code daemon --restart
```

This command:
1. Checks if any tasks are currently running
2. If tasks are running, stops and prompts user to manually restart
3. Only proceeds with restart if no tasks are active
4. Ensures Claude tasks are not interrupted

### Using the restart script

A utility script is provided at `/restart-daemon.sh`:

```bash
./restart-daemon.sh
```

This script performs:
1. Stops the ani-code service
2. Cleans up any leftover processes
3. Resets failed service states
4. Restarts the service
5. Verifies the service is running
6. Provides troubleshooting steps if needed

## Service Management Commands

### Check Status
```bash
ani-code daemon --status
# or
sudo systemctl status ani-code.service
```

### Start Service
```bash
ani-code daemon --start
# or
sudo systemctl start ani-code.service
```

### Stop Service
```bash
ani-code daemon --stop
# or
sudo systemctl stop ani-code.service
```

### View Logs
```bash
ani-code daemon --logs
# or
sudo journalctl -xeu ani-code.service
```

## Important Safety Notes

### DO NOT USE systemctl restart

**NEVER** use the following commands:
- `sudo systemctl restart ani-code`
- `sudo systemctl restart ani-code.service`

These commands will:
- Kill Claude (the AI assistant) immediately
- Interrupt any running tasks
- Potentially corrupt task state
- Cause loss of work

### Why Safe Restart is Important

1. **Task Protection**: Ensures running tasks complete before restart
2. **Claude Protection**: Prevents killing Claude mid-execution
3. **State Preservation**: Maintains task queue and workspace state
4. **Graceful Shutdown**: Allows proper cleanup of resources

## Troubleshooting

### Service Won't Start

1. Check for port conflicts:
```bash
lsof -i :3456  # HTTP port
lsof -i :3457  # WebSocket port
```

2. Check service logs:
```bash
sudo journalctl -xeu ani-code.service --no-pager | tail -50
```

3. Reset failed state:
```bash
sudo systemctl reset-failed ani-code.service
```

### After Restart

If workspace connections are lost after restart:

1. Clear chat settings in Lark:
```
/clear-settings
```

2. Generate a new workspace token:
```bash
ani-code workspace token gen <workspace-name> -n 'Lark'
```

3. Reconnect in Lark:
```
/connect <token>
```

### Force Cleanup

If processes are stuck:
```bash
# Kill all claude processes
sudo pkill -9 -f "claude"

# Kill all ani-code daemon processes
sudo pkill -9 -f "ani-code daemon"

# Then restart safely
ani-code daemon --restart
```

## Best Practices

1. **Always use safe restart**: Use `ani-code daemon --restart` or the script
2. **Check running tasks**: Before any restart, check if tasks are running
3. **Save work**: Ensure all important work is saved before restart
4. **Monitor after restart**: Check service status after restart
5. **Document issues**: Keep track of any restart issues for troubleshooting

## Integration with CLAUDE.md

The project's CLAUDE.md file contains critical warnings about daemon restart to ensure Claude (the AI assistant) always uses safe restart methods. This prevents accidental self-termination during task execution.
# Auto-Progress Feature

## Overview
The auto-progress feature allows workspaces to automatically trigger task progress tracking when tasks start, without requiring manual `/progress` commands in Telegram. When enabled, it automatically shows real-time git diff statistics, file changes, and task output.

## Configuration

### Setting up Auto-Progress

To enable auto-progress for a workspace:

```bash
ani-code workspace meta set showprogress auto
```

To enable auto-progress **with message pinning** (pins the progress message until task completes):

```bash
ani-code workspace meta set showprogress autopin
```

To check current setting:

```bash
ani-code workspace meta get showprogress
```

To disable auto-progress:

```bash
ani-code workspace meta remove showprogress
```

## How It Works

When `showprogress` is set to `auto` or `autopin`:

1. **Task Starts**: When a task begins execution in a Telegram chat
2. **Normal Notification**: The standard "Task Started" message is sent (3 seconds after task creation)
3. **Workspace Check**: The system checks if the task's workspace has `showprogress: auto` or `autopin`
4. **Auto-Trigger**: After a 4-second delay, a **separate** progress tracking message is sent
   - This is the same as running `/progress [taskId]` manually
   - Creates a new "📊 Task Progress" message
   - **If `autopin`**: The message is pinned to the chat immediately
5. **Progress Updates**: The progress message is updated in-place every 10 seconds with:
   - Current git diff statistics (+X additions, -Y deletions)
   - Files being modified (list of changed files)
   - Task runtime (Xm Ys)
   - Recent task output (last 5 lines)
   - Real-time progress indicators
6. **Task Completion**: When the task completes or fails:
   - **If `autopin`**: The message is automatically unpinned
   - The final task summary is shown in the progress message

## Benefits

- **No Manual Commands**: Users don't need to remember to run `/progress`
- **Automatic Tracking**: All tasks in the workspace are automatically tracked
- **Real-time Updates**: See task progress without additional commands
- **Per-Workspace Control**: Enable/disable for specific workspaces as needed
- **Message Pinning** (autopin mode): Keeps the progress message visible at the top of the chat until task completes

## Supported Platforms

Currently, auto-progress is supported for:
- ✅ Telegram chats
- ⏳ Lark support planned for future release

## Technical Details

### Implementation
- The feature is implemented in `src/task-monitor.js`
- Checks workspace settings when `taskStarted` event is emitted
- Uses the existing `handleProgressCommand` infrastructure
- Respects the same update intervals and limits as manual progress tracking

### Workspace Settings Storage
- Settings are stored in the workspace database
- Settings are JSON serialized in the `settings` column
- Retrieved via `WorkspaceManager.getWorkspaceByPath()`

## Example Usage

```bash
# Enable auto-progress for current workspace
$ ani-code workspace meta set showprogress auto
✓ Set showprogress = auto
Workspace: my-project

# Or enable with auto-pinning
$ ani-code workspace meta set showprogress autopin
✓ Set showprogress = autopin
Workspace: my-project

# Verify setting
$ ani-code workspace meta list
Metadata for workspace "my-project":
  homepage: https://example.com
  showprogress: autopin

# Now when you create a task in Telegram:
# /add Fix the login bug
# → Task starts normally
# → After 4 seconds, progress tracking automatically begins
# → Progress message is pinned (if using autopin)
# → Progress updates appear every 10 seconds
# → When task completes, message is unpinned automatically
```

## Related Commands

- `ani-code workspace meta set showprogress auto` - Enable auto-progress
- `ani-code workspace meta set showprogress autopin` - Enable auto-progress with message pinning
- `ani-code workspace meta get showprogress` - Check current setting
- `ani-code workspace meta remove showprogress` - Disable auto-progress
- `ani-code workspace meta list` - View all workspace metadata
# YOLO Mode Feature

## Overview
YOLO (You Only Live Once) mode is an automated plan execution feature that processes all pending plans sequentially, committing changes after each successful step. This feature enables hands-free execution of complex multi-step workflows with built-in workspace protection to prevent conflicts.

## How It Works

1. **Activation**: Start with `/yolo` command (Telegram/Lark) or `ani-code yolo`
2. **Validation**: Checks total pending steps don't exceed limit (33 steps)
3. **Execution**: Processes plans in FIFO order
4. **Dynamic Queue**: Automatically picks up new plans added during execution
5. **Commits**: Automatically commits after each successful step
6. **Completion**: Stops when all plans complete or on failure
7. **Interruption**: Can be stopped anytime with `/stopyolo`

## Key Features

### Dynamic Plan Queue
- Continuously monitors for new plans during execution
- Automatically adds newly created plans to the execution queue
- Notifies when new plans are detected and added
- Seamless integration without interrupting current execution
- Consistent plan ordering with proper FIFO execution

### Automatic Commit Generation
- Uses Claude Sonnet model to generate commit messages
- Analyzes changes and step description for context
- Creates meaningful, descriptive commit messages
- Includes step information in commit body

### Progress Tracking
- Real-time status updates in chat
- Shows current plan and step being executed
- Displays completion percentage
- Shows remaining plans in queue
- Notifies on failures or completion
- Cost tracking and duration statistics for batch operations

### Safety Features
- Stops on first failure to prevent cascading errors
- Can be interrupted at any time
- Preserves partial progress with commits
- Maintains clean git history
- Timeout protection and duplicate response prevention
- Task command validation before execution
- **Workspace Protection**: Prevents manual task execution while YOLO is running
- **Telegram Status Updates**: Consolidated status messages with real-time progress
- **Protection Override**: Ability to disable protection while YOLO continues

## Command Usage

### Starting YOLO Mode
```
/yolo
```

Response:
```
🚀 YOLO Mode Activated!

📋 Found 3 pending plan(s)
⚡ Will execute all plans with commits in between
➕ New plans added during execution will be picked up

Starting automatic execution...

💡 Use /stopyolo to stop execution

📋 Executing Plan #1
Title: Fix authentication
ID: plan_abc123
Steps: 5
Remaining: 2 plan(s)
```

### Stopping YOLO Mode
```
/stopyolo
```

Response:
```
🛑 YOLO Mode Stopped
━━━━━━━━━━━━━━━━━━━━
✅ Completed: 5 steps
📊 Progress: 5/12 steps
```

### Disabling Protection (While Keeping YOLO Running)
```
/disableprotection
```

Response:
```
🔓 Protection disabled - Manual tasks now allowed
⚠️ Warning: Manual changes may conflict with YOLO execution
```

## Execution Flow

```mermaid
graph TD
    A[Start YOLO Mode] --> B[Get Initial Plans]
    B --> C{Plans Available?}
    C -->|No| D[No Plans Message]
    C -->|Yes| E[Check for New Plans]
    E --> F{New Plans Added?}
    F -->|Yes| G[Notify New Plans]
    F -->|No| H[Get Next Plan]
    G --> H
    H --> I[Get Next Step]
    I --> J[Execute Step]
    J --> K{Success?}
    K -->|Yes| L[Commit Changes]
    L --> M{More Steps?}
    M -->|Yes| I
    M -->|No| N{Check Active?}
    N -->|Yes| E
    N -->|No| O[Stop Execution]
    K -->|No| P[Stop on Failure]
    C -->|Check Again| E
```

## Commit Message Format

YOLO mode generates commits with this structure:

```
[YOLO] Complete: <step description>

Plan: <plan_id>
Step: <step_number>/<total_steps>
Status: ✅ Completed

<detailed_change_description>
```

Example:
```
[YOLO] Complete: Add unit tests for login

Plan: plan_abc123
Step: 2/5
Status: ✅ Completed

Added comprehensive unit tests for the login functionality including:
- Username/password validation tests
- Session management tests
- Error handling scenarios
- Rate limiting tests
```

## Use Cases

### 1. Feature Rollout
Perfect for implementing features with multiple components:
- Database changes
- Backend implementation
- Frontend updates
- Tests
- Documentation

### 2. Large Refactoring
Systematic refactoring with automatic commits:
- Extract modules
- Update imports
- Remove legacy code
- Update tests
- Update docs

### 3. Bug Fix Pipeline
Structured bug fixing workflow:
- Reproduce issue
- Implement fix
- Add tests
- Update changelog

### 4. Deployment Preparation
Automated pre-deployment tasks:
- Run tests
- Update versions
- Build assets
- Generate docs

### 5. Continuous Development
Add plans while YOLO mode is running:
- Start YOLO with initial plans
- Add new plans as requirements come in
- YOLO automatically picks them up
- No need to restart or interrupt

## Benefits

1. **Hands-Free Execution**: Start and let it run
2. **Atomic Commits**: Each step gets its own commit
3. **Progress Preservation**: Partial completion is saved
4. **Clean History**: Well-documented git history
5. **Error Safety**: Stops on failure to prevent issues

## Limitations

1. **Sequential Only**: Can't parallelize steps
2. **No Rollback**: Commits are made immediately
3. **Requires Clean State**: Works best with clean git status
4. **Network Dependent**: Needs stable connection for long runs
5. **Step Limit**: Maximum 33 total pending steps across all plans

## Best Practices

1. **Test First**: Run plans manually before YOLO
2. **Small Steps**: Keep steps atomic and focused
3. **Clean Working Directory**: Start with no uncommitted changes
4. **Monitor Progress**: Watch for failures or issues
5. **Review Commits**: Check generated commits afterward

## Error Handling

YOLO mode handles errors gracefully:

1. **Task Failure**: Stops execution, preserves completed steps
2. **Commit Failure**: Notifies user, stops execution
3. **Network Issues**: Retries with timeout, then stops
4. **User Interruption**: Cleanly stops at current step
5. **Step Limit Exceeded**: Prevents start if total pending steps > 33

## Configuration

Currently, YOLO mode uses these defaults:
- Model: Claude Sonnet for commit messages
- Timeout: Standard task timeout
- Retry: No automatic retry on failure
- Commit: Always commits on success
- Step Limit: 33 steps maximum

### Step Limit Validation

YOLO mode validates the total number of pending steps before starting:

**Maximum Steps**: 33 total steps across all pending plans

**Validation Logic**:
```javascript
const totalPendingSteps = plans.reduce((sum, plan) => {
  const steps = typeof plan.steps === 'string' ? JSON.parse(plan.steps) : plan.steps;
  return sum + steps.length;
}, 0);
```

**Error Message**:
```
✗ Cannot start YOLO mode: Total pending steps (45) exceeds limit of 33

💡 To reduce pending steps:
  • Complete or cancel some plans first
  • Break large plans into smaller chunks
  • Execute plans individually with: ani-code execute <plan-id>
```

**Why This Limit?**
- Prevents overwhelming Claude with too many sequential tasks
- Maintains better control over execution flow
- Encourages breaking down large plans into manageable chunks
- Improves success rate and reduces risk of long-running failures

**Workarounds**:
1. Complete or cancel some existing plans
2. Break large plans into smaller, more focused plans
3. Execute plans individually using `ani-code execute <plan-id>`
4. Run YOLO in batches instead of all at once

## Security Considerations

1. **Code Review**: YOLO commits directly, review afterward
2. **Permissions**: Requires git write access
3. **Sensitive Data**: Be cautious with automated commits
4. **Branch Protection**: Consider using feature branches

## Workspace Protection

### How It Works

When YOLO mode is activated:
1. **Workspace Lock**: The workspace is marked as protected in the database
2. **Telegram Protection**: The chat ID is tracked to prevent task updates
3. **Manual Task Block**: New manual tasks are rejected while YOLO is active
4. **Status Message**: A consolidated status message tracks all progress

### Protection Features

- **Automatic Enable**: Protection activates when YOLO starts
- **Automatic Disable**: Protection clears when YOLO completes or stops
- **Manual Override**: Can be disabled with `/disableprotection` command
- **Status Tracking**: Real-time status updates without spam

### Telegram Integration

YOLO mode now includes enhanced Telegram integration:

1. **Consolidated Status Message**
   - Single message that updates in place
   - Shows current plan, step, and overall progress
   - Includes protection status indicator

2. **Protection Status**
   ```
   🚀 YOLO Mode - workspace_name
   ━━━━━━━━━━━━━━━━━━━━
   📋 Plan #1: Fix authentication
   📍 Step 2/5: Add unit tests
   📊 Progress: 7/15 steps total
   🔒 Protection: ENABLED
   ```

3. **Commit Tracking**
   - Shows list of commits made during execution
   - Displays commit hashes and messages
   - Updates in real-time as commits are made

### Status Message Format

```
🚀 YOLO Mode - workspace_name
━━━━━━━━━━━━━━━━━━━━
📋 Plan #2: Implement feature X
📍 Step 3/4: Update documentation
📊 Progress: 8/12 steps total
🔒 Protection: ENABLED
⏱️ Duration: 5m 23s

📝 Commits:
• abc1234: Add authentication module
• def5678: Implement login tests
• ghi9012: Update documentation
```
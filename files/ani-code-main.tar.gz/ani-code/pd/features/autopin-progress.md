# Auto-Pin Progress Feature

## Overview
The auto-pin feature extends the auto-progress functionality by automatically pinning task progress messages in Telegram until the task completes or fails. This ensures the progress message stays visible at the top of the chat.

## Implementation Details

### Files Modified
1. **src/telegram-api.js**
   - Added `pinChatMessage(chatId, messageId, options)` method
   - Added `unpinChatMessage(chatId, messageId, options)` method
   - Both methods support retry logic and proper error handling

2. **src/http-server.js**
   - Modified progress tracker initialization to check for `autopin` setting
   - Added `isPinned` flag to tracker object
   - Pin message immediately after sending initial progress message
   - Unpin and re-pin when recalling messages (message recall every 5 minutes)

3. **src/task-monitor.js**
   - Updated auto-progress trigger to recognize both `auto` and `autopin` values
   - Unpin messages when tasks complete successfully
   - Unpin messages when tasks are cancelled or fail

4. **src/commands/workspace.js**
   - Updated documentation to include `autopin` option

5. **pd/features/auto-progress.md**
   - Updated documentation with autopin usage examples
   - Added benefits section for message pinning

## Usage

### Enable Auto-Pin for Workspace

```bash
ani-code workspace meta set showprogress autopin
```

### How It Works

1. When a task starts in a workspace with `showprogress: autopin`:
   - Normal "Task Started" notification is sent
   - After 5 seconds, progress tracking message is sent
   - **Progress message is pinned immediately** with `disable_notification: true`

2. During task execution:
   - Progress message updates every 10 seconds with task status
   - If message is recalled (every 5 minutes to stay at top):
     - Old message is unpinned
     - New message is sent
     - New message is pinned

3. When task completes or fails:
   - **Progress message is unpinned automatically**
   - Final task summary is shown in the message

### Telegram API Methods

#### Pin Message
```javascript
await telegramAPI.pinChatMessage(chatId, messageId, {
  disable_notification: true  // Don't notify users about the pin
});
```

#### Unpin Message
```javascript
await telegramAPI.unpinChatMessage(chatId, messageId);
```

### Configuration Options

| Value | Behavior |
|-------|----------|
| `auto` | Auto-show progress messages, no pinning |
| `autopin` | Auto-show progress messages **and pin them** until completion |
| (not set) | No automatic progress tracking |

## Benefits

1. **Always Visible**: Progress messages stay at the top of the chat
2. **Automatic Cleanup**: Messages are unpinned when tasks complete
3. **Silent Pinning**: Uses `disable_notification: true` to avoid spamming users
4. **Backward Compatible**: Existing `auto` mode continues to work unchanged

## Technical Notes

### Pin/Unpin Error Handling
- All pin/unpin operations use try-catch blocks
- Failures are logged as warnings, not errors
- Progress tracking continues even if pin/unpin fails
- Bot needs admin permissions to pin messages in groups

### Message Recall Behavior
When a progress message is recalled (every 5 minutes):
1. Unpin old message
2. Delete old message
3. Send new message
4. Pin new message

This ensures the pinned message is always the latest one.

### Tracker Object Structure
```javascript
{
  chatId: string,
  taskId: string,
  messageId: number,
  startTime: number,
  updateCount: number,
  lastRecallTime: number,
  interval: NodeJS.Timeout | null,
  isPinned: boolean  // NEW: tracks if message is pinned
}
```

## Testing

To test the feature:

1. Enable autopin for a workspace:
   ```bash
   ani-code workspace meta set showprogress autopin
   ```

2. Create a task from Telegram:
   ```
   /add do something
   ```

3. Verify:
   - Progress message appears after 5 seconds
   - Message is pinned at the top of the chat
   - Message updates every 10 seconds
   - When task completes, message is unpinned

## Limitations

- Bot must have administrator privileges to pin messages in groups
- Only works in Telegram (Lark support planned)
- Maximum one pinned message per chat (Telegram API limitation)

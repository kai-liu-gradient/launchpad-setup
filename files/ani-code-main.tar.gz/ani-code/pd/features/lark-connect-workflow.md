# Lark Connect Workflow

## Overview
The `/connect` command provides a seamless way to link Lark chats to workspaces using JWT tokens. This eliminates the need to manually find and configure chat IDs.

## Workflow

### 1. Generate a Token (Command Line)
```bash
# Create workspace if not exists
ani-code workspace create my-project

# Generate token for Lark connection
ani-code workspace token gen my-project -n "Lark Bot"
```

### 2. Connect in Lark
In your Lark chat, simply use:
```
@AniCode Bot /connect <token>
```

The bot will:
- Validate the token
- Automatically map the current chat to the workspace
- Confirm the connection with workspace details

### 3. Verify Connection (Optional)
```bash
# View all chat-workspace mappings
ani-code workspace chat show
```

## Commands

### Lark Commands
- `/connect <token>` - Connect current chat to a workspace
- `/token <token>` - Alias for /connect
- `/help` - Show available commands

### CLI Commands
- `ani-code workspace token gen <workspace>` - Generate token
- `ani-code workspace chat show` - View chat mappings
- `ani-code workspace info` - Show workspace details

## Security Features

### Token Properties
- JWT-based authentication
- Workspace-scoped permissions
- Optional expiration dates
- One token can connect multiple chats

### Validation
- Token signature verification
- Workspace existence check
- Permission validation
- Automatic chat ID extraction

## Benefits

### User Experience
- No need to find chat IDs manually
- Simple copy-paste workflow
- Immediate visual feedback
- Persistent connections

### Security
- Tokens never expose chat IDs
- Controlled workspace access
- Revocable permissions
- Audit trail in database

## Example Session

```bash
# 1. Developer generates token
$ ani-code workspace token gen frontend-app -n "Team Chat"
✓ Token generated successfully:
  eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

# 2. In Lark chat
@AniCode Bot /connect eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

# Bot responds:
✅ Workspace Connected
Successfully connected this chat to workspace:
**frontend-app**
📁 /home/projects/frontend
🔑 Token: api (read, write)
All future tasks from this chat will run in this workspace.

# 3. Verify connection
$ ani-code workspace chat show
┌──────────────┬──────────────┬───────────────────┬─────────────┐
│ Chat ID      │ Workspace    │ Path              │ Created     │
├──────────────┼──────────────┼───────────────────┼─────────────┤
│ oc_abc123... │ frontend-app │ /home/projects... │ 2025-08-28  │
└──────────────┴──────────────┴───────────────────┴─────────────┘
```

## Migration from Legacy

The old manual mapping command still exists but is deprecated:
```bash
# Old way (deprecated - requires finding chat ID)
ani-code workspace chat map <chat-id> <workspace>

# New way (recommended)
# Just use /connect in Lark with a token
```

## Troubleshooting

### Token Invalid
- Check token hasn't expired
- Verify workspace still exists
- Ensure token wasn't revoked

### Connection Failed
- Verify ani-code daemon is running
- Check network connectivity
- Review logs: `ani-code daemon logs`

### Wrong Workspace
- Revoke old token: `ani-code workspace token revoke <id>`
- Generate new token for correct workspace
- Use /connect with new token
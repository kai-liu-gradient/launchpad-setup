# Provider Output Extraction

## Overview

The ani-code system now automatically extracts concise conclusions and token usage from verbose CLI provider outputs. This feature specifically targets providers like Codex and Cursor Agent that include extensive metadata, thinking processes, and diagnostic information in their responses.

## Problem Statement

CLI providers like Codex and Cursor Agent output verbose information including:
- Header metadata (version, config, model settings)
- User instructions
- Thinking/reasoning process
- **The actual answer** (buried in the output)
- Token usage statistics
- Timing information

For example, a simple question "what is 2+2?" from Codex generates 429 characters of output when the actual answer is just "4".

## Solution

### Output Extractor Module

Location: `src/providers/outputExtractor.js`

The module provides three main functions:

#### 1. `extractCodexConclusion(output)`

Extracts the actual response from Codex output by:
- Locating the model response marker (timestamp + "codex")
- Extracting content between the marker and "tokens used" line
- Returning only the actual answer

**Example:**
```
Input (429 chars):
[2025-10-01T07:53:59] OpenAI Codex v0.36.0...
--------
workdir: /root/workspace
model: gpt-5-codex
...
[2025-10-01T07:54:02] codex

4

[2025-10-01T07:54:02] tokens used: 2,371

Output (1 char):
4
```

#### 2. `extractCursorConclusion(output)`

Extracts the conclusion from Cursor Agent output using two strategies:

**Strategy A**: Look for explicit conclusion markers
- "Answer:", "Result:", "Conclusion:", "Summary:", etc.
- Extract everything after the marker

**Strategy B**: If no marker found
- Extract the last meaningful paragraph
- Assumes the conclusion is at the end of the output

#### 3. `extractProviderConclusion(output, providerId)`

Generic function that routes to the appropriate extractor based on provider ID:
- `codex` → `extractCodexConclusion()`
- `cursor` → `extractCursorConclusion()`
- Others (claude, deepseek) → return output unchanged

#### 4. Token Extraction Functions

The module also provides token extraction functions:

**`extractCodexTokens(output)`**
- Extracts token count from Codex output format: `[timestamp] tokens used: 197,255`
- Returns the total token count as a number, or null if not found
- Handles comma-separated numbers (e.g., "197,255" → 197255)

**`extractCursorTokens(output)`**
- Extracts token count from Cursor output using multiple patterns:
  - `tokens used: 12345`
  - `tokens: 12345`
  - `Total tokens: 12345`
  - `token_count: 12345`
- Returns the total token count as a number, or null if not found

**`extractProviderTokens(output, providerId)`**
- Generic function that routes to the appropriate token extractor:
  - `codex` → `extractCodexTokens()`
  - `cursor` → `extractCursorTokens()`
  - Others → returns null (they use ccusage API)

## Token Integration

Extracted tokens are automatically merged into `taskUsage` objects:

1. **Token Extraction**: Tokens are extracted from raw provider output before conclusion extraction
2. **Storage**: Extracted tokens are stored in `task.parsedTokens`
3. **Merge**: After task completion, parsed tokens are merged into `task.usage`:
   - If `taskUsage` doesn't exist, a basic usage object is created
   - If `taskUsage.tokens` is zero or missing, parsed tokens are used
   - For codex/cursor providers, parsed tokens override ccusage tokens (since they don't use ccusage API)

## Integration

### Task Queue Integration

Location: `src/task-queue.js`

The extraction is applied automatically during task completion:

```javascript
// Import the extractor
import { extractProviderConclusion, extractProviderTokens } from './providers/outputExtractor.js';

// In child.on('close') handler:
let combinedOutput = finalOutput || finalError || '';

// Extract tokens from provider output (codex, cursor) before extracting conclusion
if (!task.command.startsWith('shell:') && task.providerId) {
  const extractedTokens = extractProviderTokens(combinedOutput, task.providerId);
  if (extractedTokens !== null) {
    task.parsedTokens = extractedTokens;
  }
  
  // Extract conclusion from verbose provider outputs
  combinedOutput = extractProviderConclusion(combinedOutput, task.providerId);
}

// Later, after task completion snapshot:
// Merge parsed tokens into taskUsage
if (task.parsedTokens !== undefined && task.parsedTokens !== null) {
  if (!task.usage) {
    task.usage = { /* basic usage object */ };
  }
  if (!task.usage.tokens || task.usage.tokens === 0) {
    task.usage.tokens = task.parsedTokens;
  }
}
```

**Key Points:**
- Only applies to non-shell commands
- Requires `providerId` to be set on the task
- Tokens are extracted before conclusion extraction
- Preserves full output in log files for debugging
- Returns original output if extraction fails
- Tokens are merged into taskUsage after completion snapshot

### Provider Flow

1. **Provider Detection**: User sends `@@codex what is 2+2`
2. **Provider Extraction**: `extractProviderFromPrompt()` returns `'codex'`
3. **Task Creation**: `taskOptions.providerId = 'codex'`
4. **Task Execution**: Codex handler runs the command
5. **Output Capture**: Raw output (429 chars) captured in buffer
6. **Token Extraction**: `extractProviderTokens()` extracts token count (e.g., 197,255)
7. **Conclusion Extraction**: `extractProviderConclusion()` extracts "4"
8. **Token Merge**: Parsed tokens merged into `taskUsage` after completion snapshot
9. **User Display**: User sees just "4" (1 char) with token count in usage stats

## Testing

### Unit Tests

Location: `tests/manual/test-output-extraction.js`

Tests cover:
- Codex extraction with real output format
- Cursor extraction with explicit markers
- Cursor extraction without markers (last paragraph)
- Generic provider extraction routing
- Unknown provider passthrough (returns original)

**Run tests:**
```bash
node tests/manual/test-output-extraction.js
```

**Expected results:**
```
✓ Codex extraction: 429 chars → 1 char ("4")
✓ Cursor with marker: Extracts content after "Answer:"
✓ Cursor without marker: Extracts last paragraph
✓ Provider routing: Correct function called for each provider
✓ Unknown provider: Returns original output unchanged
```

## Configuration

No configuration required. The feature works automatically for all tasks with a `providerId` set.

### Supported Providers

| Provider | Conclusion Extraction | Token Extraction | Status |
|----------|----------------------|------------------|--------|
| codex | ✅ Enabled | ✅ Enabled | Extracts answer and tokens from output |
| cursor | ✅ Enabled | ✅ Enabled | Extracts using markers and token patterns |
| claude | ❌ Disabled | ❌ Disabled | Uses ccusage API for tokens |
| deepseek | ❌ Disabled | ❌ Disabled | Uses claude binary, uses ccusage API |

## Benefits

1. **Cleaner Output**: Users see only the answer, not metadata
2. **Reduced Noise**: Eliminates verbose diagnostic information
3. **Faster Reading**: 400+ chars reduced to actual answer
4. **Token Tracking**: Automatic token extraction for codex and cursor providers
5. **Preserved Logs**: Full output still saved to log files
6. **Automatic**: No user configuration required
7. **Safe Fallback**: Returns original output if extraction fails

## Future Enhancements

1. **Custom Extractors**: Allow providers to define custom extraction patterns
2. **Configurable**: Add flag to disable extraction if user wants full output
3. **More Providers**: Add extraction support for additional CLI providers
4. **Smart Detection**: Automatically detect output format without provider ID
5. **Streaming**: Apply extraction to streaming output in real-time

## Related Files

- `src/providers/outputExtractor.js` - Core extraction logic (conclusion and tokens)
- `src/task-queue.js` - Integration point (lines 9, 660-672, 341-370)
- `src/providers/codexCliHandler.js` - Codex provider handler
- `src/providers/cursorCliHandler.js` - Cursor provider handler
- `tests/manual/test-output-extraction.js` - Unit tests for conclusion extraction
- `test-token-extraction.js` - Unit tests for token extraction
- `src/model-utils.js` - Provider detection from prompts

## See Also

- [Provider Detection System](../PROVIDER_DETECTION_CHANGES.md)
- [CLI Provider Configuration](../pd/cli-provider-configuration.md)
- [Model Utils Documentation](../pd/api/model-utils.md)

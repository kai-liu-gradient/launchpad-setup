# Lark Bot Integration

Ani-code provides comprehensive Lark bot integration for remote task execution and monitoring.

## Features Overview

- **Remote Task Execution**: Run commands via Lark messages
- **Interactive UI**: Clickable buttons for common actions
- **Working Directory Management**: Per-chat directory configuration
- **Real-time Notifications**: Task status updates with emojis
- **Group Chat Support**: Works in both private and group chats

## Setup

### 1. Environment Configuration

Add to your `.env` file:

```bash
# Lark Bot Credentials
LARK_APP_ID=cli_xxxxx
LARK_APP_SECRET=xxxxx
LARK_WEBHOOK_URL=https://open.larksuite.com/open-apis/bot/v2/hook/xxxxx
LARK_VERIFICATION_TOKEN=xxxxx  # Optional, for webhook security

# Working Directories (project_name:path pairs)
LARK_WORKDIRS=project1:/path/to/project1,project2:/path/to/project2

# Group Chat IDs (optional, for notifications)
LARK_GROUP_CHAT_ID=oc_xxxxx

# Notification Settings
LARK_NOTIFICATION_ENABLED=true
LARK_NOTIFY_SUCCESS=true
LARK_NOTIFY_FAILURE=true
LARK_NOTIFY_START=false

# Timezone for timestamps
TIMEZONE=America/Los_Angeles
```

### 2. Webhook Configuration

Configure your Lark bot to send webhooks to:
```
http://your-server:3456/callback/lark
```

## Commands

### Help Command
Shows available commands with interactive buttons.

```
/help
```

**Features**:
- Lists all available commands
- Shows current working directory
- Provides quick action buttons
- Displays clickable command examples

### Working Directory Management

#### List Directories
```
/workdir
/wd
```

Shows:
- Current selected directory
- All available directories
- Selection status with ✅

#### Set Directory
```
/workdir project1
/wd project1
```

**Important**:
- Required before running tasks
- Persistent per chat
- Auto-selects first available in private chats

### Task Execution

#### Run Task
```
/task npm test
/run echo "Hello World"
```

**Requirements**:
- Working directory must be set
- Command runs asynchronously
- Notifications sent on completion

#### Force Default Directory
```
/task! npm test
/run! echo "Hello"
```

Uses daemon's default working directory.

### Task Management

#### View Status
```
/status
```

Shows:
- Running tasks count
- Pending tasks count
- Task IDs and names

#### Cancel Task
```
/cancel task-id
```

Stops a running or pending task.

### Statistics
```
/stats
```

Shows chat configuration statistics and workdir usage.

## Interactive Buttons

Lark messages include clickable buttons for:

### Quick Setup
- **Set Directory**: Choose from available workdirs
- **Show Status**: View current tasks
- **List Directories**: See all available paths

### Task Actions
- **Cancel**: Stop a running task
- **Retry**: Re-run a failed task
- **View Logs**: See task output

### Example Actions
- **Run Tests**: Execute `npm test`
- **Build Project**: Run `npm run build`
- **Deploy**: Execute deployment scripts

## Notifications

### Task Start (Optional)
```
🚀 Task Started
Task ID: abc123
Command: npm test
Directory: /path/to/project
```

### Task Success
```
✅ Task Completed
Task ID: abc123
Duration: 2.5 seconds
Exit Code: 0
```

### Task Failure
```
❌ Task Failed
Task ID: abc123
Duration: 1.2 seconds
Exit Code: 1
Error: Test suite failed
```

### With Spending Context
Includes daily and monthly API usage costs when available.

## Group Chat Features

### Behavior Differences
- **Private Chats**: Auto-select first workdir if not set
- **Group Chats**: Require explicit workdir selection
- **Chat IDs**: Automatically logged for configuration

### Setting Up Groups
1. Add bot to group chat
2. Send any message to get chat ID
3. Add chat ID to `.env` as `LARK_GROUP_CHAT_ID`

## Message Format

### Mentions
Bot responds to:
- Direct commands: `/task`, `/help`, etc.
- @mentions: `@AniCodeBot help`
- Card button interactions

### Command Parsing
- Strips HTML tags and mentions
- Supports multi-word arguments
- Handles quoted strings

## Security

### Verification Token
Optional token validation for webhooks:
- Set `LARK_VERIFICATION_TOKEN` in `.env`
- Bot verifies token on each request
- Returns 401 if token mismatch

### Access Control
- Working directories limit file system access
- Commands execute with daemon user permissions
- No arbitrary directory traversal

## Troubleshooting

### "Working directory not selected"
Select a directory first:
```
/workdir project-name
```

### "No working directories configured"
Add `LARK_WORKDIRS` to `.env`:
```
LARK_WORKDIRS=project:/path/to/project
```

### "Bot not responding"
1. Check webhook URL configuration
2. Verify daemon is running
3. Check HTTP server logs
4. Ensure bot has message permissions

### Getting Chat IDs
Send a message in the target chat, check logs for:
```
📍 Message from CHAT ID: oc_xxxxx
Add this to your .env file as LARK_GROUP_CHAT_ID=oc_xxxxx
```

## Best Practices

1. **Set Workdirs Carefully**: Only include trusted directories
2. **Use Groups for Teams**: Share task execution across team
3. **Monitor Logs**: Check daemon logs for issues
4. **Test Commands**: Try commands locally first
5. **Set Timeouts**: Use task timeouts for long-running commands
# Git Status Integration

Ani-code now provides comprehensive git repository status integration within the Lark bot interface, making it easy to manage code changes directly from chat.

## Overview

The `/status` command has been enhanced to include real-time git repository information alongside task status, providing a complete view of your project state.

## Features

### Git Status Display
When running `/status` in a directory with a git repository:

- **Staged Files**: Shows count and lists up to 3 files ready for commit
- **Modified Files**: Displays uncommitted changes count and file names
- **Untracked Files**: Shows new files not yet added to git
- **Clean State**: Indicates when working tree is clean

### Smart Action Buttons

The system intelligently shows relevant git action buttons based on repository state:

#### Stage All Button
- **Appears when**: Modified files exist but nothing is staged
- **Action**: Runs `git add .` to stage all changes
- **Button**: "📦 Stage All" (Primary style)

#### AI Commit Button
- **Appears when**: Files are staged and ready to commit
- **Action**: Runs `ani-code commit -y` for AI-generated commit message
- **Button**: "💾 AI Commit" (Primary style)

#### Push Button
- **Appears when**: Files are staged (likely with commits to push)
- **Action**: Runs `git push` to push to remote
- **Button**: "📤 Push" (Default style)

#### Diff Button
- **Appears when**: Any changes exist (staged or modified)
- **Action**: Runs `git diff --stat` to show change statistics
- **Button**: "🔍 Diff" (Default style)

### Refresh Button
Every status display includes a refresh button for real-time updates:
- **Button**: "🔄 Refresh"
- **Action**: Re-generates status with current git state

## Message Format

### With Changes
```
📊 Task Status:
• Running: 1
• Pending: 2

🔄 task-id: Task name

📁 Git Status (project-name):
✅ Staged: 2 files
  • src/index.js
  • package.json
📝 Modified: 1 file
  • README.md
❓ Untracked: 3 files

[AI Commit] [Push] [Diff] [Refresh]
```

### Clean Repository
```
📊 Task Status:
• Running: 0
• Pending: 0

✨ Git: Working tree clean in project-name

[Refresh]
```

### Not a Git Repository
```
📊 Task Status:
• Running: 1
• Pending: 0

⚠️ project-name is not a git repository

[Refresh]
```

## Implementation Details

### File Count Limits
To keep messages readable:
- Lists individual files when count ≤ 3
- Shows only count when > 3 files
- Applies to staged, modified, and untracked separately

### Performance
- Git commands run with 5-second timeout
- Executed asynchronously to avoid blocking
- Cached per chat session when possible

### Error Handling
- Gracefully handles non-git directories
- Logs git command failures for debugging
- Falls back to basic status if git fails

## Command Integration

### AI Commit Workflow
The "AI Commit" button triggers:
1. Stages all changes if needed
2. Generates commit message using Claude
3. Creates commit with generated message
4. No user interaction required (YOLO mode)

### Direct Commands
All git actions are also available as commands:
- Stage: `/run git add .`
- Commit: `/run ani-code commit -y`
- Push: `/run git push`
- Diff: `/run git diff --stat`

## Configuration

No additional configuration required. The feature automatically:
- Detects git repositories in working directories
- Uses the selected workdir's git context
- Respects existing git configuration

## Use Cases

### Quick Commit Workflow
1. Make changes to code
2. Run `/status` to see changes
3. Click "Stage All" if needed
4. Click "AI Commit" for automatic commit
5. Click "Push" to push to remote

### Review Before Commit
1. Run `/status` to see file changes
2. Click "Diff" to see detailed changes
3. Manually stage specific files if needed
4. Proceed with commit

### Monitor Repository State
- Use `/status` periodically to track changes
- Click "Refresh" for real-time updates
- See at a glance what needs attention

## Best Practices

1. **Review Changes**: Use Diff button before committing
2. **Frequent Status Checks**: Keep track of repository state
3. **Atomic Commits**: Stage related changes together
4. **Clear Working Tree**: Commit or stash before switching tasks

## Limitations

- Shows git status for selected workdir only
- Requires git to be installed on the system
- Button actions have 30-second timeout
- Large repositories may take longer to process

## Future Enhancements

Potential improvements under consideration:
- Branch information display
- Commit history preview
- Selective file staging
- Pull/fetch integration
- Stash management
- Merge conflict indicators
# Chrome Bridge Plugin Setup Guide

## Overview
The Chrome Bridge Plugin enables WebSocket communication between your Chrome browser and the AniCode daemon, allowing for browser-based interactions with your development environment.

## Prerequisites
- AniCode daemon running (`ani-code daemon start`)
- Chrome browser with the AniCode extension installed
- Access to the project directory where you want to establish connection

## Setup Instructions

### 1. Generate Connection Token

Navigate to your project directory and generate a new connection token:

```bash
node src/index.js plugin new-token
```

**Output Example:**
```
============================================================
🔐 Chrome Plugin Connection Token Generated
============================================================

Project:     ani-code
Path:        /root/workspace/ani-code
Server:      ws://localhost:6502
Expires:     [7 days from generation]

📋 Copy this token to your Chrome plugin:

------------------------------------------------------------
[BASE64_PAYLOAD].[SIGNATURE].[SECRET]
------------------------------------------------------------

Instructions:
1. Click the AniCode extension icon in Chrome
2. Paste this token in the "Connection Token" field
3. Click "Connect" to establish connection

⚠️  This token expires in 7 days
⚠️  Keep this token secure - it provides access to your project
```

### 2. Configure Server URL (Optional)

For custom server configurations, set environment variables before generating the token:

```bash
# For external/remote connections
export ANICODE_EXTERNAL_URL="ws://your-server:6502"

# Alternative server configuration
export ANICODE_SERVER_URL="ws://your-server:6502"

# Then generate token
node src/index.js plugin new-token
```

### 3. Connect Chrome Extension

1. **Open Chrome Extension**
   - Click the AniCode extension icon in your Chrome toolbar
   - If not visible, check the Extensions menu (puzzle piece icon)

2. **Enter Connection Details**
   - Paste the entire generated token into the "Connection Token" field
   - The token includes all necessary connection information (server URL, project path, authentication)

3. **Establish Connection**
   - Click the "Connect" button
   - The extension will validate the token and establish a WebSocket connection
   - You should see a success indicator when connected

## Token Management

### List Active Tokens
View all active tokens for your projects:

```bash
node src/index.js plugin list
```

Output shows:
- Token ID (first 8 characters)
- Associated project and path
- Creation and expiration dates
- Status (ACTIVE or EXPIRED)

### Revoke Tokens
Remove a specific token by its ID:

```bash
node src/index.js plugin revoke <token-id>
```

Note: You only need to provide the first few characters of the token ID.

### Revoke All Tokens
Remove all active tokens at once:

```bash
node src/index.js plugin revoke-all
```

This command:
- Clears all stored tokens from `~/.anicode/plugin-tokens.json`
- Invalidates all existing Chrome plugin connections
- Useful for security resets or when multiple tokens need to be revoked

### Token Security

- **Expiration**: Tokens automatically expire after 7 days
- **Project-Specific**: Each token is tied to a specific project directory
- **Local Storage**: Tokens are stored in `~/.anicode/plugin-tokens.json`
- **Validation**: Tokens use HMAC-SHA256 signatures for integrity

## Architecture

### Token Structure
Tokens consist of three parts separated by dots:
1. **Payload** (Base64): Contains project info, server URL, timestamps
2. **Signature** (Hex): HMAC-SHA256 signature for validation
3. **Secret** (Hex): Used for signature generation and verification

### Communication Flow
1. Chrome extension connects to WebSocket server using token
2. Server validates token signature and expiration
3. Established connection allows bidirectional communication
4. Plugin can send commands and receive responses from AniCode daemon

## Troubleshooting

### Connection Issues

1. **Token Expired**
   - Generate a new token using `plugin new-token`
   - Tokens expire after 7 days for security

2. **Server Not Reachable**
   - Verify AniCode daemon is running: `ani-code daemon status`
   - Check firewall settings for port 6502
   - Confirm server URL matches your configuration

3. **Invalid Token Format**
   - Ensure you copied the entire token including all three parts
   - Token should look like: `[base64].[hex].[hex]`

4. **Project Path Mismatch**
   - Token is tied to the directory where it was generated
   - Generate a new token from the correct project directory

### Chrome Extension Issues

1. **Extension Not Visible**
   - Check Chrome Extensions page (chrome://extensions)
   - Ensure extension is enabled
   - Pin extension to toolbar for easy access

2. **Connection Fails Silently**
   - Open Chrome DevTools for the extension
   - Check console for error messages
   - Verify WebSocket support in your network

## Security Considerations

1. **Token Handling**
   - Never share tokens publicly or commit them to version control
   - Tokens provide full access to the specified project directory
   - Revoke unused or compromised tokens immediately

2. **Network Security**
   - Use secure WebSocket (wss://) for production environments
   - Configure firewall rules to restrict access to trusted sources
   - Consider using VPN for remote connections

3. **Token Rotation**
   - Regularly generate new tokens (weekly recommended)
   - Remove expired tokens using the list command
   - Monitor active tokens for unauthorized access

## Related Documentation

- [HTTP Endpoints](/pd/api/http-endpoints.md) - REST API documentation
- [System Overview](/pd/architecture/system-overview.md) - Architecture details
- [WebSocket Bridge Source](/chrome-plugin/src/wsBridge.js) - Implementation details
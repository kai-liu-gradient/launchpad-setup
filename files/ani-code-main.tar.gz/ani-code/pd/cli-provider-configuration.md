# CLI Provider Configuration System

## Overview

The ani-code CLI now supports configurable providers for AI-powered coding assistance. This allows you to switch between different AI providers like Claude, Cursor, OpenAI Codex, or any Claude-compatible CLI (such as CCR) while maintaining a consistent interface.

## Architecture

### Provider System Components

```
src/providers/
├── baseCliHandler.js       # Abstract base class for all providers
├── claudeCliHandler.js     # Claude Code implementation
├── cursorCliHandler.js     # Cursor AI implementation
├── codexCliHandler.js      # OpenAI Codex implementation
└── providerManager.js      # Provider management and configuration
```

### Key Concepts

1. **Handler**: A class that implements the interface for interacting with a specific AI CLI tool
2. **Provider**: A configured instance of a handler with specific settings
3. **Provider Manager**: Singleton that manages provider configuration and switching

## Configuration

### Environment Variables

Providers are configured via environment variables in `.env`:

```bash
# Default provider selection
CLI_PROVIDER_ID=claude

# Claude Configuration (Default)
CLI_PROVIDER_CLAUDE_NAME=Claude Code
CLI_PROVIDER_CLAUDE_HANDLER=claude
CLI_PROVIDER_CLAUDE_BINARY=/usr/bin/claude
CLI_PROVIDER_CLAUDE_ARGS=--high-quality
CLI_PROVIDER_CLAUDE_ENV={"CLAUDE_API_KEY": "sk-xxx"}
```

### Configuration Format

Each provider uses the pattern:
- `CLI_PROVIDER_{ID}_NAME` - Display name
- `CLI_PROVIDER_{ID}_HANDLER` - Handler type (claude, cursor, codex, customClaude)
- `CLI_PROVIDER_{ID}_BINARY` - Executable path or command
- `CLI_PROVIDER_{ID}_ARGS` - Additional arguments (space-separated or JSON array)
- `CLI_PROVIDER_{ID}_ENV` - Environment variables (JSON object or key=value format)

## Built-in Providers

### 1. Claude (Default)

```bash
CLI_PROVIDER_ID=claude
CLI_PROVIDER_CLAUDE_NAME=Claude Code
CLI_PROVIDER_CLAUDE_HANDLER=claude
CLI_PROVIDER_CLAUDE_BINARY=/usr/bin/claude
```

**Features:**
- Full support for --print mode (non-interactive)
- Greenlight mode (--greenlight) for auto-approval
- Model selection (sonnet, haiku, opus, custom)
- Continue conversations (-c flag)

### 2. Cursor Agent

```bash
CLI_PROVIDER_ID=cursor
CLI_PROVIDER_CURSOR_NAME=Cursor Agent
CLI_PROVIDER_CURSOR_HANDLER=cursor
CLI_PROVIDER_CURSOR_BINARY=cursor-agent
CLI_PROVIDER_CURSOR_ENV={"CURSOR_API_KEY": "your-api-key"}
```

**Features:**
- Print mode for non-interactive output (--print)
- Resume sessions (--resume)
- Force mode for auto-approval (--force)
- Model selection (gpt-5, sonnet-4, sonnet-4-thinking)
- Output formats: text, json, stream-json
- Shell integration support

### 3. OpenAI Codex

```bash
CLI_PROVIDER_ID=codex
CLI_PROVIDER_CODEX_NAME=OpenAI Codex
CLI_PROVIDER_CODEX_HANDLER=codex
CLI_PROVIDER_CODEX_BINARY=codex
CLI_PROVIDER_CODEX_ARGS=["--sandbox", "workspace-write"]
CLI_PROVIDER_CODEX_ENV={"CODEX_ENABLE_SEARCH": "true"}
```

**Features:**
- Exec subcommand for non-interactive execution
- Resume sessions (resume --last)
- Full-auto mode (--full-auto) for sandboxed automatic execution
- Sandbox policies: read-only, workspace-write, danger-full-access
- Web search capability (--search)
- Model selection support
- Working directory control (--cd)

### 4. CustomClaude (For Claude-compatible CLIs)

**Use this handler for any Claude-compatible CLI, including CCR (Claude Code Router).**

```bash
# Minimal CCR Configuration - just specify the handler!
CLI_PROVIDER_ID=ccr
CLI_PROVIDER_CCR_HANDLER=customClaude
# That's it! The system auto-detects CCR and applies defaults:
# - binary: ccr
# - args: ["code"]
# - name: "CCR Code Router"
```

**About CCR:**
- CCR is a Claude-compatible router that can switch between different AI providers
- Configure the actual provider (Claude, DeepSeek, etc.) in `~/.claude-code-router/config.json`
- Uses the same interface as Claude Code
- Supports all Claude Code features (--print, --greenlight, -c, etc.)

**Smart Defaults:**
- When `id` is "ccr" or starts with "ccr-", the system automatically:
  - Sets binary to `ccr`
  - Sets args to `["code"]`
  - Sets name to "CCR Code Router"
- You only need to override if using non-standard paths or arguments

## Custom Provider Examples

### Using CCR for Different Providers

CCR can route to different AI providers based on its configuration file (`~/.claude-code-router/config.json`):

```bash
# Minimal configurations - the system handles the rest!

# Example 1: CCR for DeepSeek
CLI_PROVIDER_ID=ccr-deepseek
CLI_PROVIDER_CCR_DEEPSEEK_HANDLER=customClaude
CLI_PROVIDER_CCR_DEEPSEEK_NAME=DeepSeek (via CCR)  # Optional
# Auto-applies: binary=ccr, args=["code"]
# Note: Configure ~/.claude-code-router/config.json to use DeepSeek

# Example 2: Just switching provider ID is enough
CLI_PROVIDER_ID=ccr-opus
CLI_PROVIDER_CCR_OPUS_HANDLER=customClaude
# Auto-applies: binary=ccr, args=["code"], name="CCR Code Router"
# Note: Configure ~/.claude-code-router/config.json to use Claude Opus

# Example 3: Ultra-minimal - just two lines!
CLI_PROVIDER_ID=ccr
CLI_PROVIDER_CCR_HANDLER=customClaude
```

### Other Claude-Compatible CLIs

```bash
CLI_PROVIDER_ID=deepthink
CLI_PROVIDER_DEEPTHINK_NAME=DeepThink AI
CLI_PROVIDER_DEEPTHINK_HANDLER=claude
CLI_PROVIDER_DEEPTHINK_BINARY=deepthink
CLI_PROVIDER_DEEPTHINK_ARGS=["--deep-mode", "--analysis"]
CLI_PROVIDER_DEEPTHINK_ENV={"DEEPTHINK_MODEL": "advanced"}
```

## Handler Interface

All handlers must implement these methods:

```javascript
class BaseCliHandler {
  // Create a new task
  async createTask(options) { }

  // Continue existing conversation
  async continueTask(options) { }

  // Execute with auto-approval (greenlight)
  async greenlightTask(options) { }

  // Validate configuration
  validate() { }

  // Get capabilities
  getCapabilities() { }
}
```

### Task Options

```javascript
{
  command: string,         // The prompt/command
  workingDir: string,      // Working directory
  modelPreference: string, // Model selection
  interactive: boolean,    // Interactive mode
  logStream: stream,       // Log output stream
  prompt: string          // For continue tasks
}
```

### Capabilities

Each handler reports its capabilities:

```javascript
{
  supportsCreate: true,      // Can create new tasks
  supportsContinue: true,    // Can continue conversations
  supportsGreenlight: false, // Supports auto-approval
  supportsModels: false,     // Supports model selection
  supportsPrintMode: false,  // Supports non-interactive output
  supportsInteractive: true  // Supports interactive mode
}
```

## CLI Commands

### Provider Management

```bash
# List all configured providers
ani-code provider list

# Show current provider
ani-code provider current

# Switch to different provider
ani-code provider switch cursor

# Show provider details
ani-code provider info claude

# Test current provider
ani-code provider test
```

### Using Providers

The provider system is transparent to existing commands:

```bash
# Uses current provider automatically
ani-code add "Fix the bug in user.js"

# Continue with current provider
ani-code continue "Add error handling"

# Works with all existing features
ani-code add -m opus "Implement new feature"
```

## Integration with Task Queue

The task queue automatically uses the configured provider:

```javascript
// In task-queue.js
const providerManager = getProviderManager();
const handler = providerManager.getCurrentHandler();

// Execute based on task type
if (task.command.startsWith('-c')) {
  child = await handler.continueTask(taskOptions);
} else if (task.greenlight) {
  child = await handler.greenlightTask(taskOptions);
} else {
  child = await handler.createTask(taskOptions);
}
```

## Creating Custom Handlers

To create a handler for a new AI provider:

1. **Extend BaseCliHandler**:

```javascript
import { BaseCliHandler } from './baseCliHandler.js';

export class MyAIHandler extends BaseCliHandler {
  constructor(config) {
    super(config);
  }

  async createTask(options) {
    // Implementation
  }

  async continueTask(options) {
    // Implementation
  }

  validate() {
    // Check if binary exists
  }

  getCapabilities() {
    return {
      supportsCreate: true,
      supportsContinue: false,
      // ...
    };
  }
}
```

2. **Register in Provider Manager**:

```javascript
// In providerManager.js
registerBuiltInHandlers() {
  this.handlerClasses = {
    'claude': ClaudeCliHandler,
    'cursor': CursorCliHandler,
    'codex': CodexCliHandler,
    'customClaude': ClaudeCliHandler,
    'myai': MyAIHandler,  // Add your handler
    // ...
  };
}
```

3. **Configure in .env**:

```bash
CLI_PROVIDER_ID=myai
CLI_PROVIDER_MYAI_NAME=My AI Assistant
CLI_PROVIDER_MYAI_HANDLER=myai
CLI_PROVIDER_MYAI_BINARY=/usr/bin/myai
```

## Migration Guide

### From Fixed Claude to Configurable Provider

**Before** (hardcoded):
```javascript
child = spawn('/usr/bin/claude', claudeArgs, { ... });
```

**After** (configurable):
```javascript
const handler = providerManager.getCurrentHandler();
child = await handler.createTask(options);
```

### Backward Compatibility

The system defaults to Claude if no provider is configured, ensuring backward compatibility with existing installations.

## Best Practices

1. **Binary Path**: Use absolute paths for reliability
2. **Arguments**: Use JSON array format for complex arguments
3. **Environment**: Set provider-specific API keys via ENV
4. **Validation**: Always validate provider configuration on startup
5. **Testing**: Use `ani-code provider test` to verify setup

## Troubleshooting

### Common Issues

1. **Binary not found**:
   - Check PATH or use absolute path
   - Verify installation with `which <binary>`

2. **Provider not switching**:
   - Restart daemon after changing .env
   - Use `ani-code provider current` to verify

3. **Arguments not working**:
   - Try JSON array format: `["--arg1", "value1"]`
   - Check handler documentation for supported flags

### Debug Mode

Enable verbose logging:
```bash
LOG_LEVEL=debug ani-code add "test prompt"
```

## Security Considerations

1. **Binary Validation**: Handlers validate binary existence
2. **Shell Injection**: Commands use spawn without shell
3. **Environment Isolation**: Each provider has isolated env
4. **API Key Protection**: Use environment variables, never hardcode

## Future Enhancements

- [ ] Dynamic provider loading from plugins
- [ ] Provider-specific configuration UI
- [ ] Performance metrics per provider
- [ ] Provider fallback chains
- [ ] Multi-provider orchestration
- [ ] Provider capability discovery

## Conclusion

The CLI provider system makes ani-code extensible and adaptable to different AI coding assistants while maintaining a consistent interface. This allows teams to:

- Choose the best AI tool for their needs
- Switch providers without changing workflows
- Create custom integrations with proprietary systems
- Test multiple AI providers side-by-side

The architecture is designed to be simple, secure, and extensible, following SOLID principles and maintaining backward compatibility.
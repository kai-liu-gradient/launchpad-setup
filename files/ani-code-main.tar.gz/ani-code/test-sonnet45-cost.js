#!/usr/bin/env node

import { execSync } from 'child_process';

// Simulate what happens during task execution
async function testSonnet45Cost() {
  console.log('=== Testing Sonnet 4.5 Cost Calculation ===\n');

  // Get current usage snapshot (before)
  console.log('1. Getting BEFORE snapshot...');
  const beforeCmd = `npx ccusage -j --offline --breakdown --since 20251003`;
  const beforeOutput = execSync(beforeCmd, { encoding: 'utf8' });
  const beforeData = JSON.parse(beforeOutput);

  console.log('Before totals:', {
    cost: beforeData.totals.totalCost,
    tokens: beforeData.totals.totalTokens,
    inputTokens: beforeData.totals.inputTokens,
    outputTokens: beforeData.totals.outputTokens
  });

  if (beforeData.daily?.[0]?.modelBreakdowns) {
    console.log('Before model breakdowns:');
    beforeData.daily[0].modelBreakdowns.forEach(m => {
      console.log(`  - ${m.modelName}: $${m.cost}, ${m.inputTokens}in + ${m.outputTokens}out`);
    });
  }

  // Simulate some delay (task execution)
  console.log('\n2. Simulating task execution...');
  console.log('   (In real scenario, Claude API call happens here)');

  // Poll for cost update (up to 10 seconds)
  console.log('\n3. Polling for cost update (max 10s)...');
  const maxWaitTime = 10000;
  const pollInterval = 1000;
  const startTime = Date.now();
  let afterData = null;
  let lastCost = beforeData.totals.totalCost;
  let stableCount = 0;

  while (Date.now() - startTime < maxWaitTime) {
    const afterCmd = `npx ccusage -j --offline --breakdown --since 20251003`;
    const afterOutput = execSync(afterCmd, { encoding: 'utf8' });
    afterData = JSON.parse(afterOutput);

    const currentCost = afterData.totals.totalCost;
    const costDiff = currentCost - beforeData.totals.totalCost;

    const elapsed = Date.now() - startTime;
    console.log(`   Poll at ${elapsed}ms: cost=$${currentCost.toFixed(6)}, diff=$${costDiff.toFixed(6)}`);

    // If cost increased, wait for it to stabilize
    if (costDiff > 0) {
      if (currentCost === lastCost) {
        stableCount++;
        if (stableCount >= 2) {
          console.log(`   ✅ Cost stabilized at $${currentCost.toFixed(6)} after ${elapsed}ms`);
          break;
        }
      } else {
        stableCount = 0;
      }
    }

    lastCost = currentCost;
    await new Promise(resolve => setTimeout(resolve, pollInterval));
  }

  console.log(`\n4. Getting AFTER snapshot (final)...`);

  console.log('After totals:', {
    cost: afterData.totals.totalCost,
    tokens: afterData.totals.totalTokens,
    inputTokens: afterData.totals.inputTokens,
    outputTokens: afterData.totals.outputTokens
  });

  if (afterData.daily?.[0]?.modelBreakdowns) {
    console.log('After model breakdowns:');
    afterData.daily[0].modelBreakdowns.forEach(m => {
      console.log(`  - ${m.modelName}: $${m.cost}, ${m.inputTokens}in + ${m.outputTokens}out`);
    });
  }

  // Calculate difference
  console.log('\n5. Calculating difference...');
  const costDiff = afterData.totals.totalCost - beforeData.totals.totalCost;
  const tokenDiff = afterData.totals.totalTokens - beforeData.totals.totalTokens;

  console.log('Difference:', {
    cost: costDiff,
    tokens: tokenDiff,
    inputTokens: (afterData.totals.inputTokens || 0) - (beforeData.totals.inputTokens || 0),
    outputTokens: (afterData.totals.outputTokens || 0) - (beforeData.totals.outputTokens || 0)
  });

  // Check model breakdown diff
  if (afterData.daily?.[0]?.modelBreakdowns && beforeData.daily?.[0]?.modelBreakdowns) {
    console.log('\n6. Model breakdown differences:');
    const afterModels = afterData.daily[0].modelBreakdowns;
    const beforeModels = beforeData.daily[0].modelBreakdowns;

    for (const afterModel of afterModels) {
      const beforeModel = beforeModels.find(m => m.modelName === afterModel.modelName);
      const beforeCost = beforeModel ? beforeModel.cost : 0;
      const modelCostDiff = afterModel.cost - beforeCost;

      if (modelCostDiff !== 0 || !beforeModel) {
        console.log(`  - ${afterModel.modelName}:`);
        console.log(`    Before: $${beforeCost.toFixed(6)}`);
        console.log(`    After:  $${afterModel.cost.toFixed(6)}`);
        console.log(`    Diff:   $${modelCostDiff.toFixed(6)}`);
      }
    }
  }

  // Summary
  console.log('\n=== Summary ===');
  if (costDiff === 0 && tokenDiff === 0) {
    console.log('⚠️  ISSUE CONFIRMED: No cost difference detected even though both snapshots should be identical');
    console.log('This means costs are showing correctly in ccusage, but diff calculation might be problematic');
  } else if (costDiff > 0) {
    console.log('✅ Cost difference detected: $' + costDiff.toFixed(6));
  } else {
    console.log('❌ Negative cost difference: $' + costDiff.toFixed(6));
  }
}

testSonnet45Cost().catch(console.error);

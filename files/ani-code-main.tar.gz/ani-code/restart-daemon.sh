#!/bin/bash

echo "Stopping ani-code service and cleaning up processes..."

# Stop the service
sudo systemctl stop ani-code.service

# Kill any leftover claude processes
echo "Killing leftover claude processes..."
sudo pkill -9 -f "claude"
# Also kill any ani-code processes
sudo pkill -9 -f "ani-code daemon"

# Wait a moment
sleep 3

# Reset failed state if needed
sudo systemctl reset-failed ani-code.service

# Start the service again
echo "Starting ani-code service..."
sudo systemctl start ani-code.service

# Wait for it to start
sleep 2

# Check status
echo ""
echo "Service status:"
sudo systemctl status ani-code.service --no-pager | head -15

# Check if it's running
if systemctl is-active --quiet ani-code.service; then
    echo ""
    echo "✅ Daemon restart complete and running!"
else
    echo ""
    echo "⚠️ Service may have issues. Checking journal..."
    sudo journalctl -xeu ani-code.service --no-pager | tail -20
fi

echo ""
echo "Next steps:"
echo "1. Clear chat settings in Lark: /clear-settings"
echo "2. Generate a new token: ani-code workspace token gen snake-game -n 'Lark'"  
echo "3. Connect in Lark: /connect <token>"
echo ""
echo "If you still have issues, try:"
echo "  ani-code workspace clear-chats snake-game"
echo "  Then regenerate token and reconnect"
#!/usr/bin/env node

// Test script for the diagnosis command
import { spawn } from 'child_process';
import chalk from 'chalk';

console.log(chalk.blue.bold('Testing ani-code diagnosis command...\n'));

// Test 1: Basic diagnosis
console.log(chalk.yellow('Test 1: Basic diagnosis'));
const basic = spawn('node', ['src/index.js', 'diagnosis'], { stdio: 'inherit' });

basic.on('close', (code) => {
  if (code === 0) {
    console.log(chalk.green('\n✓ Basic diagnosis completed successfully\n'));
  } else {
    console.log(chalk.red(`\n✗ Basic diagnosis failed with code ${code}\n`));
  }

  // Test 2: Verbose diagnosis
  console.log(chalk.yellow('Test 2: Verbose diagnosis'));
  const verbose = spawn('node', ['src/index.js', 'diagnosis', '-v'], { stdio: 'inherit' });

  verbose.on('close', (code2) => {
    if (code2 === 0) {
      console.log(chalk.green('\n✓ Verbose diagnosis completed successfully\n'));
    } else {
      console.log(chalk.red(`\n✗ Verbose diagnosis failed with code ${code2}\n`));
    }

    // Test 3: JSON output
    console.log(chalk.yellow('Test 3: JSON output diagnosis'));
    const json = spawn('node', ['src/index.js', 'diagnosis', '-j']);

    let jsonOutput = '';
    json.stdout.on('data', (data) => {
      jsonOutput += data.toString();
    });

    json.on('close', (code3) => {
      if (code3 === 0) {
        try {
          const parsed = JSON.parse(jsonOutput);
          console.log(chalk.green('✓ JSON output is valid'));
          console.log(chalk.gray('  - Has system info:', !!parsed.system));
          console.log(chalk.gray('  - Has daemon status:', !!parsed.daemon));
          console.log(chalk.gray('  - Has version info:', !!parsed.version));
          console.log(chalk.gray('  - Has configuration:', !!parsed.configuration));
          console.log(chalk.gray('  - Has endpoints:', !!parsed.endpoints));
        } catch (error) {
          console.log(chalk.red('✗ JSON output is invalid'));
          console.log(chalk.red(error.message));
        }
      } else {
        console.log(chalk.red(`✗ JSON diagnosis failed with code ${code3}`));
      }

      console.log(chalk.blue.bold('\n✅ All diagnosis tests completed'));
    });
  });
});
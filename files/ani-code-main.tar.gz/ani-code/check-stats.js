#!/usr/bin/env node
import { getStatsDB } from './src/stats-db.js';

const db = getStatsDB();

// Get total task count
const countResult = db.db.prepare('SELECT COUNT(*) as count FROM task_stats').get();
console.log('Total tasks in database:', countResult.count);

// Get counts by status
const statusCounts = db.db.prepare(`
  SELECT status, COUNT(*) as count
  FROM task_stats
  GROUP BY status
`).all();
console.log('\nTasks by status:');
statusCounts.forEach(s => console.log(`  ${s.status}: ${s.count}`));

// Get recent tasks
const recentTasks = db.db.prepare(`
  SELECT task_id, workspace, status,
         datetime(created_at/1000, 'unixepoch', 'localtime') as created_time,
         cost_usd, total_tokens
  FROM task_stats
  ORDER BY created_at DESC
  LIMIT 5
`).all();

console.log('\nRecent 5 tasks:');
recentTasks.forEach(task => {
  console.log(`- ${task.task_id}: ${task.workspace} [${task.status}] at ${task.created_time}`);
});

// Get stats for last 24 hours
const hourlyStats = db.getHourlyStats(24);
console.log('\n24-hour stats:', hourlyStats.length > 0 ? `${hourlyStats.length} hour entries` : 'No data');
if (hourlyStats.length > 0) {
  console.log('First few hours:');
  hourlyStats.slice(0, 3).forEach(stat => {
    console.log(`  ${stat.hour}: ${stat.task_count} tasks, ${stat.completed_count} completed`);
  });
}

// Get stats for last 7 days
const dailyStats = db.getDailyStats(7);
console.log('\n7-day stats:', dailyStats.length > 0 ? `${dailyStats.length} day entries` : 'No data');
if (dailyStats.length > 0) {
  console.log('Days:');
  dailyStats.forEach(stat => {
    console.log(`  ${stat.day} (${stat.workspace}): ${stat.task_count} tasks`);
  });
}

// Check timestamps
const timestamps = db.db.prepare(`
  SELECT
    MIN(created_at) as first_task,
    MAX(created_at) as last_task,
    datetime(MIN(created_at)/1000, 'unixepoch', 'localtime') as first_time,
    datetime(MAX(created_at)/1000, 'unixepoch', 'localtime') as last_time
  FROM task_stats
`).get();

console.log('\nTimestamp range:');
console.log(`  First task: ${timestamps.first_time} (${timestamps.first_task})`);
console.log(`  Last task: ${timestamps.last_time} (${timestamps.last_task})`);
console.log(`  Current time: ${Date.now()}`);
console.log(`  24 hours ago: ${Date.now() - (24 * 60 * 60 * 1000)}`);
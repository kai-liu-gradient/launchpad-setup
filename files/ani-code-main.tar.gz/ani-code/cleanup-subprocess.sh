#!/bin.bash

journalctl -u ani-code.service -n 100| grep "Failed with result" -A 10|grep 'Unit process' | while read line; do
	echo "> $line"
	pid=$(echo "$line" | awk -F'process ' '{print $2}' | awk '{print $1}')
	echo "> kill $pid"
	kill $pid || :
done

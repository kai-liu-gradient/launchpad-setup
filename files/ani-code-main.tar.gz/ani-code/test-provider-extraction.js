#!/usr/bin/env node

/**
 * Test script to verify provider extraction from prompts
 */

import { extractProviderFromPrompt } from './src/model-utils.js';

console.log('Testing provider extraction from prompts...\n');

const testCases = [
  { input: 'fix the bug @@codex', expected: 'codex' },
  { input: '@@deepseek please help me', expected: 'deepseek' },
  { input: 'regular prompt without provider', expected: null },
  { input: '@@opus is a model not a provider', expected: null },
  { input: 'multiple @@codex and @@deepseek should return first', expected: 'codex' },
];

let passed = 0;
let failed = 0;

for (const test of testCases) {
  const result = extractProviderFromPrompt(test.input);
  const status = result === test.expected ? '✅' : '❌';

  if (result === test.expected) {
    passed++;
  } else {
    failed++;
  }

  console.log(`${status} Input: "${test.input}"`);
  console.log(`   Expected: ${test.expected}, Got: ${result}\n`);
}

console.log(`\nResults: ${passed} passed, ${failed} failed`);
process.exit(failed > 0 ? 1 : 0);
#!/bin/bash

# Test the goals sync fix
echo "Testing goals sync fix..."
echo "========================"

# Create a test goal file with problematic status
TEST_DIR="/tmp/test-goals"
mkdir -p "$TEST_DIR/pd/goals"

cat > "$TEST_DIR/pd/goals/001-test-goal.md" << 'EOF'
# Goal: Test Goal with Invalid Status

## Objective
Test goal for sync validation

## Tasks
- [x] Task 1
- [x] Task 2
- [x] Task 3

## Progress
- Status: 📋 **PLANNED**
- Completion: 100%
- Notes: This should be "Completed" based on 100% completion

## Acceptance Criteria
- All tasks done
EOF

echo "Created test goal with invalid status: '📋 **PLANNED**'"
echo ""

# Run sync on the test directory
echo "Running goals sync..."
cd "$TEST_DIR"
node /root/workspace/ani-code/src/index.js goals sync --full 2>&1 | grep -E "(Invalid status|Fixing|Re-parsing|updated cache)"

echo ""
echo "Checking if goal was properly updated in cache..."
node /root/workspace/ani-code/src/index.js goals list 2>&1 | grep -E "test-goal|Test Goal"

echo ""
echo "Test complete!"
#!/usr/bin/env node

import sqlite3 from 'sqlite3';
import { open } from 'sqlite';
import path from 'path';

async function queryTelegramChats() {
  const dbPath = path.join('/root/workspace/ani-code', 'workspaces.db');
  
  const db = await open({
    filename: dbPath,
    driver: sqlite3.Database
  });
  
  try {
    console.log('Querying telegram_chats table...\n');
    
    // Get all telegram chats
    const chats = await db.all(`
      SELECT tc.*, w.name as workspace_name, w.path as workspace_path
      FROM telegram_chats tc
      LEFT JOIN workspaces w ON tc.workspace_id = w.id
      ORDER BY tc.created_at DESC
    `);
    
    if (chats.length > 0) {
      console.log('Found Telegram chats:');
      chats.forEach(chat => {
        console.log(`\n  Chat ID: ${chat.chat_id}`);
        console.log(`    Username: ${chat.username || 'N/A'}`);
        console.log(`    First Name: ${chat.first_name || 'N/A'}`);
        console.log(`    Chat Type: ${chat.chat_type}`);
        console.log(`    Status: ${chat.status}`);
        console.log(`    Workspace: ${chat.workspace_name || 'Not connected'}`);
        console.log(`    Workspace Path: ${chat.workspace_path || 'N/A'}`);
        console.log(`    Created: ${chat.created_at}`);
      });
      
      // Find chats connected to ani-code workspace
      const aniCodeChats = chats.filter(chat => 
        chat.workspace_name?.toLowerCase().includes('ani-code') ||
        chat.workspace_path?.includes('ani-code')
      );
      
      if (aniCodeChats.length > 0) {
        console.log('\n✅ Found chat IDs connected to ani-code workspace:');
        aniCodeChats.forEach(chat => {
          console.log(`   Chat ID: ${chat.chat_id}`);
          console.log(`   Username: ${chat.username}`);
        });
        
        const chatId = aniCodeChats[0].chat_id;
        console.log('\n📝 To use this chat ID as default:');
        console.log(`   Add to .env file:`);
        console.log(`   TELEGRAM_CHAT_ID=${chatId}`);
      } else {
        // Look for any active chat
        const activeChats = chats.filter(chat => chat.status === 'active');
        if (activeChats.length > 0) {
          console.log('\n⚠️  No chats specifically connected to ani-code workspace');
          console.log('   But found active chats:');
          activeChats.forEach(chat => {
            console.log(`   Chat ID: ${chat.chat_id} (${chat.username})`);
          });
          
          const chatId = activeChats[0].chat_id;
          console.log('\n📝 You can use this active chat ID as default:');
          console.log(`   Add to .env file:`);
          console.log(`   TELEGRAM_CHAT_ID=${chatId}`);
        }
      }
    } else {
      console.log('No Telegram chats found in database');
    }
    
    // Also check workspaces table for chat_id field
    console.log('\n\nChecking workspaces table...');
    const workspaces = await db.all(`
      SELECT id, name, path, chat_id 
      FROM workspaces 
      WHERE name LIKE '%ani-code%' OR path LIKE '%ani-code%'
    `);
    
    if (workspaces.length > 0) {
      console.log('Found ani-code workspaces:');
      workspaces.forEach(ws => {
        console.log(`  ${ws.name}: chat_id = ${ws.chat_id || 'Not set'}`);
      });
    }
    
  } catch (error) {
    console.error('Error querying database:', error);
  } finally {
    await db.close();
  }
}

queryTelegramChats();
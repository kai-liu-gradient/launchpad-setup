# CLI Provider Configuration Examples

## Quick Setup - All Providers at Once

ani-code now loads all built-in providers automatically and shows their status:
- **claude** (default) - Works out-of-the-box
- **cursor** - Works if cursor-agent is installed
- **codex** - Works if codex is installed

No configuration needed for these!

## Check Provider Status

```bash
# Show all providers and their installation status
ani-code workspace provider

# Output example:
# ✅ claude     - Claude Code          ready ← active
# ⚠️  cursor     - Cursor Agent         not installed
# ✅ codex      - OpenAI Codex         ready
```

## Setting Provider Per Workspace

```bash
# Set provider for current workspace (with automatic auth/grant flow)
ani-code workspace provider cursor    # Switches to Cursor and launches it for auth
ani-code workspace provider claude    # Switch back to Claude
ani-code workspace provider codex     # Use Codex

# When you set a provider, it will:
# 1. Save the setting in workspace meta
# 2. Check if the binary is installed
# 3. Launch the provider for authentication/permissions (if needed)
# 4. Replace the current process so you can complete setup

# Check current provider
ani-code workspace provider
```

## Automatic Authentication Flow

When switching to a new provider, ani-code automatically:
1. **Checks installation** - Verifies the provider binary exists
2. **Launches for auth** - Opens the provider CLI for initial setup
3. **Grants permissions** - You complete auth in the provider's interface
4. **Ready to use** - After setup, use `ani-code add` normally

Example:
```bash
$ ani-code workspace provider cursor

✓ Set workspace provider to: cursor
Provider requires authentication/authorization:
Opening Cursor Agent for setup...
Please grant permissions and complete the setup

Executing: cursor-agent

[Cursor Agent opens for authentication...]
[You complete the setup in Cursor's interface...]

✓ Cursor Agent setup completed
You can now use: ani-code add "your prompt"
```

## Example .env Configuration

### 1. Basic Setup (Built-in Providers)
```bash
# No configuration needed! Built-in providers work automatically
# Just set per workspace or use CLI_PROVIDER_ID to override
```

### 2. Temporary Override
```bash
# Override for current session only
export CLI_PROVIDER_ID=cursor
ani-code add "implement feature"

# Or one-time use
CLI_PROVIDER_ID=codex ani-code add "write tests"
```

### 3. Custom Provider: DeepSeek
```bash
# Add to .env file:
CLI_PROVIDER_DEEPSEEK_HANDLER=customClaude
CLI_PROVIDER_DEEPSEEK_BINARY=deepseek
CLI_PROVIDER_DEEPSEEK_NAME=DeepSeek AI

# Use it in workspace:
ani-code workspace provider deepseek
```

### 4. Custom Provider: CCR (Claude Router)
```bash
# Add to .env file (minimal):
CLI_PROVIDER_CCR_HANDLER=customClaude
# Auto-applies: binary=ccr, args=["code"]

# Configure CCR's actual provider in ~/.claude-code-router/config.json
# Then use it:
ani-code workspace provider ccr
```

### 5. Complete Example with Multiple Custom Providers
```bash
# === .env file ===
# Custom DeepSeek
CLI_PROVIDER_DEEPSEEK_HANDLER=customClaude
CLI_PROVIDER_DEEPSEEK_BINARY=deepseek
CLI_PROVIDER_DEEPSEEK_NAME=DeepSeek AI

# CCR for routing
CLI_PROVIDER_CCR_HANDLER=customClaude

# Custom Cursor settings (optional)
CLI_PROVIDER_CURSOR_ENV={"CURSOR_API_KEY": "your-key"}
CLI_PROVIDER_CURSOR_ARGS=["--model", "gpt-5"]

# Custom Codex settings (optional)
CLI_PROVIDER_CODEX_ARGS=["--sandbox", "workspace-write"]
CLI_PROVIDER_CODEX_ENV={"CODEX_ENABLE_SEARCH": "true"}
```

## Priority System

The provider is selected based on this priority:
1. **CLI_PROVIDER_ID** environment variable (immediate override)
2. **Workspace meta** setting (per workspace configuration)
3. **Default**: claude

## Usage Examples

### Workspace A: Using Cursor
```bash
cd /path/to/project-a
ani-code workspace provider cursor
ani-code add "implement feature"  # Uses Cursor
```

### Workspace B: Using Codex
```bash
cd /path/to/project-b
ani-code workspace provider codex
ani-code add "write tests"  # Uses Codex
```

### Quick Switch for Testing
```bash
# Test with different providers without changing workspace setting
CLI_PROVIDER_ID=claude ani-code add "test with claude"
CLI_PROVIDER_ID=cursor ani-code add "test with cursor"
CLI_PROVIDER_ID=codex ani-code add "test with codex"
```

### Check Available Providers
```bash
# From any workspace
ani-code workspace provider

# Or use provider command
ani-code provider list
```

## Notes

- Built-in providers (claude, cursor, codex) work automatically
- Custom providers need the `customClaude` handler
- CCR auto-configures when ID starts with "ccr"
- Workspace settings persist across sessions
- CLI_PROVIDER_ID overrides workspace settings temporarily
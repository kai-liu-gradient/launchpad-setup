#!/usr/bin/env node

/**
 * Test script for dummy mode - demonstrates that tasks can be created
 * and executed without Telegram/Lark configuration when using dummy mode.
 */

import { spawn } from 'child_process';
import chalk from 'chalk';

console.log(chalk.blue('🧪 Testing ANI-CODE Dummy Mode for Gateway Control\n'));

// Set dummy mode environment variable
process.env.ANI_CODE_DUMMY_MODE = 'true';
process.env.TELEGRAM_BOT_TOKEN = 'DUMMY';

console.log(chalk.yellow('Environment configured:'));
console.log(`  ANI_CODE_DUMMY_MODE=${process.env.ANI_CODE_DUMMY_MODE}`);
console.log(`  TELEGRAM_BOT_TOKEN=${process.env.TELEGRAM_BOT_TOKEN}\n`);

async function runCommand(cmd, args = []) {
  return new Promise((resolve, reject) => {
    console.log(chalk.gray(`> ${cmd} ${args.join(' ')}`));

    const child = spawn(cmd, args, {
      env: { ...process.env },
      stdio: 'inherit',
      shell: true
    });

    child.on('close', (code) => {
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(`Command failed with code ${code}`));
      }
    });
  });
}

async function testDummyMode() {
  try {
    // Test 1: Check daemon status
    console.log(chalk.cyan('\n📍 Test 1: Check daemon status'));
    await runCommand('ani-code', ['daemon', '--status']);

    // Test 2: Test configuration validation with dummy mode
    console.log(chalk.cyan('\n📍 Test 2: Validate configuration in dummy mode'));
    await runCommand('node', ['-e', `
      process.env.ANI_CODE_DUMMY_MODE = 'true';
      import('./src/config.js').then(({ validateConfig }) => {
        try {
          validateConfig();
          console.log('✅ Configuration validated successfully in dummy mode');
        } catch (error) {
          console.error('❌ Configuration validation failed:', error.message);
          process.exit(1);
        }
      });
    `]);

    // Test 3: Create a simple task
    console.log(chalk.cyan('\n📍 Test 3: Create a test task'));
    await runCommand('ani-code', ['add', 'echo "Task executed successfully in dummy mode"']);

    // Test 4: Check task status
    console.log(chalk.cyan('\n📍 Test 4: Check task status'));
    await runCommand('ani-code', ['status']);

    // Test 5: Test the Telegram notifier in dummy mode
    console.log(chalk.cyan('\n📍 Test 5: Test Telegram notifier'));
    await runCommand('node', ['-e', `
      process.env.ANI_CODE_DUMMY_MODE = 'true';
      import('./src/telegram-notifier.js').then(({ TelegramNotifier }) => {
        const notifier = new TelegramNotifier();
        if (notifier.isDummy) {
          console.log('✅ Dummy Telegram notifier initialized successfully');
          notifier.sendCustomMessage('Test Message', 'This is a test message in dummy mode');
        } else {
          console.error('❌ Dummy mode not activated properly');
          process.exit(1);
        }
      });
    `]);

    console.log(chalk.green('\n✅ All tests passed! Dummy mode is working correctly.'));
    console.log(chalk.green('\n📝 Summary:'));
    console.log('  - Configuration validation passes with ANI_CODE_DUMMY_MODE=true');
    console.log('  - Tasks can be created without Telegram/Lark configuration');
    console.log('  - Dummy notifier logs messages instead of sending them');
    console.log('  - Gateway can control ani-code daemon remotely');

  } catch (error) {
    console.error(chalk.red(`\n❌ Test failed: ${error.message}`));
    process.exit(1);
  }
}

// Run the tests
testDummyMode();
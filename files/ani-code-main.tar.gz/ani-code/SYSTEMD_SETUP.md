# Systemd Service Installation Guide

## Overview
This guide explains how to install and manage the ani-code daemon as a systemd service.

## Installation

### 1. Copy Service File
```bash
sudo cp ani-code.service /etc/systemd/system/ani-code.service
```

### 2. Edit Service File (if needed)
Update paths and user if your installation differs:
```bash
sudo nano /etc/systemd/system/ani-code.service
```

Key settings to verify:
- `User=root` - Change if running as different user
- `WorkingDirectory=/root/workspace/ani-code` - Update to your installation path
- `ExecStart=/usr/bin/node /root/workspace/ani-code/src/index.js daemon` - Update paths if needed

### 3. Reload Systemd
```bash
sudo systemctl daemon-reload
```

### 4. Enable Service (Auto-start on Boot)
```bash
sudo systemctl enable ani-code
```

### 5. Start Service
```bash
sudo systemctl start ani-code
```

## Service Management

### Check Status
```bash
systemctl status ani-code
```

### View Logs
```bash
# Real-time logs
journalctl -u ani-code -f

# Last 100 lines
journalctl -u ani-code -n 100

# Logs since today
journalctl -u ani-code --since today
```

### Stop Service
```bash
sudo systemctl stop ani-code
```

**Warning**: Stopping the service will terminate all running Claude tasks immediately.

### Restart Service
```bash
sudo systemctl restart ani-code
```

**Warning**: Restarting will kill all active tasks. Use only when necessary.

### Disable Auto-start
```bash
sudo systemctl disable ani-code
```

## Troubleshooting

### Service Won't Start
1. Check logs: `journalctl -u ani-code -n 50`
2. Verify paths in service file
3. Check file permissions: `ls -la /root/workspace/ani-code/src/index.js`
4. Test manual start: `node /root/workspace/ani-code/src/index.js daemon`

### Permission Issues
- Ensure service user has read/write access to working directory
- Check data directory permissions
- Verify node_modules are installed: `npm install`

### Service Crashes on Boot
- Check dependencies: `npm install`
- Verify node version: `node --version` (requires Node.js 16+)
- Review startup logs: `journalctl -u ani-code --since "5 minutes ago"`

## Security Hardening

For production environments, uncomment security options in the service file:

```ini
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=read-only
ReadWritePaths=/root/workspace/ani-code
```

Then reload and restart:
```bash
sudo systemctl daemon-reload
sudo systemctl restart ani-code
```

## Uninstallation

```bash
# Stop and disable service
sudo systemctl stop ani-code
sudo systemctl disable ani-code

# Remove service file
sudo rm /etc/systemd/system/ani-code.service

# Reload systemd
sudo systemctl daemon-reload
```

## Service File Location

- **Development**: `./ani-code.service`
- **Production**: `/etc/systemd/system/ani-code.service`

## Additional Notes

- The daemon automatically handles version checking between CLI and daemon
- Service restarts automatically on failure (RestartSec=10)
- Logs are available through journalctl
- Resource limits are configured for stability (65536 file descriptors, 4096 processes)

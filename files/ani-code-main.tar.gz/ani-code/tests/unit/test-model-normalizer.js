import { normalizeModelName, normalizeModelNameLowercase } from '../../src/utils/model-normalizer.js';

// Test cases
const tests = [
  // New model formats (with minor version)
  { input: 'claude-sonnet-4-5-20250929', expected: 'Sonnet-4.5', expectedLower: 'sonnet-4.5' },
  { input: 'claude-opus-4-1-20250805', expected: 'Opus-4.1', expectedLower: 'opus-4.1' },

  // Existing model formats
  { input: 'claude-sonnet-3-5-20240620', expected: 'Sonnet-3.5', expectedLower: 'sonnet-3.5' },
  { input: 'claude-haiku-3-5-20240307', expected: 'Haiku-3.5', expectedLower: 'haiku-3.5' },

  // Models without minor version
  { input: 'claude-haiku-4-20250307', expected: 'Haiku-4', expectedLower: 'haiku-4' },
  { input: 'claude-opus-3-20240229', expected: 'Opus-3', expectedLower: 'opus-3' },

  // Edge cases
  { input: 'claude-sonnet-4', expected: 'Sonnet-4', expectedLower: 'sonnet-4' },
  { input: 'not-a-claude-model', expected: 'not-a-claude-model', expectedLower: 'not-a-claude-model' },
  { input: '', expected: '', expectedLower: '' },
  { input: null, expected: null, expectedLower: null },
];

let passed = 0;
let failed = 0;

console.log('Testing model normalizer...\n');

tests.forEach((test, index) => {
  const result = normalizeModelName(test.input);
  const resultLower = normalizeModelNameLowercase(test.input);

  const isCorrect = result === test.expected;
  const isCorrectLower = resultLower === test.expectedLower;

  if (isCorrect && isCorrectLower) {
    console.log(`✓ Test ${index + 1}: "${test.input}" -> "${result}" / "${resultLower}"`);
    passed++;
  } else {
    console.log(`✗ Test ${index + 1}: "${test.input}"`);
    if (!isCorrect) {
      console.log(`  Expected: "${test.expected}", Got: "${result}"`);
    }
    if (!isCorrectLower) {
      console.log(`  Expected (lower): "${test.expectedLower}", Got: "${resultLower}"`);
    }
    failed++;
  }
});

console.log(`\n${passed} passed, ${failed} failed`);

if (failed > 0) {
  process.exit(1);
}
#!/usr/bin/env node

import { LarkNotifier } from './src/lark-notifier.js';
import { config } from './src/config.js';
import { logger } from './src/logger.js';

async function testLarkNotification() {
  console.log('🔍 Testing Lark Notification Settings\n');
  console.log('Current Configuration:');
  console.log('=====================');
  
  // Display current config (masking sensitive data)
  console.log('Webhook URL:', config.lark.webhookUrl ? '✅ Configured' : '❌ Not configured');
  console.log('App ID:', config.lark.appId ? '✅ Configured' : '❌ Not configured');
  console.log('App Secret:', config.lark.appSecret ? '✅ Configured' : '❌ Not configured');
  console.log('Group Chat ID:', config.lark.groupChatId ? `✅ ${config.lark.groupChatId}` : '❌ Not configured');
  console.log('Verification Token:', config.lark.verificationToken ? '✅ Configured' : '❌ Not configured');
  console.log('Keyword Prefix:', config.lark.keywordPrefix || 'None');
  console.log('Hostname:', config.lark.hostname);
  console.log('Timezone:', config.timezone);
  console.log('\n');

  // Determine which method to use
  const useAPI = config.lark.appId && config.lark.appSecret && config.lark.groupChatId;
  const useWebhook = config.lark.webhookUrl;

  if (!useAPI && !useWebhook) {
    console.error('❌ Error: No notification method configured!');
    console.log('\nPlease configure either:');
    console.log('1. Webhook URL (LARK_WEBHOOK_URL)');
    console.log('2. API credentials (LARK_APP_ID, LARK_APP_SECRET, LARK_GROUP_CHAT_ID)');
    process.exit(1);
  }

  console.log('Notification Method:', useAPI ? '🔐 API (Recommended)' : '🔗 Webhook');
  console.log('\n📤 Sending test notification...\n');

  try {
    const notifier = new LarkNotifier();
    
    // Test different message types
    const tests = [];
    
    // Test 1: Simple custom message
    console.log('Test 1: Sending custom message...');
    tests.push(
      notifier.sendCustomMessage(
        '🧪 Test Notification',
        'This is a test message from ani-code to verify your Lark notification settings.',
        'green'
      ).then(() => console.log('✅ Custom message sent successfully'))
        .catch(err => console.error('❌ Custom message failed:', err.message))
    );

    // Test 2: Send message to group (if API is configured)
    if (useAPI) {
      console.log('Test 2: Sending message to group via API...');
      const testCard = {
        config: {
          wide_screen_mode: true
        },
        header: {
          title: {
            content: '🔔 API Test Notification',
            tag: 'plain_text'
          },
          template: 'blue'
        },
        elements: [
          {
            tag: 'div',
            text: {
              content: `**Configuration Test**\\n` +
                       `Time: ${new Date().toLocaleString('zh-CN', { timeZone: config.timezone })}\\n` +
                       `Hostname: ${config.lark.hostname}\\n` +
                       `Group Chat ID: ${config.lark.groupChatId}`,
              tag: 'lark_md'
            }
          }
        ]
      };

      tests.push(
        notifier.sendMessageToGroup(JSON.stringify(testCard), 'interactive')
          .then(() => console.log('✅ Group message sent successfully'))
          .catch(err => console.error('❌ Group message failed:', err.message))
      );
    }

    // Test 3: Send via webhook (if configured)
    if (useWebhook) {
      console.log('Test 3: Sending message via webhook...');
      const webhookMessage = {
        msg_type: 'interactive',
        card: {
          config: {
            wide_screen_mode: true
          },
          header: {
            title: {
              content: '🪝 Webhook Test Notification',
              tag: 'plain_text'
            },
            template: 'orange'
          },
          elements: [
            {
              tag: 'div',
              text: {
                content: `**Webhook Test**\\n` +
                         `Time: ${new Date().toLocaleString('zh-CN', { timeZone: config.timezone })}\\n` +
                         `This message was sent via webhook URL`,
                tag: 'lark_md'
              }
            }
          ]
        }
      };

      tests.push(
        notifier.sendMessage(webhookMessage)
          .then(() => console.log('✅ Webhook message sent successfully'))
          .catch(err => console.error('❌ Webhook message failed:', err.message))
      );
    }

    // Wait for all tests to complete
    await Promise.allSettled(tests);
    
    console.log('\n📊 Test Summary:');
    console.log('================');
    console.log('If you received the test notifications in your Lark group, your configuration is correct!');
    console.log('\n💡 Tips:');
    console.log('- If using API method, make sure your bot is added to the group');
    console.log('- If using webhook, ensure the webhook URL is still valid');
    console.log('- Check your Lark app for the test messages');
    
  } catch (error) {
    console.error('\n❌ Test failed with error:', error);
    console.error('Details:', error.message);
    process.exit(1);
  }
}

// Run the test
testLarkNotification().catch(console.error);
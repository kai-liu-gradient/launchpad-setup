#!/usr/bin/env node

import { ClaudeCliHandler } from '../../src/providers/claudeCliHandler.js';
import { CodexCliHandler } from '../../src/providers/codexCliHandler.js';
import { CursorCliHandler } from '../../src/providers/cursorCliHandler.js';

console.log('Testing Provider Default Configuration\n');

// Test Claude defaults
const claudeDefaults = ClaudeCliHandler.getDefaults('claude');
console.log('Claude defaults:', claudeDefaults);

// Test DeepSeek defaults (should use ccr)
const deepseekDefaults = ClaudeCliHandler.getDefaults('deepseek');
console.log('DeepSeek defaults:', deepseekDefaults);

// Test CCR defaults
const ccrDefaults = ClaudeCliHandler.getDefaults('ccr');
console.log('CCR defaults:', ccrDefaults);

// Test Codex defaults
const codexDefaults = CodexCliHandler.getDefaults('codex');
console.log('Codex defaults:', codexDefaults);

// Test Cursor defaults
const cursorDefaults = CursorCliHandler.getDefaults('cursor');
console.log('Cursor defaults:', cursorDefaults);

// Verify deepseek uses ccr binary
console.log('\n✓ Test Results:');
console.log('DeepSeek uses ccr binary:', deepseekDefaults.binary === 'ccr');
console.log('DeepSeek has "code" arg:', deepseekDefaults.args.includes('code'));
console.log('CCR uses ccr binary:', ccrDefaults.binary === 'ccr');
console.log('CCR has "code" arg:', ccrDefaults.args.includes('code'));
console.log('Claude uses /usr/bin/claude:', claudeDefaults.binary === '/usr/bin/claude');

#!/usr/bin/env node

// Mock environment for deepseek provider
process.env.CLI_PROVIDER_DEEPSEEK_HANDLER = 'customClaude';
process.env.CLI_PROVIDER_DEEPSEEK_NAME = 'deepseek';
// Note: No BINARY or ARGS specified - should use defaults

import { ProviderManager } from '../../src/providers/providerManager.js';

console.log('Testing Provider Configuration Parsing with Defaults\n');

const manager = new ProviderManager();

// Parse deepseek config (should get ccr defaults)
const deepseekConfig = manager.parseProviderConfig('deepseek');

console.log('DeepSeek Configuration:');
console.log(JSON.stringify(deepseekConfig, null, 2));

console.log('\n✓ Verification:');
console.log('Uses ccr binary:', deepseekConfig.binary === 'ccr');
console.log('Has "code" arg:', deepseekConfig.args.includes('code'));
console.log('Handler is customClaude:', deepseekConfig.handler === 'customClaude');
console.log('Name is deepseek:', deepseekConfig.name === 'deepseek');

console.log('\n✅ Provider defaults are working correctly!');
console.log('DeepSeek can now be configured with just:');
console.log('  CLI_PROVIDER_DEEPSEEK_HANDLER=customClaude');
console.log('  CLI_PROVIDER_DEEPSEEK_NAME=deepseek');
console.log('No need to specify BINARY or ARGS!');

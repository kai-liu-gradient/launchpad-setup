#!/usr/bin/env node

import { TelegramNotifier } from './src/telegram-notifier.js';
import { config } from './src/config.js';

async function testTelegramMessage() {
  console.log('Testing Telegram message sending after fix...\n');

  const notifier = new TelegramNotifier();

  if (!notifier.isEnabled()) {
    console.error('❌ Telegram bot token not configured');
    process.exit(1);
  }

  // Create a test task object with markdown content
  const testTask = {
    id: 'ac-1215-test-1234',
    name: 'Test Task: Check Markdown Formatting',
    command: 'Test command with special chars: 10:30 AM, $100.50, key=value',
    status: 'completed',
    createdAt: new Date(),
    startedAt: new Date(Date.now() - 60000),
    completedAt: new Date(),
    exitCode: 0,
    cwd: '/root/workspace/ani-code',
    output: 'Task completed successfully!\n✅ All tests passed\n📊 Coverage: 95%',
    usage: {
      cost: 0.0042,
      tokens: 1250,
      inputTokens: 1000,
      outputTokens: 250,
      cacheReadTokens: 500,
      modelBreakdowns: [
        { modelName: 'claude-sonnet-4-20250514', cost: 0.0042 }
      ]
    }
  };

  try {
    console.log('📤 Sending test message to Telegram...');

    // Test sending a task summary message
    const result = await notifier.sendTaskSummary(
      testTask,
      'success',
      testTask.usage,
      null,  // usageReporter
      config.telegram?.chatId,  // chatId
      null,  // messageId
      2  // pendingCount
    );

    if (result && result.ok) {
      console.log('✅ Message sent successfully!');
      console.log(`   Message ID: ${result.result?.message_id}`);
      console.log(`   Chat ID: ${result.result?.chat?.id}`);
      console.log('\n✨ The Telegram message bug has been fixed!');
      console.log('   Messages should now display with proper formatting.');
    } else {
      console.error('❌ Failed to send message:', result);
    }

  } catch (error) {
    console.error('❌ Error sending test message:', error.message);
    console.error('   Full error:', error);
    process.exit(1);
  }
}

// Run the test
testTelegramMessage().catch(console.error);
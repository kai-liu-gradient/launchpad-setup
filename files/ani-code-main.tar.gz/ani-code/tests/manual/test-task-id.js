import crypto from 'crypto';

// Global task counter, resets on daemon restart
let taskRandomPrefix = null;
let taskCounter = 0;

function generateTaskId(workdir = null) {
  // Generate new random prefix on daemon restart
  if (!taskRandomPrefix) {
    taskRandomPrefix = crypto.randomBytes(1).toString('hex').toUpperCase(); // 2 hex chars
  }
  
  // Increment counter and format with leading zeros
  taskCounter++;
  const counterStr = taskCounter.toString().padStart(2, '0');
  
  // Format: ac-MMDD-workdir-XX01
  const now = new Date();
  const month = (now.getMonth() + 1).toString().padStart(2, '0');
  const day = now.getDate().toString().padStart(2, '0');
  
  // Extract workdir identifier from path if provided
  let workdirPart = '';
  if (workdir) {
    // Get last part of the path
    const pathParts = workdir.split('/').filter(p => p);
    if (pathParts.length > 0) {
      // Just use the last part
      workdirPart = pathParts[pathParts.length - 1];
      // Sanitize workdir part (remove special chars, limit length)
      workdirPart = workdirPart.replace(/[^a-zA-Z0-9]/g, '').substring(0, 10) + '-';
    }
  }
  
  return `ac-${month}${day}-${workdirPart}${taskRandomPrefix}${counterStr}`;
}

console.log('Testing new task ID generation format:\n');
console.log('Without workdir:');
for(let i = 0; i < 5; i++) {
  console.log('  ' + generateTaskId());
}

console.log('\nWith workdir /root/workspace/ani-code:');
for(let i = 0; i < 3; i++) {
  console.log('  ' + generateTaskId('/root/workspace/ani-code'));
}

console.log('\nWith workdir /home/user/my-project:');
for(let i = 0; i < 3; i++) {
  console.log('  ' + generateTaskId('/home/user/my-project'));
}

console.log('\n✅ New format: ac-MMDD-[workdir]-XX##');
console.log('  - MMDD: Month and day');
console.log('  - workdir: Optional, last folder name (max 10 chars)');
console.log('  - XX: Random 2-char hex prefix (changes on daemon restart)');
console.log('  - ##: Sequential counter (01, 02, 03...)');
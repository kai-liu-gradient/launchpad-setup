#!/usr/bin/env node

import { extractModelFromPrompt, getModelPreference } from './src/model-utils.js';

console.log('🧪 Testing Prompt Model Detection');
console.log('===================================');

// Test extractModelFromPrompt function
console.log('\n✅ Testing extractModelFromPrompt:');
console.log('extractModelFromPrompt("Please @@opus help me"):', extractModelFromPrompt("Please @@opus help me"));
console.log('extractModelFromPrompt("Use @@sonnet for this task"):', extractModelFromPrompt("Use @@sonnet for this task"));
console.log('extractModelFromPrompt("No model specified"):', extractModelFromPrompt("No model specified"));
console.log('extractModelFromPrompt("@@OPUS should not work"):', extractModelFromPrompt("@@OPUS should not work"));
console.log('extractModelFromPrompt(""):', extractModelFromPrompt(""));
console.log('extractModelFromPrompt(null):', extractModelFromPrompt(null));

// Test with multiple models (should detect first)
console.log('extractModelFromPrompt("@@opus and @@sonnet both"):', extractModelFromPrompt("@@opus and @@sonnet both"));
console.log('extractModelFromPrompt("@@sonnet and @@opus both"):', extractModelFromPrompt("@@sonnet and @@opus both"));

// Test getModelPreference with mock tasks
console.log('\n🔧 Testing getModelPreference with prompt detection:');

// Mock task with no model preference but has @@opus in command
const taskWithPrompt = {
  name: "Test Task",
  command: "implement feature @@opus please",
  model: null
};

const result = await getModelPreference(taskWithPrompt, null);
console.log('Task with @@opus in command:', result);

// Mock task with @@sonnet in name
const taskWithNamePrompt = {
  name: "Complex task @@sonnet analysis",
  command: "analyze data",
  model: null
};

const result2 = await getModelPreference(taskWithNamePrompt, null);
console.log('Task with @@sonnet in name:', result2);

// Mock task with explicit model (should take priority over prompt)
const taskWithExplicitModel = {
  name: "Test Task @@opus",
  command: "implement feature @@sonnet",
  model: "opus"
};

const result3 = await getModelPreference(taskWithExplicitModel, null);
console.log('Task with explicit model (should ignore prompts):', result3);

console.log('\n✅ All prompt detection tests completed!');
#!/usr/bin/env node

/**
 * Test script for message command with double dashes
 * Tests that messages containing -- are handled correctly
 */

import { spawn } from 'child_process';
import chalk from 'chalk';

function runCommand(args) {
  return new Promise((resolve, reject) => {
    const cmd = spawn('node', ['src/index.js', ...args], {
      cwd: process.cwd(),
      stdio: 'pipe'
    });

    let output = '';
    let errorOutput = '';

    cmd.stdout.on('data', (data) => {
      output += data.toString();
    });

    cmd.stderr.on('data', (data) => {
      errorOutput += data.toString();
    });

    cmd.on('close', (code) => {
      resolve({
        code,
        output,
        errorOutput
      });
    });

    cmd.on('error', reject);
  });
}

async function testMessages() {
  console.log(chalk.cyan('=== Testing Message Command with Dashes ===\n'));

  const testCases = [
    {
      name: 'Simple message',
      args: ['message', 'Hello world'],
      expected: 'Hello world'
    },
    {
      name: 'Message with single dash',
      args: ['message', 'This is a-test'],
      expected: 'This is a-test'
    },
    {
      name: 'Message with double dash',
      args: ['message', 'This has -- double dashes'],
      expected: 'This has -- double dashes'
    },
    {
      name: 'Message starting with double dash (using --)',
      args: ['message', '--', '--this-looks-like-option'],
      expected: '--this-looks-like-option'
    },
    {
      name: 'Complex message with multiple dashes',
      args: ['message', 'Command: npm install --save-dev @types/node'],
      expected: 'Command: npm install --save-dev @types/node'
    },
    {
      name: 'Message with file attachment and dashes',
      args: ['message', 'Check @file.txt -- important'],
      expected: 'Check @file.txt -- important'
    }
  ];

  for (const test of testCases) {
    console.log(chalk.blue(`Test: ${test.name}`));
    console.log(chalk.gray(`  Command: ani-code ${test.args.join(' ')}`));
    console.log(chalk.gray(`  Expected: ${test.expected}`));

    // Note: This will try to actually send the message, which might fail
    // if no chat is configured. We're mainly testing that the parsing works.
    const result = await runCommand(test.args);

    if (result.errorOutput.includes('No chat ID configured')) {
      console.log(chalk.yellow('  ⚠ No chat configured (expected), but message was parsed'));
    } else if (result.code === 0) {
      console.log(chalk.green('  ✓ Message sent successfully'));
    } else {
      console.log(chalk.red('  ✗ Command failed'));
      if (result.errorOutput) {
        console.log(chalk.red(`    Error: ${result.errorOutput.split('\n')[0]}`));
      }
    }
    console.log();
  }

  console.log(chalk.green('\n✅ All parsing tests completed!'));
  console.log(chalk.gray('\nNote: Actual message sending requires a configured chat.'));
}

// Run the tests
testMessages().catch(error => {
  console.error(chalk.red('Test error:'), error);
  process.exit(1);
});
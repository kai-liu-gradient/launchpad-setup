// Test callback data size for Telegram buttons

const testData = [
  {
    name: 'Old format (too long)',
    data: JSON.stringify({
      action: 'create_task',
      command: 'add',
      prompt: 'what is changed?'
    })
  },
  {
    name: 'New format with shortened keys',
    data: JSON.stringify({
      a: 'ct',
      c: 'a',
      p: Date.now().toString(36)
    })
  },
  {
    name: 'Help button',
    data: JSON.stringify({
      a: 'help'
    })
  }
];

console.log('Telegram callback_data limit: 64 bytes\n');

testData.forEach(test => {
  const length = test.data.length;
  const status = length <= 64 ? '✓' : '✗';
  console.log(`${status} ${test.name}: ${length} bytes`);
  console.log(`  Data: ${test.data}`);
  console.log();
});
import { SecureUploader } from './src/utils/secure-upload.js';

// Test cases
const testCases = [
  'FetchError: request to https://api.telegram.org/bot8278665603:AAFnpGEt6zZxgYC8ijNz0XCMHMAcFe4e-Oc/sendMessage failed',
  'Error with token 8278665603:AAFnpGEt6zZxgYC8ijNz0XCMHMAcFe4e-Oc in message',
  'AWS key AKIAIOSFODNN7EXAMPLE should be masked',
  's3://myaccesskey:mysecretkey@s3.amazonaws.com/bucket',
  'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c',
  'Normal message without secrets'
];

console.log('Testing credential masking:');
console.log('==========================');

testCases.forEach((testCase, index) => {
  const masked = SecureUploader.maskCredentials(testCase);
  console.log(`\nTest ${index + 1}:`);
  console.log('Original:', testCase);
  console.log('Masked:  ', masked);
  console.log('---');
});
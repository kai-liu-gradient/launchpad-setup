#!/usr/bin/env node

import { execSync } from 'child_process';
import chalk from 'chalk';

console.log(chalk.bold('\n🧪 Testing Daemon Restart Protection\n'));

function run(cmd, expectError = false) {
  try {
    console.log(chalk.cyan(`> ${cmd}`));
    const output = execSync(cmd, { encoding: 'utf8', stdio: 'pipe' });
    console.log(chalk.gray(output));
    if (expectError) {
      console.log(chalk.red('❌ Expected command to fail but it succeeded'));
      process.exit(1);
    }
    return output;
  } catch (error) {
    if (!expectError) {
      console.log(chalk.red(`❌ Command failed unexpectedly: ${error.message}`));
      if (error.stdout) console.log(chalk.gray(error.stdout.toString()));
      if (error.stderr) console.log(chalk.gray(error.stderr.toString()));
      process.exit(1);
    }
    console.log(chalk.green('✓ Command failed as expected'));
    if (error.stdout) console.log(chalk.gray(error.stdout.toString()));
    if (error.stderr) console.log(chalk.gray(error.stderr.toString()));
    return error.stdout ? error.stdout.toString() : '';
  }
}

// Test 1: Start daemon
console.log(chalk.yellow('\n1. Starting daemon...'));
run('node src/daemon-runner.js &', true); // This will fail in direct run, but that's ok
run('sleep 2'); // Give daemon time to start

// Test 2: Check daemon status
console.log(chalk.yellow('\n2. Checking daemon status...'));
const status = run('ani-code daemon --status');

// Test 3: Add a long-running task
console.log(chalk.yellow('\n3. Adding a test task (sleeps for 30 seconds)...'));
run('echo "Please wait 30 seconds for this test task" | ani-code add -f -');

// Test 4: Try to restart without force (should fail)
console.log(chalk.yellow('\n4. Attempting restart without force (should fail)...'));
run('ani-code daemon --restart', true);

// Test 5: Check that daemon is still running
console.log(chalk.yellow('\n5. Verifying daemon is still running...'));
run('ani-code daemon --status');

// Test 6: Force restart (should work)
console.log(chalk.yellow('\n6. Force restarting daemon...'));
run('ani-code daemon --restart --force');

console.log(chalk.green.bold('\n✅ All tests passed! Restart protection is working correctly.\n'));
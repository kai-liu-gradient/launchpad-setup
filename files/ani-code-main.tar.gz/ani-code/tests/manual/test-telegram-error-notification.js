#!/usr/bin/env node

import { TelegramNotifier } from './src/telegram-notifier.js';
import { config } from './src/config.js';

async function testErrorNotification() {
  console.log('Testing Telegram error notification with loop prevention...');
  
  const notifier = new TelegramNotifier();
  
  if (!notifier.isEnabled()) {
    console.error('Telegram bot is not configured. Please set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID');
    process.exit(1);
  }
  
  if (!notifier.defaultChatId) {
    console.error('No default chat ID configured. Please set TELEGRAM_CHAT_ID');
    process.exit(1);
  }
  
  console.log(`Default chat ID: ${notifier.defaultChatId}`);
  
  // Test 1: Send a basic error notification
  console.log('\nTest 1: Sending basic error notification...');
  const basicError = new Error('Test error message');
  await notifier.sendErrorNotification(basicError, {
    source: 'test-script',
    operation: 'Testing error notification',
    suggestion: 'This is a test - no action needed'
  });
  console.log('✓ Basic error sent');
  
  // Test 2: Try to send the same error again (should be blocked)
  console.log('\nTest 2: Testing loop prevention (should skip duplicate)...');
  await notifier.sendErrorNotification(basicError, {
    source: 'test-script',
    operation: 'Testing error notification',
    suggestion: 'This is a test - no action needed'
  });
  console.log('✓ Duplicate error blocked');
  
  // Test 3: Send a different error (should go through)
  console.log('\nTest 3: Sending different error...');
  const differentError = new Error('Different error message');
  await notifier.sendErrorNotification(differentError, {
    source: 'another-module',
    taskId: 'test-task-123',
    operation: 'Different operation'
  });
  console.log('✓ Different error sent');
  
  // Test 4: Test with stack trace
  console.log('\nTest 4: Sending error with stack trace...');
  try {
    throw new Error('Error with stack trace');
  } catch (stackError) {
    await notifier.sendErrorNotification(stackError, {
      source: 'stack-test',
      operation: 'Testing stack trace display'
    });
    console.log('✓ Stack trace error sent');
  }
  
  console.log('\n✅ All tests completed successfully!');
  console.log('Check your Telegram to see the error notifications.');
}

// Run the test
testErrorNotification().catch(error => {
  console.error('Test failed:', error);
  process.exit(1);
});
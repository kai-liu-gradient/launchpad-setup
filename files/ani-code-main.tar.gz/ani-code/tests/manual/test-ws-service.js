#!/usr/bin/env node

// Test WebSocket Service
import { WSService } from './src/ws-service/index.js';
import { TaskMonitor } from './src/task-monitor.js';
import { ChatSettingsManager } from './src/chat-settings.js';
import { logger } from './src/logger.js';

async function testWSService() {
  console.log('🧪 Testing WebSocket Service...\n');
  
  try {
    // Create dependencies
    const chatSettings = new ChatSettingsManager();
    const taskMonitor = new TaskMonitor(chatSettings);
    
    // Create WebSocket service
    const wsService = new WSService(taskMonitor, chatSettings);
    
    // Start the service
    const port = await wsService.start();
    console.log(`✅ WebSocket service started on port ${port}`);
    
    // Check service stats
    const stats = wsService.getStats();
    console.log(`📊 Service stats:`, stats);
    
    // Wait a bit
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Stop the service
    wsService.stop();
    console.log('✅ WebSocket service stopped');
    
    console.log('\n✨ WebSocket service test passed!');
    process.exit(0);
  } catch (error) {
    console.error('❌ Test failed:', error);
    process.exit(1);
  }
}

// Run test
testWSService();
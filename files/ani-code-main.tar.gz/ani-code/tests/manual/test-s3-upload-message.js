#!/usr/bin/env node

/**
 * Test script for S3 upload with message command
 * This tests the automatic S3 upload feature when using @filename syntax
 */

import chalk from 'chalk';
import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';

async function testS3Upload() {
  console.log(chalk.bold('\n🧪 Testing S3 Upload with Message Command\n'));

  // Create a test image file
  const testDir = '/tmp/ani-test-s3-upload';
  const testImagePath = path.join(testDir, 'test-image.png');

  // Create directory if it doesn't exist
  if (!fs.existsSync(testDir)) {
    fs.mkdirSync(testDir, { recursive: true });
  }

  // Create a simple 1x1 PNG image (minimal valid PNG)
  const pngData = Buffer.from([
    0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A,  // PNG signature
    0x00, 0x00, 0x00, 0x0D, 0x49, 0x48, 0x44, 0x52,  // IHDR chunk
    0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01,
    0x08, 0x02, 0x00, 0x00, 0x00, 0x90, 0x77, 0x53,
    0xDE, 0x00, 0x00, 0x00, 0x0C, 0x49, 0x44, 0x41,  // IDAT chunk
    0x54, 0x08, 0x99, 0x63, 0xF8, 0x0F, 0x00, 0x00,
    0x01, 0x01, 0x01, 0x00, 0x1B, 0xB6, 0xEE, 0x56,
    0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4E, 0x44,  // IEND chunk
    0xAE, 0x42, 0x60, 0x82
  ]);

  fs.writeFileSync(testImagePath, pngData);
  console.log(chalk.green(`✓ Created test image: ${testImagePath}`));

  // Test cases
  const tests = [
    {
      name: 'Local file upload',
      command: `ani-code message "Test S3 upload: @${testImagePath}"`,
      description: 'Should upload local file to S3 and send URL to Telegram'
    },
    {
      name: 'Multiple files',
      command: `ani-code message "Multiple files test: @${testImagePath} @${testImagePath}"`,
      description: 'Should upload both files and send as separate images'
    },
    {
      name: 'Mixed local and URL',
      command: `ani-code message "Mixed test: @${testImagePath} @https://via.placeholder.com/150"`,
      description: 'Should upload local file and send URL directly'
    },
    {
      name: 'With markdown',
      command: `ani-code message -m "*Important*: Check this @${testImagePath}"`,
      description: 'Should upload and send with markdown formatting'
    }
  ];

  console.log(chalk.cyan('\n📋 Running test cases:\n'));

  for (const test of tests) {
    console.log(chalk.bold(`\n${test.name}:`));
    console.log(chalk.gray(`  ${test.description}`));
    console.log(chalk.gray(`  Command: ${test.command}`));

    try {
      // Run the command
      const output = execSync(test.command, { encoding: 'utf8' });

      // Check for expected output
      if (output.includes('Uploading to S3')) {
        console.log(chalk.green('  ✓ S3 upload initiated'));
      }
      if (output.includes('Uploaded to S3:')) {
        console.log(chalk.green('  ✓ S3 upload completed'));
      }
      if (output.includes('Sent uploaded image')) {
        console.log(chalk.green('  ✓ Image sent to Telegram'));
      }

      console.log(chalk.green(`  ✓ Test passed`));
    } catch (error) {
      console.log(chalk.red(`  ✗ Test failed: ${error.message}`));
    }

    // Small delay between tests
    await new Promise(resolve => setTimeout(resolve, 2000));
  }

  // Cleanup
  fs.unlinkSync(testImagePath);
  fs.rmdirSync(testDir);
  console.log(chalk.gray('\n✓ Cleanup completed'));

  console.log(chalk.bold('\n✅ All tests completed!\n'));
}

// Run tests
testS3Upload().catch(error => {
  console.error(chalk.red('Test failed:'), error);
  process.exit(1);
});
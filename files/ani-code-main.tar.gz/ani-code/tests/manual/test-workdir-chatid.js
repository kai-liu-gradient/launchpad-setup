#!/usr/bin/env node

// Test script to verify workdir-to-chatId mapping

import { ChatSettingsManager } from './src/chat-settings.js';
import { execSync } from 'child_process';
import { dirname } from 'path';

async function testWorkdirChatMapping() {
  console.log('Testing workdir-to-chat mapping...\n');
  
  // Create chat settings manager
  const chatSettings = new ChatSettingsManager();
  await chatSettings.load();
  
  // Simulate setting a workdir from a Lark chat
  const testChatId = 'oc_test_chat_123';
  const testWorkdirName = 'test-project';
  const testWorkdirPath = '/tmp/test-project';
  
  console.log('1. Setting workdir for chat:', testChatId);
  await chatSettings.setWorkdir(testChatId, testWorkdirName, testWorkdirPath);
  
  // Verify the mapping
  const retrievedChatId = chatSettings.getChatForWorkdir(testWorkdirPath);
  console.log('   Retrieved chat ID for workdir:', retrievedChatId);
  
  if (retrievedChatId === testChatId) {
    console.log('   ✅ Chat-to-workdir mapping works!');
  } else {
    console.log('   ❌ Chat-to-workdir mapping failed!');
  }
  
  // Test with a different workdir
  const testWorkdirPath2 = process.cwd();
  const testChatId2 = 'oc_another_chat_456';
  
  console.log('\n2. Setting current directory for another chat');
  await chatSettings.setWorkdir(testChatId2, 'current', testWorkdirPath2);
  
  const retrievedChatId2 = chatSettings.getChatForWorkdir(testWorkdirPath2);
  console.log('   Retrieved chat ID for current dir:', retrievedChatId2);
  
  if (retrievedChatId2 === testChatId2) {
    console.log('   ✅ Second mapping works!');
  } else {
    console.log('   ❌ Second mapping failed!');
  }
  
  // Show all mappings
  console.log('\n3. All workdir-to-chat mappings:');
  const allSettings = chatSettings.getAllSettings();
  const workdirMappings = chatSettings.workdirToChat;
  
  console.log('   Chat-to-workdir mappings:');
  for (const [chatId, workdirName] of allSettings) {
    console.log(`     ${chatId} -> ${workdirName}`);
  }
  
  console.log('   Workdir-to-chat mappings:');
  for (const [workdir, chatId] of workdirMappings) {
    console.log(`     ${workdir} -> ${chatId}`);
  }
  
  // Test command-line task creation
  console.log('\n4. Testing command-line task with workdir association:');
  console.log('   Creating a task from command line in current directory...');
  console.log('   This should use chat ID:', testChatId2);
  
  try {
    // Create a simple add task in the current directory
    const output = execSync(`cd "${testWorkdirPath2}" && ani-code add "test-cli" "write a haiku about code"`, { encoding: 'utf8' });
    console.log('   Task created successfully!');
    console.log('   Output:', output.trim());
    console.log('   ✅ The task should send notifications to chat:', testChatId2);
  } catch (error) {
    console.log('   ❌ Failed to create task:', error.message);
  }
  
  console.log('\n✅ All tests completed!');
  console.log('Note: Check Lark messages to verify notifications went to the correct chats.');
}

// Run the test
testWorkdirChatMapping().catch(error => {
  console.error('Test failed:', error);
  process.exit(1);
});
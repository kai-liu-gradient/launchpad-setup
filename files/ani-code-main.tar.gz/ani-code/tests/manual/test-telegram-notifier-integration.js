#!/usr/bin/env node
import { TelegramNotifier } from './src/telegram-notifier.js';
import { config } from './src/config.js';

async function testTelegramNotifierIntegration() {
  console.log('Testing TelegramNotifier integration with new API...\n');
  
  // Check if bot token is configured
  if (!config.telegram?.botToken) {
    console.log('❌ Telegram bot token not configured');
    return;
  }
  
  const chatId = config.telegram?.chatId || '394977994'; // Default test chat
  
  try {
    // Initialize notifier
    console.log('1. Initializing TelegramNotifier...');
    const notifier = new TelegramNotifier();
    
    if (!notifier.isEnabled()) {
      console.log('❌ TelegramNotifier is not enabled');
      return;
    }
    console.log('✅ TelegramNotifier initialized with new API client');
    
    // Test sendMessage through notifier
    console.log('\n2. Testing sendMessage through TelegramNotifier...');
    const result = await notifier.sendMessage(
      chatId,
      '*Integration Test*\n\n' +
      'Testing TelegramNotifier with:\n' +
      '• New centralized Telegram API\n' +
      '• Axios HTTP client\n' +
      '• Enhanced logging\n' +
      '• Automatic retries',
      {
        parse_mode: 'Markdown'
      }
    );
    
    if (result && result.ok) {
      console.log(`✅ Message sent successfully (ID: ${result.result.message_id})`);
      
      // Test editMessage
      console.log('\n3. Testing editMessage through TelegramNotifier...');
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const editResult = await notifier.editMessage(
        chatId,
        result.result.message_id,
        '*Integration Test - UPDATED*\n\n' +
        'Testing TelegramNotifier with:\n' +
        '• New centralized Telegram API ✅\n' +
        '• Axios HTTP client ✅\n' +
        '• Enhanced logging ✅\n' +
        '• Automatic retries ✅\n\n' +
        '_All features working correctly!_',
        {
          parse_mode: 'Markdown'
        }
      );
      
      if (editResult && editResult.ok) {
        console.log('✅ Message edited successfully');
      }
    }
    
    // Test custom message
    console.log('\n4. Testing sendCustomMessage...');
    await notifier.sendCustomMessage(
      '📊 System Status',
      'Telegram API refactoring complete!\n\n' +
      '*Changes implemented:*\n' +
      '• Centralized API helper (telegram-api.js)\n' +
      '• Migrated from fetch to Axios\n' +
      '• Added comprehensive debug logging\n' +
      '• Request/response timing metrics\n' +
      '• Automatic retry with exponential backoff\n' +
      '• Better error handling',
      chatId
    );
    console.log('✅ Custom message sent');
    
    // Test help message
    console.log('\n5. Testing sendHelpMessage...');
    await notifier.sendHelpMessage(chatId, 'test-workspace');
    console.log('✅ Help message sent');
    
    console.log('\n✅ All integration tests completed successfully!');
    
  } catch (error) {
    console.error('\n❌ Integration test failed:', error.message);
    console.error('Stack:', error.stack);
  }
}

// Run the test
testTelegramNotifierIntegration().catch(console.error);
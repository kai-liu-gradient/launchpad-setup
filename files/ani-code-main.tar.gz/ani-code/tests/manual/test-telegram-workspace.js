#!/usr/bin/env node

import { WorkspaceManager } from './src/workspace-manager.js';
import { ChatSettingsManager } from './src/chat-settings.js';

async function test() {
  const workspaceManager = new WorkspaceManager();
  await workspaceManager.initialize();
  
  const chatSettings = new ChatSettingsManager();
  await chatSettings.load();
  
  const telegramChatId = '394977994';
  const fullChatId = `telegram:${telegramChatId}`;
  
  console.log('\n=== Testing Telegram Workspace Connection ===\n');
  
  // Check if chat is authorized
  const authInfo = await workspaceManager.isTelegramChatAuthorized(telegramChatId);
  console.log('Authorization info:', authInfo);
  
  // Check chat settings
  const workdirName = chatSettings.getWorkdir(fullChatId);
  console.log(`Chat settings workdir name for ${fullChatId}:`, workdirName);
  
  // Check all settings
  const allSettings = chatSettings.getAllSettings();
  console.log('All chat settings:', Object.fromEntries(allSettings));
  
  // Test getAvailableWorkdirs logic
  const config = (await import('./src/config.js')).config;
  const workdirs = { ...config.lark.workdirs };
  console.log('Base workdirs from config:', workdirs);
  
  if (authInfo && authInfo.authorized && authInfo.workspace_name && authInfo.workspace_path) {
    workdirs[authInfo.workspace_name] = authInfo.workspace_path;
    console.log(`Would add workspace: ${authInfo.workspace_name} -> ${authInfo.workspace_path}`);
  }
  
  console.log('Final available workdirs:', workdirs);
  
  await workspaceManager.close();
}

test().catch(console.error);
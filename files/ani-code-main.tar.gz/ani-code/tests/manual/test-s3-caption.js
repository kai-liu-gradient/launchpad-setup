#!/usr/bin/env node

// Test script to verify image upload with caption creates a task

const http = require('http');
const fs = require('fs');
const path = require('path');

// Configuration
const SERVER_HOST = 'localhost';
const SERVER_PORT = 8001;
const TELEGRAM_WEBHOOK_PATH = '/webhook/telegram/'; // Will append chat ID
const TEST_CHAT_ID = '123456789'; // Test chat ID

// Create a test image buffer (1x1 transparent PNG)
const testImageBase64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';
const testImageBuffer = Buffer.from(testImageBase64, 'base64');

// Create test telegram message with image and caption
function createTestMessage(caption) {
  return {
    update_id: Date.now(),
    message: {
      message_id: Date.now(),
      date: Math.floor(Date.now() / 1000),
      chat: {
        id: parseInt(TEST_CHAT_ID),
        type: 'private'
      },
      from: {
        id: 987654321,
        is_bot: false,
        first_name: 'Test',
        username: 'testuser'
      },
      photo: [
        {
          file_id: 'test_file_id_' + Date.now(),
          file_unique_id: 'test_unique_' + Date.now(),
          file_size: testImageBuffer.length,
          width: 1,
          height: 1
        }
      ],
      caption: caption
    }
  };
}

// Send test webhook request
function sendWebhookRequest(message) {
  const postData = JSON.stringify(message);
  
  const options = {
    hostname: SERVER_HOST,
    port: SERVER_PORT,
    path: TELEGRAM_WEBHOOK_PATH + TEST_CHAT_ID,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData)
    }
  };

  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        resolve({
          statusCode: res.statusCode,
          headers: res.headers,
          body: data
        });
      });
    });
    
    req.on('error', reject);
    req.write(postData);
    req.end();
  });
}

async function runTests() {
  console.log('Testing Telegram Caption Processing\n');
  console.log('=====================================\n');
  
  const testCases = [
    {
      name: 'Image with descriptive caption (should create task)',
      caption: 'Analyze this chart and explain the trends'
    },
    {
      name: 'Image with /url command (should NOT create task)',
      caption: '/url'
    },
    {
      name: 'Image with /add command and prompt (should create task)',
      caption: '/add What objects are in this image?'
    },
    {
      name: 'Image without caption (should NOT create task)',
      caption: ''
    },
    {
      name: 'Image with simple caption (should create task)',
      caption: 'What is this?'
    }
  ];
  
  for (const testCase of testCases) {
    console.log(`\nTest: ${testCase.name}`);
    console.log(`Caption: "${testCase.caption}"`);
    
    try {
      const message = createTestMessage(testCase.caption);
      const response = await sendWebhookRequest(message);
      
      console.log(`Response Status: ${response.statusCode}`);
      
      if (response.body) {
        try {
          const body = JSON.parse(response.body);
          console.log('Response Body:', JSON.stringify(body, null, 2));
        } catch (e) {
          console.log('Response Body (raw):', response.body);
        }
      }
      
      // Determine expected behavior
      const shouldCreateTask = 
        testCase.caption && 
        !testCase.caption.startsWith('/url') &&
        testCase.caption.length > 0;
      
      console.log(`Expected: ${shouldCreateTask ? 'Create task' : 'No task creation'}`);
      
    } catch (error) {
      console.error(`Error: ${error.message}`);
    }
    
    console.log('-'.repeat(40));
  }
}

// Run tests
runTests().then(() => {
  console.log('\n✅ Tests completed');
}).catch(error => {
  console.error('\n❌ Test failed:', error);
  process.exit(1);
});
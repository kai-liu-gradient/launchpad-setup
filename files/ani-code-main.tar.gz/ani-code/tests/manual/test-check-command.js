#!/usr/bin/env node

import { config } from './src/config.js';
import { logger } from './src/logger.js';
import fetch from 'node-fetch';

// Simple test for /check command through Lark webhook
async function testCheckCommand() {
  try {
    const webhookUrl = `http://localhost:${config.http.port}/callback/lark`;
    
    // Simulate a Lark message event with /check command
    const payload = {
      schema: '2.0',
      header: {
        event_type: 'im.message.receive_v1',
        event_id: `test-${Date.now()}`,
        create_time: Date.now().toString(),
        token: config.lark.verificationToken || 'test-token'
      },
      event: {
        message: {
          message_id: `test-msg-${Date.now()}`,
          chat_id: 'test-chat-001',
          chat_type: 'p2p',
          message_type: 'text',
          content: JSON.stringify({ text: '/check' }),
          create_time: Date.now().toString()
        },
        sender: {
          sender_id: {
            open_id: 'test-user-001'
          }
        }
      }
    };
    
    console.log('Sending test /check command to webhook...');
    
    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });
    
    const result = await response.text();
    console.log('Response status:', response.status);
    console.log('Response body:', result);
    
    if (response.status === 200) {
      console.log('✅ Test passed - /check command accepted');
    } else {
      console.log('❌ Test failed - unexpected status code');
    }
    
  } catch (error) {
    console.error('Test error:', error);
  }
}

// Run the test
console.log('Testing /check command implementation...');
testCheckCommand();
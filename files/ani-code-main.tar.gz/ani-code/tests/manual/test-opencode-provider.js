#!/usr/bin/env node

/**
 * Test OpenCode CLI Provider Support
 *
 * This test validates:
 * 1. OpenCodeCliHandler implementation
 * 2. Provider manager registration
 * 3. Output extraction for opencode
 * 4. Cost calculation for opencode models
 * 5. Provider switching
 */

import { OpenCodeCliHandler } from '../../src/providers/opencodeCliHandler.js';
import { getProviderManager } from '../../src/providers/providerManager.js';
import {
  extractOpencodeConclusion,
  extractOpencodeTokens,
  extractOpencodeModel,
  extractProviderConclusion,
  extractProviderTokens,
  extractProviderModel
} from '../../src/providers/outputExtractor.js';
import {
  calculateTokenCost,
  getModelPricing,
  getKnownModels,
  hasPricingData
} from '../../src/providers/costCalculator.js';

console.log('='.repeat(60));
console.log('Testing OpenCode Provider Support');
console.log('='.repeat(60));

// Test 1: OpenCodeCliHandler instantiation
console.log('\n1. OpenCodeCliHandler Instantiation Test');
console.log('-'.repeat(60));

const opencode = new OpenCodeCliHandler();
console.log('Handler ID:', opencode.id);
console.log('Handler Name:', opencode.name);
console.log('Handler Binary:', opencode.binary);
console.log('OK ID is opencode:', opencode.id === 'opencode');
console.log('OK Name is OpenCode:', opencode.name === 'OpenCode');
console.log('OK Binary is opencode:', opencode.binary === 'opencode');

// Test 2: OpenCodeCliHandler defaults
console.log('\n2. OpenCodeCliHandler Defaults Test');
console.log('-'.repeat(60));

const defaults = OpenCodeCliHandler.getDefaults();
console.log('Default binary:', defaults.binary);
console.log('Default args:', JSON.stringify(defaults.args));
console.log('Default env:', JSON.stringify(defaults.env));
console.log('OK Default binary is opencode:', defaults.binary === 'opencode');
console.log('OK Default args is empty array:', Array.isArray(defaults.args) && defaults.args.length === 0);

// Test 3: OpenCodeCliHandler capabilities
console.log('\n3. OpenCodeCliHandler Capabilities Test');
console.log('-'.repeat(60));

const capabilities = opencode.getCapabilities();
console.log('Capabilities:', JSON.stringify(capabilities, null, 2));
console.log('OK Supports create:', capabilities.supportsCreate === true);
console.log('OK Supports continue:', capabilities.supportsContinue === true);
console.log('OK Supports greenlight:', capabilities.supportsGreenlight === true);
console.log('OK Supports models:', capabilities.supportsModels === true);
console.log('OK High privilege:', capabilities.highPrivilege === true);

// Test 4: Model flags generation
console.log('\n4. Model Flags Generation Test');
console.log('-'.repeat(60));

const sonnetFlags = opencode.getModelFlags('sonnet');
console.log('Sonnet flags:', sonnetFlags.join(' '));
console.log('OK Sonnet maps to anthropic/claude-sonnet-4:', sonnetFlags.includes('anthropic/claude-sonnet-4-20250514'));

const opusFlags = opencode.getModelFlags('opus');
console.log('Opus flags:', opusFlags.join(' '));
console.log('OK Opus maps to anthropic/claude-opus-4:', opusFlags.includes('anthropic/claude-opus-4-20250514'));

const gpt4oFlags = opencode.getModelFlags('gpt-4o');
console.log('GPT-4o flags:', gpt4oFlags.join(' '));
console.log('OK GPT-4o maps to openai/gpt-4o:', gpt4oFlags.includes('openai/gpt-4o'));

const geminiFlags = opencode.getModelFlags('gemini');
console.log('Gemini flags:', geminiFlags.join(' '));
console.log('OK Gemini maps to google/gemini-2.0-flash:', geminiFlags.includes('google/gemini-2.0-flash'));

const providerModelFlags = opencode.getModelFlags('anthropic/claude-3-opus');
console.log('Provider/model format flags:', providerModelFlags.join(' '));
console.log('OK Provider/model passed through:', providerModelFlags.includes('anthropic/claude-3-opus'));

const noFlags = opencode.getModelFlags(null);
console.log('Null flags:', noFlags.length === 0 ? '(none)' : noFlags.join(' '));
console.log('OK Null returns empty:', noFlags.length === 0);

// Test 5: Provider Manager Registration
console.log('\n5. Provider Manager Registration Test');
console.log('-'.repeat(60));

const pm = await getProviderManager();
const opencodeHandler = pm.getHandler('opencode');
console.log('OpenCode handler registered:', opencodeHandler !== undefined);
console.log('OK OpenCode handler exists:', opencodeHandler !== undefined);

if (opencodeHandler) {
  console.log('Registered handler ID:', opencodeHandler.id);
  console.log('Registered handler name:', opencodeHandler.name);
  console.log('OK Handler ID matches:', opencodeHandler.id === 'opencode');
}

// Test 6: Provider Switching
console.log('\n6. Provider Switching Test');
console.log('-'.repeat(60));

const originalProvider = pm.getCurrentHandler();
console.log('Original provider:', originalProvider.id);

try {
  pm.switchProvider('opencode');
  const currentAfterSwitch = pm.getCurrentHandler();
  console.log('After switch to opencode:', currentAfterSwitch.id);
  console.log('OK Switched to opencode:', currentAfterSwitch.id === 'opencode');

  // Switch back to original
  pm.switchProvider(originalProvider.id);
  console.log('Switched back to:', pm.getCurrentHandler().id);
  console.log('OK Switched back:', pm.getCurrentHandler().id === originalProvider.id);
} catch (error) {
  console.log('FAIL Switch failed:', error.message);
}

// Test 7: OpenCode Output Extraction - Text Format
console.log('\n7. OpenCode Output Extraction - Text Format');
console.log('-'.repeat(60));

const opencodeTextOutput = [
  'session: abc123',
  'model: anthropic/claude-sonnet-4',
  '',
  'thinking...',
  'processing request...',
  '',
  'Assistant: I have analyzed your request. Here is the solution:',
  '',
  'The result of 2 + 2 is 4.',
  '',
  'This is a simple arithmetic operation.',
  '',
  'User: Thanks!',
  '',
  'Assistant: You are welcome! Let me know if you need anything else.'
].join('\n');

const textConclusion = extractOpencodeConclusion(opencodeTextOutput);
console.log('Extracted conclusion:', textConclusion.substring(0, 100) + '...');
console.log('OK Contains final response:', textConclusion.includes('welcome'));

// Test 8: OpenCode Output Extraction - JSON Format
console.log('\n8. OpenCode Output Extraction - JSON Format');
console.log('-'.repeat(60));

const opencodeJsonOutput = JSON.stringify({
  model: 'anthropic/claude-sonnet-4',
  response: 'The answer is 42.',
  stats: {
    tokens: {
      total: 1500
    }
  },
  usage: {
    total_tokens: 1500
  }
});

const jsonConclusion = extractOpencodeConclusion(opencodeJsonOutput);
console.log('Extracted from JSON:', jsonConclusion.substring(0, 50) + '...');
console.log('OK Returns content:', jsonConclusion.length > 0);

// Test 9: OpenCode Token Extraction
console.log('\n9. OpenCode Token Extraction');
console.log('-'.repeat(60));

// Test with "tokens used" pattern
const tokenOutput1 = 'Task completed. tokens used: 12,345';
const tokens1 = extractOpencodeTokens(tokenOutput1);
console.log('Pattern "tokens used: 12,345":', tokens1);
console.log('OK Extracted 12345:', tokens1 === 12345);

// Test with JSON stats
const tokenOutputJson = '{ "stats": { "tokens": { "total": 9876 } } }';
const tokensJson = extractOpencodeTokens(tokenOutputJson);
console.log('JSON stats.tokens.total:', tokensJson);
console.log('OK Extracted 9876:', tokensJson === 9876);

// Test with JSON usage
const tokenOutputUsage = '{ "usage": { "total_tokens": 5432 } }';
const tokensUsage = extractOpencodeTokens(tokenOutputUsage);
console.log('JSON usage.total_tokens:', tokensUsage);
console.log('OK Extracted 5432:', tokensUsage === 5432);

// Test via generic function
const tokensViaProvider = extractProviderTokens(tokenOutput1, 'opencode');
console.log('Via extractProviderTokens:', tokensViaProvider);
console.log('OK Generic function works:', tokensViaProvider === 12345);

// Test 10: OpenCode Model Extraction
console.log('\n10. OpenCode Model Extraction');
console.log('-'.repeat(60));

// Test with "model:" pattern
const modelOutput1 = 'Using the Sonnet model for this task.\nmodel: anthropic/claude-sonnet-4';
const model1 = extractOpencodeModel(modelOutput1);
console.log('Pattern "model: anthropic/claude-sonnet-4":', model1);
console.log('OK Extracted anthropic/claude-sonnet-4:', model1 === 'anthropic/claude-sonnet-4');

// Test with JSON model
const modelOutputJson = '{ "model": "openai/gpt-4o" }';
const modelJson = extractOpencodeModel(modelOutputJson);
console.log('JSON model:', modelJson);
console.log('OK Extracted openai/gpt-4o:', modelJson === 'openai/gpt-4o');

// Test with provider/model pattern
const modelOutputPattern = 'Session started with [anthropic/claude-3-opus]';
const modelPattern = extractOpencodeModel(modelOutputPattern);
console.log('Pattern [anthropic/claude-3-opus]:', modelPattern);
console.log('OK Extracted anthropic/claude-3-opus:', modelPattern === 'anthropic/claude-3-opus');

// Test via generic function
const modelViaProvider = extractProviderModel(modelOutput1, 'opencode');
console.log('Via extractProviderModel:', modelViaProvider);
console.log('OK Generic function works:', modelViaProvider === 'anthropic/claude-sonnet-4');

// Test 11: Cost Calculation for OpenCode
console.log('\n11. Cost Calculation for OpenCode');
console.log('-'.repeat(60));

console.log('OK Has opencode pricing:', hasPricingData('opencode'));

const opencodeModels = getKnownModels('opencode');
console.log('Known opencode models:', opencodeModels.length);
console.log('Sample models:', opencodeModels.slice(0, 5).join(', '));

// Test Anthropic model cost
const anthropicPricing = getModelPricing('opencode', 'anthropic/claude-sonnet-4');
console.log('anthropic/claude-sonnet-4 pricing:', JSON.stringify(anthropicPricing));

const anthropicCost = calculateTokenCost({
  providerId: 'opencode',
  modelId: 'anthropic/claude-sonnet-4',
  totalTokens: 10000
});
console.log('anthropic/claude-sonnet-4 cost for 10k tokens: $' + anthropicCost.totalCost.toFixed(6));
console.log('OK Cost calculated:', anthropicCost.totalCost > 0);

// Test OpenAI model cost
const openaiCost = calculateTokenCost({
  providerId: 'opencode',
  modelId: 'openai/gpt-4o',
  totalTokens: 10000
});
console.log('openai/gpt-4o cost for 10k tokens: $' + openaiCost.totalCost.toFixed(6));
console.log('OK OpenAI cost calculated:', openaiCost.totalCost > 0);

// Test Google model cost
const googleCost = calculateTokenCost({
  providerId: 'opencode',
  modelId: 'google/gemini-2.5-flash',
  totalTokens: 10000
});
console.log('google/gemini-2.5-flash cost for 10k tokens: $' + googleCost.totalCost.toFixed(6));
console.log('OK Google cost calculated:', googleCost.totalCost > 0);

// Test local model cost (should be zero)
const localCost = calculateTokenCost({
  providerId: 'opencode',
  modelId: 'local/llama',
  totalTokens: 10000
});
console.log('local/llama cost for 10k tokens: $' + localCost.totalCost.toFixed(6));
console.log('OK Local model is free:', localCost.totalCost === 0);

// Test default model cost
const defaultCost = calculateTokenCost({
  providerId: 'opencode',
  modelId: 'unknown-model',
  totalTokens: 10000
});
console.log('Default model cost for 10k tokens: $' + defaultCost.totalCost.toFixed(6));
console.log('OK Default cost calculated:', defaultCost.totalCost > 0);

// Test 12: Integration Test - Full Flow
console.log('\n12. Integration Test - Full Flow');
console.log('-'.repeat(60));

const fullOutput = [
  'Starting OpenCode session...',
  'model: anthropic/claude-sonnet-4',
  'Working directory: /root/workspace/test',
  '',
  'Assistant: I will analyze this codebase and provide recommendations.',
  '',
  'After reviewing the code, I have found the following:',
  '1. Good test coverage',
  '2. Clean architecture',
  '3. Some optimization opportunities',
  '',
  'Total tokens used: 25,000'
].join('\n');

const extractedConclusion = extractProviderConclusion(fullOutput, 'opencode');
const extractedTokens = extractProviderTokens(fullOutput, 'opencode');
const extractedModel = extractProviderModel(fullOutput, 'opencode');

console.log('Extracted conclusion length:', extractedConclusion.length);
console.log('Extracted tokens:', extractedTokens);
console.log('Extracted model:', extractedModel);

const estimatedCost = calculateTokenCost({
  providerId: 'opencode',
  modelId: extractedModel,
  totalTokens: extractedTokens
});

console.log('Estimated cost: $' + estimatedCost.totalCost.toFixed(4));
console.log('OK Full flow integration:', extractedTokens > 0 && extractedModel && estimatedCost.totalCost > 0);

// Test 13: Edge Cases
console.log('\n13. Edge Cases');
console.log('-'.repeat(60));

console.log('Null conclusion:', extractOpencodeConclusion(null) === null);
console.log('Empty conclusion:', extractOpencodeConclusion(''));
console.log('Null tokens:', extractOpencodeTokens(null));
console.log('Empty tokens:', extractOpencodeTokens(''));
console.log('Null model:', extractOpencodeModel(null));
console.log('Empty model:', extractOpencodeModel(''));
console.log('OK Edge cases handled gracefully');

// Test 14: Provider List includes OpenCode
console.log('\n14. Provider List Test');
console.log('-'.repeat(60));

const providers = pm.listProviders();
const opencodeInList = providers.some(p => p.id === 'opencode');
console.log('Providers in list:', providers.map(p => p.id).join(', '));
// Note: opencode may not appear if binary is not installed
console.log('OpenCode in list (if binary available):', opencodeInList);

// Test 15: Verify handlerClasses includes opencode
console.log('\n15. Handler Classes Mapping Test');
console.log('-'.repeat(60));

// Access the handler classes mapping to verify opencode is registered
const handlerClasses = pm.handlerClasses;
console.log('OpenCode in handlerClasses:', handlerClasses.opencode !== undefined);
console.log('OK Handler class is OpenCodeCliHandler:', handlerClasses.opencode === OpenCodeCliHandler);

console.log('\n' + '='.repeat(60));
console.log('All OpenCode Provider Tests Complete');
console.log('='.repeat(60));

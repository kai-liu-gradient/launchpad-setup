#!/usr/bin/env node
import { TelegramAPI } from './src/telegram-api.js';
import { config } from './src/config.js';
import { logger } from './src/logger.js';

async function testTelegramAPI() {
  console.log('Testing Telegram API refactor with comprehensive logging...\n');
  
  // Check if bot token is configured
  if (!config.telegram?.botToken) {
    console.log('❌ Telegram bot token not configured');
    return;
  }
  
  const chatId = config.telegram?.chatId || '394977994'; // Default test chat
  
  try {
    // Initialize API client
    console.log('1. Initializing Telegram API client...');
    const api = new TelegramAPI(config.telegram.botToken);
    
    // Test getMe
    console.log('\n2. Testing getMe() - Getting bot info...');
    const botInfo = await api.getMe();
    if (botInfo.ok) {
      console.log(`✅ Bot connected: @${botInfo.result.username} (ID: ${botInfo.result.id})`);
    } else {
      console.log('❌ Failed to get bot info');
      return;
    }
    
    // Test sendMessage
    console.log(`\n3. Testing sendMessage() to chat ${chatId}...`);
    const messageResult = await api.sendMessage(chatId, 
      '🧪 Testing refactored Telegram API with Axios\n\n' +
      'Features:\n' +
      '✅ Centralized API helper\n' +
      '✅ Axios instead of fetch\n' +
      '✅ Comprehensive debug logging\n' +
      '✅ Automatic retry with exponential backoff\n' +
      '✅ Request/response timing\n' +
      '✅ Credential masking',
      {
        parse_mode: 'Markdown'
      }
    );
    
    if (messageResult.ok) {
      console.log(`✅ Message sent successfully (ID: ${messageResult.result.message_id})`);
      
      // Test editMessage
      console.log('\n4. Testing editMessageText()...');
      await new Promise(resolve => setTimeout(resolve, 2000)); // Wait 2 seconds
      
      const editResult = await api.editMessageText(
        chatId,
        messageResult.result.message_id,
        '🧪 Testing refactored Telegram API with Axios\n\n' +
        'Features:\n' +
        '✅ Centralized API helper\n' +
        '✅ Axios instead of fetch\n' +
        '✅ Comprehensive debug logging\n' +
        '✅ Automatic retry with exponential backoff\n' +
        '✅ Request/response timing\n' +
        '✅ Credential masking\n\n' +
        '✏️ *Message successfully edited!*',
        {
          parse_mode: 'Markdown'
        }
      );
      
      if (editResult.ok) {
        console.log('✅ Message edited successfully');
      } else {
        console.log('❌ Failed to edit message');
      }
      
      // Test webhook info
      console.log('\n5. Testing getWebhookInfo()...');
      const webhookInfo = await api.getWebhookInfo();
      if (webhookInfo.ok) {
        const info = webhookInfo.result;
        if (info.url) {
          console.log(`✅ Webhook configured: ${info.url}`);
          console.log(`   Pending updates: ${info.pending_update_count || 0}`);
        } else {
          console.log('✅ No webhook configured (using polling mode)');
        }
      }
      
      // Test with simulated network error (invalid file ID)
      console.log('\n6. Testing error handling with invalid file ID...');
      try {
        await api.getFile('invalid_file_id_12345');
      } catch (error) {
        console.log(`✅ Error handled correctly: ${error.message.substring(0, 50)}...`);
      }
      
      console.log('\n✅ All tests completed successfully!');
      console.log('\nCheck the logs above for detailed request/response information.');
      
    } else {
      console.log('❌ Failed to send test message');
    }
    
  } catch (error) {
    console.error('\n❌ Test failed:', error.message);
    console.error('Stack:', error.stack);
  }
}

// Run the test
testTelegramAPI().catch(console.error);
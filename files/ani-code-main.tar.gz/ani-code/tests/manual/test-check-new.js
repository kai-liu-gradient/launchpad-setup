#!/usr/bin/env node

import { config } from './src/config.js';
import fetch from 'node-fetch';

async function testCheckCommand() {
  try {
    const webhookUrl = `http://localhost:${config.http.port}/callback/lark`;
    
    const payload = {
      schema: '2.0',
      header: {
        event_type: 'im.message.receive_v1',
        event_id: `test-new-${Date.now()}`,
        create_time: Date.now().toString(),
        token: config.lark.verificationToken || 'test-token'
      },
      event: {
        message: {
          message_id: `test-msg-new-${Date.now()}`,
          chat_id: 'test-chat-new',
          chat_type: 'p2p',
          message_type: 'text',
          content: JSON.stringify({ text: '/check testing new format' })
        }
      }
    };
    
    console.log('Sending test /check command with new format...');
    
    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });
    
    const result = await response.text();
    console.log('Response status:', response.status);
    console.log('Response body:', result);
    
    if (response.status === 200) {
      console.log('✅ Test passed - new /check command accepted');
    } else {
      console.log('❌ Test failed - unexpected status code');
    }
    
  } catch (error) {
    console.error('Test error:', error);
  }
}

testCheckCommand();
#!/usr/bin/env node

/**
 * Test script for file attachment feature
 * Tests sending messages with @filename syntax to attach files
 */

import { TelegramNotifier } from '../../src/telegram-notifier.js';
import { logger } from '../../src/logger.js';
import chalk from 'chalk';

async function testFileAttachments() {
  console.log(chalk.cyan('=== Testing File Attachments Feature ===\n'));

  try {
    const notifier = new TelegramNotifier();

    if (!notifier.isEnabled()) {
      console.error(chalk.red('Telegram bot token not configured'));
      console.log(chalk.yellow('Set TELEGRAM_BOT_TOKEN environment variable'));
      process.exit(1);
    }

    // Test workspace ID (you may need to adjust this)
    const workspaceId = 'ani-code';  // or use actual workspace name/ID

    console.log(chalk.blue('Test 1: Message with single text attachment'));
    const message1 = 'Here is a test file: @tmp/test-attachment.txt';
    const result1 = await notifier.sendMessageToWorkspace(workspaceId, message1);
    console.log(chalk.green('✓ Test 1 passed:'), result1);

    console.log(chalk.blue('\nTest 2: Message with multiple attachments'));
    const message2 = 'Multiple files: @tmp/test-attachment.txt and @tmp/test-message.md';
    const result2 = await notifier.sendMessageToWorkspace(workspaceId, message2);
    console.log(chalk.green('✓ Test 2 passed:'), result2);

    console.log(chalk.blue('\nTest 3: Message with non-existent file (should handle gracefully)'));
    const message3 = 'This references a non-existent file: @tmp/does-not-exist.txt';
    const result3 = await notifier.sendMessageToWorkspace(workspaceId, message3);
    console.log(chalk.green('✓ Test 3 passed:'), result3);

    console.log(chalk.blue('\nTest 4: Message without attachments'));
    const message4 = 'This is a regular message without any attachments';
    const result4 = await notifier.sendMessageToWorkspace(workspaceId, message4);
    console.log(chalk.green('✓ Test 4 passed:'), result4);

    console.log(chalk.green('\n✅ All tests completed successfully!'));

  } catch (error) {
    console.error(chalk.red('\n❌ Test failed:'), error.message);
    console.error(error.stack);
    process.exit(1);
  }
}

// Run the test
testFileAttachments().catch(error => {
  console.error(chalk.red('Unhandled error:'), error);
  process.exit(1);
});
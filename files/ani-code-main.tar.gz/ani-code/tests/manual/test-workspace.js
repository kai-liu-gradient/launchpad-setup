#!/usr/bin/env node

import { WorkspaceManager } from './src/workspace-manager.js';
import chalk from 'chalk';

async function testWorkspaceManagement() {
  console.log(chalk.blue.bold('\n🧪 Testing Workspace Management System\n'));
  
  const manager = new WorkspaceManager();
  
  try {
    // Initialize database
    console.log(chalk.cyan('1. Initializing workspace database...'));
    await manager.initialize();
    console.log(chalk.green('✓ Database initialized successfully'));
    
    // Create a test workspace
    console.log(chalk.cyan('\n2. Creating test workspace...'));
    const workspace = await manager.createWorkspace(
      'test-workspace',
      '/tmp/test-workspace',
      'Test workspace for validation'
    );
    console.log(chalk.green(`✓ Created workspace: ${workspace.name} (${workspace.id})`));
    
    // Generate a token
    console.log(chalk.cyan('\n3. Generating access token...'));
    const tokenData = await manager.generateToken(
      workspace.id,
      'Test token',
      'api',
      ['read', 'write'],
      7 // 7 days expiration
    );
    console.log(chalk.green(`✓ Generated token with ID: ${tokenData.id}`));
    console.log(chalk.gray(`   Token (first 50 chars): ${tokenData.token.substring(0, 50)}...`));
    
    // Validate the token
    console.log(chalk.cyan('\n4. Validating token...'));
    const validation = await manager.validateToken(tokenData.token);
    if (validation.valid) {
      console.log(chalk.green('✓ Token validation successful'));
      console.log(chalk.gray(`   Workspace: ${validation.workspace_name}`));
      console.log(chalk.gray(`   Path: ${validation.workspace_path}`));
      console.log(chalk.gray(`   Permissions: ${validation.permissions.join(', ')}`));
    } else {
      console.log(chalk.red(`✗ Token validation failed: ${validation.error}`));
    }
    
    // List workspaces
    console.log(chalk.cyan('\n5. Listing workspaces...'));
    const workspaces = await manager.listWorkspaces();
    console.log(chalk.green(`✓ Found ${workspaces.length} workspace(s):`));
    workspaces.forEach(ws => {
      console.log(chalk.gray(`   - ${ws.name} (${ws.id.substring(0, 8)}...) at ${ws.path}`));
    });
    
    // Map a chat to workspace
    console.log(chalk.cyan('\n6. Mapping chat to workspace...'));
    const testChatId = 'oc_test_chat_123';
    const mapping = await manager.mapChatToWorkspace(testChatId, workspace.id);
    console.log(chalk.green(`✓ Mapped chat ${mapping.chat_id} to workspace ${mapping.workspace_name}`));
    
    // Get workspace for chat
    console.log(chalk.cyan('\n7. Getting workspace for chat...'));
    const chatWorkspace = await manager.getWorkspaceForChat(testChatId);
    if (chatWorkspace) {
      console.log(chalk.green(`✓ Found workspace for chat: ${chatWorkspace.workspace_name}`));
    } else {
      console.log(chalk.red('✗ No workspace found for chat'));
    }
    
    // Test WebSocket connection tracking
    console.log(chalk.cyan('\n8. Testing WebSocket connection tracking...'));
    const connectionId = await manager.registerWSConnection(
      workspace.id,
      tokenData.id,
      { userAgent: 'Test Client', remoteAddress: '127.0.0.1' }
    );
    console.log(chalk.green(`✓ Registered connection: ${connectionId}`));
    
    const activeConnections = await manager.getActiveConnections(workspace.id);
    console.log(chalk.green(`✓ Found ${activeConnections.length} active connection(s)`));
    
    await manager.disconnectWSConnection(connectionId);
    console.log(chalk.green('✓ Disconnected connection'));
    
    // Cleanup - delete test workspace
    console.log(chalk.cyan('\n9. Cleaning up test workspace...'));
    await manager.deleteWorkspace(workspace.id);
    console.log(chalk.green('✓ Test workspace deleted'));
    
    console.log(chalk.green.bold('\n✅ All tests passed successfully!\n'));
    
  } catch (error) {
    console.error(chalk.red(`\n❌ Test failed: ${error.message}`));
    console.error(chalk.gray(error.stack));
  } finally {
    await manager.close();
  }
}

// Run the test
testWorkspaceManagement().catch(console.error);
#!/usr/bin/env node

import fetch from 'node-fetch';
import { config } from './src/config.js';
import { logger } from './src/logger.js';

async function testLarkMessage() {
  console.log('🧪 Testing Lark Message Processing\n');
  console.log('==================================\n');
  
  // Check if HTTP server is configured
  const httpPort = config.http.port || 3000;
  const httpHost = config.http.host || 'localhost';
  const callbackUrl = `http://${httpHost}:${httpPort}/callback/lark`;
  
  console.log(`📡 Testing callback endpoint: ${callbackUrl}\n`);
  
  // Test 1: URL Verification
  console.log('Test 1: URL Verification Challenge');
  console.log('-----------------------------------');
  try {
    const verificationData = {
      type: 'url_verification',
      challenge: 'test_challenge_123456',
      token: config.lark.verificationToken || 'test_token'
    };
    
    const verificationResponse = await fetch(callbackUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(verificationData)
    });
    
    const verificationResult = await verificationResponse.json();
    console.log('✅ Verification Response:', verificationResult);
    
    if (verificationResult.challenge === verificationData.challenge) {
      console.log('✅ URL verification passed!\n');
    } else {
      console.log('❌ URL verification failed - challenge mismatch\n');
    }
  } catch (error) {
    console.error('❌ URL verification test failed:', error.message, '\n');
  }
  
  // Test 2: Message Event
  console.log('Test 2: Message Event');
  console.log('---------------------');
  try {
    const messageEvent = {
      type: 'event_callback',
      token: config.lark.verificationToken || 'test_token',
      event: {
        type: 'message',
        message: {
          chat_id: 'oc_test_chat_123456',
          content: JSON.stringify({ text: 'Test message from Lark' }),
          message_type: 'text'
        },
        sender: {
          sender_id: {
            user_id: 'test_user_123',
            open_id: 'test_open_id_123'
          }
        }
      }
    };
    
    const messageResponse = await fetch(callbackUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(messageEvent)
    });
    
    const messageResult = await messageResponse.json();
    console.log('✅ Message Event Response:', messageResult);
    
    if (messageResult.success && messageResult.taskId) {
      console.log(`✅ Task created with ID: ${messageResult.taskId}\n`);
    } else {
      console.log('ℹ️ Message processed without creating task\n');
    }
  } catch (error) {
    console.error('❌ Message event test failed:', error.message, '\n');
  }
  
  // Test 3: Card Action Event
  console.log('Test 3: Card Action Event');
  console.log('-------------------------');
  try {
    const cardActionEvent = {
      type: 'event_callback',
      token: config.lark.verificationToken || 'test_token',
      event: {
        type: 'card.action.trigger',
        action: {
          value: JSON.stringify({
            action: 'view_logs',
            taskId: 'test_task_123'
          }),
          tag: 'button'
        }
      }
    };
    
    const actionResponse = await fetch(callbackUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(cardActionEvent)
    });
    
    const actionResult = await actionResponse.json();
    console.log('✅ Card Action Response:', actionResult);
    
    if (actionResult.success) {
      console.log('✅ Card action processed successfully\n');
    } else {
      console.log(`ℹ️ Card action result: ${actionResult.message}\n`);
    }
  } catch (error) {
    console.error('❌ Card action test failed:', error.message, '\n');
  }
  
  // Test 4: Command Message
  console.log('Test 4: Command Message');
  console.log('-----------------------');
  try {
    const commandEvent = {
      type: 'event_callback',
      token: config.lark.verificationToken || 'test_token',
      event: {
        type: 'message',
        message: {
          chat_id: 'oc_test_chat_123456',
          content: JSON.stringify({ text: '/status' }),
          message_type: 'text'
        },
        sender: {
          sender_id: {
            user_id: 'test_user_123'
          }
        }
      }
    };
    
    const commandResponse = await fetch(callbackUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(commandEvent)
    });
    
    const commandResult = await commandResponse.json();
    console.log('✅ Command Response:', commandResult);
    
    if (commandResult.success && commandResult.data) {
      console.log('✅ Status command executed successfully');
      console.log('📊 Current Status:', commandResult.data, '\n');
    } else {
      console.log('ℹ️ Command processed\n');
    }
  } catch (error) {
    console.error('❌ Command message test failed:', error.message, '\n');
  }
  
  // Test 5: Task Creation Command
  console.log('Test 5: Task Creation Command');
  console.log('-----------------------------');
  try {
    const taskCommand = {
      type: 'event_callback',
      token: config.lark.verificationToken || 'test_token',
      event: {
        type: 'message',
        message: {
          chat_id: 'oc_test_chat_123456',
          content: JSON.stringify({ text: '/task echo "Hello from Lark test"' }),
          message_type: 'text'
        },
        sender: {
          sender_id: {
            user_id: 'test_user_123'
          }
        }
      }
    };
    
    const taskResponse = await fetch(callbackUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(taskCommand)
    });
    
    const taskResult = await taskResponse.json();
    console.log('✅ Task Creation Response:', taskResult);
    
    if (taskResult.success && taskResult.taskId) {
      console.log(`✅ Task created successfully with ID: ${taskResult.taskId}\n`);
    } else {
      console.log('❌ Task creation failed\n');
    }
  } catch (error) {
    console.error('❌ Task creation test failed:', error.message, '\n');
  }
  
  // Summary
  console.log('\n📊 Test Summary');
  console.log('===============');
  console.log('All tests completed. Check the logs above for results.');
  console.log('\n💡 Notes:');
  console.log('- Make sure ani-code HTTP server is running on port', httpPort);
  console.log('- The callback endpoint should be accessible at', callbackUrl);
  console.log('- Check server logs for detailed processing information');
  console.log('- Chat IDs found during testing will be logged in the server output');
}

// Run the test
testLarkMessage().catch(error => {
  console.error('❌ Test failed:', error);
  process.exit(1);
});
/**
 * Test for stripPatternsFromPrompt function
 * Run with: node tests/manual/test-pattern-stripping.js
 */

import { stripPatternsFromPrompt } from '../../src/model-utils.js';

console.log('Testing stripPatternsFromPrompt function...\n');

const testCases = [
  {
    input: 'fix the bug @@opus',
    expected: 'fix the bug'
  },
  {
    input: '@@sonnet please help me',
    expected: 'please help me'
  },
  {
    input: 'use @@opus to analyze this code',
    expected: 'use to analyze this code'
  },
  {
    input: 'fix the bug @@codex',
    expected: 'fix the bug'
  },
  {
    input: '@@deepseek optimize the database',
    expected: 'optimize the database'
  },
  {
    input: 'implement feature @@opus and @@sonnet both',
    expected: 'implement feature and both'
  },
  {
    input: 'regular command without patterns',
    expected: 'regular command without patterns'
  },
  {
    input: '@@opus @@sonnet @@codex @@deepseek all patterns',
    expected: 'all patterns'
  },
  {
    input: 'multiple   spaces   @@opus   test',
    expected: 'multiple spaces test'
  }
];

let passed = 0;
let failed = 0;

testCases.forEach((testCase, index) => {
  const result = stripPatternsFromPrompt(testCase.input);
  const success = result === testCase.expected;

  if (success) {
    passed++;
    console.log(`✅ Test ${index + 1} passed`);
  } else {
    failed++;
    console.log(`❌ Test ${index + 1} failed`);
    console.log(`   Input:    "${testCase.input}"`);
    console.log(`   Expected: "${testCase.expected}"`);
    console.log(`   Got:      "${result}"`);
  }
});

console.log(`\n📊 Results: ${passed} passed, ${failed} failed out of ${testCases.length} tests`);

if (failed === 0) {
  console.log('🎉 All tests passed!');
  process.exit(0);
} else {
  console.log('⚠️ Some tests failed');
  process.exit(1);
}

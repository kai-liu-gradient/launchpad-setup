#!/usr/bin/env node

import { SecureUploader } from './src/utils/secure-upload.js';
import { logger } from './src/logger.js';

async function testUploadWithVerification() {
  try {
    console.log('Testing image upload with verification...');
    
    const uploader = new SecureUploader();
    
    // Test with a public image URL
    const testImageUrl = 'https://via.placeholder.com/150';
    
    console.log(`Uploading test image from: ${testImageUrl}`);
    
    const result = await uploader.uploadImageFromUrl(testImageUrl, {
      workdir: 'test-verification',
      metadata: {
        'test': 'true',
        'purpose': 'verification-test'
      }
    });
    
    console.log('Upload completed successfully!');
    console.log('Result:', JSON.stringify(result, null, 2));
    
    // Try to access the URL directly
    console.log('\nAttempting to verify URL accessibility...');
    const response = await fetch(result.url, { method: 'HEAD' });
    
    if (response.ok) {
      console.log(`✅ URL is accessible: ${result.url}`);
      console.log(`   Status: ${response.status}`);
      console.log(`   Content-Type: ${response.headers.get('content-type')}`);
    } else {
      console.log(`❌ URL is not accessible: ${result.url}`);
      console.log(`   Status: ${response.status}`);
    }
    
  } catch (error) {
    console.error('Test failed:', error);
    process.exit(1);
  }
}

testUploadWithVerification();
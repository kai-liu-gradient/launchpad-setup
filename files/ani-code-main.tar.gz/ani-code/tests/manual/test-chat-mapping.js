#!/usr/bin/env node

import { ChatSettingsManager } from './src/chat-settings.js';
import { logger } from './src/logger.js';

async function testChatMapping() {
  const chatSettings = new ChatSettingsManager();
  await chatSettings.load();
  
  console.log('\n=== Testing Chat ID Mapping Logic ===\n');
  
  // Test scenarios
  const testPaths = [
    '/root/workspace/ghisha-dashboard-pilot',
    '/root/workspace/ani-code',
    '/root/workspace/ani-app-builder',
    '/root/workspace/ani-app-builder/projects/google-translate-wrapper',
    '/home/mhc/dev/ghisha',
    '/root/workspace/unknown-project',
  ];
  
  console.log('Current settings:');
  console.log('chatWorkdirs:', Object.fromEntries(chatSettings.settings));
  console.log('workdirToChat:', Object.fromEntries(chatSettings.workdirToChat));
  console.log('\n');
  
  for (const path of testPaths) {
    const chatId = chatSettings.getChatForWorkdir(path);
    console.log(`Path: ${path}`);
    console.log(`  -> Chat ID: ${chatId || 'null'}`);
    if (chatId) {
      const workdirName = chatSettings.getWorkdir(chatId);
      console.log(`  -> Workdir Name: ${workdirName}`);
    }
    console.log('');
  }
  
  // Check if the mapping was updated
  console.log('\nUpdated workdirToChat after test:');
  console.log(Object.fromEntries(chatSettings.workdirToChat));
}

testChatMapping().catch(console.error);
#!/usr/bin/env node

/**
 * Test output extraction for codex and cursor-agent
 */

import {
  extractCodexConclusion,
  extractCursorConclusion,
  extractGeminiConclusion,
  extractProviderConclusion,
  extractCodexTokens,
  extractGeminiTokens,
  extractProviderTokens,
  extractCodexModel,
  extractGeminiModel,
  extractProviderModel
} from '../../src/providers/outputExtractor.js';
import {
  calculateTokenCost,
  getModelPricing,
  getKnownProviders,
  getKnownModels,
  hasPricingData
} from '../../src/providers/costCalculator.js';

console.log('='.repeat(60));
console.log('Testing Output Extraction');
console.log('='.repeat(60));

// Test 1: Codex output extraction
const codexSample = `[2025-10-01T07:53:59] OpenAI Codex v0.36.0 (research preview)
--------
workdir: /root/workspace/ani-code
model: gpt-5-codex
provider: openai
approval: never
sandbox: read-only
reasoning effort: none
reasoning summaries: auto
--------
[2025-10-01T07:53:59] User instructions:
what is 2+2

[2025-10-01T07:54:02] thinking

**Providing simple approval output**
[2025-10-01T07:54:02] codex

4

[2025-10-01T07:54:02] tokens used: 2,371`;

console.log('\n1. Codex Extraction Test');
console.log('-'.repeat(60));
console.log('Original output length:', codexSample.length);
const codexExtracted = extractCodexConclusion(codexSample);
console.log('Extracted output length:', codexExtracted.length);
console.log('Extracted content:');
console.log('[START]');
console.log(codexExtracted);
console.log('[END]');
console.log('Expected: "4"');
console.log('✓ Extraction successful:', codexExtracted.trim() === '4');

// Test 2: Cursor output extraction (with answer marker)
const cursorSample1 = `Analyzing your question...

Thinking through the problem...

The calculation is straightforward.

Answer: 4

This is the correct result of adding 2 and 2.`;

console.log('\n2. Cursor Extraction Test (with Answer marker)');
console.log('-'.repeat(60));
console.log('Original output length:', cursorSample1.length);
const cursorExtracted1 = extractCursorConclusion(cursorSample1);
console.log('Extracted output length:', cursorExtracted1.length);
console.log('Extracted content:');
console.log('[START]');
console.log(cursorExtracted1);
console.log('[END]');
console.log('Expected: Answer after "Answer:"');
console.log('✓ Contains answer:', cursorExtracted1.includes('4'));

// Test 3: Cursor output extraction (without explicit marker)
const cursorSample2 = `Analyzing your question...

Thinking through the problem...

The calculation is straightforward.

The result is 4.`;

console.log('\n3. Cursor Extraction Test (without marker)');
console.log('-'.repeat(60));
console.log('Original output length:', cursorSample2.length);
const cursorExtracted2 = extractCursorConclusion(cursorSample2);
console.log('Extracted output length:', cursorExtracted2.length);
console.log('Extracted content:');
console.log('[START]');
console.log(cursorExtracted2);
console.log('[END]');
console.log('Expected: Last paragraph');
console.log('✓ Contains answer:', cursorExtracted2.includes('4'));

// Test 4: Generic provider extraction
console.log('\n4. Provider Extraction Test');
console.log('-'.repeat(60));
const codexViaProvider = extractProviderConclusion(codexSample, 'codex');
console.log('Codex via provider:', codexViaProvider.trim());
console.log('✓ Codex extraction:', codexViaProvider.trim() === '4');

const cursorViaProvider = extractProviderConclusion(cursorSample1, 'cursor');
console.log('Cursor via provider:', cursorViaProvider.substring(0, 50) + '...');
console.log('✓ Cursor extraction:', cursorViaProvider.includes('4'));

// Test 5: Unknown provider (should return original)
const unknownProvider = extractProviderConclusion('Some output', 'claude');
console.log('Unknown provider:', unknownProvider);
console.log('✓ Unknown provider returns original:', unknownProvider === 'Some output');

// Test 6: Codex Token Extraction
console.log('\n6. Codex Token Extraction Test');
console.log('-'.repeat(60));
const codexTokens = extractCodexTokens(codexSample);
console.log('Extracted tokens:', codexTokens);
console.log('Expected: 2371');
console.log('✓ Token extraction:', codexTokens === 2371);

// Test 7: Codex Model Extraction
console.log('\n7. Codex Model Extraction Test');
console.log('-'.repeat(60));
const codexModel = extractCodexModel(codexSample);
console.log('Extracted model:', codexModel);
console.log('Expected: gpt-5-codex');
console.log('✓ Model extraction:', codexModel === 'gpt-5-codex');

// Test 8: Gemini JSON Output Extraction
const geminiJsonSample = `Loaded cached credentials.
{
  "session_id": "5a93a5eb-8a0b-425d-a4d9-1558d3498626",
  "response": "2 + 2 is 4.",
  "stats": {
    "models": {
      "gemini-2.5-flash-lite": {
        "api": {
          "totalRequests": 1,
          "totalErrors": 0,
          "totalLatencyMs": 993
        },
        "tokens": {
          "input": 3130,
          "prompt": 3130,
          "candidates": 58,
          "total": 3229,
          "cached": 0,
          "thoughts": 41,
          "tool": 0
        }
      },
      "gemini-3-flash-preview": {
        "api": {
          "totalRequests": 1,
          "totalErrors": 0,
          "totalLatencyMs": 2239
        },
        "tokens": {
          "input": 2671,
          "prompt": 6056,
          "candidates": 8,
          "total": 6093,
          "cached": 3385,
          "thoughts": 29,
          "tool": 0
        }
      }
    },
    "tools": {
      "totalCalls": 0,
      "totalSuccess": 0,
      "totalFail": 0,
      "totalDurationMs": 0,
      "totalDecisions": {
        "accept": 0,
        "reject": 0,
        "modify": 0,
        "auto_accept": 0
      },
      "byName": {}
    },
    "files": {
      "totalLinesAdded": 0,
      "totalLinesRemoved": 0
    }
  }
}`;

console.log('\n8. Gemini JSON Conclusion Extraction Test');
console.log('-'.repeat(60));
const geminiConclusion = extractGeminiConclusion(geminiJsonSample);
console.log('Extracted conclusion:', geminiConclusion);
console.log('Expected: "2 + 2 is 4."');
console.log('✓ Conclusion extraction:', geminiConclusion === '2 + 2 is 4.');

// Test 9: Gemini Token Extraction
console.log('\n9. Gemini Token Extraction Test');
console.log('-'.repeat(60));
const geminiTokens = extractGeminiTokens(geminiJsonSample);
console.log('Extracted tokens:', geminiTokens);
console.log('Expected: 9322 (3229 + 6093)');
console.log('✓ Token extraction:', geminiTokens === 9322);

// Test 10: Gemini Model Extraction
console.log('\n10. Gemini Model Extraction Test');
console.log('-'.repeat(60));
const geminiModel = extractGeminiModel(geminiJsonSample);
console.log('Extracted model:', geminiModel);
console.log('Expected: gemini-3-flash-preview (higher token count)');
console.log('✓ Model extraction:', geminiModel === 'gemini-3-flash-preview');

// Test 11: Provider Token Extraction (via generic function)
console.log('\n11. Provider Token Extraction Tests');
console.log('-'.repeat(60));
const codexTokensViaProvider = extractProviderTokens(codexSample, 'codex');
console.log('Codex tokens via provider:', codexTokensViaProvider);
console.log('✓ Codex tokens:', codexTokensViaProvider === 2371);

const geminiTokensViaProvider = extractProviderTokens(geminiJsonSample, 'gemini');
console.log('Gemini tokens via provider:', geminiTokensViaProvider);
console.log('✓ Gemini tokens:', geminiTokensViaProvider === 9322);

// Test 12: Provider Model Extraction (via generic function)
console.log('\n12. Provider Model Extraction Tests');
console.log('-'.repeat(60));
const codexModelViaProvider = extractProviderModel(codexSample, 'codex');
console.log('Codex model via provider:', codexModelViaProvider);
console.log('✓ Codex model:', codexModelViaProvider === 'gpt-5-codex');

const geminiModelViaProvider = extractProviderModel(geminiJsonSample, 'gemini');
console.log('Gemini model via provider:', geminiModelViaProvider);
console.log('✓ Gemini model:', geminiModelViaProvider === 'gemini-3-flash-preview');

// Test 13: Edge cases
console.log('\n13. Edge Case Tests');
console.log('-'.repeat(60));
console.log('Null input for tokens:', extractCodexTokens(null));
console.log('Empty input for tokens:', extractCodexTokens(''));
console.log('Invalid JSON for Gemini:', extractGeminiTokens('not json'));
console.log('No model in output:', extractCodexModel('no model here'));
console.log('✓ Edge cases handled gracefully');

// Test 14: Cost Calculator - Known Providers
console.log('\n14. Cost Calculator - Known Providers');
console.log('-'.repeat(60));
const knownProviders = getKnownProviders();
console.log('Known providers:', knownProviders.join(', '));
console.log('✓ Has Gemini pricing:', hasPricingData('gemini'));
console.log('✓ Has Codex pricing:', hasPricingData('codex'));
console.log('✓ Has Claude pricing:', hasPricingData('claude'));

// Test 15: Cost Calculator - Gemini Cost Estimation
console.log('\n15. Cost Calculator - Gemini Cost Estimation');
console.log('-'.repeat(60));
const geminiCost = calculateTokenCost({
  providerId: 'gemini',
  modelId: 'gemini-2.5-flash-lite',
  totalTokens: 9322  // From test 9
});
console.log('Gemini cost for 9322 tokens:', `$${geminiCost.totalCost.toFixed(6)}`);
console.log('Estimated:', geminiCost.estimated);
console.log('✓ Cost calculated:', geminiCost.totalCost > 0);

// Test 16: Cost Calculator - Codex Cost Estimation
console.log('\n16. Cost Calculator - Codex Cost Estimation');
console.log('-'.repeat(60));
const codexCost = calculateTokenCost({
  providerId: 'codex',
  modelId: 'gpt-5-codex',  // Uses default pricing since model not known
  totalTokens: 2371  // From test 6
});
console.log('Codex cost for 2371 tokens:', `$${codexCost.totalCost.toFixed(6)}`);
console.log('Estimated:', codexCost.estimated);
console.log('✓ Cost calculated:', codexCost.totalCost > 0);

// Test 17: Cost Calculator - o3-mini Cost Estimation
console.log('\n17. Cost Calculator - o3-mini Cost Estimation');
console.log('-'.repeat(60));
const o3Cost = calculateTokenCost({
  providerId: 'codex',
  modelId: 'o3-mini',
  totalTokens: 100000  // 100k tokens
});
console.log('o3-mini cost for 100k tokens:', `$${o3Cost.totalCost.toFixed(4)}`);
console.log('Expected ~$0.341 (30% input * $1.10/M + 70% output * $4.40/M)');
console.log('✓ Cost matches expected:', Math.abs(o3Cost.totalCost - 0.341) < 0.01);

// Test 18: Cost Calculator - Integration with Token Extraction
console.log('\n18. Cost Calculator - Integration Test');
console.log('-'.repeat(60));
const extractedTokens = extractGeminiTokens(geminiJsonSample);
const extractedModel = extractGeminiModel(geminiJsonSample);
const integratedCost = calculateTokenCost({
  providerId: 'gemini',
  modelId: extractedModel,
  totalTokens: extractedTokens
});
console.log(`Model: ${extractedModel}, Tokens: ${extractedTokens}`);
console.log(`Estimated cost: $${integratedCost.totalCost.toFixed(6)}`);
console.log('✓ End-to-end integration:', integratedCost.totalCost > 0);

console.log('\n' + '='.repeat(60));
console.log('All Tests Complete');
console.log('='.repeat(60));

#!/usr/bin/env node

/**
 * Test script for the /connect command flow
 * This simulates a Lark message with the /connect command
 */

import fetch from 'node-fetch';
import chalk from 'chalk';
import { config } from './src/config.js';

async function testConnectCommand() {
  const httpHost = config.http.host || 'localhost';
  const httpPort = config.http.port || 3456;
  const callbackUrl = `http://${httpHost}:${httpPort}/callback/lark`;
  
  console.log(chalk.blue.bold('🧪 Testing /connect Command Flow\n'));
  console.log(`📡 Endpoint: ${callbackUrl}\n`);
  
  // Test 1: Connect without token (should show help)
  console.log(chalk.yellow('Test 1: /connect without token'));
  const noTokenMessage = {
    event: {
      message: {
        content: JSON.stringify({
          text: '/connect'
        }),
        chat_id: 'test_chat_001',
        message_type: 'text',
        mentions: [{
          key: '@_user_1',
          id: { open_id: 'bot_open_id' }
        }]
      },
      sender: {
        sender_id: {
          open_id: 'user_open_id'
        }
      }
    },
    header: {
      event_type: 'im.message.receive_v1',
      event_id: `test_event_${Date.now()}_1`
    }
  };
  
  try {
    const response1 = await fetch(callbackUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(noTokenMessage)
    });
    
    const result1 = await response1.json();
    console.log(chalk.green('✓ Response received:'), result1);
    console.log(chalk.gray('  Expected: Help message about providing token\n'));
  } catch (error) {
    console.error(chalk.red('✗ Error:'), error.message);
  }
  
  // Test 2: Connect with invalid token
  console.log(chalk.yellow('Test 2: /connect with invalid token'));
  const invalidTokenMessage = {
    event: {
      message: {
        content: JSON.stringify({
          text: '/connect invalid_token_12345'
        }),
        chat_id: 'test_chat_001',
        message_type: 'text',
        mentions: [{
          key: '@_user_1',
          id: { open_id: 'bot_open_id' }
        }]
      },
      sender: {
        sender_id: {
          open_id: 'user_open_id'
        }
      }
    },
    header: {
      event_type: 'im.message.receive_v1',
      event_id: `test_event_${Date.now()}_2`
    }
  };
  
  try {
    const response2 = await fetch(callbackUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(invalidTokenMessage)
    });
    
    const result2 = await response2.json();
    console.log(chalk.green('✓ Response received:'), result2);
    console.log(chalk.gray('  Expected: Error message about invalid token\n'));
  } catch (error) {
    console.error(chalk.red('✗ Error:'), error.message);
  }
  
  // Test 3: Connect with valid token (you need to replace with actual token)
  console.log(chalk.yellow('Test 3: /connect with valid token'));
  console.log(chalk.gray('  Note: Replace TEST_TOKEN with an actual token to test\n'));
  
  const TEST_TOKEN = 'YOUR_ACTUAL_TOKEN_HERE'; // Replace with actual token
  
  if (TEST_TOKEN !== 'YOUR_ACTUAL_TOKEN_HERE') {
    const validTokenMessage = {
      event: {
        message: {
          content: JSON.stringify({
            text: `/connect ${TEST_TOKEN}`
          }),
          chat_id: 'test_chat_002',
          message_type: 'text',
          mentions: [{
            key: '@_user_1',
            id: { open_id: 'bot_open_id' }
          }]
        },
        sender: {
          sender_id: {
            open_id: 'user_open_id'
          }
        }
      },
      header: {
        event_type: 'im.message.receive_v1',
        event_id: `test_event_${Date.now()}_3`
      }
    };
    
    try {
      const response3 = await fetch(callbackUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(validTokenMessage)
      });
      
      const result3 = await response3.json();
      console.log(chalk.green('✓ Response received:'), result3);
      console.log(chalk.gray('  Expected: Success message with workspace info\n'));
    } catch (error) {
      console.error(chalk.red('✗ Error:'), error.message);
    }
  } else {
    console.log(chalk.gray('  Skipped: No valid token provided\n'));
  }
  
  console.log(chalk.blue.bold('📊 Test Summary:'));
  console.log(chalk.gray('  - /connect without token: Shows help'));
  console.log(chalk.gray('  - /connect with invalid token: Shows error'));
  console.log(chalk.gray('  - /connect with valid token: Links chat to workspace'));
  
  console.log(chalk.green.bold('\n✅ /connect command flow is ready!'));
  console.log(chalk.cyan('\nWorkflow:'));
  console.log('1. Generate token: ani-code workspace token gen <workspace>');
  console.log('2. In Lark: @Bot /connect <token>');
  console.log('3. Verify: ani-code workspace chat show');
}

// Run the test
testConnectCommand().catch(console.error);
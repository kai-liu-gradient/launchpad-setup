#!/usr/bin/env node
import jwt from 'jsonwebtoken';
import { WorkspaceManager } from './src/workspace-manager.js';
import { promises as fs } from 'fs';

async function testJWTValidation() {
  console.log('Testing JWT Token Validation Fix...\n');
  
  try {
    // Initialize workspace manager
    const manager = new WorkspaceManager();
    await manager.initialize();
    
    // Get the JWT secret from the manager
    const jwtSecret = manager.jwtSecret;
    console.log('✓ JWT secret loaded');
    
    // Test 1: Create a token with HS256 (should work)
    console.log('\n1. Testing valid HS256 token:');
    const validPayload = {
      id: 'test-token-id',
      workspace_id: 'test-workspace',
      workspace_name: 'Test Workspace',
      type: 'test',
      permissions: ['read', 'write']
    };
    
    const validToken = jwt.sign(validPayload, jwtSecret, { algorithm: 'HS256' });
    console.log('Token created with HS256 algorithm');
    
    // Decode to verify algorithm
    const decoded = jwt.decode(validToken, { complete: true });
    console.log('Token header:', decoded.header);
    
    // Test validation (will fail because token is not in DB, but we'll see the algorithm check)
    const result = await manager.validateToken(validToken);
    console.log('Validation result:', result);
    
    // Test 2: Create a token with wrong algorithm (should fail gracefully)
    console.log('\n2. Testing token with unsupported algorithm:');
    try {
      // Create a token with RS256 (wrong algorithm)
      const wrongAlgToken = validToken.split('.');
      const header = JSON.parse(Buffer.from(wrongAlgToken[0], 'base64').toString());
      header.alg = 'RS256';
      wrongAlgToken[0] = Buffer.from(JSON.stringify(header)).toString('base64').replace(/=/g, '');
      const badToken = wrongAlgToken.join('.');
      
      const result2 = await manager.validateToken(badToken);
      console.log('Validation result for bad token:', result2);
    } catch (error) {
      console.log('Expected error:', error.message);
    }
    
    console.log('\n✓ JWT validation test completed successfully');
    
  } catch (error) {
    console.error('Test failed:', error);
  }
  
  process.exit(0);
}

testJWTValidation();
import fetch from 'node-fetch';

const botToken = '8278665603:AAFnpGEt6zZxgYC8ijNz0XCMHMAcFe4e-Oc';
const chatId = '394977994';

async function sendTestNotification() {
  const hostname = 'duke01';
  const time = new Date().toLocaleTimeString('en-GB', { 
    hour12: false, 
    hour: '2-digit',
    minute: '2-digit'
  });
  
  let message = '🚀 *Test: Ani-Code Daemon Started*\n\n';
  message += '*Status:* ✅ Running\n';
  message += '*PID:* 12345\n';
  message += '*Hostname:* ' + hostname + '\n';
  message += '*Time:* ' + time + '\n\n';
  message += '*Services:*\n';
  message += '• IPC Server: 127.0.0.1:39363\n';
  message += '• HTTP Server: 127.0.0.1:6501\n';
  message += '• WebSocket: 0.0.0.0:6502\n\n';
  message += '*Configuration:*\n';
  message += '• Max Concurrent Tasks: 5\n';
  message += '• Telegram Mode: Webhook\n';
  message += '\n━━━━━━━━━━━━━━━\n';
  message += '🖥 ' + hostname + ' • ⏰ ' + time;
  
  const url = 'https://api.telegram.org/bot' + botToken + '/sendMessage';
  const body = {
    chat_id: chatId,
    text: message,
    parse_mode: 'Markdown'
  };
  
  try {
    console.log('Sending message to Telegram...');
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      timeout: 10000
    });
    
    const result = await response.json();
    if (result.ok) {
      console.log('✅ Message sent successfully!');
      console.log('Message ID:', result.result.message_id);
    } else {
      console.log('❌ Failed to send message:', result);
    }
  } catch (error) {
    console.error('Error:', error.message);
  }
}

sendTestNotification();
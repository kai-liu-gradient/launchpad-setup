#!/usr/bin/env node

/**
 * Test GitHub Copilot CLI Provider Support
 *
 * This test validates:
 * 1. CopilotCliHandler implementation
 * 2. Provider manager registration
 * 3. Output extraction for copilot
 * 4. Cost calculation for copilot models
 * 5. Provider switching
 */

import { CopilotCliHandler } from '../../src/providers/copilotCliHandler.js';
import { getProviderManager } from '../../src/providers/providerManager.js';
import {
  extractCopilotConclusion,
  extractCopilotTokens,
  extractCopilotModel,
  extractProviderConclusion,
  extractProviderTokens,
  extractProviderModel
} from '../../src/providers/outputExtractor.js';
import {
  calculateTokenCost,
  getModelPricing,
  getKnownModels,
  hasPricingData
} from '../../src/providers/costCalculator.js';

console.log('='.repeat(60));
console.log('Testing GitHub Copilot Provider Support');
console.log('='.repeat(60));

// Test 1: CopilotCliHandler instantiation
console.log('\n1. CopilotCliHandler Instantiation Test');
console.log('-'.repeat(60));

const copilot = new CopilotCliHandler();
console.log('Handler ID:', copilot.id);
console.log('Handler Name:', copilot.name);
console.log('Handler Binary:', copilot.binary);
console.log('✓ ID is copilot:', copilot.id === 'copilot');
console.log('✓ Name is GitHub Copilot:', copilot.name === 'GitHub Copilot');
console.log('✓ Binary is copilot:', copilot.binary === 'copilot');

// Test 2: CopilotCliHandler defaults
console.log('\n2. CopilotCliHandler Defaults Test');
console.log('-'.repeat(60));

const defaults = CopilotCliHandler.getDefaults();
console.log('Default binary:', defaults.binary);
console.log('Default args:', JSON.stringify(defaults.args));
console.log('Default env:', JSON.stringify(defaults.env));
console.log('✓ Default binary is copilot:', defaults.binary === 'copilot');
console.log('✓ Default args is empty array:', Array.isArray(defaults.args) && defaults.args.length === 0);

// Test 3: CopilotCliHandler capabilities
console.log('\n3. CopilotCliHandler Capabilities Test');
console.log('-'.repeat(60));

const capabilities = copilot.getCapabilities();
console.log('Capabilities:', JSON.stringify(capabilities, null, 2));
console.log('✓ Supports create:', capabilities.supportsCreate === true);
console.log('✓ Supports continue:', capabilities.supportsContinue === true);
console.log('✓ Supports greenlight:', capabilities.supportsGreenlight === true);
console.log('✓ Supports models:', capabilities.supportsModels === true);
console.log('✓ High privilege:', capabilities.highPrivilege === true);

// Test 4: Model flags generation
console.log('\n4. Model Flags Generation Test');
console.log('-'.repeat(60));

const sonnetFlags = copilot.getModelFlags('sonnet');
console.log('Sonnet flags:', sonnetFlags.join(' '));
console.log('✓ Sonnet maps to claude-sonnet-4:', sonnetFlags.includes('claude-sonnet-4'));

const gpt5Flags = copilot.getModelFlags('gpt-5');
console.log('GPT-5 flags:', gpt5Flags.join(' '));
console.log('✓ GPT-5 passed through:', gpt5Flags.includes('gpt-5'));

const noFlags = copilot.getModelFlags(null);
console.log('Null flags:', noFlags.length === 0 ? '(none)' : noFlags.join(' '));
console.log('✓ Null returns empty:', noFlags.length === 0);

// Test 5: Provider Manager Registration
console.log('\n5. Provider Manager Registration Test');
console.log('-'.repeat(60));

const pm = await getProviderManager();
const copilotHandler = pm.getHandler('copilot');
console.log('Copilot handler registered:', copilotHandler !== undefined);
console.log('✓ Copilot handler exists:', copilotHandler !== undefined);

if (copilotHandler) {
  console.log('Registered handler ID:', copilotHandler.id);
  console.log('Registered handler name:', copilotHandler.name);
  console.log('✓ Handler ID matches:', copilotHandler.id === 'copilot');
}

// Test 6: Provider Switching
console.log('\n6. Provider Switching Test');
console.log('-'.repeat(60));

const originalProvider = pm.getCurrentHandler();
console.log('Original provider:', originalProvider.id);

try {
  pm.switchProvider('copilot');
  const currentAfterSwitch = pm.getCurrentHandler();
  console.log('After switch to copilot:', currentAfterSwitch.id);
  console.log('✓ Switched to copilot:', currentAfterSwitch.id === 'copilot');

  // Switch back to original
  pm.switchProvider(originalProvider.id);
  console.log('Switched back to:', pm.getCurrentHandler().id);
  console.log('✓ Switched back:', pm.getCurrentHandler().id === originalProvider.id);
} catch (error) {
  console.log('✗ Switch failed:', error.message);
}

// Test 7: Copilot Output Extraction - Text Format
console.log('\n7. Copilot Output Extraction - Text Format');
console.log('-'.repeat(60));

const copilotTextOutput = `thinking...
processing request...

Copilot: I've analyzed your request. Here's the solution:

The result of 2 + 2 is 4.

This is a simple arithmetic operation.

User: Thanks!

Copilot: You're welcome! Let me know if you need anything else.`;

const textConclusion = extractCopilotConclusion(copilotTextOutput);
console.log('Extracted conclusion:', textConclusion.substring(0, 100) + '...');
console.log('✓ Contains final response:', textConclusion.includes("You're welcome"));

// Test 8: Copilot Output Extraction - JSON Format
console.log('\n8. Copilot Output Extraction - JSON Format');
console.log('-'.repeat(60));

const copilotJsonOutput = `{
  "model": "gpt-5",
  "response": "The answer is 42.",
  "stats": {
    "tokens": {
      "total": 1500
    }
  },
  "usage": {
    "total_tokens": 1500
  }
}`;

const jsonConclusion = extractCopilotConclusion(copilotJsonOutput);
console.log('Extracted from JSON:', jsonConclusion.substring(0, 50) + '...');
// For JSON, it returns the raw output since there's no response markers
console.log('✓ Returns content:', jsonConclusion.length > 0);

// Test 9: Copilot Token Extraction
console.log('\n9. Copilot Token Extraction');
console.log('-'.repeat(60));

// Test with "tokens used" pattern
const tokenOutput1 = 'Task completed. tokens used: 12,345';
const tokens1 = extractCopilotTokens(tokenOutput1);
console.log('Pattern "tokens used: 12,345":', tokens1);
console.log('✓ Extracted 12345:', tokens1 === 12345);

// Test with JSON stats
const tokenOutputJson = '{ "stats": { "tokens": { "total": 9876 } } }';
const tokensJson = extractCopilotTokens(tokenOutputJson);
console.log('JSON stats.tokens.total:', tokensJson);
console.log('✓ Extracted 9876:', tokensJson === 9876);

// Test with JSON usage
const tokenOutputUsage = '{ "usage": { "total_tokens": 5432 } }';
const tokensUsage = extractCopilotTokens(tokenOutputUsage);
console.log('JSON usage.total_tokens:', tokensUsage);
console.log('✓ Extracted 5432:', tokensUsage === 5432);

// Test via generic function
const tokensViaProvider = extractProviderTokens(tokenOutput1, 'copilot');
console.log('Via extractProviderTokens:', tokensViaProvider);
console.log('✓ Generic function works:', tokensViaProvider === 12345);

// Test 10: Copilot Model Extraction
console.log('\n10. Copilot Model Extraction');
console.log('-'.repeat(60));

// Test with "model:" pattern
const modelOutput1 = 'Using the GPT-5 model for this task.\nmodel: gpt-5-turbo';
const model1 = extractCopilotModel(modelOutput1);
console.log('Pattern "model: gpt-5-turbo":', model1);
console.log('✓ Extracted gpt-5-turbo:', model1 === 'gpt-5-turbo');

// Test with JSON model
const modelOutputJson = '{ "model": "claude-sonnet-4" }';
const modelJson = extractCopilotModel(modelOutputJson);
console.log('JSON model:', modelJson);
console.log('✓ Extracted claude-sonnet-4:', modelJson === 'claude-sonnet-4');

// Test via generic function
const modelViaProvider = extractProviderModel(modelOutput1, 'copilot');
console.log('Via extractProviderModel:', modelViaProvider);
console.log('✓ Generic function works:', modelViaProvider === 'gpt-5-turbo');

// Test 11: Cost Calculation for Copilot
console.log('\n11. Cost Calculation for Copilot');
console.log('-'.repeat(60));

console.log('✓ Has copilot pricing:', hasPricingData('copilot'));

const copilotModels = getKnownModels('copilot');
console.log('Known copilot models:', copilotModels.join(', '));

// Test GPT-5 cost
const gpt5Pricing = getModelPricing('copilot', 'gpt-5');
console.log('GPT-5 pricing:', JSON.stringify(gpt5Pricing));

const gpt5Cost = calculateTokenCost({
  providerId: 'copilot',
  modelId: 'gpt-5',
  totalTokens: 10000
});
console.log('GPT-5 cost for 10k tokens: $' + gpt5Cost.totalCost.toFixed(6));
console.log('✓ Cost calculated:', gpt5Cost.totalCost > 0);

// Test Claude Sonnet 4 cost (through Copilot)
const sonnetCost = calculateTokenCost({
  providerId: 'copilot',
  modelId: 'claude-sonnet-4',
  totalTokens: 10000
});
console.log('Claude Sonnet 4 cost for 10k tokens: $' + sonnetCost.totalCost.toFixed(6));
console.log('✓ Sonnet cost calculated:', sonnetCost.totalCost > 0);

// Test default model cost
const defaultCost = calculateTokenCost({
  providerId: 'copilot',
  modelId: 'unknown-model',
  totalTokens: 10000
});
console.log('Default model cost for 10k tokens: $' + defaultCost.totalCost.toFixed(6));
console.log('✓ Default cost calculated:', defaultCost.totalCost > 0);

// Test 12: Integration Test - Full Flow
console.log('\n12. Integration Test - Full Flow');
console.log('-'.repeat(60));

const fullOutput = `Starting Copilot session...
model: gpt-5-turbo
Working directory: /root/workspace/test

Copilot: I'll analyze this codebase and provide recommendations.

After reviewing the code, I've found the following:
1. Good test coverage
2. Clean architecture
3. Some optimization opportunities

Total tokens used: 25,000`;

const extractedConclusion = extractProviderConclusion(fullOutput, 'copilot');
const extractedTokens = extractProviderTokens(fullOutput, 'copilot');
const extractedModel = extractProviderModel(fullOutput, 'copilot');

console.log('Extracted conclusion length:', extractedConclusion.length);
console.log('Extracted tokens:', extractedTokens);
console.log('Extracted model:', extractedModel);

const estimatedCost = calculateTokenCost({
  providerId: 'copilot',
  modelId: extractedModel,
  totalTokens: extractedTokens
});

console.log('Estimated cost: $' + estimatedCost.totalCost.toFixed(4));
console.log('✓ Full flow integration:', extractedTokens > 0 && extractedModel && estimatedCost.totalCost > 0);

// Test 13: Edge Cases
console.log('\n13. Edge Cases');
console.log('-'.repeat(60));

console.log('Null conclusion:', extractCopilotConclusion(null) === null);
console.log('Empty conclusion:', extractCopilotConclusion(''));
console.log('Null tokens:', extractCopilotTokens(null));
console.log('Empty tokens:', extractCopilotTokens(''));
console.log('Null model:', extractCopilotModel(null));
console.log('Empty model:', extractCopilotModel(''));
console.log('✓ Edge cases handled gracefully');

// Test 14: Provider List includes Copilot
console.log('\n14. Provider List Test');
console.log('-'.repeat(60));

const providers = pm.listProviders();
const copilotInList = providers.some(p => p.id === 'copilot');
console.log('Providers in list:', providers.map(p => p.id).join(', '));
// Note: copilot may not appear if binary is not installed
console.log('Copilot in list (if binary available):', copilotInList);

console.log('\n' + '='.repeat(60));
console.log('All Copilot Provider Tests Complete');
console.log('='.repeat(60));

#!/usr/bin/env node

// Test script to verify /rank command works

import { UsageReporter } from './src/usage-reporter.js';

async function testRankCommand() {
  console.log('Testing /rank command functionality...\n');
  
  const usageReporter = new UsageReporter();
  
  try {
    // Generate daily report
    const report = await usageReporter.generateDailyReport();
    
    if (report) {
      console.log('✅ Successfully generated usage report!');
      console.log('-'.repeat(50));
      console.log(`Title: ${report.title}`);
      console.log(`Content:\n${report.content}`);
      console.log('-'.repeat(50));
      console.log(`Color: ${report.color}`);
      console.log(`Date: ${report.date}`);
      console.log(`Total Cost: $${report.totals.totalCost.toFixed(4)}`);
      console.log(`Total Tokens: ${report.totals.totalTokens.toLocaleString()}`);
    } else {
      console.log('❌ Failed to generate report (returned null)');
    }
  } catch (error) {
    console.error('❌ Error generating report:', error);
  }
}

testRankCommand();
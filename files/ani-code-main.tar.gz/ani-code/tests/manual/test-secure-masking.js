#!/usr/bin/env node

import { SecureUploader } from './src/utils/secure-upload.js';

// Test cases for credential masking
const testCases = [
  {
    name: 'Telegram Bot Token',
    input: 'Bot token: 1234567890:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghi',
    expected: 'Bot token: 123***MASKED***hi'
  },
  {
    name: 'AWS Access Key',
    input: 'Access key: AKIAIOSFODNN7EXAMPLE',
    expected: 'Access key: AKI***MASKED***LE'
  },
  {
    name: 'S3 Endpoint',
    input: 'S3 endpoint: s3://mykey:mysecret@example.com',
    expected: 'S3 endpoint: s3:***MASKED***om'
  },
  {
    name: 'Environment Variable',
    input: 'TELEGRAM_BOT_TOKEN=1234567890:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghi',
    expected: 'TEL***MASKED***hi'
  },
  {
    name: 'Bearer Token',
    input: 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9',
    expected: 'Authorization: Bea***MASKED***J9'
  },
  {
    name: 'API Key in message',
    input: 'Your api_key=sk-proj-12345678901234567890 is ready',
    expected: 'Your api***MASKED***90 is ready'
  },
  {
    name: 'Multiple credentials',
    input: `Here are your credentials:
Bot token: 1234567890:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghi
AWS Key: AKIAIOSFODNN7EXAMPLE
Secret: s3://key:secret@endpoint.com`,
    expected: `Here are your credentials:
Bot token: 123***MASKED***hi
AWS Key: AKI***MASKED***LE
Secret: s3:***MASKED***om`
  },
  {
    name: 'Normal message without credentials',
    input: 'This is a normal message without any sensitive data',
    expected: 'This is a normal message without any sensitive data'
  }
];

console.log('Testing Secure Credential Masking\n');
console.log('=' .repeat(50));

let passed = 0;
let failed = 0;

testCases.forEach((testCase, index) => {
  console.log(`\nTest ${index + 1}: ${testCase.name}`);
  console.log('-'.repeat(40));
  
  const result = SecureUploader.maskCredentials(testCase.input);
  
  console.log('Input:   ', testCase.input.substring(0, 50) + (testCase.input.length > 50 ? '...' : ''));
  console.log('Output:  ', result.substring(0, 50) + (result.length > 50 ? '...' : ''));
  
  // Check if credentials were masked (contains MASKED keyword)
  const hasMasked = result.includes('***MASKED***');
  const expectedMasked = testCase.expected.includes('***MASKED***');
  
  if (hasMasked === expectedMasked) {
    console.log('✅ PASSED');
    passed++;
  } else {
    console.log('❌ FAILED');
    console.log('Expected:', testCase.expected.substring(0, 50) + (testCase.expected.length > 50 ? '...' : ''));
    failed++;
  }
});

console.log('\n' + '='.repeat(50));
console.log(`\nResults: ${passed} passed, ${failed} failed`);

if (failed === 0) {
  console.log('✅ All tests passed!');
  process.exit(0);
} else {
  console.log('❌ Some tests failed');
  process.exit(1);
}
#!/usr/bin/env node

import { isValidModel, normalizeModel, createInvalidModelError, getModelFlags } from './src/model-utils.js';

console.log('🧪 Testing Model Preference Utilities');
console.log('=====================================');

// Test valid model validation
console.log('\n✅ Testing valid models:');
console.log(`isValidModel('sonnet'):`, isValidModel('sonnet'));
console.log(`isValidModel('opus'):`, isValidModel('opus'));
console.log(`isValidModel('SONNET'):`, isValidModel('SONNET'));

// Test invalid model validation
console.log('\n❌ Testing invalid models:');
console.log(`isValidModel('gpt4'):`, isValidModel('gpt4'));
console.log(`isValidModel(''):`, isValidModel(''));
console.log(`isValidModel(null):`, isValidModel(null));

// Test model normalization
console.log('\n🔧 Testing model normalization:');
console.log(`normalizeModel('SONNET'):`, normalizeModel('SONNET'));
console.log(`normalizeModel('Opus'):`, normalizeModel('Opus'));
console.log(`normalizeModel('invalid'):`, normalizeModel('invalid'));

// Test model flags
console.log('\n🏗️ Testing model flags:');
console.log(`getModelFlags('sonnet'):`, getModelFlags('sonnet'));
console.log(`getModelFlags('opus'):`, getModelFlags('opus'));
console.log(`getModelFlags('invalid'):`, getModelFlags('invalid'));

// Test error creation
console.log('\n⚠️  Testing error creation:');
try {
  throw createInvalidModelError('invalid-model');
} catch (error) {
  console.log(`Error message:`, error.message);
}

console.log('\n✅ All model utility tests completed!');
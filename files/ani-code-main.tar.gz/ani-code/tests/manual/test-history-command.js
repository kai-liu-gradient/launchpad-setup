#!/usr/bin/env node

/**
 * Test the /history command locally
 */

import { ClaudeHistoryViewer } from '../../src/claude-history-viewer.js';
import fs from 'fs/promises';
import path from 'path';

async function test() {
  console.log('Testing Claude History Viewer...\n');

  try {
    const viewer = new ClaudeHistoryViewer();

    // Test finding latest session
    console.log('1. Finding latest session...');
    const projectPath = '/root/workspace/ani-code';
    const sessionFile = await viewer.findLatestSession(projectPath);

    if (!sessionFile) {
      console.error('❌ No session file found!');
      return;
    }

    console.log(`✅ Found session: ${sessionFile}\n`);

    // Test parsing session
    console.log('2. Parsing session...');
    const messages = await viewer.parseSession(sessionFile);
    console.log(`✅ Parsed ${messages.length} messages\n`);

    // Show first few messages
    console.log('3. First 3 messages:');
    messages.slice(0, 3).forEach((msg, i) => {
      console.log(`\n[${i + 1}] ${msg.type} at ${new Date(msg.timestamp).toLocaleTimeString()}`);
      if (msg.type === 'user') {
        console.log(`   Content: ${msg.content.substring(0, 100)}...`);
      } else if (msg.type === 'assistant') {
        console.log(`   Text length: ${msg.textContent.length}`);
        console.log(`   Tool uses: ${msg.toolUses.length}`);
        if (msg.usage) {
          console.log(`   Tokens: ${msg.usage.input_tokens} in, ${msg.usage.output_tokens} out`);
        }
      }
    });

    // Test HTML generation
    console.log('\n\n4. Generating HTML...');
    const html = await viewer.generateLatestSessionHTML(projectPath);
    console.log(`✅ Generated HTML (${html.length} bytes)\n`);

    // Save to temp file
    const outputFile = '/tmp/test-claude-history.html';
    await fs.writeFile(outputFile, html, 'utf-8');
    console.log(`✅ Saved to: ${outputFile}`);
    console.log('\nYou can open this file in your browser to view the result.');

  } catch (error) {
    console.error('❌ Error:', error.message);
    console.error(error.stack);
  }
}

test();

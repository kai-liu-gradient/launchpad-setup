#!/usr/bin/env node

// Test script to verify auto-progress functionality
import { WorkspaceManager } from './src/workspace-manager.js';
import { logger } from './src/logger.js';

async function testAutoProgress() {
  logger.info('Testing auto-progress configuration...');
  
  const manager = new WorkspaceManager();
  await manager.initialize();
  
  try {
    // Get current workspace
    const workspace = await manager.getCurrentWorkspace();
    
    if (!workspace) {
      logger.error('No workspace found in current directory');
      return;
    }
    
    logger.info(`Current workspace: ${workspace.name}`);
    logger.info(`Workspace path: ${workspace.path}`);
    
    // Check showprogress setting
    if (workspace.settings && workspace.settings.showprogress) {
      logger.success(`✓ showprogress is set to: ${workspace.settings.showprogress}`);
      
      if (workspace.settings.showprogress === 'auto') {
        logger.info('Auto-progress is ENABLED for this workspace');
        logger.info('When a task starts in Telegram:');
        logger.info('  1. The task will start normally');
        logger.info('  2. After 4 seconds, progress tracking will automatically begin');
        logger.info('  3. Progress updates will be sent every 10 seconds');
        logger.info('  4. The original "task started" message will be updated with progress');
      }
    } else {
      logger.info('showprogress is not configured for this workspace');
      logger.info('To enable: ani-code workspace meta set showprogress auto');
    }
    
    // Show all workspace settings
    if (workspace.settings && Object.keys(workspace.settings).length > 0) {
      logger.info('\nAll workspace settings:');
      for (const [key, value] of Object.entries(workspace.settings)) {
        logger.info(`  ${key}: ${value}`);
      }
    }
    
  } finally {
    await manager.close();
  }
}

testAutoProgress().catch(error => {
  logger.error('Test failed:', error);
  process.exit(1);
});
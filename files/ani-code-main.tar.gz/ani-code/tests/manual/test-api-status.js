#!/usr/bin/env node

// Test script to verify task status is correctly returned
import { APIHandlers } from './src/api-handlers.js';
import { TaskMonitor } from './src/task-monitor.js';

async function testTaskCreation() {
  console.log('Testing task creation with status...');

  // Create mock instances
  const taskMonitor = new TaskMonitor();
  const apiHandlers = new APIHandlers(taskMonitor, null);

  // Create a test task
  const task = taskMonitor.addTask(
    'Test Task',
    'echo "test"',
    {
      priority: 'normal',
      source: 'test',
      workspace: 'test-workspace',
      cwd: '/tmp',
      metadata: {
        test: true
      }
    }
  );

  console.log('Created task:', {
    id: task.id,
    name: task.name,
    status: task.status,
    statusType: typeof task.status
  });

  // Verify status is not undefined
  if (task.status === undefined || task.status === 'undefined') {
    console.error('❌ FAILED: Task status is undefined!');
    process.exit(1);
  } else if (task.status === 'pending') {
    console.log('✅ SUCCESS: Task status is correctly set to "pending"');
  } else {
    console.log(`⚠️ WARNING: Task status is "${task.status}" instead of "pending"`);
  }

  // Cancel the test task
  await taskMonitor.cancelTask(task.id);

  process.exit(0);
}

testTaskCreation().catch(err => {
  console.error('Test failed:', err);
  process.exit(1);
});
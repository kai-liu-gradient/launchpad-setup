#!/usr/bin/env node

import { LarkNotifier } from './src/lark-notifier.js';
import { config } from './src/config.js';

// Test sending a message to a specific chat ID
async function testChatIdRouting() {
  const notifier = new LarkNotifier();
  
  // Test chat ID (you'll need to replace this with a real chat ID for testing)
  const testChatId = 'oc_test_chat_id_123';
  
  console.log('Testing chat-specific message routing...');
  console.log('Chat ID:', testChatId);
  
  try {
    // Test sending a custom message to specific chat
    await notifier.sendCustomMessage(
      '🧪 Test Message',
      'This is a test message sent to a specific chat ID.\n\nIf you see this message, the chat ID routing is working correctly!',
      'blue',
      testChatId
    );
    
    console.log('✅ Message sent successfully to chat:', testChatId);
    
    // Test task update with chat ID
    const mockTask = {
      id: 'test-task-123',
      name: 'Test Task',
      command: 'echo "test"',
      cwd: process.cwd(),
      chatId: testChatId,
      pid: 12345
    };
    
    await notifier.sendTaskUpdate(mockTask, 'started');
    console.log('✅ Task update sent successfully to chat:', testChatId);
    
    // Test task summary with chat ID
    mockTask.startedAt = Date.now() - 5000;
    mockTask.completedAt = Date.now();
    mockTask.output = 'Test output from the task';
    mockTask.exitCode = 0;
    
    await notifier.sendTaskSummary(mockTask, 'success');
    console.log('✅ Task summary sent successfully to chat:', testChatId);
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    process.exit(1);
  }
}

// Run the test
testChatIdRouting().then(() => {
  console.log('\n✅ All tests passed!');
  process.exit(0);
}).catch(error => {
  console.error('\n❌ Test failed:', error);
  process.exit(1);
});
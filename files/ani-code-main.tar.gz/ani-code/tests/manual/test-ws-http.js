#!/usr/bin/env node

import http from 'http';

// Test if the health endpoint is accessible
const options = {
  hostname: 'localhost',
  port: 6502,
  path: '/health',
  method: 'GET'
};

console.log('Testing WebSocket service health endpoint...\n');

const req = http.request(options, (res) => {
  console.log(`Status: ${res.statusCode}`);
  console.log(`Headers:`, res.headers);
  
  let data = '';
  
  res.on('data', (chunk) => {
    data += chunk;
  });
  
  res.on('end', () => {
    if (res.statusCode === 200) {
      console.log('\n✓ WebSocket service is healthy!');
      console.log('Response:', data);
      
      try {
        const parsed = JSON.parse(data);
        console.log('\nService details:');
        console.log('- Status:', parsed.status);
        console.log('- Active connections:', parsed.connections);
        console.log('- Timestamp:', parsed.timestamp);
      } catch (e) {
        console.log('Could not parse response as JSON');
      }
    } else {
      console.log('\n✗ Unexpected status code');
      console.log('Response:', data);
    }
  });
});

req.on('error', (error) => {
  console.error('✗ Error connecting to WebSocket service:', error.message);
  console.log('\nMake sure the ani-code daemon is running:');
  console.log('  ani-code daemon --status');
});

req.end();
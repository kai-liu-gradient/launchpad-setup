#!/usr/bin/env node

import { TaskQueue } from './src/task-queue.js';

// Create a new task queue instance
const taskQueue = new TaskQueue();

// Create a test task
const testTask = taskQueue.addTask(
  'Test ID Format',
  'echo "Testing new ID format"',
  { cwd: process.cwd() }
);

// Display the generated task ID
console.log('Generated Task ID:', testTask.id);
console.log('Task Name:', testTask.name);
console.log('Task Status:', testTask.status);
console.log('Created At:', testTask.createdAt);

// Verify ID format matches expected pattern: ac-YYYYMMDD-HHMMSS-randomstring
const idPattern = /^ac-\d{8}-\d{6}-[a-f0-9]{8}$/;
const isValidFormat = idPattern.test(testTask.id);

console.log('\nID Format Validation:');
console.log('Expected Pattern: ac-YYYYMMDD-HHMMSS-randomstring');
console.log('ID Valid:', isValidFormat ? '✅ Yes' : '❌ No');

// Parse the ID components
const idParts = testTask.id.split('-');
if (idParts.length === 4) {
  console.log('\nID Components:');
  console.log('Prefix:', idParts[0]);
  console.log('Date:', idParts[1]);
  console.log('Time:', idParts[2]);
  console.log('Random:', idParts[3]);
}

// Exit after verification
process.exit(isValidFormat ? 0 : 1);
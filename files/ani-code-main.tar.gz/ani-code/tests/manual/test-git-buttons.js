#!/usr/bin/env node

// Test script to verify git button logic
import { execSync } from 'child_process';

// Simulate git status parsing
function parseGitStatus() {
  const gitStatus = execSync('git status --porcelain').toString();
  
  const lines = gitStatus.trim().split('\n');
  const staged = [];
  const modified = [];
  const untracked = [];
  
  lines.forEach(line => {
    const statusCode = line.substring(0, 2);
    let file = line.substring(3);
    
    // Handle renamed files (R  old -> new)
    if (statusCode[0] === 'R' && file.includes(' -> ')) {
      file = file.split(' -> ')[1];
    }
    
    if (statusCode[0] === 'A' || statusCode[0] === 'M' || statusCode[0] === 'D' || statusCode[0] === 'R') {
      staged.push(file);
    } else if (statusCode[1] === 'M' || statusCode[1] === 'D') {
      modified.push(file);
    } else if (statusCode === '??') {
      untracked.push(file);
    }
  });
  
  return { staged, modified, untracked };
}

// Test button logic
function getGitButtons(staged, modified, untracked) {
  const buttons = [];
  
  // Original logic (commented out)
  /*
  if (modified.length > 0 && staged.length === 0) {
    buttons.push('📦 Stage All');
  } else if (staged.length > 0) {
    buttons.push('💾 AI Commit');
    buttons.push('📤 Push');
  }
  */
  
  // New logic
  if (modified.length > 0 && staged.length === 0) {
    buttons.push('📦 Stage All');
  } else if (staged.length > 0 || untracked.length > 0) {
    const totalToCommit = staged.length + modified.length + untracked.length;
    buttons.push(`💾 AI Commit (${totalToCommit})`);
    buttons.push('📤 Push');
  }
  
  return buttons;
}

// Run test
console.log('🧪 Testing Git Button Logic\n');
console.log('Current git status:');

const { staged, modified, untracked } = parseGitStatus();
console.log(`  Staged: ${staged.length} files`, staged.length > 0 ? `(${staged.join(', ')})` : '');
console.log(`  Modified: ${modified.length} files`, modified.length > 0 ? `(${modified.join(', ')})` : '');
console.log(`  Untracked: ${untracked.length} files`, untracked.length > 0 ? `(${untracked.join(', ')})` : '');

console.log('\nButtons that will be shown:');
const buttons = getGitButtons(staged, modified, untracked);
buttons.forEach(button => console.log(`  - ${button}`));

// Test specific scenarios
console.log('\n📋 Testing different scenarios:');

console.log('\n1. Only untracked files:');
let testButtons = getGitButtons([], [], ['file1.txt', 'file2.txt']);
console.log('   Buttons:', testButtons.length > 0 ? testButtons.join(', ') : 'None');
console.log('   ✅ Should show: AI Commit button');

console.log('\n2. Only modified files (unstaged):');
testButtons = getGitButtons([], ['file1.js'], []);
console.log('   Buttons:', testButtons.length > 0 ? testButtons.join(', ') : 'None');
console.log('   ✅ Should show: Stage All button');

console.log('\n3. Staged + untracked files:');
testButtons = getGitButtons(['file1.js'], [], ['file2.txt']);
console.log('   Buttons:', testButtons.length > 0 ? testButtons.join(', ') : 'None');
console.log('   ✅ Should show: AI Commit and Push buttons');

console.log('\n4. Modified + untracked files (no staged):');
testButtons = getGitButtons([], ['file1.js'], ['file2.txt']);
console.log('   Buttons:', testButtons.length > 0 ? testButtons.join(', ') : 'None');
console.log('   ✅ Should show: Stage All button (need to stage modified first)');

console.log('\n✨ Test complete!');
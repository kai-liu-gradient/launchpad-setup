#!/usr/bin/env node

import { SecureUploader } from './src/utils/secure-upload.js';
import fetch from 'node-fetch';
import fs from 'fs/promises';

async function testFallbackUpload() {
  try {
    console.log('Testing S3 upload with fallback mechanism...\n');
    
    const uploader = new SecureUploader();
    await uploader.initialize();
    
    // Create a test file
    const testFile = '/tmp/test-upload.txt';
    await fs.writeFile(testFile, 'Test content with problematic metadata');
    
    // Test case with problematic metadata
    console.log('Testing upload with newlines in metadata...');
    const result = await uploader.uploadFile(testFile, {
      workdir: 'test-fallback',
      metadata: {
        'caption': 'Line 1\nLine 2\nLine 3',
        'test': 'fallback-test'
      }
    });
    
    console.log('✅ Upload completed!');
    console.log('URL:', result.url);
    console.log('Key:', result.s3Key);
    console.log('\nThe fallback mechanism should have kicked in if metadata had issues.');
    
    // Clean up
    await fs.unlink(testFile);
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    process.exit(1);
  }
}

testFallbackUpload();
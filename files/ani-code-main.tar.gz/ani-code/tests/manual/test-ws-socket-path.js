#!/usr/bin/env node

import WebSocket from 'ws';
import { readFileSync } from 'fs';
import { resolve } from 'path';
import { homedir } from 'os';

// Read token from config
const configPath = resolve(homedir(), '.anicode', 'config.json');
let token;

try {
  const config = JSON.parse(readFileSync(configPath, 'utf8'));
  token = config.authToken;
  console.log('✓ Token loaded from config');
} catch (error) {
  console.error('✗ Failed to load token from config:', error.message);
  process.exit(1);
}

// Test WebSocket connection with /socket path
const wsUrl = `ws://localhost:6502/socket?token=${token}`;
console.log(`\n🔌 Connecting to: ${wsUrl.replace(token, '***')}\n`);

const ws = new WebSocket(wsUrl);

ws.on('open', () => {
  console.log('✓ Connected successfully to WebSocket server on /socket path!');
  
  // Send test message
  ws.send(JSON.stringify({
    type: 'PING',
    timestamp: Date.now()
  }));
  
  console.log('→ Sent PING message');
  
  // Close connection after 2 seconds
  setTimeout(() => {
    console.log('\n✓ Test completed successfully!');
    ws.close();
    process.exit(0);
  }, 2000);
});

ws.on('message', (data) => {
  const message = JSON.parse(data.toString());
  console.log('← Received message:', message.type);
});

ws.on('error', (error) => {
  console.error('✗ WebSocket error:', error.message);
  process.exit(1);
});

ws.on('close', (code, reason) => {
  console.log(`\n🔌 Connection closed: code=${code}, reason=${reason || 'none'}`);
});

// Timeout after 5 seconds
setTimeout(() => {
  console.error('\n✗ Connection timeout after 5 seconds');
  process.exit(1);
}, 5000);
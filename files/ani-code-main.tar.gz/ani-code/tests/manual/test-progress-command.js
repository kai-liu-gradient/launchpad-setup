#!/usr/bin/env node

import { config } from './src/config.js';
import { logger } from './src/logger.js';
import { HTTPServer } from './src/http-server.js';
import { TaskMonitor } from './src/task-monitor.js';
import { ChatSettingsManager } from './src/chat-settings.js';

// Test the /progress command implementation
async function testProgressCommand() {
  logger.info('Testing /progress command implementation...');
  
  // Initialize components
  const chatSettings = new ChatSettingsManager();
  await chatSettings.initialize();
  
  const taskMonitor = new TaskMonitor(chatSettings);
  const httpServer = new HTTPServer(taskMonitor, chatSettings);
  
  // Mock a task for testing
  const testTask = {
    id: 'test-task-123',
    name: 'Test Task',
    command: 'sleep 60',
    status: 'running',
    createdAt: new Date(),
    startedAt: new Date(),
    cwd: process.cwd(),
    chatId: 'telegram:test'
  };
  
  // Add the test task to the running tasks
  taskMonitor.taskQueue.runningTasks.set(testTask.id, testTask);
  
  // Test chat ID (replace with actual chat ID for real testing)
  const testChatId = process.env.TELEGRAM_TEST_CHAT_ID || '123456789';
  
  logger.info('Configuration:');
  logger.info(`- Progress update interval: ${config.telegram.progressUpdateInterval} seconds`);
  logger.info(`- Progress max duration: ${config.telegram.progressMaxDuration} minutes`);
  logger.info(`- Test chat ID: ${testChatId}`);
  logger.info(`- Test task ID: ${testTask.id}`);
  
  try {
    // Test the progress command handler
    logger.info('Calling handleProgressCommand...');
    await httpServer.handleProgressCommand(testChatId, testTask.id);
    
    logger.success('Progress tracking started successfully!');
    logger.info(`Progress will update every ${config.telegram.progressUpdateInterval} seconds`);
    logger.info(`Maximum tracking duration: ${config.telegram.progressMaxDuration} minutes`);
    
    // Check if tracker was created
    const trackerKey = `${testChatId}:${testTask.id}`;
    if (httpServer.progressTrackers.has(trackerKey)) {
      const tracker = httpServer.progressTrackers.get(trackerKey);
      logger.success(`Tracker created successfully:`, {
        chatId: tracker.chatId,
        taskId: tracker.taskId,
        messageId: tracker.messageId,
        startTime: new Date(tracker.startTime).toISOString()
      });
    } else {
      logger.error('Tracker was not created!');
    }
    
    // Wait a bit to see if updates work
    logger.info('Waiting 5 seconds to check for updates...');
    await new Promise(resolve => setTimeout(resolve, 5000));
    
    // Update task status to test completion handling
    logger.info('Marking task as completed...');
    testTask.status = 'completed';
    testTask.completedAt = new Date();
    
    // Wait for the next update cycle
    logger.info(`Waiting ${config.telegram.progressUpdateInterval} seconds for completion update...`);
    await new Promise(resolve => setTimeout(resolve, config.telegram.progressUpdateInterval * 1000 + 1000));
    
    // Check if tracker was cleaned up
    if (!httpServer.progressTrackers.has(trackerKey)) {
      logger.success('Tracker cleaned up successfully after task completion!');
    } else {
      logger.warn('Tracker still exists after task completion');
    }
    
  } catch (error) {
    logger.error('Test failed:', error);
  } finally {
    // Cleanup
    httpServer.stop();
    logger.info('Test completed');
  }
}

// Run the test
testProgressCommand().catch(console.error);
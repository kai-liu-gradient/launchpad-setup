#!/usr/bin/env node

import fetch from 'node-fetch';

async function testStatusMessage() {
  console.log('🧪 Testing Status Message Format\n');
  console.log('==================================\n');
  
  const callbackUrl = 'http://localhost:3000/callback/lark';
  
  // Create a test message to trigger /status command
  const statusMessage = {
    type: 'event',
    event: {
      message: {
        message_id: 'test_status_' + Date.now(),
        message_type: 'text',
        content: '{"text":"@ani-code /status"}',
        mentions: [
          {
            key: '@_user_1',
            id: {
              open_id: 'ani-code_bot'
            },
            name: 'ani-code'
          }
        ],
        chat_id: 'oc_test_chat_123',
        chat_type: 'group'
      },
      sender: {
        sender_id: {
          open_id: 'test_user_123'
        },
        sender_type: 'user'
      }
    }
  };
  
  console.log('📤 Sending /status command...\n');
  
  try {
    const response = await fetch(callbackUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(statusMessage)
    });
    
    const result = await response.json();
    console.log('Response:', result);
    
    if (result.success) {
      console.log('✅ Status command processed successfully\n');
      console.log('Check your Lark chat for the formatted status message.');
    } else {
      console.log('❌ Status command failed:', result.message);
    }
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    console.log('\nMake sure the daemon is running: ani-code daemon --status');
  }
}

testStatusMessage();
#!/usr/bin/env node

import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import crypto from 'crypto';

async function testS3Upload() {
  try {
    console.log('Testing basic S3 upload...');
    
    // Get S3 credentials from environment
    const s3Endpoint = process.env.S3_ENDPOINT;
    const bucketName = process.env.S3_CACHE_BUCKET;
    
    if (!s3Endpoint || !bucketName) {
      throw new Error('S3_ENDPOINT and S3_CACHE_BUCKET environment variables must be set');
    }
    
    console.log('Bucket:', bucketName);
    console.log('Endpoint format:', s3Endpoint.replace(/:[^@]+@/, ':***@'));
    
    // Parse S3 endpoint
    const endpointMatch = s3Endpoint.match(/^s3:\/\/([^:]+):([^@]+)@(.+)$/);
    if (!endpointMatch) {
      throw new Error('Invalid S3_ENDPOINT format');
    }
    
    const [, accessKeyId, secretAccessKey, endpoint] = endpointMatch;
    console.log('Endpoint URL:', `https://${endpoint}`);
    console.log('Access Key ID:', accessKeyId.substring(0, 4) + '***');
    
    // Initialize S3 client
    const s3Client = new S3Client({
      endpoint: `https://${endpoint}`,
      region: 'auto',
      credentials: {
        accessKeyId,
        secretAccessKey
      },
      forcePathStyle: process.env.S3_FORCE_PATH_STYLE === 'true'
    });
    
    // Create test data
    const testData = Buffer.from('Hello, S3! This is a test upload at ' + new Date().toISOString());
    const md5Hash = crypto.createHash('md5').update(testData).digest('hex');
    
    // Generate S3 key
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    const s3Key = `test/${dateStr}/test-${md5Hash}.txt`;
    
    console.log('\nUploading to S3...');
    console.log('Key:', s3Key);
    console.log('Size:', testData.length, 'bytes');
    
    // Simple metadata without any special characters
    const metadata = {
      'test': 'true',
      'timestamp': Date.now().toString()
    };
    
    console.log('Metadata:', metadata);
    
    // Upload to S3
    const command = new PutObjectCommand({
      Bucket: bucketName,
      Key: s3Key,
      Body: testData,
      ContentType: 'text/plain',
      Metadata: metadata
    });
    
    console.log('\nSending command to S3...');
    const response = await s3Client.send(command);
    
    console.log('\n✅ Upload successful!');
    console.log('Response:', {
      ETag: response.ETag,
      VersionId: response.VersionId
    });
    
    const downloadUrl = `https://${bucketName}.${endpoint}/${s3Key}`;
    console.log('\nDownload URL:', downloadUrl);
    
  } catch (error) {
    console.error('\n❌ Test failed:', error.message);
    if (error.name === 'SignatureDoesNotMatch') {
      console.error('\nSignature error details:');
      console.error('- Check that S3_ENDPOINT credentials are correct');
      console.error('- Verify the endpoint URL format');
      console.error('- Ensure system time is synchronized');
    }
    console.error('\nFull error:', error);
    process.exit(1);
  }
}

testS3Upload();
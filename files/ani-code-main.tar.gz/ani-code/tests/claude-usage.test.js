import { jest } from '@jest/globals';
import { formatUsageMarkdown, formatUsageText } from '../src/claude-usage.js';

describe('Claude Usage Commands', () => {
  // Note: getClaudeUsage() tests are skipped because they require mocking spawn
  // which is complex. Manual testing with real expect script validates functionality.

  describe('formatUsageMarkdown', () => {
    it('should return a string when awaited', async () => {
      const mockUsage = {
        currentSession: 5,
        weekAllModels: 12,
        weekOpus: 25,
        currentPlan: 'Sonnet 4.5 · Claude Max',
        sessionResetTime: 'Oct 18, 9:59am (UTC)',
        weekAllModelsResetTime: 'Oct 21, 12am (UTC)',
        weekOpusResetTime: 'Oct 21, 12am (UTC)',
        sessionResetInfo: null,
        weekAllModelsResetInfo: null,
        weekOpusResetInfo: {
          daysUntilReset: 2,
          hoursUntilReset: 48,
          percentTimeElapsed: 71,
          usageVelocity: 0.8,
          projectedUsage: 95
        }
      };

      const result = await formatUsageMarkdown(mockUsage);

      expect(typeof result).toBe('string');
      expect(result.length).toBeGreaterThan(0);
      expect(result).toContain('```');
      expect(result).toContain('Claude Max');
    });

    it('should include usage percentages in compact format', async () => {
      const mockUsage = {
        currentSession: 80,
        weekAllModels: 50,
        weekOpus: 90,
        currentPlan: 'Claude Max'
      };

      const result = await formatUsageMarkdown(mockUsage);

      // Updated to match actual format: Session:, Week (All):, Opus:
      expect(result).toContain('Session:');
      expect(result).toContain('Week (All):');
      expect(result).toContain('Opus:');
    });

    it('should show warning indicators for high usage', async () => {
      const mockUsage = {
        currentSession: 85,
        weekAllModels: 65,
        weekOpus: 95,
        currentPlan: 'Claude Max'
      };

      const result = await formatUsageMarkdown(mockUsage);

      // High usage should have warning indicators
      expect(result).toContain('!!');
    });
  });

  describe('formatUsageText', () => {
    it('should return a formatted text string when awaited', async () => {
      const mockUsage = {
        currentSession: 5,
        weekAllModels: 12,
        weekOpus: 25,
        currentPlan: 'Sonnet 4.5 · Claude Max',
        sessionResetInfo: {
          hoursUntilReset: 4,
          minutesUntilReset: 30
        },
        weekAllModelsResetInfo: {
          daysUntilReset: 2,
          hoursUntilReset: 48
        },
        weekOpusResetInfo: {
          daysUntilReset: 2,
          hoursUntilReset: 48,
          percentTimeElapsed: 71,
          usageVelocity: 0.8,
          projectedUsage: 95
        }
      };

      const result = await formatUsageText(mockUsage);

      expect(typeof result).toBe('string');
      expect(result.length).toBeGreaterThan(0);
      expect(result).toContain('CLAUDE API USAGE');
      expect(result).toContain('Session:');
      expect(result).toContain('Week (All):');
      expect(result).toContain('Week (Opus):');
    });

    it('should include progress bars', async () => {
      const mockUsage = {
        currentSession: 50,
        weekAllModels: 75,
        weekOpus: 90
      };

      const result = await formatUsageText(mockUsage);

      // Progress bars use these characters
      expect(result).toMatch(/[▓░█]/);
    });
  });

  describe('HTTP Handler Integration', () => {
    it('should properly await formatUsageMarkdown in handler context', async () => {
      // This test simulates what happens in http-server.js
      const mockUsage = {
        currentSession: 10,
        weekAllModels: 20,
        weekOpus: 30,
        currentPlan: 'Claude Max'
      };

      // Simulate the exact handler code
      const { formatUsageMarkdown: formatMD } = await import('../src/claude-usage.js');
      const message = await formatMD(mockUsage);

      // Verify it's a string, not a Promise
      expect(typeof message).toBe('string');
      expect(message).not.toBe('[object Promise]');
      expect(message.length).toBeGreaterThan(0);
    });
  });
});

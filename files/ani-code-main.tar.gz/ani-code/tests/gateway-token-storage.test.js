import { jest } from '@jest/globals';
import { config } from '../src/config.js';

describe('Gateway Token Storage', () => {
  let originalEnv;

  beforeEach(() => {
    // Save original environment
    originalEnv = {
      GATEWAY_TOKEN: process.env.GATEWAY_TOKEN,
      GATEWAY_API_KEY: process.env.GATEWAY_API_KEY
    };
  });

  afterEach(() => {
    // Restore original environment
    Object.entries(originalEnv).forEach(([key, value]) => {
      if (value === undefined) {
        delete process.env[key];
      } else {
        process.env[key] = value;
      }
    });
  });

  test('should make stored token available through config getter', () => {
    const mockGatewayToken = 'gw_config_test_token';

    // Set token directly in environment
    process.env.GATEWAY_TOKEN = mockGatewayToken;

    // Verify config getter returns the token
    expect(config.gateway.token).toBe(mockGatewayToken);
  });

  test('should dynamically update config token when environment changes', () => {
    const firstToken = 'gw_first_token';
    const secondToken = 'gw_second_token';

    // Set first token
    process.env.GATEWAY_TOKEN = firstToken;
    expect(config.gateway.token).toBe(firstToken);

    // Update to second token (simulating runtime update after registration)
    process.env.GATEWAY_TOKEN = secondToken;
    expect(config.gateway.token).toBe(secondToken);
  });

  test('should NOT fallback to GATEWAY_API_KEY for token validation', () => {
    // Ensure GATEWAY_TOKEN is not set
    delete process.env.GATEWAY_TOKEN;

    // Verify config.gateway.token does NOT use GATEWAY_API_KEY
    // This is correct behavior: GATEWAY_API_KEY is for outbound auth, not inbound validation
    expect(config.gateway.token).toBeUndefined();

    // Note: config.gateway.apiKey is set once at config initialization
    // It cannot be dynamically tested in this way
  });

  test('should keep GATEWAY_TOKEN separate from GATEWAY_API_KEY', () => {
    const token = 'gw_primary_token';

    // Set gateway token
    process.env.GATEWAY_TOKEN = token;

    // Verify GATEWAY_TOKEN is used for inbound validation
    expect(config.gateway.token).toBe(token);

    // Note: GATEWAY_API_KEY (config.gateway.apiKey) is for outbound authentication
    // and is set at config initialization time
  });

  test('should return undefined when neither token is set', () => {
    // Ensure both are not set
    delete process.env.GATEWAY_TOKEN;
    delete process.env.GATEWAY_API_KEY;

    // Verify config returns undefined
    expect(config.gateway.token).toBeUndefined();
  });

  test('should handle token being set at runtime after initialization', () => {
    // Start with no token
    delete process.env.GATEWAY_TOKEN;
    expect(config.gateway.token).toBeUndefined();

    // Simulate setting token at runtime (like after gateway registration)
    const runtimeToken = 'gw_runtime_token_123';
    process.env.GATEWAY_TOKEN = runtimeToken;

    // Verify config now returns the token
    expect(config.gateway.token).toBe(runtimeToken);
  });

  test('should allow token to be updated multiple times at runtime', () => {
    const tokens = ['gw_token_1', 'gw_token_2', 'gw_token_3'];

    tokens.forEach((token) => {
      process.env.GATEWAY_TOKEN = token;
      expect(config.gateway.token).toBe(token);
    });
  });
});

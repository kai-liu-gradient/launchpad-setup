import { jest } from '@jest/globals';
import { config, validateConfig } from '../src/config.js';

describe('Config Module', () => {
  let originalEnv;

  beforeEach(() => {
    // Save original environment
    originalEnv = { ...process.env };
    // Clear environment variables for testing
    jest.resetModules();
  });

  afterEach(() => {
    // Restore original environment
    process.env = originalEnv;
  });

  describe('parseWorkdirs', () => {
    test('should parse workdirs correctly from comma-separated format', () => {
      process.env.LARK_WORKDIRS = 'workspace1:/path/to/workspace1,workspace2:/path/to/workspace2';
      
      // Re-import to get fresh config with new env
      jest.resetModules();
      return import('../src/config.js').then((module) => {
        const workdirs = module.config.lark.workdirs;
        expect(workdirs).toEqual({
          workspace1: '/path/to/workspace1',
          workspace2: '/path/to/workspace2'
        });
      });
    });

    test('should handle empty workdirs string', () => {
      process.env.LARK_WORKDIRS = '';
      
      jest.resetModules();
      return import('../src/config.js').then((module) => {
        const workdirs = module.config.lark.workdirs;
        expect(workdirs).toEqual({});
      });
    });

    test('should handle undefined workdirs', () => {
      delete process.env.LARK_WORKDIRS;
      
      jest.resetModules();
      return import('../src/config.js').then((module) => {
        const workdirs = module.config.lark.workdirs;
        expect(workdirs).toEqual({});
      });
    });
  });

  describe('config structure', () => {
    test('should have correct structure with default values', () => {
      expect(config).toHaveProperty('lark');
      expect(config).toHaveProperty('telegram');
      expect(config).toHaveProperty('http');
      expect(config).toHaveProperty('tasks');
      expect(config).toHaveProperty('logging');
      expect(config).toHaveProperty('timezone');
    });

    test('should use default values when env vars are not set', () => {
      expect(config.http.port).toBe(6501);
      expect(config.http.host).toBe('0.0.0.0');
      expect(config.tasks.maxConcurrent).toBe(3);
      expect(config.tasks.timeoutMs).toBe(1800000);
      expect(config.logging.level).toBe('info');
      expect(config.timezone).toBe('Asia/Shanghai');
    });

    test('should parse integer values correctly', () => {
      process.env.HTTP_CALLBACK_PORT = '8080';
      process.env.MAX_CONCURRENT_TASKS = '5';
      
      jest.resetModules();
      return import('../src/config.js').then((module) => {
        expect(module.config.http.port).toBe(8080);
        expect(module.config.tasks.maxConcurrent).toBe(5);
      });
    });

    test('should handle boolean values correctly', () => {
      process.env.TELEGRAM_USE_WEBHOOK = 'true';
      
      jest.resetModules();
      return import('../src/config.js').then((module) => {
        expect(module.config.telegram.useWebhook).toBe(true);
      });
    });

    test('should parse allowed chats correctly', () => {
      process.env.TELEGRAM_ALLOWED_CHATS = '123456,789012,345678';
      
      jest.resetModules();
      return import('../src/config.js').then((module) => {
        expect(module.config.telegram.allowedChats).toEqual(['123456', '789012', '345678']);
      });
    });
  });

  describe('validateConfig', () => {
    test('should throw error when no notification method is configured', () => {
      // Clear all notification configs
      delete process.env.LARK_WEBHOOK_URL;
      delete process.env.LARK_APP_ID;
      delete process.env.LARK_APP_SECRET;
      delete process.env.LARK_GROUP_CHAT_ID;
      delete process.env.TELEGRAM_BOT_TOKEN;
      
      jest.resetModules();
      return import('../src/config.js').then((module) => {
        expect(() => module.validateConfig()).toThrow('At least one notification method is required');
      });
    });

    test('should pass validation with Lark webhook configured', () => {
      process.env.LARK_WEBHOOK_URL = 'https://lark.webhook.url';
      
      jest.resetModules();
      return import('../src/config.js').then((module) => {
        expect(() => module.validateConfig()).not.toThrow();
      });
    });

    test('should pass validation with Lark API configured', () => {
      process.env.LARK_APP_ID = 'app_id';
      process.env.LARK_APP_SECRET = 'app_secret';
      process.env.LARK_GROUP_CHAT_ID = 'group_id';
      
      jest.resetModules();
      return import('../src/config.js').then((module) => {
        expect(() => module.validateConfig()).not.toThrow();
      });
    });

    test('should pass validation with Telegram configured', () => {
      process.env.TELEGRAM_BOT_TOKEN = 'bot_token';
      
      jest.resetModules();
      return import('../src/config.js').then((module) => {
        expect(() => module.validateConfig()).not.toThrow();
      });
    });
  });

  describe('hostname', () => {
    test('should include hostname in lark config', () => {
      expect(config.lark.hostname).toBeDefined();
      expect(typeof config.lark.hostname).toBe('string');
      expect(config.lark.hostname.length).toBeGreaterThan(0);
    });
  });

  describe('keyword prefix', () => {
    test('should handle keyword prefix correctly', () => {
      process.env.LARK_KEYWORD_PREFIX = '@bot';
      
      jest.resetModules();
      return import('../src/config.js').then((module) => {
        expect(module.config.lark.keywordPrefix).toBe('@bot');
      });
    });

    test('should default to null when not set', () => {
      delete process.env.LARK_KEYWORD_PREFIX;
      
      jest.resetModules();
      return import('../src/config.js').then((module) => {
        expect(module.config.lark.keywordPrefix).toBeNull();
      });
    });
  });
});
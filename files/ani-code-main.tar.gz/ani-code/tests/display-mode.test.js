import { jest } from '@jest/globals';
import {
  DISPLAY_MODES,
  VALID_DISPLAY_MODES,
  resolveDisplayMode,
  DisplayModeManager
} from '../src/display-mode.js';

// Mock the logger module
jest.unstable_mockModule('../src/logger.js', () => ({
  logger: {
    info: jest.fn(),
    debug: jest.fn(),
    warn: jest.fn(),
    error: jest.fn()
  }
}));

describe('Display Mode Constants', () => {
  test('DISPLAY_MODES has correct values', () => {
    expect(DISPLAY_MODES.FULL).toBe('full');
    expect(DISPLAY_MODES.SIMPLE).toBe('simple');
    expect(DISPLAY_MODES.DEFAULT).toBe('default');
  });

  test('VALID_DISPLAY_MODES contains all modes', () => {
    expect(VALID_DISPLAY_MODES).toEqual(['full', 'simple', 'default']);
    expect(VALID_DISPLAY_MODES).toHaveLength(3);
  });
});

describe('resolveDisplayMode', () => {
  test('resolves "full" to "full"', () => {
    expect(resolveDisplayMode('full')).toBe('full');
  });

  test('resolves "simple" to "simple"', () => {
    expect(resolveDisplayMode('simple')).toBe('simple');
  });

  test('resolves "default" to "full"', () => {
    expect(resolveDisplayMode('default')).toBe('full');
  });

  test('resolves unknown values to "full"', () => {
    expect(resolveDisplayMode('invalid')).toBe('full');
    expect(resolveDisplayMode('')).toBe('full');
    expect(resolveDisplayMode(null)).toBe('full');
    expect(resolveDisplayMode(undefined)).toBe('full');
  });
});

describe('DisplayModeManager', () => {
  let manager;
  let mockChatSettings;

  beforeEach(() => {
    // Reset env var
    delete process.env.CHAT_DISPLAY_MODE;

    mockChatSettings = {
      getDisplayMode: jest.fn().mockReturnValue(null),
      setDisplayMode: jest.fn().mockResolvedValue(undefined)
    };

    manager = new DisplayModeManager(mockChatSettings);
  });

  afterEach(() => {
    delete process.env.CHAT_DISPLAY_MODE;
  });

  describe('constructor', () => {
    test('stores chatSettings reference', () => {
      expect(manager.chatSettings).toBe(mockChatSettings);
    });
  });

  describe('getDisplayMode', () => {
    test('returns per-chat setting when available', () => {
      mockChatSettings.getDisplayMode.mockReturnValue('simple');
      expect(manager.getDisplayMode('telegram:123')).toBe('simple');
      expect(mockChatSettings.getDisplayMode).toHaveBeenCalledWith('telegram:123');
    });

    test('resolves "default" per-chat setting to "full"', () => {
      mockChatSettings.getDisplayMode.mockReturnValue('default');
      expect(manager.getDisplayMode('telegram:123')).toBe('full');
    });

    test('falls back to CHAT_DISPLAY_MODE env var when no per-chat setting', () => {
      mockChatSettings.getDisplayMode.mockReturnValue(null);
      process.env.CHAT_DISPLAY_MODE = 'simple';
      expect(manager.getDisplayMode('telegram:123')).toBe('simple');
    });

    test('resolves "default" env var to "full"', () => {
      mockChatSettings.getDisplayMode.mockReturnValue(null);
      process.env.CHAT_DISPLAY_MODE = 'default';
      expect(manager.getDisplayMode('telegram:123')).toBe('full');
    });

    test('ignores invalid CHAT_DISPLAY_MODE env var', () => {
      mockChatSettings.getDisplayMode.mockReturnValue(null);
      process.env.CHAT_DISPLAY_MODE = 'invalid_mode';
      expect(manager.getDisplayMode('telegram:123')).toBe('full');
    });

    test('defaults to "full" when no per-chat setting and no env var', () => {
      mockChatSettings.getDisplayMode.mockReturnValue(null);
      expect(manager.getDisplayMode('telegram:123')).toBe('full');
    });

    test('per-chat setting takes priority over env var', () => {
      mockChatSettings.getDisplayMode.mockReturnValue('simple');
      process.env.CHAT_DISPLAY_MODE = 'full';
      expect(manager.getDisplayMode('telegram:123')).toBe('simple');
    });

    test('handles null chatId gracefully', () => {
      expect(manager.getDisplayMode(null)).toBe('full');
    });

    test('handles undefined chatId gracefully', () => {
      expect(manager.getDisplayMode(undefined)).toBe('full');
    });

    test('handles null chatSettings', () => {
      const managerNoChatSettings = new DisplayModeManager(null);
      expect(managerNoChatSettings.getDisplayMode('telegram:123')).toBe('full');
    });

    test('uses env var when chatSettings is null', () => {
      const managerNoChatSettings = new DisplayModeManager(null);
      process.env.CHAT_DISPLAY_MODE = 'simple';
      expect(managerNoChatSettings.getDisplayMode('telegram:123')).toBe('simple');
    });
  });

  describe('setDisplayMode', () => {
    test('sets mode and returns previous and new mode', async () => {
      mockChatSettings.getDisplayMode.mockReturnValue(null); // no existing setting
      const result = await manager.setDisplayMode('telegram:123', 'simple');
      expect(result).toEqual({ previousMode: 'full', newMode: 'simple' });
      expect(mockChatSettings.setDisplayMode).toHaveBeenCalledWith('telegram:123', 'simple');
    });

    test('resolves "default" mode to "full" when setting', async () => {
      const result = await manager.setDisplayMode('telegram:123', 'default');
      expect(result.newMode).toBe('full');
      expect(mockChatSettings.setDisplayMode).toHaveBeenCalledWith('telegram:123', 'full');
    });

    test('returns correct previousMode when switching from simple to full', async () => {
      mockChatSettings.getDisplayMode.mockReturnValue('simple');
      const result = await manager.setDisplayMode('telegram:123', 'full');
      expect(result).toEqual({ previousMode: 'simple', newMode: 'full' });
    });

    test('throws on invalid mode', async () => {
      await expect(manager.setDisplayMode('telegram:123', 'invalid'))
        .rejects.toThrow('Invalid display mode: invalid');
    });

    test('throws with list of valid modes in error message', async () => {
      await expect(manager.setDisplayMode('telegram:123', 'xyz'))
        .rejects.toThrow('Valid modes: full, simple, default');
    });

    test('works when chatSettings is null', async () => {
      const managerNoChatSettings = new DisplayModeManager(null);
      const result = await managerNoChatSettings.setDisplayMode('telegram:123', 'simple');
      expect(result).toEqual({ previousMode: 'full', newMode: 'simple' });
    });
  });

  describe('getAvailableModes (static)', () => {
    test('returns array of mode objects', () => {
      const modes = DisplayModeManager.getAvailableModes();
      expect(modes).toHaveLength(3);
    });

    test('each mode has id, name, and description', () => {
      const modes = DisplayModeManager.getAvailableModes();
      for (const mode of modes) {
        expect(mode).toHaveProperty('id');
        expect(mode).toHaveProperty('name');
        expect(mode).toHaveProperty('description');
        expect(typeof mode.id).toBe('string');
        expect(typeof mode.name).toBe('string');
        expect(typeof mode.description).toBe('string');
      }
    });

    test('contains full, simple, and default modes', () => {
      const modes = DisplayModeManager.getAvailableModes();
      const ids = modes.map(m => m.id);
      expect(ids).toContain('full');
      expect(ids).toContain('simple');
      expect(ids).toContain('default');
    });

    test('full mode has correct metadata', () => {
      const modes = DisplayModeManager.getAvailableModes();
      const fullMode = modes.find(m => m.id === 'full');
      expect(fullMode.name).toBe('Full');
      expect(fullMode.description).toContain('headers');
    });

    test('simple mode has correct metadata', () => {
      const modes = DisplayModeManager.getAvailableModes();
      const simpleMode = modes.find(m => m.id === 'simple');
      expect(simpleMode.name).toBe('Simple');
      expect(simpleMode.description).toContain('task output');
    });

    test('default mode describes itself as alias for full', () => {
      const modes = DisplayModeManager.getAvailableModes();
      const defaultMode = modes.find(m => m.id === 'default');
      expect(defaultMode.description.toLowerCase()).toContain('alias');
    });
  });
});

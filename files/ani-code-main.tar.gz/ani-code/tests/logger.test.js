import { jest } from '@jest/globals';

// Mock the config module before importing logger
jest.unstable_mockModule('../src/config.js', () => ({
  config: {
    logging: {
      level: 'info'
    }
  }
}));

// Mock the secure-upload utility
jest.unstable_mockModule('../src/utils/secure-upload.js', () => ({
  SecureUploader: {
    maskCredentials: jest.fn((text) => {
      if (!text) return text;
      // Simple mock implementation
      return String(text).replace(/AKIA[A-Z0-9]{16}/g, 'AKIA****');
    })
  }
}));

describe('Logger Module', () => {
  let logger;
  let consoleLogSpy, consoleErrorSpy, consoleWarnSpy;
  let originalEnv;

  beforeEach(async () => {
    // Save original environment
    originalEnv = { ...process.env };
    
    // Mock console methods
    consoleLogSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
    consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
    consoleWarnSpy = jest.spyOn(console, 'warn').mockImplementation(() => {});
    
    // Reset modules to get fresh instances
    jest.resetModules();
  });

  afterEach(() => {
    // Restore console methods
    consoleLogSpy.mockRestore();
    consoleErrorSpy.mockRestore();
    consoleWarnSpy.mockRestore();
    
    // Restore environment
    process.env = originalEnv;
  });

  describe('log levels', () => {
    test('should respect info log level', async () => {
      process.env.LOG_LEVEL = 'info';
      
      // Re-mock with the new log level
      jest.unstable_mockModule('../src/config.js', () => ({
        config: {
          logging: {
            level: 'info'
          }
        }
      }));
      
      const { logger } = await import('../src/logger.js');
      
      logger.debug('debug message');
      logger.info('info message');
      logger.warn('warn message');
      logger.error('error message');
      
      expect(consoleLogSpy).toHaveBeenCalledTimes(1); // info only
      expect(consoleWarnSpy).toHaveBeenCalledTimes(1);
      expect(consoleErrorSpy).toHaveBeenCalledTimes(1);
    });

    test('should respect debug log level', async () => {
      // Re-mock with debug level
      jest.unstable_mockModule('../src/config.js', () => ({
        config: {
          logging: {
            level: 'debug'
          }
        }
      }));
      
      jest.resetModules();
      const { logger } = await import('../src/logger.js');
      
      logger.debug('debug message');
      logger.info('info message');
      logger.warn('warn message');
      logger.error('error message');
      
      expect(consoleLogSpy).toHaveBeenCalledTimes(2); // debug and info
      expect(consoleWarnSpy).toHaveBeenCalledTimes(1);
      expect(consoleErrorSpy).toHaveBeenCalledTimes(1);
    });

    test('should respect error log level', async () => {
      // Re-mock with error level
      jest.unstable_mockModule('../src/config.js', () => ({
        config: {
          logging: {
            level: 'error'
          }
        }
      }));
      
      jest.resetModules();
      const { logger } = await import('../src/logger.js');
      
      logger.debug('debug message');
      logger.info('info message');
      logger.warn('warn message');
      logger.error('error message');
      
      expect(consoleLogSpy).toHaveBeenCalledTimes(0);
      expect(consoleWarnSpy).toHaveBeenCalledTimes(0);
      expect(consoleErrorSpy).toHaveBeenCalledTimes(1);
    });

    test('should respect warn log level', async () => {
      // Re-mock with warn level
      jest.unstable_mockModule('../src/config.js', () => ({
        config: {
          logging: {
            level: 'warn'
          }
        }
      }));
      
      jest.resetModules();
      const { logger } = await import('../src/logger.js');
      
      logger.debug('debug message');
      logger.info('info message');
      logger.warn('warn message');
      logger.error('error message');
      
      expect(consoleLogSpy).toHaveBeenCalledTimes(0);
      expect(consoleWarnSpy).toHaveBeenCalledTimes(1);
      expect(consoleErrorSpy).toHaveBeenCalledTimes(1);
    });
  });

  describe('message formatting', () => {
    test('should format multiple arguments correctly', async () => {
      const { logger } = await import('../src/logger.js');
      
      logger.info('Hello', 'World', 123);
      
      expect(consoleLogSpy).toHaveBeenCalled();
      const call = consoleLogSpy.mock.calls[0][0];
      expect(call).toContain('Hello World 123');
    });

    test('should format objects as JSON', async () => {
      const { logger } = await import('../src/logger.js');
      
      const obj = { key: 'value', number: 42 };
      logger.info('Object:', obj);
      
      expect(consoleLogSpy).toHaveBeenCalled();
      const call = consoleLogSpy.mock.calls[0][0];
      expect(call).toContain('Object:');
      expect(call).toContain('"key": "value"');
      expect(call).toContain('"number": 42');
    });
  });

  describe('sensitive data masking', () => {
    test('should mask AWS credentials', async () => {
      const { logger } = await import('../src/logger.js');
      
      logger.info('AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE');
      
      expect(consoleLogSpy).toHaveBeenCalled();
      const call = consoleLogSpy.mock.calls[0][0];
      expect(call).toContain('AKIA****');
      expect(call).not.toContain('AKIAIOSFODNN7EXAMPLE');
    });
  });

  describe('success method', () => {
    test('should log success messages at info level', async () => {
      const { logger } = await import('../src/logger.js');
      
      logger.success('Operation completed');
      
      expect(consoleLogSpy).toHaveBeenCalled();
      const call = consoleLogSpy.mock.calls[0][0];
      expect(call).toContain('SUCCESS:');
      expect(call).toContain('Operation completed');
    });
  });

  describe('edge cases', () => {
    test('should handle null and undefined gracefully', async () => {
      const { logger } = await import('../src/logger.js');
      
      logger.info(null, undefined);
      
      expect(consoleLogSpy).toHaveBeenCalled();
      const call = consoleLogSpy.mock.calls[0][0];
      expect(call).toContain('null undefined');
    });

    test('should handle empty arguments', async () => {
      const { logger } = await import('../src/logger.js');
      
      logger.info();
      
      expect(consoleLogSpy).toHaveBeenCalled();
      const call = consoleLogSpy.mock.calls[0][0];
      expect(call).toContain('INFO:');
    });
  });
});
import { jest } from '@jest/globals';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { mkdirSync, writeFileSync, rmSync, existsSync } from 'fs';

// Import the healthcheck module functions
import {
  detectTechstacks,
  generateTimestampedFilename,
  calculateHealthScore,
  generateRecommendations,
  cleanupOldReports,
  loadPromptTemplate,
  buildAnalysisPrompt,
  parseClaudeResponse,
  validateAnalysisResponse,
  mergeClaudeAnalysis,
  TECHSTACK_DETECTORS,
  SCHEMA_VERSION
} from '../src/commands/healthcheck.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

describe('Healthcheck Command Module', () => {
  const testDir = join(__dirname, 'test-workspace');
  const healthcheckDir = join(testDir, '.ani-code', 'healthcheck');

  beforeEach(() => {
    // Create test directory structure
    mkdirSync(testDir, { recursive: true });
    mkdirSync(healthcheckDir, { recursive: true });
  });

  afterEach(() => {
    // Cleanup test directory
    if (existsSync(testDir)) {
      rmSync(testDir, { recursive: true, force: true });
    }
  });

  describe('detectTechstacks', () => {
    test('should detect Node.js project by package.json', () => {
      writeFileSync(join(testDir, 'package.json'), '{}');

      const detected = detectTechstacks(testDir);
      expect(detected).toContain('node');
    });

    test('should detect Python project by requirements.txt', () => {
      writeFileSync(join(testDir, 'requirements.txt'), '');

      const detected = detectTechstacks(testDir);
      expect(detected).toContain('python');
    });

    test('should detect Go project by go.mod', () => {
      writeFileSync(join(testDir, 'go.mod'), 'module test');

      const detected = detectTechstacks(testDir);
      expect(detected).toContain('go');
    });

    test('should detect Rust project by Cargo.toml', () => {
      writeFileSync(join(testDir, 'Cargo.toml'), '[package]');

      const detected = detectTechstacks(testDir);
      expect(detected).toContain('rust');
    });

    test('should detect Java project by pom.xml', () => {
      writeFileSync(join(testDir, 'pom.xml'), '<project></project>');

      const detected = detectTechstacks(testDir);
      expect(detected).toContain('java');
    });

    test('should detect multiple techstacks', () => {
      writeFileSync(join(testDir, 'package.json'), '{}');
      writeFileSync(join(testDir, 'requirements.txt'), '');

      const detected = detectTechstacks(testDir);
      expect(detected).toContain('node');
      expect(detected).toContain('python');
    });

    test('should return empty array for unknown project', () => {
      const detected = detectTechstacks(testDir);
      expect(detected).toEqual([]);
    });
  });

  describe('generateTimestampedFilename', () => {
    test('should generate filename in correct format', () => {
      const filename = generateTimestampedFilename();

      // Pattern: healthcheck-YYYY-MM-DD-HHMMSS
      expect(filename).toMatch(/^healthcheck-\d{4}-\d{2}-\d{2}-\d{6}$/);
    });

    test('should generate unique filenames', () => {
      const filename1 = generateTimestampedFilename();
      // Wait a bit to ensure different timestamp
      const startTime = Date.now();
      while (Date.now() - startTime < 1100) {
        // busy wait for 1.1 seconds
      }
      const filename2 = generateTimestampedFilename();

      expect(filename1).not.toEqual(filename2);
    });
  });

  describe('calculateHealthScore', () => {
    test('should return 100 for no vulnerabilities', () => {
      const auditData = {
        metadata: {
          vulnerabilities: {
            critical: 0,
            high: 0,
            moderate: 0,
            low: 0,
            info: 0
          }
        }
      };

      const result = calculateHealthScore(auditData);
      expect(result.healthScore).toBe(100);
      expect(result.status).toBe('pass');
    });

    test('should reduce score for critical vulnerabilities', () => {
      const auditData = {
        metadata: {
          vulnerabilities: {
            critical: 1,
            high: 0,
            moderate: 0,
            low: 0,
            info: 0
          }
        }
      };

      const result = calculateHealthScore(auditData);
      expect(result.healthScore).toBe(75); // 100 - 25
      expect(result.status).toBe('critical');
      expect(result.critical).toBe(1);
    });

    test('should reduce score for high vulnerabilities', () => {
      const auditData = {
        metadata: {
          vulnerabilities: {
            critical: 0,
            high: 2,
            moderate: 0,
            low: 0,
            info: 0
          }
        }
      };

      const result = calculateHealthScore(auditData);
      expect(result.healthScore).toBe(70); // 100 - 30
      expect(result.status).toBe('fail');
    });

    test('should handle combined vulnerabilities', () => {
      const auditData = {
        metadata: {
          vulnerabilities: {
            critical: 1,
            high: 1,
            moderate: 2,
            low: 3,
            info: 0
          }
        }
      };

      const result = calculateHealthScore(auditData);
      // 100 - 25 (critical) - 15 (high) - 10 (moderate) - 3 (low) = 47
      expect(result.healthScore).toBe(47);
      expect(result.totalIssues).toBe(7);
    });

    test('should not go below 0', () => {
      const auditData = {
        metadata: {
          vulnerabilities: {
            critical: 10,
            high: 10,
            moderate: 10,
            low: 10,
            info: 0
          }
        }
      };

      const result = calculateHealthScore(auditData);
      expect(result.healthScore).toBe(0);
    });
  });

  describe('generateRecommendations', () => {
    test('should recommend fix for critical vulnerabilities', () => {
      const nodeData = {
        audit: {
          metadata: {
            vulnerabilities: {
              critical: 2,
              high: 0
            }
          }
        },
        outdated: {}
      };
      const config = { hasLockFile: true, enginesDefined: true };

      const recs = generateRecommendations(nodeData, config);

      const criticalRec = recs.find(r => r.priority === 'critical');
      expect(criticalRec).toBeDefined();
      expect(criticalRec.action).toContain('npm audit fix');
    });

    test('should recommend lock file when missing', () => {
      const nodeData = { audit: {}, outdated: {} };
      const config = { hasLockFile: false, enginesDefined: true };

      const recs = generateRecommendations(nodeData, config);

      const lockFileRec = recs.find(r => r.reason.includes('lock file'));
      expect(lockFileRec).toBeDefined();
      expect(lockFileRec.priority).toBe('high');
    });

    test('should recommend engines field when missing', () => {
      const nodeData = { audit: {}, outdated: {} };
      const config = { hasLockFile: true, enginesDefined: false };

      const recs = generateRecommendations(nodeData, config);

      const enginesRec = recs.find(r => r.action.includes('engines'));
      expect(enginesRec).toBeDefined();
    });

    test('should recommend updating outdated packages', () => {
      const nodeData = {
        audit: {},
        outdated: {
          'package1': {},
          'package2': {},
          'package3': {}
        }
      };
      const config = { hasLockFile: true, enginesDefined: true };

      const recs = generateRecommendations(nodeData, config);

      const outdatedRec = recs.find(r => r.reason.includes('outdated'));
      expect(outdatedRec).toBeDefined();
    });
  });

  describe('cleanupOldReports', () => {
    test('should delete files older than specified days', async () => {
      // Create an old file
      const oldFile = join(healthcheckDir, 'healthcheck-2020-01-01-000000.json');
      writeFileSync(oldFile, '{}');

      // Set modification time to 60 days ago
      const oldTime = Date.now() - (60 * 24 * 60 * 60 * 1000);
      const { utimesSync } = await import('fs');
      utimesSync(oldFile, new Date(oldTime), new Date(oldTime));

      const deleted = cleanupOldReports(healthcheckDir, 30);

      expect(deleted).toBe(1);
      expect(existsSync(oldFile)).toBe(false);
    });

    test('should keep recent files', () => {
      const recentFile = join(healthcheckDir, 'healthcheck-2025-01-01-000000.json');
      writeFileSync(recentFile, '{}');

      const deleted = cleanupOldReports(healthcheckDir, 30);

      expect(deleted).toBe(0);
      expect(existsSync(recentFile)).toBe(true);
    });

    test('should return 0 for non-existent directory', () => {
      const deleted = cleanupOldReports('/non/existent/path', 30);
      expect(deleted).toBe(0);
    });
  });

  describe('loadPromptTemplate', () => {
    test('should load node template', () => {
      const template = loadPromptTemplate('node');
      expect(template).toBeDefined();
      expect(template).toContain('Node.js');
    });

    test('should load auto template', () => {
      const template = loadPromptTemplate('auto');
      expect(template).toBeDefined();
      expect(template).toContain('Auto');
    });

    test('should return null for non-existent template', () => {
      const template = loadPromptTemplate('nonexistent');
      expect(template).toBeNull();
    });
  });

  describe('buildAnalysisPrompt', () => {
    test('should include template and data', () => {
      const stackData = {
        audit: { vulnerabilities: {} },
        config: { hasLockFile: true }
      };

      const prompt = buildAnalysisPrompt('node', stackData);

      expect(prompt).toContain('Node.js');
      expect(prompt).toContain('hasLockFile');
    });

    test('should fallback for unknown stack', () => {
      const stackData = { test: 'data' };
      const prompt = buildAnalysisPrompt('unknown', stackData);

      expect(prompt).toContain('unknown');
      expect(prompt).toContain('test');
    });
  });

  describe('parseClaudeResponse', () => {
    test('should parse valid JSON', () => {
      const output = '{"analysis": {"securityRisk": "low"}}';
      const result = parseClaudeResponse(output);

      expect(result).toEqual({ analysis: { securityRisk: 'low' } });
    });

    test('should extract JSON from surrounding text', () => {
      const output = 'Here is the analysis:\n{"result": "success"}\nEnd of response.';
      const result = parseClaudeResponse(output);

      expect(result).toEqual({ result: 'success' });
    });

    test('should handle markdown code blocks', () => {
      const output = '```json\n{"data": "value"}\n```';
      const result = parseClaudeResponse(output);

      expect(result).toEqual({ data: 'value' });
    });

    test('should return null for invalid JSON', () => {
      const output = 'This is not JSON';
      const result = parseClaudeResponse(output);

      expect(result).toBeNull();
    });

    test('should return null for empty output', () => {
      const result = parseClaudeResponse('');
      expect(result).toBeNull();
    });

    test('should return null for null input', () => {
      const result = parseClaudeResponse(null);
      expect(result).toBeNull();
    });
  });

  describe('validateAnalysisResponse', () => {
    test('should validate complete node analysis', () => {
      const analysis = {
        analysis: {
          securityRisk: 'low',
          maintenanceStatus: 'good',
          overallAssessment: 'Project is healthy'
        },
        insights: [],
        prioritizedActions: []
      };

      const result = validateAnalysisResponse(analysis, 'node');

      expect(result.isValid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    test('should detect missing analysis field', () => {
      const analysis = {
        insights: [],
        prioritizedActions: []
      };

      const result = validateAnalysisResponse(analysis, 'node');

      expect(result.isValid).toBe(false);
      expect(result.errors).toContain('Missing analysis field');
    });

    test('should detect missing insights array', () => {
      const analysis = {
        analysis: { securityRisk: 'low', maintenanceStatus: 'good' },
        prioritizedActions: []
      };

      const result = validateAnalysisResponse(analysis, 'node');

      expect(result.isValid).toBe(false);
      expect(result.errors).toContain('Missing or invalid insights array');
    });

    test('should validate auto analysis', () => {
      const analysis = {
        projectOverview: { healthScore: 85 },
        prioritizedActions: []
      };

      const result = validateAnalysisResponse(analysis, 'auto');

      expect(result.isValid).toBe(true);
    });

    test('should handle null analysis', () => {
      const result = validateAnalysisResponse(null, 'node');

      expect(result.isValid).toBe(false);
      expect(result.errors).toContain('No analysis response received');
    });
  });

  describe('mergeClaudeAnalysis', () => {
    test('should add claude analysis to stack', () => {
      const report = {
        stacks: { node: {} },
        recommendations: []
      };
      const claudeAnalysis = {
        analysis: { overallAssessment: 'Good project' },
        insights: [],
        prioritizedActions: []
      };

      mergeClaudeAnalysis(report, claudeAnalysis, 'node');

      expect(report.stacks.node.claudeAnalysis).toEqual(claudeAnalysis);
      expect(report.claudeAssessment).toBe('Good project');
    });

    test('should merge insights into recommendations', () => {
      const report = {
        stacks: { node: {} },
        recommendations: []
      };
      const claudeAnalysis = {
        insights: [
          {
            severity: 'high',
            title: 'Security Issue',
            description: 'Details',
            recommendation: 'Fix it'
          }
        ],
        prioritizedActions: []
      };

      mergeClaudeAnalysis(report, claudeAnalysis, 'node');

      expect(report.recommendations).toHaveLength(1);
      expect(report.recommendations[0].action).toBe('Fix it');
      expect(report.recommendations[0].source).toBe('claude-analysis');
    });

    test('should merge prioritized actions', () => {
      const report = {
        stacks: { node: {} },
        recommendations: []
      };
      const claudeAnalysis = {
        insights: [],
        prioritizedActions: [
          {
            order: 1,
            action: 'Run npm update',
            impact: 'high',
            reason: 'Updates available'
          }
        ]
      };

      mergeClaudeAnalysis(report, claudeAnalysis, 'node');

      expect(report.recommendations).toHaveLength(1);
      expect(report.recommendations[0].action).toBe('Run npm update');
      expect(report.recommendations[0].priority).toBe('high');
    });

    test('should handle null analysis gracefully', () => {
      const report = {
        stacks: { node: {} },
        recommendations: []
      };

      mergeClaudeAnalysis(report, null, 'node');

      expect(report.recommendations).toHaveLength(0);
    });
  });

  describe('SCHEMA_VERSION', () => {
    test('should be defined', () => {
      expect(SCHEMA_VERSION).toBeDefined();
      expect(SCHEMA_VERSION).toBe('1.0.0');
    });
  });

  describe('TECHSTACK_DETECTORS', () => {
    test('should have node detector', () => {
      expect(TECHSTACK_DETECTORS.node).toBeDefined();
      expect(TECHSTACK_DETECTORS.node.files).toContain('package.json');
    });

    test('should have python detector', () => {
      expect(TECHSTACK_DETECTORS.python).toBeDefined();
      expect(TECHSTACK_DETECTORS.python.files).toContain('requirements.txt');
    });

    test('should have go detector', () => {
      expect(TECHSTACK_DETECTORS.go).toBeDefined();
      expect(TECHSTACK_DETECTORS.go.files).toContain('go.mod');
    });

    test('should have rust detector', () => {
      expect(TECHSTACK_DETECTORS.rust).toBeDefined();
      expect(TECHSTACK_DETECTORS.rust.files).toContain('Cargo.toml');
    });

    test('should have java detector', () => {
      expect(TECHSTACK_DETECTORS.java).toBeDefined();
      expect(TECHSTACK_DETECTORS.java.files).toContain('pom.xml');
    });
  });
});

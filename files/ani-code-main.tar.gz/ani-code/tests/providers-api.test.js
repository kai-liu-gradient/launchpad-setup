import { describe, test, expect, beforeAll, afterAll } from '@jest/globals';
import { ProviderManager, getProviderManager } from '../src/providers/providerManager.js';
import { getKnownModels, getModelPricing, MODEL_PRICING } from '../src/providers/costCalculator.js';

describe('Providers API', () => {
  let providerManager;

  beforeAll(async () => {
    providerManager = await getProviderManager();
  });

  describe('ProviderManager API methods', () => {
    test('listProvidersWithMetadata returns all providers with metadata', () => {
      const providers = providerManager.listProvidersWithMetadata();

      expect(Array.isArray(providers)).toBe(true);
      expect(providers.length).toBeGreaterThan(0);

      // Check structure of first provider
      const provider = providers[0];
      expect(provider).toHaveProperty('id');
      expect(provider).toHaveProperty('name');
      expect(provider).toHaveProperty('binary');
      expect(provider).toHaveProperty('available');
      expect(provider).toHaveProperty('enabled');
      expect(provider).toHaveProperty('current');
      expect(provider).toHaveProperty('capabilities');
      expect(provider).toHaveProperty('modelCount');

      // Check capabilities structure
      expect(provider.capabilities).toHaveProperty('supportsCreate');
      expect(provider.capabilities).toHaveProperty('supportsContinue');
      expect(provider.capabilities).toHaveProperty('supportsGreenlight');
      expect(provider.capabilities).toHaveProperty('supportsModels');
    });

    test('listProviders includes unavailable providers when requested', () => {
      const availableOnly = providerManager.listProviders(false);
      const allProviders = providerManager.listProviders(true);

      expect(Array.isArray(availableOnly)).toBe(true);
      expect(Array.isArray(allProviders)).toBe(true);
      expect(allProviders.length).toBeGreaterThanOrEqual(availableOnly.length);
    });

    test('getHandlerInfo returns provider details', () => {
      const info = providerManager.getHandlerInfo('claude');

      expect(info).not.toBeNull();
      expect(info.id).toBe('claude');
      // Name may be 'claude' or 'Claude Code' depending on config merge
      expect(typeof info.name).toBe('string');
      expect(info).toHaveProperty('binary');
      expect(info).toHaveProperty('available');
      expect(info).toHaveProperty('capabilities');
    });

    test('getHandlerInfo returns null for unknown provider', () => {
      const info = providerManager.getHandlerInfo('unknown-provider');
      expect(info).toBeNull();
    });

    test('getProviderModels returns model IDs for known provider', () => {
      const models = providerManager.getProviderModels('claude');

      expect(Array.isArray(models)).toBe(true);
      expect(models.length).toBeGreaterThan(0);
      expect(models).toContain('claude-sonnet-4');
    });

    test('getProviderModels returns empty array for unknown provider', () => {
      const models = providerManager.getProviderModels('unknown-provider');
      expect(Array.isArray(models)).toBe(true);
      expect(models.length).toBe(0);
    });

    test('getProviderModelsWithPricing returns models with pricing data', () => {
      const models = providerManager.getProviderModelsWithPricing('claude');

      expect(Array.isArray(models)).toBe(true);
      expect(models.length).toBeGreaterThan(0);

      const model = models[0];
      expect(model).toHaveProperty('id');
      expect(model).toHaveProperty('name');
      expect(model).toHaveProperty('enabled');
      expect(model).toHaveProperty('default');
      expect(model).toHaveProperty('pricing');
      expect(model).toHaveProperty('aliases');

      // Check pricing structure
      expect(model.pricing).toHaveProperty('input');
      expect(model.pricing).toHaveProperty('output');
      expect(model.pricing).toHaveProperty('cached');
      expect(typeof model.pricing.input).toBe('number');
    });
  });

  describe('Cost Calculator Integration', () => {
    test('getKnownModels returns models for all registered providers', () => {
      const providersWithPricing = ['claude', 'copilot', 'opencode', 'gemini', 'codex', 'cursor'];

      for (const providerId of providersWithPricing) {
        const models = getKnownModels(providerId);
        expect(Array.isArray(models)).toBe(true);
        expect(models.length).toBeGreaterThan(0);
      }
    });

    test('getModelPricing returns pricing for known models', () => {
      const pricing = getModelPricing('claude', 'claude-sonnet-4');

      expect(pricing).toHaveProperty('input');
      expect(pricing).toHaveProperty('output');
      expect(pricing).toHaveProperty('cached');
      expect(pricing.input).toBe(3.00);
      expect(pricing.output).toBe(15.00);
    });

    test('getModelPricing returns default pricing for unknown model', () => {
      const pricing = getModelPricing('claude', 'unknown-model');

      // Should return the _default pricing
      expect(pricing).toHaveProperty('input');
      expect(pricing).toHaveProperty('output');
    });

    test('MODEL_PRICING has copilot models', () => {
      const copilotPricing = MODEL_PRICING.copilot;

      expect(copilotPricing).toBeDefined();
      expect(copilotPricing['gpt-5']).toBeDefined();
      expect(copilotPricing['claude-sonnet-4']).toBeDefined();
    });

    test('MODEL_PRICING has opencode models', () => {
      const opencodePricing = MODEL_PRICING.opencode;

      expect(opencodePricing).toBeDefined();
      expect(opencodePricing['anthropic/claude-sonnet-4']).toBeDefined();
      expect(opencodePricing['openai/gpt-4o']).toBeDefined();
      expect(opencodePricing['google/gemini-2.5-flash']).toBeDefined();
    });
  });

  describe('Provider Capabilities', () => {
    test('Copilot provider has correct capabilities', () => {
      const handler = providerManager.getHandler('copilot');
      expect(handler).not.toBeNull();

      const capabilities = handler.getCapabilities();
      expect(capabilities.supportsCreate).toBe(true);
      expect(capabilities.supportsContinue).toBe(true);
      expect(capabilities.supportsGreenlight).toBe(true);
      expect(capabilities.supportsModels).toBe(true);
      expect(capabilities.supportsCcusage).toBe(false);
    });

    test('OpenCode provider has correct capabilities', () => {
      const handler = providerManager.getHandler('opencode');
      expect(handler).not.toBeNull();

      const capabilities = handler.getCapabilities();
      expect(capabilities.supportsCreate).toBe(true);
      expect(capabilities.supportsContinue).toBe(true);
      expect(capabilities.supportsGreenlight).toBe(true);
      expect(capabilities.supportsModels).toBe(true);
      expect(capabilities.supportsCcusage).toBe(false);
    });

    test('Claude provider has ccusage support', () => {
      const handler = providerManager.getHandler('claude');
      expect(handler).not.toBeNull();

      const capabilities = handler.getCapabilities();
      expect(capabilities.supportsCcusage).toBe(true);
    });
  });

  describe('Model Flags Generation', () => {
    test('Copilot handler generates correct model flags', () => {
      const handler = providerManager.getHandler('copilot');

      // Test sonnet mapping
      const sonnetFlags = handler.getModelFlags('sonnet');
      expect(sonnetFlags).toEqual(['--model', 'claude-sonnet-4']);

      // Test direct model name
      const gpt5Flags = handler.getModelFlags('gpt-5');
      expect(gpt5Flags).toEqual(['--model', 'gpt-5']);
    });

    test('OpenCode handler generates correct model flags', () => {
      const handler = providerManager.getHandler('opencode');

      // Test sonnet mapping
      const sonnetFlags = handler.getModelFlags('sonnet');
      expect(sonnetFlags).toEqual(['-m', 'anthropic/claude-sonnet-4-20250514']);

      // Test provider/model format passthrough
      const customFlags = handler.getModelFlags('openai/gpt-4');
      expect(customFlags).toEqual(['-m', 'openai/gpt-4']);
    });
  });
});

describe('API Response Format', () => {
  test('Provider list response matches expected schema', async () => {
    const providerManager = await getProviderManager();
    const providers = providerManager.listProvidersWithMetadata();

    // Simulate API response format
    const response = {
      success: true,
      providers: providers,
      timestamp: new Date().toISOString()
    };

    expect(response.success).toBe(true);
    expect(Array.isArray(response.providers)).toBe(true);
    expect(response.timestamp).toMatch(/^\d{4}-\d{2}-\d{2}T/);

    // Verify provider structure matches API spec
    if (response.providers.length > 0) {
      const provider = response.providers[0];
      expect(typeof provider.id).toBe('string');
      expect(typeof provider.name).toBe('string');
      expect(typeof provider.binary).toBe('string');
      expect(typeof provider.available).toBe('boolean');
      expect(typeof provider.enabled).toBe('boolean');
      expect(typeof provider.current).toBe('boolean');
      expect(typeof provider.modelCount).toBe('number');
    }
  });

  test('Provider models response matches expected schema', async () => {
    const providerManager = await getProviderManager();
    const models = providerManager.getProviderModelsWithPricing('claude');
    const providerInfo = providerManager.getHandlerInfo('claude');

    // Simulate API response format
    const response = {
      success: true,
      providerId: 'claude',
      providerName: providerInfo.name,
      models: models,
      timestamp: new Date().toISOString()
    };

    expect(response.success).toBe(true);
    expect(response.providerId).toBe('claude');
    // Name may vary depending on config merge
    expect(typeof response.providerName).toBe('string');
    expect(Array.isArray(response.models)).toBe(true);

    // Verify model structure matches API spec
    if (response.models.length > 0) {
      const model = response.models[0];
      expect(typeof model.id).toBe('string');
      expect(typeof model.name).toBe('string');
      expect(typeof model.enabled).toBe('boolean');
      expect(typeof model.default).toBe('boolean');
      expect(typeof model.pricing).toBe('object');
      expect(typeof model.pricing.input).toBe('number');
      expect(typeof model.pricing.output).toBe('number');
      expect(typeof model.pricing.cached).toBe('number');
      expect(Array.isArray(model.aliases)).toBe(true);
    }
  });
});

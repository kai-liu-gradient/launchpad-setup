import { jest } from '@jest/globals';

// Mock config and logger before importing notifier base
jest.unstable_mockModule('../src/config.js', () => ({
  config: {
    timezone: 'UTC',
    lark: { hostname: 'test-host' }
  }
}));

jest.unstable_mockModule('../src/logger.js', () => ({
  logger: {
    info: jest.fn(),
    debug: jest.fn(),
    warn: jest.fn(),
    error: jest.fn()
  }
}));

jest.unstable_mockModule('../src/utils/model-normalizer.js', () => ({
  normalizeModelNameLowercase: jest.fn((m) => m)
}));

const { TelegramNotifierBase } = await import('../src/telegram-notifier-base.js');

describe('TelegramNotifierBase - Simple Mode Formatting', () => {
  let notifier;

  beforeEach(() => {
    notifier = new TelegramNotifierBase();
  });

  describe('formatSimpleFooter', () => {
    test('returns task ID in backticks', () => {
      const result = notifier.formatSimpleFooter('ac-0210-B1234');
      expect(result).toBe('\n\n`ac-0210-B1234`');
    });

    test('returns empty string for null taskId', () => {
      const result = notifier.formatSimpleFooter(null);
      expect(result).toBe('');
    });

    test('returns empty string for undefined taskId', () => {
      const result = notifier.formatSimpleFooter(undefined);
      expect(result).toBe('');
    });

    test('returns empty string for empty string taskId', () => {
      const result = notifier.formatSimpleFooter('');
      expect(result).toBe('');
    });
  });

  describe('formatSimpleTaskUpdateMessage', () => {
    const task = { id: 'ac-0210-xyz-B1234', command: 'implement login feature', name: 'Login Feature' };

    test('formats started status with rocket emoji and prompt', () => {
      const result = notifier.formatSimpleTaskUpdateMessage(task, 'started');
      expect(result).toBe('🚀 implement login feature');
    });

    test('formats queued status with hourglass emoji and prompt', () => {
      const result = notifier.formatSimpleTaskUpdateMessage(task, 'queued');
      expect(result).toBe('⏳ implement login feature');
    });

    test('formats unknown status with notepad emoji and prompt', () => {
      const result = notifier.formatSimpleTaskUpdateMessage(task, 'processing');
      expect(result).toBe('📝 implement login feature');
    });

    test('truncates long command to 60 chars', () => {
      const longTask = { id: 'ac-0210-xyz-B1234', command: 'implement a very long feature description that exceeds the sixty character limit for display' };
      const result = notifier.formatSimpleTaskUpdateMessage(longTask, 'started');
      // emoji (2 chars) + space (1) + truncated text (60 chars with "...")
      expect(result.length).toBeLessThanOrEqual(63);
      expect(result).toContain('...');
    });

    test('falls back to task name when no command', () => {
      const noCommandTask = { id: 'ac-0210-xyz-B1234', name: 'My Task' };
      const result = notifier.formatSimpleTaskUpdateMessage(noCommandTask, 'started');
      expect(result).toBe('🚀 My Task');
    });
  });

  describe('formatSimpleTaskSummaryMessage', () => {
    test('formats successful task with output', async () => {
      const task = {
        id: 'ac-0210-xyz-B1234',
        startedAt: 1000,
        completedAt: 155000,
        output: 'Task completed successfully'
      };

      const result = await notifier.formatSimpleTaskSummaryMessage(task, 'success');
      expect(result).toContain('Task completed successfully');
      expect(result).toContain('✅ Done');
      expect(result).toContain('2m 34s');
      // No task ID in simple mode footer
      expect(result).not.toContain('ac-0210-xyz-B1234');
    });

    test('formats error task with error message', async () => {
      const task = {
        id: 'ac-test-B5678',
        startedAt: 0,
        completedAt: 30000,
        output: '',
        error: 'Something went wrong'
      };

      const result = await notifier.formatSimpleTaskSummaryMessage(task, 'error');
      expect(result).toContain('❌ Done');
      expect(result).toContain('30s');
      expect(result).toContain('Something went wrong');
    });

    test('formats cancelled task', async () => {
      const task = {
        id: 'ac-test-B9999',
        startedAt: 0,
        completedAt: 5000,
        output: 'partial output',
        error: 'User cancelled'
      };

      const result = await notifier.formatSimpleTaskSummaryMessage(task, 'cancelled');
      expect(result).toContain('⏹ Done');
      expect(result).toContain('User cancelled');
    });

    test('formats duration in hours when > 60 minutes', async () => {
      const task = {
        id: 'ac-test-B0001',
        startedAt: 0,
        completedAt: 3700000, // 1h 1m 40s
        output: 'done'
      };

      const result = await notifier.formatSimpleTaskSummaryMessage(task, 'success');
      expect(result).toContain('1h 1m');
    });

    test('formats duration in minutes when > 60 seconds', async () => {
      const task = {
        id: 'ac-test-B0002',
        startedAt: 0,
        completedAt: 90000, // 1m 30s
        output: 'done'
      };

      const result = await notifier.formatSimpleTaskSummaryMessage(task, 'success');
      expect(result).toContain('1m 30s');
    });

    test('formats duration in seconds when < 60 seconds', async () => {
      const task = {
        id: 'ac-test-B0003',
        startedAt: 0,
        completedAt: 45000,
        output: 'done'
      };

      const result = await notifier.formatSimpleTaskSummaryMessage(task, 'success');
      expect(result).toContain('45s');
    });

    test('does not wrap plain text output in code block', async () => {
      const longOutput = Array.from({ length: 10 }, (_, i) => `Line ${i + 1}`).join('\n');
      const task = {
        id: 'ac-test-B0004',
        startedAt: 0,
        completedAt: 10000,
        output: longOutput
      };

      const result = await notifier.formatSimpleTaskSummaryMessage(task, 'success');
      expect(result).not.toContain('```');
      expect(result).toContain('Line 1');
      expect(result).toContain('Line 10');
    });

    test('wraps markdown table output in code block', async () => {
      const tableOutput = '| Name | Value |\n|------|-------|\n| foo  | bar   |\n| baz  | qux   |';
      const task = {
        id: 'ac-test-B0004b',
        startedAt: 0,
        completedAt: 10000,
        output: tableOutput
      };

      const result = await notifier.formatSimpleTaskSummaryMessage(task, 'success');
      expect(result).toContain('```');
      expect(result).toContain('foo');
      expect(result).toContain('bar');
    });

    test('wraps output with code fences in code block', async () => {
      const codeOutput = 'Here is the fix:\n```js\nconsole.log("hello")\n```\nDone.';
      const task = {
        id: 'ac-test-B0004c',
        startedAt: 0,
        completedAt: 10000,
        output: codeOutput
      };

      const result = await notifier.formatSimpleTaskSummaryMessage(task, 'success');
      // Should be wrapped — original code fences get cleaned
      expect(result).toContain('```');
    });

    test('sanitizes backticks in output to prevent Telegram parse failure', async () => {
      const outputWithBackticks = 'Run `npm install` then `npm test`\nAlso try ```bash\necho hello\n```';
      const task = {
        id: 'ac-test-B0004d',
        startedAt: 0,
        completedAt: 10000,
        output: outputWithBackticks
      };

      const result = await notifier.formatSimpleTaskSummaryMessage(task, 'success');
      // This output has code fences so looksLikeStructuredContent → true → wrapInCodeBlock
      // The outer ``` fences should be exactly 2, inner backticks sanitized
      const fences = result.match(/```/g);
      expect(fences.length).toBe(2); // only the wrapping fences, inner ones replaced
    });

    test('shows full output without truncation', async () => {
      const longOutput = Array.from({ length: 100 }, (_, i) => `Line ${i + 1}`).join('\n');
      const task = {
        id: 'ac-test-B0005',
        startedAt: 0,
        completedAt: 10000,
        output: longOutput
      };

      const result = await notifier.formatSimpleTaskSummaryMessage(task, 'success');
      expect(result).not.toContain('hidden');
      expect(result).toContain('Line 1');
      expect(result).toContain('Line 50');
      expect(result).toContain('Line 100');
    });

    test('includes pending count when provided', async () => {
      const task = {
        id: 'ac-test-B0006',
        startedAt: 0,
        completedAt: 10000,
        output: 'done'
      };

      const result = await notifier.formatSimpleTaskSummaryMessage(task, 'success', null, null, 3);
      expect(result).toContain('(3 pending)');
    });

    test('does not include pending count when zero', async () => {
      const task = {
        id: 'ac-test-B0007',
        startedAt: 0,
        completedAt: 10000,
        output: 'done'
      };

      const result = await notifier.formatSimpleTaskSummaryMessage(task, 'success', null, null, 0);
      expect(result).not.toContain('pending');
    });

    test('handles empty output', async () => {
      const task = {
        id: 'ac-test-B0008',
        startedAt: 0,
        completedAt: 10000,
        output: ''
      };

      const result = await notifier.formatSimpleTaskSummaryMessage(task, 'success');
      expect(result).toContain('✅ Done');
    });

    test('handles null output', async () => {
      const task = {
        id: 'ac-test-B0009',
        startedAt: 0,
        completedAt: 10000,
        output: null
      };

      const result = await notifier.formatSimpleTaskSummaryMessage(task, 'success');
      expect(result).toContain('✅ Done');
    });

    test('does not include git status in simple mode', async () => {
      const task = {
        id: 'ac-test-B0010',
        startedAt: 0,
        completedAt: 10000,
        output: 'done'
      };

      const result = await notifier.formatSimpleTaskSummaryMessage(task, 'success');
      expect(result).not.toContain('Git Status');
      expect(result).not.toContain('Branch:');
    });

    test('includes cost/token line when usage data provided', async () => {
      const task = {
        id: 'ac-test-B0011',
        startedAt: 0,
        completedAt: 10000,
        output: 'done'
      };
      const taskUsage = {
        cost: 0.0847,
        tokens: 16600,
        inputTokens: 12500,
        outputTokens: 4100,
        cacheReadTokens: 3200
      };

      const result = await notifier.formatSimpleTaskSummaryMessage(task, 'success', taskUsage);
      expect(result).toContain('$0.0847');
      expect(result).toContain('In:');
      expect(result).toContain('Out:');
    });

    test('omits cost/token when no usage data', async () => {
      const task = {
        id: 'ac-test-B0012',
        startedAt: 0,
        completedAt: 10000,
        output: 'done'
      };

      const result = await notifier.formatSimpleTaskSummaryMessage(task, 'success');
      expect(result).not.toContain('$');
      expect(result).not.toContain('In:');
    });
  });

  describe('sanitizeForCodeBlock', () => {
    test('replaces triple backticks with prime characters', () => {
      const result = notifier.sanitizeForCodeBlock('before ```code``` after');
      expect(result).not.toContain('`');
      expect(result).toContain('′′′');
    });

    test('replaces single backticks with prime character', () => {
      const result = notifier.sanitizeForCodeBlock('use `foo` here');
      expect(result).not.toContain('`');
      expect(result).toContain('′foo′');
    });

    test('removes control characters', () => {
      const result = notifier.sanitizeForCodeBlock('hello\x07world');
      expect(result).toBe('helloworld');
    });

    test('normalizes line endings', () => {
      const result = notifier.sanitizeForCodeBlock('line1\r\nline2\rline3');
      expect(result).toBe('line1\nline2\nline3');
    });

    test('handles empty/null input', () => {
      expect(notifier.sanitizeForCodeBlock('')).toBe('');
      expect(notifier.sanitizeForCodeBlock(null)).toBe('');
    });
  });

  describe('wrapInCodeBlock', () => {
    test('wraps text in triple backtick fences', () => {
      const result = notifier.wrapInCodeBlock('hello world');
      expect(result).toBe('```\nhello world\n```');
    });

    test('sanitizes backticks inside the block', () => {
      const result = notifier.wrapInCodeBlock('use `foo` and ```bar```');
      // Must not contain raw backticks between the outer fences
      const inner = result.slice(4, -4); // strip opening "```\n" and "\n```"
      expect(inner).not.toContain('`');
      // Outer fences still intact
      expect(result.startsWith('```\n')).toBe(true);
      expect(result.endsWith('\n```')).toBe(true);
    });

    test('never produces nested code blocks', () => {
      const result = notifier.wrapInCodeBlock('```js\nconsole.log("hi")\n```');
      // Count occurrences of ``` — should only be the outer two
      const fences = result.match(/```/g);
      expect(fences.length).toBe(2);
    });
  });

  describe('renderSimpleOutput', () => {
    test('wraps structured content in code block', () => {
      const table = '| Name | Value |\n|------|-------|\n| foo  | bar   |';
      const result = notifier.renderSimpleOutput(table);
      expect(result).toContain('```');
      expect(result).toContain('foo');
    });

    test('returns escaped plain text without code block', () => {
      const result = notifier.renderSimpleOutput('just plain text');
      expect(result).not.toContain('```');
      expect(result).toContain('just plain text');
    });

    test('sanitizes backticks in structured content', () => {
      const output = '| Col |\n|-----|\n| `val` |';
      const result = notifier.renderSimpleOutput(output);
      // Inner backticks must be replaced, outer fences present
      const fences = result.match(/```/g);
      expect(fences.length).toBe(2); // only the wrapping fences
    });

    test('returns empty string for null/empty', () => {
      expect(notifier.renderSimpleOutput(null)).toBe('');
      expect(notifier.renderSimpleOutput('')).toBe('');
      expect(notifier.renderSimpleOutput('   ')).toBe('');
    });
  });

  describe('looksLikeStructuredContent', () => {
    test('detects markdown tables', () => {
      const table = '| Name | Value |\n|------|-------|\n| foo  | bar   |';
      expect(notifier.looksLikeStructuredContent(table)).toBe(true);
    });

    test('detects code fences', () => {
      expect(notifier.looksLikeStructuredContent('text\n```js\ncode\n```')).toBe(true);
    });

    test('detects HTML tags', () => {
      expect(notifier.looksLikeStructuredContent('<div>hello</div>')).toBe(true);
    });

    test('detects column-aligned data', () => {
      const aligned = 'Name    Age    City\nJohn    30     NYC\nJane    25     LA\nBob     40     SF';
      expect(notifier.looksLikeStructuredContent(aligned)).toBe(true);
    });

    test('returns false for plain text', () => {
      expect(notifier.looksLikeStructuredContent('just some plain text')).toBe(false);
    });

    test('returns false for simple multi-line text', () => {
      expect(notifier.looksLikeStructuredContent('line 1\nline 2\nline 3')).toBe(false);
    });

    test('returns false for null/empty', () => {
      expect(notifier.looksLikeStructuredContent(null)).toBe(false);
      expect(notifier.looksLikeStructuredContent('')).toBe(false);
    });
  });
});

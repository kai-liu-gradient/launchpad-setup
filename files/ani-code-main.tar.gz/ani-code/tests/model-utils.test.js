import { describe, it, expect, jest } from '@jest/globals';
import {
  VALID_MODELS,
  MODEL_FLAGS,
  isValidModel,
  normalizeModel,
  getModelFlags,
  extractModelFromPrompt,
  extractProviderFromPrompt,
  stripPatternsFromPrompt,
  getModelPreference,
  createInvalidModelError
} from '../src/model-utils.js';

describe('Model Utils', () => {
  describe('Constants', () => {
    it('should export VALID_MODELS', () => {
      expect(VALID_MODELS).toBeDefined();
      expect(VALID_MODELS.SONNET).toBe('sonnet');
      expect(VALID_MODELS.OPUS).toBe('opus');
    });

    it('should export MODEL_FLAGS', () => {
      expect(MODEL_FLAGS).toBeDefined();
      expect(MODEL_FLAGS[VALID_MODELS.SONNET]).toBe('--model');
      expect(MODEL_FLAGS[VALID_MODELS.OPUS]).toBe('--model');
    });
  });

  describe('isValidModel', () => {
    it('should return true for valid models', () => {
      expect(isValidModel('sonnet')).toBe(true);
      expect(isValidModel('opus')).toBe(true);
      expect(isValidModel('SONNET')).toBe(true);
      expect(isValidModel('OPUS')).toBe(true);
    });

    it('should return false for invalid models', () => {
      expect(isValidModel('invalid')).toBe(false);
      expect(isValidModel('claude')).toBe(false);
      expect(isValidModel('gpt')).toBe(false);
    });

    it('should return false for null or undefined', () => {
      expect(isValidModel(null)).toBe(false);
      expect(isValidModel(undefined)).toBe(false);
    });

    it('should return false for empty string', () => {
      expect(isValidModel('')).toBe(false);
    });

    it('should be case insensitive', () => {
      expect(isValidModel('SoNnEt')).toBe(true);
      expect(isValidModel('OpUs')).toBe(true);
    });
  });

  describe('normalizeModel', () => {
    it('should normalize valid models to lowercase', () => {
      expect(normalizeModel('SONNET')).toBe('sonnet');
      expect(normalizeModel('Opus')).toBe('opus');
      expect(normalizeModel('sonnet')).toBe('sonnet');
    });

    it('should return null for invalid models', () => {
      expect(normalizeModel('invalid')).toBeNull();
      expect(normalizeModel('gpt')).toBeNull();
    });

    it('should return null for null or undefined', () => {
      expect(normalizeModel(null)).toBeNull();
      expect(normalizeModel(undefined)).toBeNull();
    });

    it('should return null for empty string', () => {
      expect(normalizeModel('')).toBeNull();
    });

    it('should handle mixed case input', () => {
      expect(normalizeModel('SoNnEt')).toBe('sonnet');
      expect(normalizeModel('OpUs')).toBe('opus');
    });
  });

  describe('getModelFlags', () => {
    it('should return correct flags for valid models', () => {
      expect(getModelFlags('sonnet')).toEqual(['--model', 'sonnet']);
      expect(getModelFlags('opus')).toEqual(['--model', 'opus']);
    });

    it('should return empty array for invalid models', () => {
      expect(getModelFlags('invalid')).toEqual([]);
      expect(getModelFlags('gpt')).toEqual([]);
    });

    it('should return empty array for null or undefined', () => {
      expect(getModelFlags(null)).toEqual([]);
      expect(getModelFlags(undefined)).toEqual([]);
    });

    it('should normalize model names before generating flags', () => {
      expect(getModelFlags('SONNET')).toEqual(['--model', 'sonnet']);
      expect(getModelFlags('Opus')).toEqual(['--model', 'opus']);
    });

    it('should handle empty string', () => {
      expect(getModelFlags('')).toEqual([]);
    });
  });

  describe('extractModelFromPrompt', () => {
    it('should extract @@opus from prompt', () => {
      expect(extractModelFromPrompt('Use @@opus for this task')).toBe('opus');
      expect(extractModelFromPrompt('@@opus please help')).toBe('opus');
      expect(extractModelFromPrompt('Complete task @@opus')).toBe('opus');
    });

    it('should extract @@sonnet from prompt', () => {
      expect(extractModelFromPrompt('Use @@sonnet for this')).toBe('sonnet');
      expect(extractModelFromPrompt('@@sonnet analyze code')).toBe('sonnet');
      expect(extractModelFromPrompt('Help me @@sonnet')).toBe('sonnet');
    });

    it('should return null when no model pattern found', () => {
      expect(extractModelFromPrompt('Regular prompt text')).toBeNull();
      expect(extractModelFromPrompt('Use claude model')).toBeNull();
    });

    it('should return null for null or undefined', () => {
      expect(extractModelFromPrompt(null)).toBeNull();
      expect(extractModelFromPrompt(undefined)).toBeNull();
    });

    it('should return null for non-string input', () => {
      expect(extractModelFromPrompt(123)).toBeNull();
      expect(extractModelFromPrompt({})).toBeNull();
      expect(extractModelFromPrompt([])).toBeNull();
    });

    it('should prioritize opus over sonnet if both present', () => {
      const result = extractModelFromPrompt('Use @@opus or @@sonnet');
      expect(result).toBe('opus');
    });

    it('should handle model patterns in different positions', () => {
      expect(extractModelFromPrompt('@@sonnet at start')).toBe('sonnet');
      expect(extractModelFromPrompt('in middle @@opus here')).toBe('opus');
      expect(extractModelFromPrompt('at end @@sonnet')).toBe('sonnet');
    });

    it('should not match partial patterns', () => {
      expect(extractModelFromPrompt('Use @opus')).toBeNull();
      expect(extractModelFromPrompt('Use opus@@')).toBeNull();
    });

    it('should handle multiple same patterns', () => {
      expect(extractModelFromPrompt('@@opus @@opus @@opus')).toBe('opus');
    });
  });

  describe('extractProviderFromPrompt', () => {
    it('should extract provider patterns', () => {
      expect(extractProviderFromPrompt('Use @@codex for this')).toBe('codex');
      expect(extractProviderFromPrompt('Try @@cursor here')).toBe('cursor');
      expect(extractProviderFromPrompt('@@gemini please help')).toBe('gemini');
    });

    it('should skip model patterns (opus, sonnet)', () => {
      expect(extractProviderFromPrompt('Use @@opus model')).toBeNull();
      expect(extractProviderFromPrompt('Use @@sonnet model')).toBeNull();
    });

    it('should return first valid provider when validProviders list provided', () => {
      const validProviders = ['codex', 'cursor', 'gemini'];
      expect(extractProviderFromPrompt('@@codex task', validProviders)).toBe('codex');
      expect(extractProviderFromPrompt('@@invalid task', validProviders)).toBeNull();
    });

    it('should return null for invalid input', () => {
      expect(extractProviderFromPrompt(null)).toBeNull();
      expect(extractProviderFromPrompt(undefined)).toBeNull();
      expect(extractProviderFromPrompt(123)).toBeNull();
    });

    it('should handle provider with hyphens', () => {
      expect(extractProviderFromPrompt('Use @@my-provider')).toBe('my-provider');
    });

    it('should handle provider with numbers', () => {
      expect(extractProviderFromPrompt('Use @@provider2')).toBe('provider2');
    });

    it('should be case insensitive', () => {
      expect(extractProviderFromPrompt('Use @@CODEX')).toBe('codex');
      expect(extractProviderFromPrompt('Use @@Cursor')).toBe('cursor');
    });

    it('should skip providers not in validProviders list', () => {
      const validProviders = ['codex', 'cursor'];
      expect(extractProviderFromPrompt('@@gemini task', validProviders)).toBeNull();
    });

    it('should return first valid provider when multiple present', () => {
      const validProviders = ['codex', 'cursor'];
      const result = extractProviderFromPrompt('@@codex and @@cursor', validProviders);
      expect(result).toBe('codex');
    });
  });

  describe('stripPatternsFromPrompt', () => {
    it('should strip model patterns', () => {
      expect(stripPatternsFromPrompt('Use @@opus for this')).toBe('Use for this');
      expect(stripPatternsFromPrompt('Use @@sonnet here')).toBe('Use here');
    });

    it('should strip provider patterns', () => {
      expect(stripPatternsFromPrompt('Use @@codex for this')).toBe('Use for this');
      expect(stripPatternsFromPrompt('Try @@cursor here')).toBe('Try here');
    });

    it('should strip multiple patterns', () => {
      expect(stripPatternsFromPrompt('@@opus @@codex task')).toBe('task');
      expect(stripPatternsFromPrompt('Use @@sonnet and @@cursor')).toBe('Use and');
    });

    it('should normalize extra spaces without removing indentation', () => {
      expect(stripPatternsFromPrompt('Use  @@opus   for   this')).toBe('Use for this');
      expect(stripPatternsFromPrompt('@@sonnet  task')).toBe('task');
      expect(stripPatternsFromPrompt('  - @@opus  Step')).toBe('  - Step');
    });

    it('should handle prompt without patterns', () => {
      expect(stripPatternsFromPrompt('Regular prompt')).toBe('Regular prompt');
    });

    it('should return original for null or undefined', () => {
      expect(stripPatternsFromPrompt(null)).toBeNull();
      expect(stripPatternsFromPrompt(undefined)).toBeUndefined();
    });

    it('should handle empty string', () => {
      expect(stripPatternsFromPrompt('')).toBe('');
    });

    it('should handle patterns with hyphens', () => {
      expect(stripPatternsFromPrompt('Use @@my-provider task')).toBe('Use task');
    });

    it('should handle patterns with numbers', () => {
      expect(stripPatternsFromPrompt('Use @@provider2 task')).toBe('Use task');
    });

    it('should preserve newline formatting', () => {
      const input = 'Use   @@opus\n\n  for  this\n  task list:\n    - a\n    - b';
      const result = stripPatternsFromPrompt(input);
      expect(result).toContain('\n\n  for this');
      expect(result).toContain('\n  task list:');
      expect(result).toContain('\n    - a');
    });
  });

  describe('getModelPreference', () => {
    it('should return task model if present', async () => {
      const task = { model: 'opus', command: 'test', cwd: '/test' };
      const result = await getModelPreference(task, null);
      expect(result.model).toBe('opus');
      expect(result.source).toBe('task');
    });

    it('should normalize task model', async () => {
      const task = { model: 'OPUS', command: 'test' };
      const result = await getModelPreference(task, null);
      expect(result.model).toBe('opus');
      expect(result.source).toBe('task');
    });

    it('should return null for invalid task model', async () => {
      const task = { model: 'invalid', command: 'test' };
      const result = await getModelPreference(task, null);
      expect(result.model).toBeNull();
      expect(result.source).toBeNull();
    });

    it('should check prompt for model pattern if no task model', async () => {
      const task = { command: 'Use @@opus for this' };
      const result = await getModelPreference(task, null);
      expect(result.model).toBe('opus');
      expect(result.source).toBe('prompt');
    });

    it('should check task name for model pattern', async () => {
      const task = { command: 'test', name: 'Task with @@sonnet' };
      const result = await getModelPreference(task, null);
      expect(result.model).toBe('sonnet');
      expect(result.source).toBe('prompt');
    });

    it('should prioritize command over name for prompt patterns', async () => {
      const task = {
        command: 'Use @@opus',
        name: 'Task with @@sonnet'
      };
      const result = await getModelPreference(task, null);
      expect(result.model).toBe('opus');
    });

    it('should return null when no preference found', async () => {
      const task = { command: 'Regular task' };
      const result = await getModelPreference(task, null);
      expect(result.model).toBeNull();
      expect(result.source).toBeNull();
    });

    it('should handle workspace model preference', async () => {
      const task = { command: 'test', cwd: '/workspace' };
      const mockWorkspaceManager = {
        getWorkspaceByPath: jest.fn().mockResolvedValue({
          settings: { model: 'opus' }
        })
      };
      const result = await getModelPreference(task, mockWorkspaceManager);
      expect(result.model).toBe('opus');
      expect(result.source).toBe('workspace');
    });

    it('should prioritize task model over workspace model', async () => {
      const task = { model: 'sonnet', command: 'test', cwd: '/workspace' };
      const mockWorkspaceManager = {
        getWorkspaceByPath: jest.fn().mockResolvedValue({
          settings: { model: 'opus' }
        })
      };
      const result = await getModelPreference(task, mockWorkspaceManager);
      expect(result.model).toBe('sonnet');
      expect(result.source).toBe('task');
    });

    it('should handle workspace lookup failure gracefully', async () => {
      const task = { command: 'test', cwd: '/workspace' };
      const mockWorkspaceManager = {
        getWorkspaceByPath: jest.fn().mockRejectedValue(new Error('Failed'))
      };
      const result = await getModelPreference(task, mockWorkspaceManager);
      expect(result.model).toBeNull();
    });

    it('should handle workspace without model setting', async () => {
      const task = { command: 'test', cwd: '/workspace' };
      const mockWorkspaceManager = {
        getWorkspaceByPath: jest.fn().mockResolvedValue({
          settings: {}
        })
      };
      const result = await getModelPreference(task, mockWorkspaceManager);
      expect(result.model).toBeNull();
    });
  });

  describe('createInvalidModelError', () => {
    it('should create error with model name', () => {
      const error = createInvalidModelError('invalid');
      expect(error).toBeInstanceOf(Error);
      expect(error.message).toContain('invalid');
    });

    it('should list valid models in error message', () => {
      const error = createInvalidModelError('gpt');
      expect(error.message).toContain('sonnet');
      expect(error.message).toContain('opus');
    });

    it('should have proper error format', () => {
      const error = createInvalidModelError('test');
      expect(error.message).toMatch(/Invalid model/);
      expect(error.message).toMatch(/Valid models are:/);
    });
  });

  describe('Integration Scenarios', () => {
    it('should handle complete workflow with task model', async () => {
      const task = { model: 'opus', command: 'Build the app' };
      const preference = await getModelPreference(task, null);
      const flags = getModelFlags(preference.model);

      expect(preference.model).toBe('opus');
      expect(flags).toEqual(['--model', 'opus']);
    });

    it('should handle complete workflow with prompt model', async () => {
      const task = { command: 'Build the app @@sonnet' };
      const preference = await getModelPreference(task, null);
      const cleanedCommand = stripPatternsFromPrompt(task.command);
      const flags = getModelFlags(preference.model);

      expect(preference.model).toBe('sonnet');
      expect(cleanedCommand).toBe('Build the app');
      expect(flags).toEqual(['--model', 'sonnet']);
    });

    it('should validate model before using', () => {
      const userInput = 'OPUS';
      const normalized = normalizeModel(userInput);
      if (normalized) {
        const flags = getModelFlags(normalized);
        expect(flags).toEqual(['--model', 'opus']);
      }
    });

    it('should handle invalid model gracefully', () => {
      const userInput = 'invalid-model';
      const normalized = normalizeModel(userInput);
      expect(normalized).toBeNull();

      if (!normalized) {
        const error = createInvalidModelError(userInput);
        expect(error.message).toContain('invalid-model');
      }
    });
  });
});

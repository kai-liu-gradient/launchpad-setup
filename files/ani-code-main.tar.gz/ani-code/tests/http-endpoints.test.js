import { jest } from '@jest/globals';
import http from 'http';

/**
 * HTTP Endpoints Test Suite
 * Tests for /api/task and /health endpoints with API key validation and rate limiting
 */

describe('HTTP Endpoints', () => {
  let server;
  let apiHandlers;
  let taskMonitor;
  let config;
  const TEST_PORT = 16502;
  const BASE_URL = `http://localhost:${TEST_PORT}`;

  beforeAll(async () => {
    // Set up test environment
    process.env.GATEWAY_API_KEY = 'test-api-key-12345';
    process.env.WORKSPACE_ID = 'test-workspace';
    process.env.PROJECT_ID = 'test-project';
    process.env.GATEWAY_URL = 'http://gateway.test.com';
    process.env.HTTP_CALLBACK_PORT = TEST_PORT.toString();

    // Import config to apply env vars
    const configModule = await import('../src/config.js');
    config = configModule.config;

    // Import APIHandlers
    const apiHandlersModule = await import('../src/api-handlers.js');
    const APIHandlers = apiHandlersModule.APIHandlers;

    // Mock task monitor
    taskMonitor = {
      addTask: jest.fn((name, command, options) => ({
        id: 'task-' + Date.now(),
        name,
        command,
        status: 'pending',
        workspace: options.workspace || 'default',
        ...options
      })),
      getTaskById: jest.fn(),
      getQueuePosition: jest.fn(() => 0),
      getAllTasks: jest.fn(() => []),
      getActiveTasksCount: jest.fn(() => 0),
      getQueuedTasksCount: jest.fn(() => 0),
      getTotalTasksCount: jest.fn(() => 0),
      getCompletedTasksCount: jest.fn(() => 0),
      getFailedTasksCount: jest.fn(() => 0)
    };

    // Create API handlers instance
    apiHandlers = new APIHandlers(taskMonitor);

    // Create simple HTTP server for testing
    server = http.createServer(async (req, res) => {
      // Parse URL
      const url = new URL(req.url, BASE_URL);

      // Handle /api/* endpoints via APIHandlers
      if (url.pathname.startsWith('/api/')) {
        await apiHandlers.handleAPIRequest(req, res, url.pathname);
        return;
      }

      // Handle /health endpoint
      if (url.pathname === '/health' && req.method === 'GET') {
        const healthStatus = {
          status: 'healthy',
          uptime: process.uptime(),
          tasks: {
            active: taskMonitor.getActiveTasksCount(),
            queued: taskMonitor.getQueuedTasksCount(),
            total: taskMonitor.getTotalTasksCount(),
            completed: taskMonitor.getCompletedTasksCount(),
            failed: taskMonitor.getFailedTasksCount()
          },
          gateway: {
            connected: false,
            lastHeartbeat: null,
            registeredAt: null
          },
          resources: {
            cpuUsage: 0,
            memoryUsage: 0,
            diskUsage: 0
          },
          timestamp: new Date().toISOString()
        };

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(healthStatus));
        return;
      }

      // 404 for other routes
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Not found' }));
    });

    await new Promise((resolve) => {
      server.listen(TEST_PORT, resolve);
    });
  });

  afterAll(async () => {
    if (server) {
      await new Promise((resolve) => {
        server.close(resolve);
      });
    }
  });

  beforeEach(() => {
    // Reset mocks
    jest.clearAllMocks();

    // Clear rate limit state
    apiHandlers.rateLimitMap.clear();
  });

  describe('POST /api/task', () => {
    test('should accept valid task with API key', async () => {
      const payload = {
        taskId: 'task-uuid-123',
        command: 'Fix the bug in auth module',
        data: {
          context: {
            files: { 'src/auth.js': 'const auth = {}' }
          },
          userId: 'user-123',
          projectId: 'test-project',
          workspaceId: 'test-workspace'
        },
        source: 'gateway',
        priority: 'normal'
      };

      const response = await fetch(`${BASE_URL}/api/task`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-API-Key': 'test-api-key-12345'
        },
        body: JSON.stringify(payload)
      });

      expect(response.status).toBe(201);
      const data = await response.json();
      expect(data.success).toBe(true);
      expect(data.taskId).toBeDefined();
      expect(data.status).toBe('pending');
      expect(taskMonitor.addTask).toHaveBeenCalledTimes(1);
    });

    test('should reject request with missing required fields', async () => {
      const payload = {
        // Missing taskId and command
        data: {
          workspaceId: 'test-workspace'
        }
      };

      const response = await fetch(`${BASE_URL}/api/task`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-API-Key': 'test-api-key-12345'
        },
        body: JSON.stringify(payload)
      });

      expect(response.status).toBe(400);
      const data = await response.json();
      expect(data.success).toBe(false);
      expect(data.error).toContain('required');
      expect(taskMonitor.addTask).not.toHaveBeenCalled();
    });

    test('should reject request with invalid API key', async () => {
      const response = await fetch(`${BASE_URL}/api/task`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-API-Key': 'invalid-key'
        },
        body: JSON.stringify({
          command: 'echo test',
          workspace: 'test-workspace'
        })
      });

      expect(response.status).toBe(401);
      const data = await response.json();
      expect(data.success).toBe(false);
      expect(data.error).toContain('Invalid API key');
      expect(taskMonitor.addTask).not.toHaveBeenCalled();
    });

    test('should reject request with missing API key', async () => {
      const payload = {
        taskId: 'task-uuid-123',
        command: 'Fix the bug',
        data: {
          workspaceId: 'test-workspace'
        }
      };

      const response = await fetch(`${BASE_URL}/api/task`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
          // Missing X-API-Key header
        },
        body: JSON.stringify(payload)
      });

      expect(response.status).toBe(401);
      const data = await response.json();
      expect(data.success).toBe(false);
      expect(taskMonitor.addTask).not.toHaveBeenCalled();
    });

    test('should enforce rate limiting (10 req/min)', async () => {
      const payload = {
        taskId: 'task-uuid',
        command: 'Test task',
        data: {
          workspaceId: 'test-workspace'
        }
      };

      // Send 10 requests (should all succeed)
      for (let i = 0; i < 10; i++) {
        const response = await fetch(`${BASE_URL}/api/task`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-API-Key': 'test-api-key-12345'
          },
          body: JSON.stringify({ ...payload, taskId: `task-${i}` })
        });
        expect(response.status).toBe(201);
      }

      // 11th request should be rate limited
      const rateLimitedResponse = await fetch(`${BASE_URL}/api/task`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-API-Key': 'test-api-key-12345'
        },
        body: JSON.stringify({ ...payload, taskId: 'task-11' })
      });

      expect(rateLimitedResponse.status).toBe(429);
      const data = await rateLimitedResponse.json();
      expect(data.error).toContain('Rate limit');
      expect(rateLimitedResponse.headers.get('Retry-After')).toBeDefined();
    });

    test('should validate command length', async () => {
      const longCommand = 'a'.repeat(11000); // > 10KB
      const payload = {
        taskId: 'task-uuid-123',
        command: longCommand,
        data: {
          workspaceId: 'test-workspace'
        }
      };

      const response = await fetch(`${BASE_URL}/api/task`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-API-Key': 'test-api-key-12345'
        },
        body: JSON.stringify(payload)
      });

      // Should reject commands that are too long
      // Implementation may vary - adjust assertion based on actual behavior
      expect([400, 413]).toContain(response.status);
    });

    test('should reject malformed JSON', async () => {
      const response = await fetch(`${BASE_URL}/api/task`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-API-Key': 'test-api-key-12345'
        },
        body: 'invalid json {'
      });

      expect(response.status).toBe(400);
      const data = await response.json();
      expect(data.error).toContain('JSON');
    });
  });

  describe('GET /health', () => {
    test('should return health status with correct format', async () => {
      const response = await fetch(`${BASE_URL}/health`);

      expect(response.status).toBe(200);
      const data = await response.json();

      // Verify structure
      expect(data).toHaveProperty('status');
      expect(data).toHaveProperty('uptime');
      expect(data).toHaveProperty('tasks');
      expect(data).toHaveProperty('gateway');
      expect(data).toHaveProperty('resources');
      expect(data).toHaveProperty('timestamp');

      // Verify tasks object
      expect(data.tasks).toHaveProperty('active');
      expect(data.tasks).toHaveProperty('queued');
      expect(data.tasks).toHaveProperty('total');
      expect(data.tasks).toHaveProperty('completed');
      expect(data.tasks).toHaveProperty('failed');

      // Verify gateway object
      expect(data.gateway).toHaveProperty('connected');
      expect(data.gateway).toHaveProperty('lastHeartbeat');
      expect(data.gateway).toHaveProperty('registeredAt');

      // Verify resources object
      expect(data.resources).toHaveProperty('cpuUsage');
      expect(data.resources).toHaveProperty('memoryUsage');
      expect(data.resources).toHaveProperty('diskUsage');
    });

    test('should return healthy status when queue is low', async () => {
      // Mock low queue
      taskMonitor.getQueuedTasksCount.mockReturnValue(5);

      const response = await fetch(`${BASE_URL}/health`);
      const data = await response.json();

      expect(response.status).toBe(200);
      expect(data.status).toBe('healthy');
    });

    test('should include correct task counts', async () => {
      taskMonitor.getActiveTasksCount.mockReturnValue(2);
      taskMonitor.getQueuedTasksCount.mockReturnValue(3);
      taskMonitor.getTotalTasksCount.mockReturnValue(100);
      taskMonitor.getCompletedTasksCount.mockReturnValue(90);
      taskMonitor.getFailedTasksCount.mockReturnValue(5);

      const response = await fetch(`${BASE_URL}/health`);
      const data = await response.json();

      expect(data.tasks.active).toBe(2);
      expect(data.tasks.queued).toBe(3);
      expect(data.tasks.total).toBe(100);
      expect(data.tasks.completed).toBe(90);
      expect(data.tasks.failed).toBe(5);
    });

    test('should include valid timestamp', async () => {
      const response = await fetch(`${BASE_URL}/health`);
      const data = await response.json();

      const timestamp = new Date(data.timestamp);
      expect(timestamp.toString()).not.toBe('Invalid Date');

      // Timestamp should be recent (within last 5 seconds)
      const now = new Date();
      const diff = Math.abs(now - timestamp);
      expect(diff).toBeLessThan(5000);
    });
  });
});

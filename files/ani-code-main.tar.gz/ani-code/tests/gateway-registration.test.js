import { jest, describe, it, beforeEach, afterEach, expect } from '@jest/globals';
import { AniCodeDaemon } from '../src/daemon.js';
import { config } from '../src/config.js';

describe('Gateway Instance Registration', () => {
  let daemon;
  let originalGatewayConfig;
  let originalFetch;
  let originalGatewayToken;

  beforeEach(() => {
    // Save original config, fetch and env
    originalGatewayConfig = { ...config.gateway };
    originalFetch = global.fetch;
    originalGatewayToken = process.env.GATEWAY_TOKEN;

    // Enable gateway mode for tests
    config.gateway.enabled = true;
    config.gateway.url = 'http://test-gateway:6555';
    process.env.GATEWAY_TOKEN = 'test-secure-token';
    config.gateway.instanceId = 'test-instance';
    config.gateway.registerOnStartup = true;

    // Create daemon instance (but don't start it)
    daemon = new AniCodeDaemon();
  });

  afterEach(() => {
    // Restore original config (excluding read-only token getter)
    const { token, ...rest } = originalGatewayConfig;
    Object.assign(config.gateway, rest);
    global.fetch = originalFetch;
    if (originalGatewayToken === undefined) {
      delete process.env.GATEWAY_TOKEN;
    } else {
      process.env.GATEWAY_TOKEN = originalGatewayToken;
    }
  });

  it('should register with gateway on startup', async () => {
    let capturedRequest = null;

    global.fetch = jest.fn().mockImplementation(async (url, options) => {
      capturedRequest = { url, options };
      return {
        ok: true,
        json: async () => ({
          registered: true,
          instanceId: 'test-instance'
        })
      };
    });

    await daemon.registerWithGateway();

    expect(capturedRequest).toBeTruthy();
    expect(capturedRequest.url).toBe('http://test-gateway:6555/api/instances/register');
  });

  it('should include instance information in registration', async () => {
    let capturedPayload = null;

    global.fetch = jest.fn().mockImplementation(async (url, options) => {
      capturedPayload = JSON.parse(options.body);
      return {
        ok: true,
        json: async () => ({ registered: true })
      };
    });

    await daemon.registerWithGateway();

    expect(capturedPayload).toBeTruthy();
    expect(capturedPayload.instanceId).toBe('test-instance');
    expect(capturedPayload.token).toBe('test-secure-token');
    expect(Array.isArray(capturedPayload.capabilities)).toBe(true);
    expect(capturedPayload.endpoint).toBeTruthy();
    expect(capturedPayload.version).toBeTruthy();
    expect(capturedPayload.hostname).toBeTruthy();
  });

  it('should detect capabilities based on configuration', async () => {
    let capturedPayload = null;

    // Configure telegram and lark
    config.telegram.botToken = 'test-token';
    config.lark.appId = 'test-app-id';

    global.fetch = jest.fn().mockImplementation(async (url, options) => {
      capturedPayload = JSON.parse(options.body);
      return {
        ok: true,
        json: async () => ({ registered: true })
      };
    });

    await daemon.registerWithGateway();

    expect(capturedPayload.capabilities).toContain('telegram');
    expect(capturedPayload.capabilities).toContain('lark');
    expect(capturedPayload.capabilities).toContain('cli');
  });

  it('should skip registration when gateway mode disabled', async () => {
    config.gateway.enabled = false;

    let registrationCalled = false;
    global.fetch = jest.fn().mockImplementation(async () => {
      registrationCalled = true;
      return {
        ok: true,
        json: async () => ({ registered: true })
      };
    });

    await daemon.registerWithGateway();

    expect(registrationCalled).toBe(false);
  });

  it('should skip registration when registerOnStartup is false', async () => {
    config.gateway.registerOnStartup = false;

    let registrationCalled = false;
    global.fetch = jest.fn().mockImplementation(async () => {
      registrationCalled = true;
      return {
        ok: true,
        json: async () => ({ registered: true })
      };
    });

    await daemon.registerWithGateway();

    expect(registrationCalled).toBe(false);
  });

  it('should continue without registration on failure', async () => {
    global.fetch = jest.fn().mockImplementation(async () => {
      throw new Error('Gateway unavailable');
    });

    // Should not throw, should continue gracefully
    await daemon.registerWithGateway();
    expect(true).toBe(true);
  });

  it('should handle non-OK HTTP response', async () => {
    global.fetch = jest.fn().mockImplementation(async () => ({
      ok: false,
      status: 500,
      text: async () => 'Internal Server Error'
    }));

    // Should not throw
    await daemon.registerWithGateway();
    expect(true).toBe(true);
  });

  it('should include authentication headers', async () => {
    let capturedHeaders = null;

    global.fetch = jest.fn().mockImplementation(async (url, options) => {
      capturedHeaders = options.headers;
      return {
        ok: true,
        json: async () => ({ registered: true })
      };
    });

    await daemon.registerWithGateway();

    expect(capturedHeaders['Content-Type']).toBe('application/json');
    expect(capturedHeaders['x-api-key']).toBe('test-secure-token');
  });

  it('should use configured instance ID', async () => {
    config.gateway.instanceId = 'custom-instance-123';

    let capturedPayload = null;
    global.fetch = jest.fn().mockImplementation(async (url, options) => {
      capturedPayload = JSON.parse(options.body);
      return {
        ok: true,
        json: async () => ({ registered: true })
      };
    });

    await daemon.registerWithGateway();

    expect(capturedPayload.instanceId).toBe('custom-instance-123');
  });

  it('should include endpoint with correct port', async () => {
    config.http.port = 6501;

    let capturedPayload = null;
    global.fetch = jest.fn().mockImplementation(async (url, options) => {
      capturedPayload = JSON.parse(options.body);
      return {
        ok: true,
        json: async () => ({ registered: true })
      };
    });

    await daemon.registerWithGateway();

    expect(capturedPayload.endpoint).toContain(':6501');
  });

  it('should handle timeout gracefully', async () => {
    global.fetch = jest.fn().mockImplementation(async () => {
      // Simulate timeout by waiting longer than timeout value
      await new Promise(resolve => setTimeout(resolve, 1100)); // Reduced for test speed
      throw new Error('Timeout');
    });

    // Should not throw, should continue
    await daemon.registerWithGateway();
    expect(true).toBe(true);
  });

  it('should parse and include version from package.json', async () => {
    let capturedPayload = null;

    global.fetch = jest.fn().mockImplementation(async (url, options) => {
      capturedPayload = JSON.parse(options.body);
      return {
        ok: true,
        json: async () => ({ registered: true })
      };
    });

    await daemon.registerWithGateway();

    expect(capturedPayload.version).toBeTruthy();
    expect(capturedPayload.version).toMatch(/^\d+\.\d+\.\d+/);
  });

  it('should include workspaces from lark config', async () => {
    config.lark.workdirs = {
      'workspace1': '/path/to/workspace1',
      'workspace2': '/path/to/workspace2'
    };

    let capturedPayload = null;
    global.fetch = jest.fn().mockImplementation(async (url, options) => {
      capturedPayload = JSON.parse(options.body);
      return {
        ok: true,
        json: async () => ({ registered: true })
      };
    });

    await daemon.registerWithGateway();

    expect(Array.isArray(capturedPayload.workspaces)).toBe(true);
    expect(capturedPayload.workspaces).toContain('workspace1');
    expect(capturedPayload.workspaces).toContain('workspace2');
  });
});

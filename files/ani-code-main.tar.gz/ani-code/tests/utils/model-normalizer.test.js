import { jest } from '@jest/globals';
import { normalizeModelName, normalizeModelNameLowercase } from '../../src/utils/model-normalizer.js';

describe('Model Normalizer', () => {
  describe('normalizeModelName', () => {
    test('should normalize Sonnet 4.5 model name', () => {
      const input = 'claude-sonnet-4-5-20250929';
      const result = normalizeModelName(input);
      expect(result).toBe('Sonnet-4.5');
    });

    test('should normalize Opus 4.1 model name', () => {
      const input = 'claude-opus-4-1-20250805';
      const result = normalizeModelName(input);
      expect(result).toBe('Opus-4.1');
    });

    test('should normalize Sonnet 3.5 model name', () => {
      const input = 'claude-sonnet-3-5-20240620';
      const result = normalizeModelName(input);
      expect(result).toBe('Sonnet-3.5');
    });

    test('should normalize Haiku 3.5 model name', () => {
      const input = 'claude-haiku-3-5-20240307';
      const result = normalizeModelName(input);
      expect(result).toBe('Haiku-3.5');
    });

    test('should normalize Haiku 3.0 model name (no minor version)', () => {
      const input = 'claude-haiku-3-20240307';
      const result = normalizeModelName(input);
      expect(result).toBe('Haiku-3');
    });

    test('should handle model names without dates', () => {
      const input = 'claude-sonnet-4-5';
      const result = normalizeModelName(input);
      expect(result).toBe('Sonnet-4.5');
    });

    test('should return original if not a Claude model', () => {
      const input = 'gpt-4-turbo';
      const result = normalizeModelName(input);
      expect(result).toBe('gpt-4-turbo');
    });

    test('should return original if model format is invalid', () => {
      const input = 'claude-invalid';
      const result = normalizeModelName(input);
      expect(result).toBe('claude-invalid');
    });

    test('should handle null input', () => {
      const result = normalizeModelName(null);
      expect(result).toBeNull();
    });

    test('should handle undefined input', () => {
      const result = normalizeModelName(undefined);
      expect(result).toBeUndefined();
    });

    test('should handle non-string input', () => {
      const result = normalizeModelName(12345);
      expect(result).toBe(12345);
    });

    test('should handle empty string', () => {
      const result = normalizeModelName('');
      expect(result).toBe('');
    });

    test('should capitalize family name correctly', () => {
      const input = 'claude-opus-4-1-20250805';
      const result = normalizeModelName(input);
      expect(result).toMatch(/^Opus-/);
    });

    test('should handle edge case with multiple version numbers', () => {
      const input = 'claude-sonnet-4-5-1-20250929';
      const result = normalizeModelName(input);
      // Should only take first two version numbers
      expect(result).toBe('Sonnet-4.5');
    });

    test('should handle model names with only major version', () => {
      const input = 'claude-opus-4-20250805';
      const result = normalizeModelName(input);
      expect(result).toBe('Opus-4');
    });

    test('should capitalize family name (not preserve case)', () => {
      const input = 'claude-SoNnEt-4-5-20250929';
      const result = normalizeModelName(input);
      // The function capitalizes first letter only, preserving rest of case
      expect(result).toBe('SoNnEt-4.5');
    });
  });

  describe('normalizeModelNameLowercase', () => {
    test('should return lowercase version of normalized name', () => {
      const input = 'claude-sonnet-4-5-20250929';
      const result = normalizeModelNameLowercase(input);
      expect(result).toBe('sonnet-4.5');
    });

    test('should handle Opus model', () => {
      const input = 'claude-opus-4-1-20250805';
      const result = normalizeModelNameLowercase(input);
      expect(result).toBe('opus-4.1');
    });

    test('should handle Haiku model', () => {
      const input = 'claude-haiku-3-5-20240307';
      const result = normalizeModelNameLowercase(input);
      expect(result).toBe('haiku-3.5');
    });

    test('should return original for non-Claude models', () => {
      const input = 'gpt-4-turbo';
      const result = normalizeModelNameLowercase(input);
      expect(result).toBe('gpt-4-turbo');
    });

    test('should handle null input', () => {
      const result = normalizeModelNameLowercase(null);
      expect(result).toBeNull();
    });

    test('should handle undefined input', () => {
      const result = normalizeModelNameLowercase(undefined);
      expect(result).toBeUndefined();
    });

    test('should handle already lowercase names', () => {
      const input = 'claude-sonnet-3-5-20240620';
      const result = normalizeModelNameLowercase(input);
      expect(result).toBe('sonnet-3.5');
      expect(result).toMatch(/^[a-z]/);
    });

    test('should handle model with no minor version', () => {
      const input = 'claude-opus-4-20250805';
      const result = normalizeModelNameLowercase(input);
      expect(result).toBe('opus-4');
    });
  });

  describe('Model name patterns', () => {
    test('should handle various date formats in model names', () => {
      const testCases = [
        { input: 'claude-sonnet-4-5-20250929', expected: 'Sonnet-4.5' },
        { input: 'claude-sonnet-4-5-20241231', expected: 'Sonnet-4.5' },
        { input: 'claude-sonnet-4-5-20240101', expected: 'Sonnet-4.5' }
      ];

      testCases.forEach(({ input, expected }) => {
        expect(normalizeModelName(input)).toBe(expected);
      });
    });

    test('should handle all known model families', () => {
      const families = ['sonnet', 'opus', 'haiku'];

      families.forEach(family => {
        const input = `claude-${family}-4-5-20250929`;
        const result = normalizeModelName(input);
        const capitalizedFamily = family.charAt(0).toUpperCase() + family.slice(1);
        expect(result).toBe(`${capitalizedFamily}-4.5`);
      });
    });

    test('should correctly identify date component (8 digits)', () => {
      const input = 'claude-sonnet-4-5-20250929';
      const result = normalizeModelName(input);

      // Should not include the date in the normalized name
      expect(result).not.toContain('20250929');
      expect(result).not.toContain('2025');
    });

    test('should handle version numbers before date', () => {
      const input = 'claude-sonnet-3-5-20240620';
      const result = normalizeModelName(input);

      expect(result).toContain('3.5');
      expect(result).not.toContain('20240620');
    });
  });
});

import { jest } from '@jest/globals';
import { SecureUploader } from '../../src/utils/secure-upload.js';

describe('SecureUploader', () => {
  let originalEnv;

  beforeEach(() => {
    // Save original environment
    originalEnv = { ...process.env };
    // Clear S3 env vars for testing
    delete process.env.S3_CACHE_BUCKET;
    delete process.env.S3_ENDPOINT;
    delete process.env.S3_FORCE_PATH_STYLE;
  });

  afterEach(() => {
    // Restore original environment
    process.env = originalEnv;
  });

  describe('initialization', () => {
    test('should throw error when S3_CACHE_BUCKET is not set', async () => {
      const uploader = new SecureUploader();
      
      await expect(uploader.initialize()).rejects.toThrow('S3_CACHE_BUCKET environment variable not set');
    });

    test('should throw error when S3_ENDPOINT is not set', async () => {
      process.env.S3_CACHE_BUCKET = 'test-bucket';
      const uploader = new SecureUploader();
      
      await expect(uploader.initialize()).rejects.toThrow('S3_ENDPOINT environment variable not set');
    });

    test('should throw error for invalid S3_ENDPOINT format', async () => {
      process.env.S3_CACHE_BUCKET = 'test-bucket';
      process.env.S3_ENDPOINT = 'invalid-format';
      const uploader = new SecureUploader();
      
      await expect(uploader.initialize()).rejects.toThrow('Invalid S3_ENDPOINT format');
    });

    test('should initialize successfully with valid configuration', async () => {
      process.env.S3_CACHE_BUCKET = 'test-bucket';
      process.env.S3_ENDPOINT = 's3://ACCESSKEY:SECRETKEY@endpoint.example.com';
      
      const uploader = new SecureUploader();
      const result = await uploader.initialize();
      
      expect(result).toBe(true);
      expect(uploader.initialized).toBe(true);
      expect(uploader.s3Client).toBeDefined();
      expect(uploader.endpoint).toBe('endpoint.example.com');
    });

    test('should not reinitialize if already initialized', async () => {
      process.env.S3_CACHE_BUCKET = 'test-bucket';
      process.env.S3_ENDPOINT = 's3://ACCESSKEY:SECRETKEY@endpoint.example.com';
      
      const uploader = new SecureUploader();
      await uploader.initialize();
      const firstClient = uploader.s3Client;
      
      await uploader.initialize();
      expect(uploader.s3Client).toBe(firstClient);
    });

    test('should handle S3_FORCE_PATH_STYLE correctly', async () => {
      process.env.S3_CACHE_BUCKET = 'test-bucket';
      process.env.S3_ENDPOINT = 's3://ACCESSKEY:SECRETKEY@endpoint.example.com';
      process.env.S3_FORCE_PATH_STYLE = 'true';
      
      const uploader = new SecureUploader();
      await uploader.initialize();
      
      expect(uploader.initialized).toBe(true);
    });
  });

  describe('maskCredentials', () => {
    test('should mask Telegram bot tokens in URLs', () => {
      const text = 'https://api.telegram.org/bot1234567890:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghi/sendMessage';
      const masked = SecureUploader.maskCredentials(text);
      
      expect(masked).toContain('****');
      expect(masked).not.toContain('1234567890:ABCDEFGHIJKLMNOPQRSTUVWXYZ');
    });

    test('should mask standalone Telegram bot tokens', () => {
      const text = 'Token: 1234567890:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghi';
      const masked = SecureUploader.maskCredentials(text);
      
      expect(masked).toContain('****');
      expect(masked).not.toContain('1234567890:ABCDEFGHIJKLMNOPQRSTUVWXYZ');
    });

    test('should mask Discord bot tokens', () => {
      const text = 'Bot NjU0MzIxMDk4NzY1NDMyMTA5.XfK3Jw.1234567890abcdefghijklmnopqrstuvwxyz';
      const masked = SecureUploader.maskCredentials(text);
      
      expect(masked).toContain('Bot ****');
      expect(masked).not.toContain('NjU0MzIxMDk4NzY1NDMyMTA5');
    });

    test('should mask API keys in various formats', () => {
      const texts = [
        'api_key=sk-1234567890abcdefghijklmnopqrstuvwxyz',
        'apikey: "sk-1234567890abcdefghijklmnopqrstuvwxyz"',
        'secret_key = abcd1234567890efghijklmnopqrstuvwxyz',
        'access-key:1234567890abcdefghijklmnopqrstuvwxyz'
      ];
      
      texts.forEach(text => {
        const masked = SecureUploader.maskCredentials(text);
        expect(masked).toContain('****');
        expect(masked).not.toContain('1234567890abcdefghijklmnopqrstuvwxyz');
      });
    });

    test('should mask AWS Access Key IDs', () => {
      const text = 'AWS Access Key: AKIAIOSFODNN7EXAMPLE';
      const masked = SecureUploader.maskCredentials(text);
      
      expect(masked).toContain('AKIA****');
      expect(masked).not.toContain('AKIAIOSFODNN7EXAMPLE');
    });

    test('should mask AWS Secret Access Keys', () => {
      const text = 'Secret: wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY';
      const masked = SecureUploader.maskCredentials(text);
      
      expect(masked).toContain('****');
      expect(masked).not.toContain('wJalrXUtnFEMI/K7MDENG');
    });

    test('should mask Bearer tokens', () => {
      const text = 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP03fq0o';
      const masked = SecureUploader.maskCredentials(text);
      
      expect(masked).toContain('Bearer ****');
      expect(masked).not.toContain('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9');
    });

    test('should mask GitHub tokens', () => {
      const texts = [
        'token: ghp_1234567890abcdefghijklmnopqrstuvwxyz',
        'PAT: gho_1234567890abcdefghijklmnopqrstuvwxyz',
        'App token: ghu_1234567890abcdefghijklmnopqrstuvwxyz'
      ];
      
      texts.forEach(text => {
        const masked = SecureUploader.maskCredentials(text);
        expect(masked).toContain('gh');
        expect(masked).toContain('****');
        expect(masked).not.toContain('1234567890abcdefghijklmnopqrstuvwxyz');
      });
    });

    test('should mask JWT tokens', () => {
      const text = 'JWT: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c';
      const masked = SecureUploader.maskCredentials(text);
      
      expect(masked).toContain('eyJ****');
      expect(masked).not.toContain('SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c');
    });

    test('should mask OpenAI API keys', () => {
      const text = 'OPENAI_API_KEY=sk-1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJ';
      const masked = SecureUploader.maskCredentials(text);
      
      expect(masked).toContain('sk-****');
      expect(masked).not.toContain('1234567890abcdefghijklmnopqrstuvwxyz');
    });

    test('should handle null and undefined input', () => {
      expect(SecureUploader.maskCredentials(null)).toBeNull();
      expect(SecureUploader.maskCredentials(undefined)).toBeUndefined();
    });

    test('should handle empty string', () => {
      expect(SecureUploader.maskCredentials('')).toBe('');
    });

    test('should preserve non-sensitive text', () => {
      const text = 'This is a normal message without any sensitive data';
      const masked = SecureUploader.maskCredentials(text);
      
      expect(masked).toBe(text);
    });

    test('should mask multiple credentials in the same text', () => {
      const text = 'API_KEY=sk-abc123 and AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE with token 1234567890:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghi';
      const masked = SecureUploader.maskCredentials(text);
      
      expect(masked).toContain('API_KEY=****');
      expect(masked).toContain('AKIA****');
      expect(masked).toContain('****');
      expect(masked).not.toContain('sk-abc123');
      expect(masked).not.toContain('AKIAIOSFODNN7EXAMPLE');
      expect(masked).not.toContain('1234567890:ABCDEFGHIJKLMNOPQRSTUVWXYZ');
    });

    test('should mask credentials in JSON strings', () => {
      const json = JSON.stringify({
        api_key: 'sk-1234567890abcdefghijklmnopqrstuvwxyz',
        aws_access_key: 'AKIAIOSFODNN7EXAMPLE',
        normal_field: 'visible data'
      });
      
      const masked = SecureUploader.maskCredentials(json);
      
      expect(masked).toContain('****');
      expect(masked).toContain('visible data');
      expect(masked).not.toContain('sk-1234567890abcdefghijklmnopqrstuvwxyz');
      expect(masked).not.toContain('AKIAIOSFODNN7EXAMPLE');
    });
  });
});
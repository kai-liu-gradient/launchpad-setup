import { jest } from '@jest/globals';

// Mock dependencies
jest.unstable_mockModule('../src/config.js', () => ({
  config: {
    logging: { level: 'info' }
  }
}));

jest.unstable_mockModule('../src/logger.js', () => ({
  logger: {
    info: jest.fn(),
    debug: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    success: jest.fn()
  }
}));

jest.unstable_mockModule('../src/stats-db.js', () => ({
  getStatsDB: jest.fn(() => ({
    recordTaskCreation: jest.fn(),
    recordTaskCompletion: jest.fn()
  }))
}));

jest.unstable_mockModule('../src/providers/costCalculator.js', () => ({
  calculateTokenCost: jest.fn(() => ({
    inputCost: 0.001,
    outputCost: 0.002,
    cachedCost: 0,
    totalCost: 0.003,
    currency: 'USD',
    estimated: true
  }))
}));

const mockLoadRegistry = jest.fn(() => null);
jest.unstable_mockModule('../src/commands/projects.js', () => ({
  loadRegistry: mockLoadRegistry
}));

// We need to mock fs/promises for controlled testing
const mockReaddir = jest.fn();
const mockStat = jest.fn();
const mockAccess = jest.fn();
const mockReadFile = jest.fn();

jest.unstable_mockModule('fs/promises', () => ({
  default: {
    readdir: mockReaddir,
    stat: mockStat,
    access: mockAccess,
    readFile: mockReadFile
  },
  readdir: mockReaddir,
  stat: mockStat,
  access: mockAccess,
  readFile: mockReadFile
}));

describe('UnmanagedTaskWatcher', () => {
  let UnmanagedTaskWatcher;
  let logger;
  let getStatsDB;
  let calculateTokenCost;

  beforeAll(async () => {
    const module = await import('../src/unmanaged-task-watcher.js');
    UnmanagedTaskWatcher = module.UnmanagedTaskWatcher;
    const loggerModule = await import('../src/logger.js');
    logger = loggerModule.logger;
    const statsModule = await import('../src/stats-db.js');
    getStatsDB = statsModule.getStatsDB;
    const costModule = await import('../src/providers/costCalculator.js');
    calculateTokenCost = costModule.calculateTokenCost;
  });

  beforeEach(() => {
    jest.clearAllMocks();
    mockReaddir.mockReset();
    mockStat.mockReset();
    mockAccess.mockReset();
    mockReadFile.mockReset();
    mockLoadRegistry.mockReset();
    mockLoadRegistry.mockReturnValue(null);
    // Reset env vars
    delete process.env.UNMANAGED_TASK_DETECTION_ENABLED;
    delete process.env.UNMANAGED_TASK_INSERT_STATS;
    delete process.env.UNMANAGED_TASK_SCAN_INTERVAL_MS;
    delete process.env.UNMANAGED_TASK_SETTLE_TIME_MS;
    delete process.env.UNMANAGED_TASK_MAX_AGE_MS;
  });

  describe('Configuration', () => {
    test('should be disabled by default', () => {
      const watcher = new UnmanagedTaskWatcher(null);
      expect(watcher.enabled).toBe(false);
    });

    test('should be enabled when env var is true', () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);
      expect(watcher.enabled).toBe(true);
    });

    test('should use default scan interval of 60 seconds', () => {
      const watcher = new UnmanagedTaskWatcher(null);
      expect(watcher.scanIntervalMs).toBe(60000);
    });

    test('should use custom scan interval from env', () => {
      process.env.UNMANAGED_TASK_SCAN_INTERVAL_MS = '30000';
      const watcher = new UnmanagedTaskWatcher(null);
      expect(watcher.scanIntervalMs).toBe(30000);
    });

    test('should use default settle time of 5 minutes', () => {
      const watcher = new UnmanagedTaskWatcher(null);
      expect(watcher.settleTimeMs).toBe(300000);
    });

    test('should use custom settle time from env', () => {
      process.env.UNMANAGED_TASK_SETTLE_TIME_MS = '120000';
      const watcher = new UnmanagedTaskWatcher(null);
      expect(watcher.settleTimeMs).toBe(120000);
    });

    test('should use default max age of 1 hour', () => {
      const watcher = new UnmanagedTaskWatcher(null);
      expect(watcher.maxAgeMs).toBe(3600000);
    });

    test('should use custom max age from env', () => {
      process.env.UNMANAGED_TASK_MAX_AGE_MS = '7200000';
      const watcher = new UnmanagedTaskWatcher(null);
      expect(watcher.maxAgeMs).toBe(7200000);
    });

    test('should have stats insertion disabled by default', () => {
      const watcher = new UnmanagedTaskWatcher(null);
      expect(watcher.insertStats).toBe(false);
    });

    test('should enable stats insertion when env var is true', () => {
      process.env.UNMANAGED_TASK_INSERT_STATS = 'true';
      const watcher = new UnmanagedTaskWatcher(null);
      expect(watcher.insertStats).toBe(true);
    });
  });

  describe('Path decoding', () => {
    test('should decode folder name to project path', () => {
      const watcher = new UnmanagedTaskWatcher(null);
      expect(watcher._decodeFolderName('-root-workspace-project')).toBe('/root/workspace/project');
    });

    test('should decode folder name starting with hyphen', () => {
      const watcher = new UnmanagedTaskWatcher(null);
      expect(watcher._decodeFolderName('-root-workspace-ani-code')).toBe('/root/workspace/ani/code');
    });

    test('should handle folder name without leading hyphen', () => {
      const watcher = new UnmanagedTaskWatcher(null);
      expect(watcher._decodeFolderName('home-user-project')).toBe('home/user/project');
    });
  });

  describe('start/stop', () => {
    test('should not start scanning when disabled', () => {
      const watcher = new UnmanagedTaskWatcher(null);
      watcher.start();
      expect(watcher.running).toBe(false);
      expect(watcher.scanTimer).toBeNull();
      expect(logger.info).toHaveBeenCalledWith(
        expect.stringContaining('[UNMANAGED] Unmanaged task detection is disabled')
      );
    });

    test('should start scanning when enabled', () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);
      watcher.start();
      expect(watcher.running).toBe(true);
      expect(watcher.scanTimer).not.toBeNull();
      watcher.stop();
    });

    test('should stop scanning on stop()', () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);
      watcher.start();
      watcher.stop();
      expect(watcher.running).toBe(false);
      expect(watcher.scanTimer).toBeNull();
    });
  });

  describe('Managed file registration', () => {
    test('should register managed files', () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);
      watcher.registerManagedFile('/path/to/session.jsonl');
      expect(watcher.knownManagedFiles.has('/path/to/session.jsonl')).toBe(true);
    });

    test('should remove from unmanaged when registered as managed', () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);
      watcher.detectedUnmanaged.set('/path/to/session.jsonl', { filename: 'session.jsonl' });
      watcher.registerManagedFile('/path/to/session.jsonl');
      expect(watcher.detectedUnmanaged.has('/path/to/session.jsonl')).toBe(false);
    });

    test('should do nothing when disabled', () => {
      const watcher = new UnmanagedTaskWatcher(null);
      watcher.registerManagedFile('/path/to/session.jsonl');
      expect(watcher.knownManagedFiles.size).toBe(0);
    });

    test('should register known tasks from task queue', () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const mockTaskQueue = {
        getAllTasks: () => ({
          running: [{ sessionFile: '/path/running.jsonl' }],
          pending: [{ sessionFile: '/path/pending.jsonl' }]
        }),
        getTaskHistory: () => [{ sessionFile: '/path/history.jsonl' }]
      };
      const watcher = new UnmanagedTaskWatcher(mockTaskQueue);
      watcher._registerKnownTasks();
      expect(watcher.knownManagedFiles.size).toBe(3);
    });

    test('should skip tasks without sessionFile', () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const mockTaskQueue = {
        getAllTasks: () => ({
          running: [{ id: 'task1' }],
          pending: []
        }),
        getTaskHistory: () => []
      };
      const watcher = new UnmanagedTaskWatcher(mockTaskQueue);
      watcher._registerKnownTasks();
      expect(watcher.knownManagedFiles.size).toBe(0);
    });
  });

  describe('Active task association', () => {
    test('should identify files associated with active tasks by cwd', () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const mockTaskQueue = {
        getAllTasks: () => ({
          running: [{ cwd: '/root/workspace/project' }],
          pending: []
        }),
        getTaskHistory: () => []
      };
      const watcher = new UnmanagedTaskWatcher(mockTaskQueue);
      const result = watcher._isAssociatedWithActiveTask('-root-workspace-project', 'session.jsonl');
      expect(result).toBe(true);
    });

    test('should not associate files from different projects', () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const mockTaskQueue = {
        getAllTasks: () => ({
          running: [{ cwd: '/root/workspace/other-project' }],
          pending: []
        }),
        getTaskHistory: () => []
      };
      const watcher = new UnmanagedTaskWatcher(mockTaskQueue);
      const result = watcher._isAssociatedWithActiveTask('-root-workspace-project', 'session.jsonl');
      expect(result).toBe(false);
    });

    test('should return false when no task queue', () => {
      const watcher = new UnmanagedTaskWatcher(null);
      const result = watcher._isAssociatedWithActiveTask('-root-workspace-project', 'session.jsonl');
      expect(result).toBe(false);
    });
  });

  describe('File stability detection', () => {
    test('should detect stabilized files with concise summary', async () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);
      watcher.running = true;
      watcher.settleTimeMs = 1000; // 1 second for testing

      // Mock JSONL content matching real Claude Code format (model in message object)
      mockReadFile.mockResolvedValue(
        '{"timestamp":"2026-01-01T00:00:00Z","type":"queue-operation","operation":"dequeue"}\n' +
        '{"timestamp":"2026-01-01T00:00:01Z","type":"user","message":{"role":"user","content":"explain the login flow"}}\n' +
        '{"timestamp":"2026-01-01T00:01:00Z","type":"assistant","message":{"model":"claude-sonnet-4","role":"assistant","content":"...","usage":{"input_tokens":500,"output_tokens":200,"cache_read_input_tokens":100}}}\n'
      );

      // Add a file that was last modified more than 1 second ago
      const oldMtime = Date.now() - 2000;
      watcher.detectedUnmanaged.set('/path/session.jsonl', {
        mtime: oldMtime,
        detectedAt: oldMtime - 1000,
        size: 1024,
        birthtime: oldMtime - 5000,
        projectPath: '/root/workspace/project',
        folderName: '-root-workspace-project',
        filename: 'session.jsonl',
        logged: false
      });

      await watcher._checkStabilized();

      expect(watcher.detectedUnmanaged.size).toBe(0);
      expect(watcher.insertedFiles.has('/path/session.jsonl')).toBe(true);
      // Verify concise one-line log format
      expect(logger.info).toHaveBeenCalledWith(
        expect.stringMatching(/\[UNMANAGED\] Stabilized:.*session\.jsonl.*claude-sonnet-4.*\$/)
      );
      // Verify calculateTokenCost was called
      expect(calculateTokenCost).toHaveBeenCalledWith(expect.objectContaining({
        providerId: 'claude',
        modelId: 'claude-sonnet-4'
      }));
    });

    test('should not flag active files as stabilized', async () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);
      watcher.running = true;
      watcher.settleTimeMs = 300000;

      // Add a recently modified file
      watcher.detectedUnmanaged.set('/path/session.jsonl', {
        mtime: Date.now(),
        detectedAt: Date.now() - 1000,
        size: 1024,
        birthtime: Date.now() - 5000,
        projectPath: '/root/workspace/project',
        folderName: '-root-workspace-project',
        filename: 'session.jsonl',
        logged: false
      });

      await watcher._checkStabilized();

      expect(watcher.detectedUnmanaged.size).toBe(1);
    });
  });

  describe('Folder scanning', () => {
    test('should detect unmanaged JSONL files', async () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);
      watcher.running = true;

      mockReaddir.mockResolvedValueOnce(['abc123.jsonl', 'def456.jsonl']);
      mockStat.mockResolvedValue({
        size: 1024,
        mtimeMs: Date.now() - 60000,
        birthtimeMs: Date.now() - 120000
      });

      await watcher._scanProjectFolder('-root-workspace-project');

      expect(watcher.detectedUnmanaged.size).toBe(2);
      expect(logger.info).toHaveBeenCalledWith(
        expect.stringContaining('[UNMANAGED] Detected:')
      );
    });

    test('should skip agent sub-session files', async () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);
      watcher.running = true;

      mockReaddir.mockResolvedValueOnce(['abc123.jsonl', 'agent-xyz.jsonl']);
      mockStat.mockResolvedValue({
        size: 1024,
        mtimeMs: Date.now() - 60000,
        birthtimeMs: Date.now() - 120000
      });

      await watcher._scanProjectFolder('-root-workspace-project');

      expect(watcher.detectedUnmanaged.size).toBe(1);
    });

    test('should skip empty JSONL files', async () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);
      watcher.running = true;

      mockReaddir.mockResolvedValueOnce(['empty.jsonl']);
      mockStat.mockResolvedValue({
        size: 0,
        mtimeMs: Date.now(),
        birthtimeMs: Date.now()
      });

      await watcher._scanProjectFolder('-root-workspace-project');

      expect(watcher.detectedUnmanaged.size).toBe(0);
    });

    test('should skip known managed files', async () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);
      watcher.running = true;

      const os = await import('os');
      const path = await import('path');
      const filePath = path.default.join(os.default.homedir(), '.claude', 'projects', '-root-workspace-project', 'known.jsonl');
      watcher.knownManagedFiles.add(filePath);

      mockReaddir.mockResolvedValueOnce(['known.jsonl']);

      await watcher._scanProjectFolder('-root-workspace-project');

      expect(watcher.detectedUnmanaged.size).toBe(0);
    });

    test('should skip JSONL files older than maxAgeMs', async () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);
      watcher.running = true;
      watcher.maxAgeMs = 3600000; // 1 hour

      mockReaddir.mockResolvedValueOnce(['old-session.jsonl', 'new-session.jsonl']);
      // First call: old file (2 hours old)
      mockStat
        .mockResolvedValueOnce({
          size: 1024,
          mtimeMs: Date.now() - 7200000,
          birthtimeMs: Date.now() - 7200000
        })
        // Second call: new file (10 minutes old)
        .mockResolvedValueOnce({
          size: 1024,
          mtimeMs: Date.now() - 600000,
          birthtimeMs: Date.now() - 600000
        });

      await watcher._scanProjectFolder('-root-workspace-project');

      // Only the new file should be detected
      expect(watcher.detectedUnmanaged.size).toBe(1);
      const detected = Array.from(watcher.detectedUnmanaged.values());
      expect(detected[0].filename).toBe('new-session.jsonl');
    });

    test('should keep tracking already-detected files even if older than maxAgeMs', async () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);
      watcher.running = true;
      watcher.maxAgeMs = 3600000;

      const os = await import('os');
      const pathMod = await import('path');
      const filePath = pathMod.default.join(
        os.default.homedir(), '.claude', 'projects',
        '-root-workspace-project', 'tracked.jsonl'
      );

      // Pre-add as already detected
      watcher.detectedUnmanaged.set(filePath, {
        mtime: Date.now() - 7200000,
        detectedAt: Date.now() - 7200000,
        size: 512,
        projectPath: '/root/workspace/project',
        folderName: '-root-workspace-project',
        filename: 'tracked.jsonl',
        logged: false
      });

      mockReaddir.mockResolvedValueOnce(['tracked.jsonl']);
      mockStat.mockResolvedValueOnce({
        size: 2048,
        mtimeMs: Date.now() - 7200000,
        birthtimeMs: Date.now() - 7200000
      });

      await watcher._scanProjectFolder('-root-workspace-project');

      // Should still be tracked and have updated size
      expect(watcher.detectedUnmanaged.size).toBe(1);
      expect(watcher.detectedUnmanaged.get(filePath).size).toBe(2048);
    });

    test('should handle permission errors gracefully', async () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);
      watcher.running = true;

      const error = new Error('Permission denied');
      error.code = 'EACCES';
      mockReaddir.mockRejectedValueOnce(error);

      await watcher._scanProjectFolder('-root-workspace-project');

      // Should not throw and should not log error for known error codes
      expect(watcher.detectedUnmanaged.size).toBe(0);
    });
  });

  describe('Stats insertion', () => {
    test('should insert stats record when enabled and file stabilizes', async () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      process.env.UNMANAGED_TASK_INSERT_STATS = 'true';
      const watcher = new UnmanagedTaskWatcher(null);
      watcher.running = true;
      watcher.settleTimeMs = 1000;

      const mockStatsDB = {
        recordTaskCreation: jest.fn(),
        recordTaskCompletion: jest.fn()
      };
      getStatsDB.mockReturnValue(mockStatsDB);

      // Mock the JSONL file content (model in message object, matching real Claude Code format)
      mockReadFile.mockResolvedValue(
        '{"timestamp":"2026-01-01T00:00:00Z","type":"queue-operation"}\n' +
        '{"timestamp":"2026-01-01T00:05:00Z","type":"user","message":{"role":"user","content":"hello world"}}\n' +
        '{"timestamp":"2026-01-01T00:06:00Z","type":"assistant","message":{"model":"claude-sonnet-4","role":"assistant","content":"hi"}}\n'
      );

      const oldMtime = Date.now() - 2000;
      watcher.detectedUnmanaged.set('/path/session.jsonl', {
        mtime: oldMtime,
        detectedAt: oldMtime - 1000,
        size: 1024,
        birthtime: oldMtime - 5000,
        projectPath: '/root/workspace/project',
        folderName: '-root-workspace-project',
        filename: 'session.jsonl',
        logged: false
      });

      await watcher._checkStabilized();

      expect(mockStatsDB.recordTaskCreation).toHaveBeenCalledWith(
        expect.stringContaining('unmanaged-'),
        '/root/workspace/project',
        expect.stringContaining('unmanaged: hello world')
      );
      expect(mockStatsDB.recordTaskCompletion).toHaveBeenCalledWith(
        expect.stringContaining('unmanaged-'),
        expect.stringContaining('tokens'),
        'claude-sonnet-4',
        expect.any(Number),
        expect.any(Object),
        null
      );
    });

    test('should not insert stats when insertStats is disabled', async () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);
      watcher.running = true;
      watcher.settleTimeMs = 1000;

      const mockStatsDB = {
        recordTaskCreation: jest.fn(),
        recordTaskCompletion: jest.fn()
      };
      getStatsDB.mockReturnValue(mockStatsDB);

      // Mock JSONL content for _parseSessionMetrics call in _checkStabilized (model in message)
      mockReadFile.mockResolvedValue(
        '{"timestamp":"2026-01-01T00:00:00Z","type":"assistant","message":{"model":"claude-sonnet-4","role":"assistant","content":"hi"}}\n'
      );

      const oldMtime = Date.now() - 2000;
      watcher.detectedUnmanaged.set('/path/session.jsonl', {
        mtime: oldMtime,
        detectedAt: oldMtime - 1000,
        size: 1024,
        birthtime: oldMtime - 5000,
        projectPath: '/root/workspace/project',
        folderName: '-root-workspace-project',
        filename: 'session.jsonl',
        logged: false
      });

      await watcher._checkStabilized();

      expect(mockStatsDB.recordTaskCreation).not.toHaveBeenCalled();
    });
  });

  describe('Session metrics parsing', () => {
    test('should parse model from root level and timestamps from JSONL', async () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);

      mockReadFile.mockResolvedValue(
        '{"timestamp":"2026-01-01T00:00:00Z","model":"claude-sonnet-4"}\n' +
        '{"timestamp":"2026-01-01T00:10:00Z","message":"response"}\n'
      );

      const metrics = await watcher._parseSessionMetrics('/path/session.jsonl');

      expect(metrics.model).toBe('claude-sonnet-4');
      expect(metrics.lineCount).toBe(2);
      expect(metrics.durationMs).toBe(600000); // 10 minutes
    });

    test('should parse model from message.model (Claude Code JSONL format)', async () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);

      mockReadFile.mockResolvedValue(
        '{"timestamp":"2026-01-01T00:00:00Z","type":"queue-operation"}\n' +
        '{"timestamp":"2026-01-01T00:00:01Z","type":"user","message":{"role":"user","content":"hello"}}\n' +
        '{"timestamp":"2026-01-01T00:10:00Z","type":"assistant","message":{"model":"claude-opus-4-6","role":"assistant","content":"hi","usage":{"input_tokens":100,"output_tokens":50}}}\n'
      );

      const metrics = await watcher._parseSessionMetrics('/path/session.jsonl');

      expect(metrics.model).toBe('claude-opus-4-6');
      expect(metrics.lineCount).toBe(3);
      expect(metrics.durationMs).toBe(600000);
      expect(metrics.approximateTokens.input).toBe(100);
      expect(metrics.approximateTokens.output).toBe(50);
    });

    test('should handle empty files', async () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);

      mockReadFile.mockResolvedValue('');

      const metrics = await watcher._parseSessionMetrics('/path/empty.jsonl');

      expect(metrics.model).toBeNull();
      expect(metrics.lineCount).toBe(0);
    });

    test('should handle malformed JSONL lines', async () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);

      mockReadFile.mockResolvedValue(
        'not valid json\n' +
        '{"timestamp":"2026-01-01T00:00:00Z","model":"claude-sonnet-4"}\n'
      );

      const metrics = await watcher._parseSessionMetrics('/path/session.jsonl');

      expect(metrics.model).toBe('claude-sonnet-4');
      expect(metrics.lineCount).toBe(2);
    });

    test('should aggregate token usage including cached tokens', async () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);

      mockReadFile.mockResolvedValue(
        '{"usage":{"input_tokens":100,"output_tokens":50,"cache_read_input_tokens":30}}\n' +
        '{"usage":{"input_tokens":200,"output_tokens":100,"cache_read_input_tokens":70}}\n'
      );

      const metrics = await watcher._parseSessionMetrics('/path/session.jsonl');

      expect(metrics.approximateTokens.input).toBe(300);
      expect(metrics.approximateTokens.output).toBe(150);
      expect(metrics.approximateTokens.cached).toBe(100);
      expect(metrics.approximateTokens.total).toBe(450);
    });

    test('should extract initial user prompt', async () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);

      mockReadFile.mockResolvedValue(
        '{"timestamp":"2026-01-01T00:00:00Z","type":"init"}\n' +
        '{"timestamp":"2026-01-01T00:00:01Z","type":"user","message":{"role":"user","content":"fix the login bug in auth.js"}}\n' +
        '{"timestamp":"2026-01-01T00:00:05Z","type":"assistant","message":{"role":"assistant","content":"I will fix that."}}\n'
      );

      const metrics = await watcher._parseSessionMetrics('/path/session.jsonl');

      expect(metrics.initialPrompt).toBe('fix the login bug in auth.js');
    });

    test('should truncate long initial prompts to 120 chars', async () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);

      const longPrompt = 'a'.repeat(200);
      mockReadFile.mockResolvedValue(
        `{"timestamp":"2026-01-01T00:00:00Z","type":"user","message":{"role":"user","content":"${longPrompt}"}}\n`
      );

      const metrics = await watcher._parseSessionMetrics('/path/session.jsonl');

      expect(metrics.initialPrompt).toBe('a'.repeat(120) + '...');
    });

    test('should handle array content in user message', async () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);

      mockReadFile.mockResolvedValue(
        '{"type":"user","message":{"role":"user","content":[{"type":"text","text":"review this code"}]}}\n'
      );

      const metrics = await watcher._parseSessionMetrics('/path/session.jsonl');

      expect(metrics.initialPrompt).toBe('review this code');
    });
  });

  describe('getStatus()', () => {
    test('should return current watcher status', () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);

      const status = watcher.getStatus();

      expect(status.enabled).toBe(true);
      expect(status.running).toBe(false);
      expect(status.knownManagedFiles).toBe(0);
      expect(status.detectedUnmanaged).toBe(0);
      expect(status.insertedFiles).toBe(0);
    });

    test('should include projectName in detected files', () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);

      watcher.detectedUnmanaged.set('/path/session.jsonl', {
        mtime: Date.now(),
        detectedAt: Date.now(),
        size: 1024,
        projectPath: '/root/workspace/project',
        projectName: 'my-project',
        folderName: '-root-workspace-project',
        filename: 'session.jsonl',
        logged: false
      });

      const status = watcher.getStatus();
      expect(status.detectedFiles[0].projectName).toBe('my-project');
    });
  });

  describe('Integration: full scan pipeline', () => {
    test('should detect unmanaged JSONL file, log it, stabilize, and insert stats', async () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      process.env.UNMANAGED_TASK_INSERT_STATS = 'true';
      const watcher = new UnmanagedTaskWatcher(null);
      watcher.running = true;
      // Use a long settle time so file is NOT stabilized during first scan
      watcher.settleTimeMs = 600000; // 10 minutes

      const mockStatsDB = {
        recordTaskCreation: jest.fn(),
        recordTaskCompletion: jest.fn()
      };
      getStatsDB.mockReturnValue(mockStatsDB);

      const now = Date.now();
      const sessionContent =
        '{"timestamp":"2026-02-09T10:00:00Z","type":"queue-operation","operation":"dequeue"}\n' +
        '{"timestamp":"2026-02-09T10:01:00Z","type":"user","message":{"role":"user","content":"hello"}}\n' +
        '{"timestamp":"2026-02-09T10:02:00Z","type":"assistant","message":{"model":"claude-sonnet-4","role":"assistant","content":"hi","usage":{"input_tokens":50,"output_tokens":30,"cache_read_input_tokens":10}}}\n' +
        '{"timestamp":"2026-02-09T10:05:00Z","type":"user","message":{"role":"user","content":"bye"}}\n';

      // Step 1: Simulate _scan() discovering a projects directory
      mockAccess.mockResolvedValue(undefined);
      // readdir for projects directory - returns one project folder (withFileTypes: true)
      const mockDirent = { name: '-root-workspace-test-project', isDirectory: () => true };
      mockReaddir
        .mockResolvedValueOnce([mockDirent])
        // readdir for project folder - returns one JSONL file (simulating external claude session)
        .mockResolvedValueOnce(['external-session-abc123.jsonl']);

      mockStat.mockResolvedValue({
        size: sessionContent.length,
        mtimeMs: now - 60000, // Modified 1 minute ago
        birthtimeMs: now - 300000
      });

      // Step 1: First scan - should detect the file (but not stabilize it yet)
      await watcher._scan();

      expect(watcher.detectedUnmanaged.size).toBe(1);
      expect(logger.info).toHaveBeenCalledWith(
        expect.stringContaining('[UNMANAGED] Detected: external-session-abc123.jsonl')
      );

      // Step 2: File hasn't stabilized yet (settleTime is 10 minutes, file is 1 minute old)
      const detectedInfo = Array.from(watcher.detectedUnmanaged.values())[0];
      expect(detectedInfo.filename).toBe('external-session-abc123.jsonl');
      expect(detectedInfo.projectPath).toBe('/root/workspace/test/project');

      // Step 3: Simulate time passing - set mtime far enough in the past
      // and reduce settleTime to trigger stabilization
      watcher.settleTimeMs = 1000; // Reduce to 1 second
      detectedInfo.mtime = now - 2000; // 2 seconds ago, settleTime is now 1s

      // Mock readFile for metrics parsing during stabilization
      mockReadFile.mockResolvedValue(sessionContent);

      // Step 3: Check stabilization - should detect as stabilized and insert stats
      jest.clearAllMocks();
      // Re-setup mock after clearAllMocks
      calculateTokenCost.mockReturnValue({
        inputCost: 0.001,
        outputCost: 0.002,
        cachedCost: 0,
        totalCost: 0.003,
        currency: 'USD',
        estimated: true
      });
      getStatsDB.mockReturnValue(mockStatsDB);
      await watcher._checkStabilized();

      // File should be moved from detected to inserted
      expect(watcher.detectedUnmanaged.size).toBe(0);
      expect(watcher.insertedFiles.size).toBe(1);

      // Stats should have been inserted with initial prompt
      expect(mockStatsDB.recordTaskCreation).toHaveBeenCalledWith(
        expect.stringContaining('unmanaged-'),
        '/root/workspace/test/project',
        expect.stringContaining('unmanaged: hello')
      );
      expect(mockStatsDB.recordTaskCompletion).toHaveBeenCalledWith(
        expect.stringContaining('unmanaged-'),
        expect.stringContaining('tokens'),
        'claude-sonnet-4',
        expect.any(Number),
        expect.objectContaining({
          input: 50,
          output: 30,
          cached: 10,
          total: 80
        }),
        null
      );

      // Stabilization should have been logged with concise one-line format
      expect(logger.info).toHaveBeenCalledWith(
        expect.stringMatching(/\[UNMANAGED\] Stabilized:.*external-session-abc123\.jsonl.*claude-sonnet-4.*\$.*"hello"/)
      );

      // Stats insertion should have been logged concisely
      expect(logger.info).toHaveBeenCalledWith(
        expect.stringContaining('[UNMANAGED] Stats inserted: unmanaged-')
      );
    });

    test('should not re-detect files already inserted into stats', async () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);
      watcher.running = true;

      const os = await import('os');
      const pathMod = await import('path');
      const filePath = pathMod.default.join(
        os.default.homedir(), '.claude', 'projects',
        '-root-workspace-project', 'already-processed.jsonl'
      );
      watcher.insertedFiles.add(filePath);

      mockReaddir.mockResolvedValueOnce(['already-processed.jsonl']);

      await watcher._scanProjectFolder('-root-workspace-project');

      expect(watcher.detectedUnmanaged.size).toBe(0);
    });
  });

  describe('Project registry cross-reference', () => {
    test('should resolve project name from registry when root project exists', () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);

      mockLoadRegistry.mockReturnValueOnce({
        version: '1.0.0',
        projects: [
          { id: 'my-app', name: 'my-app', path: '.', version: '1.0.0' },
          { id: 'sub-pkg', name: 'sub-pkg', path: 'packages/sub', version: '0.1.0' }
        ]
      });

      const result = watcher._resolveProjectName('/root/workspace/my-app');
      expect(result).toBe('my-app');
      expect(mockLoadRegistry).toHaveBeenCalledWith('/root/workspace/my-app');
    });

    test('should fallback to first project when no root project', () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);

      mockLoadRegistry.mockReturnValueOnce({
        version: '1.0.0',
        projects: [
          { id: 'sub-pkg', name: 'sub-pkg', path: 'packages/sub', version: '0.1.0' }
        ]
      });

      const result = watcher._resolveProjectName('/root/workspace/mono');
      expect(result).toBe('sub-pkg');
    });

    test('should return null when registry not found', () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);

      mockLoadRegistry.mockReturnValueOnce(null);

      const result = watcher._resolveProjectName('/nonexistent/path');
      expect(result).toBeNull();
    });

    test('should return null when registry has no projects', () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);

      mockLoadRegistry.mockReturnValueOnce({ version: '1.0.0', projects: [] });

      const result = watcher._resolveProjectName('/empty/workspace');
      expect(result).toBeNull();
    });

    test('should return null when loadRegistry throws', () => {
      process.env.UNMANAGED_TASK_DETECTION_ENABLED = 'true';
      const watcher = new UnmanagedTaskWatcher(null);

      mockLoadRegistry.mockImplementationOnce(() => { throw new Error('file not found'); });

      const result = watcher._resolveProjectName('/broken/path');
      expect(result).toBeNull();
    });
  });
});

import { jest } from '@jest/globals';
import http from 'http';
import fs from 'fs';
import path from 'path';

/**
 * Gateway Callbacks Test Suite
 * Tests for gateway callback mechanism with retry logic and failed callback logging
 */

describe('Gateway Callbacks', () => {
  let TaskMonitor;
  let taskMonitor;
  let mockGatewayServer;
  let receivedCallbacks;
  let callbackAttempts;
  let shouldFailCallback;
  let gatewayPort;
  let gatewayUrl;
  const TEST_LOG_DIR = '/tmp/ani-code-test-logs';
  const FAILED_CALLBACK_LOG = path.join(TEST_LOG_DIR, 'failed-callbacks.jsonl');

  beforeAll(async () => {
    // Set up test environment
    process.env.GATEWAY_API_KEY = 'test-gateway-key';
    process.env.WORKSPACE_ID = 'test-workspace';
    process.env.PROJECT_ID = 'test-project';

    // Create test log directory
    if (!fs.existsSync(TEST_LOG_DIR)) {
      fs.mkdirSync(TEST_LOG_DIR, { recursive: true });
    }

    // Mock gateway server
    receivedCallbacks = [];
    callbackAttempts = [];
    shouldFailCallback = false;

    mockGatewayServer = http.createServer((req, res) => {
      if (req.url === '/api/callback/task-status' && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => {
          body += chunk.toString();
        });

        req.on('end', () => {
          const callback = JSON.parse(body);
          callbackAttempts.push({
            timestamp: new Date().toISOString(),
            callback
          });

          if (shouldFailCallback) {
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Gateway error' }));
          } else {
            receivedCallbacks.push(callback);
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ success: true }));
          }
        });
        return;
      }

      res.writeHead(404);
      res.end('Not found');
    });

    await new Promise((resolve) => {
      mockGatewayServer.listen(0, resolve);
    });

    gatewayPort = mockGatewayServer.address().port;
    gatewayUrl = `http://localhost:${gatewayPort}`;
    process.env.GATEWAY_URL = gatewayUrl;

    // Import TaskMonitor after env setup
    const taskMonitorModule = await import('../src/task-monitor.js');
    TaskMonitor = taskMonitorModule.TaskMonitor;
  });

  afterAll(async () => {
    if (mockGatewayServer) {
      await new Promise((resolve) => {
        mockGatewayServer.close(resolve);
      });
    }

    // Clean up test log directory
    if (fs.existsSync(TEST_LOG_DIR)) {
      fs.rmSync(TEST_LOG_DIR, { recursive: true, force: true });
    }
  });

  beforeEach(() => {
    // Clear callback history
    receivedCallbacks = [];
    callbackAttempts = [];
    shouldFailCallback = false;

    // Clear failed callback log
    if (fs.existsSync(FAILED_CALLBACK_LOG)) {
      fs.unlinkSync(FAILED_CALLBACK_LOG);
    }

    // Create fresh task monitor instance
    taskMonitor = new TaskMonitor();
    taskMonitor.gatewayCallbackEnabled = true;

    // Mock the log file path
    taskMonitor.logFailedCallback = (payload) => {
      const failedCallback = {
        timestamp: new Date().toISOString(),
        payload
      };

      taskMonitor.failedCallbacks = taskMonitor.failedCallbacks || [];
      taskMonitor.failedCallbacks.push(failedCallback);

      // Write to test log file
      if (!fs.existsSync(TEST_LOG_DIR)) {
        fs.mkdirSync(TEST_LOG_DIR, { recursive: true });
      }
      fs.appendFileSync(FAILED_CALLBACK_LOG, JSON.stringify(failedCallback) + '\n');
    };
  });

  describe('Successful Callbacks', () => {
    test('should send callback on task started', async () => {
      const task = {
        id: 'task-123',
        name: 'Test Task',
        status: 'started',
        metadata: {
          source: 'gateway',
          workspace_id: 'workspace-1',
          project_id: 'project-1'
        },
        startedAt: Date.now()
      };

      await taskMonitor.notifyGateway(task, 'started', 0);

      expect(receivedCallbacks).toHaveLength(1);
      expect(receivedCallbacks[0]).toMatchObject({
        taskId: 'task-123',
        workspaceId: 'workspace-1',
        projectId: 'project-1',
        status: 'started',
        progress: 0,
        output: null,
        error: null
      });
      expect(receivedCallbacks[0].metadata).toBeDefined();
      expect(receivedCallbacks[0].timestamp).toBeDefined();
    });

    test('should send callback on task completed', async () => {
      const startTime = Date.now();
      const task = {
        id: 'task-456',
        name: 'Completed Task',
        status: 'completed',
        metadata: {
          source: 'gateway',
          workspace_id: 'workspace-1',
          project_id: 'project-1'
        },
        startedAt: startTime,
        completedAt: startTime + 5000,
        usage: {
          tokens: 1500
        },
        model: 'claude-sonnet-4'
      };

      await taskMonitor.notifyGateway(task, 'completed', 100, 'Task output here');

      expect(receivedCallbacks).toHaveLength(1);
      expect(receivedCallbacks[0]).toMatchObject({
        taskId: 'task-456',
        status: 'completed',
        progress: 100,
        output: 'Task output here',
        error: null
      });
      expect(receivedCallbacks[0].metadata.duration).toBeGreaterThan(0);
      expect(receivedCallbacks[0].metadata.tokensUsed).toBe(1500);
      expect(receivedCallbacks[0].metadata.model).toBe('claude-sonnet-4');
    });

    test('should send callback on task failed', async () => {
      const task = {
        id: 'task-789',
        name: 'Failed Task',
        status: 'failed',
        metadata: {
          source: 'gateway',
          workspace_id: 'workspace-1',
          project_id: 'project-1'
        },
        startedAt: Date.now(),
        completedAt: Date.now() + 1000
      };

      await taskMonitor.notifyGateway(task, 'failed', 50, null, 'Authentication error');

      expect(receivedCallbacks).toHaveLength(1);
      expect(receivedCallbacks[0]).toMatchObject({
        taskId: 'task-789',
        status: 'failed',
        progress: 50,
        output: null,
        error: 'Authentication error'
      });
    });

    test('should include correct metadata fields', async () => {
      const task = {
        id: 'task-metadata',
        name: 'Metadata Test',
        metadata: {
          source: 'gateway',
          workspace_id: 'ws-1',
          project_id: 'proj-1'
        },
        startedAt: Date.now(),
        completedAt: Date.now() + 3000,
        usage: {
          tokens: 2500
        },
        model: 'claude-opus-4'
      };

      await taskMonitor.notifyGateway(task, 'completed', 100);

      expect(receivedCallbacks[0].metadata).toMatchObject({
        duration: expect.any(Number),
        tokensUsed: 2500,
        model: 'claude-opus-4'
      });
    });
  });

  describe('Retry Logic', () => {
    test('should retry on failure with exponential backoff', async () => {
      shouldFailCallback = true;

      const task = {
        id: 'task-retry',
        name: 'Retry Test',
        metadata: {
          source: 'gateway',
          workspace_id: 'workspace-1',
          project_id: 'project-1'
        },
        startedAt: Date.now()
      };

      const startTime = Date.now();
      await taskMonitor.notifyGateway(task, 'started', 0);
      const duration = Date.now() - startTime;

      // Should have attempted 3 times (initial + 2 retries)
      expect(callbackAttempts.length).toBeGreaterThanOrEqual(3);

      // With exponential backoff: 0ms + 1000ms + 2000ms = ~3000ms minimum
      expect(duration).toBeGreaterThanOrEqual(3000);

      // No successful callbacks
      expect(receivedCallbacks).toHaveLength(0);
    });

    test('should succeed on second attempt', async () => {
      let attemptCount = 0;
      shouldFailCallback = true;

      // Override callback handler to succeed on second attempt
      const originalListener = mockGatewayServer.listeners('request')[0];
      mockGatewayServer.removeAllListeners('request');

      mockGatewayServer.on('request', (req, res) => {
        if (req.url === '/api/callback/task-status') {
          let body = '';
          req.on('data', chunk => { body += chunk.toString(); });
          req.on('end', () => {
            attemptCount++;
            const callback = JSON.parse(body);
            callbackAttempts.push({ attempt: attemptCount, callback });

            if (attemptCount === 1) {
              // Fail first attempt
              res.writeHead(500);
              res.end(JSON.stringify({ error: 'Server error' }));
            } else {
              // Succeed on subsequent attempts
              receivedCallbacks.push(callback);
              res.writeHead(200);
              res.end(JSON.stringify({ success: true }));
            }
          });
          return;
        }
        res.writeHead(404);
        res.end();
      });

      const task = {
        id: 'task-second-attempt',
        name: 'Second Attempt Test',
        metadata: {
          source: 'gateway',
          workspace_id: 'workspace-1',
          project_id: 'project-1'
        }
      };

      await taskMonitor.notifyGateway(task, 'started', 0);

      // Should have 2 attempts (1 failed, 1 succeeded)
      expect(callbackAttempts.length).toBe(2);
      expect(receivedCallbacks.length).toBe(1);

      // Restore original listener
      mockGatewayServer.removeAllListeners('request');
      mockGatewayServer.on('request', originalListener);
    });

    test('should use exponential backoff delays', async () => {
      shouldFailCallback = true;

      const task = {
        id: 'task-backoff',
        metadata: {
          source: 'gateway',
          workspace_id: 'workspace-1',
          project_id: 'project-1'
        }
      };

      const timestamps = [];
      const originalFetch = global.fetch;
      global.fetch = async (...args) => {
        timestamps.push(Date.now());
        return originalFetch(...args);
      };

      await taskMonitor.notifyGateway(task, 'started', 0);

      global.fetch = originalFetch;

      // Check delays between attempts
      if (timestamps.length >= 2) {
        const delay1 = timestamps[1] - timestamps[0];
        expect(delay1).toBeGreaterThanOrEqual(950); // ~1000ms
      }
      if (timestamps.length >= 3) {
        const delay2 = timestamps[2] - timestamps[1];
        expect(delay2).toBeGreaterThanOrEqual(1950); // ~2000ms
      }
    });
  });

  describe('Failed Callback Logging', () => {
    test('should log failed callbacks to file after max retries', async () => {
      shouldFailCallback = true;

      const task = {
        id: 'task-failed-log',
        name: 'Failed Logging Test',
        metadata: {
          source: 'gateway',
          workspace_id: 'workspace-1',
          project_id: 'project-1'
        },
        startedAt: Date.now()
      };

      await taskMonitor.notifyGateway(task, 'failed', 0, null, 'Test error');

      // Check in-memory failed callbacks
      expect(taskMonitor.failedCallbacks).toBeDefined();
      expect(taskMonitor.failedCallbacks.length).toBeGreaterThan(0);

      // Check log file
      expect(fs.existsSync(FAILED_CALLBACK_LOG)).toBe(true);
      const logContent = fs.readFileSync(FAILED_CALLBACK_LOG, 'utf-8');
      const logLines = logContent.trim().split('\n');
      expect(logLines.length).toBeGreaterThan(0);

      const loggedCallback = JSON.parse(logLines[0]);
      expect(loggedCallback.payload.taskId).toBe('task-failed-log');
      expect(loggedCallback.payload.status).toBe('failed');
      expect(loggedCallback.timestamp).toBeDefined();
    });

    test('should log multiple failed callbacks', async () => {
      shouldFailCallback = true;

      const tasks = [
        { id: 'task-1', metadata: { source: 'gateway' }, startedAt: Date.now() },
        { id: 'task-2', metadata: { source: 'gateway' }, startedAt: Date.now() },
        { id: 'task-3', metadata: { source: 'gateway' }, startedAt: Date.now() }
      ];

      for (const task of tasks) {
        await taskMonitor.notifyGateway(task, 'failed', 0);
      }

      const logContent = fs.readFileSync(FAILED_CALLBACK_LOG, 'utf-8');
      const logLines = logContent.trim().split('\n');
      expect(logLines.length).toBe(3);

      const taskIds = logLines.map(line => JSON.parse(line).payload.taskId);
      expect(taskIds).toContain('task-1');
      expect(taskIds).toContain('task-2');
      expect(taskIds).toContain('task-3');
    });
  });

  describe('Callback Payload Validation', () => {
    test('should include all required fields in callback', async () => {
      const task = {
        id: 'task-validation',
        metadata: {
          source: 'gateway',
          workspace_id: 'ws-123',
          project_id: 'proj-456'
        },
        startedAt: Date.now()
      };

      await taskMonitor.notifyGateway(task, 'running', 50);

      const callback = receivedCallbacks[0];
      expect(callback).toHaveProperty('taskId');
      expect(callback).toHaveProperty('workspaceId');
      expect(callback).toHaveProperty('projectId');
      expect(callback).toHaveProperty('status');
      expect(callback).toHaveProperty('progress');
      expect(callback).toHaveProperty('output');
      expect(callback).toHaveProperty('error');
      expect(callback).toHaveProperty('timestamp');
      expect(callback).toHaveProperty('metadata');
      expect(callback.metadata).toHaveProperty('duration');
      expect(callback.metadata).toHaveProperty('tokensUsed');
      expect(callback.metadata).toHaveProperty('model');
    });

    test('should use default values for missing metadata', async () => {
      const task = {
        id: 'task-defaults',
        metadata: {
          source: 'gateway'
        },
        startedAt: Date.now()
      };

      await taskMonitor.notifyGateway(task, 'started', 0);

      const callback = receivedCallbacks[0];
      expect(callback.workspaceId).toBe('test-workspace'); // From env
      expect(callback.projectId).toBe('test-project'); // From env
      expect(callback.metadata.tokensUsed).toBe(0);
      expect(callback.metadata.model).toBe('claude-sonnet-4');
    });
  });
});

import { jest, describe, it, beforeEach, afterEach, expect } from '@jest/globals';

// Mock node-fetch to use global.fetch
jest.unstable_mockModule('node-fetch', () => ({
  default: jest.fn().mockImplementation((...args) => global.fetch(...args))
}));

const { TelegramNotifier } = await import('../src/telegram-notifier.js');
const { LarkNotifier } = await import('../src/lark-notifier.js');
const { config } = await import('../src/config.js');

describe('Gateway Callback Routing', () => {
  let originalGatewayConfig;
  let originalFetch;
  let originalGatewayToken;

  beforeEach(() => {
    // Save original config, fetch and env
    originalGatewayConfig = { ...config.gateway };
    originalFetch = global.fetch;
    originalGatewayToken = process.env.GATEWAY_TOKEN;

    // Enable gateway mode for tests
    config.gateway.enabled = true;
    config.gateway.url = 'http://test-gateway:6555';
    process.env.GATEWAY_TOKEN = 'test-secure-token';
    config.gateway.instanceId = 'test-instance';
  });

  afterEach(() => {
    // Restore original config (excluding read-only token getter)
    const { token, ...rest } = originalGatewayConfig;
    Object.assign(config.gateway, rest);
    global.fetch = originalFetch;
    if (originalGatewayToken === undefined) {
      delete process.env.GATEWAY_TOKEN;
    } else {
      process.env.GATEWAY_TOKEN = originalGatewayToken;
    }
  });

  describe('Telegram Callback Routing', () => {
    it('should route message through gateway when enabled', async () => {
      let capturedRequest = null;

      // Mock fetch to capture gateway request
      global.fetch = jest.fn().mockImplementation(async (url, options) => {
        capturedRequest = { url, options };
        return {
          ok: true,
          json: async () => ({ success: true, messageId: '123' })
        };
      });

      const notifier = new TelegramNotifier();
      const chatId = '123456';
      const text = 'Test message';

      await notifier.sendMessage(chatId, text, { parse_mode: 'Markdown' });

      expect(capturedRequest).toBeTruthy();
      expect(capturedRequest.url).toBe('http://test-gateway:6555/api/callback/message');
      expect(capturedRequest.options.headers['x-gateway-token']).toBe('test-secure-token');
      expect(capturedRequest.options.headers['x-instance-id']).toBe('test-instance');

      const payload = JSON.parse(capturedRequest.options.body);
      expect(payload.platform).toBe('telegram');
      expect(payload.chatId).toBe(chatId);
      expect(payload.message.text).toBe(text);
    });

    it('should fallback to direct send on gateway failure', async () => {
      let directSendCalled = false;

      // Mock fetch to simulate gateway failure
      global.fetch = jest.fn().mockImplementation(async () => {
        throw new Error('Gateway unavailable');
      });

      const notifier = new TelegramNotifier();
      // Mock the direct API call
      notifier.api = {
        sendMessage: jest.fn().mockImplementation(async () => {
          directSendCalled = true;
          return { ok: true };
        })
      };

      const chatId = '123456';
      const text = 'Test message';

      await notifier.sendMessage(chatId, text);

      expect(directSendCalled).toBe(true);
    });

    it('should send edit action through gateway', async () => {
      let capturedPayload = null;

      global.fetch = jest.fn().mockImplementation(async (url, options) => {
        capturedPayload = JSON.parse(options.body);
        return {
          ok: true,
          json: async () => ({ success: true })
        };
      });

      const notifier = new TelegramNotifier();
      await notifier.editMessage('123456', '789', 'Updated text', { parse_mode: 'Markdown' });

      expect(capturedPayload).toBeTruthy();
      expect(capturedPayload.message.type).toBe('edit');
      expect(capturedPayload.message.options.messageId).toBe('789');
    });

    it('should handle gateway timeout gracefully', async () => {
      global.fetch = jest.fn().mockImplementation(async () => {
        // Simulate timeout by waiting longer than timeout value
        await new Promise(resolve => setTimeout(resolve, 1100)); // Reduced timeout for test speed
        throw new Error('Timeout');
      });

      const notifier = new TelegramNotifier();
      notifier.api = {
        sendMessage: jest.fn().mockImplementation(async () => ({ ok: true }))
      };

      // Should not throw, should fallback
      const result = await notifier.sendMessage('123456', 'Test');
      expect(result).toBeTruthy();
    });
  });

  describe('Lark Callback Routing', () => {
    it('should route message through gateway when enabled', async () => {
      let capturedRequest = null;

      // Mock fetch to capture gateway request
      global.fetch = jest.fn().mockImplementation(async (url, options) => {
        capturedRequest = { url, options };
        return {
          ok: true,
          json: async () => ({ success: true })
        };
      });

      const notifier = new LarkNotifier();
      const message = {
        msg_type: 'text',
        content: { text: 'Test message' }
      };

      await notifier.sendMessage(message, 'test-chat-id');

      expect(capturedRequest).toBeTruthy();
      const payload = JSON.parse(capturedRequest.options.body);
      expect(payload.platform).toBe('lark');
    });

    it('should fallback to direct send on gateway failure', async () => {
      global.fetch = jest.fn().mockImplementation(async (url) => {
        // Fail gateway callback
        if (url.includes('/api/callback/message')) {
          throw new Error('Gateway unavailable');
        }
        // Allow fallback webhook call
        return {
          ok: true,
          json: async () => ({ code: 0 })
        };
      });

      const notifier = new LarkNotifier();
      notifier.webhookUrl = 'http://lark-webhook';
      notifier.groupChatId = 'test-group';

      const message = {
        msg_type: 'text',
        content: { text: 'Test message' }
      };

      // Should fallback without throwing
      const result = await notifier.sendMessage(message);
      expect(result === undefined || result === null || result || !result).toBeTruthy();
    });
  });

  describe('Gateway Request Format', () => {
    it('should include all required fields in gateway request', async () => {
      let capturedPayload = null;

      global.fetch = jest.fn().mockImplementation(async (url, options) => {
        capturedPayload = JSON.parse(options.body);
        return {
          ok: true,
          json: async () => ({ success: true })
        };
      });

      const notifier = new TelegramNotifier();
      await notifier.sendMessage('123456', 'Test', { reply_markup: {} });

      expect(capturedPayload.platform).toBeTruthy();
      expect(capturedPayload.chatId).toBeTruthy();
      expect(capturedPayload.message).toBeTruthy();
      expect(capturedPayload.instanceId).toBeTruthy();
      expect(capturedPayload.timestamp).toBeTruthy();
    });

    it('should include message options in gateway request', async () => {
      let capturedPayload = null;

      global.fetch = jest.fn().mockImplementation(async (url, options) => {
        capturedPayload = JSON.parse(options.body);
        return {
          ok: true,
          json: async () => ({ success: true })
        };
      });

      const notifier = new TelegramNotifier();
      const options = {
        parse_mode: 'Markdown',
        reply_markup: { inline_keyboard: [[]] }
      };

      await notifier.sendMessage('123456', 'Test', options);

      expect(capturedPayload.message.parse_mode).toBe('Markdown');
      expect(capturedPayload.message.reply_markup).toBeTruthy();
    });
  });

  describe('Gateway Error Handling', () => {
    it('should handle non-OK HTTP response', async () => {
      global.fetch = jest.fn().mockImplementation(async () => ({
        ok: false,
        status: 500,
        text: async () => 'Internal Server Error'
      }));

      const notifier = new TelegramNotifier();
      notifier.api = {
        sendMessage: jest.fn().mockImplementation(async () => ({ ok: true }))
      };

      // Should fallback without throwing
      await notifier.sendMessage('123456', 'Test');
    });

    it('should handle network errors', async () => {
      global.fetch = jest.fn().mockImplementation(async () => {
        throw new Error('Network error');
      });

      const notifier = new TelegramNotifier();
      notifier.api = {
        sendMessage: jest.fn().mockImplementation(async () => ({ ok: true }))
      };

      // Should fallback without throwing
      await notifier.sendMessage('123456', 'Test');
    });

    it('should handle malformed gateway response', async () => {
      global.fetch = jest.fn().mockImplementation(async () => ({
        ok: true,
        json: async () => {
          throw new Error('Invalid JSON');
        }
      }));

      const notifier = new TelegramNotifier();
      notifier.api = {
        sendMessage: jest.fn().mockImplementation(async () => ({ ok: true }))
      };

      // Should fallback without throwing
      await notifier.sendMessage('123456', 'Test');
    });
  });
});
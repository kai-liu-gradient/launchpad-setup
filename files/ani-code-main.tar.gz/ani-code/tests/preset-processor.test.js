import { describe, it, expect, beforeEach, afterEach, jest } from '@jest/globals';
import { processPresets } from '../src/preset-processor.js';
import { existsSync, readFileSync, readdirSync, mkdirSync, writeFileSync, rmSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const testPresetsDir = join(__dirname, '..', 'src', 'presets-test');

describe('Preset Processor', () => {
  beforeEach(() => {
    // Create test presets directory
    if (!existsSync(testPresetsDir)) {
      mkdirSync(testPresetsDir, { recursive: true });
    }

    // Create test preset files
    writeFileSync(
      join(testPresetsDir, 'test.md'),
      '# Test Preset\n\nThis is a test preset content.'
    );
    writeFileSync(
      join(testPresetsDir, 'api.md'),
      '# API Configuration\n\nAPI endpoint: /api/v1'
    );
    writeFileSync(
      join(testPresetsDir, 'database.md'),
      '# Database Setup\n\nConnection string here'
    );
  });

  afterEach(() => {
    // Clean up test directory
    if (existsSync(testPresetsDir)) {
      rmSync(testPresetsDir, { recursive: true, force: true });
    }
  });

  describe('processPresets', () => {
    it('should return original text when no presets found', async () => {
      const result = await processPresets('Just some text');
      expect(result.text).toBe('Just some text');
      expect(result.presets).toEqual([]);
    });

    it('should handle null or undefined input', async () => {
      const result1 = await processPresets(null);
      expect(result1.text).toBeNull();
      expect(result1.presets).toEqual([]);

      const result2 = await processPresets(undefined);
      expect(result2.text).toBeUndefined();
      expect(result2.presets).toEqual([]);
    });

    it('should handle empty string', async () => {
      const result = await processPresets('');
      expect(result.text).toBe('');
      expect(result.presets).toEqual([]);
    });

    it('should detect @preset.md syntax', async () => {
      const input = 'Use @test.md for this task';
      const matches = input.match(/@([\w*-]+)\.md/g);
      expect(matches).toContain('@test.md');
    });

    it('should extract preset pattern correctly', async () => {
      const match = '@test.md';
      const pattern = match.replace('@', '').replace('.md', '');
      expect(pattern).toBe('test');
    });

    it('should handle wildcard patterns', async () => {
      const pattern = 'test*';
      const regexPattern = pattern.replace(/\*/g, '.*');
      const regex = new RegExp(`^${regexPattern}$`);
      expect(regex.test('test')).toBe(true);
      expect(regex.test('test-file')).toBe(true);
      expect(regex.test('other')).toBe(false);
    });

    it('should handle multiple preset matches', async () => {
      const input = 'Use @test.md and @api.md';
      const matches = input.match(/@([\w*-]+)\.md/g);
      expect(matches).toHaveLength(2);
      expect(matches).toContain('@test.md');
      expect(matches).toContain('@api.md');
    });

    it('should extract heading as description', () => {
      const content = '# Test Preset\n\nContent here';
      const headingMatch = content.match(/^#\s+(.+)$/m);
      const description = headingMatch ? headingMatch[1].trim() : 'fallback';
      expect(description).toBe('Test Preset');
    });

    it('should handle content without heading', () => {
      const content = 'Just content without heading';
      const headingMatch = content.match(/^#\s+(.+)$/m);
      const description = headingMatch ? headingMatch[1].trim() : 'fallback';
      expect(description).toBe('fallback');
    });

    it('should remove preset patterns from user text', () => {
      let userText = 'Use @test.md for setup';
      const match = '@test.md';
      userText = userText.replace(match, '');
      userText = userText.trim();
      expect(userText).toBe('Use  for setup');
    });

    it('should combine user text with preset content', () => {
      const userText = 'Configure the API';
      const presetContent = '# API Config\nEndpoint: /api';
      const result = `${userText}\n\n---\n# Reference Template Content\n${presetContent}`;
      expect(result).toContain('Configure the API');
      expect(result).toContain('# API Config');
      expect(result).toContain('Endpoint: /api');
    });

    it('should use XML tags for long content', () => {
      const userText = 'Setup task';
      const longContent = Array(25).fill('Line of content').join('\n');
      const presetName = 'test';

      if (longContent.split('\n').length > 20) {
        const result = `${userText}\n\n<${presetName}>\n${longContent}\n</${presetName}>`;
        expect(result).toContain(`<${presetName}>`);
        expect(result).toContain(`</${presetName}>`);
      }
    });

    it('should handle preset content only (no user text)', () => {
      const presetContent = '# Preset\nContent';
      const userText = '';
      const result = presetContent;
      expect(result).toBe('# Preset\nContent');
    });

    it('should deduplicate preset files', () => {
      const matchedPresets = new Set();
      const file1 = 'test.md';

      if (!matchedPresets.has(file1)) {
        matchedPresets.add(file1);
      }

      // Try to add again
      if (!matchedPresets.has(file1)) {
        matchedPresets.add(file1);
      }

      expect(matchedPresets.size).toBe(1);
    });

    it('should create preset metadata', () => {
      const metadata = {
        file: '@test.md',
        description: 'Test Preset'
      };
      expect(metadata.file).toBe('@test.md');
      expect(metadata.description).toBe('Test Preset');
    });

    it('should handle multiple presets with header separation', () => {
      const matchedPresetsSize = 3;
      const file = 'test.md';
      let content = '';

      if (matchedPresetsSize > 1) {
        content = `\n\n# From preset: ${file}\n`;
      }

      expect(content).toContain('# From preset:');
      expect(content).toContain(file);
    });
  });

  describe('Pattern Matching', () => {
    it('should match exact preset name', () => {
      const pattern = 'api';
      const filename = 'api.md';
      const exactFile = `${pattern}.md`;
      expect(exactFile).toBe(filename);
    });

    it('should match wildcard patterns correctly', () => {
      const pattern = 'test*';
      const regex = new RegExp(`^${pattern.replace(/\*/g, '.*')}$`);
      const files = ['test.md', 'test-api.md', 'test-db.md', 'other.md'];
      const matches = files.filter(f => regex.test(f.replace('.md', '')));
      expect(matches.length).toBeGreaterThan(0);
      expect(matches).toContain('test.md');
    });

    it('should convert wildcard to regex correctly', () => {
      const pattern = 'api*';
      const regexPattern = pattern.replace(/\*/g, '.*');
      expect(regexPattern).toBe('api.*');
    });
  });

  describe('Content Processing', () => {
    it('should determine if content is long', () => {
      const shortContent = 'Short content\nJust two lines';
      const longContent = Array(25).fill('Line').join('\n');

      expect(shortContent.split('\n').length).toBeLessThan(20);
      expect(longContent.split('\n').length).toBeGreaterThan(20);
    });

    it('should generate proper XML tags for single preset', () => {
      const presetName = 'config';
      const content = 'Content here';
      const tagged = `<${presetName}>\n${content}\n</${presetName}>`;
      expect(tagged).toBe('<config>\nContent here\n</config>');
    });

    it('should generate reference-presets tag for multiple', () => {
      const presetNames = ['api', 'db', 'config'];
      const content = 'Combined content';
      const tagged = `<reference-presets>\n${content}\n</reference-presets>`;
      expect(tagged).toContain('<reference-presets>');
      expect(tagged).toContain('</reference-presets>');
    });
  });

  describe('Edge Cases', () => {
    it('should handle text with multiple spaces', async () => {
      const result = await processPresets('Text   with   spaces');
      expect(result.text).toBe('Text   with   spaces');
    });

    it('should handle special characters in text', async () => {
      const result = await processPresets('Special chars: !@#$%^&*()');
      expect(result.text).toContain('Special chars:');
    });

    it('should handle newlines in input', async () => {
      const result = await processPresets('Line 1\nLine 2\nLine 3');
      expect(result.text).toContain('\n');
    });

    it('should handle preset pattern at start of text', async () => {
      const input = '@test.md additional text';
      const matches = input.match(/@([\w*-]+)\.md/g);
      expect(matches).toContain('@test.md');
    });

    it('should handle preset pattern at end of text', async () => {
      const input = 'additional text @test.md';
      const matches = input.match(/@([\w*-]+)\.md/g);
      expect(matches).toContain('@test.md');
    });

    it('should handle hyphens in preset names', async () => {
      const input = '@test-api.md';
      const matches = input.match(/@([\w*-]+)\.md/g);
      expect(matches).toContain('@test-api.md');
    });

    it('should handle numbers in preset names', async () => {
      const input = '@test123.md';
      const matches = input.match(/@([\w*-]+)\.md/g);
      expect(matches).toContain('@test123.md');
    });
  });
});

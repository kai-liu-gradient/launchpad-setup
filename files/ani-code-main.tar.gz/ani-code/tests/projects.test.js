import { jest } from '@jest/globals';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { mkdirSync, writeFileSync, rmSync, existsSync, readFileSync } from 'fs';

// Import the projects module functions
import {
  MANIFEST_TYPES,
  DEFAULT_EXCLUSIONS,
  SCHEMA_VERSION,
  scanDirectory,
  incrementVersion,
  updateManifestVersion,
  findProject,
  loadRegistry,
  saveRegistry
} from '../src/commands/projects.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

describe('Projects Command Module', () => {
  const testDir = join(__dirname, 'test-projects-workspace');
  const projectsDir = join(testDir, '.ani-code', 'projects');

  beforeEach(() => {
    // Create test directory structure
    mkdirSync(testDir, { recursive: true });
    mkdirSync(projectsDir, { recursive: true });
  });

  afterEach(() => {
    // Cleanup test directory
    if (existsSync(testDir)) {
      rmSync(testDir, { recursive: true, force: true });
    }
  });

  describe('MANIFEST_TYPES', () => {
    test('should have all expected manifest types', () => {
      const expectedTypes = [
        'package.json',
        'pyproject.toml',
        'setup.py',
        'requirements.txt',
        'Pipfile',
        'go.mod',
        'Cargo.toml',
        'pom.xml',
        'build.gradle',
        'build.gradle.kts',
        'composer.json'
      ];

      for (const type of expectedTypes) {
        expect(MANIFEST_TYPES[type]).toBeDefined();
        expect(MANIFEST_TYPES[type].techstack).toBeDefined();
        expect(MANIFEST_TYPES[type].parser).toBeDefined();
      }
    });

    test('should have correct techstack mapping', () => {
      expect(MANIFEST_TYPES['package.json'].techstack).toBe('node');
      expect(MANIFEST_TYPES['pyproject.toml'].techstack).toBe('python');
      expect(MANIFEST_TYPES['go.mod'].techstack).toBe('go');
      expect(MANIFEST_TYPES['Cargo.toml'].techstack).toBe('rust');
      expect(MANIFEST_TYPES['pom.xml'].techstack).toBe('java');
      expect(MANIFEST_TYPES['composer.json'].techstack).toBe('php');
    });

    test('should have priority ordering', () => {
      // package.json should have higher priority than pyproject.toml
      expect(MANIFEST_TYPES['package.json'].priority).toBeLessThan(
        MANIFEST_TYPES['pyproject.toml'].priority
      );
    });
  });

  describe('DEFAULT_EXCLUSIONS', () => {
    test('should include common build and dependency directories', () => {
      expect(DEFAULT_EXCLUSIONS).toContain('node_modules');
      expect(DEFAULT_EXCLUSIONS).toContain('.git');
      expect(DEFAULT_EXCLUSIONS).toContain('dist');
      expect(DEFAULT_EXCLUSIONS).toContain('build');
      expect(DEFAULT_EXCLUSIONS).toContain('vendor');
      expect(DEFAULT_EXCLUSIONS).toContain('__pycache__');
      expect(DEFAULT_EXCLUSIONS).toContain('.ani-code');
    });

    test('should include IDE and environment directories', () => {
      expect(DEFAULT_EXCLUSIONS).toContain('.venv');
      expect(DEFAULT_EXCLUSIONS).toContain('venv');
      expect(DEFAULT_EXCLUSIONS).toContain('.idea');
      expect(DEFAULT_EXCLUSIONS).toContain('.vscode');
    });
  });

  describe('SCHEMA_VERSION', () => {
    test('should be defined as 1.0.0', () => {
      expect(SCHEMA_VERSION).toBe('1.0.0');
    });
  });

  describe('scanDirectory', () => {
    test('should detect package.json in root directory', () => {
      const packageJson = {
        name: 'test-package',
        version: '1.0.0',
        description: 'Test package'
      };
      writeFileSync(join(testDir, 'package.json'), JSON.stringify(packageJson));

      const projects = scanDirectory(testDir, testDir, DEFAULT_EXCLUSIONS, 5);

      expect(projects).toHaveLength(1);
      expect(projects[0].name).toBe('test-package');
      expect(projects[0].version).toBe('1.0.0');
      expect(projects[0].techstack).toBe('node');
      expect(projects[0].manifestType).toBe('package.json');
    });

    test('should detect nested projects', () => {
      // Root project
      writeFileSync(join(testDir, 'package.json'), JSON.stringify({
        name: 'root-package',
        version: '1.0.0'
      }));

      // Nested package
      const nestedDir = join(testDir, 'packages', 'sub-package');
      mkdirSync(nestedDir, { recursive: true });
      writeFileSync(join(nestedDir, 'package.json'), JSON.stringify({
        name: 'sub-package',
        version: '2.0.0'
      }));

      const projects = scanDirectory(testDir, testDir, DEFAULT_EXCLUSIONS, 5);

      expect(projects).toHaveLength(2);
      const rootProject = projects.find(p => p.name === 'root-package');
      const subProject = projects.find(p => p.name === 'sub-package');
      expect(rootProject).toBeDefined();
      expect(subProject).toBeDefined();
      expect(subProject.path).toBe('packages/sub-package');
    });

    test('should respect depth limit', () => {
      // Create deeply nested project
      const deepDir = join(testDir, 'a', 'b', 'c', 'd', 'e', 'f');
      mkdirSync(deepDir, { recursive: true });
      writeFileSync(join(deepDir, 'package.json'), JSON.stringify({
        name: 'deep-package',
        version: '1.0.0'
      }));

      // Root project
      writeFileSync(join(testDir, 'package.json'), JSON.stringify({
        name: 'root-package',
        version: '1.0.0'
      }));

      // Scan with depth 3
      const projects = scanDirectory(testDir, testDir, DEFAULT_EXCLUSIONS, 3);

      // Should find root but not the deeply nested package
      expect(projects.length).toBe(1);
      expect(projects[0].name).toBe('root-package');
    });

    test('should exclude specified directories', () => {
      // Create package in node_modules (should be excluded)
      const nodeModulesDir = join(testDir, 'node_modules', 'some-package');
      mkdirSync(nodeModulesDir, { recursive: true });
      writeFileSync(join(nodeModulesDir, 'package.json'), JSON.stringify({
        name: 'some-package',
        version: '1.0.0'
      }));

      // Root project
      writeFileSync(join(testDir, 'package.json'), JSON.stringify({
        name: 'root-package',
        version: '1.0.0'
      }));

      const projects = scanDirectory(testDir, testDir, DEFAULT_EXCLUSIONS, 5);

      expect(projects).toHaveLength(1);
      expect(projects[0].name).toBe('root-package');
    });

    test('should detect pyproject.toml', () => {
      const pyproject = `
[project]
name = "my-python-project"
version = "0.1.0"
description = "A Python project"
`;
      writeFileSync(join(testDir, 'pyproject.toml'), pyproject);

      const projects = scanDirectory(testDir, testDir, DEFAULT_EXCLUSIONS, 5);

      expect(projects).toHaveLength(1);
      expect(projects[0].name).toBe('my-python-project');
      expect(projects[0].version).toBe('0.1.0');
      expect(projects[0].techstack).toBe('python');
    });

    test('should detect go.mod', () => {
      const goMod = `module github.com/test/myproject

go 1.21

require (
    github.com/some/dep v1.0.0
)
`;
      writeFileSync(join(testDir, 'go.mod'), goMod);

      const projects = scanDirectory(testDir, testDir, DEFAULT_EXCLUSIONS, 5);

      expect(projects).toHaveLength(1);
      expect(projects[0].name).toBe('myproject');
      expect(projects[0].techstack).toBe('go');
    });

    test('should detect Cargo.toml', () => {
      const cargoToml = `
[package]
name = "my-rust-project"
version = "0.2.0"
description = "A Rust project"
`;
      writeFileSync(join(testDir, 'Cargo.toml'), cargoToml);

      const projects = scanDirectory(testDir, testDir, DEFAULT_EXCLUSIONS, 5);

      expect(projects).toHaveLength(1);
      expect(projects[0].name).toBe('my-rust-project');
      expect(projects[0].version).toBe('0.2.0');
      expect(projects[0].techstack).toBe('rust');
    });

    test('should detect pom.xml', () => {
      const pomXml = `<?xml version="1.0" encoding="UTF-8"?>
<project>
  <modelVersion>4.0.0</modelVersion>
  <groupId>com.example</groupId>
  <artifactId>my-java-project</artifactId>
  <version>1.0.0-SNAPSHOT</version>
  <name>My Java Project</name>
</project>
`;
      writeFileSync(join(testDir, 'pom.xml'), pomXml);

      const projects = scanDirectory(testDir, testDir, DEFAULT_EXCLUSIONS, 5);

      expect(projects).toHaveLength(1);
      expect(projects[0].name).toBe('my-java-project');
      expect(projects[0].version).toBe('1.0.0-SNAPSHOT');
      expect(projects[0].techstack).toBe('java');
    });

    test('should detect composer.json', () => {
      const composerJson = {
        name: 'vendor/my-php-project',
        version: '1.2.3',
        description: 'A PHP project'
      };
      writeFileSync(join(testDir, 'composer.json'), JSON.stringify(composerJson));

      const projects = scanDirectory(testDir, testDir, DEFAULT_EXCLUSIONS, 5);

      expect(projects).toHaveLength(1);
      expect(projects[0].name).toBe('vendor/my-php-project');
      expect(projects[0].version).toBe('1.2.3');
      expect(projects[0].techstack).toBe('php');
    });

    test('should detect multiple manifest types in same directory', () => {
      // Create both package.json and pyproject.toml
      writeFileSync(join(testDir, 'package.json'), JSON.stringify({
        name: 'fullstack-app',
        version: '1.0.0'
      }));
      writeFileSync(join(testDir, 'pyproject.toml'), `
[project]
name = "fullstack-app-python"
version = "1.0.0"
`);

      const projects = scanDirectory(testDir, testDir, DEFAULT_EXCLUSIONS, 5);

      // Should pick the higher priority manifest (package.json)
      expect(projects).toHaveLength(1);
      expect(projects[0].manifestType).toBe('package.json');
    });

    test('should return empty array for directory with no projects', () => {
      // Just create an empty directory
      const emptyDir = join(testDir, 'empty');
      mkdirSync(emptyDir, { recursive: true });

      const projects = scanDirectory(emptyDir, emptyDir, DEFAULT_EXCLUSIONS, 5);

      expect(projects).toHaveLength(0);
    });
  });

  describe('incrementVersion', () => {
    test('should increment patch version', () => {
      expect(incrementVersion('1.0.0', 'patch')).toBe('1.0.1');
      expect(incrementVersion('1.2.3', 'patch')).toBe('1.2.4');
      expect(incrementVersion('0.0.9', 'patch')).toBe('0.0.10');
    });

    test('should increment minor version', () => {
      expect(incrementVersion('1.0.0', 'minor')).toBe('1.1.0');
      expect(incrementVersion('1.2.3', 'minor')).toBe('1.3.0');
      expect(incrementVersion('0.9.5', 'minor')).toBe('0.10.0');
    });

    test('should increment major version', () => {
      expect(incrementVersion('1.0.0', 'major')).toBe('2.0.0');
      expect(incrementVersion('1.2.3', 'major')).toBe('2.0.0');
      expect(incrementVersion('0.9.5', 'major')).toBe('1.0.0');
    });

    test('should preserve prerelease suffix', () => {
      expect(incrementVersion('1.0.0-beta', 'patch')).toBe('1.0.1-beta');
      expect(incrementVersion('2.0.0-alpha.1', 'minor')).toBe('2.1.0-alpha.1');
    });

    test('should default to patch increment', () => {
      expect(incrementVersion('1.0.0')).toBe('1.0.1');
    });

    test('should handle non-semver versions', () => {
      // Version ending with number should increment that number
      expect(incrementVersion('v1')).toBe('v2');
      expect(incrementVersion('release-5')).toBe('release-6');
    });

    test('should handle versions without numbers', () => {
      // Should append .0.1
      expect(incrementVersion('latest')).toBe('latest.0.1');
    });
  });

  describe('updateManifestVersion', () => {
    test('should update package.json version', () => {
      const packagePath = join(testDir, 'package.json');
      writeFileSync(packagePath, JSON.stringify({
        name: 'test-pkg',
        version: '1.0.0'
      }, null, 2));

      const success = updateManifestVersion(packagePath, 'package.json', '2.0.0');

      expect(success).toBe(true);
      const updated = JSON.parse(readFileSync(packagePath, 'utf8'));
      expect(updated.version).toBe('2.0.0');
    });

    test('should update pyproject.toml version', () => {
      const pyprojectPath = join(testDir, 'pyproject.toml');
      writeFileSync(pyprojectPath, `
[project]
name = "test-project"
version = "1.0.0"
`);

      const success = updateManifestVersion(pyprojectPath, 'pyproject.toml', '1.1.0');

      expect(success).toBe(true);
      const updated = readFileSync(pyprojectPath, 'utf8');
      expect(updated).toContain('version = "1.1.0"');
    });

    test('should update Cargo.toml version', () => {
      const cargoPath = join(testDir, 'Cargo.toml');
      writeFileSync(cargoPath, `
[package]
name = "my-crate"
version = "0.1.0"
`);

      const success = updateManifestVersion(cargoPath, 'Cargo.toml', '0.2.0');

      expect(success).toBe(true);
      const updated = readFileSync(cargoPath, 'utf8');
      expect(updated).toContain('version = "0.2.0"');
    });

    test('should update pom.xml version', () => {
      const pomPath = join(testDir, 'pom.xml');
      writeFileSync(pomPath, `<?xml version="1.0" encoding="UTF-8"?>
<project>
  <version>1.0.0</version>
</project>
`);

      const success = updateManifestVersion(pomPath, 'pom.xml', '1.0.1');

      expect(success).toBe(true);
      const updated = readFileSync(pomPath, 'utf8');
      expect(updated).toContain('<version>1.0.1</version>');
    });

    test('should update build.gradle version', () => {
      const gradlePath = join(testDir, 'build.gradle');
      writeFileSync(gradlePath, `
plugins {
    id 'java'
}

version = '1.0.0'
group = 'com.example'
`);

      const success = updateManifestVersion(gradlePath, 'build.gradle', '1.1.0');

      expect(success).toBe(true);
      const updated = readFileSync(gradlePath, 'utf8');
      expect(updated).toContain("version = '1.1.0'");
    });

    test('should update composer.json version', () => {
      const composerPath = join(testDir, 'composer.json');
      writeFileSync(composerPath, JSON.stringify({
        name: 'vendor/package',
        version: '1.0.0'
      }, null, 2));

      const success = updateManifestVersion(composerPath, 'composer.json', '1.0.1');

      expect(success).toBe(true);
      const updated = JSON.parse(readFileSync(composerPath, 'utf8'));
      expect(updated.version).toBe('1.0.1');
    });

    test('should return false for unsupported manifest type', () => {
      const unknownPath = join(testDir, 'unknown.txt');
      writeFileSync(unknownPath, 'version=1.0.0');

      const success = updateManifestVersion(unknownPath, 'unknown.txt', '2.0.0');

      expect(success).toBe(false);
    });

    test('should return false when file does not exist', () => {
      const nonExistentPath = join(testDir, 'nonexistent.json');

      const success = updateManifestVersion(nonExistentPath, 'package.json', '1.0.0');

      expect(success).toBe(false);
    });
  });

  describe('findProject', () => {
    const mockRegistry = {
      projects: [
        { id: 'my-package', name: 'my-package', version: '1.0.0' },
        { id: 'another-pkg', name: 'Another Package', version: '2.0.0' },
        { id: 'packages-sub', name: 'sub-package', version: '0.1.0' }
      ]
    };

    test('should find project by exact id', () => {
      const project = findProject(mockRegistry, 'my-package');
      expect(project).toBeDefined();
      expect(project.name).toBe('my-package');
    });

    test('should find project by name (case-insensitive)', () => {
      const project = findProject(mockRegistry, 'ANOTHER PACKAGE');
      expect(project).toBeDefined();
      expect(project.id).toBe('another-pkg');
    });

    test('should return undefined for non-existent project', () => {
      const project = findProject(mockRegistry, 'nonexistent');
      expect(project).toBeUndefined();
    });

    test('should return null for null registry', () => {
      const project = findProject(null, 'my-package');
      expect(project).toBeNull();
    });

    test('should return null for registry without projects', () => {
      const project = findProject({}, 'my-package');
      expect(project).toBeNull();
    });
  });

  describe('saveRegistry and loadRegistry', () => {
    test('should save and load registry correctly', () => {
      const registry = {
        version: SCHEMA_VERSION,
        lastScan: new Date().toISOString(),
        workspacePath: testDir,
        scanDepth: 5,
        exclusions: DEFAULT_EXCLUSIONS,
        projectCount: 1,
        projects: [
          {
            id: 'test-project',
            name: 'test-project',
            version: '1.0.0',
            path: '.',
            manifestPath: 'package.json',
            manifestType: 'package.json',
            techstack: 'node'
          }
        ]
      };

      saveRegistry(testDir, registry);
      const loaded = loadRegistry(testDir);

      expect(loaded).not.toBeNull();
      expect(loaded.version).toBe(SCHEMA_VERSION);
      expect(loaded.projects).toHaveLength(1);
      expect(loaded.projects[0].name).toBe('test-project');
    });

    test('should return null for non-existent registry', () => {
      const nonExistentDir = join(testDir, 'nonexistent-dir');
      const loaded = loadRegistry(nonExistentDir);

      expect(loaded).toBeNull();
    });

    test('should return null for invalid JSON', () => {
      mkdirSync(projectsDir, { recursive: true });
      writeFileSync(join(projectsDir, 'registry.json'), 'invalid json{');

      const loaded = loadRegistry(testDir);

      expect(loaded).toBeNull();
    });
  });

  describe('Exclusion patterns', () => {
    test('should exclude directories matching simple patterns', () => {
      // Create a build directory with a package.json (should be excluded)
      const buildDir = join(testDir, 'build');
      mkdirSync(buildDir, { recursive: true });
      writeFileSync(join(buildDir, 'package.json'), JSON.stringify({
        name: 'build-artifact',
        version: '1.0.0'
      }));

      // Create a regular package
      writeFileSync(join(testDir, 'package.json'), JSON.stringify({
        name: 'main-package',
        version: '1.0.0'
      }));

      const projects = scanDirectory(testDir, testDir, DEFAULT_EXCLUSIONS, 5);

      expect(projects).toHaveLength(1);
      expect(projects[0].name).toBe('main-package');
    });

    test('should handle custom exclusion patterns', () => {
      // Create a custom directory that should be excluded
      const customDir = join(testDir, 'custom-exclude');
      mkdirSync(customDir, { recursive: true });
      writeFileSync(join(customDir, 'package.json'), JSON.stringify({
        name: 'custom-package',
        version: '1.0.0'
      }));

      // Create a regular package
      writeFileSync(join(testDir, 'package.json'), JSON.stringify({
        name: 'main-package',
        version: '1.0.0'
      }));

      const customExclusions = [...DEFAULT_EXCLUSIONS, 'custom-exclude'];
      const projects = scanDirectory(testDir, testDir, customExclusions, 5);

      expect(projects).toHaveLength(1);
      expect(projects[0].name).toBe('main-package');
    });

    test('should support glob-like exclusion patterns', () => {
      // Create directories with pattern
      const tempDir = join(testDir, 'temp-cache');
      mkdirSync(tempDir, { recursive: true });
      writeFileSync(join(tempDir, 'package.json'), JSON.stringify({
        name: 'temp-package',
        version: '1.0.0'
      }));

      // Create a regular package
      writeFileSync(join(testDir, 'package.json'), JSON.stringify({
        name: 'main-package',
        version: '1.0.0'
      }));

      const customExclusions = [...DEFAULT_EXCLUSIONS, 'temp-*'];
      const projects = scanDirectory(testDir, testDir, customExclusions, 5);

      expect(projects).toHaveLength(1);
      expect(projects[0].name).toBe('main-package');
    });
  });

  describe('Monorepo support', () => {
    test('should detect packages in packages directory', () => {
      // Root package.json
      writeFileSync(join(testDir, 'package.json'), JSON.stringify({
        name: 'monorepo-root',
        version: '1.0.0',
        private: true,
        workspaces: ['packages/*']
      }));

      // Create packages directory with multiple packages
      const packagesDir = join(testDir, 'packages');
      mkdirSync(packagesDir, { recursive: true });

      const pkg1Dir = join(packagesDir, 'package-a');
      mkdirSync(pkg1Dir, { recursive: true });
      writeFileSync(join(pkg1Dir, 'package.json'), JSON.stringify({
        name: '@monorepo/package-a',
        version: '1.0.0'
      }));

      const pkg2Dir = join(packagesDir, 'package-b');
      mkdirSync(pkg2Dir, { recursive: true });
      writeFileSync(join(pkg2Dir, 'package.json'), JSON.stringify({
        name: '@monorepo/package-b',
        version: '2.0.0'
      }));

      const projects = scanDirectory(testDir, testDir, DEFAULT_EXCLUSIONS, 5);

      expect(projects).toHaveLength(3);
      const names = projects.map(p => p.name);
      expect(names).toContain('monorepo-root');
      expect(names).toContain('@monorepo/package-a');
      expect(names).toContain('@monorepo/package-b');
    });

    test('should handle apps and packages in turborepo structure', () => {
      // Root
      writeFileSync(join(testDir, 'package.json'), JSON.stringify({
        name: 'turborepo',
        version: '0.0.0'
      }));

      // apps/web
      const webDir = join(testDir, 'apps', 'web');
      mkdirSync(webDir, { recursive: true });
      writeFileSync(join(webDir, 'package.json'), JSON.stringify({
        name: '@repo/web',
        version: '1.0.0'
      }));

      // apps/docs
      const docsDir = join(testDir, 'apps', 'docs');
      mkdirSync(docsDir, { recursive: true });
      writeFileSync(join(docsDir, 'package.json'), JSON.stringify({
        name: '@repo/docs',
        version: '1.0.0'
      }));

      // packages/ui
      const uiDir = join(testDir, 'packages', 'ui');
      mkdirSync(uiDir, { recursive: true });
      writeFileSync(join(uiDir, 'package.json'), JSON.stringify({
        name: '@repo/ui',
        version: '0.1.0'
      }));

      const projects = scanDirectory(testDir, testDir, DEFAULT_EXCLUSIONS, 5);

      expect(projects).toHaveLength(4);
      const names = projects.map(p => p.name);
      expect(names).toContain('turborepo');
      expect(names).toContain('@repo/web');
      expect(names).toContain('@repo/docs');
      expect(names).toContain('@repo/ui');
    });
  });

  describe('Package metadata extraction', () => {
    test('should extract dependencies count from package.json', () => {
      const packageJson = {
        name: 'test-pkg',
        version: '1.0.0',
        dependencies: {
          'lodash': '^4.17.21',
          'axios': '^1.0.0'
        },
        devDependencies: {
          'jest': '^29.0.0',
          'typescript': '^5.0.0',
          'eslint': '^8.0.0'
        }
      };
      writeFileSync(join(testDir, 'package.json'), JSON.stringify(packageJson));

      const projects = scanDirectory(testDir, testDir, DEFAULT_EXCLUSIONS, 5);

      expect(projects).toHaveLength(1);
      expect(projects[0].metadata.dependencies).toBe(2);
      expect(projects[0].metadata.devDependencies).toBe(3);
    });

    test('should detect lock file presence', () => {
      writeFileSync(join(testDir, 'package.json'), JSON.stringify({
        name: 'test-pkg',
        version: '1.0.0'
      }));
      writeFileSync(join(testDir, 'package-lock.json'), '{}');

      const projects = scanDirectory(testDir, testDir, DEFAULT_EXCLUSIONS, 5);

      expect(projects).toHaveLength(1);
      expect(projects[0].metadata.hasLockFile).toBe(true);
    });

    test('should detect yarn.lock', () => {
      writeFileSync(join(testDir, 'package.json'), JSON.stringify({
        name: 'test-pkg',
        version: '1.0.0'
      }));
      writeFileSync(join(testDir, 'yarn.lock'), '');

      const projects = scanDirectory(testDir, testDir, DEFAULT_EXCLUSIONS, 5);

      expect(projects).toHaveLength(1);
      expect(projects[0].metadata.hasLockFile).toBe(true);
    });

    test('should extract scripts from package.json', () => {
      const packageJson = {
        name: 'test-pkg',
        version: '1.0.0',
        scripts: {
          'build': 'tsc',
          'test': 'jest',
          'start': 'node index.js'
        }
      };
      writeFileSync(join(testDir, 'package.json'), JSON.stringify(packageJson));

      const projects = scanDirectory(testDir, testDir, DEFAULT_EXCLUSIONS, 5);

      expect(projects).toHaveLength(1);
      expect(projects[0].metadata.scripts).toContain('build');
      expect(projects[0].metadata.scripts).toContain('test');
      expect(projects[0].metadata.scripts).toContain('start');
    });
  });
});

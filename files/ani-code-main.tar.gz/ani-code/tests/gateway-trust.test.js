import { jest, describe, it, beforeEach, afterEach, expect } from '@jest/globals';
import { APIHandlers } from '../src/api-handlers.js';
import { config } from '../src/config.js';

describe('Gateway Trust Verification', () => {
  let handlers;
  let originalGatewayConfig;
  let originalGatewayToken;

  beforeEach(() => {
    // Save original config and env
    originalGatewayConfig = { ...config.gateway };
    originalGatewayToken = process.env.GATEWAY_TOKEN;

    // Enable gateway mode and set token
    config.gateway.enabled = true;
    process.env.GATEWAY_TOKEN = 'test-secure-token';

    handlers = new APIHandlers();
  });

  afterEach(() => {
    // Restore original config (excluding read-only token getter)
    const { token, ...rest } = originalGatewayConfig;
    Object.assign(config.gateway, rest);
    if (originalGatewayToken === undefined) {
      delete process.env.GATEWAY_TOKEN;
    } else {
      process.env.GATEWAY_TOKEN = originalGatewayToken;
    }
  });

  it('should trust requests with valid gateway token', async () => {
    const req = {
      headers: {
        'x-gateway-token': 'test-secure-token'
      }
    };

    const isTrusted = await handlers.isRequestTrusted(req);
    expect(isTrusted).toBe(true);
  });

  it('should not trust requests with missing gateway token', async () => {
    const req = {
      headers: {}
    };

    const isTrusted = await handlers.isRequestTrusted(req);
    expect(isTrusted).toBe(false);
  });

  it('should not trust requests with invalid gateway token', async () => {
    const req = {
      headers: {
        'x-gateway-token': 'wrong-token'
      }
    };

    const isTrusted = await handlers.isRequestTrusted(req);
    expect(isTrusted).toBe(false);
  });

  it('should not trust requests when gateway mode is disabled', async () => {
    config.gateway.enabled = false;

    const req = {
      headers: {
        'x-gateway-token': 'test-secure-token'
      }
    };

    const isTrusted = await handlers.isRequestTrusted(req);
    expect(isTrusted).toBe(false);
  });

  it('should not trust requests when gateway token is not configured', async () => {
    process.env.GATEWAY_TOKEN = '';

    const req = {
      headers: {
        'x-gateway-token': 'test-secure-token'
      }
    };

    const isTrusted = await handlers.isRequestTrusted(req);
    expect(isTrusted).toBe(false);
  });
});

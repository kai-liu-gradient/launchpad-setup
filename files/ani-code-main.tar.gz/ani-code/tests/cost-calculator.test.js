import { describe, it, expect } from '@jest/globals';
import {
  calculateTokenCost,
  getModelPricing,
  getKnownModels,
  getKnownProviders,
  hasPricingData,
  MODEL_PRICING
} from '../src/providers/costCalculator.js';

describe('costCalculator', () => {
  describe('getKnownProviders', () => {
    it('should return all known provider IDs', () => {
      const providers = getKnownProviders();
      expect(providers).toContain('gemini');
      expect(providers).toContain('codex');
      expect(providers).toContain('cursor');
      expect(providers).toContain('claude');
      expect(providers.length).toBeGreaterThanOrEqual(4);
    });
  });

  describe('hasPricingData', () => {
    it('should return true for known providers', () => {
      expect(hasPricingData('gemini')).toBe(true);
      expect(hasPricingData('codex')).toBe(true);
      expect(hasPricingData('cursor')).toBe(true);
      expect(hasPricingData('claude')).toBe(true);
    });

    it('should return false for unknown providers', () => {
      expect(hasPricingData('unknown')).toBe(false);
      expect(hasPricingData('nonexistent')).toBe(false);
    });
  });

  describe('getKnownModels', () => {
    it('should return Gemini models', () => {
      const models = getKnownModels('gemini');
      expect(models).toContain('gemini-2.5-flash');
      expect(models).toContain('gemini-2.5-pro');
      expect(models).not.toContain('_default');
    });

    it('should return Codex/OpenAI models', () => {
      const models = getKnownModels('codex');
      expect(models).toContain('o3-mini');
      expect(models).toContain('gpt-4o');
      expect(models).not.toContain('_default');
    });

    it('should return empty array for unknown provider', () => {
      const models = getKnownModels('unknown');
      expect(models).toEqual([]);
    });
  });

  describe('getModelPricing', () => {
    it('should return exact match pricing for Gemini model', () => {
      const pricing = getModelPricing('gemini', 'gemini-2.5-flash');
      expect(pricing.input).toBe(0.15);
      expect(pricing.output).toBe(0.60);
    });

    it('should return exact match pricing for Codex model', () => {
      const pricing = getModelPricing('codex', 'o3-mini');
      expect(pricing.input).toBe(1.10);
      expect(pricing.output).toBe(4.40);
    });

    it('should return prefix match pricing for versioned models', () => {
      const pricing = getModelPricing('gemini', 'gemini-2.5-flash-preview-04-17');
      expect(pricing.input).toBeGreaterThan(0);
      expect(pricing.output).toBeGreaterThan(0);
    });

    it('should return default pricing for unknown models', () => {
      const pricing = getModelPricing('gemini', 'gemini-unknown-model');
      expect(pricing.input).toBe(MODEL_PRICING.gemini['_default'].input);
      expect(pricing.output).toBe(MODEL_PRICING.gemini['_default'].output);
    });

    it('should return zero pricing for unknown providers', () => {
      const pricing = getModelPricing('unknown', 'some-model');
      expect(pricing.input).toBe(0);
      expect(pricing.output).toBe(0);
    });

    it('should handle case-insensitive model names', () => {
      const pricing = getModelPricing('gemini', 'GEMINI-2.5-FLASH');
      expect(pricing.input).toBe(0.15);
      expect(pricing.output).toBe(0.60);
    });
  });

  describe('calculateTokenCost', () => {
    it('should calculate cost for Gemini with total tokens only', () => {
      const result = calculateTokenCost({
        providerId: 'gemini',
        modelId: 'gemini-2.5-flash',
        totalTokens: 1000000  // 1M tokens
      });

      // 30% input (300k tokens * 0.15/M = $0.045)
      // 70% output (700k tokens * 0.60/M = $0.42)
      // Total: $0.465
      expect(result.totalCost).toBeCloseTo(0.465, 3);
      expect(result.estimated).toBe(true);
      expect(result.estimatedRatio).toBe('30/70');
      expect(result.currency).toBe('USD');
    });

    it('should calculate cost for Codex with total tokens only', () => {
      const result = calculateTokenCost({
        providerId: 'codex',
        modelId: 'o3-mini',
        totalTokens: 100000  // 100k tokens
      });

      // 30% input (30k tokens * 1.10/M = $0.033)
      // 70% output (70k tokens * 4.40/M = $0.308)
      // Total: $0.341
      expect(result.totalCost).toBeCloseTo(0.341, 3);
      expect(result.estimated).toBe(true);
    });

    it('should calculate cost with separate input/output tokens', () => {
      const result = calculateTokenCost({
        providerId: 'gemini',
        modelId: 'gemini-2.5-flash',
        inputTokens: 500000,   // 500k input
        outputTokens: 500000   // 500k output
      });

      // Input: 500k * 0.15/M = $0.075
      // Output: 500k * 0.60/M = $0.30
      // Total: $0.375
      expect(result.inputCost).toBeCloseTo(0.075, 4);
      expect(result.outputCost).toBeCloseTo(0.30, 4);
      expect(result.totalCost).toBeCloseTo(0.375, 3);
      expect(result.estimated).toBe(true);
    });

    it('should include cached token cost', () => {
      const result = calculateTokenCost({
        providerId: 'gemini',
        modelId: 'gemini-2.5-flash',
        inputTokens: 400000,
        cachedTokens: 100000,  // 100k cached
        outputTokens: 500000
      });

      // Input: 400k * 0.15/M = $0.06
      // Cached: 100k * 0.0375/M = $0.00375
      // Output: 500k * 0.60/M = $0.30
      expect(result.cachedCost).toBeCloseTo(0.00375, 5);
      expect(result.totalCost).toBeCloseTo(0.36375, 4);
    });

    it('should return zero cost for zero tokens', () => {
      const result = calculateTokenCost({
        providerId: 'gemini',
        modelId: 'gemini-2.5-flash',
        totalTokens: 0
      });

      expect(result.totalCost).toBe(0);
      expect(result.estimated).toBe(false);
    });

    it('should return zero cost for unknown providers', () => {
      const result = calculateTokenCost({
        providerId: 'unknown',
        modelId: 'some-model',
        totalTokens: 1000000
      });

      expect(result.totalCost).toBe(0);
    });

    it('should handle GPT-4o pricing', () => {
      const result = calculateTokenCost({
        providerId: 'codex',
        modelId: 'gpt-4o',
        inputTokens: 100000,  // 100k input
        outputTokens: 50000   // 50k output
      });

      // Input: 100k * 2.50/M = $0.25
      // Output: 50k * 10.00/M = $0.50
      // Total: $0.75
      expect(result.inputCost).toBeCloseTo(0.25, 4);
      expect(result.outputCost).toBeCloseTo(0.50, 4);
      expect(result.totalCost).toBeCloseTo(0.75, 3);
    });

    it('should handle Claude pricing', () => {
      const result = calculateTokenCost({
        providerId: 'claude',
        modelId: 'claude-opus-4-5',
        inputTokens: 100000,  // 100k input
        outputTokens: 10000   // 10k output
      });

      // Input: 100k * 15.00/M = $1.50
      // Output: 10k * 75.00/M = $0.75
      // Total: $2.25
      expect(result.inputCost).toBeCloseTo(1.50, 4);
      expect(result.outputCost).toBeCloseTo(0.75, 4);
      expect(result.totalCost).toBeCloseTo(2.25, 3);
    });
  });

  describe('pricing data validation', () => {
    it('should have valid pricing structure for all providers', () => {
      for (const providerId of getKnownProviders()) {
        const models = getKnownModels(providerId);

        for (const modelId of models) {
          const pricing = getModelPricing(providerId, modelId);
          expect(pricing.input).toBeGreaterThanOrEqual(0);
          expect(pricing.output).toBeGreaterThanOrEqual(0);
          expect(pricing.cached).toBeGreaterThanOrEqual(0);
        }
      }
    });

    it('should have default pricing for all providers', () => {
      for (const providerId of getKnownProviders()) {
        const defaultPricing = MODEL_PRICING[providerId]['_default'];
        expect(defaultPricing).toBeDefined();
        expect(defaultPricing.input).toBeGreaterThan(0);
        expect(defaultPricing.output).toBeGreaterThan(0);
      }
    });
  });
});

import { jest } from '@jest/globals';
import { DaemonClient } from '../src/daemon-client.js';
import { existsSync, readFileSync } from 'fs';
import { execSync } from 'child_process';

// Mock fs and child_process modules
jest.mock('fs');
jest.mock('child_process');

describe('DaemonClient', () => {
  let daemonClient;

  beforeEach(() => {
    daemonClient = new DaemonClient();
    jest.clearAllMocks();
  });

  describe('constructor', () => {
    test('should initialize with correct properties', () => {
      expect(daemonClient.pidFile).toContain('.ani-code-daemon.pid');
      expect(daemonClient.serviceName).toBe('ani-code');
    });
  });

  describe('isDaemonRunning', () => {
    test('should return false when pid file does not exist', () => {
      existsSync.mockReturnValue(false);
      
      expect(daemonClient.isDaemonRunning()).toBe(false);
      expect(existsSync).toHaveBeenCalledWith(daemonClient.pidFile);
    });

    test('should return true when pid file exists and process is running', () => {
      existsSync.mockReturnValue(true);
      readFileSync.mockReturnValue('12345');
      // Mock process.kill to not throw (process exists)
      const originalKill = process.kill;
      process.kill = jest.fn();
      
      expect(daemonClient.isDaemonRunning()).toBe(true);
      
      process.kill = originalKill;
    });

    test('should return false when pid file exists but process is not running', () => {
      existsSync.mockReturnValue(true);
      readFileSync.mockReturnValue('12345');
      // Mock process.kill to throw (process doesn't exist)
      const originalKill = process.kill;
      process.kill = jest.fn(() => {
        throw new Error('Process not found');
      });
      
      expect(daemonClient.isDaemonRunning()).toBe(false);
      
      process.kill = originalKill;
    });

    test('should handle invalid pid file content', () => {
      existsSync.mockReturnValue(true);
      readFileSync.mockReturnValue('invalid-pid');
      
      expect(daemonClient.isDaemonRunning()).toBe(false);
    });
  });

  describe('getDaemonPid', () => {
    test('should return pid when pid file exists', () => {
      existsSync.mockReturnValue(true);
      readFileSync.mockReturnValue('12345');
      
      expect(daemonClient.getDaemonPid()).toBe(12345);
    });

    test('should return null when pid file does not exist', () => {
      existsSync.mockReturnValue(false);
      
      expect(daemonClient.getDaemonPid()).toBeNull();
    });

    test('should return null when reading pid file fails', () => {
      existsSync.mockReturnValue(true);
      readFileSync.mockImplementation(() => {
        throw new Error('Read error');
      });
      
      expect(daemonClient.getDaemonPid()).toBeNull();
    });

    test('should handle non-numeric pid file content', () => {
      existsSync.mockReturnValue(true);
      readFileSync.mockReturnValue('not-a-number');
      
      const result = daemonClient.getDaemonPid();
      expect(isNaN(result)).toBe(true);
    });
  });

  describe('isServiceInstalled', () => {
    test('should return system service installed when systemctl succeeds', () => {
      execSync.mockImplementation((cmd) => {
        if (cmd.includes('systemctl is-enabled')) {
          return '';
        }
        throw new Error('Command failed');
      });
      
      const result = daemonClient.isServiceInstalled();
      
      expect(result).toEqual({
        type: 'system',
        installed: true
      });
    });

    test('should return user service installed when user systemctl succeeds', () => {
      execSync.mockImplementation((cmd) => {
        if (cmd.includes('--user')) {
          return '';
        }
        throw new Error('Command failed');
      });
      
      const result = daemonClient.isServiceInstalled();
      
      expect(result).toEqual({
        type: 'user',
        installed: true
      });
    });

    test('should return not installed when both checks fail', () => {
      execSync.mockImplementation(() => {
        throw new Error('Command failed');
      });
      
      const result = daemonClient.isServiceInstalled();
      
      expect(result).toEqual({
        type: 'none',
        installed: false
      });
    });

    test('should handle unexpected errors', () => {
      const errorMessage = 'Unexpected error';
      execSync.mockImplementation(() => {
        const error = new Error(errorMessage);
        error.code = 'ENOENT';
        throw error;
      });
      
      const result = daemonClient.isServiceInstalled();
      
      expect(result.installed).toBe(false);
    });
  });

  describe('getServiceStatus', () => {
    test('should return active status for system service', () => {
      execSync.mockImplementation((cmd) => {
        if (cmd.includes('is-active')) {
          return 'active\n';
        }
        return '';
      });
      
      const result = daemonClient.getServiceStatus('system');
      
      expect(result).toEqual({
        active: true,
        status: 'active'
      });
    });

    test('should return inactive status for user service', () => {
      execSync.mockImplementation((cmd) => {
        if (cmd.includes('is-active')) {
          return 'inactive\n';
        }
        return '';
      });
      
      const result = daemonClient.getServiceStatus('user');
      
      expect(result).toEqual({
        active: false,
        status: 'inactive'
      });
    });

    test('should handle service check errors', () => {
      execSync.mockImplementation(() => {
        throw new Error('Service not found');
      });
      
      const result = daemonClient.getServiceStatus('system');
      
      expect(result).toEqual({
        active: false,
        status: 'unknown'
      });
    });

    test('should handle failed status', () => {
      execSync.mockImplementation((cmd) => {
        if (cmd.includes('is-active')) {
          return 'failed\n';
        }
        return '';
      });
      
      const result = daemonClient.getServiceStatus('system');
      
      expect(result).toEqual({
        active: false,
        status: 'failed'
      });
    });
  });

  describe('getFullStatus', () => {
    test('should combine daemon and service status', () => {
      existsSync.mockReturnValue(true);
      readFileSync.mockReturnValue('12345');
      const originalKill = process.kill;
      process.kill = jest.fn();
      
      execSync.mockImplementation((cmd) => {
        if (cmd.includes('systemctl is-enabled')) {
          return '';
        }
        if (cmd.includes('is-active')) {
          return 'active\n';
        }
        return '';
      });
      
      const result = daemonClient.getFullStatus();
      
      expect(result).toEqual({
        daemon: {
          running: true,
          pid: 12345
        },
        service: {
          type: 'system',
          installed: true,
          active: true,
          status: 'active'
        }
      });
      
      process.kill = originalKill;
    });

    test('should handle when daemon is not running', () => {
      existsSync.mockReturnValue(false);
      execSync.mockImplementation(() => {
        throw new Error('Command failed');
      });
      
      const result = daemonClient.getFullStatus();
      
      expect(result).toEqual({
        daemon: {
          running: false,
          pid: null
        },
        service: {
          type: 'none',
          installed: false,
          active: false,
          status: 'unknown'
        }
      });
    });
  });

  describe('stopDaemon', () => {
    test('should stop daemon when running', () => {
      existsSync.mockReturnValue(true);
      readFileSync.mockReturnValue('12345');
      const originalKill = process.kill;
      process.kill = jest.fn();
      
      const result = daemonClient.stopDaemon();
      
      expect(result).toBe(true);
      expect(process.kill).toHaveBeenCalledWith(12345, 'SIGTERM');
      
      process.kill = originalKill;
    });

    test('should return false when daemon is not running', () => {
      existsSync.mockReturnValue(false);
      
      const result = daemonClient.stopDaemon();
      
      expect(result).toBe(false);
    });

    test('should handle errors when stopping daemon', () => {
      existsSync.mockReturnValue(true);
      readFileSync.mockReturnValue('12345');
      const originalKill = process.kill;
      process.kill = jest.fn(() => {
        throw new Error('Permission denied');
      });
      
      const result = daemonClient.stopDaemon();
      
      expect(result).toBe(false);
      
      process.kill = originalKill;
    });
  });
});
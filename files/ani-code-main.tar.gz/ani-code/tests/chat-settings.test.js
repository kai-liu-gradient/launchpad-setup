import { jest } from '@jest/globals';
import fs from 'fs/promises';
import { ChatSettingsManager } from '../src/chat-settings.js';

// Mock fs/promises
jest.mock('fs/promises');

describe('ChatSettingsManager', () => {
  let manager;
  const testSettingsPath = '/tmp/test-chat-settings.json';

  beforeEach(() => {
    jest.clearAllMocks();
    manager = new ChatSettingsManager(testSettingsPath);
  });

  describe('constructor', () => {
    test('should initialize with correct properties', () => {
      expect(manager.settingsPath).toBe(testSettingsPath);
      expect(manager.settings).toBeInstanceOf(Map);
      expect(manager.workdirToChat).toBeInstanceOf(Map);
      expect(manager.saveDebounceTimer).toBeNull();
    });

    test('should use default path when not provided', () => {
      const defaultManager = new ChatSettingsManager();
      expect(defaultManager.settingsPath).toContain('.ani-code-chat-settings.json');
    });
  });

  describe('load', () => {
    test('should load settings from file', async () => {
      const mockData = {
        version: '1.1',
        updated: '2024-01-01T00:00:00.000Z',
        chatWorkdirs: {
          'chat123': 'workspace1',
          'chat456': 'workspace2'
        },
        workdirToChat: {
          '/path/to/workspace1': 'chat123',
          '/path/to/workspace2': 'chat456'
        }
      };

      fs.readFile.mockResolvedValue(JSON.stringify(mockData));

      await manager.load();

      expect(manager.settings.size).toBe(2);
      expect(manager.settings.get('chat123')).toBe('workspace1');
      expect(manager.settings.get('chat456')).toBe('workspace2');
      expect(manager.workdirToChat.size).toBe(2);
      expect(manager.workdirToChat.get('/path/to/workspace1')).toBe('chat123');
    });

    test('should create empty file when file does not exist', async () => {
      const error = new Error('File not found');
      error.code = 'ENOENT';
      fs.readFile.mockRejectedValue(error);
      fs.writeFile.mockResolvedValue();

      await manager.load();

      expect(fs.writeFile).toHaveBeenCalled();
      expect(manager.settings.size).toBe(0);
      expect(manager.workdirToChat.size).toBe(0);
    });

    test('should handle JSON parse errors', async () => {
      fs.readFile.mockResolvedValue('invalid json');

      await manager.load();

      expect(manager.settings.size).toBe(0);
      expect(manager.workdirToChat.size).toBe(0);
    });

    test('should handle file read errors', async () => {
      const error = new Error('Permission denied');
      error.code = 'EACCES';
      fs.readFile.mockRejectedValue(error);

      await manager.load();

      expect(manager.settings.size).toBe(0);
      expect(manager.workdirToChat.size).toBe(0);
    });

    test('should handle missing chatWorkdirs in file', async () => {
      const mockData = {
        version: '1.1',
        updated: '2024-01-01T00:00:00.000Z'
      };

      fs.readFile.mockResolvedValue(JSON.stringify(mockData));

      await manager.load();

      expect(manager.settings.size).toBe(0);
      expect(manager.workdirToChat.size).toBe(0);
    });
  });

  describe('save', () => {
    test('should save settings to file', async () => {
      manager.settings.set('chat123', 'workspace1');
      manager.settings.set('chat456', 'workspace2');
      manager.workdirToChat.set('/path/to/workspace1', 'chat123');

      fs.writeFile.mockResolvedValue();

      await manager.save();

      expect(fs.writeFile).toHaveBeenCalledWith(
        testSettingsPath,
        expect.stringContaining('"chat123": "workspace1"')
      );
      expect(fs.writeFile).toHaveBeenCalledWith(
        testSettingsPath,
        expect.stringContaining('"chat456": "workspace2"')
      );
      expect(fs.writeFile).toHaveBeenCalledWith(
        testSettingsPath,
        expect.stringContaining('"/path/to/workspace1": "chat123"')
      );
    });

    test('should include version and timestamp', async () => {
      fs.writeFile.mockResolvedValue();

      await manager.save();

      const savedData = JSON.parse(fs.writeFile.mock.calls[0][1]);
      expect(savedData.version).toBe('1.1');
      expect(savedData.updated).toBeDefined();
      expect(new Date(savedData.updated)).toBeInstanceOf(Date);
    });

    test('should clear pending save timer', async () => {
      const mockTimer = setTimeout(() => {}, 1000);
      manager.saveDebounceTimer = mockTimer;
      
      fs.writeFile.mockResolvedValue();
      const clearTimeoutSpy = jest.spyOn(global, 'clearTimeout');

      await manager.save();

      expect(clearTimeoutSpy).toHaveBeenCalledWith(mockTimer);
      expect(manager.saveDebounceTimer).toBeNull();

      clearTimeout(mockTimer);
      clearTimeoutSpy.mockRestore();
    });

    test('should handle save errors gracefully', async () => {
      fs.writeFile.mockRejectedValue(new Error('Write failed'));

      // Should not throw
      await expect(manager.save()).resolves.toBeUndefined();
    });
  });

  describe('saveDebounced', () => {
    beforeEach(() => {
      jest.useFakeTimers();
    });

    afterEach(() => {
      jest.useRealTimers();
    });

    test('should debounce multiple save calls', () => {
      fs.writeFile.mockResolvedValue();

      manager.saveDebounced();
      manager.saveDebounced();
      manager.saveDebounced();

      // Should only have one timer active
      expect(manager.saveDebounceTimer).toBeDefined();

      // Fast-forward time
      jest.advanceTimersByTime(2000);

      // Save should be called only once
      expect(fs.writeFile).toHaveBeenCalledTimes(1);
    });

    test('should reset timer on subsequent calls', () => {
      fs.writeFile.mockResolvedValue();
      const clearTimeoutSpy = jest.spyOn(global, 'clearTimeout');

      manager.saveDebounced();
      const firstTimer = manager.saveDebounceTimer;
      
      manager.saveDebounced();
      const secondTimer = manager.saveDebounceTimer;

      expect(clearTimeoutSpy).toHaveBeenCalledWith(firstTimer);
      expect(secondTimer).not.toBe(firstTimer);

      clearTimeoutSpy.mockRestore();
    });
  });

  describe('setWorkdir', () => {
    test('should set workdir for chat', async () => {
      fs.writeFile.mockResolvedValue();

      const result = await manager.setWorkdir('chat123', 'workspace1', '/path/to/workspace1');

      expect(result).toBe(true);
      expect(manager.settings.get('chat123')).toBe('workspace1');
      expect(manager.workdirToChat.get('/path/to/workspace1')).toBe('chat123');
    });

    test('should save after setting workdir', async () => {
      fs.writeFile.mockResolvedValue();

      await manager.setWorkdir('chat123', 'workspace1', '/path/to/workspace1');

      expect(fs.writeFile).toHaveBeenCalled();
    });

    test('should handle save errors', async () => {
      fs.writeFile.mockRejectedValue(new Error('Save failed'));

      const result = await manager.setWorkdir('chat123', 'workspace1', '/path/to/workspace1');

      expect(result).toBe(false);
    });
  });

  describe('getWorkdir', () => {
    test('should get workdir for chat', () => {
      manager.settings.set('chat123', 'workspace1');

      const result = manager.getWorkdir('chat123');

      expect(result).toBe('workspace1');
    });

    test('should return undefined for unknown chat', () => {
      const result = manager.getWorkdir('unknown');

      expect(result).toBeUndefined();
    });
  });

  describe('getChatByWorkdir', () => {
    test('should get chat ID by workdir path', () => {
      manager.workdirToChat.set('/path/to/workspace1', 'chat123');

      const result = manager.getChatByWorkdir('/path/to/workspace1');

      expect(result).toBe('chat123');
    });

    test('should return undefined for unknown workdir', () => {
      const result = manager.getChatByWorkdir('/unknown/path');

      expect(result).toBeUndefined();
    });
  });

  describe('clearWorkdir', () => {
    test('should clear workdir for chat', async () => {
      manager.settings.set('chat123', 'workspace1');
      manager.workdirToChat.set('/path/to/workspace1', 'chat123');
      fs.writeFile.mockResolvedValue();

      const result = await manager.clearWorkdir('chat123');

      expect(result).toBe(true);
      expect(manager.settings.has('chat123')).toBe(false);
    });

    test('should clear workdir-to-chat mapping', async () => {
      manager.settings.set('chat123', 'workspace1');
      manager.workdirToChat.set('/path/to/workspace1', 'chat123');
      fs.writeFile.mockResolvedValue();

      await manager.clearWorkdir('chat123');

      // workdirToChat entries are not automatically cleared when clearing a chat's workdir
      // This is by design to maintain history
      expect(manager.workdirToChat.has('/path/to/workspace1')).toBe(true);
    });

    test('should save after clearing', async () => {
      manager.settings.set('chat123', 'workspace1');
      fs.writeFile.mockResolvedValue();

      await manager.clearWorkdir('chat123');

      expect(fs.writeFile).toHaveBeenCalled();
    });

    test('should handle save errors', async () => {
      manager.settings.set('chat123', 'workspace1');
      fs.writeFile.mockRejectedValue(new Error('Save failed'));

      const result = await manager.clearWorkdir('chat123');

      expect(result).toBe(false);
    });
  });

  describe('getAllSettings', () => {
    test('should return all settings as object', () => {
      manager.settings.set('chat123', 'workspace1');
      manager.settings.set('chat456', 'workspace2');

      const result = manager.getAllSettings();

      expect(result).toEqual({
        'chat123': 'workspace1',
        'chat456': 'workspace2'
      });
    });

    test('should return empty object when no settings', () => {
      const result = manager.getAllSettings();

      expect(result).toEqual({});
    });
  });

  describe('getAllWorkdirMappings', () => {
    test('should return all workdir mappings as object', () => {
      manager.workdirToChat.set('/path/to/workspace1', 'chat123');
      manager.workdirToChat.set('/path/to/workspace2', 'chat456');

      const result = manager.getAllWorkdirMappings();

      expect(result).toEqual({
        '/path/to/workspace1': 'chat123',
        '/path/to/workspace2': 'chat456'
      });
    });

    test('should return empty object when no mappings', () => {
      const result = manager.getAllWorkdirMappings();

      expect(result).toEqual({});
    });
  });

  describe('displayMode methods', () => {
    test('getDisplayMode should return null for unknown chat', () => {
      const result = manager.getDisplayMode('unknown');
      expect(result).toBeNull();
    });

    test('setDisplayMode should store mode for chat', async () => {
      fs.writeFile.mockResolvedValue();

      await manager.setDisplayMode('chat123', 'simple');
      expect(manager.getDisplayMode('chat123')).toBe('simple');
    });

    test('setDisplayMode should overwrite existing mode', async () => {
      fs.writeFile.mockResolvedValue();

      await manager.setDisplayMode('chat123', 'simple');
      await manager.setDisplayMode('chat123', 'full');
      expect(manager.getDisplayMode('chat123')).toBe('full');
    });

    test('displayModes should persist in save', async () => {
      fs.writeFile.mockResolvedValue();

      manager.displayModes.set('chat123', 'simple');
      manager.displayModes.set('chat456', 'full');

      await manager.save();

      const savedData = JSON.parse(fs.writeFile.mock.calls[0][1]);
      expect(savedData.displayModes).toEqual({
        'chat123': 'simple',
        'chat456': 'full'
      });
    });

    test('save should use version 1.2 with displayModes', async () => {
      fs.writeFile.mockResolvedValue();

      await manager.save();

      const savedData = JSON.parse(fs.writeFile.mock.calls[0][1]);
      expect(savedData.version).toBe('1.2');
      expect(savedData).toHaveProperty('displayModes');
    });

    test('load should restore displayModes from file', async () => {
      const mockData = {
        version: '1.2',
        updated: '2026-01-01T00:00:00.000Z',
        chatWorkdirs: {},
        workdirToChat: {},
        displayModes: {
          'chat123': 'simple',
          'chat456': 'full'
        }
      };

      fs.readFile.mockResolvedValue(JSON.stringify(mockData));

      await manager.load();

      expect(manager.getDisplayMode('chat123')).toBe('simple');
      expect(manager.getDisplayMode('chat456')).toBe('full');
    });

    test('load should handle missing displayModes gracefully', async () => {
      const mockData = {
        version: '1.1',
        updated: '2026-01-01T00:00:00.000Z',
        chatWorkdirs: { 'chat123': 'workspace1' },
        workdirToChat: {}
      };

      fs.readFile.mockResolvedValue(JSON.stringify(mockData));

      await manager.load();

      expect(manager.displayModes.size).toBe(0);
      expect(manager.getDisplayMode('chat123')).toBeNull();
    });
  });
});
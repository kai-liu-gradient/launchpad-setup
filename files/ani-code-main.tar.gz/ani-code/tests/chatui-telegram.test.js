import { jest } from '@jest/globals';
import {
  VALID_DISPLAY_MODES,
  resolveDisplayMode,
  DisplayModeManager
} from '../src/display-mode.js';

/**
 * Tests for Telegram /chatui command handling
 *
 * These tests validate the handleChatUICommand logic as it exists in HTTPServer.
 * Since HTTPServer is large and has many dependencies, we test the command logic
 * by extracting and simulating the handler behavior with mocks.
 */

describe('Telegram /chatui Command Handling', () => {
  let mockTelegramNotifier;
  let mockChatSettings;
  let displayModeManager;

  beforeEach(() => {
    mockTelegramNotifier = {
      sendMessage: jest.fn().mockResolvedValue(undefined),
      escapeMarkdownContent: jest.fn((text) => text)
    };

    mockChatSettings = {
      getDisplayMode: jest.fn().mockReturnValue(null),
      setDisplayMode: jest.fn().mockResolvedValue(undefined)
    };

    displayModeManager = new DisplayModeManager(mockChatSettings);
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  /**
   * Simulates the handleChatUICommand logic from HTTPServer
   * This mirrors the actual implementation at http-server.js:12983
   */
  async function handleChatUICommand(chatId, args) {
    const fullChatId = `telegram:${chatId}`;

    try {
      const currentMode = displayModeManager.getDisplayMode(fullChatId);

      if (!args || !args.trim()) {
        // Show current mode with inline keyboard
        const modes = DisplayModeManager.getAvailableModes().filter(m => m.id !== 'default');

        const keyboard = {
          inline_keyboard: [
            [
              { text: currentMode === 'full' ? '● Full' : '○ Full', callback_data: 'chatui:full' },
              { text: currentMode === 'simple' ? '● Simple' : '○ Simple', callback_data: 'chatui:simple' }
            ]
          ]
        };

        await mockTelegramNotifier.sendMessage(chatId,
          `📱 *Chat Display Mode*\n\nCurrent: *${currentMode}*\n\n` +
          `● *full* \\- All output: headers, git status, cost/tokens, footer\n` +
          `○ *simple* \\- Streamlined: task output \\+ brief completion line\n\n` +
          `Tap a button or send /chatui <mode> to switch\\.`,
          { parse_mode: 'MarkdownV2', reply_markup: keyboard }
        );
        return;
      }

      const mode = args.trim().toLowerCase();

      if (!VALID_DISPLAY_MODES.includes(mode)) {
        await mockTelegramNotifier.sendMessage(chatId,
          `❌ Invalid display mode: ${mode}\n\nValid modes: ${VALID_DISPLAY_MODES.join(', ')}\n\nExample: /chatui simple`
        );
        return;
      }

      const { previousMode, newMode } = await displayModeManager.setDisplayMode(fullChatId, mode);

      let message;
      if (mode === 'default') {
        message = `✅ Display mode reset to default: *${newMode}*`;
      } else if (previousMode === newMode) {
        message = `ℹ️ Display mode already set to: *${newMode}*`;
      } else {
        message = `✅ Display mode changed: *${previousMode}* → *${newMode}*`;
      }

      await mockTelegramNotifier.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    } catch (error) {
      await mockTelegramNotifier.sendMessage(chatId,
        `❌ Failed to update display mode: ${error.message}`
      );
    }
  }

  describe('/chatui with no arguments', () => {
    test('shows current mode with inline keyboard', async () => {
      await handleChatUICommand('123456', '');

      expect(mockTelegramNotifier.sendMessage).toHaveBeenCalledTimes(1);
      const [chatId, message, options] = mockTelegramNotifier.sendMessage.mock.calls[0];

      expect(chatId).toBe('123456');
      expect(message).toContain('Chat Display Mode');
      expect(message).toContain('Current: *full*');
      expect(options.parse_mode).toBe('MarkdownV2');
      expect(options.reply_markup).toBeDefined();
    });

    test('includes inline keyboard buttons for full and simple', async () => {
      await handleChatUICommand('123456', null);

      const [, , options] = mockTelegramNotifier.sendMessage.mock.calls[0];
      const buttons = options.reply_markup.inline_keyboard[0];

      expect(buttons).toHaveLength(2);
      expect(buttons[0].callback_data).toBe('chatui:full');
      expect(buttons[1].callback_data).toBe('chatui:simple');
    });

    test('marks current full mode as selected in keyboard', async () => {
      await handleChatUICommand('123456', '');

      const [, , options] = mockTelegramNotifier.sendMessage.mock.calls[0];
      const buttons = options.reply_markup.inline_keyboard[0];

      expect(buttons[0].text).toBe('● Full');
      expect(buttons[1].text).toBe('○ Simple');
    });

    test('marks current simple mode as selected in keyboard', async () => {
      mockChatSettings.getDisplayMode.mockReturnValue('simple');

      await handleChatUICommand('123456', '');

      const [, , options] = mockTelegramNotifier.sendMessage.mock.calls[0];
      const buttons = options.reply_markup.inline_keyboard[0];

      expect(buttons[0].text).toBe('○ Full');
      expect(buttons[1].text).toBe('● Simple');
    });

    test('uses telegram: prefix for chatId when checking mode', async () => {
      await handleChatUICommand('123456', '');

      expect(mockChatSettings.getDisplayMode).toHaveBeenCalledWith('telegram:123456');
    });
  });

  describe('/chatui simple', () => {
    test('switches to simple mode and confirms', async () => {
      await handleChatUICommand('123456', 'simple');

      expect(mockChatSettings.setDisplayMode).toHaveBeenCalledWith('telegram:123456', 'simple');

      const [chatId, message, options] = mockTelegramNotifier.sendMessage.mock.calls[0];
      expect(chatId).toBe('123456');
      expect(message).toContain('Display mode changed');
      expect(message).toContain('simple');
      expect(options.parse_mode).toBe('Markdown');
    });

    test('shows already set message when mode unchanged', async () => {
      mockChatSettings.getDisplayMode.mockReturnValue('simple');

      await handleChatUICommand('123456', 'simple');

      const [, message] = mockTelegramNotifier.sendMessage.mock.calls[0];
      expect(message).toContain('already set to');
      expect(message).toContain('simple');
    });
  });

  describe('/chatui full', () => {
    test('switches to full mode and confirms', async () => {
      mockChatSettings.getDisplayMode.mockReturnValue('simple');

      await handleChatUICommand('123456', 'full');

      expect(mockChatSettings.setDisplayMode).toHaveBeenCalledWith('telegram:123456', 'full');

      const [, message] = mockTelegramNotifier.sendMessage.mock.calls[0];
      expect(message).toContain('Display mode changed');
      expect(message).toContain('full');
    });

    test('shows already set when full mode already active', async () => {
      // Default is full, so setting full again should show "already set"
      mockChatSettings.getDisplayMode.mockReturnValue('full');

      await handleChatUICommand('123456', 'full');

      const [, message] = mockTelegramNotifier.sendMessage.mock.calls[0];
      expect(message).toContain('already set to');
    });
  });

  describe('/chatui default', () => {
    test('resets to default (full) mode', async () => {
      mockChatSettings.getDisplayMode.mockReturnValue('simple');

      await handleChatUICommand('123456', 'default');

      expect(mockChatSettings.setDisplayMode).toHaveBeenCalledWith('telegram:123456', 'full');

      const [, message] = mockTelegramNotifier.sendMessage.mock.calls[0];
      expect(message).toContain('reset to default');
      expect(message).toContain('full');
    });
  });

  describe('/chatui with invalid mode', () => {
    test('rejects invalid mode with error message', async () => {
      await handleChatUICommand('123456', 'verbose');

      expect(mockChatSettings.setDisplayMode).not.toHaveBeenCalled();

      const [, message] = mockTelegramNotifier.sendMessage.mock.calls[0];
      expect(message).toContain('Invalid display mode');
      expect(message).toContain('verbose');
      expect(message).toContain('Valid modes');
    });

    test('shows example usage in error message', async () => {
      await handleChatUICommand('123456', 'compact');

      const [, message] = mockTelegramNotifier.sendMessage.mock.calls[0];
      expect(message).toContain('/chatui simple');
    });

    test('lists all valid modes in error', async () => {
      await handleChatUICommand('123456', 'xyz');

      const [, message] = mockTelegramNotifier.sendMessage.mock.calls[0];
      expect(message).toContain('full');
      expect(message).toContain('simple');
      expect(message).toContain('default');
    });
  });

  describe('/chatui with whitespace handling', () => {
    test('trims whitespace from mode argument', async () => {
      await handleChatUICommand('123456', '  simple  ');

      expect(mockChatSettings.setDisplayMode).toHaveBeenCalledWith('telegram:123456', 'simple');
    });

    test('treats whitespace-only input as no argument', async () => {
      await handleChatUICommand('123456', '   ');

      const [, message] = mockTelegramNotifier.sendMessage.mock.calls[0];
      expect(message).toContain('Chat Display Mode');
    });

    test('lowercases mode argument', async () => {
      await handleChatUICommand('123456', 'SIMPLE');

      expect(mockChatSettings.setDisplayMode).toHaveBeenCalledWith('telegram:123456', 'simple');
    });
  });

  describe('error handling', () => {
    test('sends error message when setDisplayMode fails', async () => {
      mockChatSettings.setDisplayMode.mockRejectedValue(new Error('Storage error'));

      await handleChatUICommand('123456', 'simple');

      const [, message] = mockTelegramNotifier.sendMessage.mock.calls[0];
      expect(message).toContain('Failed to update display mode');
      expect(message).toContain('Storage error');
    });
  });

  describe('callback button handling', () => {
    test('callback data format is correct for chatui buttons', async () => {
      await handleChatUICommand('123456', '');

      const [, , options] = mockTelegramNotifier.sendMessage.mock.calls[0];
      const buttons = options.reply_markup.inline_keyboard[0];

      // Callback data should match the format used in HTTPServer's parseCallbackData
      expect(buttons[0].callback_data).toMatch(/^chatui:/);
      expect(buttons[1].callback_data).toMatch(/^chatui:/);
    });
  });
});

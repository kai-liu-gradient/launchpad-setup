# Testing Structure

## Directory Layout

- `tests/` - Jest unit tests
  - `*.test.js` - Unit test files
  - `utils/` - Utility test files
  - `manual/` - Manual test scripts for ad-hoc testing

## Running Tests

```bash
# Run all tests
npm test

# Run with coverage
npm run test:coverage

# Watch mode for development
npm run test:watch
```

## Test Status

Currently working tests:
- `markdown-to-lark.test.js` - Markdown to Lark conversion tests

Tests requiring fixes:
- `config.test.js` - Config module tests (environment variable handling)
- `chat-settings.test.js` - Chat settings manager tests
- `daemon-client.test.js` - Daemon client tests
- `logger.test.js` - Logger module tests
- `utils/secure-upload.test.js` - Secure upload utility tests

## Manual Test Scripts

The `manual/` directory contains standalone test scripts for testing specific features:
- Model preference detection
- Telegram notifications
- WebSocket services
- S3 uploads
- Various command testing

These can be run individually with:
```bash
node tests/manual/test-<feature>.js
```
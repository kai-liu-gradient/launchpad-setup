import { jest } from '@jest/globals';
import {
  VALID_DISPLAY_MODES,
  resolveDisplayMode,
  DisplayModeManager
} from '../src/display-mode.js';

/**
 * Tests for /api/chatui REST API endpoints
 *
 * These tests validate the handleChatUIAPI logic as it exists in HTTPServer.
 * Since HTTPServer is large with many dependencies, we simulate the handler
 * behavior with mocks matching the actual implementation at http-server.js:12916.
 */

describe('ChatUI API Endpoints', () => {
  let mockChatSettings;
  let displayModeManager;
  let responses;

  beforeEach(() => {
    mockChatSettings = {
      getDisplayMode: jest.fn().mockReturnValue(null),
      setDisplayMode: jest.fn().mockResolvedValue(undefined)
    };

    displayModeManager = new DisplayModeManager(mockChatSettings);

    // Track API responses
    responses = [];
  });

  /**
   * Helper to simulate sendSuccess
   */
  function sendSuccess(data) {
    responses.push({ status: 200, body: data });
  }

  /**
   * Helper to simulate sendError
   */
  function sendError(status, message) {
    responses.push({ status, body: { success: false, error: message } });
  }

  /**
   * Simulates the handleChatUIAPI logic from HTTPServer
   * Mirrors the actual implementation at http-server.js:12916
   */
  async function handleChatUIAPI(method, pathname, query = {}, body = {}) {
    try {
      // GET /api/chatui/modes - List available modes
      if (pathname === '/api/chatui/modes' && method === 'GET') {
        sendSuccess({
          success: true,
          modes: DisplayModeManager.getAvailableModes(),
          timestamp: new Date().toISOString()
        });
        return;
      }

      // GET /api/chatui?chatId=xxx - Get current mode for a chat
      if (method === 'GET') {
        const chatId = query.chatId;
        if (!chatId) {
          sendError(400, 'Missing required parameter: chatId');
          return;
        }

        const mode = displayModeManager.getDisplayMode(chatId);
        sendSuccess({
          success: true,
          chatId,
          mode,
          availableModes: ['full', 'simple', 'default'],
          timestamp: new Date().toISOString()
        });
        return;
      }

      // PATCH /api/chatui - Set mode for a chat
      if (method === 'PATCH') {
        const { chatId, mode } = body;

        if (!chatId || !mode) {
          sendError(400, 'Missing required fields: chatId, mode');
          return;
        }

        if (!VALID_DISPLAY_MODES.includes(mode)) {
          sendError(400, `Invalid mode: ${mode}. Valid: ${VALID_DISPLAY_MODES.join(', ')}`);
          return;
        }

        const { previousMode, newMode } = await displayModeManager.setDisplayMode(chatId, mode);
        sendSuccess({
          success: true,
          chatId,
          mode: newMode,
          previousMode,
          timestamp: new Date().toISOString()
        });
        return;
      }

      sendError(405, 'Method Not Allowed');
    } catch (error) {
      sendError(500, error.message);
    }
  }

  describe('GET /api/chatui/modes', () => {
    test('returns list of available modes', async () => {
      await handleChatUIAPI('GET', '/api/chatui/modes');

      expect(responses).toHaveLength(1);
      expect(responses[0].status).toBe(200);
      expect(responses[0].body.success).toBe(true);
      expect(responses[0].body.modes).toHaveLength(3);
    });

    test('includes full, simple, and default modes', async () => {
      await handleChatUIAPI('GET', '/api/chatui/modes');

      const modeIds = responses[0].body.modes.map(m => m.id);
      expect(modeIds).toContain('full');
      expect(modeIds).toContain('simple');
      expect(modeIds).toContain('default');
    });

    test('each mode has id, name, and description', async () => {
      await handleChatUIAPI('GET', '/api/chatui/modes');

      for (const mode of responses[0].body.modes) {
        expect(mode).toHaveProperty('id');
        expect(mode).toHaveProperty('name');
        expect(mode).toHaveProperty('description');
      }
    });

    test('includes timestamp', async () => {
      await handleChatUIAPI('GET', '/api/chatui/modes');

      expect(responses[0].body.timestamp).toBeDefined();
      expect(new Date(responses[0].body.timestamp).toString()).not.toBe('Invalid Date');
    });
  });

  describe('GET /api/chatui?chatId=xxx', () => {
    test('returns current mode for a chat', async () => {
      await handleChatUIAPI('GET', '/api/chatui', { chatId: 'telegram:123456' });

      expect(responses).toHaveLength(1);
      expect(responses[0].status).toBe(200);
      expect(responses[0].body.success).toBe(true);
      expect(responses[0].body.chatId).toBe('telegram:123456');
      expect(responses[0].body.mode).toBe('full');
    });

    test('returns simple mode when chat has simple preference', async () => {
      mockChatSettings.getDisplayMode.mockReturnValue('simple');

      await handleChatUIAPI('GET', '/api/chatui', { chatId: 'telegram:789' });

      expect(responses[0].body.mode).toBe('simple');
    });

    test('includes available modes in response', async () => {
      await handleChatUIAPI('GET', '/api/chatui', { chatId: 'telegram:123' });

      expect(responses[0].body.availableModes).toEqual(['full', 'simple', 'default']);
    });

    test('returns 400 when chatId is missing', async () => {
      await handleChatUIAPI('GET', '/api/chatui', {});

      expect(responses).toHaveLength(1);
      expect(responses[0].status).toBe(400);
      expect(responses[0].body.error).toContain('chatId');
    });

    test('includes timestamp in response', async () => {
      await handleChatUIAPI('GET', '/api/chatui', { chatId: 'telegram:123' });

      expect(responses[0].body.timestamp).toBeDefined();
    });

    test('uses DisplayModeManager to resolve mode', async () => {
      await handleChatUIAPI('GET', '/api/chatui', { chatId: 'telegram:123' });

      expect(mockChatSettings.getDisplayMode).toHaveBeenCalledWith('telegram:123');
    });
  });

  describe('PATCH /api/chatui', () => {
    test('sets mode for a chat successfully', async () => {
      await handleChatUIAPI('PATCH', '/api/chatui', {}, {
        chatId: 'telegram:123456',
        mode: 'simple'
      });

      expect(responses).toHaveLength(1);
      expect(responses[0].status).toBe(200);
      expect(responses[0].body.success).toBe(true);
      expect(responses[0].body.chatId).toBe('telegram:123456');
      expect(responses[0].body.mode).toBe('simple');
      expect(responses[0].body.previousMode).toBe('full');
    });

    test('calls setDisplayMode with correct arguments', async () => {
      await handleChatUIAPI('PATCH', '/api/chatui', {}, {
        chatId: 'telegram:123',
        mode: 'simple'
      });

      expect(mockChatSettings.setDisplayMode).toHaveBeenCalledWith('telegram:123', 'simple');
    });

    test('returns previous mode in response', async () => {
      mockChatSettings.getDisplayMode.mockReturnValue('simple');

      await handleChatUIAPI('PATCH', '/api/chatui', {}, {
        chatId: 'telegram:123',
        mode: 'full'
      });

      expect(responses[0].body.previousMode).toBe('simple');
      expect(responses[0].body.mode).toBe('full');
    });

    test('resolves default mode to full', async () => {
      await handleChatUIAPI('PATCH', '/api/chatui', {}, {
        chatId: 'telegram:123',
        mode: 'default'
      });

      expect(responses[0].body.mode).toBe('full');
      expect(mockChatSettings.setDisplayMode).toHaveBeenCalledWith('telegram:123', 'full');
    });

    test('returns 400 when chatId is missing', async () => {
      await handleChatUIAPI('PATCH', '/api/chatui', {}, {
        mode: 'simple'
      });

      expect(responses[0].status).toBe(400);
      expect(responses[0].body.error).toContain('chatId');
    });

    test('returns 400 when mode is missing', async () => {
      await handleChatUIAPI('PATCH', '/api/chatui', {}, {
        chatId: 'telegram:123'
      });

      expect(responses[0].status).toBe(400);
      expect(responses[0].body.error).toContain('mode');
    });

    test('returns 400 for invalid mode', async () => {
      await handleChatUIAPI('PATCH', '/api/chatui', {}, {
        chatId: 'telegram:123',
        mode: 'invalid'
      });

      expect(responses[0].status).toBe(400);
      expect(responses[0].body.error).toContain('Invalid mode');
      expect(responses[0].body.error).toContain('invalid');
    });

    test('includes valid modes in error for invalid mode', async () => {
      await handleChatUIAPI('PATCH', '/api/chatui', {}, {
        chatId: 'telegram:123',
        mode: 'compact'
      });

      expect(responses[0].body.error).toContain('full');
      expect(responses[0].body.error).toContain('simple');
      expect(responses[0].body.error).toContain('default');
    });

    test('returns 400 when both chatId and mode are missing', async () => {
      await handleChatUIAPI('PATCH', '/api/chatui', {}, {});

      expect(responses[0].status).toBe(400);
    });

    test('includes timestamp in success response', async () => {
      await handleChatUIAPI('PATCH', '/api/chatui', {}, {
        chatId: 'telegram:123',
        mode: 'simple'
      });

      expect(responses[0].body.timestamp).toBeDefined();
    });
  });

  describe('Unsupported methods', () => {
    test('returns 405 for POST method', async () => {
      await handleChatUIAPI('POST', '/api/chatui');

      expect(responses[0].status).toBe(405);
      expect(responses[0].body.error).toContain('Method Not Allowed');
    });

    test('returns 405 for DELETE method', async () => {
      await handleChatUIAPI('DELETE', '/api/chatui');

      expect(responses[0].status).toBe(405);
    });

    test('returns 405 for PUT method', async () => {
      await handleChatUIAPI('PUT', '/api/chatui');

      expect(responses[0].status).toBe(405);
    });
  });

  describe('Error handling', () => {
    test('returns 500 when setDisplayMode throws unexpected error', async () => {
      mockChatSettings.setDisplayMode.mockRejectedValue(new Error('Database connection lost'));

      await handleChatUIAPI('PATCH', '/api/chatui', {}, {
        chatId: 'telegram:123',
        mode: 'simple'
      });

      expect(responses[0].status).toBe(500);
      expect(responses[0].body.error).toContain('Database connection lost');
    });
  });

  describe('Integration with DisplayModeManager', () => {
    test('GET returns env var mode when no per-chat setting', async () => {
      process.env.CHAT_DISPLAY_MODE = 'simple';

      await handleChatUIAPI('GET', '/api/chatui', { chatId: 'telegram:999' });

      expect(responses[0].body.mode).toBe('simple');

      delete process.env.CHAT_DISPLAY_MODE;
    });

    test('per-chat setting takes priority over env var for GET', async () => {
      process.env.CHAT_DISPLAY_MODE = 'simple';
      mockChatSettings.getDisplayMode.mockReturnValue('full');

      await handleChatUIAPI('GET', '/api/chatui', { chatId: 'telegram:999' });

      expect(responses[0].body.mode).toBe('full');

      delete process.env.CHAT_DISPLAY_MODE;
    });

    test('PATCH then GET returns updated mode', async () => {
      // Set mode
      await handleChatUIAPI('PATCH', '/api/chatui', {}, {
        chatId: 'telegram:123',
        mode: 'simple'
      });

      expect(responses[0].status).toBe(200);
      expect(responses[0].body.mode).toBe('simple');

      // After PATCH, the mock should reflect the new setting
      mockChatSettings.getDisplayMode.mockReturnValue('simple');

      // Get mode
      await handleChatUIAPI('GET', '/api/chatui', { chatId: 'telegram:123' });

      expect(responses[1].status).toBe(200);
      expect(responses[1].body.mode).toBe('simple');
    });
  });
});

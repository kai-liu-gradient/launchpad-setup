import { jest } from '@jest/globals';

// Mock chalk to return plain strings for testable output
jest.unstable_mockModule('chalk', () => {
  const identity = (str) => str;
  const chainable = new Proxy(identity, {
    get: () => chainable,
    apply: (target, thisArg, args) => args[0]
  });
  return {
    default: chainable,
    __esModule: true
  };
});

// Mock display-mode module
const mockGetAvailableModes = jest.fn(() => [
  { id: 'full', name: 'Full', description: 'All output: headers, git status, cost/tokens, footer' },
  { id: 'simple', name: 'Simple', description: 'Streamlined: task output + brief completion line only' },
  { id: 'default', name: 'Default', description: 'Alias for full mode' }
]);

jest.unstable_mockModule('../src/display-mode.js', () => ({
  VALID_DISPLAY_MODES: ['full', 'simple', 'default'],
  resolveDisplayMode: (mode) => {
    if (mode === 'default' || mode === 'full') return 'full';
    if (mode === 'simple') return 'simple';
    return 'full';
  },
  DisplayModeManager: class {
    static getAvailableModes = mockGetAvailableModes;
  }
}));

const { Command } = await import('commander');

describe('ChatUI CLI Command', () => {
  let chatUICommand;
  let consoleSpy;
  let consoleErrorSpy;
  let exitSpy;

  beforeEach(async () => {
    // Re-import to get fresh command instance
    const module = await import('../src/commands/chatui.js');
    chatUICommand = module.default;

    consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
    consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
    exitSpy = jest.spyOn(process, 'exit').mockImplementation(() => {
      throw new Error('process.exit called');
    });

    delete process.env.CHAT_DISPLAY_MODE;
  });

  afterEach(() => {
    consoleSpy.mockRestore();
    consoleErrorSpy.mockRestore();
    exitSpy.mockRestore();
    delete process.env.CHAT_DISPLAY_MODE;
  });

  test('command is properly configured', () => {
    expect(chatUICommand.name()).toBe('chatui');
    expect(chatUICommand.description()).toContain('display mode');
  });

  test('command accepts optional mode argument', () => {
    const args = chatUICommand.registeredArguments || chatUICommand._args;
    expect(args).toHaveLength(1);
    expect(args[0].required).toBe(false);
  });

  test('command has --chat option', () => {
    const chatOption = chatUICommand.options.find(o => o.long === '--chat');
    expect(chatOption).toBeDefined();
    expect(chatOption.short).toBe('-c');
  });

  test('shows current mode when no argument provided', async () => {
    // Create a parent program to avoid commander's exitOverride issues
    const program = new Command();
    program.exitOverride();
    program.addCommand(chatUICommand);

    await program.parseAsync(['node', 'test', 'chatui']);

    // Should show current mode info
    const allOutput = consoleSpy.mock.calls.map(c => c.join(' ')).join('\n');
    expect(allOutput).toContain('Chat Display Mode');
    expect(allOutput).toContain('Current mode');
    expect(allOutput).toContain('full');
  });

  test('shows current mode from CHAT_DISPLAY_MODE env var', async () => {
    process.env.CHAT_DISPLAY_MODE = 'simple';

    const program = new Command();
    program.exitOverride();
    program.addCommand(chatUICommand);

    await program.parseAsync(['node', 'test', 'chatui']);

    const allOutput = consoleSpy.mock.calls.map(c => c.join(' ')).join('\n');
    expect(allOutput).toContain('simple');
    expect(allOutput).toContain('CHAT_DISPLAY_MODE');
  });

  test('shows default source when no env var set', async () => {
    const program = new Command();
    program.exitOverride();
    program.addCommand(chatUICommand);

    await program.parseAsync(['node', 'test', 'chatui']);

    const allOutput = consoleSpy.mock.calls.map(c => c.join(' ')).join('\n');
    expect(allOutput).toContain('default');
  });

  test('lists available modes when no argument provided', async () => {
    const program = new Command();
    program.exitOverride();
    program.addCommand(chatUICommand);

    await program.parseAsync(['node', 'test', 'chatui']);

    expect(mockGetAvailableModes).toHaveBeenCalled();
    const allOutput = consoleSpy.mock.calls.map(c => c.join(' ')).join('\n');
    expect(allOutput).toContain('Available modes');
  });

  test('confirms switching to simple mode', async () => {
    const program = new Command();
    program.exitOverride();
    program.addCommand(chatUICommand);

    await program.parseAsync(['node', 'test', 'chatui', 'simple']);

    const allOutput = consoleSpy.mock.calls.map(c => c.join(' ')).join('\n');
    expect(allOutput).toContain('Display mode set to');
    expect(allOutput).toContain('simple');
  });

  test('confirms switching to full mode', async () => {
    const program = new Command();
    program.exitOverride();
    program.addCommand(chatUICommand);

    await program.parseAsync(['node', 'test', 'chatui', 'full']);

    const allOutput = consoleSpy.mock.calls.map(c => c.join(' ')).join('\n');
    expect(allOutput).toContain('Display mode set to');
    expect(allOutput).toContain('full');
  });

  test('confirms resetting to default mode', async () => {
    const program = new Command();
    program.exitOverride();
    program.addCommand(chatUICommand);

    await program.parseAsync(['node', 'test', 'chatui', 'default']);

    const allOutput = consoleSpy.mock.calls.map(c => c.join(' ')).join('\n');
    expect(allOutput).toContain('reset to default');
    expect(allOutput).toContain('full');
  });

  test('rejects invalid mode with error', async () => {
    const program = new Command();
    program.exitOverride();
    program.addCommand(chatUICommand);

    try {
      await program.parseAsync(['node', 'test', 'chatui', 'invalid_mode']);
    } catch (e) {
      // process.exit throws in our mock
    }

    const errorOutput = consoleErrorSpy.mock.calls.map(c => c.join(' ')).join('\n');
    expect(errorOutput).toContain('Invalid display mode');
    expect(errorOutput).toContain('invalid_mode');
  });

  test('shows valid modes in error message for invalid mode', async () => {
    const program = new Command();
    program.exitOverride();
    program.addCommand(chatUICommand);

    try {
      await program.parseAsync(['node', 'test', 'chatui', 'badmode']);
    } catch (e) {
      // process.exit throws in our mock
    }

    const allOutput = consoleSpy.mock.calls.map(c => c.join(' ')).join('\n');
    expect(allOutput).toContain('full, simple, default');
  });

  test('calls process.exit(1) for invalid mode', async () => {
    const program = new Command();
    program.exitOverride();
    program.addCommand(chatUICommand);

    try {
      await program.parseAsync(['node', 'test', 'chatui', 'badmode']);
    } catch (e) {
      // Expected
    }

    expect(exitSpy).toHaveBeenCalledWith(1);
  });

  test('shows note about per-chat setting after mode switch', async () => {
    const program = new Command();
    program.exitOverride();
    program.addCommand(chatUICommand);

    await program.parseAsync(['node', 'test', 'chatui', 'simple']);

    const allOutput = consoleSpy.mock.calls.map(c => c.join(' ')).join('\n');
    expect(allOutput).toContain('CHAT_DISPLAY_MODE');
  });

  test('ignores invalid CHAT_DISPLAY_MODE env var', async () => {
    process.env.CHAT_DISPLAY_MODE = 'not_a_valid_mode';

    const program = new Command();
    program.exitOverride();
    program.addCommand(chatUICommand);

    await program.parseAsync(['node', 'test', 'chatui']);

    const allOutput = consoleSpy.mock.calls.map(c => c.join(' ')).join('\n');
    // Should fall back to 'full' when env var is invalid
    expect(allOutput).toContain('full');
  });
});

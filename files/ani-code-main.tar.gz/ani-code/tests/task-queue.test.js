import { jest } from '@jest/globals';

// Mock dependencies
jest.unstable_mockModule('../src/config.js', () => ({
  config: {
    tasks: {
      maxConcurrent: 3,
      timeoutMs: 1800000
    },
    logging: {
      level: 'info'
    }
  }
}));

jest.unstable_mockModule('../src/logger.js', () => ({
  logger: {
    info: jest.fn(),
    debug: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    success: jest.fn()
  }
}));

jest.unstable_mockModule('../src/usage-reporter.js', () => ({
  UsageReporter: jest.fn().mockImplementation(() => ({
    createTaskCompletionSnapshot: jest.fn(),
    reportTaskUsage: jest.fn()
  }))
}));

jest.unstable_mockModule('../src/telegram-notifier.js', () => ({
  TelegramNotifier: jest.fn().mockImplementation(() => ({
    isEnabled: jest.fn(() => false),
    notifyError: jest.fn(),
    notifySuccess: jest.fn()
  }))
}));

jest.unstable_mockModule('../src/model-utils.js', () => ({
  isValidModel: jest.fn(() => true),
  normalizeModel: jest.fn((model) => model),
  createInvalidModelError: jest.fn(() => new Error('Invalid model')),
  getModelPreference: jest.fn(() => null),
  getModelFlags: jest.fn(() => []),
  extractProviderFromPrompt: jest.fn(() => null)
}));

jest.unstable_mockModule('../src/stats-db.js', () => ({
  getStatsDB: jest.fn(() => ({
    recordTaskCreation: jest.fn(),
    recordTaskStart: jest.fn(),
    recordTaskCompletion: jest.fn(),
    recordTaskFailure: jest.fn()
  }))
}));

jest.unstable_mockModule('../src/providers/providerManager.js', () => ({
  getProviderManager: jest.fn(() => ({
    getHandler: jest.fn(),
    getDefaultProvider: jest.fn(() => 'claude')
  })),
  getProviderManagerSync: jest.fn(() => ({
    getHandler: jest.fn(),
    getDefaultProvider: jest.fn(() => 'claude')
  }))
}));

jest.unstable_mockModule('../src/providers/outputExtractor.js', () => ({
  extractProviderConclusion: jest.fn(() => null),
  extractProviderTokens: jest.fn(() => null),
  extractProviderModel: jest.fn(() => null),
  extractProviderStats: jest.fn(() => null)
}));

jest.unstable_mockModule('../src/providers/costCalculator.js', () => ({
  calculateTokenCost: jest.fn(() => ({ totalCost: 0, estimated: false }))
}));

describe('Task Queue - Task ID Generation', () => {
  let TaskQueue;

  beforeAll(async () => {
    const module = await import('../src/task-queue.js');
    TaskQueue = module.TaskQueue;
  });

  test('should generate task ID with correct format', () => {
    const queue = new TaskQueue();
    const task = queue.addTask('test-task', 'echo test', {
      chatId: '123',
      cwd: '/test/workspace'
    });

    // Task ID format: ac-MMDD-...
    expect(task.id).toMatch(/^ac-\d{4}-/);
  });

  test('should increment task counter for sequential tasks', () => {
    const queue = new TaskQueue();
    const task1 = queue.addTask('task1', 'echo 1', { chatId: '123' });
    const task2 = queue.addTask('task2', 'echo 2', { chatId: '123' });

    // Task IDs should be different
    expect(task1.id).not.toBe(task2.id);
  });

  test('should include month and day in task ID', () => {
    const queue = new TaskQueue();
    const task = queue.addTask('test', 'echo test', { chatId: '123' });

    const now = new Date();
    const month = (now.getMonth() + 1).toString().padStart(2, '0');
    const day = now.getDate().toString().padStart(2, '0');
    const expectedDate = `${month}${day}`;

    expect(task.id).toContain(`ac-${expectedDate}-`);
  });

  test('should sanitize workspace name in task ID', () => {
    const queue = new TaskQueue();
    const task = queue.addTask('test', 'echo test', {
      chatId: '123',
      cwd: '/path/to/my-project-123'
    });

    // Task ID should be generated
    expect(task.id).toBeDefined();
    expect(task.id.length).toBeGreaterThan(0);
  });

  test('should handle long workspace paths', () => {
    const queue = new TaskQueue();
    const task = queue.addTask('test', 'echo test', {
      chatId: '123',
      cwd: '/path/to/verylongworkspacenamethatexceedslimit'
    });

    // Task ID should still be generated
    expect(task.id).toBeDefined();
    expect(task.id).toMatch(/^ac-\d{4}-/);
  });
});

describe('Task Queue - Task Creation', () => {
  let TaskQueue;

  beforeAll(async () => {
    const module = await import('../src/task-queue.js');
    TaskQueue = module.TaskQueue;
  });

  test('should create task with output property', () => {
    const queue = new TaskQueue();
    const task = queue.addTask('test', 'echo test', { chatId: '123' });

    // Task should have output property
    expect(task.output).toBeDefined();
    expect(task.output).toBe('');
  });

  test('should handle task creation with valid options', () => {
    const queue = new TaskQueue();
    const options = {
      chatId: '123456',
      cwd: '/workspace/project',
      model: 'claude-sonnet-4-5-20250929',
      providerId: 'claude'
    };

    const task = queue.addTask('test-task', 'echo test', options);

    expect(task.name).toBe('test-task');
    expect(task.command).toBe('echo test');
    expect(task.chatId).toBe('123456');
    expect(task.cwd).toBe('/workspace/project');
    // Status may be pending or running depending on queue processing
    expect(['pending', 'running']).toContain(task.status);
  });

  test('should create task with minimal options', () => {
    const queue = new TaskQueue();
    const task = queue.addTask('simple', 'echo hello');

    expect(task.name).toBe('simple');
    expect(task.command).toBe('echo hello');
    // Status may be pending or running depending on queue processing
    expect(['pending', 'running']).toContain(task.status);
  });

  test('should assign unique IDs to different tasks', () => {
    const queue = new TaskQueue();
    const task1 = queue.addTask('task1', 'echo 1', { chatId: '123' });
    const task2 = queue.addTask('task2', 'echo 2', { chatId: '456' });
    const task3 = queue.addTask('task3', 'echo 3', { chatId: '789' });

    expect(task1.id).not.toBe(task2.id);
    expect(task2.id).not.toBe(task3.id);
    expect(task1.id).not.toBe(task3.id);
  });

  test('should preserve task metadata', () => {
    const queue = new TaskQueue();
    const options = {
      chatId: '123456',
      metadata: { user: 'testuser' },
      cwd: '/workspace/test'
    };

    const task = queue.addTask('meta-task', 'echo test', options);

    expect(task.chatId).toBe('123456');
    expect(task.metadata).toEqual({ user: 'testuser' });
    expect(task.cwd).toBe('/workspace/test');
  });

  test('should reject invalid command parameter', () => {
    const queue = new TaskQueue();

    expect(() => {
      queue.addTask('bad-task', null);
    }).toThrow('Invalid command parameter');

    expect(() => {
      queue.addTask('bad-task', 123);
    }).toThrow('Invalid command parameter');

    expect(() => {
      queue.addTask('bad-task', '');
    }).toThrow('Command parameter cannot be empty');
  });
});

describe('Task Queue - Task Status', () => {
  let TaskQueue;

  beforeAll(async () => {
    const module = await import('../src/task-queue.js');
    TaskQueue = module.TaskQueue;
  });

  test('should initialize tasks with status', () => {
    const queue = new TaskQueue();
    const task = queue.addTask('test', 'echo test', { chatId: '123' });

    // Status may be pending or running depending on queue processing
    expect(['pending', 'running']).toContain(task.status);
  });

  test('should include timestamp in task', () => {
    const queue = new TaskQueue();
    const beforeTime = Date.now();
    const task = queue.addTask('test', 'echo test', { chatId: '123' });
    const afterTime = Date.now();

    expect(task.createdAt).toBeDefined();
    const taskTime = new Date(task.createdAt).getTime();
    expect(taskTime).toBeGreaterThanOrEqual(beforeTime);
    expect(taskTime).toBeLessThanOrEqual(afterTime);
  });

  test('should handle long commands', () => {
    const queue = new TaskQueue();
    const longCommand = 'echo ' + 'x'.repeat(1000);
    const task = queue.addTask('long', longCommand, { chatId: '123' });

    expect(task.command).toBe(longCommand);
    expect(task.command.length).toBeGreaterThan(1000);
  });

  test('should handle special characters in command', () => {
    const queue = new TaskQueue();
    const specialCommand = 'echo "Test with symbols !@#$%"';
    const task = queue.addTask('special', specialCommand, { chatId: '123' });

    expect(task.command).toBe(specialCommand);
  });

  test('should handle null chatId gracefully', () => {
    const queue = new TaskQueue();
    const task = queue.addTask('test', 'echo test', { chatId: null });

    expect(task.chatId).toBeNull();
    expect(task.id).toBeDefined();
  });

  test('should use current directory when cwd not provided', () => {
    const queue = new TaskQueue();
    const task = queue.addTask('test', 'echo test', { chatId: '123' });

    expect(task.cwd).toBeDefined();
    expect(typeof task.cwd).toBe('string');
  });

  test('should respect provided cwd', () => {
    const queue = new TaskQueue();
    const task = queue.addTask('test', 'echo test', {
      chatId: '123',
      cwd: '/custom/path'
    });

    expect(task.cwd).toBe('/custom/path');
  });
});

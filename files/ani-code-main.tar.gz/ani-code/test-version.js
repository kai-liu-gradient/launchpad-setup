#!/usr/bin/env node

import { DaemonClient } from './src/daemon-client.js';
import chalk from 'chalk';

async function testVersionCheck() {
  const client = new DaemonClient();

  console.log(chalk.blue('Testing version compatibility check...'));

  // Check if daemon is running
  if (!client.isDaemonRunning()) {
    console.log(chalk.yellow('Daemon is not running. Cannot test version check.'));
    console.log(chalk.gray('Start daemon with: ani-code daemon --start'));
    return;
  }

  // Test version check
  const result = await client.checkVersionCompatibility();

  console.log('\nVersion Check Result:');
  console.log('-------------------');

  if (result.error) {
    console.log(chalk.yellow(`Warning: ${result.error}`));
    console.log(chalk.gray('(Version check failed but assuming compatible)'));
  } else {
    console.log(`CLI Version: ${chalk.green(result.cliVersion || 'Unknown')}`);
    console.log(`Daemon Version: ${chalk.green(result.daemonVersion || 'Unknown')}`);

    if (!result.compatible) {
      console.log(chalk.red('\n✗ Version Incompatibility Detected'));
      console.log(chalk.red(result.message));
    } else if (result.warning) {
      console.log(chalk.yellow('\n⚠ Version Warning'));
      console.log(chalk.yellow(result.message));
    } else {
      console.log(chalk.green('\n✓ Versions are compatible'));
    }
  }
}

testVersionCheck().catch(console.error);
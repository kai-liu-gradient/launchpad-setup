#!/usr/bin/env node
import crypto from 'crypto';
import { promises as fs } from 'fs';
import path from 'path';
import { homedir } from 'os';

const tokenFile = path.join(homedir(), '.anicode', 'plugin-tokens.json');

async function debugTokenValidation() {
  console.log('🔍 Debugging Token Validation');
  console.log('='.repeat(50));
  
  // Read saved tokens
  const tokensData = await fs.readFile(tokenFile, 'utf8');
  const tokens = JSON.parse(tokensData);
  console.log('📁 Saved tokens:', Object.keys(tokens));
  
  // Get the token we're trying to validate - NEW TOKEN ID
  const tokenId = '932d62736e3cafb14cfd512a3026b1cc';
  const savedToken = tokens[tokenId];
  
  if (!savedToken) {
    console.error('❌ Token not found in saved tokens');
    return;
  }
  
  console.log('✅ Found saved token:', {
    id: savedToken.id,
    project: savedToken.project,
    secretHash: savedToken.secretHash
  });
  
  // The actual token sent by extension (from the decoded config) - NEW TOKEN
  const actualToken = 'eyJpZCI6IjkzMmQ2MjczNmUzY2FmYjE0Y2ZkNTEyYTMwMjZiMWNjIiwicHJvamVjdCI6ImFuaS1jb2RlIiwicHJvamVjdFBhdGgiOiIvcm9vdC93b3Jrc3BhY2UvYW5pLWNvZGUiLCJzZXJ2ZXJVcmwiOiJ3c3M6Ly90eW9zcC5zdGVhZHloYXNoLmFpL2JtYy1kZXYtdG9reW8tZHVrZTAxL2FuaWNvZGUtd3MiLCJjcmVhdGVkQXQiOjE3NTYzODM2NTU5MzgsImV4cGlyZXNBdCI6MTc1Njk4ODQ1NTkzOCwiaG9zdG5hbWUiOiJibWMtZGV2LXRva3lvLWR1a2UwMSIsInVzZXIiOiJyb290In0=.30f66c4a253bc6e953a79baf3ae1d17addc14131ff5513a1871d2fff9c6abf31.c99fc333d258bbc71e9b2fc1f205d78feb539ec245e20d0825bc342fc33479f7';
  
  const parts = actualToken.split('.');
  console.log('🔢 Token parts count:', parts.length);
  
  if (parts.length !== 3) {
    console.error('❌ Invalid token format');
    return;
  }
  
  const [encodedPayload, signature, secret] = parts;
  console.log('📦 Token parts:', {
    payloadLength: encodedPayload.length,
    signatureLength: signature.length,
    secretLength: secret.length
  });
  
  // Decode payload
  const payload = JSON.parse(Buffer.from(encodedPayload, 'base64').toString());
  console.log('📄 Payload:', payload);
  
  // Verify signature with the secret from the token
  const expectedSignature = crypto
    .createHmac('sha256', secret)
    .update(encodedPayload)
    .digest('hex');
  
  console.log('🔐 Signature verification:');
  console.log('  Expected:', expectedSignature);
  console.log('  Actual  :', signature);
  console.log('  Match   :', signature === expectedSignature);
  
  // Check if the secret hash matches what's saved
  const secretHash = crypto.createHash('sha256').update(secret).digest('hex');
  console.log('🔑 Secret hash verification:');
  console.log('  Computed:', secretHash);
  console.log('  Saved   :', savedToken.secretHash);
  console.log('  Match   :', secretHash === savedToken.secretHash);
  
  // Check expiration
  const now = Date.now();
  console.log('⏰ Expiration check:');
  console.log('  Now     :', new Date(now).toISOString());
  console.log('  Expires :', new Date(payload.expiresAt).toISOString());
  console.log('  Valid   :', now < payload.expiresAt);
}

debugTokenValidation().catch(console.error);
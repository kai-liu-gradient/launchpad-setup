# Claude Configuration

## CRITICAL - DO NOT RESTART OR KILL SERVICES

**NEVER restart/stop/kill the ani-code daemon or nodejs processes!**

Forbidden: `systemctl restart|stop|kill ani-code`, `sudo systemctl restart|stop|kill ani-code`, killing nodejs processes.

This will terminate Claude immediately, interrupt all tasks, and potentially cause data loss.

Safe read-only commands: `ani-code daemon --status`, `systemctl status ani-code`

## Version Management

Update `package.json` version using semver: MAJOR (breaking API), MINOR (new features), PATCH (bug fixes). CLI auto-checks daemon version compatibility.

## Project Context

- Documentation: `pd/` folder (`pd/api/`, `pd/changes/`, `pd/architecture/`, `pd/features/`)
- Daily changes: `pd/changes/YYYY-MM-DD.md`
- Full read/write access to `pd/`
- Detailed command reference: `pd/api/command-reference.md`

## Key Commands Quick Reference

| Command | Purpose |
|---------|---------|
| `ani-code healthcheck` | Project health analysis |
| `ani-code projects` | Project discovery & version management |
| `ani-code providers` | CLI provider management |
| `ani-code chatui` | Display mode (full/simple) |
| `ani-code hint` | Transient context injection |
| `ani-code goals sync` | Goal file analysis (batched, 10/batch) |
| `ani-browser snapshot <url>` | Full web diagnostic |

## Port Configuration

| Service | Default | Env Variable |
|---------|---------|-------------|
| Daemon HTTP API | 6501 | `ANI_CODE_DAEMON_PORT` (fallback: `HTTP_CALLBACK_PORT`, `PORT`) |
| WebSocket | 6502 | `ANICODE_WS_PORT` |

## CLI Providers

Supported: `claude` (default), `copilot`, `codex`, `gemini`, `cursor`, `opencode`

Selection: `CLI_PROVIDER_ID` env > workspace meta > `claude`

Task targeting: `@@copilot`, `@@opencode` syntax in task messages.

## Gateway Callback Signing

Set `PROJECT_GATEWAY_KEY` env var (64-byte hex) to enable HMAC-SHA256 signing on outbound callbacks. Auto-detected; legacy mode (unsigned) if key not set.

## Development Workflow

1. Run `npm run lint` and `npm test` before committing
2. Follow existing code patterns
3. Services auto-restart on failure - trust it, don't restart manually
4. Keep responses concise and actionable

## Web Development

See `pd/rules/web-development.md`, `pd/definitions/react-patterns.md`, `pd/rules/ui-ux-guidelines.md`

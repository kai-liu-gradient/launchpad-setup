# ⚠️ IMPORTANT: Reload the Chrome Extension

**Version 1.0.1** - Fixed CSP and Error Handling

The browser is still using the old cached version. You MUST reload the extension for ALL changes to take effect.

## Steps to Reload:

1. **Open Chrome Extensions Page**
   - Go to `chrome://extensions/`
   - Or click the puzzle piece icon → "Manage Extensions"

2. **Find the AniCode Extension**
   - Look for "AniCode Editor Bridge" in the list

3. **Reload the Extension**
   - Click the **↻ Reload** button on the extension card
   - Or toggle the extension OFF and then ON again

4. **Verify the Reload**
   - The extension icon might briefly disappear and reappear
   - Open Developer Tools (F12) on the extensions page
   - Look for any error messages in the console

5. **Test Again**
   - Close and reopen the popup
   - Click "Test Sync Message" - should work now
   - Click "Test Async Message" - should work now

## Why This Happens

Chrome caches the background script (service worker) for performance. When you make changes to the code, you must manually reload the extension for Chrome to pick up the new version.

## Alternative Method

If the reload button doesn't work:
1. Disable the extension (toggle OFF)
2. Wait 2 seconds
3. Enable the extension (toggle ON)
4. This forces Chrome to completely restart the extension

## What's Fixed in Version 1.0.1

1. **Content Security Policy (CSP)**
   - Fixed WebSocket connection blocking
   - Updated CSP to allow connections to `wss://tyosp.steadyhash.ai`
   - Added support for wildcard subdomains

2. **Error Handling**
   - Better error messages for connection failures
   - Specific messages for CSP violations, timeouts, and connection refused
   - Multi-line error display in popup
   - Detailed error logging in console

3. **Message Passing**
   - Fixed async message handling
   - Proper error propagation from background to popup
   - Test buttons for sync/async verification

## Verify It's Working

After reloading, you should see:
1. **In console**: "AniCode Bridge constructor called - VERSION 2.0 WITH ASYNC FIX"
2. **Version check**: Extension version should be "1.0.1" in chrome://extensions/
3. **Test messages**: Both sync and async tests should pass
4. **Connection**: WebSocket should connect without CSP errors

## If Connection Still Fails

1. Check the console for specific error messages
2. If you see "CSP" or "blocked", reload the extension again
3. If you see "timeout", verify the AniCode server is running
4. If you see "refused", check the server URL in the token
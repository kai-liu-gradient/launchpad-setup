#!/usr/bin/env node

import { spawn } from 'child_process';
import { setTimeout } from 'timers/promises';

async function testSync() {
  console.log('Testing goals sync with fix for missing goals...\n');

  const proc = spawn('ani-code', ['goals', 'sync', '--full'], {
    cwd: '/root/workspace/ghisha-helix',
    stdio: 'pipe',
    env: process.env
  });

  let output = '';

  proc.stdout.on('data', (data) => {
    const text = data.toString();
    output += text;
    process.stdout.write(text);
  });

  proc.stderr.on('data', (data) => {
    const text = data.toString();
    output += text;
    process.stderr.write(text);
  });

  return new Promise((resolve) => {
    proc.on('close', async (code) => {
      console.log(`\n\nSync process exited with code ${code}`);

      if (code === 0) {
        // Check if goal 061 is now in cache
        console.log('\nChecking if goal 061 is now in cache...');
        await setTimeout(1000);

        const checkProc = spawn('node', ['/root/workspace/ani-code/check-cache.js'], {
          stdio: 'inherit'
        });

        checkProc.on('close', () => {
          resolve();
        });
      } else {
        resolve();
      }
    });
  });
}

testSync().catch(console.error);
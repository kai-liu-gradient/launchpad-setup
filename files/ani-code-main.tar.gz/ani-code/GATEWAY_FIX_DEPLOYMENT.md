# Gateway Fix Deployment Guide

## Changes Summary

Fixed the issue where ani-code wasn't sending response messages back through the gateway when receiving commands from Telegram.

### Root Cause - CRITICAL DISCOVERY

**The system was using `DummyTelegramNotifier`** (for gateway-only operation without real Telegram credentials), but this class **did not implement gateway callback routing**. Messages were being logged but never actually sent through the gateway callback endpoint.

### Files Modified

1. **src/telegram-notifier.js** - Enhanced gateway callback logging
2. **src/http-server.js** - Added error path logging in createTelegramTask
3. **src/dummy-telegram-notifier.js** - **CRITICAL FIX**: Added gateway callback support

## Deployment Steps

### Option 1: Deploy to Production Server

1. **Commit the changes:**
   ```bash
   cd /root/workspace/ani-code
   git add src/telegram-notifier.js src/http-server.js
   git commit -m "fix: enhance gateway callback logging and error handling"
   git push
   ```

2. **On the production server where ani-code daemon is running:**
   ```bash
   # Pull the latest changes
   cd /path/to/ani-code
   git pull

   # Install dependencies (if any changed)
   npm install

   # Restart the daemon
   systemctl restart ani-code

   # Verify it's running
   systemctl status ani-code
   ```

3. **Test the fix:**
   - Send `/add hi` from Telegram chat -4868224422
   - Check logs: `journalctl -u ani-code -f`
   - Look for: `[Gateway] Attempting to send message via gateway callback`

### Option 2: Test Locally First

1. **Start local daemon:**
   ```bash
   cd /root/workspace/ani-code

   # Set required environment variables
   export GATEWAY_URL="https://launchpad.corp.anispark.xyz/gatewayproxy/"
   export TELEGRAM_BOT_TOKEN="your-bot-token"

   # Run daemon
   node src/daemon-runner.js
   ```

2. **Send test webhook:**
   ```bash
   curl -X POST http://localhost:6501/callback/telegram \
     -H "Content-Type: application/json" \
     -H "x-gateway-token: test-token" \
     -d '{
       "message": {
         "message_id": 999,
         "chat": {"id": -4868224422, "type": "group"},
         "from": {"id": 394977994, "username": "viilachen"},
         "text": "/add hi",
         "date": 1732291676
       }
     }'
   ```

3. **Check logs for:**
   ```
   [Gateway] No workdir configured for chat -4868224422
   [Gateway] Routing message through gateway for chat -4868224422
   [Gateway] Attempting to send message via gateway callback
   [Gateway] ✓ Message sent successfully via gateway
   ```

## What to Expect

### Before Fix
- No logs showing gateway callback attempts
- No response sent to user in Telegram
- Silent failure

### After Fix
- Detailed logs at every step:
  ```
  INFO: [Gateway] No workdir configured for chat -4868224422
  DEBUG: [Gateway] Routing message through gateway for chat -4868224422
  INFO: [Gateway] Attempting to send message via gateway callback {
    "platform": "telegram",
    "chatId": -4868224422,
    "messageLength": 78,
    "gatewayUrl": "https://...",
    "instanceId": "project-p-6o0kp4lu"
  }
  INFO: [Gateway] ✓ Message sent successfully via gateway
  INFO: [Gateway] Error message sent to chat -4868224422 about missing workdir
  ```
- User receives error message in Telegram
- If gateway fails, automatic fallback to direct Telegram API

## Verification Checklist

- [ ] Changes committed and pushed to git
- [ ] Production server has latest code
- [ ] Daemon restarted successfully
- [ ] Test command sent from Telegram
- [ ] Gateway callback logs appear in journalctl
- [ ] User receives response message
- [ ] No errors in logs

## Troubleshooting

### If gateway logs still don't appear:

1. **Check gateway is enabled:**
   ```bash
   journalctl -u ani-code -n 100 | grep "gateway.*enabled\|GATEWAY_URL"
   ```

2. **Verify GATEWAY_URL is set:**
   ```bash
   systemctl show ani-code | grep GATEWAY_URL
   ```

3. **Check config.gateway.enabled:**
   - Gateway is enabled when `GATEWAY_URL` env var is set
   - See `src/config.js` line 64

### If messages still aren't sent:

1. **Check if sendViaGateway is being called:**
   ```bash
   journalctl -u ani-code -f | grep "sendViaGateway\|Routing message"
   ```

2. **Verify gateway callback endpoint:**
   - Should be: `{GATEWAY_URL}/api/callback/message`
   - Check if endpoint exists and is accessible

3. **Test gateway callback manually:**
   ```bash
   curl -X POST https://launchpad.corp.anispark.xyz/gatewayproxy/api/callback/message \
     -H "Content-Type: application/json" \
     -H "x-instance-id: project-p-6o0kp4lu" \
     -H "x-gateway-token: your-token" \
     -d '{
       "platform": "telegram",
       "chatId": -4868224422,
       "message": {
         "text": "Test message"
       },
       "instanceId": "project-p-6o0kp4lu",
       "timestamp": "2025-11-22T15:30:00.000Z"
     }'
   ```

## Rollback Plan

If issues occur after deployment:

```bash
# On production server
cd /path/to/ani-code
git revert HEAD
systemctl restart ani-code
```

## Support

- Check logs: `journalctl -u ani-code -f`
- Review: `GATEWAY_FIX_SUMMARY.md` for detailed explanation
- Contact: Development team if issues persist

#!/usr/bin/env node

import { WorkspaceManager } from './src/workspace-manager.js';

async function findAniCodeWorkspace() {
  const manager = new WorkspaceManager();
  
  try {
    await manager.initialize();
    
    // Get all workspaces
    const workspaces = await manager.listWorkspaces(true);
    
    console.log('Looking for ani-code workspace...\n');
    
    // Find ani-code workspace
    const aniCodeWorkspace = workspaces.find(ws => 
      ws.name.toLowerCase().includes('ani-code') || 
      ws.path?.includes('ani-code')
    );
    
    if (aniCodeWorkspace) {
      console.log('✅ Found ani-code workspace:');
      console.log('   Name:', aniCodeWorkspace.name);
      console.log('   Path:', aniCodeWorkspace.path);
      console.log('   Chat ID:', aniCodeWorkspace.chatId || 'Not set');
      
      if (aniCodeWorkspace.settings) {
        console.log('   Settings:', JSON.stringify(aniCodeWorkspace.settings, null, 2));
      }
      
      if (aniCodeWorkspace.chatId) {
        console.log('\n📝 To use this chat ID as default, add to .env:');
        console.log(`   TELEGRAM_CHAT_ID=${aniCodeWorkspace.chatId}`);
      }
    } else {
      console.log('❌ No ani-code workspace found');
      
      // Show all workspaces
      console.log('\nAvailable workspaces:');
      workspaces.forEach(ws => {
        console.log(`  - ${ws.name} (${ws.path}) - Chat ID: ${ws.chatId || 'Not set'}`);
      });
    }
    
    await manager.close();
  } catch (error) {
    console.error('Error:', error);
    await manager.close();
  }
}

findAniCodeWorkspace();
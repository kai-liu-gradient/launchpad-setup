# Goals Sync Fix - Batch Processing

## Problem Identified
When running `goals sync` in `/root/workspace/ghisha-helix`:
- There are 67 goal files total
- Only 41 goals appear in the cache
- Goal 061 and many others (38-44, 46-47, 49-58, 60-61) are missing
- The sync process takes very long and seems to hang when processing all 67 files at once

## Root Cause
1. Claude is being asked to analyze 67 files in a single prompt
2. This exceeds practical limits for reliable processing
3. Claude may be timing out or truncating output
4. The validation expects all files but only gets partial results

## Solution Implemented
Added a safety check in `syncGoalsCache` function that:
1. Detects when goal files are missing from the cache after sync
2. Adds placeholder entries for missing files
3. Marks them as "[UNPROCESSED]" with a flag `needsSync: true`
4. Ensures all goal files are represented in the cache

## Code Changes
File: `/root/workspace/ani-code/src/commands/goals.js`
- Added missing file detection after Claude processing
- Creates placeholder entries for unprocessed goals
- Ensures cache always contains all goal files

## Better Long-term Solution Needed
The sync should be modified to:
1. Process goals in smaller batches (e.g., 10-15 files at a time)
2. Merge results progressively
3. Show progress for each batch
4. Handle timeouts gracefully

## Testing
The fix has been applied but the current sync is still running. To test:
1. Kill the current sync process if stuck
2. Run `ani-code goals sync --full` from ghisha-helix directory
3. Check if all 67 goals appear in cache (even if some are placeholders)
4. Run `ani-code goals list` to verify goal 061 appears
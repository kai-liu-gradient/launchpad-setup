# Goals API Implementation

## Overview

Implemented HTTP REST API endpoints in ani-code daemon to expose goals from the filesystem, enabling the gateway to fetch and aggregate goals across multiple project instances.

## Changes Made

### File: `src/http-server.js`

#### 1. Added Imports (lines 22-26)
```javascript
import {
  findGoalFiles,
  parseGoalFile,
  extractGoalId
} from './utils/goals-utils.js';
```

#### 2. Fixed URL Parsing (lines 647-648)
```javascript
async handleRequest(req, res) {
  const url = parse(req.url, true);
  let { pathname } = url;
```

#### 3. Added Route Handler (lines 716-718)
```javascript
// Goals API endpoints (no auth required - public access from gateway)
if (pathname === '/api/goals' || pathname.startsWith('/api/goals/')) {
  await this.handleGoalsAPI(req, res, pathname, url.query);
}
```

#### 4. Implemented Handler Functions

**`handleGoalsAPI(req, res, pathname, query)`** - Main router
- Routes to appropriate handler based on path
- Returns empty array with success=true if no goals directory exists
- Handles errors gracefully

**`handleGoalsList(req, res, query, goalsDir)`** - List all goals
- GET `/api/goals`
- Query parameters: `status`, `limit`, `offset`
- Parses all goal files and returns structured data

**`handleSingleGoal(req, res, goalNumber, goalsDir)`** - Get specific goal
- GET `/api/goals/:goalNumber`
- Returns 404 if goal not found
- Includes full file content in response

## API Endpoints

### GET /api/goals

List all goals from `/workspace/pd/goals/` directory.

**Query Parameters:**
- `workspace` (optional) - Workspace path (default: `/workspace`)
  - Priority: query param > `WORKSPACE` env var > `/workspace`
  - Example: `?workspace=/workspace` or `?workspace=/custom/workspace/path`
  - Used to locate the goals directory at `{workspace}/pd/goals`
  - **Important:** Single goal endpoint also respects this parameter
- `status` (optional) - Filter by status: `not_started`, `in_progress`, `completed`, `blocked`, `cancelled`
- `limit` (optional) - Max goals to return (default: 100)
- `offset` (optional) - Pagination offset (default: 0)

**Response:**
```json
{
  "success": true,
  "goals": [
    {
      "goal_number": 1,
      "title": "Implement user authentication",
      "status": "In Progress",
      "objective": "Add secure authentication to the application",
      "progress": 45,
      "start_date": "2025-11-20",
      "completion_date": null,
      "last_updated": "2025-11-21T13:30:00Z",
      "tasks": [
        {"title": "Design auth flow", "completed": true},
        {"title": "Implement JWT tokens", "completed": false}
      ],
      "acceptance_criteria": [],
      "dependencies": [],
      "file_path": "pd/goals/001-user-authentication.md"
    }
  ],
  "total": 1,
  "source": "filesystem",
  "timestamp": "2025-11-21T13:30:00Z"
}
```

### GET /api/goals/:goalNumber

Get detailed information for a specific goal.

**Query Parameters:**
- `workspace` (optional) - Workspace path (default: `/workspace`)
  - Same as list endpoint, allows specifying custom workspace location

**Response:**
```json
{
  "success": true,
  "goal": {
    "goal_number": 1,
    "title": "Implement user authentication",
    "status": "In Progress",
    "objective": "Add secure authentication to the application",
    "progress": 45,
    "start_date": "2025-11-20",
    "completion_date": null,
    "last_updated": "2025-11-21T13:30:00Z",
    "tasks": [...],
    "acceptance_criteria": [],
    "dependencies": [],
    "file_path": "pd/goals/001-user-authentication.md",
    "file_content": "# Goal: Implement User Authentication\n\n..."
  }
}
```

## Testing

**Note:** Changes require daemon restart to take effect. Test after next daemon restart.

### Local Testing (Inside Pod)

```bash
# List all goals (uses default workspace)
curl -s http://localhost:6501/api/goals | jq '.'

# List goals from custom workspace
curl -s "http://localhost:6501/api/goals?workspace=/custom/workspace" | jq '.'

# Filter by status
curl -s "http://localhost:6501/api/goals?status=in_progress" | jq '.'

# Pagination
curl -s "http://localhost:6501/api/goals?limit=10&offset=0" | jq '.'

# Get specific goal
curl -s http://localhost:6501/api/goals/1 | jq '.'

# Combined: custom workspace + filtering + pagination
curl -s "http://localhost:6501/api/goals?workspace=/workspace&status=in_progress&limit=5" | jq '.'
```

### Gateway Integration Testing

```bash
# Test via gateway (after daemon restart in target project)
curl -s "http://localhost:6555/api/projects/PROJECT_ID/goals" \
  -H "x-api-key: YOUR_API_KEY" | jq '.'
```

### Test from Inside Pod (Kubernetes)

```bash
# Test from inside project pod
kubectl exec -n anilaunchpad project-p-xxxxx -- curl -s http://localhost:6501/api/goals
```

## Features

✅ **No authentication required** - Public access from gateway
✅ **Graceful handling** - Returns empty array with success=true when no goals exist (not 404)
✅ **Error handling** - Handles missing directories and parse errors gracefully
✅ **Status filtering** - Supports both "in_progress" and "In Progress" formats
✅ **Pagination** - Supports limit and offset parameters
✅ **Sorted results** - Goals sorted by goal_number
✅ **Full content** - Single goal endpoint includes complete file content
✅ **Reuses existing code** - Uses existing goal parsing logic from goals-utils.js

## Implementation Status

- ✅ Code implemented
- ✅ Syntax validated (no errors)
- ⏳ Awaiting daemon restart for changes to take effect
- ⏳ Gateway integration testing pending

## Next Steps

1. Daemon will automatically pick up changes on next restart
2. Test endpoints locally with curl
3. Verify gateway can fetch goals from project workspaces
4. Confirm UI Goals tab displays project goals

## Related Files

- `src/http-server.js` - HTTP server with goals endpoints
- `src/utils/goals-utils.js` - Goal parsing utilities
- `src/commands/goals.js` - Goals CLI commands
- `/root/workspace/ani-launchpad/pd/todo/implement-daemon-goals-api-endpoint.md` - Original requirements

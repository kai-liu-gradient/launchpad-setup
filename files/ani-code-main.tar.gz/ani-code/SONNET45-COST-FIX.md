# Sonnet 4.5 Cost Tracking Fix

## Issue
Tasks using Sonnet 4.5 (`claude-sonnet-4-5-20250929`) were showing cost = $0 in task completion notifications and database records.

## Root Cause Analysis

### What Was Working
- ✅ ccusage v17.1.1 correctly calculates Sonnet 4.5 pricing
- ✅ Daily usage reports show correct costs ($3.56 for today)
- ✅ Model breakdowns include Sonnet 4.5 with accurate pricing

### The Actual Problem
The issue is in the **snapshot timing and processing delay**:

1. **Before snapshot** is taken when task starts
2. **Task executes** (makes API calls to Claude)
3. **2-second delay** to let ccusage process usage data
4. **After snapshot** is taken
5. **Cost diff calculated** as: `after.totalCost - before.totalCost`

The problem: **2 seconds wasn't enough time for ccusage to process and price the usage data**, especially for Sonnet 4.5 which may require additional processing time.

When the after snapshot is taken before ccusage finishes processing:
- Both snapshots show the same cumulative costs
- Diff calculation: `$3.56 - $3.56 = $0`
- Task gets recorded with cost = $0

## Changes Made

### 1. Increased Processing Delay (src/usage-reporter.js:298)
```javascript
// OLD: 2 second delay
await new Promise(resolve => setTimeout(resolve, 2000));

// NEW: 3 second delay
await new Promise(resolve => setTimeout(resolve, 3000));
```

### 2. Enhanced Debug Logging (src/usage-reporter.js:490-503)
Added detailed logging to track cost calculation issues:

```javascript
// Log before/after values with full token breakdown
logger.debug(`[USAGE_DIFF] Before snapshot: cost=${before.totalCost}, tokens=${before.totalTokens}, input=${before.inputTokens}, output=${before.outputTokens}`);
logger.debug(`[USAGE_DIFF] After snapshot: cost=${after.totalCost}, tokens=${after.totalTokens}, input=${after.inputTokens}, output=${after.outputTokens}`);
logger.debug(`[USAGE_DIFF] Calculated diff: cost=${costDiff}, tokens=${tokenDiff}, inputDiff=${inputDiff}, outputDiff=${outputDiff}`);

// Warn if tokens changed but cost didn't
if (costDiff === 0 && tokenDiff > 0) {
  logger.warn(`[USAGE_DIFF] ⚠️  Tokens changed (${tokenDiff}) but cost is still 0 - possible pricing delay`);
}

// Warn if negative values detected
if (costDiff < 0 || tokenDiff < 0) {
  logger.warn(`[USAGE_DIFF] ⚠️  Negative diff detected - cost=${costDiff}, tokens=${tokenDiff}`);
}
```

### 3. Model Breakdown Logging (src/usage-reporter.js:519-542)
Added logging to track which models are found and processed:

```javascript
logger.debug(`[USAGE_DIFF] Found ${afterModels.length} models in after snapshot`);
for (const afterModel of afterModels) {
  const beforeModel = beforeModels.find(m => m.modelName === afterModel.modelName);
  const beforeCost = beforeModel ? beforeModel.cost : 0;
  const modelCostDiff = Math.max(0, afterModel.cost - beforeCost);

  logger.debug(`[USAGE_DIFF] Model ${afterModel.modelName}: before=$${beforeCost.toFixed(6)}, after=$${afterModel.cost.toFixed(6)}, diff=$${modelCostDiff.toFixed(6)}`);

  if (modelCostDiff > 0) {
    // ... add to breakdown ...
    logger.debug(`[USAGE_DIFF] ✅ Added ${afterModel.modelName} to breakdown`);
  } else {
    logger.debug(`[USAGE_DIFF] ⏭️  Skipped ${afterModel.modelName} (no cost diff)`);
  }
}
logger.debug(`[USAGE_DIFF] Total models in breakdown: ${modelBreakdowns.length}`);
```

## Testing

### To enable debug logging:
```bash
# Edit .env file
LOG_LEVEL=debug

# Restart daemon (WARNING: This will kill Claude!)
# Only do this after current conversation ends
sudo systemctl restart ani-code
```

### To verify the fix:
1. Run a task that makes Claude API calls
2. Check logs for `[USAGE_DIFF]` entries
3. Verify cost > 0 in task completion notification
4. Check database: `ani-code stats`

### Expected Log Output (Success):
```
[USAGE_DIFF] Before snapshot: cost=3.5600, tokens=320000, input=14000, output=6000
[USAGE_DIFF] After snapshot: cost=3.7800, tokens=360000, input=16000, output=8000
[USAGE_DIFF] Calculated diff: cost=0.2200, tokens=40000, inputDiff=2000, outputDiff=2000
[USAGE_DIFF] Found 1 models in after snapshot
[USAGE_DIFF] Model claude-sonnet-4-5-20250929: before=$3.560000, after=$3.780000, diff=$0.220000
[USAGE_DIFF] ✅ Added claude-sonnet-4-5-20250929 to breakdown
[USAGE_DIFF] Total models in breakdown: 1
```

### Expected Log Output (Timing Issue):
```
[USAGE_DIFF] Before snapshot: cost=3.5600, tokens=320000, input=14000, output=6000
[USAGE_DIFF] After snapshot: cost=3.5600, tokens=320000, input=14000, output=6000
[USAGE_DIFF] Calculated diff: cost=0, tokens=0, inputDiff=0, outputDiff=0
[USAGE_DIFF] Found 1 models in after snapshot
[USAGE_DIFF] Model claude-sonnet-4-5-20250929: before=$3.560000, after=$3.560000, diff=$0.000000
[USAGE_DIFF] ⏭️  Skipped claude-sonnet-4-5-20250929 (no cost diff)
[USAGE_DIFF] Total models in breakdown: 0
```

## Alternative Solutions (If 3s delay isn't enough)

### Option 1: Increase Delay Further
If 3 seconds still isn't enough, increase to 5 seconds:
```javascript
await new Promise(resolve => setTimeout(resolve, 5000));
```

### Option 2: Poll Until Cost Changes
Instead of fixed delay, poll ccusage until cost changes:
```javascript
let attempts = 0;
const maxAttempts = 10;
let afterData;

while (attempts < maxAttempts) {
  await new Promise(resolve => setTimeout(resolve, 500));
  afterData = await execAsync(command, { encoding: 'utf8', timeout: 30000 });
  const parsed = JSON.parse(afterData.stdout);

  if (parsed.totals.totalCost > beforeData.totals.totalCost) {
    break; // Cost has changed!
  }
  attempts++;
}
```

### Option 3: Use Timestamp-Based Filtering
Instead of daily cumulative data, use precise timestamps:
```javascript
// Get usage only since the task started
const startTime = new Date(task.startedAt).toISOString();
const command = `ccusage -j --offline --breakdown --after "${startTime}"`;
```

## Files Changed
- `src/usage-reporter.js` - Increased delay to 3s, added debug logging

## Verification
Run this command to check current ccusage pricing:
```bash
npx ccusage -j --offline --breakdown --since $(date +%Y%m%d) | jq '.daily[0].modelBreakdowns'
```

Should show:
```json
[
  {
    "modelName": "claude-sonnet-4-5-20250929",
    "cost": 3.555750899999999,
    ...
  }
]
```

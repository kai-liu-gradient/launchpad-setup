#!/usr/bin/env node

import { ChatSettingsManager } from './src/chat-settings.js';

async function fix() {
  const chatSettings = new ChatSettingsManager();
  await chatSettings.load();
  
  const telegramChatId = '394977994';
  const fullChatId = `telegram:${telegramChatId}`;
  const workspaceName = 'ani-code';
  const workspacePath = '/root/workspace/ani-code';
  
  console.log('\n=== Fixing Telegram Workspace Settings ===\n');
  
  // Check current settings
  const currentWorkdir = chatSettings.getWorkdir(fullChatId);
  console.log(`Current workdir for ${fullChatId}:`, currentWorkdir);
  
  // Set the correct workdir
  await chatSettings.setWorkdir(fullChatId, workspaceName, workspacePath);
  await chatSettings.save();
  
  console.log(`Set workdir for ${fullChatId} to: ${workspaceName} (${workspacePath})`);
  
  // Verify the fix
  const newWorkdir = chatSettings.getWorkdir(fullChatId);
  console.log(`New workdir for ${fullChatId}:`, newWorkdir);
  
  console.log('\n✅ Settings fixed and saved!');
}

fix().catch(console.error);
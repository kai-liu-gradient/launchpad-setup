import { EventEmitter } from 'events';
import { config } from './config.js';
import { UsageReporter } from './usage-reporter.js';
import { logger } from './logger.js';
import { TelegramNotifier } from './telegram-notifier.js';
import { isValidModel, normalizeModel, createInvalidModelError, getModelPreference, getModelFlags, extractProviderFromPrompt } from './model-utils.js';
import { getStatsDB } from './stats-db.js';
import { getProviderManager, getProviderManagerSync } from './providers/providerManager.js';
import { extractProviderConclusion, extractProviderTokens, extractProviderModel, extractProviderStats } from './providers/outputExtractor.js';
import { calculateTokenCost } from './providers/costCalculator.js';
import crypto from 'crypto';
import os from 'os';

// Global task counter, resets on daemon restart
let taskRandomPrefix = null;
let taskCounter = 1000; // Start from 1000 so first task is 1001

function generateTaskId(workdir = null) {
  // Generate new random prefix on daemon restart
  if (!taskRandomPrefix) {
    taskRandomPrefix = crypto.randomBytes(1).toString('hex').toUpperCase(); // 2 hex chars
  }
  
  // Increment counter (starts at 1001)
  taskCounter++;
  const counterStr = taskCounter.toString();
  
  // Format: ac-MMDD-workdir-XX01
  const now = new Date();
  const month = (now.getMonth() + 1).toString().padStart(2, '0');
  const day = now.getDate().toString().padStart(2, '0');
  
  // Extract workdir identifier from path if provided
  let workdirPart = '';
  if (workdir) {
    // Get last part of the path
    const pathParts = workdir.split('/').filter(p => p);
    if (pathParts.length > 0) {
      // Just use the last part
      workdirPart = pathParts[pathParts.length - 1];
      // Sanitize workdir part (remove special chars, limit length)
      workdirPart = workdirPart.replace(/[^a-zA-Z0-9]/g, '').substring(0, 10) + '-';
    }
  }
  
  return `ac-${month}${day}-${workdirPart}${taskRandomPrefix}${counterStr}`;
}

class OutputBuffer {
  constructor(maxLines = 1000) {
    this.maxLines = maxLines;
    this.lines = [];
    this.totalBytes = 0;
  }
  
  append(data) {
    const dataStr = data.toString();
    if (dataStr.length === 0) return;

    const parts = dataStr.split('\n');
    const endsWithNewline = dataStr.endsWith('\n');

    // First part may continue a previous partial line
    if (this.lines.length > 0 && !this.lines[this.lines.length - 1].complete) {
      this.lines[this.lines.length - 1].content += parts[0];
      // If there are more parts (data had at least one \n), the partial is now complete
      if (parts.length > 1) {
        this.lines[this.lines.length - 1].complete = true;
      }
      parts.shift(); // Remove first part, already handled
    }

    // All parts except the last are complete lines
    for (let i = 0; i < parts.length - 1; i++) {
      this.lines.push({ content: parts[i], complete: true });
    }

    // Handle last part
    if (parts.length > 0) {
      const lastPart = parts[parts.length - 1];
      if (!endsWithNewline) {
        // Last part is a new partial line
        this.lines.push({ content: lastPart, complete: false });
      }
      // If endsWithNewline, lastPart is empty string, nothing to add
    }

    // Keep only maxLines recent lines
    while (this.lines.length > this.maxLines) {
      this.lines.shift();
    }

    this.totalBytes += data.length;
  }
  
  getLines(count = null) {
    if (count === null) return this.lines.map(l => l.content);
    return this.lines.slice(-count).map(l => l.content);
  }
  
  getLastLines(count) {
    return this.lines.slice(-count).map(l => l.content);
  }
  
  getTotalBytes() {
    return this.totalBytes;
  }
}

export class TaskQueue extends EventEmitter {
  constructor(maxConcurrent = 3, workspaceManager = null) {
    super();
    this.maxConcurrent = maxConcurrent;
    this.workspaceManager = workspaceManager;
    this.runningTasks = new Map();
    this.pendingTasks = [];
    this.childProcesses = new Map(); // Store child processes for cancellation
    this.lastOutputTime = new Map(); // Track last output time for stuck detection
    this.taskOutputBuffers = new Map(); // Ring buffers for real-time output
    this.staleDetectionState = new Map(); // Track stale pattern detection for Claude tasks
    this.fatalErrorTimeouts = new Map(); // Track fatal error timeouts per task
    this.logStreams = new Map(); // File write streams for logging
    this.usageReporter = new UsageReporter(); // For tracking task usage
    this.runningTasksByProject = new Map(); // Track running tasks per project (workdir)
    this.taskHistory = []; // Keep history of completed tasks (last 10)
    this.maxHistorySize = 10;
    this.telegramNotifier = new TelegramNotifier(); // For error notifications
    this.streamLineBuffers = new Map(); // Track partial stdout/stderr lines per task for cleaner logging
  }

  addTask(taskName, command, options = {}) {
    // Validate command parameter
    if (typeof command !== 'string') {
      throw new Error(`Invalid command parameter: expected string, got ${typeof command}`);
    }
    if (!command || command.trim() === '') {
      throw new Error('Command parameter cannot be empty');
    }

    const cwd = options.cwd || process.cwd();
    // Extract known options to prevent overriding critical task properties
    const {
      priority,
      source,
      workspace,
      metadata,
      chatId,
      timeout,
      model,
      providerId,
      ...otherOptions
    } = options;

    // Validate model if provided
    if (model && !isValidModel(model)) {
      throw createInvalidModelError(model);
    }

    // Extract provider from command if not already specified
    // This handles @@gemini, @@codex, @@cursor syntax in commands
    let effectiveProviderId = providerId;
    if (!effectiveProviderId && command) {
      const extractedProvider = extractProviderFromPrompt(command);
      if (extractedProvider) {
        effectiveProviderId = extractedProvider;
        logger.info(`[TASK-QUEUE] Extracted provider '${effectiveProviderId}' from command`);
      }
    }

    const task = {
      id: generateTaskId(cwd),
      name: taskName,
      command,
      status: 'pending',
      createdAt: new Date(),
      startedAt: null,
      completedAt: null,
      error: null,
      output: '',
      exitCode: null,
      cwd: cwd, // Use provided cwd or current working directory
      priority,
      source,
      workspace,
      metadata,
      chatId,
      timeout,
      model: normalizeModel(model), // Normalize and store model preference
      providerId: effectiveProviderId, // Store provider ID for tracking which provider was requested
      ...otherOptions
    };

    // Log provider assignment for debugging
    logger.debug(`[TASK-QUEUE] Task ${task.id} created with providerId: ${task.providerId || 'NOT SET'}, source: ${task.source || 'unknown'}`);

    // Ensure status is never undefined or overridden
    if (!task.status || task.status === 'undefined') {
      task.status = 'pending';
    }

    this.pendingTasks.push(task);
    this.emit('taskAdded', task);

    // Record task creation in stats database
    try {
      const statsDB = getStatsDB();
      statsDB.recordTaskCreation(task.id, workspace || cwd, command, chatId);
    } catch (error) {
      logger.error(`Failed to record task creation stats: ${error.message}`);
    }

    this.processQueue();
    return task;
  }

  processQueue() {
    // Process tasks respecting per-project concurrency limits
    const tasksByProject = this.groupPendingTasksByProject();
    
    for (const [projectPath, projectTasks] of tasksByProject) {
      // Count only Claude tasks (not shell commands) for concurrent limit
      const runningClaudeTasks = this.getRunningClaudeTasksForProject(projectPath);
      
      // Check if this project can run more tasks
      // Shell commands don't count towards the limit, only Claude tasks do
      if (projectTasks.length > 0) {
        const nextTask = projectTasks[0];
        const isShellCommand = nextTask.command.startsWith('shell:');
        
        // Shell commands can always run, Claude tasks respect the limit
        if (isShellCommand || runningClaudeTasks < this.maxConcurrent) {
          const task = projectTasks.shift();
          // Remove from pending tasks
          const taskIndex = this.pendingTasks.findIndex(t => t.id === task.id);
          if (taskIndex !== -1) {
            this.pendingTasks.splice(taskIndex, 1);
          }
          this.executeTask(task);
          break; // Process one task at a time to maintain fairness across projects
        }
      }
    }
  }

  groupPendingTasksByProject() {
    const groups = new Map();
    for (const task of this.pendingTasks) {
      const projectPath = task.cwd;
      if (!groups.has(projectPath)) {
        groups.set(projectPath, []);
      }
      groups.get(projectPath).push(task);
    }
    return groups;
  }

  getRunningClaudeTasksForProject(projectPath) {
    let count = 0;
    for (const task of this.runningTasks.values()) {
      if (task.cwd === projectPath && !task.command.startsWith('shell:')) {
        count++;
      }
    }
    return count;
  }

  /**
   * Check if usage tracking (ccusage) should be enabled for this task
   * @param {Object} task - The task to check
   * @returns {boolean} True if usage should be tracked
   */
  shouldTrackUsage(task) {
    // If no provider specified, default to tracking (assume Claude)
    if (!task.providerId) {
      logger.debug(`[USAGE_TRACKING] No providerId, defaulting to tracking enabled`);
      return true;
    }

    // Get provider handler capabilities
    const providerManager = getProviderManagerSync();
    const handler = providerManager.getHandler(task.providerId);

    if (!handler) {
      // Handler not found - this could be a customClaude provider that wasn't registered
      // Still enable tracking since customClaude providers (ccr-based) use Claude and write to ccusage logs
      logger.info(`[USAGE_TRACKING] Provider ${task.providerId} handler not found, defaulting to tracking enabled (assuming Claude-compatible)`);
      return true;
    }

    const capabilities = handler.getCapabilities();
    const shouldTrack = capabilities.supportsCcusage !== false;

    // Log handler info for debugging
    const isCustom = typeof handler.isCustomClaude === 'function' && handler.isCustomClaude();
    const handlerInfo = isCustom ? `customClaude (binary: ${handler.binary})` : handler.id;
    logger.info(`[USAGE_TRACKING] Provider ${task.providerId} (${handlerInfo}) ccusage support: ${shouldTrack}`);
    return shouldTrack;
  }

  async executeTask(task) {
    task.status = 'running';
    task.startedAt = new Date();
    this.runningTasks.set(task.id, task);
    
    // Track running tasks per project
    const projectPath = task.cwd;
    const currentRunning = this.runningTasksByProject.get(projectPath) || 0;
    this.runningTasksByProject.set(projectPath, currentRunning + 1);
    
    this.emit('taskStarted', task);

    // Create usage snapshot before task execution (only for providers that support ccusage)
    // Wait for snapshot to complete before starting task to ensure proper cost tracking
    if (!task.command.startsWith('shell:') && this.shouldTrackUsage(task)) {
      try {
        await this.usageReporter.createTaskSnapshot(task.id, task.name, task);
        logger.debug(`[TASK_START] Usage snapshot created for task ${task.id}`);
      } catch (err) {
        logger.error(`Failed to create task snapshot: ${err.message}`);
        // Continue with task execution even if snapshot fails
      }
    }

    try {
      const result = await this.runClaudeCommand(task);
      task.output = result.output;
      task.exitCode = result.exitCode;
      task.status = result.exitCode === 0 ? 'completed' : 'failed';
      task.error = result.error;
    } catch (error) {
      task.status = 'failed';
      task.error = error.message;
      task.exitCode = 1;
      
      // Send error notification to default channel if configured
      if (this.telegramNotifier.isEnabled()) {
        this.telegramNotifier.sendErrorNotification(error, {
          source: 'task-queue',
          taskId: task.id,
          operation: `Running task: ${task.name}`,
          suggestion: 'Check task logs for more details'
        }).catch(notifyError => {
          logger.error('Failed to send error notification:', notifyError);
        });
      }
    } finally {
      // Check if task was already processed by cancelTask
      // (Running tasks cancelled by user will have status 'failed' and already be removed from runningTasks)
      if (!this.runningTasks.has(task.id)) {
        // Task was already handled by cancelTask, don't emit duplicate event
        return;
      }

      task.completedAt = new Date();

      // Merge parsed tokens/stats from provider output into taskUsage IMMEDIATELY (synchronous)
      // This is needed for providers like codex, gemini, and cursor that don't use ccusage API
      if (task.parsedStats && task.parsedStats.usageV2) {
        // Use detailed stats from extractProviderStats (Gemini with full token breakdown)
        if (!task.usage) {
          task.usage = {
            cost: 0,
            tokens: 0,
            inputTokens: 0,
            outputTokens: 0,
            cacheCreationTokens: 0,
            cacheReadTokens: 0,
            duration: 0,
            modelsUsed: [],
            modelBreakdowns: []
          };
        }

        const totals = task.parsedStats.totals;
        task.usage.tokens = totals.totalTokens;
        task.usage.inputTokens = totals.inputTokens;
        task.usage.outputTokens = totals.outputTokens;
        task.usage.cacheReadTokens = totals.cachedTokens;

        // Calculate cost for each model and build usageV2
        task.usage.usageV2 = [];
        let totalCost = 0;

        for (const modelUsage of task.parsedStats.usageV2) {
          const costResult = calculateTokenCost({
            providerId: modelUsage.providerId || task.providerId || 'gemini',
            modelId: modelUsage.modelId,
            inputTokens: modelUsage.inputTokens,
            outputTokens: modelUsage.outputTokens,
            cachedTokens: modelUsage.inputCachedTokens
          });

          task.usage.usageV2.push({
            modelId: modelUsage.modelId,
            providerId: modelUsage.providerId || task.providerId || 'gemini',
            inputTokens: modelUsage.inputTokens,
            inputCachedTokens: modelUsage.inputCachedTokens,
            outputTokens: modelUsage.outputTokens,
            totalTokens: modelUsage.totalTokens,
            costUsd: costResult.totalCost
          });

          totalCost += costResult.totalCost;
          task.usage.modelsUsed.push(modelUsage.modelId);
        }

        task.usage.cost = totalCost;

        const modelsStr = task.usage.modelsUsed.join(', ');
        logger.info(`[STATS_MERGE] Created usageV2 from parsed stats for ${task.providerId} task ${task.id}: ` +
          `models=[${modelsStr}], in=${totals.inputTokens.toLocaleString()}, out=${totals.outputTokens.toLocaleString()}, ` +
          `cached=${totals.cachedTokens.toLocaleString()}, total=${totals.totalTokens.toLocaleString()}, cost=$${totalCost.toFixed(6)}`);
      } else if (task.parsedTokens !== undefined && task.parsedTokens !== null) {
        // Fallback: use simple parsed tokens (for providers without detailed stats)
        if (!task.usage) {
          // Create a basic usage object if it doesn't exist
          task.usage = {
            cost: 0,
            tokens: 0,
            inputTokens: 0,
            outputTokens: 0,
            cacheCreationTokens: 0,
            cacheReadTokens: 0,
            duration: 0,
            modelsUsed: [],
            modelBreakdowns: []
          };
        }

        // Use parsed tokens if ccusage didn't provide tokens or provided zero tokens
        if (!task.usage.tokens || task.usage.tokens === 0) {
          task.usage.tokens = task.parsedTokens;
          logger.info(`[TOKEN_MERGE] Merged ${task.parsedTokens.toLocaleString()} parsed tokens into taskUsage for task ${task.id}`);
        } else {
          // If ccusage provided tokens, prefer parsed tokens for non-claude providers
          if (task.providerId === 'codex' || task.providerId === 'cursor' || task.providerId === 'gemini') {
            logger.info(`[TOKEN_MERGE] Overriding ccusage tokens (${task.usage.tokens.toLocaleString()}) with parsed tokens (${task.parsedTokens.toLocaleString()}) for ${task.providerId}`);
            task.usage.tokens = task.parsedTokens;
          }
        }

        // Create usageV2 record for providers without ccusage if not already present
        if (!task.usage.usageV2 || task.usage.usageV2.length === 0) {
          const modelName = task.parsedModel || task.model || task.providerId || 'unknown';
          const providerId = task.providerId || 'unknown';

          // Calculate estimated cost based on provider and model pricing
          const costResult = calculateTokenCost({
            providerId: providerId,
            modelId: modelName,
            totalTokens: task.parsedTokens
          });

          task.usage.usageV2 = [{
            modelId: modelName,
            providerId: providerId,
            inputTokens: 0,  // Provider output may not separate input/output
            inputCachedTokens: 0,
            outputTokens: 0,
            totalTokens: task.parsedTokens,
            costUsd: costResult.totalCost
          }];

          // Update the main usage cost as well
          if (costResult.totalCost > 0) {
            task.usage.cost = costResult.totalCost;
          }

          logger.info(`[TOKEN_MERGE] Created usageV2 record for ${providerId} task ${task.id}: model=${modelName}, tokens=${task.parsedTokens}, estimatedCost=$${costResult.totalCost.toFixed(6)}`);
        }
      }

      this.runningTasks.delete(task.id);
      this.childProcesses.delete(task.id);

      // Update running tasks count per project
      const projectPath = task.cwd;
      const currentRunning = this.runningTasksByProject.get(projectPath) || 0;
      if (currentRunning > 0) {
        this.runningTasksByProject.set(projectPath, currentRunning - 1);
        if (currentRunning === 1) {
          this.runningTasksByProject.delete(projectPath);
        }
      }

      // Add to history before processing queue
      this.addToHistory(task);

      // Clean up temporary image files if task had attachments
      if (task.attachments && task.attachments.length > 0 && task.cwd) {
        try {
          const { cleanupTaskImages } = await import('./services/imageHandler.js');
          cleanupTaskImages(task.cwd, task.id);
        } catch (cleanupErr) {
          logger.debug(`[TASK ${task.id}] Failed to cleanup temp images: ${cleanupErr.message}`);
        }
      }

      // EMIT IMMEDIATELY - don't wait for usage calculation
      // This ensures gateway/telegram gets completion status right away
      this.emit('taskCompleted', task);
      this.processQueue();

      // Calculate usage asynchronously in background (don't block completion)
      // This allows the completion notification to be sent immediately
      if (!task.command.startsWith('shell:') && this.shouldTrackUsage(task)) {
        this.calculateUsageAsync(task).catch(error => {
          logger.error(`[ASYNC_USAGE] Failed to calculate usage for task ${task.id}: ${error.message}`);
        });
      } else {
        // For shell tasks or non-tracked providers, record stats immediately with no usage
        this.recordTaskStats(task);
      }
    }
  }

  async runClaudeCommand(task) {
    const { spawn } = await import('child_process');
    const { writeFileSync, mkdirSync, existsSync, createWriteStream } = await import('fs');
    const { join } = await import('path');

    // Get model preference outside of Promise constructor
    const modelPreferenceResult = await getModelPreference(task, this.workspaceManager);
    const modelPreference = modelPreferenceResult.model;

    // Log model preference source if found
    if (modelPreference && modelPreferenceResult.source) {
      if (modelPreferenceResult.source === 'prompt') {
        // Already logged in getModelPreference for prompt detection
      } else {
        logger.info(`[TASK ${task.id}] Model preference: ${modelPreference} (source: ${modelPreferenceResult.source})`);
      }
    }

    return new Promise(async (resolve) => {
      // Initialize output buffers for this task
      this.taskOutputBuffers.set(task.id, {
        stdout: new OutputBuffer(1000),
        stderr: new OutputBuffer(1000)
      });
      this.streamLineBuffers.set(task.id, { stdout: '', stderr: '' });

      let child;

      // Check if this is a shell command (starts with "shell:")
      if (task.command.startsWith('shell:')) {
        const shellCommand = task.command.substring(6); // Remove "shell:" prefix

        // Use a fallback working directory if not specified
        const workingDir = task.cwd || process.cwd();

        logger.info(`[TASK ${task.id}] Executing shell: ${shellCommand}`);
        logger.info(`[TASK ${task.id}] Working directory: ${workingDir}`);

        // Pass chatId through environment variable for child processes
        const envVars = { ...process.env };
        if (task.chatId) {
          envVars.ANICODE_PARENT_CHAT_ID = task.chatId;
          logger.info(`[CHATID-TRACK] Setting ANICODE_PARENT_CHAT_ID=${task.chatId} for shell command`);
        }

        child = spawn('bash', ['-c', shellCommand], {
          stdio: ['pipe', 'pipe', 'pipe'],
          shell: false,
          cwd: workingDir,
          env: envVars
        });
      } else {
        // Use the provider manager to handle CLI execution
        try {
          const providerManager = await getProviderManager();

          // Use task-specific provider if specified, otherwise use current handler
          let handler;
          if (task.providerId) {
            handler = providerManager.getHandler(task.providerId);
            if (!handler) {
              logger.warn(`Provider ${task.providerId} not found, using default provider`);
              handler = providerManager.getCurrentHandler();
            } else {
              logger.info(`[TASK ${task.id}] Using provider: ${task.providerId}`);
            }
          } else {
            handler = providerManager.getCurrentHandler();
          }

          // Use a fallback working directory if not specified
          const workingDir = task.cwd || process.cwd();

          // Process image attachments if present
          let downloadedImages = [];
          if (task.attachments && Array.isArray(task.attachments)) {
            try {
              const { processAttachments } = await import('./services/imageHandler.js');
              downloadedImages = await processAttachments(task.attachments, workingDir, task.id);
              if (downloadedImages.length > 0) {
                logger.info(`[TASK ${task.id}] Processed ${downloadedImages.length} image attachment(s)`);
              }
            } catch (imgErr) {
              logger.error(`[TASK ${task.id}] Failed to process image attachments: ${imgErr.message}`);
              // Continue without images - don't fail the task
            }

            // Fallback: if downloads failed but we have URLs, pass them through
            // so buildPromptWithImageUrls can still inject the URLs into the prompt
            if (downloadedImages.length === 0) {
              const urlFallbacks = task.attachments
                .filter(a => a.url)
                .map(a => ({ originalUrl: a.url }));
              if (urlFallbacks.length > 0) {
                logger.info(`[TASK ${task.id}] Using ${urlFallbacks.length} attachment URL(s) as fallback (download failed or skipped)`);
                downloadedImages = urlFallbacks;
              }
            }
          }

          // Check if provider has high privilege mode enabled
          const capabilities = handler.getCapabilities();
          const useGreenlight = task.greenlight || capabilities.highPrivilege;

          // Determine task type and execute accordingly
          const taskOptions = {
            workingDir,
            modelPreference,
            interactive: false, // Daemon mode is always non-interactive
            logStream: null, // Will be set later after logStream is created
            taskQueue: this, // Pass taskQueue reference for context-based continue
            taskId: task.id, // Pass task ID for file-based prompt handling
            images: downloadedImages // Pass downloaded images to CLI handlers
          };

          // Check if this is a continue command (starts with -c)
          if (task.command.startsWith('-c')) {
            // Extract the prompt and flags after -c
            const commandAfterC = task.command.substring(2).trim();

            // Check for --dangerously-skip-permissions flag
            const skipPermissions = commandAfterC.includes('--dangerously-skip-permissions');

            // Extract the prompt (everything after the flag if present)
            let prompt;
            if (skipPermissions) {
              prompt = commandAfterC.replace('--dangerously-skip-permissions', '').trim() || 'continue';
            } else {
              prompt = commandAfterC || 'continue';
            }

            taskOptions.prompt = prompt;
            taskOptions.skipPermissions = skipPermissions;
            child = await handler.continueTask(taskOptions);
          } else if (useGreenlight) {
            // Use greenlight mode if specified or if provider has high privilege
            taskOptions.command = task.command;
            child = await handler.greenlightTask(taskOptions);
          } else {
            // Regular command
            taskOptions.command = task.command;
            child = await handler.createTask(taskOptions);
          }
        } catch (err) {
          logger.error(`Failed to execute task with provider: ${err.message}`);
          this.taskOutputBuffers.delete(task.id);
          this.streamLineBuffers.delete(task.id);
          resolve({
            exitCode: 1,
            output: '',
            error: err.message
          });
          return;
        }
      }

      // Add spawn event debugging
      child.on('spawn', () => {
        logger.debug(`[TASK ${task.id}] Process spawned successfully (PID: ${child.pid})`);

        // Store the PID in the task object
        task.pid = child.pid;

        // Emit taskUpdated event with PID info
        this.emit('taskUpdated', task);

        try {
          if (logStream) {
            logStream.write(`[DEBUG] Process spawned successfully (PID: ${child.pid})\n`);
          }
        } catch (err) {
          // Ignore file write errors
        }

        // Close stdin - both shell and claude commands don't need input in daemon mode
        child.stdin.end();
      });

      // Store the child process for potential cancellation
      this.childProcesses.set(task.id, child);
      
      // Initialize last output time for stuck detection (only for shell commands)
      let stuckCheckInterval = null;
      let staleCheckInterval = null;

      if (task.command.startsWith('shell:')) {
        this.lastOutputTime.set(task.id, Date.now());

        // Set up stuck detection timer only for shell commands
        stuckCheckInterval = setInterval(() => {
          const lastOutput = this.lastOutputTime.get(task.id);
          if (lastOutput && Date.now() - lastOutput > config.tasks.stuckDetectionMs) {
            logger.warn(`[TASK ${task.id}] Shell task appears stuck, killing process...`);
            clearInterval(stuckCheckInterval);
            this.lastOutputTime.delete(task.id);

            // Log stuck detection to stream if available
            if (logStream) {
              logStream.write(`\n${'='.repeat(50)}\nTask killed - stuck detection (no output for ${config.tasks.stuckDetectionMs}ms)\nKilled: ${new Date().toISOString()}\n`);
              logStream.end();
            }

            if (this.childProcesses.has(task.id)) {
              child.kill('SIGKILL'); // Force kill stuck process
            }
          }
        }, Math.min(config.tasks.stuckDetectionMs / 4, 15000)); // Check every quarter of timeout period, but at least every 15s
      } else if (config.tasks.staleDetection?.enabled) {
        // Set up stale detection timer for Claude tasks (non-shell commands)
        const staleConfig = config.tasks.staleDetection;
        staleCheckInterval = setInterval(() => {
          const staleCheck = this.checkStaleTask(task);
          if (staleCheck.shouldKill) {
            logger.warn(`[TASK ${task.id}] ${staleCheck.reason}`);
            clearInterval(staleCheckInterval);
            this.staleDetectionState.delete(task.id);

            // Log stale detection to stream if available
            if (logStream) {
              logStream.write(`\n${'='.repeat(50)}\nTask killed - stale detection\nReason: ${staleCheck.reason}\nKilled: ${new Date().toISOString()}\n`);
              logStream.end();
            }

            // Mark task as failed with stale reason
            task.error = `Task terminated: ${staleCheck.reason}`;

            if (this.childProcesses.has(task.id)) {
              child.kill('SIGTERM'); // Use SIGTERM first for graceful shutdown

              // Force kill after 5 seconds if still running
              setTimeout(() => {
                if (this.childProcesses.has(task.id)) {
                  logger.warn(`[TASK ${task.id}] Force killing stale task after SIGTERM timeout`);
                  child.kill('SIGKILL');
                }
              }, 5000);
            }
          }
        }, staleConfig.checkIntervalMs);
      }
      
      // Create log file for this task in .ani-code/logs/YYYY-MM directory
      const aniCodeDir = join(task.cwd, '.ani-code');
      const now = new Date();
      const yearMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
      const logsDir = join(aniCodeDir, 'logs', yearMonth);
      const logFile = join(logsDir, `${task.id}.log`);

      // Ensure .ani-code/logs directory exists
      if (!existsSync(logsDir)) {
        try {
          mkdirSync(logsDir, { recursive: true });
        } catch (err) {
          logger.warn(`Failed to create logs directory ${logsDir}: ${err.message}`);
        }
      }

      // Initialize .gitignore in .ani-code if it doesn't exist
      this.initAniCodeGitignore(aniCodeDir, existsSync, writeFileSync, join);
      
      // Create file stream for logging (non-blocking)
      let logStream = null;
      try {
        logStream = createWriteStream(logFile, { flags: 'w' });
        this.logStreams.set(task.id, logStream);
        
        // Write initial task info
        logStream.write(`Task: ${task.name}\nCommand: ${task.command}\nStarted: ${task.startedAt}\n${'='.repeat(50)}\n`);
        logger.info(`[TASK ${task.id}] Log file: ${logFile}`);
      } catch (err) {
        logger.warn(`Failed to create log stream ${logFile}: ${err.message}`);
      }

      child.stdout.on('data', (data) => {
        const dataStr = data.toString();
        this.logTaskStreamChunk(task, 'stdout', dataStr);

        // Update last output time for stuck detection (only for shell commands)
        if (task.command.startsWith('shell:')) {
          this.lastOutputTime.set(task.id, Date.now());
        } else {
          // Track output for stale detection (Claude tasks)
          // Split by lines and track each line separately
          const lines = dataStr.split('\n');
          for (const line of lines) {
            this.trackOutputForStaleDetection(task.id, line);
          }

          // Cancel fatal error timeout if we get meaningful stdout
          // This means Claude recovered and is producing output
          this.cancelFatalErrorTimeout(task.id, dataStr, logStream);
        }

        // Add to memory buffer
        const buffers = this.taskOutputBuffers.get(task.id);
        if (buffers) {
          buffers.stdout.append(data);
        }

        // Log to file stream (non-blocking)
        if (logStream) {
          logStream.write(`[STDOUT] ${dataStr}`);
        }

        // Emit real-time output
        this.emit('taskOutput', { taskId: task.id, data: dataStr, type: 'stdout' });
      });

      child.stderr.on('data', (data) => {
        const dataStr = data.toString();
        this.logTaskStreamChunk(task, 'stderr', dataStr);

        // Update last output time for stuck detection (only for shell commands)
        if (task.command.startsWith('shell:')) {
          this.lastOutputTime.set(task.id, Date.now());
        } else {
          // Track stderr for stale detection too (Claude tasks)
          const lines = dataStr.split('\n');
          for (const line of lines) {
            this.trackOutputForStaleDetection(task.id, line);
          }
        }

        // Check for fatal errors and start kill timer (for non-shell commands)
        if (!task.command.startsWith('shell:')) {
          this.checkFatalErrorAndScheduleKill(task.id, dataStr, child, logStream);
        }

        // Add to memory buffer
        const buffers = this.taskOutputBuffers.get(task.id);
        if (buffers) {
          buffers.stderr.append(data);
        }

        // Log to file stream (non-blocking)
        if (logStream) {
          logStream.write(`[STDERR] ${dataStr}`);
        }

        // Emit real-time error output
        this.emit('taskOutput', { taskId: task.id, data: dataStr, type: 'stderr' });
      });

      // Handler for both 'close' and 'exit' events to ensure task cleanup
      let taskResolved = false;
      let mainTimeoutId = null;

      const handleTaskCompletion = (code, eventType) => {
        if (taskResolved) return; // Prevent duplicate handling
        taskResolved = true;

        this.childProcesses.delete(task.id);
        this.lastOutputTime.delete(task.id);
        this.staleDetectionState.delete(task.id);
        // Clear fatal error timeout if set
        const fatalTimeout = this.fatalErrorTimeouts.get(task.id);
        if (fatalTimeout) {
          clearTimeout(fatalTimeout);
          this.fatalErrorTimeouts.delete(task.id);
        }
        if (mainTimeoutId) {
          clearTimeout(mainTimeoutId);
        }
        if (stuckCheckInterval) {
          clearInterval(stuckCheckInterval);
        }
        if (staleCheckInterval) {
          clearInterval(staleCheckInterval);
        }

        // Schedule post-completion cleanup to force-kill any lingering process
        // This handles cases where the process doesn't properly exit after task completion
        if (child && child.pid) {
          this.schedulePostCompletionCleanup(task.id, child.pid, 60000); // 60 seconds
        }

        this.flushTaskStreamBuffers(task);

        // Get final output from buffers
        const buffers = this.taskOutputBuffers.get(task.id);
        let finalOutput = '';
        let finalError = '';

        if (buffers) {
          finalOutput = buffers.stdout.getLines().join('\n');
          finalError = buffers.stderr.getLines().join('\n');
        }

        // Log completion to file stream
        if (logStream && !logStream.destroyed) {
          logStream.write(`\n${'='.repeat(50)}\nTask completed with exit code: ${code} (via ${eventType})\nFinished: ${new Date().toISOString()}\n`);
          logStream.end(); // Close stream
        }

        // Cleanup resources
        this.taskOutputBuffers.delete(task.id);
        this.logStreams.delete(task.id);

        // For extraction purposes, combine both stdout and stderr since different providers
        // output tokens/stats to different streams (Codex: stderr, Gemini: stdout)
        const fullOutput = [finalOutput, finalError].filter(Boolean).join('\n');
        // For the final resolved output, prefer stdout but fall back to stderr
        let combinedOutput = finalOutput || finalError || '';

        // Extract tokens and model from provider output (codex, gemini) before extracting conclusion
        // Only for non-shell commands
        if (!task.command.startsWith('shell:') && task.providerId) {
          // Try to extract detailed stats first (for Gemini with usageV2 breakdown)
          // Use fullOutput (stdout + stderr) since different providers output stats to different streams
          const extractedStats = extractProviderStats(fullOutput, task.providerId);
          if (extractedStats && extractedStats.usageV2) {
            // Store detailed stats for direct usageV2 insertion
            task.parsedStats = extractedStats;
            task.parsedTokens = extractedStats.totals.totalTokens;
            // Get model from first usageV2 entry
            if (extractedStats.usageV2.length > 0) {
              task.parsedModel = extractedStats.usageV2[0].modelId;
            }
            const modelsUsed = extractedStats.usageV2.map(u => u.modelId).join(', ');
            logger.info(`[STATS_EXTRACT] Extracted detailed stats from ${task.providerId}: ${extractedStats.totals.totalTokens.toLocaleString()} tokens, models: ${modelsUsed}`);
          } else {
            // Fallback: try simple token extraction
            const extractedTokens = extractProviderTokens(fullOutput, task.providerId);
            if (extractedTokens !== null) {
              // Store tokens in task for later use in taskUsage
              task.parsedTokens = extractedTokens;
              logger.info(`[TOKEN_EXTRACT] Extracted ${extractedTokens.toLocaleString()} tokens from ${task.providerId} output for task ${task.id}`);
            }

            // Extract model name from provider output (codex, gemini)
            const extractedModel = extractProviderModel(fullOutput, task.providerId);
            if (extractedModel) {
              task.parsedModel = extractedModel;
              logger.info(`[MODEL_EXTRACT] Extracted model "${extractedModel}" from ${task.providerId} output for task ${task.id}`);
            }
          }

          // Extract conclusion from verbose provider outputs
          combinedOutput = extractProviderConclusion(combinedOutput, task.providerId);
        }

        resolve({
          exitCode: code,
          output: combinedOutput,
          error: code !== 0 ? finalError : null
        });
      };

      child.on('close', (code) => handleTaskCompletion(code, 'close'));
      child.on('exit', (code) => handleTaskCompletion(code, 'exit'));

      child.on('error', (err) => {
        if (taskResolved) return; // Prevent duplicate handling
        taskResolved = true;

        this.childProcesses.delete(task.id);
        this.lastOutputTime.delete(task.id);
        if (stuckCheckInterval) {
          clearInterval(stuckCheckInterval);
        }
        this.flushTaskStreamBuffers(task);
        logger.error(`Task spawn error: ${err.message}`);

        // Get output from buffers if available
        const buffers = this.taskOutputBuffers.get(task.id);
        let finalOutput = '';
        if (buffers) {
          finalOutput = buffers.stdout.getLines().join('\n');
        }

        // Log error to file stream
        if (logStream && !logStream.destroyed) {
          logStream.write(`\n${'='.repeat(50)}\nTask spawn error: ${err.message}\nFinished: ${new Date().toISOString()}\n`);
          logStream.end(); // Close stream
        }

        // Cleanup resources
        this.taskOutputBuffers.delete(task.id);
        this.logStreams.delete(task.id);

        resolve({
          exitCode: 1,
          output: finalOutput,
          error: err.message
        });
      });

      if (task.timeout) {
        mainTimeoutId = setTimeout(() => {
          if (!this.childProcesses.has(task.id)) return;

          const runMinutes = Math.round(task.timeout / 60000);
          logger.warn(`[TASK ${task.id}] Task timed out after ${runMinutes} minutes, killing process...`);

          // Log timeout to stream if available
          if (logStream && !logStream.destroyed) {
            logStream.write(`\n${'='.repeat(50)}\nTask killed - timeout after ${runMinutes} minutes\nKilled: ${new Date().toISOString()}\n`);
          }

          // Mark task error for reporting
          task.error = `Task timed out after ${runMinutes} minutes`;

          child.kill('SIGTERM');

          // Force kill after 10 seconds if SIGTERM is ignored
          setTimeout(() => {
            if (this.childProcesses.has(task.id)) {
              logger.warn(`[TASK ${task.id}] Force killing timed-out task after SIGTERM was ignored`);
              child.kill('SIGKILL');
            }
          }, 10000);
        }, task.timeout);
      }
    });
  }

  logTaskStreamChunk(task, streamType, chunk) {
    if (!chunk) {
      return;
    }

    const buffers = this.streamLineBuffers.get(task.id);
    if (!buffers) {
      return;
    }

    const key = streamType === 'stderr' ? 'stderr' : 'stdout';
    const combined = `${buffers[key]}${chunk}`;
    const lines = combined.split(/\r?\n/);
    buffers[key] = lines.pop() ?? '';

    const isStderr = streamType === 'stderr';
    const logFn = isStderr ? (message) => logger.warn(message) : (message) => logger.info(message);
    const prefix = isStderr ? 'stderr>' : 'stdout>';

    for (const line of lines) {
      const cleaned = line.replace(/\r/g, '');
      if (cleaned.length === 0) {
        continue;
      }
      logFn(`[TASK ${task.id}] ${prefix} ${cleaned}`);
    }
  }

  flushTaskStreamBuffers(task) {
    const buffers = this.streamLineBuffers.get(task.id);
    if (!buffers) {
      return;
    }

    if (buffers.stdout && buffers.stdout.trim().length > 0) {
      // logger.info(`[TASK ${task.id}] stdout> ${buffers.stdout.replace(/\r/g, '')}`);
    }

    if (buffers.stderr && buffers.stderr.trim().length > 0) {
      logger.warn(`[TASK ${task.id}] stderr> ${buffers.stderr.replace(/\r/g, '')}`);
    }

    this.streamLineBuffers.delete(task.id);
  }

  findTaskByPartialId(partialId) {
    // Search in running tasks
    for (const [fullId, task] of this.runningTasks) {
      if (fullId.endsWith(partialId)) {
        return { task, fullId, status: 'running' };
      }
    }
    
    // Search in pending tasks
    for (const task of this.pendingTasks) {
      if (task.id.endsWith(partialId)) {
        return { task, fullId: task.id, status: 'pending' };
      }
    }
    
    // Search in history
    for (const task of this.taskHistory) {
      if (task.id.endsWith(partialId)) {
        return { task, fullId: task.id, status: 'history' };
      }
    }
    
    return null;
  }

  cancelTask(taskId) {
    // First try exact match, then try partial match
    let runningTask = this.runningTasks.get(taskId);
    let actualTaskId = taskId;
    
    // If exact match not found, try to find by partial ID
    if (!runningTask) {
      const result = this.findTaskByPartialId(taskId);
      if (result && result.status === 'running') {
        runningTask = result.task;
        actualTaskId = result.fullId;
      }
    }
    
    if (runningTask) {
      const child = this.childProcesses.get(actualTaskId);
      if (child) {
        child.kill('SIGTERM');
        // For running tasks, mark as 'failed' instead of 'cancelled'
        runningTask.status = 'failed';
        runningTask.error = 'Task cancelled by user';
        runningTask.exitCode = 143; // SIGTERM exit code
        runningTask.completedAt = new Date();

        // Record task cancellation in stats database
        try {
          const statsDB = getStatsDB();
          statsDB.recordTaskCancellation(actualTaskId, 'Task cancelled by user');
        } catch (error) {
          logger.error(`Failed to record task cancellation stats: ${error.message}`);
        }

        this.runningTasks.delete(actualTaskId);
        this.childProcesses.delete(actualTaskId);
        this.lastOutputTime.delete(actualTaskId);
        this.staleDetectionState.delete(actualTaskId);
        // Clear fatal error timeout if set
        const fatalTimeout = this.fatalErrorTimeouts.get(actualTaskId);
        if (fatalTimeout) {
          clearTimeout(fatalTimeout);
          this.fatalErrorTimeouts.delete(actualTaskId);
        }

        // Update running tasks count per project
        const projectPath = runningTask.cwd;
        const currentRunning = this.runningTasksByProject.get(projectPath) || 0;
        if (currentRunning > 0) {
          this.runningTasksByProject.set(projectPath, currentRunning - 1);
          if (currentRunning === 1) {
            this.runningTasksByProject.delete(projectPath);
          }
        }
        
        // Clean up resources
        this.taskOutputBuffers.delete(actualTaskId);
        const logStream = this.logStreams.get(actualTaskId);
        if (logStream) {
          logStream.end();
          this.logStreams.delete(actualTaskId);
        }
        this.streamLineBuffers.delete(actualTaskId);
        
        // Add to history
        this.addToHistory(runningTask);
        
        // Emit as completed with failed status (not cancelled)
        this.emit('taskCompleted', runningTask);
        this.processQueue();

        // Calculate usage asynchronously for cancelled running tasks
        // The task already has a "before" snapshot from when it started, so we can still get cost data
        if (!runningTask.command.startsWith('shell:') && this.shouldTrackUsage(runningTask)) {
          this.calculateUsageAsync(runningTask).catch(error => {
            logger.error(`[ASYNC_USAGE] Failed to calculate usage for cancelled task ${actualTaskId}: ${error.message}`);
          });
        } else {
          this.recordTaskStats(runningTask);
        }

        return { success: true, message: 'Task cancelled successfully' };
      }
    }
    
    // Check if it's a pending (queued) task
    let pendingIndex = this.pendingTasks.findIndex(task => task.id === taskId);
    
    // If exact match not found, try to find by partial ID
    if (pendingIndex === -1) {
      const result = this.findTaskByPartialId(taskId);
      if (result && result.status === 'pending') {
        pendingIndex = this.pendingTasks.findIndex(task => task.id === result.fullId);
      }
    }
    
    if (pendingIndex !== -1) {
      const task = this.pendingTasks[pendingIndex];
      
      // Remove from pending queue
      this.pendingTasks.splice(pendingIndex, 1);
      
      // Mark as cancelled
      task.status = 'cancelled';
      task.error = 'Task cancelled while queued';
      task.completedAt = new Date();

      // Record task cancellation in stats database
      try {
        const statsDB = getStatsDB();
        statsDB.recordTaskCancellation(task.id, 'Task cancelled while queued');
      } catch (error) {
        logger.error(`Failed to record pending task cancellation stats: ${error.message}`);
      }

      // Add to history
      this.addToHistory(task);
      
      // Emit cancellation event
      this.emit('taskCancelled', task);
      
      return { success: true, message: 'Queued task cancelled successfully' };
    }
    
    // Check history (for recently completed tasks)
    let historyTask = this.taskHistory.find(task => task.id === taskId);
    
    // If exact match not found, try to find by partial ID
    if (!historyTask) {
      const result = this.findTaskByPartialId(taskId);
      if (result && result.status === 'history') {
        historyTask = result.task;
      }
    }
    
    if (historyTask) {
      return { success: false, message: `Task ${taskId} has already completed with status: ${historyTask.status}` };
    }

    return { success: false, message: 'Task not found' };
  }

  getTaskStatus(taskId) {
    // Check running tasks
    const runningTask = this.runningTasks.get(taskId);
    if (runningTask) return runningTask;
    
    // Check pending tasks
    const pendingTask = this.pendingTasks.find(task => task.id === taskId);
    if (pendingTask) return pendingTask;
    
    // Check history
    return this.taskHistory.find(task => task.id === taskId);
  }

  getAllTasks() {
    return {
      running: Array.from(this.runningTasks.values()),
      pending: this.pendingTasks,
      runningByProject: this.getRunningTasksByProject()
    };
  }

  getRunningTasksByProject() {
    const result = new Map();
    for (const task of this.runningTasks.values()) {
      const projectPath = task.cwd;
      if (!result.has(projectPath)) {
        result.set(projectPath, []);
      }
      result.get(projectPath).push(task);
    }
    return result;
  }

  isTaskRunning(taskId) {
    return this.runningTasks.has(taskId);
  }

  /**
   * Update task's response channel (chatId and source)
   * This allows switching where task notifications are sent
   * @param {string} taskId - Task ID or partial ID
   * @param {string} chatId - New chat ID (e.g., 'telegram:123456')
   * @param {string} source - New source (e.g., 'telegram', 'lark', 'gateway')
   * @returns {Object|null} Updated task or null if not found
   */
  updateTaskChannel(taskId, chatId, source = null) {
    // Find task (running or pending)
    let task = null;
    let actualTaskId = taskId;

    // Check running tasks (support partial ID matching)
    for (const [fullId, t] of this.runningTasks) {
      if (fullId === taskId || fullId.endsWith(taskId)) {
        task = t;
        actualTaskId = fullId;
        break;
      }
    }

    // Check pending tasks if not found in running
    if (!task) {
      const pendingIdx = this.pendingTasks.findIndex(t =>
        t.id === taskId || t.id.endsWith(taskId)
      );
      if (pendingIdx !== -1) {
        task = this.pendingTasks[pendingIdx];
        actualTaskId = task.id;
      }
    }

    if (!task) {
      logger.warn(`[TASK-QUEUE] Cannot update channel: task ${taskId} not found`);
      return null;
    }

    const oldChatId = task.chatId;
    const oldSource = task.metadata?.source || task.source;

    // Update chatId
    task.chatId = chatId;

    // Update source in both task and metadata
    if (source) {
      task.source = source;
      if (!task.metadata) {
        task.metadata = {};
      }
      // Clear gateway source so notifications go directly to the new channel
      if (source !== 'gateway') {
        delete task.metadata.source;
      } else {
        task.metadata.source = 'gateway';
      }
    } else if (chatId && !String(chatId).includes('gateway')) {
      // If chatId indicates a direct channel, clear gateway routing
      if (task.metadata?.source === 'gateway') {
        delete task.metadata.source;
      }
    }

    logger.info(`[TASK-QUEUE] Updated channel for task ${actualTaskId}: chatId ${oldChatId} -> ${chatId}, source ${oldSource} -> ${source || task.source || 'unchanged'}`);

    return task;
  }

  getTaskOutput(taskId, type = 'all', lines = null) {
    const buffers = this.taskOutputBuffers.get(taskId);
    if (!buffers) {
      return null;
    }

    switch (type) {
      case 'stdout':
        return buffers.stdout.getLines(lines);
      case 'stderr':
        return buffers.stderr.getLines(lines);
      case 'all':
      default:
        const stdout = buffers.stdout.getLines(lines);
        const stderr = buffers.stderr.getLines(lines);
        return { stdout, stderr };
    }
  }

  getTaskOutputMetrics(taskId) {
    const buffers = this.taskOutputBuffers.get(taskId);
    if (!buffers) {
      return null;
    }

    return {
      stdout: {
        lines: buffers.stdout.lines.length,
        bytes: buffers.stdout.getTotalBytes()
      },
      stderr: {
        lines: buffers.stderr.lines.length,
        bytes: buffers.stderr.getTotalBytes()
      }
    };
  }

  getTaskUsage(taskId) {
    return this.usageReporter.getTaskUsage(taskId);
  }

  getAllTaskUsage() {
    return this.usageReporter.getAllTaskUsage();
  }

  cleanupOldSnapshots(olderThanHours = 24) {
    this.usageReporter.cleanupTaskSnapshots(olderThanHours);
  }

  /**
   * Calculate usage asynchronously after task completion
   * This runs in background so completion notification is not delayed
   */
  async calculateUsageAsync(task) {
    try {
      logger.info(`[ASYNC_USAGE] Starting background usage calculation for task ${task.id} (provider: ${task.providerId || 'claude'})`);

      // Create completion snapshot and calculate usage difference
      const usageDiff = await this.usageReporter.createTaskCompletionSnapshot(task.id, task.name, task);
      if (usageDiff) {
        task.usage = usageDiff;

        // Update history entry with usage data
        const historyTask = this.taskHistory.find(t => t.id === task.id);
        if (historyTask) {
          historyTask.usage = usageDiff;
        }

        // Log detailed usage info for debugging
        const costStr = usageDiff.cost?.toFixed(4) || '0';
        const tokensStr = usageDiff.tokens?.toLocaleString() || '0';
        const inputStr = usageDiff.inputTokens?.toLocaleString() || '0';
        const outputStr = usageDiff.outputTokens?.toLocaleString() || '0';
        logger.info(`[ASYNC_USAGE] Usage calculated for task ${task.id}: $${costStr}, tokens=${tokensStr} (in=${inputStr}, out=${outputStr})`);

        // Log if cost is 0 but tokens exist (potential issue)
        if ((!usageDiff.cost || usageDiff.cost === 0) && usageDiff.tokens > 0) {
          logger.warn(`[ASYNC_USAGE] ⚠️ Task ${task.id} has tokens but no cost - check if ccusage captured the usage correctly`);
        }
      } else {
        logger.warn(`[ASYNC_USAGE] No usage diff returned for task ${task.id} - snapshot might have failed`);
      }

      // Record stats after usage is calculated
      this.recordTaskStats(task);

      // Emit event so listeners can update with usage data
      this.emit('taskUsageReady', task);

    } catch (error) {
      logger.error(`[ASYNC_USAGE] Error calculating usage for task ${task.id}: ${error.message}`);
      // Still record stats even if usage calculation failed
      this.recordTaskStats(task);
    }
  }

  /**
   * Record task completion stats to database
   */
  recordTaskStats(task) {
    try {
      const statsDB = getStatsDB();
      const outputPreview = task.output ? task.output.substring(0, 500) : null;
      // Use extracted model from provider output if available, otherwise use task.model or provider ID
      const model = task.parsedModel || task.model || task.providerId || 'unknown';
      const cost = task.usage?.cost || 0;
      const tokens = {
        input: task.usage?.inputTokens || 0,
        output: task.usage?.outputTokens || 0,
        total: task.usage?.tokens || 0
      };

      const providerId = task.providerId || 'claude'; // Default to claude if not specified
      logger.info(`[STATS_RECORD] Recording task ${task.id} completion - cost: $${cost}, tokens: ${tokens.total}, provider: ${providerId}, usage object: ${task.usage ? 'present' : 'missing'}`);
      if (task.usage) {
        logger.debug(`[STATS_RECORD] Task ${task.id} usage details: ${JSON.stringify(task.usage)}`);
      }

      if (task.status === 'completed') {
        statsDB.recordTaskCompletion(task.id, outputPreview, model, cost, tokens, providerId);

        // Record detailed per-model usage (usage v2)
        if (task.usage?.usageV2 && task.usage.usageV2.length > 0) {
          statsDB.recordTaskUsageV2(task.id, task.usage.usageV2, providerId);
          logger.debug(`[STATS_RECORD] Recorded ${task.usage.usageV2.length} model usage(s) for task ${task.id} (provider: ${providerId})`);
        } else if (task.usage?.modelBreakdowns && task.usage.modelBreakdowns.length > 0) {
          // Fallback: convert modelBreakdowns to v2 format
          const usageV2 = task.usage.modelBreakdowns.map(breakdown => ({
            modelId: breakdown.modelName,
            inputTokens: breakdown.inputTokens || 0,
            inputCachedTokens: breakdown.cacheReadTokens || 0,
            outputTokens: breakdown.outputTokens || 0,
            costUsd: breakdown.cost || 0
          }));
          statsDB.recordTaskUsageV2(task.id, usageV2, providerId);
          logger.debug(`[STATS_RECORD] Recorded ${usageV2.length} model usage(s) from modelBreakdowns for task ${task.id} (provider: ${providerId})`);
        }
      } else if (task.status === 'failed') {
        statsDB.recordTaskError(task.id, task.error);
      }
    } catch (error) {
      logger.error(`Failed to record task completion stats: ${error.message}`);
    }
  }

  addToHistory(task) {
    // Add task to history (most recent first)
    this.taskHistory.unshift({
      id: task.id,
      name: task.name,
      command: task.command,
      status: task.status,
      createdAt: task.createdAt,
      startedAt: task.startedAt,
      completedAt: task.completedAt,
      duration: task.completedAt - task.startedAt,
      error: task.error,
      exitCode: task.exitCode,
      cwd: task.cwd,
      usage: task.usage,
      output: task.output,
      providerId: task.providerId,  // Track which provider executed this task
      sessionFile: task.sessionFile  // Store session file path for history lookup
    });
    
    // Keep only the last N tasks
    if (this.taskHistory.length > this.maxHistorySize) {
      this.taskHistory = this.taskHistory.slice(0, this.maxHistorySize);
    }
  }

  getTaskHistory(limit = null) {
    if (limit === null) {
      return this.taskHistory;
    }
    return this.taskHistory.slice(0, limit);
  }

  getHistoryById(taskId) {
    return this.taskHistory.find(task => task.id === taskId);
  }

  getLastTaskForWorkspace(workdir) {
    // Find the most recent completed task for this workspace
    // Skip shell commands and continue commands
    return this.taskHistory.find(task =>
      task.cwd === workdir &&
      task.status === 'completed' &&
      !task.command.startsWith('shell:') &&
      !task.command.startsWith('-c')
    );
  }

  getConversationHistory(workdir, maxTasks = 5) {
    // Build conversation history by finding the chain of tasks
    // Includes both regular tasks and continue tasks in chronological order
    const conversationTasks = [];

    // Get all completed tasks for this workspace (most recent first)
    const allTasks = this.taskHistory.filter(task =>
      task.cwd === workdir &&
      task.status === 'completed' &&
      !task.command.startsWith('shell:')
    );

    // Take the most recent tasks (up to maxTasks)
    for (let i = 0; i < Math.min(maxTasks, allTasks.length); i++) {
      const task = allTasks[i];

      // For continue tasks, extract the actual prompt
      let prompt = task.command;
      if (task.command.startsWith('-c')) {
        prompt = task.command.substring(2).trim() || 'continue';
      }

      conversationTasks.push({
        prompt: prompt,
        response: task.output ? task.output.substring(0, 1500) : '(no output)',
        timestamp: task.completedAt,
        providerId: task.providerId  // Include provider info
      });
    }

    // Reverse to get chronological order (oldest to newest)
    return conversationTasks.reverse();
  }
  
  async getProcessInfo(pid) {
    try {
      const { execSync } = await import('child_process');
      
      // Check if process exists and get its info using ps command
      // Format: USER PID %CPU %MEM VSZ RSS TTY STAT START TIME COMMAND
      const psOutput = execSync(`ps aux | grep "^[^ ]*[ ]*${pid} " || true`, { encoding: 'utf-8' });
      
      if (!psOutput || psOutput.trim() === '') {
        return null;
      }
      
      const lines = psOutput.trim().split('\n');
      const processLine = lines[0];
      
      if (!processLine) {
        return null;
      }
      
      // Parse ps output
      const parts = processLine.split(/\s+/);
      if (parts.length < 11) {
        return null;
      }
      
      return {
        user: parts[0],
        pid: parseInt(parts[1]),
        cpu: parseFloat(parts[2]),
        memory: parseFloat(parts[3]),
        vsz: parseInt(parts[4]),
        rss: parseInt(parts[5]),
        tty: parts[6],
        stat: parts[7],
        start: parts[8],
        time: parts[9],
        command: parts.slice(10).join(' ')
      };
    } catch (error) {
      logger.error(`Failed to get process info for PID ${pid}: ${error.message}`);
      return null;
    }
  }
  
  async getTaskWithProcessInfo(taskId) {
    const task = this.runningTasks.get(taskId);
    if (!task) {
      return null;
    }

    // Get process info if PID is available
    if (task.pid) {
      task.processInfo = await this.getProcessInfo(task.pid);
    }

    return task;
  }

  /**
   * Normalize output line for comparison (remove timestamps, line numbers, etc.)
   * @param {string} output - Output line to normalize
   * @returns {string} Normalized output for comparison
   */
  normalizeOutputForComparison(output) {
    return output
      // Remove ANSI color codes
      .replace(/\x1b\[[0-9;]*m/g, '')
      // Remove timestamps like [2026-01-11T15:00:00.000Z] or 15:00:00
      .replace(/\[\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}.\d{3}Z\]/g, '')
      .replace(/\d{2}:\d{2}:\d{2}/g, '')
      // Remove line numbers like :123 or line 123
      .replace(/:\d+/g, ':N')
      .replace(/line \d+/gi, 'line N')
      // Normalize whitespace
      .trim();
  }

  /**
   * Check if output is meaningful for stale detection (not just progress indicators)
   * @param {string} output - Output line to check
   * @returns {boolean} True if line should be tracked
   */
  isTrackableOutput(output) {
    const trimmed = output.trim();

    // Skip empty lines
    if (!trimmed || trimmed.length < 5) {
      return false;
    }

    // Skip common progress indicators that repeat normally
    const skipPatterns = [
      /^[.\s]+$/,           // Just dots or spaces (progress dots)
      /^\d+%$/,             // Just percentage
      /^[-=]+$/,            // Horizontal lines
      /^[│├└─┌┐]+$/,        // Box drawing characters
      /^Streaming\.\.\./,   // Streaming indicator
      /^Thinking\.\.\./,    // Thinking indicator
    ];

    for (const pattern of skipPatterns) {
      if (pattern.test(trimmed)) {
        return false;
      }
    }

    return true;
  }

  /**
   * Track output for stale detection - detects ANY repeated output patterns
   * This catches stuck tasks that repeat the same message regardless of error type
   * @param {string} taskId - Task ID
   * @param {string} output - Output line to track
   * @returns {{ isStale: boolean, reason?: string }} Stale detection result
   */
  trackOutputForStaleDetection(taskId, output) {
    const staleConfig = config.tasks.staleDetection;
    if (!staleConfig?.enabled) {
      return { isStale: false };
    }

    let state = this.staleDetectionState.get(taskId);
    if (!state) {
      state = {
        recentMessages: [],
        maxMessages: staleConfig.repeatThreshold + 10,
        consecutiveCount: 0,
        lastNormalizedMsg: null,
        messageFirstSeen: null, // Timestamp when current repeated message first appeared
      };
      this.staleDetectionState.set(taskId, state);
    }

    // Only track meaningful output lines
    const trimmedOutput = output.trim();
    if (!this.isTrackableOutput(trimmedOutput)) {
      return { isStale: false };
    }

    // Normalize for comparison
    const normalizedMsg = this.normalizeOutputForComparison(trimmedOutput);

    // Track consecutive repetitions of the same message
    if (state.lastNormalizedMsg && this.areMessagesSimilar(normalizedMsg, state.lastNormalizedMsg)) {
      state.consecutiveCount++;
    } else {
      // Different message, reset counter and timestamp
      state.consecutiveCount = 1;
      state.lastNormalizedMsg = normalizedMsg;
      state.messageFirstSeen = Date.now();
    }

    // Store original message for logging
    state.recentMessages.push(trimmedOutput);
    while (state.recentMessages.length > state.maxMessages) {
      state.recentMessages.shift();
    }

    // Check for consecutive repetitions
    if (state.consecutiveCount >= staleConfig.repeatThreshold) {
      return {
        isStale: true,
        reason: `Same output repeated ${state.consecutiveCount}+ times consecutively: "${trimmedOutput.substring(0, 100)}..."`,
      };
    }

    return { isStale: false };
  }

  /**
   * Check if two normalized messages are similar (allowing for small variations)
   * @param {string} msg1 - First message
   * @param {string} msg2 - Second message
   * @returns {boolean} True if messages are similar
   */
  areMessagesSimilar(msg1, msg2) {
    if (msg1 === msg2) {
      return true;
    }

    // Check if one contains most of the other (for messages with variable parts)
    const minLen = Math.min(50, Math.min(msg1.length, msg2.length));
    if (minLen > 10) {
      const prefix1 = msg1.substring(0, minLen);
      const prefix2 = msg2.substring(0, minLen);
      if (prefix1 === prefix2) {
        return true;
      }
    }

    return false;
  }

  /**
   * Check if a Claude task should be considered stale
   * @param {object} task - The task object
   * @returns {{ shouldKill: boolean, reason?: string }} Whether to kill the task
   */
  checkStaleTask(task) {
    const staleConfig = config.tasks.staleDetection;
    if (!staleConfig?.enabled) {
      return { shouldKill: false };
    }

    // Skip shell commands (they have their own stuck detection)
    if (task.command.startsWith('shell:')) {
      return { shouldKill: false };
    }

    // Check minimum runtime
    const runTimeMs = Date.now() - new Date(task.startedAt).getTime();
    if (runTimeMs < staleConfig.minRunTimeMs) {
      return { shouldKill: false };
    }

    // Check stale detection state
    const state = this.staleDetectionState.get(task.id);
    if (!state) {
      return { shouldKill: false };
    }

    // Check for consecutive repetitions of the same output
    if (state.consecutiveCount >= staleConfig.repeatThreshold) {
      const lastMsg = state.recentMessages[state.recentMessages.length - 1] || 'unknown';
      return {
        shouldKill: true,
        reason: `Task stale - same output repeated ${state.consecutiveCount}+ times consecutively after ${Math.round(runTimeMs / 60000)} minutes: "${lastMsg.substring(0, 80)}..."`,
      };
    }

    return { shouldKill: false };
  }

  /**
   * Get stale detection info for a task (for progress display)
   * Returns information about whether the last message has been repeated and for how long
   * @param {string} taskId - The task ID
   * @returns {{ isStale: boolean, staleDurationSeconds?: number, consecutiveCount?: number, lastMessage?: string } | null}
   */
  getStaleInfo(taskId) {
    const state = this.staleDetectionState.get(taskId);
    if (!state || !state.messageFirstSeen) {
      return null;
    }

    const staleDurationMs = Date.now() - state.messageFirstSeen;
    const staleDurationSeconds = Math.floor(staleDurationMs / 1000);
    const lastMessage = state.recentMessages.length > 0
      ? state.recentMessages[state.recentMessages.length - 1]
      : null;

    // Consider stale if same message shown for more than 60 seconds
    const isStale = staleDurationSeconds >= 60 && state.consecutiveCount >= 2;

    return {
      isStale,
      staleDurationSeconds,
      consecutiveCount: state.consecutiveCount,
      lastMessage,
    };
  }

  /**
   * Check for fatal errors in stderr and schedule process termination
   * This handles cases where Claude CLI throws unhandled errors but doesn't exit
   * @param {string} taskId - The task ID
   * @param {string} stderrData - The stderr output to check
   * @param {ChildProcess} child - The child process to kill if needed
   * @param {WriteStream} logStream - The log stream for recording
   */
  checkFatalErrorAndScheduleKill(taskId, stderrData, child, logStream) {
    const fatalConfig = config.tasks.fatalErrorTimeout;
    if (!fatalConfig?.enabled) {
      return;
    }

    // Don't set another timer if one is already running
    if (this.fatalErrorTimeouts.has(taskId)) {
      return;
    }

    // Check if stderr contains any fatal error patterns
    const lowerStderr = stderrData.toLowerCase();
    const matchedPattern = fatalConfig.patterns.find(pattern =>
      lowerStderr.includes(pattern.toLowerCase())
    );

    if (!matchedPattern) {
      return;
    }

    const timeoutMs = fatalConfig.timeoutMs;
    const timeoutMinutes = Math.round(timeoutMs / 60000);

    logger.warn(`[FATAL-ERROR] Task ${taskId} detected fatal error pattern: "${matchedPattern}"`);
    logger.warn(`[FATAL-ERROR] Scheduling kill in ${timeoutMinutes} minutes if process doesn't exit`);

    // Log to task's log file
    if (logStream && !logStream.destroyed) {
      logStream.write(`\n[FATAL-ERROR] Detected: "${matchedPattern}" - will kill in ${timeoutMinutes} minutes if stuck\n`);
    }

    // Schedule the kill
    const timeoutId = setTimeout(() => {
      // Check if task is still running
      if (!this.childProcesses.has(taskId)) {
        logger.info(`[FATAL-ERROR] Task ${taskId} already exited, no need to kill`);
        this.fatalErrorTimeouts.delete(taskId);
        return;
      }

      logger.warn(`[FATAL-ERROR] Task ${taskId} still running ${timeoutMinutes} minutes after fatal error, killing...`);

      // Log to task's log file
      if (logStream && !logStream.destroyed) {
        logStream.write(`\n${'='.repeat(50)}\nTask killed - fatal error timeout\nReason: Process did not exit after "${matchedPattern}" error\nKilled: ${new Date().toISOString()}\n`);
      }

      // Store the error reason in the task
      const task = this.runningTasks.get(taskId);
      if (task) {
        task.error = `Task terminated: Fatal error detected ("${matchedPattern}") and process did not exit within ${timeoutMinutes} minutes`;
      }

      // Kill the process
      try {
        child.kill('SIGTERM');

        // Force kill after 5 seconds if still running
        setTimeout(() => {
          if (this.childProcesses.has(taskId)) {
            logger.warn(`[FATAL-ERROR] Task ${taskId} still alive after SIGTERM, sending SIGKILL`);
            child.kill('SIGKILL');
          }
        }, 5000);
      } catch (killError) {
        logger.error(`[FATAL-ERROR] Failed to kill task ${taskId}: ${killError.message}`);
      }

      this.fatalErrorTimeouts.delete(taskId);
    }, timeoutMs);

    this.fatalErrorTimeouts.set(taskId, timeoutId);
  }

  /**
   * Cancel fatal error timeout if meaningful stdout is received
   * This indicates Claude recovered and is working normally
   * @param {string} taskId - The task ID
   * @param {string} stdoutData - The stdout output to check
   * @param {WriteStream} logStream - The log stream for recording
   */
  cancelFatalErrorTimeout(taskId, stdoutData, logStream) {
    // Check if there's a fatal error timeout running for this task
    const timeoutId = this.fatalErrorTimeouts.get(taskId);
    if (!timeoutId) {
      return;
    }

    // Check if this is meaningful output (not just whitespace or progress indicators)
    const trimmed = stdoutData.trim();
    if (!trimmed || trimmed.length < 10) {
      return; // Skip very short output
    }

    // Skip progress indicators that don't indicate actual work
    const skipPatterns = [
      /^[.\s]+$/,           // Just dots or spaces
      /^\d+%$/,             // Just percentage
      /^[-=]+$/,            // Horizontal lines
      /^Streaming\.\.\./,   // Streaming indicator
      /^Thinking\.\.\./,    // Thinking indicator
    ];

    for (const pattern of skipPatterns) {
      if (pattern.test(trimmed)) {
        return;
      }
    }

    // Meaningful output received - cancel the fatal error timeout
    clearTimeout(timeoutId);
    this.fatalErrorTimeouts.delete(taskId);

    logger.info(`[FATAL-ERROR] Task ${taskId} produced meaningful stdout, cancelling kill timer (recovered)`);

    // Log to task's log file
    if (logStream && !logStream.destroyed) {
      logStream.write(`\n[FATAL-ERROR] Recovered - meaningful output received, kill timer cancelled\n`);
    }
  }

  /**
   * Schedule a post-completion cleanup to force-kill any lingering process
   * This handles edge cases where the child process doesn't properly exit
   * @param {string} taskId - The task ID for logging
   * @param {number} pid - The process ID to monitor and potentially kill
   * @param {number} delayMs - Delay in milliseconds before force-killing (default: 60000)
   */
  schedulePostCompletionCleanup(taskId, pid, delayMs = 60000) {
    setTimeout(async () => {
      try {
        // Check if the process is still running
        const processInfo = await this.getProcessInfo(pid);

        if (processInfo) {
          logger.warn(`[CLEANUP] Task ${taskId} process (PID: ${pid}) still alive ${delayMs / 1000}s after completion, force killing...`);

          try {
            // First try SIGTERM
            process.kill(pid, 'SIGTERM');

            // Wait 5 seconds then check again
            setTimeout(async () => {
              const stillAlive = await this.getProcessInfo(pid);
              if (stillAlive) {
                logger.warn(`[CLEANUP] PID ${pid} still alive after SIGTERM, sending SIGKILL...`);
                try {
                  process.kill(pid, 'SIGKILL');
                  logger.info(`[CLEANUP] Sent SIGKILL to PID ${pid}`);
                } catch (killErr) {
                  if (killErr.code !== 'ESRCH') {
                    logger.error(`[CLEANUP] Failed to SIGKILL PID ${pid}: ${killErr.message}`);
                  }
                }
              }
            }, 5000);

            logger.info(`[CLEANUP] Sent SIGTERM to lingering process (PID: ${pid}) for task ${taskId}`);
          } catch (killErr) {
            // ESRCH means process already exited, which is fine
            if (killErr.code !== 'ESRCH') {
              logger.error(`[CLEANUP] Failed to kill lingering process (PID: ${pid}): ${killErr.message}`);
            }
          }
        } else {
          logger.debug(`[CLEANUP] Task ${taskId} process (PID: ${pid}) already exited, no cleanup needed`);
        }
      } catch (err) {
        logger.error(`[CLEANUP] Error during post-completion cleanup for task ${taskId}: ${err.message}`);
      }
    }, delayMs);
  }
  
  async getAllTasksWithProcessInfo() {
    const tasks = this.getAllTasks();
    
    // Add process info to running tasks
    for (const task of tasks.running) {
      if (task.pid) {
        task.processInfo = await this.getProcessInfo(task.pid);
      }
    }
    
    return tasks;
  }

  getPendingTasksCountForWorkspace(workspace) {
    if (!workspace) return 0;
    return this.pendingTasks.filter(task => task.cwd === workspace).length;
  }

  /**
   * Initialize .gitignore inside .ani-code directory to ignore logs and instructions
   * @param {string} aniCodeDir - Path to .ani-code directory
   * @param {Function} existsSync - fs.existsSync function
   * @param {Function} writeFileSync - fs.writeFileSync function
   * @param {Function} join - path.join function
   */
  initAniCodeGitignore(aniCodeDir, existsSync, writeFileSync, join) {
    const gitignorePath = join(aniCodeDir, '.gitignore');
    if (!existsSync(gitignorePath)) {
      const gitignoreContent = `# Auto-generated by ani-code
# Ignore task logs and instruction files

logs/
instructions/
`;
      try {
        writeFileSync(gitignorePath, gitignoreContent, 'utf-8');
      } catch {
        // Ignore errors - gitignore is not critical
      }
    }
  }
}

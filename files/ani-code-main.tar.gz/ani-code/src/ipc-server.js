import { createServer } from 'net';
import { writeFileSync, unlinkSync, existsSync, readFileSync } from 'fs';
import { join, dirname } from 'path';
import { EventEmitter } from 'events';
import { logger } from './logger.js';
import { fileURLToPath } from 'url';

export class IPCServer extends EventEmitter {
  constructor(taskMonitor, providerManager = null) {
    super();
    this.taskMonitor = taskMonitor;
    this.providerManager = providerManager;
    this.server = null;
    this.clients = new Set();

    // Use the directory where this script is located as base directory
    const __filename = fileURLToPath(import.meta.url);
    const __dirname = dirname(__filename);
    const baseDir = join(__dirname, '..');
    this.portFile = join(baseDir, '.ani-code-ipc.port');

    // Get daemon version
    try {
      const packagePath = join(baseDir, 'package.json');
      const packageJson = JSON.parse(readFileSync(packagePath, 'utf8'));
      this.daemonVersion = packageJson.version;
    } catch {
      this.daemonVersion = 'unknown';
    }

    this.setupTaskMonitorHandlers();
  }

  setupTaskMonitorHandlers() {
    // Forward task output to connected clients
    this.taskMonitor.on('taskOutput', (outputData) => {
      this.broadcastToClients({
        type: 'task_output',
        data: outputData
      });
    });
  }

  async start() {
    return new Promise((resolve, reject) => {
      this.server = createServer((socket) => {
        this.handleClient(socket);
      });

      this.server.on('error', (error) => {
        logger.error('IPC server error:', error);
        reject(error);
      });

      this.server.listen(0, '127.0.0.1', () => {
        const port = this.server.address().port;

        // Write port to file for clients to connect
        writeFileSync(this.portFile, port.toString());

        logger.debug(`IPC server listening on port ${port}`);
        resolve(port);
      });
    });
  }

  stop() {
    if (this.server) {
      // Close all client connections
      this.clients.forEach(client => {
        try {
          client.end();
        } catch (error) {
          // Ignore errors when closing clients
        }
      });
      this.clients.clear();

      // Close server
      this.server.close();
      this.server = null;

      // Remove port file
      if (existsSync(this.portFile)) {
        unlinkSync(this.portFile);
      }

      logger.info('IPC server stopped');
    }
  }

  handleClient(socket) {
    this.clients.add(socket);
    logger.debug('IPC client connected');

    let buffer = '';

    socket.on('data', (data) => {
      buffer += data.toString();
      
      // Process complete messages (separated by newlines)
      const messages = buffer.split('\n');
      buffer = messages.pop(); // Keep incomplete message in buffer
      
      for (const messageStr of messages) {
        if (messageStr.trim()) {
          this.handleMessage(socket, messageStr);
        }
      }
    });

    socket.on('close', () => {
      this.clients.delete(socket);
      logger.debug('IPC client disconnected');
    });

    socket.on('end', () => {
      this.clients.delete(socket);
      logger.debug('IPC client ended connection');
    });

    socket.on('error', (error) => {
      logger.debug('IPC client error:', error.message);
      this.clients.delete(socket);
    });
  }

  async handleMessage(socket, messageStr) {
    let message;
    try {
      message = JSON.parse(messageStr);

      // Check version mismatch and log (but don't block)
      if (message.cliVersion && this.daemonVersion && message.cliVersion !== this.daemonVersion) {
        const cliParts = message.cliVersion.split('.').map(Number);
        const daemonParts = this.daemonVersion.split('.').map(Number);

        // Log version mismatch
        if (cliParts[0] !== daemonParts[0]) {
          logger.warn(`[Version] Major version mismatch - CLI: ${message.cliVersion}, Daemon: ${this.daemonVersion}`);
        } else if (cliParts[1] !== daemonParts[1]) {
          logger.info(`[Version] Minor version mismatch - CLI: ${message.cliVersion}, Daemon: ${this.daemonVersion}`);
        } else {
          logger.debug(`[Version] Patch version mismatch - CLI: ${message.cliVersion}, Daemon: ${this.daemonVersion}`);
        }
      }

      // Log incoming IPC message for debugging
      if (process.env.DEBUG_IPC) {
        logger.debug(`[IPC] Received message: ${message.type} (id: ${message.id}) from CLI v${message.cliVersion || 'unknown'}`);
      }

      const startTime = Date.now();
      const response = await this.processMessage(message);
      const processingTime = Date.now() - startTime;
      
      // Log slow IPC responses
      if (processingTime > 1000) {
        logger.warn(`[IPC] Slow response for ${message.type} (id: ${message.id}): ${processingTime}ms`);
      }
      
      // Send response back to client
      socket.write(JSON.stringify(response) + '\n');
      
      if (process.env.DEBUG_IPC) {
        logger.debug(`[IPC] Sent response for ${message.type} (id: ${message.id}) in ${processingTime}ms`);
      }
    } catch (error) {
      logger.error('Failed to handle IPC message:', error);
      
      // Send error response
      const errorResponse = {
        id: message?.id,
        success: false,
        error: error.message
      };
      socket.write(JSON.stringify(errorResponse) + '\n');
    }
  }

  async processMessage(message) {
    const { type, id, data } = message;

    try {
      switch (type) {
        case 'add_task':
          const task = this.taskMonitor.addTask(data.name, data.command, data.options);
          return { id, success: true, data: task };

        case 'cancel_task':
          const result = this.taskMonitor.cancelTask(data.taskId);
          return { id, success: true, data: result };

        case 'get_status':
          const status = this.taskMonitor.getStatus();
          return { id, success: true, data: status };
        
        case 'get_status_with_process_info':
          const statusWithInfo = await this.taskMonitor.getStatusWithProcessInfo();
          return { id, success: true, data: statusWithInfo };

        case 'get_task':
          const taskInfo = this.taskMonitor.getTaskById(data.taskId);
          return { id, success: true, data: taskInfo };

        case 'get_task_by_index':
          const taskByIndex = this.taskMonitor.getTaskByIndex(data.index);
          return { id, success: true, data: taskByIndex };

        case 'watch_task':
          // For watching, we just acknowledge the request
          // Real-time output will be sent via broadcast
          return { id, success: true, data: { watching: true } };

        case 'get_task_output':
          const output = this.taskMonitor.getTaskOutput(data.taskId, data.type, data.lines);
          return { id, success: true, data: output };

        case 'get_task_output_metrics':
          const metrics = this.taskMonitor.getTaskOutputMetrics(data.taskId);
          return { id, success: true, data: metrics };

        case 'get_task_history':
          const history = this.taskMonitor.getTaskHistory(data.limit);
          return { id, success: true, data: history };

        case 'get_history_task':
          const historyTask = this.taskMonitor.getHistoryTaskById(data.taskId);
          return { id, success: true, data: historyTask };

        case 'getChatIdForWorkdir':
          // Get chat ID associated with a workdir
          const chatId = this.taskMonitor.chatSettings ?
            this.taskMonitor.chatSettings.getChatForWorkdir(data.workdir) : null;
          return { id, success: true, data: { chatId } };

        // Provider management cases
        case 'provider_list':
          if (!this.providerManager) throw new Error('Provider manager not available');
          const providers = this.providerManager.listProviders();
          return { id, success: true, data: providers };

        case 'provider_current':
          if (!this.providerManager) throw new Error('Provider manager not available');
          const currentHandler = this.providerManager.getCurrentHandler();
          const currentInfo = currentHandler ? currentHandler.getInfo() : null;
          return { id, success: true, data: currentInfo };

        case 'provider_switch':
          if (!this.providerManager) throw new Error('Provider manager not available');
          const switchResult = this.providerManager.switchProvider(data.providerId);
          const switchInfo = switchResult ? switchResult.getInfo() : null;
          return { id, success: true, data: switchInfo };

        case 'provider_get':
          if (!this.providerManager) throw new Error('Provider manager not available');
          const getHandler = this.providerManager.getHandler(data.providerId);
          const getInfo = getHandler ? getHandler.getInfo() : null;
          return { id, success: true, data: getInfo };

        case 'gateway_status':
          // Get gateway status from the daemon's gatewayClient
          const { gatewayClient } = await import('./gateway-client.js');
          const gatewayStatus = await gatewayClient.getStatus();
          return { id, success: true, data: gatewayStatus };

        default:
          throw new Error(`Unknown message type: ${type}`);
      }
    } catch (error) {
      return { id, success: false, error: error.message };
    }
  }

  broadcastToClients(message) {
    this.clients.forEach(client => {
      try {
        // Check multiple socket states to ensure it's writable
        if (!client.destroyed && client.readyState !== 'closed' && client.writable && !client.pending) {
          client.write(JSON.stringify(message) + '\n');
        } else {
          // Remove disconnected clients
          this.clients.delete(client);
        }
      } catch (error) {
        logger.debug('Failed to broadcast to client (removing from list):', error.message);
        this.clients.delete(client);
      }
    });
  }
}

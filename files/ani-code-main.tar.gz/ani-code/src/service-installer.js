import { writeFileSync, readFileSync, existsSync, unlinkSync, chmodSync } from 'fs';
import { join, dirname } from 'path';
import { execSync } from 'child_process';
import { logger } from './logger.js';

export class ServiceInstaller {
  constructor() {
    this.serviceName = 'ani-code';
    this.serviceDescription = 'Ani Code Claude Task Manager Daemon';
    this.user = process.env.USER || process.env.LOGNAME || 'root';
    this.homeDir = process.env.HOME || '/root';
    this.projectDir = process.cwd();
    this.nodePath = process.execPath;
  }

  generateServiceFile() {
    const serviceContent = `[Unit]
Description=${this.serviceDescription}
After=network.target
Wants=network.target

[Service]
Type=simple
User=${this.user}
WorkingDirectory=${this.projectDir}
Environment=NODE_ENV=production
Environment=PATH=${process.env.PATH}
ExecStart=${this.nodePath} ${join(this.projectDir, 'src/daemon-runner.js')}
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=${this.serviceName}

# Security settings
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=false
ReadWritePaths=${this.projectDir}

# Resource limits
LimitNOFILE=65536
LimitNPROC=4096

[Install]
WantedBy=multi-user.target
`;

    return serviceContent;
  }

  installService() {
    try {
      // Check if running as root or with sudo
      if (process.getuid && process.getuid() !== 0) {
        logger.error('Service installation requires root privileges. Please run with sudo.');
        return { success: false, message: 'Root privileges required' };
      }

      const serviceContent = this.generateServiceFile();
      const servicePath = `/etc/systemd/system/${this.serviceName}.service`;

      // Write service file
      writeFileSync(servicePath, serviceContent);
      chmodSync(servicePath, 0o644);

      // Reload systemd
      execSync('systemctl daemon-reload', { stdio: 'inherit' });

      // Enable service
      execSync(`systemctl enable ${this.serviceName}`, { stdio: 'inherit' });

      logger.info(`Service installed successfully: ${servicePath}`);
      logger.info(`Service enabled and will start on boot`);
      logger.info(`Use 'systemctl start ${this.serviceName}' to start the service`);
      logger.info(`Use 'systemctl status ${this.serviceName}' to check status`);

      return { success: true, message: 'Service installed successfully' };
    } catch (error) {
      logger.error('Failed to install service:', error);
      return { success: false, message: error.message };
    }
  }

  uninstallService() {
    try {
      // Check if running as root or with sudo
      if (process.getuid && process.getuid() !== 0) {
        logger.error('Service uninstallation requires root privileges. Please run with sudo.');
        return { success: false, message: 'Root privileges required' };
      }

      const servicePath = `/etc/systemd/system/${this.serviceName}.service`;

      // Stop and disable service if running
      try {
        execSync(`systemctl stop ${this.serviceName}`, { stdio: 'inherit' });
        execSync(`systemctl disable ${this.serviceName}`, { stdio: 'inherit' });
      } catch (error) {
        // Service might not be running, ignore
      }

      // Remove service file
      if (existsSync(servicePath)) {
        unlinkSync(servicePath);
      }

      // Reload systemd
      execSync('systemctl daemon-reload', { stdio: 'inherit' });

      logger.info(`Service uninstalled successfully`);
      return { success: true, message: 'Service uninstalled successfully' };
    } catch (error) {
      logger.error('Failed to uninstall service:', error);
      return { success: false, message: error.message };
    }
  }

  generateUserServiceFile() {
    const userServiceDir = join(this.homeDir, '.config/systemd/user');
    const serviceContent = `[Unit]
Description=${this.serviceDescription}
After=network.target
Wants=network.target

[Service]
Type=simple
WorkingDirectory=${this.projectDir}
Environment=NODE_ENV=production
Environment=PATH=${process.env.PATH}
ExecStart=${this.nodePath} ${join(this.projectDir, 'src/daemon-runner.js')}
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=${this.serviceName}

# Resource limits
LimitNOFILE=65536
LimitNPROC=4096

[Install]
WantedBy=default.target
`;

    return { content: serviceContent, path: join(userServiceDir, `${this.serviceName}.service`) };
  }

  installUserService() {
    try {
      const { content, path } = this.generateUserServiceFile();
      const userServiceDir = dirname(path);

      // Create user service directory if it doesn't exist
      if (!existsSync(userServiceDir)) {
        execSync(`mkdir -p ${userServiceDir}`, { stdio: 'inherit' });
      }

      // Write service file
      writeFileSync(path, content);
      chmodSync(path, 0o644);

      // Enable user service
      execSync(`systemctl --user daemon-reload`, { stdio: 'inherit' });
      execSync(`systemctl --user enable ${this.serviceName}`, { stdio: 'inherit' });

      logger.info(`User service installed successfully: ${path}`);
      logger.info(`Service enabled and will start on login`);
      logger.info(`Use 'systemctl --user start ${this.serviceName}' to start the service`);
      logger.info(`Use 'systemctl --user status ${this.serviceName}' to check status`);

      return { success: true, message: 'User service installed successfully' };
    } catch (error) {
      logger.error('Failed to install user service:', error);
      return { success: false, message: error.message };
    }
  }

  uninstallUserService() {
    try {
      const { path } = this.generateUserServiceFile();

      // Stop and disable service if running
      try {
        execSync(`systemctl --user stop ${this.serviceName}`, { stdio: 'inherit' });
        execSync(`systemctl --user disable ${this.serviceName}`, { stdio: 'inherit' });
      } catch (error) {
        // Service might not be running, ignore
      }

      // Remove service file
      if (existsSync(path)) {
        unlinkSync(path);
      }

      // Reload user systemd
      execSync('systemctl --user daemon-reload', { stdio: 'inherit' });

      logger.info(`User service uninstalled successfully`);
      return { success: true, message: 'User service uninstalled successfully' };
    } catch (error) {
      logger.error('Failed to uninstall user service:', error);
      return { success: false, message: error.message };
    }
  }

  getServiceStatus() {
    try {
      // Check system service
      try {
        const systemStatus = execSync(`systemctl is-active ${this.serviceName}`, { encoding: 'utf8' }).trim();
        return { type: 'system', status: systemStatus, running: systemStatus === 'active' };
      } catch (error) {
        // System service not found, check user service
        try {
          const userStatus = execSync(`systemctl --user is-active ${this.serviceName}`, { encoding: 'utf8' }).trim();
          return { type: 'user', status: userStatus, running: userStatus === 'active' };
        } catch (error2) {
          return { type: 'none', status: 'not-installed', running: false };
        }
      }
    } catch (error) {
      return { type: 'error', status: 'unknown', running: false, error: error.message };
    }
  }
}

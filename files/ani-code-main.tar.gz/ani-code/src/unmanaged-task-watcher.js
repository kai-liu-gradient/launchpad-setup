import fs from 'fs/promises';
import fsSync from 'fs';
import path from 'path';
import os from 'os';
import { logger } from './logger.js';
import { getStatsDB } from './stats-db.js';
import { loadRegistry } from './commands/projects.js';
import { calculateTokenCost } from './providers/costCalculator.js';

/**
 * Unmanaged Task Watcher
 *
 * Monitors ~/.claude/projects/ for JSONL session files that are NOT associated
 * with any currently tracked ani-code task. When an unmanaged session is detected
 * (e.g., a user ran `claude` directly), it logs the discovery.
 *
 * Optionally, once the file stabilizes (no writes for a configurable period),
 * it can insert a summary record into the stats DB.
 *
 * Feature is disabled by default via UNMANAGED_TASK_DETECTION_ENABLED env var.
 */
export class UnmanagedTaskWatcher {
  constructor(taskQueue) {
    this.taskQueue = taskQueue;
    this.projectsDir = path.join(os.homedir(), '.claude', 'projects');

    // Configuration from env vars
    this.enabled = process.env.UNMANAGED_TASK_DETECTION_ENABLED === 'true';
    this.insertStats = process.env.UNMANAGED_TASK_INSERT_STATS === 'true';
    this.scanIntervalMs = parseInt(process.env.UNMANAGED_TASK_SCAN_INTERVAL_MS) || 60000;
    this.settleTimeMs = parseInt(process.env.UNMANAGED_TASK_SETTLE_TIME_MS) || 300000;
    this.maxAgeMs = parseInt(process.env.UNMANAGED_TASK_MAX_AGE_MS) || 3600000; // 1 hour

    // Internal state
    this.scanTimer = null;
    this.knownManagedFiles = new Set();       // JSONL files associated with ani-code tasks
    this.detectedUnmanaged = new Map();        // filepath -> { mtime, detectedAt, size, logged }
    this.insertedFiles = new Set();            // Files already inserted into stats DB
    this.running = false;
  }

  /**
   * Start the watcher. Logs configuration and begins periodic scanning.
   */
  start() {
    if (!this.enabled) {
      logger.info('[UNMANAGED] Unmanaged task detection is disabled (set UNMANAGED_TASK_DETECTION_ENABLED=true to enable)');
      return;
    }

    logger.info('[UNMANAGED] Unmanaged task detection enabled', {
      scanIntervalMs: this.scanIntervalMs,
      settleTimeMs: this.settleTimeMs,
      insertStats: this.insertStats
    });

    // Register known session files from currently active/queued tasks
    this._registerKnownTasks();

    // Start periodic scanning
    this.running = true;
    this.scanTimer = setInterval(() => this._scan(), this.scanIntervalMs);

    // Run initial scan after a short delay to let tasks settle
    setTimeout(() => this._scan(), 5000);
  }

  /**
   * Stop the watcher and clean up resources.
   */
  stop() {
    if (this.scanTimer) {
      clearInterval(this.scanTimer);
      this.scanTimer = null;
    }
    this.running = false;
    logger.debug('[UNMANAGED] Watcher stopped');
  }

  /**
   * Register a JSONL file as managed (associated with an ani-code task).
   * Called externally when a new task starts and its session file is known.
   * @param {string} filePath - Absolute path to the JSONL session file
   */
  registerManagedFile(filePath) {
    if (!this.enabled) return;
    this.knownManagedFiles.add(filePath);
    // If it was previously detected as unmanaged, remove it
    this.detectedUnmanaged.delete(filePath);
  }

  /**
   * Populate known managed files from active/pending/recent tasks in the queue.
   */
  _registerKnownTasks() {
    if (!this.taskQueue) return;

    const allTasks = this.taskQueue.getAllTasks();

    // Register from running tasks
    for (const task of allTasks.running) {
      if (task.sessionFile) {
        this.knownManagedFiles.add(task.sessionFile);
      }
    }

    // Register from pending tasks
    for (const task of allTasks.pending) {
      if (task.sessionFile) {
        this.knownManagedFiles.add(task.sessionFile);
      }
    }

    // Register from task history
    const history = this.taskQueue.getTaskHistory(50);
    for (const task of history) {
      if (task.sessionFile) {
        this.knownManagedFiles.add(task.sessionFile);
      }
    }

    logger.debug(`[UNMANAGED] Registered ${this.knownManagedFiles.size} known managed session file(s)`);
  }

  /**
   * Main scan loop: discover project folders, find JSONL files, cross-reference.
   */
  async _scan() {
    if (!this.running) return;

    try {
      // Check if the projects directory exists
      try {
        await fs.access(this.projectsDir);
      } catch {
        logger.debug(`[UNMANAGED] Projects directory not found: ${this.projectsDir}`);
        return;
      }

      // Refresh known tasks each scan
      this._registerKnownTasks();

      // List all project folders
      const entries = await fs.readdir(this.projectsDir, { withFileTypes: true });
      const projectFolders = entries.filter(e => e.isDirectory());

      for (const folder of projectFolders) {
        await this._scanProjectFolder(folder.name);
      }

      // Check for stabilized unmanaged files
      await this._checkStabilized();
    } catch (error) {
      logger.error('[UNMANAGED] Scan error:', error.message);
    }
  }

  /**
   * Scan a single project folder for unmanaged JSONL files.
   * @param {string} folderName - Encoded project folder name (e.g., '-root-workspace-ani-code')
   */
  async _scanProjectFolder(folderName) {
    const folderPath = path.join(this.projectsDir, folderName);

    try {
      const files = await fs.readdir(folderPath);
      const jsonlFiles = files.filter(f => f.endsWith('.jsonl') && !f.startsWith('agent-'));

      for (const file of jsonlFiles) {
        const filePath = path.join(folderPath, file);

        // Skip if already known as managed
        if (this.knownManagedFiles.has(filePath)) continue;

        // Skip if already inserted into stats
        if (this.insertedFiles.has(filePath)) continue;

        // Cross-reference with active tasks by matching project path
        if (this._isAssociatedWithActiveTask(folderName, file)) {
          this.knownManagedFiles.add(filePath);
          continue;
        }

        // Get file stats
        let stat;
        try {
          stat = await fs.stat(filePath);
        } catch {
          continue; // File may have been deleted mid-scan
        }

        // Skip empty files
        if (stat.size === 0) continue;

        // Skip files older than maxAgeMs (default 1 hour) - only for new detections
        const fileAge = Date.now() - stat.mtimeMs;
        if (!this.detectedUnmanaged.has(filePath) && fileAge > this.maxAgeMs) continue;

        const mtimeMs = stat.mtimeMs;

        if (this.detectedUnmanaged.has(filePath)) {
          // Update mtime if file has been modified
          const existing = this.detectedUnmanaged.get(filePath);
          existing.mtime = mtimeMs;
          existing.size = stat.size;
        } else {
          // New unmanaged file detected
          const projectPath = this._decodeFolderName(folderName);
          const projectName = this._resolveProjectName(projectPath);
          this.detectedUnmanaged.set(filePath, {
            mtime: mtimeMs,
            detectedAt: Date.now(),
            size: stat.size,
            birthtime: stat.birthtimeMs,
            projectPath,
            projectName,
            folderName,
            filename: file,
            logged: false
          });

          const displayName = projectName || projectPath;
          logger.info(`[UNMANAGED] Detected: ${file} in ${displayName}`);
        }
      }
    } catch (error) {
      // Graceful handling of permission errors and missing directories
      if (error.code !== 'ENOENT' && error.code !== 'EACCES') {
        logger.debug(`[UNMANAGED] Error scanning ${folderName}: ${error.message}`);
      }
    }
  }

  /**
   * Check if a JSONL file is associated with an active task by matching
   * the encoded project path to running task working directories.
   * @param {string} folderName - Encoded folder name
   * @param {string} filename - JSONL filename
   * @returns {boolean}
   */
  _isAssociatedWithActiveTask(folderName, filename) {
    if (!this.taskQueue) return false;

    const allTasks = this.taskQueue.getAllTasks();
    const allRunning = allTasks.running || [];
    const allPending = allTasks.pending || [];

    for (const task of [...allRunning, ...allPending]) {
      // Match by working directory (cwd) encoded as folder name
      const taskCwd = task.cwd || task.workspace;
      if (taskCwd) {
        const encodedCwd = taskCwd.replace(/\//g, '-');
        if (encodedCwd === folderName) {
          // This folder matches an active task's workspace.
          // The JSONL file could belong to this task.
          // Check creation time proximity as additional filter.
          return true;
        }
      }
    }

    return false;
  }

  /**
   * Check detected unmanaged files for stability (no writes for settleTime).
   */
  async _checkStabilized() {
    const now = Date.now();

    for (const [filePath, info] of this.detectedUnmanaged) {
      // Check if file has stabilized (mtime hasn't changed for settleTime)
      const timeSinceLastWrite = now - info.mtime;

      if (timeSinceLastWrite >= this.settleTimeMs) {
        // Parse session for rich summary
        const metrics = await this._parseSessionMetrics(filePath);

        // Estimate cost using costCalculator
        const costResult = calculateTokenCost({
          providerId: 'claude',
          modelId: metrics.model || 'unknown',
          inputTokens: metrics.approximateTokens.input,
          outputTokens: metrics.approximateTokens.output,
          cachedTokens: metrics.approximateTokens.cached
        });

        const durationStr = metrics.durationMs
          ? `${Math.round(metrics.durationMs / 1000)}s`
          : '?';
        const displayName = info.projectName || info.projectPath;
        const model = metrics.model || '?';
        const promptPreview = metrics.initialPrompt
          ? metrics.initialPrompt.length > 80
            ? metrics.initialPrompt.slice(0, 80) + '...'
            : metrics.initialPrompt
          : '';
        const tokenStr = `in:${metrics.approximateTokens.input} out:${metrics.approximateTokens.output} cached:${metrics.approximateTokens.cached}`;

        logger.info(`[UNMANAGED] Stabilized: ${info.filename} | ${displayName} | ${model} | ${durationStr} | $${costResult.totalCost.toFixed(4)} | ${tokenStr}${promptPreview ? ` | "${promptPreview}"` : ''}`);

        // Store metrics on info for stats insertion
        info._metrics = metrics;
        info._costResult = costResult;

        // Optionally insert into stats DB
        if (this.insertStats) {
          await this._insertStatsRecord(filePath, info);
        }

        // Remove from detected map (processing complete)
        this.detectedUnmanaged.delete(filePath);
        this.insertedFiles.add(filePath);
      }
    }
  }

  /**
   * Parse a JSONL session file to extract basic metrics for stats insertion.
   * @param {string} filePath - Path to the JSONL file
   * @returns {Promise<object>} Extracted metrics
   */
  async _parseSessionMetrics(filePath) {
    const metrics = {
      model: null,
      startTime: null,
      endTime: null,
      durationMs: 0,
      lineCount: 0,
      initialPrompt: null,
      approximateTokens: { input: 0, output: 0, cached: 0, total: 0 }
    };

    try {
      const content = await fs.readFile(filePath, 'utf-8');
      const lines = content.trim().split('\n').filter(l => l.trim());
      metrics.lineCount = lines.length;

      if (lines.length === 0) return metrics;

      // Parse first line for start time
      try {
        const firstLine = JSON.parse(lines[0]);
        if (firstLine.timestamp) {
          metrics.startTime = new Date(firstLine.timestamp).getTime();
        }
        // Model can be at root level or nested in message (Claude Code uses message.model)
        if (firstLine.model) {
          metrics.model = firstLine.model;
        } else if (firstLine.message?.model) {
          metrics.model = firstLine.message.model;
        }
      } catch { /* ignore parse errors */ }

      // Parse last line for end time and model
      try {
        const lastLine = JSON.parse(lines[lines.length - 1]);
        if (lastLine.timestamp) {
          metrics.endTime = new Date(lastLine.timestamp).getTime();
        }
        if (!metrics.model) {
          if (lastLine.model) {
            metrics.model = lastLine.model;
          } else if (lastLine.message?.model) {
            metrics.model = lastLine.message.model;
          }
        }
      } catch { /* ignore parse errors */ }

      // Calculate duration
      if (metrics.startTime && metrics.endTime) {
        metrics.durationMs = metrics.endTime - metrics.startTime;
      }

      // Scan lines for initial prompt, model, and token info
      for (const line of lines) {
        try {
          const entry = JSON.parse(line);

          // Look for model info (root level or nested in message for Claude Code JSONL)
          if (!metrics.model) {
            if (entry.model) {
              metrics.model = entry.model;
            } else if (entry.message?.model) {
              metrics.model = entry.message.model;
            }
          }

          // Extract initial user prompt (first user message)
          if (!metrics.initialPrompt && entry.type === 'user' && entry.message?.content) {
            const content = typeof entry.message.content === 'string'
              ? entry.message.content
              : Array.isArray(entry.message.content)
                ? entry.message.content.map(c => c.text || '').join(' ')
                : '';
            if (content) {
              metrics.initialPrompt = content.length > 120
                ? content.slice(0, 120) + '...'
                : content;
            }
          }

          // Look for usage/token info (root level or nested in message for Claude Code JSONL)
          const usage = entry.usage || entry.message?.usage;
          if (usage) {
            if (usage.input_tokens) metrics.approximateTokens.input += usage.input_tokens;
            if (usage.output_tokens) metrics.approximateTokens.output += usage.output_tokens;
            // Track cached tokens (cache_read_input_tokens from Claude API)
            if (usage.cache_read_input_tokens) metrics.approximateTokens.cached += usage.cache_read_input_tokens;
          }
        } catch { /* ignore parse errors for individual lines */ }
      }

      metrics.approximateTokens.total =
        metrics.approximateTokens.input + metrics.approximateTokens.output;
    } catch (error) {
      logger.debug(`[UNMANAGED] Error parsing session metrics: ${error.message}`);
    }

    return metrics;
  }

  /**
   * Insert a stats record for a stabilized unmanaged session.
   * @param {string} filePath - Path to the JSONL file
   * @param {object} info - Detection info from detectedUnmanaged map
   */
  async _insertStatsRecord(filePath, info) {
    try {
      // Use pre-parsed metrics from _checkStabilized if available
      const metrics = info._metrics || await this._parseSessionMetrics(filePath);
      const costResult = info._costResult || calculateTokenCost({
        providerId: 'claude',
        modelId: metrics.model || 'unknown',
        inputTokens: metrics.approximateTokens.input,
        outputTokens: metrics.approximateTokens.output,
        cachedTokens: metrics.approximateTokens.cached
      });
      const statsDB = getStatsDB();

      if (!statsDB) {
        logger.warn('[UNMANAGED] Stats DB not available, skipping stats insertion');
        return;
      }

      // Generate synthetic task ID with unmanaged- prefix
      const timestamp = info.birthtime ? new Date(info.birthtime).toISOString().slice(5, 10).replace('-', '') : 'unknown';
      const fileId = path.basename(info.filename, '.jsonl').slice(0, 8);
      const taskId = `unmanaged-${timestamp}-${fileId}`;

      // Create task record with initial prompt
      const displayName = info.projectName || info.projectPath;
      const promptPreview = metrics.initialPrompt
        ? `unmanaged: ${metrics.initialPrompt}`
        : `unmanaged: Claude session in ${displayName}`;
      statsDB.recordTaskCreation(taskId, info.projectPath, promptPreview);

      // Complete task record with metrics and cost
      const durationStr = metrics.durationMs ? Math.round(metrics.durationMs / 1000) + 's' : 'unknown';
      const outputPreview = `Unmanaged session: ${metrics.lineCount} lines, ${durationStr} duration, ${metrics.approximateTokens.total} tokens, ~$${costResult.totalCost.toFixed(4)}`;
      statsDB.recordTaskCompletion(
        taskId,
        outputPreview,
        metrics.model || 'unknown',
        costResult.totalCost,
        metrics.approximateTokens,
        null // provider unknown
      );

      logger.info(`[UNMANAGED] Stats inserted: ${taskId}`);
    } catch (error) {
      logger.error(`[UNMANAGED] Failed to insert stats record: ${error.message}`);
    }
  }

  /**
   * Decode an encoded folder name back to a project path.
   * Claude encodes paths by replacing / with -
   * e.g., '-root-workspace-ani-code' -> '/root/workspace/ani-code'
   *
   * Note: This is inherently ambiguous for paths containing hyphens in directory names.
   * We do a best-effort decode by checking if the decoded path exists.
   * @param {string} folderName - Encoded folder name
   * @returns {string} Decoded project path (best effort)
   */
  _decodeFolderName(folderName) {
    // Simple decode: leading hyphen becomes /, remaining hyphens become /
    // This works for paths without hyphens in directory names
    if (folderName.startsWith('-')) {
      return '/' + folderName.slice(1).replace(/-/g, '/');
    }
    return folderName.replace(/-/g, '/');
  }

  /**
   * Resolve a project name from the project registry (Goal 004) for a given project path.
   * Looks for a registry.json in the decoded path's .ani-code/projects/ directory.
   * @param {string} projectPath - Decoded project path (e.g., '/root/workspace/ani-code')
   * @returns {string|null} Project name if found, null otherwise
   */
  _resolveProjectName(projectPath) {
    try {
      const registry = loadRegistry(projectPath);
      if (!registry || !registry.projects || registry.projects.length === 0) {
        return null;
      }

      // Look for the root project (path: ".") first
      const rootProject = registry.projects.find(p => p.path === '.');
      if (rootProject) {
        return rootProject.name || rootProject.id;
      }

      // Fallback: return the first project's name
      return registry.projects[0].name || registry.projects[0].id;
    } catch {
      return null;
    }
  }

  /**
   * Get current watcher status for diagnostics.
   * @returns {object} Status info
   */
  getStatus() {
    return {
      enabled: this.enabled,
      running: this.running,
      insertStats: this.insertStats,
      scanIntervalMs: this.scanIntervalMs,
      settleTimeMs: this.settleTimeMs,
      knownManagedFiles: this.knownManagedFiles.size,
      detectedUnmanaged: this.detectedUnmanaged.size,
      insertedFiles: this.insertedFiles.size,
      detectedFiles: Array.from(this.detectedUnmanaged.entries()).map(([fp, info]) => ({
        filename: info.filename,
        projectPath: info.projectPath,
        projectName: info.projectName || null,
        size: info.size,
        detectedAt: new Date(info.detectedAt).toISOString(),
        timeSinceLastWrite: Date.now() - info.mtime
      }))
    };
  }
}

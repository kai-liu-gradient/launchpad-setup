import { existsSync, mkdirSync, readFileSync, writeFileSync, readdirSync, unlinkSync, renameSync } from 'fs';
import { join, basename } from 'path';
import crypto from 'crypto';
import { logger } from './logger.js';

/**
 * HintManager - Manages transient contextual hints for task iterations
 *
 * Hints are stored as markdown files in .ani-code/hints/ directory.
 * They are automatically injected into task prompts and expire after 1 hour.
 *
 * File naming convention:
 * - Active hints: todo.<YYYY-MM-DD-HHmmss>-<4char-id>.md
 * - Acknowledged hints: ack.<YYYY-MM-DD-HHmmss>-<4char-id>.md
 */
export class HintManager {
  constructor(workspacePath = null) {
    this.workspacePath = workspacePath || process.cwd();
    this.hintsDir = join(this.workspacePath, '.ani-code', 'hints');
    this.ttlHours = parseInt(process.env.HINT_TTL_HOURS) || 1;
    this.maxInject = parseInt(process.env.HINT_MAX_INJECT) || 5;
    this.maxLength = parseInt(process.env.HINT_MAX_LENGTH) || 10240;
  }

  /**
   * Ensure hints directory exists
   */
  ensureHintsDir() {
    if (!existsSync(this.hintsDir)) {
      mkdirSync(this.hintsDir, { recursive: true });
      logger.debug(`[HINT] Created hints directory: ${this.hintsDir}`);
    }
  }

  /**
   * Generate a short unique ID (4 characters)
   * @returns {string} 4-character hex ID
   */
  generateShortId() {
    return crypto.randomBytes(2).toString('hex');
  }

  /**
   * Generate timestamp string in YYYY-MM-DD-HHmmss format
   * @param {Date} date - Date object (defaults to now)
   * @returns {string} Formatted timestamp
   */
  formatTimestamp(date = new Date()) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    return `${year}-${month}-${day}-${hours}${minutes}${seconds}`;
  }

  /**
   * Parse hint filename to extract metadata
   * @param {string} filename - Hint filename
   * @returns {Object|null} Parsed metadata or null if invalid
   */
  parseHintFilename(filename) {
    // Pattern: (todo|ack).<YYYY-MM-DD-HHmmss>-<4char-id>.md
    const match = filename.match(/^(todo|ack)\.(\d{4}-\d{2}-\d{2}-\d{6})-([a-f0-9]{4})\.md$/);
    if (!match) {
      return null;
    }

    const [, prefix, timestamp, id] = match;
    const isActive = prefix === 'todo';

    // Parse timestamp back to Date
    const [datePart, timePart] = timestamp.split('-').length === 4
      ? [timestamp.slice(0, 10), timestamp.slice(11)]
      : [null, null];

    if (!datePart || !timePart) {
      return null;
    }

    const year = parseInt(datePart.slice(0, 4));
    const month = parseInt(datePart.slice(5, 7)) - 1;
    const day = parseInt(datePart.slice(8, 10));
    const hours = parseInt(timePart.slice(0, 2));
    const minutes = parseInt(timePart.slice(2, 4));
    const seconds = parseInt(timePart.slice(4, 6));

    const created = new Date(year, month, day, hours, minutes, seconds);

    return {
      id,
      filename,
      prefix,
      isActive,
      timestamp,
      created,
      expires: new Date(created.getTime() + this.ttlHours * 60 * 60 * 1000)
    };
  }

  /**
   * Create a new hint
   * @param {string} content - Hint content
   * @param {string} source - Source of the hint (cli, api, gateway)
   * @returns {Object} Created hint info { id, filename, expires }
   */
  async createHint(content, source = 'cli') {
    this.ensureHintsDir();

    // Validate content
    if (!content || typeof content !== 'string') {
      throw new Error('Hint content is required');
    }

    // Truncate if too long
    if (content.length > this.maxLength) {
      content = content.substring(0, this.maxLength) + '\n\n[Content truncated - exceeded max length]';
      logger.warn(`[HINT] Content truncated to ${this.maxLength} characters`);
    }

    const now = new Date();
    const id = this.generateShortId();
    const timestamp = this.formatTimestamp(now);
    const filename = `todo.${timestamp}-${id}.md`;
    const filepath = join(this.hintsDir, filename);

    const expires = new Date(now.getTime() + this.ttlHours * 60 * 60 * 1000);

    // Create hint file with YAML frontmatter
    const fileContent = `---
created: ${now.toISOString()}
expires: ${expires.toISOString()}
source: ${source}
---

${content}
`;

    writeFileSync(filepath, fileContent, 'utf8');
    logger.info(`[HINT] Created hint ${id}: ${content.substring(0, 50)}...`);

    return {
      id,
      filename,
      filepath,
      expires,
      created: now
    };
  }

  /**
   * Parse hint file content
   * @param {string} filepath - Full path to hint file
   * @returns {Object} Parsed hint { metadata, content }
   */
  parseHintFile(filepath) {
    const raw = readFileSync(filepath, 'utf8');

    // Parse YAML frontmatter
    const frontmatterMatch = raw.match(/^---\n([\s\S]*?)\n---\n([\s\S]*)$/);

    let metadata = {};
    let content = raw;

    if (frontmatterMatch) {
      const frontmatter = frontmatterMatch[1];
      content = frontmatterMatch[2].trim();

      // Simple YAML parsing for key: value pairs
      frontmatter.split('\n').forEach(line => {
        const colonIndex = line.indexOf(':');
        if (colonIndex > 0) {
          const key = line.substring(0, colonIndex).trim();
          const value = line.substring(colonIndex + 1).trim();
          metadata[key] = value;
        }
      });
    }

    return { metadata, content };
  }

  /**
   * Get all active (non-expired, non-acknowledged) hints
   * @returns {Array} Array of active hint objects
   */
  async getActiveHints() {
    if (!existsSync(this.hintsDir)) {
      return [];
    }

    const files = readdirSync(this.hintsDir);
    const now = new Date();
    const activeHints = [];

    for (const file of files) {
      // Only process active hints (todo.* prefix)
      if (!file.startsWith('todo.')) {
        continue;
      }

      const parsed = this.parseHintFilename(file);
      if (!parsed) {
        logger.debug(`[HINT] Skipping invalid hint file: ${file}`);
        continue;
      }

      // Check if expired
      if (parsed.expires < now) {
        logger.debug(`[HINT] Hint ${parsed.id} has expired`);
        continue;
      }

      // Parse file content
      const filepath = join(this.hintsDir, file);
      const { metadata, content } = this.parseHintFile(filepath);

      // Calculate age
      const ageMs = now - parsed.created;
      const ageMinutes = Math.floor(ageMs / (60 * 1000));
      const ageText = ageMinutes < 1 ? 'just now'
        : ageMinutes === 1 ? '1 minute ago'
        : ageMinutes < 60 ? `${ageMinutes} minutes ago`
        : `${Math.floor(ageMinutes / 60)} hour(s) ago`;

      activeHints.push({
        id: parsed.id,
        filename: file,
        filepath,
        created: parsed.created,
        expires: parsed.expires,
        ageMinutes,
        ageText,
        source: metadata.source || 'unknown',
        content
      });
    }

    // Sort by creation time (oldest first for consistent ordering)
    activeHints.sort((a, b) => a.created - b.created);

    // Limit to maxInject
    return activeHints.slice(0, this.maxInject);
  }

  /**
   * Acknowledge a hint (mark as resolved)
   * @param {string} hintId - Hint ID (4-character hex)
   * @returns {boolean} True if hint was acknowledged
   */
  async ackHint(hintId) {
    if (!existsSync(this.hintsDir)) {
      return false;
    }

    const files = readdirSync(this.hintsDir);

    for (const file of files) {
      if (!file.startsWith('todo.') || !file.includes(`-${hintId}.md`)) {
        continue;
      }

      const oldPath = join(this.hintsDir, file);
      const newFilename = file.replace(/^todo\./, 'ack.');
      const newPath = join(this.hintsDir, newFilename);

      renameSync(oldPath, newPath);
      logger.info(`[HINT] Acknowledged hint ${hintId}`);
      return true;
    }

    logger.warn(`[HINT] Hint ${hintId} not found for acknowledgment`);
    return false;
  }

  /**
   * Clear all active hints
   * @returns {number} Number of hints cleared
   */
  async clearHints() {
    if (!existsSync(this.hintsDir)) {
      return 0;
    }

    const files = readdirSync(this.hintsDir);
    let cleared = 0;

    for (const file of files) {
      if (file.startsWith('todo.')) {
        const filepath = join(this.hintsDir, file);
        unlinkSync(filepath);
        cleared++;
      }
    }

    logger.info(`[HINT] Cleared ${cleared} active hint(s)`);
    return cleared;
  }

  /**
   * Cleanup expired hints (both active and acknowledged)
   * @returns {number} Number of hints cleaned up
   */
  async cleanupExpiredHints() {
    if (!existsSync(this.hintsDir)) {
      return 0;
    }

    const files = readdirSync(this.hintsDir);
    const now = new Date();
    let cleaned = 0;

    for (const file of files) {
      const parsed = this.parseHintFilename(file);
      if (!parsed) {
        continue;
      }

      // Remove if expired
      if (parsed.expires < now) {
        const filepath = join(this.hintsDir, file);
        unlinkSync(filepath);
        cleaned++;
        logger.debug(`[HINT] Cleaned up expired hint: ${file}`);
      }
    }

    if (cleaned > 0) {
      logger.info(`[HINT] Cleaned up ${cleaned} expired hint(s)`);
    }

    return cleaned;
  }

  /**
   * Format hints for prompt injection
   * @param {Array} hints - Array of hint objects from getActiveHints()
   * @returns {string} Formatted hints section for prompt injection
   */
  formatForPrompt(hints) {
    if (!hints || hints.length === 0) {
      return '';
    }

    let formatted = `
---
## Active Hints (Optional Context)

The following hints were recorded by the user. Consider them if relevant to the current task.
If a hint describes an issue you resolve, please acknowledge it by creating a file named \`ack.<original-hint-filename-without-todo>\` in \`.ani-code/hints/\` or inform the user that the issue is resolved.

`;

    hints.forEach((hint, index) => {
      formatted += `### Hint ${index + 1} (recorded ${hint.ageText}, ID: ${hint.id})
${hint.content}

`;
    });

    formatted += '---\n';

    return formatted;
  }

  /**
   * Get hint by ID
   * @param {string} hintId - Hint ID (4-character hex)
   * @returns {Object|null} Hint object or null if not found
   */
  async getHintById(hintId) {
    if (!existsSync(this.hintsDir)) {
      return null;
    }

    const files = readdirSync(this.hintsDir);

    for (const file of files) {
      if (!file.includes(`-${hintId}.md`)) {
        continue;
      }

      const parsed = this.parseHintFilename(file);
      if (!parsed) {
        continue;
      }

      const filepath = join(this.hintsDir, file);
      const { metadata, content } = this.parseHintFile(filepath);

      return {
        ...parsed,
        filepath,
        source: metadata.source || 'unknown',
        content
      };
    }

    return null;
  }

  /**
   * List all hints (both active and acknowledged)
   * @returns {Array} Array of all hint objects
   */
  async listAllHints() {
    if (!existsSync(this.hintsDir)) {
      return [];
    }

    const files = readdirSync(this.hintsDir);
    const hints = [];

    for (const file of files) {
      const parsed = this.parseHintFilename(file);
      if (!parsed) {
        continue;
      }

      const filepath = join(this.hintsDir, file);
      const { metadata, content } = this.parseHintFile(filepath);

      hints.push({
        ...parsed,
        filepath,
        source: metadata.source || 'unknown',
        content
      });
    }

    // Sort by creation time (newest first)
    hints.sort((a, b) => b.created - a.created);

    return hints;
  }
}

// Export singleton factory for convenience
let defaultInstance = null;

export function getHintManager(workspacePath = null) {
  if (!defaultInstance || (workspacePath && defaultInstance.workspacePath !== workspacePath)) {
    defaultInstance = new HintManager(workspacePath);
  }
  return defaultInstance;
}

export default HintManager;

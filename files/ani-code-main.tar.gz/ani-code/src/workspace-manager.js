import sqlite3 from 'sqlite3';
import { open } from 'sqlite';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { logger } from './logger.js';
import fs from 'fs/promises';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import crypto from 'crypto';
import {
  normalizePlanStep,
  normalizePlanSteps,
  stepsToPlanDescription
} from './utils/plan-step-utils.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

/**
 * Get the effective showprogress mode for a workspace.
 * Defaults to 'autopin' if not explicitly set (i.e. autopin is the default).
 * @param {Object} workspace - The workspace object
 * @returns {string} 'autopin' | 'auto' | 'off'
 */
export function getShowProgressMode(workspace) {
  if (workspace?.settings?.showprogress) {
    return workspace.settings.showprogress;
  }
  return 'autopin';
}

// Global plan counter, resets on daemon restart
let planRandomPrefix = null;
let planCounter = 1000; // Start from 1000 so first plan is 1001

function generatePlanId(workspaceName = null) {
  // Generate new random prefix on daemon restart
  if (!planRandomPrefix) {
    planRandomPrefix = crypto.randomBytes(1).toString('hex').toUpperCase(); // 2 hex chars
  }

  // Increment counter (starts at 1001)
  planCounter++;
  const counterStr = planCounter.toString();

  // Format: acp-MMDD-workspace-XX01
  const now = new Date();
  const month = (now.getMonth() + 1).toString().padStart(2, '0');
  const day = now.getDate().toString().padStart(2, '0');

  // Extract workspace identifier if provided
  let workspacePart = '';
  if (workspaceName) {
    // Sanitize workspace part (remove special chars, limit length)
    workspacePart = workspaceName.replace(/[^a-zA-Z0-9]/g, '').substring(0, 10) + '-';
  }

  return `acp-${month}${day}-${workspacePart}${planRandomPrefix}${counterStr}`;
}

export class WorkspaceManager {
  constructor(dbPath = null) {
    const aniCodeRoot = path.resolve(__dirname, '..');
    this.dbPath = dbPath || path.join(aniCodeRoot, 'workspaces.db');
    this.db = null;
    this.jwtSecret = null;
  }

  async initialize() {
    try {
      // Open database connection
      this.db = await open({
        filename: this.dbPath,
        driver: sqlite3.Database
      });

      // Create tables if they don't exist
      await this.createTables();
      
      // Load or generate JWT secret
      await this.loadJWTSecret();
      
      logger.debug(`Workspace database initialized at ${this.dbPath}`);
    } catch (error) {
      logger.error('Failed to initialize workspace database:', error);
      throw error;
    }
  }

  async createTables() {
    // Workspaces table
    await this.db.exec(`
      CREATE TABLE IF NOT EXISTS workspaces (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        description TEXT,
        path TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        is_active BOOLEAN DEFAULT 1,
        settings TEXT DEFAULT '{}'
      )
    `);

    // Add yolo mode columns if they don't exist (migration)
    try {
      await this.db.exec(`
        ALTER TABLE workspaces ADD COLUMN yolo_mode_active BOOLEAN DEFAULT 0;
      `);
    } catch (e) {
      // Column already exists, ignore
    }

    try {
      await this.db.exec(`
        ALTER TABLE workspaces ADD COLUMN yolo_status_message_id TEXT;
      `);
    } catch (e) {
      // Column already exists, ignore
    }

    try {
      await this.db.exec(`
        ALTER TABLE workspaces ADD COLUMN yolo_message_version INTEGER DEFAULT 0;
      `);
    } catch (e) {
      // Column already exists, ignore
    }

    try {
      await this.db.exec(`
        ALTER TABLE workspaces ADD COLUMN yolo_start_time DATETIME;
      `);
    } catch (e) {
      // Column already exists, ignore
    }

    try {
      await this.db.exec(`
        ALTER TABLE workspaces ADD COLUMN yolo_plans_total INTEGER DEFAULT 0;
      `);
    } catch (e) {
      // Column already exists, ignore
    }

    try {
      await this.db.exec(`
        ALTER TABLE workspaces ADD COLUMN yolo_plans_completed INTEGER DEFAULT 0;
      `);
    } catch (e) {
      // Column already exists, ignore
    }

    try {
      await this.db.exec(`
        ALTER TABLE workspaces ADD COLUMN yolo_current_plan TEXT;
      `);
    } catch (e) {
      // Column already exists, ignore
    }

    try {
      await this.db.exec(`
        ALTER TABLE workspaces ADD COLUMN yolo_scheduled_time TEXT;
      `);
    } catch (e) {
      // Column already exists, ignore
    }

    // Workspace tokens table
    await this.db.exec(`
      CREATE TABLE IF NOT EXISTS workspace_tokens (
        id TEXT PRIMARY KEY,
        workspace_id TEXT NOT NULL,
        token_hash TEXT NOT NULL,
        name TEXT,
        type TEXT DEFAULT 'api',
        permissions TEXT DEFAULT '["read", "write"]',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        expires_at DATETIME,
        last_used_at DATETIME,
        is_revoked BOOLEAN DEFAULT 0,
        FOREIGN KEY (workspace_id) REFERENCES workspaces(id) ON DELETE CASCADE
      )
    `);

    // Chat workspace mappings table (for Lark)
    await this.db.exec(`
      CREATE TABLE IF NOT EXISTS chat_workspace_mappings (
        id TEXT PRIMARY KEY,
        chat_id TEXT NOT NULL,
        workspace_id TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        is_active BOOLEAN DEFAULT 1,
        FOREIGN KEY (workspace_id) REFERENCES workspaces(id) ON DELETE CASCADE,
        UNIQUE(chat_id, workspace_id)
      )
    `);

    // Telegram chat authorization table
    await this.db.exec(`
      CREATE TABLE IF NOT EXISTS telegram_chats (
        id TEXT PRIMARY KEY,
        chat_id TEXT NOT NULL UNIQUE,
        chat_type TEXT NOT NULL,
        chat_title TEXT,
        username TEXT,
        first_name TEXT,
        last_name TEXT,
        workspace_id TEXT,
        token_id TEXT,
        is_authorized BOOLEAN DEFAULT 0,
        authorized_by TEXT,
        authorized_at DATETIME,
        last_interaction DATETIME,
        metadata TEXT DEFAULT '{}',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (workspace_id) REFERENCES workspaces(id) ON DELETE SET NULL,
        FOREIGN KEY (token_id) REFERENCES workspace_tokens(id) ON DELETE SET NULL
      )
    `);

    // Telegram allowed users table
    await this.db.exec(`
      CREATE TABLE IF NOT EXISTS telegram_allowed_users (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL UNIQUE,
        username TEXT,
        first_name TEXT,
        last_name TEXT,
        is_admin BOOLEAN DEFAULT 0,
        can_authorize_chats BOOLEAN DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // WebSocket connections table for tracking active connections
    await this.db.exec(`
      CREATE TABLE IF NOT EXISTS ws_connections (
        id TEXT PRIMARY KEY,
        workspace_id TEXT NOT NULL,
        token_id TEXT,
        client_info TEXT,
        connected_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        disconnected_at DATETIME,
        is_active BOOLEAN DEFAULT 1,
        FOREIGN KEY (workspace_id) REFERENCES workspaces(id) ON DELETE CASCADE,
        FOREIGN KEY (token_id) REFERENCES workspace_tokens(id) ON DELETE SET NULL
      )
    `);

    // Workspace plans table for storing task plans
    await this.db.exec(`
      CREATE TABLE IF NOT EXISTS workspace_plans (
        id TEXT PRIMARY KEY,
        workspace_id TEXT NOT NULL,
        plan_id TEXT NOT NULL,
        title TEXT,
        description TEXT,
        steps TEXT NOT NULL,
        status TEXT DEFAULT 'pending',
        current_step INTEGER DEFAULT 0,
        created_by TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        completed_at DATETIME,
        metadata TEXT DEFAULT '{}',
        FOREIGN KEY (workspace_id) REFERENCES workspaces(id) ON DELETE CASCADE,
        UNIQUE(workspace_id, plan_id)
      )
    `);

    // Create indices for better query performance
    // Task logs table for tracking all task events
    await this.db.exec(`
      CREATE TABLE IF NOT EXISTS task_logs (
        id TEXT PRIMARY KEY,
        task_id TEXT,
        workspace_id TEXT,
        event_type TEXT NOT NULL,
        chat_id TEXT,
        source TEXT,
        command TEXT,
        message TEXT,
        metadata TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (workspace_id) REFERENCES workspaces(id) ON DELETE CASCADE
      )
    `);

    await this.db.exec(`
      CREATE INDEX IF NOT EXISTS idx_workspace_tokens_workspace_id ON workspace_tokens(workspace_id);
      CREATE INDEX IF NOT EXISTS idx_workspace_tokens_hash ON workspace_tokens(token_hash);
      CREATE INDEX IF NOT EXISTS idx_task_logs_task_id ON task_logs(task_id);
      CREATE INDEX IF NOT EXISTS idx_task_logs_workspace_id ON task_logs(workspace_id);
      CREATE INDEX IF NOT EXISTS idx_task_logs_chat_id ON task_logs(chat_id);
      CREATE INDEX IF NOT EXISTS idx_task_logs_created_at ON task_logs(created_at);
      CREATE INDEX IF NOT EXISTS idx_chat_workspace_mappings_chat_id ON chat_workspace_mappings(chat_id);
      CREATE INDEX IF NOT EXISTS idx_chat_workspace_mappings_workspace_id ON chat_workspace_mappings(workspace_id);
      CREATE INDEX IF NOT EXISTS idx_workspace_plans_workspace_id ON workspace_plans(workspace_id);
      CREATE INDEX IF NOT EXISTS idx_workspace_plans_plan_id ON workspace_plans(plan_id);
      CREATE INDEX IF NOT EXISTS idx_ws_connections_workspace_id ON ws_connections(workspace_id);
      CREATE INDEX IF NOT EXISTS idx_ws_connections_active ON ws_connections(is_active);
      CREATE INDEX IF NOT EXISTS idx_telegram_chats_chat_id ON telegram_chats(chat_id);
      CREATE INDEX IF NOT EXISTS idx_telegram_chats_workspace_id ON telegram_chats(workspace_id);
      CREATE INDEX IF NOT EXISTS idx_telegram_chats_authorized ON telegram_chats(is_authorized);
      CREATE INDEX IF NOT EXISTS idx_telegram_allowed_users_user_id ON telegram_allowed_users(user_id);
    `);
  }

  async loadJWTSecret() {
    const secretPath = path.join(path.dirname(this.dbPath), '.jwt-secret');
    try {
      this.jwtSecret = await fs.readFile(secretPath, 'utf8');
    } catch (error) {
      // Generate a new secret if it doesn't exist
      const crypto = await import('crypto');
      this.jwtSecret = crypto.randomBytes(64).toString('hex');
      await fs.writeFile(secretPath, this.jwtSecret, { mode: 0o600 });
      logger.info('Generated new JWT secret');
    }
  }

  // Workspace CRUD operations
  async createWorkspace(name, workspacePath, description = null) {
    const id = uuidv4();
    const normalizedPath = path.resolve(workspacePath);
    
    try {
      // Check if path exists
      const stats = await fs.stat(normalizedPath);
      if (!stats.isDirectory()) {
        throw new Error(`Path ${normalizedPath} is not a directory`);
      }
    } catch (error) {
      if (error.code === 'ENOENT') {
        // Create directory if it doesn't exist
        await fs.mkdir(normalizedPath, { recursive: true });
        logger.info(`Created workspace directory: ${normalizedPath}`);
      } else {
        throw error;
      }
    }

    await this.db.run(
      `INSERT INTO workspaces (id, name, description, path) VALUES (?, ?, ?, ?)`,
      [id, name, description, normalizedPath]
    );

    logger.info(`Created workspace: ${name} (${id}) at ${normalizedPath}`);
    return { id, name, description, path: normalizedPath };
  }

  /**
   * Ensure the gateway-default workspace exists in the database.
   * This is called when gateway mode is enabled to ensure workspace-aware
   * operations (plans, goals, etc.) work correctly.
   * @returns {Object} The gateway workspace object
   */
  async ensureGatewayWorkspace() {
    const gatewayWorkspaceId = 'gateway-default';
    const gatewayWorkspaceName = 'workspace';
    const gatewayWorkspacePath = '/workspace';

    // Check if gateway workspace already exists
    let workspace = await this.getWorkspace(gatewayWorkspaceId);
    if (workspace) {
      return workspace;
    }

    // Also check by name in case it exists with a different ID
    workspace = await this.getWorkspace(gatewayWorkspaceName);
    if (workspace) {
      return workspace;
    }

    // Create the gateway workspace with a known ID
    try {
      const { existsSync, mkdirSync } = await import('fs');
      if (!existsSync(gatewayWorkspacePath)) {
        mkdirSync(gatewayWorkspacePath, { recursive: true });
        logger.info(`Created gateway workspace directory: ${gatewayWorkspacePath}`);
      }

      await this.db.run(
        `INSERT INTO workspaces (id, name, description, path) VALUES (?, ?, ?, ?)`,
        [gatewayWorkspaceId, gatewayWorkspaceName, 'Gateway default workspace', gatewayWorkspacePath]
      );

      logger.info(`Created gateway workspace: ${gatewayWorkspaceName} (${gatewayWorkspaceId}) at ${gatewayWorkspacePath}`);

      return {
        id: gatewayWorkspaceId,
        name: gatewayWorkspaceName,
        description: 'Gateway default workspace',
        path: gatewayWorkspacePath
      };
    } catch (error) {
      // Handle race condition where workspace was created between check and insert
      if (error.code === 'SQLITE_CONSTRAINT') {
        workspace = await this.getWorkspace(gatewayWorkspaceId);
        if (workspace) {
          return workspace;
        }
      }
      logger.error(`Failed to create gateway workspace: ${error.message}`);
      throw error;
    }
  }

  async getWorkspace(idOrName) {
    const workspace = await this.db.get(
      `SELECT * FROM workspaces WHERE (id = ? OR name = ?) AND is_active = 1`,
      [idOrName, idOrName]
    );
    
    if (workspace && workspace.settings) {
      workspace.settings = JSON.parse(workspace.settings);
    }
    
    return workspace;
  }

  async getAnyWorkspace(idOrName) {
    // Get workspace regardless of active status (for force operations)
    const workspace = await this.db.get(
      `SELECT * FROM workspaces WHERE (id = ? OR name = ?)`,
      [idOrName, idOrName]
    );
    
    if (workspace && workspace.settings) {
      workspace.settings = JSON.parse(workspace.settings);
    }
    
    return workspace;
  }

  async getWorkspaceByPath(searchPath) {
    // Normalize the search path
    const normalizedPath = path.resolve(searchPath);
    
    // Get all active workspaces
    const workspaces = await this.db.all(
      `SELECT * FROM workspaces WHERE is_active = 1`
    );
    
    // Find workspace that matches the path or is a parent of the path
    for (const workspace of workspaces) {
      const workspacePath = path.resolve(workspace.path);
      if (normalizedPath === workspacePath || normalizedPath.startsWith(workspacePath + path.sep)) {
        if (workspace.settings) {
          workspace.settings = JSON.parse(workspace.settings);
        }
        return workspace;
      }
    }
    
    return null;
  }

  async getCurrentWorkspace() {
    // Try to find workspace for current working directory
    return await this.getWorkspaceByPath(process.cwd());
  }

  async listWorkspaces(includeInactive = false) {
    const whereClause = includeInactive ? '' : 'WHERE is_active = 1';
    const workspaces = await this.db.all(
      `SELECT * FROM workspaces ${whereClause} ORDER BY created_at DESC`
    );
    
    return workspaces.map(w => {
      if (w.settings) {
        w.settings = JSON.parse(w.settings);
      }
      return w;
    });
  }

  async updateWorkspace(idOrName, updates) {
    const allowedFields = ['name', 'description', 'path', 'settings', 'is_active'];
    const updateFields = [];
    const values = [];
    
    for (const [key, value] of Object.entries(updates)) {
      if (allowedFields.includes(key)) {
        updateFields.push(`${key} = ?`);
        values.push(key === 'settings' ? JSON.stringify(value) : value);
      }
    }
    
    if (updateFields.length === 0) {
      throw new Error('No valid fields to update');
    }
    
    updateFields.push('updated_at = CURRENT_TIMESTAMP');
    values.push(idOrName, idOrName);
    
    const result = await this.db.run(
      `UPDATE workspaces SET ${updateFields.join(', ')} WHERE (id = ? OR name = ?)`,
      values
    );
    
    return result.changes > 0;
  }

  async deleteWorkspace(idOrName, force = false) {
    const workspace = await this.getWorkspace(idOrName);
    if (!workspace) {
      throw new Error(`Workspace ${idOrName} not found`);
    }
    
    // Revoke all tokens associated with this workspace
    const revokeResult = await this.db.run(
      `UPDATE workspace_tokens SET is_revoked = 1 WHERE workspace_id = ? AND is_revoked = 0`,
      [workspace.id]
    );
    
    if (revokeResult.changes > 0) {
      logger.info(`Revoked ${revokeResult.changes} token(s) for workspace: ${workspace.name}`);
    }
    
    if (force) {
      // Hard delete - actually remove from database
      await this.db.run(`DELETE FROM workspaces WHERE id = ?`, [workspace.id]);
      logger.info(`Force deleted workspace: ${workspace.name} (${workspace.id})`);
    } else {
      // Soft delete by default
      await this.db.run(
        `UPDATE workspaces SET is_active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
        [workspace.id]
      );
      logger.info(`Deleted workspace: ${workspace.name} (${workspace.id})`);
    }
    
    return true;
  }

  async getWorkspaceMeta(idOrName, key = null) {
    const workspace = await this.getWorkspace(idOrName);
    if (!workspace) {
      throw new Error(`Workspace ${idOrName} not found`);
    }

    // Handle settings being either a string or an object
    let settings;
    if (typeof workspace.settings === 'string') {
      settings = JSON.parse(workspace.settings || '{}');
    } else if (typeof workspace.settings === 'object') {
      settings = workspace.settings || {};
    } else {
      settings = {};
    }

    const meta = settings.meta || {};

    if (key) {
      return meta[key];
    }
    return meta;
  }

  async setWorkspaceMeta(idOrName, key, value) {
    const workspace = await this.getWorkspace(idOrName);
    if (!workspace) {
      throw new Error(`Workspace ${idOrName} not found`);
    }

    // Ensure workspace.settings is a string, not an object
    let currentSettings;
    if (typeof workspace.settings === 'string') {
      currentSettings = JSON.parse(workspace.settings || '{}');
    } else if (typeof workspace.settings === 'object') {
      // If it's already an object, use it directly
      currentSettings = workspace.settings || {};
    } else {
      currentSettings = {};
    }

    if (!currentSettings.meta) {
      currentSettings.meta = {};
    }
    currentSettings.meta[key] = value;

    // Ensure the settings are properly stringified
    const settingsJson = JSON.stringify(currentSettings);

    // Log for debugging
    logger.debug(`Setting workspace meta - key: ${key}, value type: ${typeof value}, settings length: ${settingsJson.length}`);

    try {
      const result = await this.db.run(
        `UPDATE workspaces SET settings = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
        [settingsJson, workspace.id]
      );

      return result.changes > 0;
    } catch (error) {
      logger.error(`Failed to update workspace settings: ${error.message}`);
      logger.error(`Settings JSON: ${settingsJson.substring(0, 200)}`);
      throw error;
    }
  }

  async deleteWorkspaceMeta(idOrName, key) {
    const workspace = await this.getWorkspace(idOrName);
    if (!workspace) {
      throw new Error(`Workspace ${idOrName} not found`);
    }

    // Handle settings being either a string or an object
    let settings;
    if (typeof workspace.settings === 'string') {
      settings = JSON.parse(workspace.settings || '{}');
    } else if (typeof workspace.settings === 'object') {
      settings = workspace.settings || {};
    } else {
      settings = {};
    }
    if (!settings.meta) {
      return false;
    }

    if (!(key in settings.meta)) {
      return false;
    }

    delete settings.meta[key];

    const result = await this.db.run(
      `UPDATE workspaces SET settings = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
      [JSON.stringify(settings), workspace.id]
    );

    return result.changes > 0;
  }

  async listWorkspaceMeta(idOrName, prefix = null) {
    const workspace = await this.getWorkspace(idOrName);
    if (!workspace) {
      throw new Error(`Workspace ${idOrName} not found`);
    }

    // Handle settings being either a string or an object
    let settings;
    if (typeof workspace.settings === 'string') {
      settings = JSON.parse(workspace.settings || '{}');
    } else if (typeof workspace.settings === 'object') {
      settings = workspace.settings || {};
    } else {
      settings = {};
    }
    const meta = settings.meta || {};

    if (prefix) {
      const filtered = {};
      for (const [key, value] of Object.entries(meta)) {
        if (key.startsWith(prefix)) {
          filtered[key] = value;
        }
      }
      return filtered;
    }

    return meta;
  }

  async forceDeleteByName(name) {
    // This method handles orphaned entries that may not show in the list
    // First delete any associated tokens
    await this.db.run(
      `DELETE FROM workspace_tokens WHERE workspace_id IN (SELECT id FROM workspaces WHERE name = ?)`,
      [name]
    );

    // Delete any chat mappings
    await this.db.run(
      `DELETE FROM chat_workspace_mappings WHERE workspace_id IN (SELECT id FROM workspaces WHERE name = ?)`,
      [name]
    );
    
    // Delete any ws connections
    await this.db.run(
      `DELETE FROM ws_connections WHERE workspace_id IN (SELECT id FROM workspaces WHERE name = ?)`,
      [name]
    );
    
    // Now delete any workspace with this name (active or inactive)
    const result = await this.db.run(
      `DELETE FROM workspaces WHERE name = ?`,
      [name]
    );
    
    if (result.changes > 0) {
      logger.info(`Force deleted workspace by name: ${name} (${result.changes} entries)`);
      return true;
    }
    return false;
  }

  async clearChatAssociations(workspaceIdOrName) {
    // Clear all chat associations for a workspace
    const workspace = await this.getAnyWorkspace(workspaceIdOrName);
    if (!workspace) {
      throw new Error(`Workspace ${workspaceIdOrName} not found`);
    }
    
    const result = await this.db.run(
      `DELETE FROM chat_workspace_mappings WHERE workspace_id = ?`,
      [workspace.id]
    );
    
    logger.info(`Cleared ${result.changes} chat associations for workspace: ${workspace.name}`);
    return result.changes;
  }

  // Token management
  async generateToken(workspaceIdOrName, tokenName = null, type = 'api', permissions = ['read', 'write'], expiresInDays = null) {
    const workspace = await this.getWorkspace(workspaceIdOrName);
    if (!workspace) {
      throw new Error(`Workspace ${workspaceIdOrName} not found`);
    }

    const tokenId = uuidv4();
    const payload = {
      id: tokenId,
      workspace_id: workspace.id,
      workspace_name: workspace.name,
      type,
      permissions
    };

    const options = {
      algorithm: 'HS256'
    };
    let expiresAt = null;
    
    if (expiresInDays) {
      options.expiresIn = `${expiresInDays}d`;
      expiresAt = new Date(Date.now() + expiresInDays * 24 * 60 * 60 * 1000).toISOString();
    }

    const token = jwt.sign(payload, this.jwtSecret, options);
    const tokenHash = await bcrypt.hash(token, 10);

    await this.db.run(
      `INSERT INTO workspace_tokens (id, workspace_id, token_hash, name, type, permissions, expires_at) 
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [tokenId, workspace.id, tokenHash, tokenName, type, JSON.stringify(permissions), expiresAt]
    );

    logger.info(`Generated token for workspace ${workspace.name}: ${tokenId}`);
    
    return {
      id: tokenId,
      token,
      workspace_id: workspace.id,
      workspace_name: workspace.name,
      name: tokenName,
      type,
      permissions,
      expires_at: expiresAt
    };
  }

  async validateToken(token) {
    try {
      // Compact debug logging
      const parts = token.split('.');
      logger.debug(`Token validation: len=${token?.length}, parts=${parts.length}/3, structure=${parts.map(p => p.length).join('-')}`);

      // Check for common issues
      if (token.includes(' ') || token.includes('@')) {
        logger.warn(`Token contains invalid characters: ${token.includes(' ') ? 'space' : ''}${token.includes('@') ? '@' : ''}`);
      }

      // Check signature validity
      if (parts.length === 3 && (parts[2].includes('@') || parts[2].includes(' '))) {
        logger.error(`Invalid signature characters detected`);
      }
      
      // First decode without verification to check the header
      const unverified = jwt.decode(token, { complete: true });
      
      if (!unverified) {
        logger.error('Failed to decode JWT token - jwt.decode returned null');
        logger.error(`Full token that failed: '${token}'`);
        logger.error(`Token char codes at end: ${token.slice(-10).split('').map(c => c.charCodeAt(0)).join(', ')}`);
        return { valid: false, error: 'Invalid token format' };
      }
      
      // Log the algorithm in the token for debugging
      logger.debug(`Token algorithm: ${unverified.header.alg}`);
      
      // Check if the token uses the correct algorithm
      if (unverified.header.alg !== 'HS256') {
        logger.error(`Invalid token algorithm: ${unverified.header.alg}, expected HS256`);
        return { valid: false, error: `Invalid algorithm: ${unverified.header.alg}` };
      }
      
      // Verify JWT signature with explicit algorithm
      const decoded = jwt.verify(token, this.jwtSecret, { algorithms: ['HS256'] });
      
      // Check if token exists and is not revoked
      const tokenRecord = await this.db.get(
        `SELECT * FROM workspace_tokens WHERE id = ? AND is_revoked = 0`,
        [decoded.id]
      );
      
      if (!tokenRecord) {
        return { valid: false, error: 'Token not found or revoked' };
      }
      
      // Check expiration
      if (tokenRecord.expires_at && new Date(tokenRecord.expires_at) < new Date()) {
        return { valid: false, error: 'Token expired' };
      }
      
      // Verify token hash
      const isValid = await bcrypt.compare(token, tokenRecord.token_hash);
      if (!isValid) {
        return { valid: false, error: 'Invalid token hash' };
      }
      
      // Update last used timestamp
      await this.db.run(
        `UPDATE workspace_tokens SET last_used_at = CURRENT_TIMESTAMP WHERE id = ?`,
        [decoded.id]
      );
      
      // Get workspace info
      const workspace = await this.db.get(
        `SELECT * FROM workspaces WHERE id = ? AND is_active = 1`,
        [decoded.workspace_id]
      );
      
      if (!workspace) {
        return { valid: false, error: 'Workspace not found or inactive' };
      }
      
      return {
        valid: true,
        token_id: decoded.id,
        workspace_id: workspace.id,
        workspace_name: workspace.name,
        workspace_path: workspace.path,
        permissions: JSON.parse(tokenRecord.permissions),
        type: tokenRecord.type
      };
    } catch (error) {
      logger.error('Token validation error:', error);
      
      // Provide more specific error messages
      if (error.name === 'JsonWebTokenError') {
        if (error.message === 'invalid algorithm') {
          return { valid: false, error: 'Token uses unsupported algorithm. Please regenerate the token.' };
        } else if (error.message === 'invalid signature') {
          return { valid: false, error: 'Invalid token signature' };
        } else if (error.message === 'jwt malformed') {
          return { valid: false, error: 'Malformed token' };
        }
      } else if (error.name === 'TokenExpiredError') {
        return { valid: false, error: 'Token expired' };
      }
      
      return { valid: false, error: error.message };
    }
  }

  async listTokens(workspaceIdOrName = null) {
    let query = `
      SELECT t.*, w.name as workspace_name 
      FROM workspace_tokens t
      JOIN workspaces w ON t.workspace_id = w.id
      WHERE t.is_revoked = 0
    `;
    
    const params = [];
    if (workspaceIdOrName) {
      const workspace = await this.getWorkspace(workspaceIdOrName);
      if (workspace) {
        query += ` AND t.workspace_id = ?`;
        params.push(workspace.id);
      }
    }
    
    query += ` ORDER BY t.created_at DESC`;
    
    const tokens = await this.db.all(query, params);
    return tokens.map(t => {
      if (t.permissions) {
        t.permissions = JSON.parse(t.permissions);
      }
      // Don't return the actual token hash
      delete t.token_hash;
      return t;
    });
  }

  async revokeToken(tokenIdOrPrefix) {
    // Check if it's a full ID or a prefix
    const tokens = await this.db.all(
      `SELECT id FROM workspace_tokens WHERE id LIKE ? AND is_revoked = 0`,
      [`${tokenIdOrPrefix}%`]
    );
    
    if (tokens.length === 0) {
      logger.info(`No tokens found matching: ${tokenIdOrPrefix}`);
      return false;
    }
    
    if (tokens.length > 1) {
      // If multiple tokens match, check if one is an exact match
      const exactMatch = tokens.find(t => t.id === tokenIdOrPrefix);
      if (exactMatch) {
        const result = await this.db.run(
          `UPDATE workspace_tokens SET is_revoked = 1 WHERE id = ?`,
          [exactMatch.id]
        );
        if (result.changes > 0) {
          logger.info(`Revoked token (exact match): ${exactMatch.id}`);
          return true;
        }
      } else {
        logger.warn(`Multiple tokens found matching prefix: ${tokenIdOrPrefix}`);
        logger.info('Matching tokens:', tokens.map(t => t.id));
        throw new Error(`Ambiguous prefix: ${tokens.length} tokens match '${tokenIdOrPrefix}'. Please provide a longer prefix.`);
      }
    }
    
    // Single token found, revoke it
    const result = await this.db.run(
      `UPDATE workspace_tokens SET is_revoked = 1 WHERE id = ?`,
      [tokens[0].id]
    );
    
    if (result.changes > 0) {
      logger.info(`Revoked token: ${tokens[0].id}`);
      return true;
    }
    return false;
  }

  // Chat-Workspace mapping
  async mapChatToWorkspace(chatId, workspaceIdOrName, exclusive = true) {
    const workspace = await this.getWorkspace(workspaceIdOrName);
    if (!workspace) {
      throw new Error(`Workspace ${workspaceIdOrName} not found`);
    }
    
    // Check if this exact mapping already exists
    const existingMapping = await this.db.get(
      `SELECT * FROM chat_workspace_mappings WHERE chat_id = ? AND workspace_id = ?`,
      [chatId, workspace.id]
    );
    
    if (existingMapping) {
      // Mapping already exists, just reactivate it
      await this.db.run(
        `UPDATE chat_workspace_mappings SET is_active = 1, updated_at = CURRENT_TIMESTAMP WHERE chat_id = ? AND workspace_id = ?`,
        [chatId, workspace.id]
      );
      
      // Deactivate any OTHER mappings for this chat
      await this.db.run(
        `UPDATE chat_workspace_mappings SET is_active = 0 WHERE chat_id = ? AND workspace_id != ?`,
        [chatId, workspace.id]
      );
      
      // If exclusive mode, deactivate any other chats bound to this workspace
      if (exclusive) {
        const otherChats = await this.db.run(
          `UPDATE chat_workspace_mappings SET is_active = 0 WHERE workspace_id = ? AND chat_id != ?`,
          [workspace.id, chatId]
        );
        if (otherChats.changes > 0) {
          logger.info(`Deactivated ${otherChats.changes} other chat mapping(s) for workspace ${workspace.name} (exclusive mode)`);
        }
      }
      
      logger.info(`Reactivated existing mapping for chat ${chatId} to workspace ${workspace.name}`);
      return { 
        id: existingMapping.id, 
        chat_id: chatId, 
        workspace_id: workspace.id, 
        workspace_name: workspace.name, 
        workspace_path: workspace.path 
      };
    }
    
    // No existing mapping, create a new one
    const id = uuidv4();
    
    // First, deactivate any existing mapping for this chat (clean up old bindings)
    const oldMappings = await this.db.run(
      `UPDATE chat_workspace_mappings SET is_active = 0 WHERE chat_id = ?`,
      [chatId]
    );
    if (oldMappings.changes > 0) {
      logger.info(`Deactivated ${oldMappings.changes} old mapping(s) for chat ${chatId}`);
    }
    
    // If exclusive mode, deactivate any other chats bound to this workspace
    if (exclusive) {
      const otherChats = await this.db.run(
        `UPDATE chat_workspace_mappings SET is_active = 0 WHERE workspace_id = ? AND chat_id != ?`,
        [workspace.id, chatId]
      );
      if (otherChats.changes > 0) {
        logger.info(`Deactivated ${otherChats.changes} other chat mapping(s) for workspace ${workspace.name} (exclusive mode)`);
      }
    }
    
    // Create new mapping
    await this.db.run(
      `INSERT INTO chat_workspace_mappings (id, chat_id, workspace_id) VALUES (?, ?, ?)`,
      [id, chatId, workspace.id]
    );
    
    logger.info(`Created new mapping for chat ${chatId} to workspace ${workspace.name}${exclusive ? ' (exclusive)' : ''}`);
    return { id, chat_id: chatId, workspace_id: workspace.id, workspace_name: workspace.name, workspace_path: workspace.path };
  }

  async getWorkspaceForChat(chatId) {
    const mapping = await this.db.get(`
      SELECT m.*, w.name as workspace_name, w.path as workspace_path, w.settings
      FROM chat_workspace_mappings m
      JOIN workspaces w ON m.workspace_id = w.id
      WHERE m.chat_id = ? AND m.is_active = 1 AND w.is_active = 1
      ORDER BY m.created_at DESC
      LIMIT 1
    `, [chatId]);
    
    if (mapping && mapping.settings) {
      mapping.settings = JSON.parse(mapping.settings);
    }
    
    return mapping;
  }

  async getChatWorkspaceMappings() {
    const mappings = await this.db.all(`
      SELECT m.*, w.name as workspace_name, w.path as workspace_path
      FROM chat_workspace_mappings m
      JOIN workspaces w ON m.workspace_id = w.id
      WHERE m.is_active = 1 AND w.is_active = 1
      ORDER BY m.created_at DESC
    `);
    
    return mappings;
  }

  // WebSocket connection tracking
  async registerWSConnection(workspaceId, tokenId = null, clientInfo = null) {
    const connectionId = uuidv4();
    await this.db.run(
      `INSERT INTO ws_connections (id, workspace_id, token_id, client_info) VALUES (?, ?, ?, ?)`,
      [connectionId, workspaceId, tokenId, JSON.stringify(clientInfo)]
    );
    return connectionId;
  }

  async disconnectWSConnection(connectionId) {
    await this.db.run(
      `UPDATE ws_connections SET disconnected_at = CURRENT_TIMESTAMP, is_active = 0 WHERE id = ?`,
      [connectionId]
    );
  }

  async getActiveConnections(workspaceId = null) {
    let query = `
      SELECT c.*, w.name as workspace_name
      FROM ws_connections c
      JOIN workspaces w ON c.workspace_id = w.id
      WHERE c.is_active = 1
    `;
    
    const params = [];
    if (workspaceId) {
      query += ` AND c.workspace_id = ?`;
      params.push(workspaceId);
    }
    
    const connections = await this.db.all(query, params);
    return connections.map(c => {
      if (c.client_info) {
        c.client_info = JSON.parse(c.client_info);
      }
      return c;
    });
  }

  // Migration from existing chat-settings.json
  async migrateFromChatSettings(chatSettingsPath) {
    try {
      const data = await fs.readFile(chatSettingsPath, 'utf8');
      const parsed = JSON.parse(data);
      
      let migrated = 0;
      
      // Migrate workdir to chat mappings
      if (parsed.workdirToChat) {
        for (const [workdirPath, chatId] of Object.entries(parsed.workdirToChat)) {
          // Extract workspace name from path
          const workspaceName = path.basename(workdirPath);
          
          // Check if workspace already exists
          let workspace = await this.getWorkspace(workspaceName);
          
          if (!workspace) {
            // Create new workspace
            workspace = await this.createWorkspace(
              workspaceName,
              workdirPath,
              `Migrated from chat settings`
            );
          }
          
          // Map chat to workspace
          await this.mapChatToWorkspace(chatId, workspace.id);
          migrated++;
        }
      }
      
      logger.info(`Migrated ${migrated} chat-workspace mappings`);
      return migrated;
    } catch (error) {
      logger.error('Failed to migrate from chat settings:', error);
      throw error;
    }
  }

  // Telegram chat management methods
  async getTelegramChat(chatId) {
    const chat = await this.db.get(
      `SELECT * FROM telegram_chats WHERE chat_id = ?`,
      [chatId]
    );
    
    if (chat && chat.metadata) {
      chat.metadata = JSON.parse(chat.metadata);
    }
    
    return chat;
  }

  async registerTelegramChat(chatInfo) {
    const existingChat = await this.getTelegramChat(chatInfo.chat_id);
    
    if (existingChat) {
      // Update existing chat info
      await this.db.run(
        `UPDATE telegram_chats SET 
          chat_type = ?, chat_title = ?, username = ?, 
          first_name = ?, last_name = ?, last_interaction = CURRENT_TIMESTAMP,
          updated_at = CURRENT_TIMESTAMP
        WHERE chat_id = ?`,
        [
          chatInfo.chat_type || existingChat.chat_type,
          chatInfo.chat_title || existingChat.chat_title,
          chatInfo.username || existingChat.username,
          chatInfo.first_name || existingChat.first_name,
          chatInfo.last_name || existingChat.last_name,
          chatInfo.chat_id
        ]
      );
      return await this.getTelegramChat(chatInfo.chat_id);
    }
    
    // Create new chat record
    const id = uuidv4();
    await this.db.run(
      `INSERT INTO telegram_chats 
        (id, chat_id, chat_type, chat_title, username, first_name, last_name, metadata)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        id,
        chatInfo.chat_id,
        chatInfo.chat_type || 'private',
        chatInfo.chat_title || null,
        chatInfo.username || null,
        chatInfo.first_name || null,
        chatInfo.last_name || null,
        JSON.stringify(chatInfo.metadata || {})
      ]
    );
    
    logger.info(`Registered new Telegram chat: ${chatInfo.chat_id} (${chatInfo.chat_type})`);
    return await this.getTelegramChat(chatInfo.chat_id);
  }

  async authorizeTelegramChat(chatId, workspaceIdOrName, tokenId = null, authorizedBy = null) {
    const chat = await this.getTelegramChat(chatId);
    if (!chat) {
      throw new Error(`Telegram chat ${chatId} not found`);
    }
    
    const workspace = await this.getWorkspace(workspaceIdOrName);
    if (!workspace) {
      throw new Error(`Workspace ${workspaceIdOrName} not found`);
    }
    
    await this.db.run(
      `UPDATE telegram_chats SET 
        workspace_id = ?, token_id = ?, is_authorized = 1,
        authorized_by = ?, authorized_at = CURRENT_TIMESTAMP,
        updated_at = CURRENT_TIMESTAMP
      WHERE chat_id = ?`,
      [workspace.id, tokenId, authorizedBy, chatId]
    );
    
    logger.info(`Authorized Telegram chat ${chatId} for workspace ${workspace.name}`);
    return true;
  }

  async revokeTelegramChatAuth(chatId) {
    const result = await this.db.run(
      `UPDATE telegram_chats SET 
        is_authorized = 0, workspace_id = NULL, token_id = NULL,
        updated_at = CURRENT_TIMESTAMP
      WHERE chat_id = ?`,
      [chatId]
    );
    
    if (result.changes > 0) {
      logger.info(`Revoked authorization for Telegram chat ${chatId}`);
      return true;
    }
    return false;
  }

  async isTelegramChatAuthorized(chatId) {
    const chat = await this.db.get(
      `SELECT tc.*, w.name as workspace_name, w.path as workspace_path
      FROM telegram_chats tc
      LEFT JOIN workspaces w ON tc.workspace_id = w.id
      WHERE tc.chat_id = ? AND tc.is_authorized = 1`,
      [chatId]
    );
    
    if (!chat) {
      return null;
    }
    
    // Update last interaction
    await this.db.run(
      `UPDATE telegram_chats SET last_interaction = CURRENT_TIMESTAMP WHERE chat_id = ?`,
      [chatId]
    );
    
    return {
      authorized: true,
      chat_id: chat.chat_id,
      workspace_id: chat.workspace_id,
      workspace_name: chat.workspace_name,
      workspace_path: chat.workspace_path,
      token_id: chat.token_id
    };
  }

  async addAllowedTelegramUser(userId, userInfo = {}) {
    const existingUser = await this.db.get(
      `SELECT * FROM telegram_allowed_users WHERE user_id = ?`,
      [userId]
    );
    
    if (existingUser) {
      // Update existing user
      await this.db.run(
        `UPDATE telegram_allowed_users SET 
          username = ?, first_name = ?, last_name = ?,
          updated_at = CURRENT_TIMESTAMP
        WHERE user_id = ?`,
        [
          userInfo.username || existingUser.username,
          userInfo.first_name || existingUser.first_name,
          userInfo.last_name || existingUser.last_name,
          userId
        ]
      );
      logger.info(`Updated allowed Telegram user: ${userId}`);
      return true;
    }
    
    // Add new allowed user
    const id = uuidv4();
    await this.db.run(
      `INSERT INTO telegram_allowed_users 
        (id, user_id, username, first_name, last_name, is_admin, can_authorize_chats)
        VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        id,
        userId,
        userInfo.username || null,
        userInfo.first_name || null,
        userInfo.last_name || null,
        userInfo.is_admin || false,
        userInfo.can_authorize_chats || false
      ]
    );
    
    logger.info(`Added allowed Telegram user: ${userId}`);
    return true;
  }

  async removeAllowedTelegramUser(userId) {
    const result = await this.db.run(
      `DELETE FROM telegram_allowed_users WHERE user_id = ?`,
      [userId]
    );
    
    if (result.changes > 0) {
      logger.info(`Removed allowed Telegram user: ${userId}`);
      return true;
    }
    return false;
  }

  async isAllowedTelegramUser(userId) {
    const user = await this.db.get(
      `SELECT * FROM telegram_allowed_users WHERE user_id = ?`,
      [userId]
    );
    
    return user !== undefined;
  }

  async getAllowedTelegramUsers() {
    return await this.db.all(
      `SELECT * FROM telegram_allowed_users ORDER BY created_at DESC`
    );
  }

  async getAuthorizedTelegramChats() {
    return await this.db.all(
      `SELECT tc.*, w.name as workspace_name
      FROM telegram_chats tc
      LEFT JOIN workspaces w ON tc.workspace_id = w.id
      WHERE tc.is_authorized = 1
      ORDER BY tc.last_interaction DESC`
    );
  }

  async connectTelegramChatWithToken(chatId, token) {
    // Debug logging
    logger.info(`Attempting to connect Telegram chat ${chatId} with token length: ${token?.length}`);
    logger.debug(`Token first 50 chars: ${token?.substring(0, 50)}`);
    
    // Validate the token first
    const validation = await this.validateToken(token);
    if (!validation.valid) {
      throw new Error(`Invalid token: ${validation.error}`);
    }
    
    // Register the chat if needed
    let chat = await this.getTelegramChat(chatId);
    if (!chat) {
      await this.registerTelegramChat({
        chat_id: chatId,
        chat_type: 'private'
      });
      chat = await this.getTelegramChat(chatId);
    }
    
    // Authorize the chat with the workspace from the token
    await this.authorizeTelegramChat(
      chatId,
      validation.workspace_id,
      validation.token_id,
      'token'
    );
    
    // Update the token name to include the Telegram chat info
    try {
      let updatedName = `Telegram: `;
      if (chat.chat_title) {
        updatedName += chat.chat_title;
      } else if (chat.username) {
        updatedName += `@${chat.username}`;
      } else if (chat.first_name || chat.last_name) {
        updatedName += [chat.first_name, chat.last_name].filter(n => n).join(' ');
      } else {
        updatedName += `Chat ${chatId}`;
      }
      
      // Update the token name in the database
      await this.db.run(
        `UPDATE workspace_tokens SET name = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
        [updatedName, validation.token_id]
      );
      
      logger.info(`Updated token name to: ${updatedName}`);
    } catch (error) {
      logger.warn(`Failed to update token name: ${error.message}`);
      // Don't fail the connection if we can't update the name
    }
    
    logger.info(`Connected Telegram chat ${chatId} to workspace ${validation.workspace_name} via token`);
    
    return {
      success: true,
      workspace_name: validation.workspace_name,
      workspace_path: validation.workspace_path
    };
  }

  // Get workspace for Telegram chat
  async getWorkspaceForTelegramChat(chatId) {
    try {
      // First check if the Telegram chat is authorized
      const chat = await this.db.get(
        `SELECT * FROM telegram_chats WHERE chat_id = ? AND is_authorized = 1`,
        [chatId]
      );

      if (!chat) {
        logger.debug(`No authorized Telegram chat found for chatId: ${chatId}`);
        return null;
      }

      if (!chat.workspace_id) {
        logger.debug(`Telegram chat ${chatId} has no workspace_id set`);
        return null;
      }

      // Get the workspace
      const workspace = await this.db.get(
        `SELECT * FROM workspaces WHERE id = ? AND is_active = 1`,
        [chat.workspace_id]
      );

      if (!workspace) {
        logger.warn(`Workspace ${chat.workspace_id} not found or not active for Telegram chat ${chatId}`);
        return null;
      }

      if (workspace && workspace.settings) {
        workspace.settings = JSON.parse(workspace.settings || '{}');
      }

      logger.debug(`Found workspace ${workspace.name} for Telegram chat ${chatId}`);
      return workspace;
    } catch (error) {
      logger.error(`Failed to get workspace for Telegram chat: ${error.message}`);
      return null;
    }
  }

  // Plan management methods
  async createPlan(workspaceId, planData) {
    try {
      const id = uuidv4();

      // Ensure workspace exists
      const workspace = await this.getWorkspace(workspaceId);
      if (!workspace) {
        throw new Error(`Workspace not found: ${workspaceId}`);
      }

      // Generate plan ID using the same style as task IDs
      const planId = planData.planId || generatePlanId(workspace.name);

      const normalizedSteps = normalizePlanSteps(planData.steps || []);
      const planDescription = planData.description ?? stepsToPlanDescription(normalizedSteps);
      const firstStep = normalizedSteps[0] || null;
      const defaultTitle = firstStep ? (firstStep.description || firstStep.prompt || firstStep.raw || 'Untitled Plan') : 'Untitled Plan';

      const result = await this.db.run(
        `INSERT INTO workspace_plans (id, workspace_id, plan_id, title, description, steps, created_by, metadata)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          id,
          workspace.id,
          planId,
          planData.title || defaultTitle.substring(0, 50),
          planDescription,
          JSON.stringify(normalizedSteps),
          planData.createdBy || 'system',
          JSON.stringify(planData.metadata || {})
        ]
      );

      if (result.changes > 0) {
        return { id, planId, workspaceId: workspace.id };
      }

      throw new Error('Failed to create plan');
    } catch (error) {
      logger.error(`Failed to create plan: ${error.message}`);
      throw error;
    }
  }

  async getPlan(workspaceId, planId) {
    try {
      // First try to get workspace
      const workspace = await this.getWorkspace(workspaceId);
      if (!workspace) {
        return null;
      }

      const plan = await this.db.get(
        `SELECT * FROM workspace_plans WHERE workspace_id = ? AND plan_id = ?`,
        [workspace.id, planId]
      );

      if (plan) {
        try {
          const parsedSteps = JSON.parse(plan.steps || '[]');
          plan.steps = normalizePlanSteps(parsedSteps);
        } catch (e) {
          logger.error(`Failed to parse steps for plan ${planId}: ${e.message}`);
          plan.steps = [];
        }

        try {
          plan.metadata = JSON.parse(plan.metadata || '{}');
        } catch (e) {
          logger.error(`Failed to parse metadata for plan ${planId}: ${e.message}`);
          plan.metadata = {};
        }
      }

      return plan;
    } catch (error) {
      logger.error(`Failed to get plan: ${error.message}`);
      return null;
    }
  }

  async getNextPlan(workspaceId) {
    try {
      // First try to get workspace
      const workspace = await this.getWorkspace(workspaceId);
      if (!workspace) {
        return null;
      }

      // Get the oldest pending plan (FIFO - first submitted, first executed)
      const plan = await this.db.get(
        `SELECT * FROM workspace_plans
         WHERE workspace_id = ? AND status = 'pending'
         ORDER BY created_at ASC
         LIMIT 1`,
        [workspace.id]
      );

      if (plan) {
        try {
          const parsedSteps = JSON.parse(plan.steps || '[]');
          plan.steps = normalizePlanSteps(parsedSteps);
        } catch (e) {
          logger.error(`Failed to parse steps for plan ${plan.plan_id}: ${e.message}`);
          plan.steps = [];
        }

        try {
          plan.metadata = JSON.parse(plan.metadata || '{}');
        } catch (e) {
          logger.error(`Failed to parse metadata for plan ${plan.plan_id}: ${e.message}`);
          plan.metadata = {};
        }
      }

      return plan;
    } catch (error) {
      logger.error(`Failed to get next plan: ${error.message}`);
      return null;
    }
  }

  async listPlans(workspaceId, status = null) {
    try {
      const workspace = await this.getWorkspace(workspaceId);
      if (!workspace) {
        return [];
      }

      let query = `SELECT * FROM workspace_plans WHERE workspace_id = ?`;
      const params = [workspace.id];

      if (status) {
        query += ` AND status = ?`;
        params.push(status);
      }

      query += ` ORDER BY created_at ASC`;

      const plans = await this.db.all(query, params);

      // Parse JSON fields
      for (const plan of plans) {
        try {
          const parsedSteps = JSON.parse(plan.steps || '[]');
          plan.steps = normalizePlanSteps(parsedSteps);
        } catch (e) {
          logger.error(`Failed to parse steps for plan ${plan.id}: ${e.message}`);
          plan.steps = [];
        }
        try {
          plan.metadata = JSON.parse(plan.metadata || '{}');
        } catch (e) {
          logger.error(`Failed to parse metadata for plan ${plan.id}: ${e.message}`);
          plan.metadata = {};
        }
      }

      return plans;
    } catch (error) {
      logger.error(`Failed to list plans: ${error.message}`);
      return [];
    }
  }

  async updatePlanStatus(workspaceId, planId, status, currentStep = null) {
    try {
      const workspace = await this.getWorkspace(workspaceId);
      if (!workspace) {
        throw new Error(`Workspace not found: ${workspaceId}`);
      }

      let query = `UPDATE workspace_plans SET status = ?, updated_at = CURRENT_TIMESTAMP`;
      const params = [status];

      if (currentStep !== null) {
        query += `, current_step = ?`;
        params.push(currentStep);
      }

      if (status === 'completed') {
        query += `, completed_at = CURRENT_TIMESTAMP`;
      }

      query += ` WHERE workspace_id = ? AND plan_id = ?`;
      params.push(workspace.id, planId);

      const result = await this.db.run(query, params);

      return result.changes > 0;
    } catch (error) {
      logger.error(`Failed to update plan status: ${error.message}`);
      return false;
    }
  }

  async deletePlan(workspaceId, planId) {
    try {
      const workspace = await this.getWorkspace(workspaceId);
      if (!workspace) {
        return false;
      }

      const result = await this.db.run(
        `DELETE FROM workspace_plans WHERE workspace_id = ? AND plan_id = ?`,
        [workspace.id, planId]
      );

      return result.changes > 0;
    } catch (error) {
      logger.error(`Failed to delete plan: ${error.message}`);
      return false;
    }
  }

  async updatePlan(workspaceId, planId, updates) {
    try {
      const workspace = await this.getWorkspace(workspaceId);
      if (!workspace) {
        throw new Error(`Workspace not found: ${workspaceId}`);
      }

      // Get current plan
      const plan = await this.getPlan(workspaceId, planId);
      if (!plan) {
        throw new Error(`Plan not found: ${planId}`);
      }

      // Normalize incoming steps if provided
      let normalizedSteps = null;
      if (updates.steps !== undefined) {
        normalizedSteps = normalizePlanSteps(updates.steps);
      }

      let nextDescription = updates.description;
      if (normalizedSteps && nextDescription === undefined) {
        nextDescription = stepsToPlanDescription(normalizedSteps);
      }

      // Build update query
      const updateFields = [];
      const params = [];

      if (updates.title !== undefined) {
        updateFields.push('title = ?');
        params.push(updates.title);
      }

      if (nextDescription !== undefined) {
        updateFields.push('description = ?');
        params.push(nextDescription);
      }

      if (normalizedSteps !== null) {
        updateFields.push('steps = ?');
        params.push(JSON.stringify(normalizedSteps));

        // Reset current_step if steps changed and plan is in progress
        if (plan.status === 'in_progress') {
          updateFields.push('current_step = ?');
          params.push(0);
          updateFields.push('status = ?');
          params.push('pending');
        }
      }

      if (updateFields.length === 0) {
        return { success: false, message: 'No updates provided' };
      }

      updateFields.push('updated_at = CURRENT_TIMESTAMP');

      const query = `UPDATE workspace_plans SET ${updateFields.join(', ')} WHERE workspace_id = ? AND plan_id = ?`;
      params.push(workspace.id, planId);

      const result = await this.db.run(query, params);

      if (result.changes > 0) {
        return { success: true, message: 'Plan updated successfully' };
      } else {
        return { success: false, message: 'Failed to update plan' };
      }
    } catch (error) {
      logger.error(`Failed to update plan: ${error.message}`);
      return { success: false, message: error.message };
    }
  }

  async updatePlanMetadata(workspaceId, planId, metadata) {
    try {
      const workspace = await this.getWorkspace(workspaceId);
      if (!workspace) {
        throw new Error(`Workspace not found: ${workspaceId}`);
      }

      const result = await this.db.run(
        `UPDATE workspace_plans SET metadata = ?, updated_at = CURRENT_TIMESTAMP WHERE workspace_id = ? AND plan_id = ?`,
        [JSON.stringify(metadata), workspace.id, planId]
      );

      return result.changes > 0;
    } catch (error) {
      logger.error(`Failed to update plan metadata: ${error.message}`);
      return false;
    }
  }

  async updatePlanStep(workspaceId, planId, stepIndex, updates) {
    try {
      const workspace = await this.getWorkspace(workspaceId);
      if (!workspace) {
        throw new Error(`Workspace not found: ${workspaceId}`);
      }

      // Get current plan
      const plan = await this.getPlan(workspaceId, planId);
      if (!plan) {
        throw new Error(`Plan not found: ${planId}`);
      }

      // Update the specific step
      const steps = normalizePlanSteps(plan.steps || []);
      if (stepIndex >= 0 && stepIndex < steps.length) {
        let stepData = normalizePlanStep(steps[stepIndex], { force: true });
        stepData = normalizePlanStep({ ...stepData, ...updates }, { force: true });
        steps[stepIndex] = stepData;

        const result = await this.db.run(
          `UPDATE workspace_plans SET steps = ?, updated_at = CURRENT_TIMESTAMP WHERE workspace_id = ? AND plan_id = ?`,
          [JSON.stringify(steps), workspace.id, planId]
        );

        return result.changes > 0;
      }

      return false;
    } catch (error) {
      logger.error(`Failed to update plan step: ${error.message}`);
      return false;
    }
  }

  async checkPlanStepsComplete(workspaceId, planId) {
    try {
      const plan = await this.getPlan(workspaceId, planId);
      if (!plan) {
        return false;
      }

      const steps = normalizePlanSteps(plan.steps || []);

      // Check if all steps have been completed
      for (const step of steps) {
        if (!step.status || step.status !== 'completed') {
          return false;
        }
      }

      return true;
    } catch (error) {
      logger.error(`Failed to check plan steps: ${error.message}`);
      return false;
    }
  }

  async resetPlans(workspaceId, status = null) {
    try {
      const workspace = await this.getWorkspace(workspaceId);
      if (!workspace) {
        return { success: false, count: 0, message: 'Workspace not found' };
      }

      let query = `DELETE FROM workspace_plans WHERE workspace_id = ?`;
      const params = [workspace.id];

      // If status specified, only delete plans with that status
      if (status) {
        query += ` AND status = ?`;
        params.push(status);
      }

      const result = await this.db.run(query, params);

      return {
        success: true,
        count: result.changes,
        message: `Cleared ${result.changes} plan(s)${status ? ` with status: ${status}` : ''}`
      };
    } catch (error) {
      logger.error(`Failed to reset plans: ${error.message}`);
      return { success: false, count: 0, message: error.message };
    }
  }

  async getPlanSummary(workspaceId) {
    try {
      const workspace = await this.getWorkspace(workspaceId);
      if (!workspace) {
        return null;
      }

      // Get count of plans by status
      const query = `
        SELECT
          status,
          COUNT(*) as count,
          MIN(created_at) as oldest,
          MAX(updated_at) as latest
        FROM workspace_plans
        WHERE workspace_id = ?
        GROUP BY status
      `;

      const statusCounts = await this.db.all(query, [workspace.id]);

      // Get total steps and completed steps across all plans
      const progressQuery = `
        SELECT
          SUM(JSON_ARRAY_LENGTH(steps)) as total_steps,
          SUM(CASE
            WHEN status = 'completed' THEN JSON_ARRAY_LENGTH(steps)
            WHEN status IN ('in_progress', 'paused') THEN COALESCE(current_step, 0)
            ELSE 0
          END) as completed_steps
        FROM workspace_plans
        WHERE workspace_id = ?
      `;

      const progress = await this.db.get(progressQuery, [workspace.id]);

      return {
        counts: statusCounts.reduce((acc, row) => {
          acc[row.status] = row.count;
          return acc;
        }, {}),
        totalSteps: progress?.total_steps || 0,
        completedSteps: progress?.completed_steps || 0,
        workspaceName: workspace.name
      };
    } catch (error) {
      logger.error(`Failed to get plan summary: ${error.message}`);
      return null;
    }
  }

  async close() {
    if (this.db) {
      await this.db.close();
    }
  }

  // Yolo mode management methods
  async setYoloModeActive(workspaceId, active, statusMessageId = null, totalPlans = 0, scheduledTime = null) {
    try {
      const now = new Date().toISOString();
      await this.db.run(
        `UPDATE workspaces SET
          yolo_mode_active = ?,
          yolo_status_message_id = ?,
          yolo_start_time = ?,
          yolo_plans_total = ?,
          yolo_plans_completed = 0,
          yolo_message_version = 0,
          yolo_current_plan = NULL,
          yolo_scheduled_time = ?,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = ?`,
        [active ? 1 : 0, statusMessageId, active ? now : null, totalPlans, scheduledTime, workspaceId]
      );
      return true;
    } catch (error) {
      logger.error('Failed to set yolo mode status:', error);
      throw error;
    }
  }

  async updateYoloProgress(workspaceId, currentPlan, plansCompleted = null) {
    try {
      const updates = ['yolo_current_plan = ?', 'updated_at = CURRENT_TIMESTAMP'];
      const params = [currentPlan];

      if (plansCompleted !== null) {
        updates.push('yolo_plans_completed = ?');
        params.push(plansCompleted);
      }

      params.push(workspaceId);

      await this.db.run(
        `UPDATE workspaces SET ${updates.join(', ')} WHERE id = ?`,
        params
      );
      return true;
    } catch (error) {
      logger.error('Failed to update yolo progress:', error);
      throw error;
    }
  }

  async getYoloStatus(workspaceId) {
    try {
      const workspace = await this.db.get(
        `SELECT yolo_mode_active, yolo_status_message_id, yolo_start_time,
          yolo_plans_total, yolo_plans_completed, yolo_current_plan, yolo_message_version
        FROM workspaces WHERE id = ?`,
        [workspaceId]
      );

      if (!workspace) return null;

      return {
        active: !!workspace.yolo_mode_active,
        statusMessageId: workspace.yolo_status_message_id,
        startTime: workspace.yolo_start_time,
        plansTotal: workspace.yolo_plans_total || 0,
        plansCompleted: workspace.yolo_plans_completed || 0,
        currentPlan: workspace.yolo_current_plan,
        messageVersion: workspace.yolo_message_version || 0
      };
    } catch (error) {
      logger.error('Failed to get yolo status:', error);
      throw error;
    }
  }

  async clearYoloMode(workspaceId) {
    try {
      await this.db.run(
        `UPDATE workspaces SET
          yolo_mode_active = 0,
          yolo_status_message_id = NULL,
          yolo_start_time = NULL,
          yolo_plans_total = 0,
          yolo_plans_completed = 0,
          yolo_current_plan = NULL,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = ?`,
        [workspaceId]
      );
      return true;
    } catch (error) {
      logger.error('Failed to clear yolo mode:', error);
      throw error;
    }
  }

  async updateYoloMessageVersion(workspaceId, version) {
    try {
      await this.db.run(
        `UPDATE workspaces SET
          yolo_message_version = ?,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = ?`,
        [version, workspaceId]
      );
      return true;
    } catch (error) {
      logger.error('Failed to update yolo message version:', error);
      throw error;
    }
  }

  async updateYoloStatusMessageId(workspaceId, messageId) {
    try {
      await this.db.run(
        `UPDATE workspaces SET
          yolo_status_message_id = ?,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = ?`,
        [messageId, workspaceId]
      );
      return true;
    } catch (error) {
      logger.error('Failed to update yolo status message ID:', error);
      throw error;
    }
  }

  async clearYoloProtection(workspaceId) {
    try {
      // Only clear the protection mode, keep yolo running
      await this.db.run(
        `UPDATE workspaces SET
          yolo_mode_active = 0,
          yolo_scheduled_time = NULL,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = ?`,
        [workspaceId]
      );
      return true;
    } catch (error) {
      logger.error('Failed to clear yolo protection:', error);
      return false;
    }
  }

  // Task logging methods
  async logTaskEvent(eventData) {
    const {
      task_id = null,
      workspace_id = null,
      event_type,
      chat_id = null,
      source = null,
      command = null,
      message = null,
      metadata = {}
    } = eventData;

    const id = uuidv4();

    try {
      await this.db.run(
        `INSERT INTO task_logs
          (id, task_id, workspace_id, event_type, chat_id, source, command, message, metadata)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          id,
          task_id,
          workspace_id,
          event_type,
          chat_id,
          source,
          command,
          message,
          JSON.stringify(metadata)
        ]
      );

      logger.debug(`Logged task event: ${event_type} for task ${task_id || 'webhook'}`);
      return id;
    } catch (error) {
      logger.error('Failed to log task event:', error);
      return null;
    }
  }

  async logTelegramWebhookReceived(chatId, message, metadata = {}) {
    return this.logTaskEvent({
      event_type: 'telegram_webhook_received',
      chat_id: `telegram:${chatId}`,
      message: message?.text || message?.caption || 'No text',
      metadata: {
        ...metadata,
        message_id: message?.message_id,
        user_id: message?.from?.id,
        username: message?.from?.username,
        has_photo: message?.photo ? true : false,
        has_document: message?.document ? true : false
      }
    });
  }

  async logTaskCreated(task, workspaceId = null) {
    return this.logTaskEvent({
      task_id: task.id,
      workspace_id: workspaceId,
      event_type: 'task_created',
      chat_id: task.chatId,
      source: task.source,
      command: task.command,
      message: task.name,
      metadata: {
        cwd: task.cwd,
        priority: task.priority
      }
    });
  }

  async getTaskLogs(options = {}) {
    const {
      task_id = null,
      workspace_id = null,
      chat_id = null,
      event_type = null,
      limit = 100,
      offset = 0
    } = options;

    let query = 'SELECT * FROM task_logs WHERE 1=1';
    const params = [];

    if (task_id) {
      query += ' AND task_id = ?';
      params.push(task_id);
    }

    if (workspace_id) {
      query += ' AND workspace_id = ?';
      params.push(workspace_id);
    }

    if (chat_id) {
      query += ' AND chat_id = ?';
      params.push(chat_id);
    }

    if (event_type) {
      query += ' AND event_type = ?';
      params.push(event_type);
    }

    query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    params.push(limit, offset);

    const logs = await this.db.all(query, params);

    // Parse JSON metadata
    return logs.map(log => ({
      ...log,
      metadata: log.metadata ? JSON.parse(log.metadata) : {}
    }));
  }
}

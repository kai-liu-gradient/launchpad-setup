import { logger } from './logger.js';

/**
 * Display mode constants
 */
export const DISPLAY_MODES = {
  FULL: 'full',
  SIMPLE: 'simple',
  DEFAULT: 'default'  // Alias for full
};

export const VALID_DISPLAY_MODES = ['full', 'simple', 'default'];

/**
 * Resolve a display mode value to its actual mode (handles 'default' alias)
 * @param {string} mode
 * @returns {string} Resolved mode ('full' or 'simple')
 */
export function resolveDisplayMode(mode) {
  if (mode === 'default' || mode === 'full') return 'full';
  if (mode === 'simple') return 'simple';
  return 'full';
}

/**
 * DisplayModeManager - manages global display mode preference
 *
 * Priority chain: global setting > CHAT_DISPLAY_MODE env var > 'full'
 */
export class DisplayModeManager {
  constructor(chatSettings) {
    this.chatSettings = chatSettings;
  }

  /**
   * Get the effective display mode (global)
   * Priority: global setting > CHAT_DISPLAY_MODE env var > 'full'
   * @param {string} [chatId] - ignored, kept for API compat
   * @returns {string} Resolved display mode ('full' or 'simple')
   */
  getDisplayMode(chatId) {
    // 1. Check global setting
    if (this.chatSettings) {
      const mode = this.chatSettings.getDisplayMode();
      if (mode) {
        return resolveDisplayMode(mode);
      }
    }

    // 2. Check environment variable
    const envMode = process.env.CHAT_DISPLAY_MODE;
    if (envMode && VALID_DISPLAY_MODES.includes(envMode)) {
      return resolveDisplayMode(envMode);
    }

    // 3. Default to full
    return 'full';
  }

  /**
   * Set global display mode
   * @param {string} chatId - ignored, kept for API compat
   * @param {string} mode - 'full', 'simple', or 'default'
   * @returns {Promise<{previousMode: string, newMode: string}>}
   */
  async setDisplayMode(chatId, mode) {
    if (!VALID_DISPLAY_MODES.includes(mode)) {
      throw new Error(`Invalid display mode: ${mode}. Valid modes: ${VALID_DISPLAY_MODES.join(', ')}`);
    }

    const previousMode = this.getDisplayMode();
    const resolvedMode = resolveDisplayMode(mode);

    if (this.chatSettings) {
      await this.chatSettings.setDisplayMode(null, resolvedMode);
    }

    logger.info(`[DISPLAY-MODE] Global: ${previousMode} → ${resolvedMode}`);

    return { previousMode, newMode: resolvedMode };
  }

  /**
   * Get available modes with descriptions
   * @returns {Array<{id: string, name: string, description: string}>}
   */
  static getAvailableModes() {
    return [
      {
        id: 'full',
        name: 'Full',
        description: 'All output included: headers, git status, cost/tokens, footer'
      },
      {
        id: 'simple',
        name: 'Simple',
        description: 'Streamlined: task output + brief completion line only'
      },
      {
        id: 'default',
        name: 'Default',
        description: 'Alias for full mode'
      }
    ];
  }
}

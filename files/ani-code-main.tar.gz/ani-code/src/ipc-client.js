import { createConnection } from 'net';
import { readFileSync, existsSync } from 'fs';
import { join, dirname } from 'path';
import { EventEmitter } from 'events';
import { fileURLToPath } from 'url';

export class IPCClient extends EventEmitter {
  constructor() {
    super();
    // Use the directory where this script is located as base directory
    const __filename = fileURLToPath(import.meta.url);
    const __dirname = dirname(__filename);
    const baseDir = join(__dirname, '..');
    this.portFile = join(baseDir, '.ani-code-ipc.port');
    this.socket = null;
    this.messageId = 0;
    this.pendingMessages = new Map();

    // Get CLI version
    try {
      const packagePath = join(baseDir, 'package.json');
      const packageJson = JSON.parse(readFileSync(packagePath, 'utf8'));
      this.cliVersion = packageJson.version;
    } catch {
      this.cliVersion = 'unknown';
    }
  }

  async connect() {
    try {
      if (!existsSync(this.portFile)) {
        throw new Error('Daemon IPC port file not found');
      }

      const port = parseInt(readFileSync(this.portFile, 'utf8'));
      
      return new Promise((resolve, reject) => {
        this.socket = createConnection(port, '127.0.0.1', () => {
          this.setupSocketHandlers();
          resolve();
        });

        this.socket.on('error', (error) => {
          reject(new Error(`Failed to connect to daemon: ${error.message}`));
        });

        this.socket.setTimeout(5000, () => {
          reject(new Error('Connection timeout'));
        });
      });
    } catch (error) {
      throw new Error(`Failed to connect to daemon: ${error.message}`);
    }
  }

  setupSocketHandlers() {
    let buffer = '';

    this.socket.on('data', (data) => {
      buffer += data.toString();

      // Process complete messages (separated by newlines)
      const messages = buffer.split('\n');
      buffer = messages.pop(); // Keep incomplete message in buffer

      for (const messageStr of messages) {
        if (messageStr.trim()) {
          try {
            const message = JSON.parse(messageStr);
            this.handleMessage(message);
          } catch (error) {
            console.error('Failed to parse IPC message:', error);
          }
        }
      }
    });

    this.socket.on('close', () => {
      this.emit('disconnected');
    });

    this.socket.on('error', (error) => {
      this.emit('error', error);
    });
  }

  handleMessage(message) {
    if (message.id && this.pendingMessages.has(message.id)) {
      const { resolve, reject, timeoutId } = this.pendingMessages.get(message.id);
      
      // Clear the timeout
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
      
      this.pendingMessages.delete(message.id);
      
      if (message.success) {
        resolve(message.data);
      } else {
        reject(new Error(message.error));
      }
    } else {
      // Handle broadcast messages (like task output)
      this.emit('message', message);
    }
  }

  async sendMessage(type, data = {}, timeout = 10000) {
    if (!this.socket) {
      throw new Error('Not connected to daemon');
    }

    const id = ++this.messageId;
    // Include CLI version in all messages
    const message = { type, id, data, cliVersion: this.cliVersion };

    return new Promise((resolve, reject) => {
      // Set timeout for response (default 10s, but can be overridden)
      const timeoutId = setTimeout(() => {
        if (this.pendingMessages.has(id)) {
          this.pendingMessages.delete(id);
          if (process.env.DEBUG_IPC || process.env.VERBOSE) {
            console.error(`[IPC] Request timeout for message type: ${type}, id: ${id} after ${timeout}ms`);
          }
          reject(new Error(`Request timeout after ${timeout}ms`));
        }
      }, timeout);
      
      this.pendingMessages.set(id, { resolve, reject, timeoutId });
      
      // Log IPC message sending for debugging
      if (process.env.DEBUG_IPC) {
        console.log(`[IPC] Sending message: ${type} (id: ${id})`);
      }
      
      this.socket.write(JSON.stringify(message) + '\n');
    });
  }

  async addTask(name, command, options = {}) {
    return this.sendMessage('add_task', { name, command, options });
  }

  async cancelTask(taskId) {
    return this.sendMessage('cancel_task', { taskId });
  }

  async getStatus() {
    return this.sendMessage('get_status');
  }
  
  async getStatusWithProcessInfo() {
    return this.sendMessage('get_status_with_process_info');
  }

  async getTask(taskId) {
    // Use 30 second timeout for task fetching (as we might be polling frequently)
    return this.sendMessage('get_task', { taskId }, 30000);
  }

  async getTaskByIndex(index) {
    return this.sendMessage('get_task_by_index', { index }, 30000);
  }

  async watchTask(taskId, callback) {
    // Set up output handler
    const messageHandler = (message) => {
      if (message.type === 'task_output' && message.data.taskId === taskId) {
        callback(message.data);
      }
    };

    this.on('message', messageHandler);

    // Start watching
    await this.sendMessage('watch_task', { taskId });

    // Return cleanup function
    return () => {
      this.off('message', messageHandler);
    };
  }

  disconnect() {
    // Clear any pending timeouts
    for (const [id, { timeoutId }] of this.pendingMessages) {
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
    }
    
    if (this.socket) {
      this.socket.end();
      this.socket = null;
    }
    this.pendingMessages.clear();
  }

  isConnected() {
    return this.socket && !this.socket.destroyed;
  }

  async getTaskHistory(limit = null) {
    return this.sendMessage('get_task_history', { limit });
  }

  async getHistoryTask(taskId) {
    // Use 30 second timeout for history task fetching
    return this.sendMessage('get_history_task', { taskId }, 30000);
  }

  async getGatewayStatus() {
    return this.sendMessage('gateway_status');
  }
}

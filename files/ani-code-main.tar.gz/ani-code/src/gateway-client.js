import axios from 'axios';
import { logger } from './logger.js';
import os from 'os';
import { getGatewayUserAgent } from './utils/gateway-request.js';

/**
 * Gateway Client for ani-code instance registration
 * Implements the K8s pod registration protocol with the ani-code-gateway
 *
 * This module is 100% optional and backward compatible:
 * - Only activates when GATEWAY_URL environment variable is set
 * - Falls back to standalone mode if gateway is unavailable
 * - Does not affect normal ani-code operation
 */
export class GatewayClient {
  constructor() {
    // Gateway configuration (optional)
    this.gatewayUrl = process.env.GATEWAY_URL;
    this.apiKey = process.env.GATEWAY_API_KEY;

    // Pod metadata (for K8s environments)
    this.projectId = process.env.PROJECT_ID;
    this.workspaceId = process.env.WORKSPACE_ID;
    this.podName = process.env.POD_NAME || os.hostname();

    // Instance tracking
    this.instanceId = null;
    this.registeredWithGateway = false;
    this.heartbeatInterval = null;

    // Instance URL - prefer ANI_CODE_URL environment variable
    // This allows proper configuration in container/cloud environments
    this.instanceUrl = this.getInstanceUrl();
  }

  /**
   * Get the instance URL for gateway registration
   * Priority:
   * 1. ANI_CODE_URL - Explicit URL (supports custom domains/proxies)
   * 2. Auto-detected: http://{podIp}:{port} - For direct pod access
   */
  getInstanceUrl() {
    // First priority: use ANI_CODE_URL if set (for production/cloud deployments)
    if (process.env.ANI_CODE_URL) {
      return process.env.ANI_CODE_URL;
    }

    // Second priority: auto-detect using pod IP and port
    const podIp = this.getPodIp();
    const port = process.env.ANI_CODE_DAEMON_PORT || process.env.HTTP_CALLBACK_PORT || process.env.PORT || 6501;
    return `http://${podIp}:${port}`;
  }

  /**
   * Get User-Agent string for external API calls
   */
  getUserAgent() {
    return getGatewayUserAgent();
  }

  /**
   * Get the pod IP address
   * In K8s, this is typically the pod's IP
   * In local development, fallback to localhost
   */
  getPodIp() {
    // Check for explicit pod IP environment variable (K8s sets this)
    if (process.env.POD_IP) {
      return process.env.POD_IP;
    }

    // Get all network interfaces
    const interfaces = os.networkInterfaces();
    for (const [name, addrs] of Object.entries(interfaces)) {
      // Skip loopback interface
      if (name === 'lo' || name === 'lo0') continue;

      for (const addr of addrs) {
        // Use first IPv4 non-loopback address
        if (addr.family === 'IPv4' && !addr.internal) {
          return addr.address;
        }
      }
    }

    // Fallback to localhost
    return '127.0.0.1';
  }

  /**
   * Check if gateway integration is enabled
   */
  isEnabled() {
    return !!this.gatewayUrl;
  }

  /**
   * Register this instance with the gateway
   * @param {boolean} isHeartbeat - True if this is a heartbeat re-registration
   * @returns {Promise<string|null>} Instance ID if successful, null otherwise
   */
  async register(isHeartbeat = false) {
    // Skip if no gateway configured
    if (!this.gatewayUrl) {
      logger.info('No GATEWAY_URL configured, running in standalone mode');
      return null;
    }

    try {
      const response = await axios.post(
        `${this.gatewayUrl}/api/registry/instance`,
        {
          url: this.instanceUrl,
          // Include daemon's GATEWAY_TOKEN so gateway can use it for request forwarding
          token: process.env.GATEWAY_TOKEN,
          metadata: {
            projectId: this.projectId || 'unknown',
            workspaceId: this.workspaceId || 'unknown',
            podName: this.podName,
            version: '1.2.0',
            capabilities: ['telegram', 'lark', 'cli', 'http', 'websocket'],
            // Also include in metadata as backup
            gatewayToken: process.env.GATEWAY_TOKEN
          }
        },
        {
          headers: {
            'x-api-key': this.apiKey || 'dev-key-1',
            'Content-Type': 'application/json',
            'User-Agent': this.getUserAgent()
          },
          timeout: 5000
        }
      );

      const wasRegistered = this.registeredWithGateway;
      this.instanceId = response.data.id;
      this.registeredWithGateway = true;

      // Only log at INFO level for first registration, use DEBUG for heartbeats
      if (!wasRegistered && !isHeartbeat) {
        logger.info('Registered with gateway:', {
          instanceId: this.instanceId,
          url: this.instanceUrl,
          projectId: this.projectId,
          workspaceId: this.workspaceId
        });
      } else {
        logger.debug('Gateway heartbeat sent:', {
          instanceId: this.instanceId
        });
      }

      return this.instanceId;
    } catch (error) {
      // Handle specific error cases
      if (error.code === 'ECONNREFUSED' || error.code === 'ENOTFOUND') {
        logger.warn(`Gateway unavailable at ${this.gatewayUrl} (continuing in standalone mode)`);
      } else if (error.response?.status === 401) {
        logger.warn('Gateway authentication failed - check GATEWAY_API_KEY');
      } else {
        logger.warn('Failed to register with gateway (continuing in standalone mode):', error.message);
      }

      // Clear registration state on failure
      this.registeredWithGateway = false;
      this.instanceId = null;

      // Don't throw - continue in standalone mode
      return null;
    }
  }

  /**
   * Deregister this instance from the gateway
   */
  async deregister() {
    if (!this.registeredWithGateway || !this.instanceId) {
      return; // Not registered, nothing to do
    }

    try {
      await axios.delete(
        `${this.gatewayUrl}/api/registry/instance/${this.instanceId}`,
        {
          headers: {
            'x-api-key': this.apiKey || 'dev-key-1',
            'User-Agent': this.getUserAgent()
          },
          timeout: 3000
        }
      );

      logger.info('Deregistered from gateway:', { instanceId: this.instanceId });
    } catch (error) {
      // Best effort - log but don't throw during shutdown
      logger.warn('Failed to deregister from gateway:', error.message);
    } finally {
      this.registeredWithGateway = false;
      this.instanceId = null;
    }
  }

  /**
   * Send heartbeat to gateway (updates lastSeen timestamp)
   * Re-registration acts as a heartbeat
   */
  async sendHeartbeat() {
    if (!this.registeredWithGateway) {
      return;
    }

    // Re-register to update lastSeen, mark as heartbeat
    await this.register(true);
  }

  /**
   * Start periodic heartbeat
   */
  startHeartbeat() {
    if (!this.isEnabled()) {
      return;
    }

    // Send initial registration
    this.register().catch(err => {
      logger.debug('Initial gateway registration failed:', err.message);
    });

    // Send heartbeat every 60 seconds (reduced frequency to minimize log noise)
    this.heartbeatInterval = setInterval(() => {
      this.sendHeartbeat().catch(err => {
        logger.debug('Gateway heartbeat failed:', err.message);
      });
    }, 60000);

    logger.info('Gateway heartbeat started', {
      gatewayUrl: this.gatewayUrl,
      interval: '60s'
    });
  }

  /**
   * Stop heartbeat
   */
  stopHeartbeat() {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
      logger.info('Gateway heartbeat stopped');
    }
  }

  /**
   * Graceful shutdown - deregister and stop heartbeat
   */
  async shutdown() {
    this.stopHeartbeat();
    await this.deregister();
  }

  /**
   * Get current gateway registration status
   * @returns {Promise<object>} Status information
   */
  async getStatus() {
    const status = {
      enabled: this.isEnabled(),
      gatewayUrl: this.gatewayUrl || null,
      instanceUrl: this.instanceUrl,
      registered: this.registeredWithGateway,
      instanceId: this.instanceId || null,
      projectId: this.projectId || null,
      workspaceId: this.workspaceId || null,
      podName: this.podName || null,
      heartbeatActive: !!this.heartbeatInterval,
      apiKey: this.apiKey || null  // Include API key for CLI commands
    };

    // If gateway is enabled, try to verify connection
    if (this.isEnabled()) {
      try {
        // Check gateway health
        const healthResponse = await axios.get(
          `${this.gatewayUrl}/api/health`,
          {
            timeout: 3000,
            headers: {
              'User-Agent': this.getUserAgent()
            }
          }
        );
        status.gatewayHealthy = healthResponse.status === 200;
        status.gatewayHealth = healthResponse.data;
      } catch (error) {
        status.gatewayHealthy = false;
        status.gatewayError = error.message;
      }

      // Check registration status using secure single-instance endpoint
      try {
        const config = {
          gateway: {
            projectId: this.projectId || 'unknown'
          }
        };

        const checkResponse = await axios.get(
          `${this.gatewayUrl}/api/registry/instance/check`,
          {
            params: {
              instanceId: config.gateway.projectId,
              url: this.instanceUrl
            },
            headers: {
              'x-api-key': this.apiKey || 'dev-key-1',
              'User-Agent': this.getUserAgent()
            },
            timeout: 3000
          }
        );

        const { registered, instance: ourInstance } = checkResponse.data;

        if (registered && ourInstance) {
          // Successfully registered - update our tracking
          if (!this.instanceId || this.instanceId !== ourInstance.id) {
            this.instanceId = ourInstance.id;
            this.registeredWithGateway = true;
            logger.info('Instance registration confirmed', {
              instanceId: ourInstance.id,
              url: ourInstance.url
            });
          }

          status.registered = true;
          status.instanceId = ourInstance.id;
          status.registrationDetails = {
            id: ourInstance.id,
            url: ourInstance.url,
            lastSeen: ourInstance.lastSeen,
            metadata: ourInstance.metadata
          };
        } else {
          // Not registered - clear stale data and trigger re-registration
          logger.warn('Instance not found in gateway registry - will re-register');
          this.instanceId = null;
          this.registeredWithGateway = false;
          status.registered = false;
          status.instanceId = null;
          status.registrationWarning = 'Instance not registered, re-registration in progress';

          // Trigger immediate re-registration if heartbeat is active
          if (this.heartbeatInterval) {
            this.register().catch(err => {
              logger.debug('Re-registration attempt failed:', err.message);
            });
          }
        }
      } catch (error) {
        logger.error('Failed to check registration status', {
          error: error.message,
          gatewayUrl: this.gatewayUrl
        });
        status.registrationError = error.message;
      }
    }

    return status;
  }
}

// Export singleton instance
export const gatewayClient = new GatewayClient();
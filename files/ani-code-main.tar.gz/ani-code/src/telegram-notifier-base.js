import { basename, resolve } from 'path';
import { statSync } from 'fs';
import { config } from './config.js';
import { logger } from './logger.js';
import { normalizeModelNameLowercase } from './utils/model-normalizer.js';

/**
 * Base class for Telegram notifiers with shared formatting methods.
 * Both TelegramNotifier and DummyTelegramNotifier extend this.
 */
export class TelegramNotifierBase {
  constructor() {
    this.messageCache = new Map();
    this.yoloProtectedChats = new Set();
  }

  /**
   * Check if a task has attachments (web chat images or Telegram photo URLs in prompt)
   */
  taskHasAttachments(task) {
    if (task.attachments && task.attachments.length > 0) return true;
    // Telegram photo uploads embed the image URL in the prompt
    if (task.command && /\nImage: https?:\/\//.test(task.command)) return true;
    return false;
  }

  /**
   * Escape special Markdown characters in content
   */
  escapeMarkdownContent(text) {
    if (!text) return '';

    // Only escape special markdown characters that aren't part of intended formatting
    // We want to preserve * for bold, ` for code, etc. when they're intentional
    // But escape them in file paths and other content
    return text
      .replace(/([_\[\]()~>#+=|{}.!-])/g, '\\$1');
  }

  /**
   * Format a minimal footer for simple mode (task ID only)
   */
  formatSimpleFooter(taskId) {
    return taskId ? `\n\n\`${taskId}\`` : '';
  }

  /**
   * Format footer with workspace, time, hostname, and provider info
   */
  async formatFooter(workdir, options = {}) {
    const time = new Date().toLocaleTimeString('en-GB', {
      hour12: false,
      timeZone: config.timezone,
      hour: '2-digit',
      minute: '2-digit'
    });

    const hostname = config.lark?.hostname || 'unknown';
    const provider = options.taskProviderId || '';

    const parts = [`🖥 ${hostname}`, `⏰ ${time}`, `📁 ${workdir}`];
    if (provider) {
      parts.push(`🤖 ${provider}`);
    }

    return `\n\n${parts.join(' • ')}`;
  }

  /**
   * Format a simple one-line task update (for simple display mode)
   * Shows only minimal info: emoji + task name + provider
   */
  formatSimpleTaskUpdateMessage(task, status) {
    let emoji;
    if (status === 'started') {
      emoji = '🚀';
    } else if (status === 'queued') {
      emoji = '⏳';
    } else {
      emoji = '📝';
    }

    // Show first line of command truncated as the task description
    const firstLine = (task.command || '').split('\n')[0] || task.name || 'task';
    const provider = task.providerId || 'claude';
    const shortPrompt = firstLine.length > 50 ? firstLine.substring(0, 47) + '...' : firstLine;
    const escapedPrompt = this.escapeMarkdownContent(shortPrompt);
    const attachmentIndicator = this.taskHasAttachments(task) ? ' 📃' : '';
    return `${emoji} ${escapedPrompt} (${provider})${attachmentIndicator}`;
  }

  /**
   * Format task update message (started, queued, etc.)
   */
  async formatTaskUpdateMessage(task, status) {
    let emoji, title;
    const escapedName = this.escapeMarkdownContent(task.name || 'Unknown Task');
    if (status === 'started') {
      emoji = '🚀';
      title = `Task Started - ${escapedName}`;
    } else if (status === 'queued') {
      emoji = '⏳';
      title = `Task Queued - ${escapedName}`;
    } else {
      emoji = '📝';
      title = `Task ${status} - ${escapedName}`;
    }

    const workdir = task.cwd ? basename(task.cwd) : 'unknown';

    const attachmentIndicator = this.taskHasAttachments(task) ? ' 📃' : '';
    let message = `${emoji} *${title}*${attachmentIndicator}\n\n`;
    message += `*Task ID:* \`${task.id}\`\n`;

    if (task.pid && status === 'started') {
      message += `*PID:* ${task.pid}\n`;
    }

    // Add prompt section with truncation for long prompts
    const firstLine = task.command.split('\n')[0] || task.command;
    const truncatedPrompt = firstLine.length > 120 ? firstLine.substring(0, 117) + '...' : firstLine;
    message += `*Prompt:* ${truncatedPrompt}`;

    message += await this.formatFooter(workdir, { taskProviderId: task.providerId });

    return message;
  }

  /**
   * Format task summary message (completed, failed, etc.)
   * Updated to match direct Telegram format for consistency across modes
   */
  async formatTaskSummaryMessage(task, result, taskUsage = null, usageReporter = null, pendingCount = 0) {
    const duration = task.completedAt - task.startedAt;
    const durationMs = duration;
    const seconds = Math.floor(durationMs / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);

    let durationFormatted;
    if (hours > 0) {
      durationFormatted = `${hours}h ${minutes % 60}m`;
    } else if (minutes > 0) {
      durationFormatted = `${minutes}m ${seconds % 60}s`;
    } else {
      durationFormatted = `${seconds}s`;
    }

    const workdir = task.cwd ? basename(task.cwd) : 'unknown';

    // Build title in compact format (matching direct Telegram)
    let emoji, title;
    const escapedName = this.escapeMarkdownContent(task.name || 'Unknown Task');
    if (result === 'success') {
      emoji = '✅';
      title = `Task Completed - ${escapedName}`;
      if (pendingCount > 0) {
        title += ` (${pendingCount} pending)`;
      }
    } else if (result === 'cancelled') {
      emoji = '⏹';
      title = `Task Cancelled - ${escapedName}`;
      if (pendingCount > 0) {
        title += ` (${pendingCount} pending)`;
      }
    } else {
      emoji = '❌';
      title = `Task Failed - ${escapedName}`;
      if (pendingCount > 0) {
        title += ` (${pendingCount} pending)`;
      }
    }

    // Start with compact title line (emoji, title, duration)
    let message = `${emoji} *${title}* (${durationFormatted})\n\n`;

    // Add Task ID
    message += `*Task ID:* \`${task.id}\`\n`;

    // Add truncated prompt
    if (task.command) {
      const firstLine = task.command.split('\n')[0] || task.command;
      const truncatedPrompt = firstLine.length > 120 ? firstLine.substring(0, 117) + '...' : firstLine;
      message += `*Prompt:* ${truncatedPrompt}\n`;
    }

    // Add exit code if non-zero
    if (task.exitCode !== null && task.exitCode !== 0) {
      message += `*Exit Code:* ${task.exitCode}\n`;
    }

    // Add output if available
    if (task.output && task.output.trim()) {
      const allLines = task.output.trim().split('\n');
      const totalLines = allLines.length;

      // If output is 3 lines or less, show inline
      if (totalLines <= 3) {
        message += '\n' + this.escapeMarkdownContent(task.output.trim()) + '\n';
      } else {
        // For longer output, use code block with sanitized content
        if (totalLines <= 20) {
          message += '\n' + this.wrapInCodeBlock(task.output.trim());
        } else {
          // Show first 4 lines and last 16 lines (total 20 visible)
          const firstLines = allLines.slice(0, 4).join('\n').trim();
          const lastLines = allLines.slice(-16).join('\n').trim();
          const hiddenCount = totalLines - 20;

          if (hiddenCount < 20) {
            // If hiding less than 20 lines, just show all
            message += '\n' + this.wrapInCodeBlock(task.output.trim());
          } else {
            const combined = this.sanitizeForCodeBlock(firstLines) + '\n\n... (' + hiddenCount + ' lines hidden) ...\n\n' + this.sanitizeForCodeBlock(lastLines);
            message += '\n```\n' + combined + '\n```';
          }
        }
      }
    }

    // Add error if present
    if ((result === 'error' || result === 'cancelled') && task.error) {
      const escapedError = this.escapeMarkdownContent(task.error);
      message += `\n💬 ${escapedError}\n`;
    }

    // Add git status for the task's working directory
    if (task.cwd) {
      try {
        const { execSync } = await import('child_process');

        // Get current branch
        const branch = execSync('git branch --show-current', {
          cwd: task.cwd,
          encoding: 'utf8',
          timeout: 5000
        }).trim();

        // Only show branch if it's not main or master
        if (branch && branch !== 'main' && branch !== 'master') {
          message += `\n*🌿 Branch:* \`${branch}\``;
        }

        // Get dirty files
        const statusOutput = execSync('git status --porcelain', {
          cwd: task.cwd,
          encoding: 'utf8',
          timeout: 5000
        }).trim();

        if (statusOutput) {
          const dirtyFiles = statusOutput.split('\n').map(line => {
            const trimmedLine = line.trim();
            const [status, ...fileParts] = trimmedLine.split(/\s+/);
            const fileName = fileParts.join(' ');
            return `${status.padEnd(3)} ${fileName}`;
          });

          // Get git diff stats
          let diffStatsText = '';
          try {
            const diffStatsOutput = execSync('git diff --shortstat', {
              cwd: task.cwd,
              encoding: 'utf8',
              timeout: 5000
            }).trim();

            if (diffStatsOutput) {
              const insertions = diffStatsOutput.match(/(\d+) insertion/)?.[1] || 0;
              const deletions = diffStatsOutput.match(/(\d+) deletion/)?.[1] || 0;
              if (parseInt(insertions) > 0 || parseInt(deletions) > 0) {
                diffStatsText = `: +${insertions}/-${deletions}`;
              }
            }
          } catch (error) {
            // Ignore diff stats errors
          }

          message += `\n*📂 Git Status* (${dirtyFiles.length} file${dirtyFiles.length === 1 ? '' : 's'}${diffStatsText}):\n\`\`\`\n${dirtyFiles.slice(0, 10).join('\n')}${dirtyFiles.length > 10 ? `\n... and ${dirtyFiles.length - 10} more` : ''}\n\`\`\``;
        } else {
          message += `\n*📂 Git Status:* Clean`;
        }
      } catch (error) {
        // Not a git repo or error getting status - silently skip
      }
    }

    // Add cost/token info if available
    const costTokenLine = await this.buildCostTokenLine(taskUsage, usageReporter, task.id);
    if (costTokenLine) {
      message += `\n${costTokenLine}\n`;
    }

    // Add footer
    message += await this.formatFooter(workdir, { taskProviderId: task.providerId });

    return message;
  }

  /**
   * Detect if text contains structured/markdown content that needs code block wrapping
   * for proper display in Telegram (tables, code fences, aligned columns, etc.)
   */
  looksLikeStructuredContent(text) {
    if (!text) return false;
    // Markdown table: lines with | separators and a header separator row (|---|)
    if (/\|.+\|/.test(text) && /\|[-:]+\|/.test(text)) return true;
    // Code fences (``` blocks)
    if (/```/.test(text)) return true;
    // Markdown headings (## Title, ### Subtitle, etc.)
    if (/^#{1,6}\s+\S/m.test(text)) return true;
    // Bold/italic markdown (**text** or __text__)
    if (/\*\*\S/.test(text) || /__\S/.test(text)) return true;
    // Markdown bullet lists (- item or * item at start of line)
    if (/^[\s]*[-*]\s+\S/m.test(text)) {
      const bulletLines = text.split('\n').filter(l => /^\s*[-*]\s+\S/.test(l));
      if (bulletLines.length >= 2) return true;
    }
    // Tab-aligned or column-aligned data (3+ lines with consistent spacing patterns)
    const lines = text.split('\n');
    if (lines.length >= 3) {
      // Multiple lines with 2+ consecutive spaces (aligned columns)
      const alignedLines = lines.filter(l => /\S {2,}\S/.test(l));
      if (alignedLines.length >= 3) return true;
    }
    // HTML tags
    if (/<\/?[a-z][\s\S]*>/i.test(text)) return true;
    return false;
  }

  /**
   * Sanitize text for safe inclusion inside a Telegram ``` code block.
   * Replaces backticks with prime characters (′) so the outer fence is never broken.
   * Returns the sanitized text WITHOUT the wrapping ``` fences.
   */
  sanitizeForCodeBlock(text) {
    if (!text) return '';
    return text
      .replace(/```+/g, '′′′')           // Replace triple+ backticks with triple primes
      .replace(/`/g, '′')                 // Replace single backticks with prime
      .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, '') // Remove control chars except \n\r\t
      .replace(/\r\n/g, '\n')             // Normalize line endings
      .replace(/\r/g, '\n');              // Normalize line endings
  }

  /**
   * Wrap text in a Telegram-safe code block.
   * Sanitizes backticks and control characters inside the text so the
   * outer ``` fence is never broken.
   * Returns the full ```...``` wrapped string.
   */
  wrapInCodeBlock(text) {
    return '```\n' + this.sanitizeForCodeBlock(text) + '\n```';
  }

  /**
   * Render output for simple display mode.
   * If the output looks like structured content (tables, code, etc.), wraps in
   * a sanitized code block. Otherwise returns escaped raw text.
   */
  renderSimpleOutput(text) {
    if (!text || !text.trim()) return '';
    const trimmed = text.trim();
    if (this.looksLikeStructuredContent(trimmed)) {
      return this.wrapInCodeBlock(trimmed) + '\n';
    }
    return this.escapeMarkdownContent(trimmed) + '\n';
  }

  /**
   * Format task summary in simple mode - content + duration + cost
   * No git status, no verbose footer, no task ID
   */
  async formatSimpleTaskSummaryMessage(task, result, taskUsage = null, usageReporter = null, pendingCount = 0) {
    const duration = task.completedAt - task.startedAt;
    const durationMs = duration;
    const seconds = Math.floor(durationMs / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);

    let durationFormatted;
    if (hours > 0) {
      durationFormatted = `${hours}h ${minutes % 60}m`;
    } else if (minutes > 0) {
      durationFormatted = `${minutes}m ${seconds % 60}s`;
    } else {
      durationFormatted = `${seconds}s`;
    }

    let emoji;
    if (result === 'success') {
      emoji = '✅';
    } else if (result === 'cancelled') {
      emoji = '⏹';
    } else {
      emoji = '❌';
    }

    let message = '';

    // Add output if available (content first in simple mode)
    // No truncation — show full output
    // Wrap in code block if structured content (tables, code, aligned columns)
    let outputIsPlainText = false;
    if (task.output && task.output.trim()) {
      message += this.renderSimpleOutput(task.output);
      outputIsPlainText = !this.looksLikeStructuredContent(task.output.trim());
    }

    // Add error if present
    if ((result === 'error' || result === 'cancelled') && task.error) {
      const escapedError = this.escapeMarkdownContent(task.error);
      message += `💬 ${escapedError}\n`;
    }

    // Add git file changes for completed tasks
    if (task.cwd) {
      try {
        const { execSync } = await import('child_process');
        const statusOutput = execSync('git status --porcelain', {
          cwd: task.cwd,
          encoding: 'utf8',
          timeout: 5000
        }).trim();

        if (statusOutput) {
          const { duringTask, beforeTask } = categorizeGitFilesByTaskTiming(statusOutput, task.cwd, task.startedAt);

          let diffStatsText = '';
          try {
            const diffStatsOutput = execSync('git diff --shortstat', {
              cwd: task.cwd,
              encoding: 'utf8',
              timeout: 5000
            }).trim();
            if (diffStatsOutput) {
              const insertions = diffStatsOutput.match(/(\d+) insertion/)?.[1] || 0;
              const deletions = diffStatsOutput.match(/(\d+) deletion/)?.[1] || 0;
              if (parseInt(insertions) > 0 || parseInt(deletions) > 0) {
                diffStatsText = `: +${insertions}/-${deletions}`;
              }
            }
          } catch (error) {
            // Ignore diff stats errors
          }

          const totalChanges = duringTask.length + beforeTask.length;
          const beforeNote = beforeTask.length > 0 ? ` (${beforeTask.length} uncommitted before)` : '';
          if (duringTask.length > 0) {
            message += `\n📂 ${duringTask.length} file${duringTask.length === 1 ? '' : 's'} changed${diffStatsText}${beforeNote}\n\`\`\`\n${duringTask.slice(0, 10).join('\n')}${duringTask.length > 10 ? `\n... +${duringTask.length - 10} more` : ''}\n\`\`\``;
            outputIsPlainText = false;
          } else if (beforeTask.length > 0) {
            message += `\n📁 ${beforeTask.length} file${beforeTask.length === 1 ? '' : 's'} uncommitted before task\n`;
          }
        }
      } catch (error) {
        // Not a git repo or error getting status - silently skip
      }
    }

    // Brief completion line: emoji Done (duration) • cost • #taskid
    // Add empty line before Done when output is plain text (not in codeblock)
    if (outputIsPlainText) {
      message += '\n';
    }
    const shortTaskId = task.id.slice(-6);
    message += `${emoji} Done (${durationFormatted})`;

    // Add cost info if available
    const costTokenLine = await this.buildCostTokenLine(taskUsage, usageReporter, task.id, { simple: true });
    if (costTokenLine) {
      message += ` • ${costTokenLine}`;
    }

    message += ` • #${shortTaskId}`;

    if (pendingCount > 0) {
      message += ` (${pendingCount} pending)`;
    }

    return message;
  }

  /**
   * Build cost and token line for task completion messages
   */
  async buildCostTokenLine(taskUsage, usageReporter, taskId = null, { simple = false } = {}) {
    if (!taskUsage || (taskUsage.cost <= 0 && taskUsage.tokens <= 0)) {
      return '';
    }

    const formatTokens = (tokens) => {
      if (tokens >= 1000000) {
        return `${(tokens / 1000000).toFixed(1)}m`;
      } else if (tokens >= 1000) {
        return `${(tokens / 1000).toFixed(1)}k`;
      }
      return tokens.toLocaleString();
    };

    // Helper function to format model names for display
    const formatModelName = (modelName) => {
      return normalizeModelNameLowercase(modelName);
    };

    const inputTotal = (taskUsage.inputTokens || 0);
    const cachedInput = (taskUsage.cacheReadTokens || 0);
    const outputTotal = (taskUsage.outputTokens || 0);

    const tokenParts = [];

    if (taskUsage.tokens > 0 && inputTotal === 0 && outputTotal === 0) {
      tokenParts.push(`Total: ${formatTokens(taskUsage.tokens)}`);
    } else {
      if (inputTotal > 0) {
        tokenParts.push(`In: ${formatTokens(inputTotal)}${cachedInput > 0 ? ` (${formatTokens(cachedInput)} cached)` : ''}`);
      }
      if (outputTotal > 0) {
        tokenParts.push(`Out: ${formatTokens(outputTotal)}`);
      }
    }

    // Build model information
    let modelInfo = '';
    if (taskUsage.modelBreakdowns && taskUsage.modelBreakdowns.length > 0) {
      // Sort models by cost (highest first) to show the primary model first
      const sortedModels = taskUsage.modelBreakdowns.sort((a, b) => b.cost - a.cost);
      const modelNames = sortedModels.map(model => formatModelName(model.modelName));
      modelInfo = ` (${modelNames.join(', ')})`;
    } else if (taskUsage.modelsUsed && taskUsage.modelsUsed.length > 0) {
      // Fallback to modelsUsed if modelBreakdowns not available
      const modelNames = taskUsage.modelsUsed.map(model => formatModelName(model));
      modelInfo = ` (${modelNames.join(', ')})`;
    }

    const tokensText = tokenParts.length > 0 ? tokenParts.join(' • ') : '';

    if (taskUsage.cost > 0) {
      let costTokenLine = `💰 $${taskUsage.cost.toFixed(4)}${modelInfo}`;
      if (tokensText && !simple) {
        costTokenLine += ` • ${tokensText}`;
      }
      return costTokenLine;
    }

    if (tokensText && !simple) {
      return `🧮 ${tokensText}${modelInfo}`;
    }

    return modelInfo.trim() ? `🤖${modelInfo}` : '';
  }

  /**
   * Truncate output to specified length
   */
  truncateOutput(output, maxLength = 300) {
    if (!output) return 'No output';

    // Remove ANSI color codes
    const cleaned = output.replace(/\x1b\[[0-9;]*m/g, '');

    if (cleaned.length <= maxLength) {
      return cleaned;
    }

    return cleaned.substring(0, maxLength - 3) + '...';
  }

  /**
   * Sanitize message for Telegram API
   */
  sanitizeMessageForTelegram(text) {
    if (!text) return '';

    // Telegram has issues with some markdown characters
    // We need to ensure balanced asterisks and backticks
    let sanitized = text;

    // Count asterisks and make them balanced
    const asteriskCount = (sanitized.match(/\*/g) || []).length;
    if (asteriskCount % 2 !== 0) {
      // Add an asterisk at the end to balance
      sanitized += '*';
    }

    // Count backticks and make them balanced
    const backtickCount = (sanitized.match(/`/g) || []).length;
    if (backtickCount % 2 !== 0) {
      // Add a backtick at the end to balance
      sanitized += '`';
    }

    // Escape other problematic characters that might cause parse errors
    // But only if they're not part of valid markdown
    sanitized = sanitized
      .replace(/([_\[\]()~>#+=|{}.!-])/g, '\\$1')
      .replace(/\\\*/g, '*') // Unescape asterisks we want to keep for bold
      .replace(/\\`/g, '`'); // Unescape backticks we want to keep for code

    return sanitized;
  }

  /**
   * Get keyboard for task updates
   */
  getTaskUpdateKeyboard(task, status) {
    if (status !== 'started') {
      return null;
    }

    return {
      inline_keyboard: [
        [
          {
            text: '🛑 Cancel Task',
            callback_data: `cancel:${task.id}`
          }
        ]
      ]
    };
  }

  /**
   * Get keyboard for task summary
   */
  async getTaskSummaryKeyboard(task, result) {
    const keyboard = {
      inline_keyboard: []
    };

    // Add view output button for all completed tasks
    if (result === 'success' || result === 'error') {
      keyboard.inline_keyboard.push([
        {
          text: '📜 View Full Output',
          callback_data: `output:${task.id}`
        }
      ]);
    }

    return keyboard.inline_keyboard.length > 0 ? keyboard : null;
  }

  /**
   * Check if chat is YOLO protected
   */
  isYoloProtected(chatId) {
    return this.yoloProtectedChats.has(chatId);
  }

  /**
   * Enable YOLO protection for a chat
   */
  enableYoloProtection(chatId) {
    this.yoloProtectedChats.add(chatId);
    logger.info(`[TELEGRAM] YOLO protection enabled for chat ${chatId}`);
  }

  /**
   * Disable YOLO protection for a chat
   */
  disableYoloProtection(chatId) {
    this.yoloProtectedChats.delete(chatId);
    logger.info(`[TELEGRAM] YOLO protection disabled for chat ${chatId}`);
  }
}

/**
 * Categorize git dirty files into "edited during task" vs "previously uncommitted".
 * Uses file mtime to determine if a file was modified during the task's execution window.
 *
 * @param {string} statusOutput - Raw output from `git status --porcelain`
 * @param {string} cwd - Working directory of the task
 * @param {Date} taskStartedAt - When the task started
 * @returns {{ duringTask: string[], beforeTask: string[] }} Categorized file lines
 */
export function categorizeGitFilesByTaskTiming(statusOutput, cwd, taskStartedAt) {
  const duringTask = [];
  const beforeTask = [];

  if (!statusOutput || !taskStartedAt) {
    // No timing info — treat all as during-task (legacy behavior)
    const all = statusOutput ? statusOutput.split('\n').map(line => {
      const trimmedLine = line.trim();
      const [status, ...fileParts] = trimmedLine.split(/\s+/);
      const fileName = fileParts.join(' ');
      return `${status.padEnd(3)} ${fileName}`;
    }) : [];
    return { duringTask: all, beforeTask: [] };
  }

  const taskStart = new Date(taskStartedAt).getTime();
  // Small buffer: files modified up to 2s before task start count as during-task
  const threshold = taskStart - 2000;

  const lines = statusOutput.split('\n');
  for (const line of lines) {
    const trimmedLine = line.trim();
    if (!trimmedLine) continue;
    const [status, ...fileParts] = trimmedLine.split(/\s+/);
    const fileName = fileParts.join(' ');
    const formatted = `${status.padEnd(3)} ${fileName}`;

    try {
      const fullPath = resolve(cwd, fileName);
      const stat = statSync(fullPath);
      const mtime = stat.mtimeMs;
      if (mtime >= threshold) {
        duringTask.push(formatted);
      } else {
        beforeTask.push(formatted);
      }
    } catch {
      // File might be deleted or inaccessible — if status is D, it's during-task
      if (status.includes('D')) {
        duringTask.push(formatted);
      } else {
        duringTask.push(formatted);
      }
    }
  }

  return { duringTask, beforeTask };
}
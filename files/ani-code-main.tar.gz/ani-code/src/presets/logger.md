# Logger Standards

## Systemd/Journalctl Considerations
Since logs are primarily accessed via `journalctl`, timestamps are redundant.
- **DO NOT** output timestamps in log messages (journalctl adds them)
- **DO NOT** output time/date information unless specifically required by business logic
- **Focus** on the message content and context

## Color Coding by Level
Use ANSI colors for clear visual distinction in terminal output:

```javascript
const colors = {
  ERROR: '\x1b[31m',   // Red
  WARN: '\x1b[33m',    // Yellow
  INFO: '\x1b[36m',    // Cyan
  DEBUG: '\x1b[35m',   // Magenta
  RESET: '\x1b[0m'
};

// Example usage
console.log(`${colors.ERROR}[ERROR]${colors.RESET} Message here`);
```

### Color Standards
- **ERROR (Red)**: Critical errors requiring immediate attention
- **WARN (Yellow)**: Warnings and potential issues
- **INFO (Cyan)**: Normal operational messages
- **DEBUG (Magenta)**: Debug information during development

## Debug Logging Discipline
- **ALWAYS** remove debug logs after debugging is complete
- **NEVER** leave temporary debug logs in production code
- Use conditional debug flags for persistent debug needs
- Review code before committing to remove console.log/debug statements

## Single Line Logging
- **AVOID** multi-line logs, especially JSON objects
- **CONCAT** information into single line with delimiters
- **EXTRACT** only critical fields from objects

### Bad Example
```javascript
console.log('User data:');
console.log(JSON.stringify(userData, null, 2));
```

### Good Example
```javascript
console.log(`User: ${userId} | email=${user.email} | status=${user.status}`);
```

## User Context Logging
When logs belong to a logged-in user:
- **ALWAYS** prefix with user ID
- Format: `[userId] action | details`
- Makes log filtering/searching easier

### Example
```javascript
console.log(`[${userId}] Order created | orderId=${orderId} | amount=$${amount}`);
console.log(`[${userId}] Login failed | reason=${reason} | ip=${ip}`);
```

## Logger Implementation Template

```javascript
const LOG_LEVELS = {
  ERROR: { label: 'ERROR', color: '\x1b[31m' },
  WARN: { label: 'WARN', color: '\x1b[33m' },
  INFO: { label: 'INFO', color: '\x1b[36m' },
  DEBUG: { label: 'DEBUG', color: '\x1b[35m' }
};

const RESET = '\x1b[0m';

class Logger {
  constructor(context = '') {
    this.context = context;
  }

  log(level, message, userId = null, meta = {}) {
    const { label, color } = LOG_LEVELS[level];
    const userPrefix = userId ? `[${userId}] ` : '';
    const contextPrefix = this.context ? `[${this.context}] ` : '';

    // Flatten meta object to single line
    const metaStr = Object.entries(meta)
      .map(([k, v]) => `${k}=${v}`)
      .join(' | ');

    const fullMessage = `${color}[${label}]${RESET} ${contextPrefix}${userPrefix}${message}${metaStr ? ' | ' + metaStr : ''}`;

    console.log(fullMessage);
  }

  error(message, userId = null, meta = {}) {
    this.log('ERROR', message, userId, meta);
  }

  warn(message, userId = null, meta = {}) {
    this.log('WARN', message, userId, meta);
  }

  info(message, userId = null, meta = {}) {
    this.log('INFO', message, userId, meta);
  }

  debug(message, userId = null, meta = {}) {
    // Only log debug in development
    if (process.env.NODE_ENV === 'development') {
      this.log('DEBUG', message, userId, meta);
    }
  }
}

module.exports = Logger;
```

## Usage Examples

```javascript
const logger = new Logger('AuthService');

// User login success
logger.info('Login success', userId, { ip: req.ip, method: 'oauth' });
// Output: [INFO] [AuthService] [user123] Login success | ip=192.168.1.1 | method=oauth

// Error with context
logger.error('Database connection failed', null, {
  host: dbConfig.host,
  code: err.code
});
// Output: [ERROR] [AuthService] Database connection failed | host=localhost | code=ECONNREFUSED

// Warning for specific user
logger.warn('Rate limit approaching', userId, {
  current: 95,
  limit: 100
});
// Output: [WARN] [AuthService] [user456] Rate limit approaching | current=95 | limit=100

// Debug (only in development)
logger.debug('Cache hit', userId, { key: cacheKey });
// Output: [DEBUG] [AuthService] [user789] Cache hit | key=session:user789
```

## Best Practices Summary

1. **No timestamps** - journalctl handles this
2. **Color by level** - visual clarity in terminals
3. **Clean up debug logs** - remove after debugging
4. **Single line only** - concat or extract critical info
5. **User ID prefix** - always include for user-related logs
6. **Flat metadata** - key=value pairs separated by |
7. **Consistent format** - use logger class for standardization
8. **Context aware** - include service/module name
9. **Searchable** - structure for easy grep/filtering
10. **Concise** - only essential information

## Filtering Logs with Journalctl

```bash
# By user
journalctl -u service-name | grep "\[user123\]"

# By level
journalctl -u service-name | grep "ERROR"

# By context
journalctl -u service-name | grep "\[AuthService\]"

# Combined
journalctl -u service-name | grep "\[user123\].*ERROR"
```

## Notes
- Adjust color codes if using light terminal themes
- Consider log aggregation services for production
- Set up log rotation with journalctl limits
- Use structured logging (JSON) only if feeding to log aggregators

# Web Project Development Template

## Project Structure
```
/src
  /components      # Reusable UI components
    /common        # Shared components (Button, Input, Modal, etc.)
    /layout        # Layout components (Header, Footer, Sidebar)
    /features      # Feature-specific components
  /pages           # Route pages/views
  /hooks           # Custom React/Vue hooks
  /utils           # Utility functions
  /services        # API services and external integrations
  /styles          # Global styles and theme
  /assets          # Static assets (images, fonts, icons)
  /store           # State management (Redux/Zustand/Pinia)
  /types           # TypeScript type definitions
  /lib             # Third-party library configurations
/public            # Public static files
/tests             # Test files
```

## Component Implementation Best Practices

### Component Structure
- **Single Responsibility**: Each component should have one clear purpose
- **Composition over Inheritance**: Use component composition for flexibility
- **Props Interface**: Define clear prop types/interfaces
- **Default Props**: Always provide sensible defaults
- **Error Boundaries**: Implement error boundaries for critical components

### Naming Conventions
- **Components**: PascalCase (e.g., `UserProfile`, `NavigationBar`)
- **Files**: Match component name (e.g., `UserProfile.tsx`)
- **Props**: Component name + "Props" (e.g., `UserProfileProps`)
- **Hooks**: Start with "use" (e.g., `useAuth`, `useLocalStorage`)
- **Utils**: camelCase (e.g., `formatDate`, `validateEmail`)

## Theme Configuration

### Light Theme Enforcement
```css
:root {
  /* Primary Colors */
  --color-primary: #3B82F6;
  --color-primary-hover: #2563EB;

  /* Background Colors */
  --color-bg-primary: #FFFFFF;
  --color-bg-secondary: #F9FAFB;
  --color-bg-tertiary: #F3F4F6;

  /* Text Colors */
  --color-text-primary: #111827;
  --color-text-secondary: #4B5563;
  --color-text-tertiary: #6B7280;

  /* Border Colors */
  --color-border: #E5E7EB;
  --color-border-hover: #D1D5DB;

  /* Status Colors */
  --color-success: #10B981;
  --color-warning: #F59E0B;
  --color-error: #EF4444;
  --color-info: #3B82F6;

  /* Shadows */
  --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
  --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
}

/* Enforce light theme globally */
body {
  background-color: var(--color-bg-primary);
  color: var(--color-text-primary);
}

/* Disable dark mode */
@media (prefers-color-scheme: dark) {
  :root {
    /* Keep light theme values even in dark mode preference */
  }
}
```

## Component Template
```tsx
// ComponentName.tsx
import React, { FC, memo } from 'react';
import styles from './ComponentName.module.css';

interface ComponentNameProps {
  // Define props here
  children?: React.ReactNode;
  className?: string;
}

export const ComponentName: FC<ComponentNameProps> = memo(({
  children,
  className = '',
}) => {
  // Component logic here

  return (
    <div className={`${styles.container} ${className}`}>
      {children}
    </div>
  );
});

ComponentName.displayName = 'ComponentName';
```

## Performance Best Practices
- **Code Splitting**: Use dynamic imports for route-based splitting
- **Lazy Loading**: Implement lazy loading for images and components
- **Memoization**: Use React.memo, useMemo, useCallback appropriately
- **Virtual Scrolling**: For large lists, use virtual scrolling
- **Bundle Optimization**: Analyze and optimize bundle size regularly

## Accessibility Standards
- **Semantic HTML**: Use proper HTML5 semantic elements
- **ARIA Labels**: Add appropriate ARIA labels and roles
- **Keyboard Navigation**: Ensure all interactive elements are keyboard accessible
- **Focus Management**: Implement proper focus management
- **Color Contrast**: Maintain WCAG AA compliance (4.5:1 for normal text)

## State Management
- **Local State**: Use useState for component-specific state
- **Context API**: For cross-component state without prop drilling
- **Global Store**: Use Redux/Zustand for application-wide state
- **Server State**: Use React Query/SWR for server state management

## API Integration
```typescript
// services/api.ts
const API_BASE_URL = '[SPECIFY API BASE URL]';

export const apiClient = {
  get: async (endpoint: string) => {
    const response = await fetch(`${API_BASE_URL}${endpoint}`);
    if (!response.ok) throw new Error('API request failed');
    return response.json();
  },
  post: async (endpoint: string, data: any) => {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error('API request failed');
    return response.json();
  },
};
```

## Testing Strategy
- **Unit Tests**: Test individual functions and components
- **Integration Tests**: Test component interactions
- **E2E Tests**: Test critical user flows
- **Coverage Target**: Maintain minimum 80% code coverage

## Build Configuration
- **Development**: `npm run dev` - Hot reload enabled
- **Production**: `npm run build` - Optimized production build
- **Testing**: `npm test` - Run test suite
- **Linting**: `npm run lint` - Code quality checks
- **Type Check**: `npm run type-check` - TypeScript validation

## Security Best Practices
- **Input Validation**: Always validate and sanitize user input
- **XSS Prevention**: Use proper escaping and Content Security Policy
- **HTTPS Only**: Enforce HTTPS in production
- **Authentication**: Implement secure authentication flow
- **Environment Variables**: Never commit sensitive data

## Performance Metrics
- **Core Web Vitals**: Target good scores for LCP, FID, CLS
- **Bundle Size**: Keep initial JS bundle under 200KB
- **Time to Interactive**: Target under 3 seconds
- **First Contentful Paint**: Target under 1.5 seconds

## Notes
[ADD PROJECT-SPECIFIC NOTES HERE]
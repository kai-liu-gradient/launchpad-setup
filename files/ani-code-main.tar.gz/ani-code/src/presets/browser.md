# ani-browser

The `ani-browser` command provides browser automation capabilities for debugging web applications and troubleshooting rendering errors.

## Key Commands for Troubleshooting

### Check Console Errors
```bash
ani-browser console <url>
```
Retrieves console logs from a webpage, useful for identifying JavaScript errors, warnings, and debug messages.

Options:
- `-W, --wait <ms>` - Wait time in milliseconds before capturing (useful for SPAs)
- `-o, --output <file>` - Save console logs to a file

### Capture Screenshots
```bash
ani-browser screenshot <url>
```
Takes a screenshot to visually verify page rendering.

Options:
- `-w, --width <width>` - Viewport width (default: 1920)
- `-h, --height <height>` - Viewport height (default: 1080)
- `-W, --wait <ms>` - Wait before capturing
- `--upload` - Upload screenshot and get a URL for sharing
- `--full` - Capture full page (scrollable content)
- `--mobile` - Use mobile viewport (375x667, iPhone-like)

#### Screenshot Modes

**Viewport Screenshot (default)** - Captures only visible area:
```bash
# Capture visible viewport area (1920x1080)
ani-browser screenshot https://example.com

# Custom viewport size
ani-browser screenshot https://example.com -w 1366 -h 768
```

**Mobile Screenshot** - Captures with mobile viewport:
```bash
# Capture with mobile viewport (375x667)
ani-browser screenshot https://example.com --mobile

# Mobile with custom dimensions
ani-browser screenshot https://example.com -w 390 -h 844  # iPhone 14 Pro
ani-browser screenshot https://example.com -w 412 -h 915  # Pixel 7
```

**Full Page Screenshot** - Captures entire scrollable page:
```bash
# Capture full scrollable page
ani-browser screenshot https://example.com --full

# Full page with custom viewport width
ani-browser screenshot https://example.com --full -w 1920

# Full page mobile view
ani-browser screenshot https://example.com --full --mobile
```

### Get Full Snapshot
```bash
ani-browser snapshot <url>
```
Captures screenshot, DOM content, and console logs in one command for comprehensive debugging.

Options:
- `-W, --wait <ms>` - Wait time in milliseconds before capturing
- `-d, --dir <directory>` - Output directory for all snapshot files
- `--upload` - Upload screenshot to cloud and get URL
- `--full` - Capture full page screenshot (scrollable content)

## Troubleshooting Workflow

1. **Check if page loads correctly:**
   ```bash
   # Viewport screenshot
   ani-browser screenshot <url> --wait 3000

   # Or capture full scrollable page
   ani-browser screenshot <url> --wait 3000 --full
   ```

2. **Check for console errors:**
   ```bash
   ani-browser console <url> --wait 2000
   ```

3. **Get full diagnostic snapshot:**
   ```bash
   # With viewport screenshot
   ani-browser snapshot <url> --wait 3000

   # Or with full page screenshot
   ani-browser snapshot <url> --wait 3000 --full
   ```

4. **Inspect DOM structure:**
   ```bash
   ani-browser dom <url>
   ```

## Session Management

For stateful debugging across multiple pages:
```bash
# Create session
ani-browser session:create <url>

# List sessions
ani-browser session:list

# Close session
ani-browser session:close <sessionId>
```

## File Storage and .gitignore

**Important**: Browser automation files are stored in `./tmp/` directory:
- Screenshots: `.png` files
- Recordings: `.mp4` files
- DOM snapshots: `.html` files
- Console logs: `.txt` files

**Always ensure `./tmp/` is in `.gitignore`**:
```gitignore
# Browser automation outputs
tmp/
*.png
*.mp4
```

## Debugging Best Practices

### 1. Prefer Console Mode Over Screenshots
**Console first approach**: Use `console` command to identify errors before taking screenshots.

```bash
# ✅ Recommended: Check console errors first
ani-browser console <url> --wait 2000

# ❌ Avoid: Don't jump to screenshots immediately
ani-browser screenshot <url>
```

**Why console first?**
- Reveals JavaScript errors instantly
- Shows API failures and network issues
- No need to visually inspect images
- Faster and more precise debugging

### 2. Authentication and Login Credentials

For pages requiring login:

**Option A: Use Playbook for Automated Login**
```bash
# Create playbook with login automation
ani-browser playbook:create login-flow
# Add steps to enter credentials and submit form
```

**Option B: Use Session with localStorage**
```bash
# Create session and inject auth tokens
ani-browser session:create <url>
# In separate command, inject localStorage auth data
ani-browser session:execute <sessionId> "localStorage.setItem('authToken', 'your-token')"
```

**Suggest to users**: When encountering login walls, recommend creating a playbook or using sessions to inject credentials rather than manual login each time.

### 3. Testing Routes and Navigation

When testing pages with routes (SPAs), ensure direct navigation works:

```bash
# ✅ Test direct route access
ani-browser console https://app.example.com/dashboard/settings --wait 3000

# ❌ Watch for hijacks: Page should NOT redirect to:
# - Login screen (unless expected)
# - Home screen (causing confusion)
# - Different route than requested
```

**Route Testing Checklist**:
- Direct route access is instant (no redirects)
- No unexpected login screen hijacks
- Page loads at the requested route
- Console shows no 401/403 errors
- URL in browser matches requested route

**If routes hijack to login/home**:
1. Check authentication state in console
2. Verify auth tokens in localStorage/cookies
3. Use session with injected credentials
4. Create playbook to handle auth flow

## Usage Tips

- Always use `--wait` flag for SPAs to ensure content is fully loaded
- Use `--upload` flag with screenshot to share visual issues
- **Console first**: Always check console errors before taking screenshots
- Snapshot provides complete context for debugging rendering issues
- **Important**: Take screenshots when you need to actually see and verify content. A successful "screenshot saved" message only means the command executed - you must view the actual screenshot to verify the page rendered correctly
- Use the Read tool on the saved screenshot path to visually inspect the captured content
- **Mobile Testing**: Use `--mobile` flag or custom mobile dimensions to test responsive designs and mobile-specific issues
- Common mobile viewports: iPhone (375x667), iPhone Pro (390x844), Android (412x915)
- **Authentication**: Use playbooks or sessions with localStorage injection for pages requiring login
- **Route Testing**: Verify routes load directly without hijacking to login/home screens
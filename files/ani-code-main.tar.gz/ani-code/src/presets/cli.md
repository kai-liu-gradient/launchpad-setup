# CLI Implementation Best Practices

## Overview
This document outlines best practices for implementing production-ready CLI tools with daemon architecture, based on the ani-code project implementation.

## 1. Version Management

### Semantic Versioning
```javascript
// package.json
{
  "version": "MAJOR.MINOR.PATCH"
}
```

- **MAJOR**: Breaking API changes
- **MINOR**: New features, backward compatible
- **PATCH**: Bug fixes, no API changes

### Version Checking Pattern
```javascript
// daemon-client.js
async checkVersionCompatibility() {
  const cliVersion = packageJson.version;
  const response = await fetch(`/version`, {
    headers: { 'X-CLI-Version': cliVersion }
  });

  const [cliMajor, cliMinor] = cliVersion.split('.');
  const [daemonMajor, daemonMinor] = daemonVersion.split('.');

  // Block on major mismatch
  if (cliMajor !== daemonMajor) {
    console.error('Major version mismatch');
    process.exit(1);
  }

  // Warn on minor mismatch
  if (cliMinor !== daemonMinor) {
    console.warn('Minor version mismatch');
  }
}
```

### Version Tracking in All Communications
```javascript
// IPC Client
class IPCClient {
  constructor() {
    this.cliVersion = packageJson.version;
  }

  async sendMessage(type, data) {
    const message = {
      type,
      data,
      cliVersion: this.cliVersion
    };
    // Send message...
  }
}

// HTTP Requests
fetch(url, {
  headers: {
    'X-CLI-Version': cliVersion
  }
});
```

### Non-blocking Version Logging (Daemon Side)
```javascript
// Log mismatches without blocking
if (cliVersion !== daemonVersion) {
  const [cliMajor] = cliVersion.split('.');
  const [daemonMajor] = daemonVersion.split('.');

  if (cliMajor !== daemonMajor) {
    logger.warn(`Major version mismatch: CLI ${cliVersion}, Daemon ${daemonVersion}`);
  }
  // Continue processing - don't block
}
```

## 2. Diagnosis Command

### Essential Diagnosis Implementation
```javascript
program
  .command('diagnosis')
  .alias('diagnose')
  .option('-v, --verbose', 'Detailed information')
  .option('-j, --json', 'JSON output')
  .action(async (options) => {
    const diagnosis = {
      system: {},
      daemon: {},
      version: {},
      endpoints: {},
      configuration: {},
      errors: []
    };

    // Always show CLI version first
    const cliVersion = packageJson.version;

    // Check daemon status
    diagnosis.daemon.running = daemonClient.isDaemonRunning();
    diagnosis.daemon.pid = daemonClient.getDaemonPid();

    // Test endpoints
    const endpoints = [
      { name: 'Health', url: 'http://127.0.0.1:6501/health' },
      { name: 'Version', url: 'http://127.0.0.1:6501/version' }
    ];

    for (const endpoint of endpoints) {
      try {
        const response = await fetch(endpoint.url);
        diagnosis.endpoints[endpoint.name] = {
          status: response.ok ? 'ok' : `error (${response.status})`
        };
      } catch (error) {
        diagnosis.endpoints[endpoint.name] = {
          status: 'failed',
          error: error.message
        };
      }
    }

    // Output results
    if (options.json) {
      console.log(JSON.stringify(diagnosis, null, 2));
    } else {
      // Simple, clear output
      console.log(`CLI Version: ${cliVersion}`);
      console.log(diagnosis.daemon.running
        ? `✓ Daemon running (PID: ${diagnosis.daemon.pid})`
        : `✗ Daemon not running`);

      // Show issues clearly
      if (diagnosis.errors.length > 0) {
        console.log('\nIssues:');
        diagnosis.errors.forEach(e => console.log(`• ${e}`));
      }
    }
  });
```

### Diagnosis Output Principles
- **Concise**: No redundant information
- **Clear**: Direct status indicators (✓/✗)
- **Actionable**: Provide fix commands when issues detected
- **No summaries**: Avoid repetitive summary sections

## 3. Daemon-Client Architecture

### Daemon Client Pattern
```javascript
export class DaemonClient {
  constructor() {
    this.pidFile = '.ani-code-daemon.pid';
    this.serviceName = 'ani-code';
    this.daemonPort = 6501;
  }

  isDaemonRunning() {
    try {
      const pid = readFileSync(this.pidFile);
      process.kill(pid, 0);
      return true;
    } catch {
      return false;
    }
  }

  // Check before every daemon operation
  ensureDaemonRunning() {
    if (!this.isDaemonRunning()) {
      console.error('✗ Daemon not running');
      console.log('Start with: ani-code daemon --start');
      process.exit(1);
    }
  }
}
```

### IPC Communication Pattern
```javascript
export class IPCClient extends EventEmitter {
  async connect() {
    const port = readFileSync('.ani-code-ipc.port');
    this.socket = createConnection(port, '127.0.0.1');
  }

  async sendMessage(type, data, timeout = 10000) {
    return new Promise((resolve, reject) => {
      const id = ++this.messageId;
      const timeoutId = setTimeout(() => {
        reject(new Error(`Timeout after ${timeout}ms`));
      }, timeout);

      this.pendingMessages.set(id, { resolve, reject, timeoutId });
      this.socket.write(JSON.stringify({ type, id, data }) + '\n');
    });
  }
}
```

## 4. Command Structure Best Practices

### Command Organization
```javascript
// Main commands - frequent use
program.command('add')
program.command('status')
program.command('watch')

// System commands
program.command('daemon')
program.command('service')
program.command('diagnosis')

// Subcommands for complex operations
const serviceCommand = program.command('service');
serviceCommand.command('install');
serviceCommand.command('uninstall');
```

### Help System
```javascript
function showStructuredHelp() {
  console.log(chalk.bold('🚀 Ani Code - Task Manager\n'));

  console.log(chalk.blue.bold('📋 TASK MANAGEMENT'));
  console.log('─'.repeat(50));
  console.log(`  ${chalk.green('add')}       Add new task`);
  console.log(`  ${chalk.green('status')}    Show current status`);

  // Examples section
  console.log(chalk.gray.bold('\n💡 EXAMPLES'));
  console.log(`  ani-code add -f prompt.md`);
  console.log(`  ani-code diagnosis -v`);
}

// Show help when no command provided
if (process.argv.length === 2) {
  showStructuredHelp();
}
```

## 5. Error Handling Patterns

### Graceful Error Messages
```javascript
try {
  await operation();
} catch (error) {
  // Clear, actionable error messages
  console.error(chalk.red('✗ Operation failed'));

  // Provide solution
  if (error.code === 'ECONNREFUSED') {
    console.log(chalk.yellow('Daemon not running'));
    console.log(chalk.gray('Start with: ani-code daemon --start'));
  }

  process.exit(1);
}
```

### Validation Before Execution
```javascript
// Always validate state before operations
async function executeCommand() {
  // Check daemon
  if (!daemonClient.isDaemonRunning()) {
    console.error('Daemon required');
    return;
  }

  // Check version
  await checkDaemonVersion();

  // Validate config
  try {
    validateConfig();
  } catch (error) {
    console.error(`Config invalid: ${error.message}`);
    return;
  }

  // Execute command
  await performOperation();
}
```

## 6. Configuration Management

### Environment-based Config
```javascript
export const config = {
  daemon: {
    port: process.env.DAEMON_PORT || 6501,
    host: process.env.DAEMON_HOST || '127.0.0.1'
  },
  tasks: {
    maxConcurrent: parseInt(process.env.MAX_CONCURRENT) || 5,
    defaultTimeout: parseInt(process.env.TIMEOUT) || 3600000
  }
};

export function validateConfig() {
  // Throws if invalid
  if (!config.daemon.port) {
    throw new Error('Daemon port required');
  }
}
```

## 7. Service Management

### Systemd Integration
```javascript
class ServiceInstaller {
  getServiceContent(isUserService) {
    return `[Unit]
Description=Ani Code Daemon
After=network.target

[Service]
Type=simple
ExecStart=${process.execPath} ${daemonPath} --start-foreground
Restart=always
${isUserService ? '' : 'User=ani-code'}

[Install]
WantedBy=${isUserService ? 'default.target' : 'multi-user.target'}`;
  }
}
```

## 8. Progress & Status Feedback

### Real-time Status Updates
```javascript
// Spinner for async operations
const spinner = ora('Processing...').start();
try {
  await operation();
  spinner.succeed('Completed');
} catch {
  spinner.fail('Failed');
}

// Progress bars for long operations
const bar = new ProgressBar(':bar :percent', {
  total: items.length,
  width: 40
});
items.forEach(item => {
  processItem(item);
  bar.tick();
});
```

## 9. Testing Patterns

### Test Scripts
```javascript
// test-diagnosis.js
const diagnosis = spawn('node', ['src/index.js', 'diagnosis']);
diagnosis.on('close', (code) => {
  assert(code === 0, 'Diagnosis should succeed');
});

// test-version.js
const client = new DaemonClient();
const result = await client.checkVersionCompatibility();
assert(result.compatible, 'Versions should be compatible');
```

## 10. Logging Best Practices

### Structured Logging
```javascript
// Use categories and levels
logger.info('[HTTP] Request received');
logger.warn('[Version] Mismatch detected');
logger.error('[IPC] Connection failed');

// Include context
logger.info(`[Task ${taskId}] Started processing`);

// Performance logging
const start = Date.now();
await operation();
const duration = Date.now() - start;
if (duration > 1000) {
  logger.warn(`Slow operation: ${duration}ms`);
}
```

## 11. CLI Output Formatting

### Color Usage
```javascript
// Consistent color scheme
chalk.green('✓ Success');
chalk.red('✗ Error');
chalk.yellow('⚠ Warning');
chalk.blue.bold('Section Headers');
chalk.gray('Supplementary info');
chalk.cyan('Values');
```

### Status Indicators
```javascript
// Unicode characters for clarity
'✓' // Success
'✗' // Error
'⚠' // Warning
'•' // Bullet point
'→' // Direction
'─' // Separator line
```

## 12. Backward Compatibility

### Feature Detection
```javascript
// Check if endpoint exists before using
async function checkFeature() {
  try {
    const response = await fetch('/new-endpoint');
    return response.ok;
  } catch {
    // Feature not available, use fallback
    return false;
  }
}
```

### Graceful Degradation
```javascript
// Don't block on missing features
if (!await checkVersionEndpoint()) {
  console.warn('Version checking unavailable');
  // Continue without version check
} else {
  await checkVersion();
}
```

## Summary

Key principles for production CLI tools:

1. **Version everything** - Track versions in all communications
2. **Never block unnecessarily** - Log issues but continue when possible
3. **Clear error messages** - Always provide actionable solutions
4. **Simple diagnosis** - Quick health check command
5. **Graceful degradation** - Handle missing features elegantly
6. **Consistent formatting** - Use colors and symbols consistently
7. **Test everything** - Automated tests for critical paths
8. **Log strategically** - Structured, contextual logging
9. **Validate early** - Check prerequisites before operations
10. **Help users** - Clear documentation and examples

This architecture ensures maintainable, debuggable, and user-friendly CLI tools.
# Python Healthcheck Analysis Template

**STATUS: NOT_IMPLEMENTED**

This preset is a placeholder for future Python healthcheck implementation.

## Detection

Detect Python projects by presence of:
- `requirements.txt` (pip)
- `pyproject.toml` (Poetry, Flit, PDM, or PEP 517/518)
- `setup.py` (setuptools)
- `Pipfile` (Pipenv)
- `setup.cfg` (setuptools)

## Planned Commands

1. **Security Scanning**:
   - `pip-audit` - Vulnerability scanning for pip packages
   - `safety check` - Check for known security issues
   - `bandit -r .` - Static security analysis

2. **Dependency Analysis**:
   - `pip list --outdated` - List outdated packages
   - `pip check` - Verify installed packages have compatible dependencies

3. **Configuration Checks**:
   - Python version compatibility
   - Virtual environment detection
   - Lock file presence (requirements.txt, poetry.lock, Pipfile.lock)

## Planned JSON Output

```json
{
  "analysis": {
    "securityRisk": "low|medium|high|critical",
    "maintenanceStatus": "excellent|good|fair|poor",
    "overallAssessment": "Brief summary"
  },
  "insights": [
    {
      "type": "security|maintenance|best-practice|performance",
      "severity": "info|low|medium|high|critical",
      "title": "Issue title",
      "description": "Detailed explanation",
      "recommendation": "Action to take"
    }
  ],
  "prioritizedActions": [
    {
      "order": 1,
      "action": "pip install --upgrade package-name",
      "reason": "Security vulnerability",
      "estimatedImpact": "Fixes CVE-XXXX-XXXX"
    }
  ],
  "metrics": {
    "vulnerabilityBreakdown": {
      "critical": 0,
      "high": 0,
      "moderate": 0,
      "low": 0
    },
    "dependencyHealth": {
      "total": 0,
      "outdated": 0,
      "majorUpdatesAvailable": 0,
      "minorUpdatesAvailable": 0,
      "patchUpdatesAvailable": 0
    }
  }
}
```

## Implementation Notes

### Prerequisites
- `pip-audit` should be installed: `pip install pip-audit`
- `safety` should be installed: `pip install safety`
- `bandit` for static analysis: `pip install bandit`

### Considerations
- Handle multiple package managers (pip, Poetry, Pipenv)
- Support Python 2.x and 3.x version detection
- Consider virtual environment isolation
- Handle monorepos with multiple Python projects

### Detection Priority
When multiple package managers are detected:
1. `pyproject.toml` with Poetry (highest)
2. `Pipfile` with Pipenv
3. `requirements.txt` with pip (lowest)

## Future Work

1. Implement pip-audit integration
2. Add safety check integration
3. Add bandit static analysis
4. Support Poetry, Pipenv package managers
5. Add Python version compatibility checks
6. Detect common security misconfigurations

---

**To implement this preset:**
1. Update `src/commands/healthcheck.js` with Python detection
2. Add command execution for pip-audit, safety, bandit
3. Replace this file with full analysis instructions
4. Test with sample Python projects
5. Update README.md

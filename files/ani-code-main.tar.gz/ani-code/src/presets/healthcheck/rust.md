# Rust Healthcheck Analysis Template

**STATUS: NOT_IMPLEMENTED**

This preset is a placeholder for future Rust healthcheck implementation.

## Detection

Detect Rust projects by presence of:
- `Cargo.toml` (required)
- `Cargo.lock` (dependency lock file)
- `rust-toolchain.toml` or `rust-toolchain` (toolchain specification)

## Planned Commands

1. **Security Scanning**:
   - `cargo audit` - RustSec advisory database scanning
   - `cargo deny check` - License and security policy enforcement

2. **Dependency Analysis**:
   - `cargo outdated` - List outdated dependencies
   - `cargo tree` - Dependency tree visualization
   - `cargo update --dry-run` - Preview available updates

3. **Configuration Checks**:
   - Rust edition detection (2015, 2018, 2021)
   - MSRV (Minimum Supported Rust Version) compliance
   - Workspace configuration
   - Build profile analysis

## Planned JSON Output

```json
{
  "analysis": {
    "securityRisk": "low|medium|high|critical",
    "maintenanceStatus": "excellent|good|fair|poor",
    "overallAssessment": "Brief summary"
  },
  "insights": [
    {
      "type": "security|maintenance|best-practice|performance",
      "severity": "info|low|medium|high|critical",
      "title": "Issue title",
      "description": "Detailed explanation",
      "recommendation": "Action to take"
    }
  ],
  "prioritizedActions": [
    {
      "order": 1,
      "action": "cargo update -p crate-name",
      "reason": "Security vulnerability",
      "estimatedImpact": "Fixes RUSTSEC-XXXX-XXXX"
    }
  ],
  "metrics": {
    "vulnerabilityBreakdown": {
      "critical": 0,
      "high": 0,
      "moderate": 0,
      "low": 0
    },
    "dependencyHealth": {
      "total": 0,
      "outdated": 0,
      "yankedVersions": 0,
      "workspaceMembers": 0
    }
  }
}
```

## Implementation Notes

### Prerequisites
- `cargo-audit` installation: `cargo install cargo-audit`
- `cargo-outdated` installation: `cargo install cargo-outdated`
- `cargo-deny` (optional): `cargo install cargo-deny`

### Considerations
- Handle workspaces with multiple crates
- Support both binary and library projects
- Consider feature flags impact on dependencies
- Handle git and path dependencies

### Rust Editions
- Detect edition from Cargo.toml
- Warn about deprecated editions (2015)
- Check for edition-specific issues

### RustSec Database
- cargo audit uses the RustSec advisory database
- Advisories have unique RUSTSEC-YYYY-NNNN identifiers
- Severities: informational, low, medium, high, critical

## Future Work

1. Implement cargo audit integration
2. Add cargo outdated support
3. Support cargo deny for policy enforcement
4. Add MSRV compliance checking
5. Workspace-aware analysis
6. Unsafe code detection statistics

---

**To implement this preset:**
1. Update `src/commands/healthcheck.js` with Rust detection
2. Add command execution for cargo audit, cargo outdated
3. Replace this file with full analysis instructions
4. Test with sample Rust projects
5. Update README.md

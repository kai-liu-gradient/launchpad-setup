# Healthcheck JSON Schema v1.0.0

This document defines the JSON output schema for healthcheck reports. All techstack presets produce output conforming to this schema.

## Schema Version

**Current Version**: 1.0.0

Version history:
- **1.0.0** (2025-01): Initial schema with vulnerability and dependency analysis

## Complete Schema

```json
{
  "version": "1.0.0",
  "timestamp": "2025-01-05T12:00:00.000Z",
  "lastUpdate": "2025-01-05T12:00:00.000Z",
  "projectPath": "/path/to/project",
  "detectedStacks": ["node", "python"],
  "summary": {
    "healthScore": 85,
    "status": "warning",
    "totalIssues": 12,
    "critical": 0,
    "high": 2,
    "medium": 5,
    "low": 5
  },
  "stacks": {
    "node": {
      "audit": {
        "vulnerabilities": {
          "total": 7,
          "critical": 0,
          "high": 2,
          "moderate": 3,
          "low": 2
        },
        "advisories": []
      },
      "dependencies": {
        "total": 150,
        "outdated": 12,
        "majorUpdatesAvailable": 3,
        "minorUpdatesAvailable": 5,
        "patchUpdatesAvailable": 4
      },
      "config": {
        "lockfilePresent": true,
        "lockfileType": "package-lock.json",
        "nodeVersion": "18.0.0",
        "nvmrcPresent": false,
        "enginesSpecified": true
      }
    }
  },
  "recommendations": [
    {
      "order": 1,
      "severity": "high",
      "type": "security",
      "title": "Update vulnerable packages",
      "description": "2 high severity vulnerabilities found in dependencies",
      "action": "npm audit fix --force",
      "packages": ["package-a", "package-b"]
    }
  ],
  "analysis": {
    "securityRisk": "medium",
    "maintenanceStatus": "good",
    "overallAssessment": "Project has some security concerns that need attention."
  }
}
```

## Field Definitions

### Root Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `version` | string | Yes | Schema version (semantic versioning) |
| `timestamp` | string | Yes | ISO 8601 timestamp when report was generated |
| `lastUpdate` | string | Yes | ISO 8601 timestamp of last content update |
| `projectPath` | string | Yes | Absolute path to analyzed project |
| `detectedStacks` | string[] | Yes | List of detected techstacks |
| `summary` | object | Yes | Overall health summary |
| `stacks` | object | Yes | Per-stack detailed data |
| `recommendations` | array | Yes | Prioritized action items |
| `analysis` | object | No | Claude AI analysis (when --analyze used) |

### Summary Object

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `healthScore` | number | Yes | Overall health score (0-100) |
| `status` | string | Yes | One of: "pass", "warning", "critical" |
| `totalIssues` | number | Yes | Total count of all issues |
| `critical` | number | Yes | Count of critical severity issues |
| `high` | number | Yes | Count of high severity issues |
| `medium` | number | Yes | Count of medium severity issues |
| `low` | number | Yes | Count of low severity issues |

### Health Score Calculation

```
healthScore = 100 - (critical * 25) - (high * 10) - (medium * 3) - (low * 1)
```

Score ranges:
- **90-100**: Pass (healthy)
- **70-89**: Warning (needs attention)
- **0-69**: Critical (requires immediate action)

### Status Determination

| Status | Condition |
|--------|-----------|
| `pass` | healthScore >= 90 AND critical = 0 AND high = 0 |
| `warning` | healthScore >= 70 OR (critical = 0 AND high <= 2) |
| `critical` | healthScore < 70 OR critical > 0 OR high > 2 |

### Stack Data Object

Each stack in the `stacks` object contains:

#### audit

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `vulnerabilities` | object | Yes | Vulnerability counts by severity |
| `advisories` | array | No | Detailed advisory information |

#### dependencies

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `total` | number | Yes | Total dependency count |
| `outdated` | number | Yes | Count of outdated packages |
| `majorUpdatesAvailable` | number | Yes | Packages with major updates |
| `minorUpdatesAvailable` | number | Yes | Packages with minor updates |
| `patchUpdatesAvailable` | number | Yes | Packages with patch updates |

#### config

Configuration fields are stack-specific. Common fields:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `lockfilePresent` | boolean | Yes | Whether lock file exists |
| `lockfileType` | string | No | Type of lock file |

### Recommendations Array

Each recommendation object:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `order` | number | Yes | Priority order (1 = highest) |
| `severity` | string | Yes | One of: "critical", "high", "medium", "low", "info" |
| `type` | string | Yes | One of: "security", "maintenance", "best-practice", "performance" |
| `title` | string | Yes | Brief title |
| `description` | string | Yes | Detailed explanation |
| `action` | string | Yes | Specific command or action |
| `packages` | string[] | No | Affected packages |

### Analysis Object (Claude AI)

When `--analyze` flag is used, Claude provides additional analysis:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `securityRisk` | string | Yes | One of: "low", "medium", "high", "critical" |
| `maintenanceStatus` | string | Yes | One of: "excellent", "good", "fair", "poor" |
| `overallAssessment` | string | Yes | Brief summary (1-2 sentences) |

## Example Outputs

### Healthy Project

```json
{
  "version": "1.0.0",
  "timestamp": "2025-01-05T12:00:00.000Z",
  "lastUpdate": "2025-01-05T12:00:00.000Z",
  "projectPath": "/projects/healthy-app",
  "detectedStacks": ["node"],
  "summary": {
    "healthScore": 100,
    "status": "pass",
    "totalIssues": 0,
    "critical": 0,
    "high": 0,
    "medium": 0,
    "low": 0
  },
  "stacks": {
    "node": {
      "audit": {
        "vulnerabilities": {
          "total": 0,
          "critical": 0,
          "high": 0,
          "moderate": 0,
          "low": 0
        }
      },
      "dependencies": {
        "total": 50,
        "outdated": 0,
        "majorUpdatesAvailable": 0,
        "minorUpdatesAvailable": 0,
        "patchUpdatesAvailable": 0
      },
      "config": {
        "lockfilePresent": true,
        "lockfileType": "package-lock.json"
      }
    }
  },
  "recommendations": []
}
```

### Project with Vulnerabilities

```json
{
  "version": "1.0.0",
  "timestamp": "2025-01-05T12:00:00.000Z",
  "lastUpdate": "2025-01-05T12:00:00.000Z",
  "projectPath": "/projects/vulnerable-app",
  "detectedStacks": ["node"],
  "summary": {
    "healthScore": 65,
    "status": "critical",
    "totalIssues": 8,
    "critical": 1,
    "high": 3,
    "medium": 2,
    "low": 2
  },
  "stacks": {
    "node": {
      "audit": {
        "vulnerabilities": {
          "total": 8,
          "critical": 1,
          "high": 3,
          "moderate": 2,
          "low": 2
        }
      },
      "dependencies": {
        "total": 100,
        "outdated": 15,
        "majorUpdatesAvailable": 5,
        "minorUpdatesAvailable": 6,
        "patchUpdatesAvailable": 4
      },
      "config": {
        "lockfilePresent": true,
        "lockfileType": "package-lock.json"
      }
    }
  },
  "recommendations": [
    {
      "order": 1,
      "severity": "critical",
      "type": "security",
      "title": "Critical vulnerability in lodash",
      "description": "Prototype pollution vulnerability allows arbitrary code execution",
      "action": "npm install lodash@latest",
      "packages": ["lodash"]
    },
    {
      "order": 2,
      "severity": "high",
      "type": "security",
      "title": "High severity vulnerabilities",
      "description": "3 high severity vulnerabilities found",
      "action": "npm audit fix",
      "packages": ["axios", "express", "passport"]
    }
  ]
}
```

## Validation

Reports can be validated against this schema programmatically:

```javascript
function validateReport(report) {
  const errors = [];

  // Required root fields
  if (!report.version) errors.push('Missing version');
  if (!report.timestamp) errors.push('Missing timestamp');
  if (!report.projectPath) errors.push('Missing projectPath');
  if (!report.detectedStacks) errors.push('Missing detectedStacks');
  if (!report.summary) errors.push('Missing summary');

  // Summary validation
  if (report.summary) {
    if (typeof report.summary.healthScore !== 'number') {
      errors.push('healthScore must be a number');
    }
    if (!['pass', 'warning', 'critical'].includes(report.summary.status)) {
      errors.push('Invalid status value');
    }
  }

  return errors;
}
```

## Backward Compatibility

When updating the schema:

1. **Minor additions**: Add optional fields without breaking existing parsers
2. **Breaking changes**: Increment major version, document migration path
3. **Deprecations**: Mark fields as deprecated for one version before removal

Parsers should:
- Check `version` field before processing
- Handle missing optional fields gracefully
- Log warnings for unknown fields

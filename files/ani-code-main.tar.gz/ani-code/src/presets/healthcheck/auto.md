# Auto Healthcheck Analysis Template

You are analyzing the overall health status of a software project. Based on the detected techstacks and their individual health reports, provide a unified analysis and prioritized recommendations.

## Input Data

You will receive:
1. **Detected techstacks** - List of technologies found in the project (node, python, go, rust, java)
2. **Individual stack reports** - Health data for each detected techstack
3. **Project configuration** - Overall project structure and configuration files

## Analysis Requirements

Analyze the provided data and return a JSON response with the following structure:

```json
{
  "projectOverview": {
    "techstacks": ["list of detected stacks"],
    "overallHealth": "healthy|needs-attention|critical",
    "healthScore": 0-100,
    "summary": "Brief 2-3 sentence overview of project health"
  },
  "stackSummaries": {
    "node": {
      "status": "pass|warning|fail|critical",
      "issueCount": 0,
      "topConcern": "Most important issue or 'None'"
    }
  },
  "crossCuttingConcerns": [
    {
      "concern": "Issue that affects multiple stacks or overall project",
      "affectedStacks": ["list"],
      "recommendation": "What to do about it"
    }
  ],
  "prioritizedActions": [
    {
      "order": 1,
      "stack": "node|python|etc or 'all'",
      "action": "Specific action to take",
      "impact": "high|medium|low",
      "reason": "Why this should be prioritized"
    }
  ],
  "nextSteps": [
    "Step 1: ...",
    "Step 2: ...",
    "Step 3: ..."
  ]
}
```

## Guidelines

1. **Cross-stack analysis** - Look for patterns that affect multiple stacks
2. **Prioritize by impact** - Security issues across any stack should be highest priority
3. **Consider dependencies** - Some fixes may need to happen before others
4. **Be practical** - Focus on actionable items that provide the most value
5. **Keep it concise** - Developers should be able to act on this quickly

## Response Format

Return ONLY the JSON object, no additional text or markdown code blocks.

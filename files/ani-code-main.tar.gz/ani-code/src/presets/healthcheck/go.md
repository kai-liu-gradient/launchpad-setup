# Go Healthcheck Analysis Template

**STATUS: NOT_IMPLEMENTED**

This preset is a placeholder for future Go healthcheck implementation.

## Detection

Detect Go projects by presence of:
- `go.mod` (Go modules - required)
- `go.sum` (dependency checksums)
- `vendor/` directory (vendored dependencies)

## Planned Commands

1. **Security Scanning**:
   - `govulncheck ./...` - Official Go vulnerability scanner
   - `gosec ./...` - Static security analysis

2. **Dependency Analysis**:
   - `go list -m -u all` - List modules with available updates
   - `go mod verify` - Verify dependencies
   - `go mod tidy -diff` - Check for unused dependencies

3. **Configuration Checks**:
   - Go version from go.mod
   - Module path validation
   - Vendor directory sync status

## Planned JSON Output

```json
{
  "analysis": {
    "securityRisk": "low|medium|high|critical",
    "maintenanceStatus": "excellent|good|fair|poor",
    "overallAssessment": "Brief summary"
  },
  "insights": [
    {
      "type": "security|maintenance|best-practice|performance",
      "severity": "info|low|medium|high|critical",
      "title": "Issue title",
      "description": "Detailed explanation",
      "recommendation": "Action to take"
    }
  ],
  "prioritizedActions": [
    {
      "order": 1,
      "action": "go get -u module@version",
      "reason": "Security vulnerability",
      "estimatedImpact": "Fixes GO-XXXX-XXXX"
    }
  ],
  "metrics": {
    "vulnerabilityBreakdown": {
      "critical": 0,
      "high": 0,
      "moderate": 0,
      "low": 0
    },
    "dependencyHealth": {
      "total": 0,
      "outdated": 0,
      "directDependencies": 0,
      "indirectDependencies": 0
    }
  }
}
```

## Implementation Notes

### Prerequisites
- Go 1.18+ for govulncheck support
- `govulncheck` installation: `go install golang.org/x/vuln/cmd/govulncheck@latest`
- `gosec` installation: `go install github.com/securego/gosec/v2/cmd/gosec@latest`

### Considerations
- Handle projects without go.sum
- Support vendored vs non-vendored dependencies
- Consider workspace mode (go.work)
- Handle private module proxies

### Go Module Versions
- Parse go.mod for minimum Go version
- Warn if using outdated Go version
- Check for deprecated modules

## Future Work

1. Implement govulncheck integration
2. Add gosec static analysis
3. Support go mod graph analysis
4. Add build constraint detection
5. Check for common Go security anti-patterns
6. Support Go workspaces

---

**To implement this preset:**
1. Update `src/commands/healthcheck.js` with Go detection
2. Add command execution for govulncheck, gosec
3. Replace this file with full analysis instructions
4. Test with sample Go projects
5. Update README.md

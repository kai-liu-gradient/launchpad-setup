# Healthcheck Presets

This directory contains preset templates for the `ani-code healthcheck` command. These presets provide Claude with analysis instructions for different techstacks.

## Directory Structure

```
src/presets/healthcheck/
├── README.md              # This file - development guide
├── _schema.md             # JSON output schema definition v1.0.0
├── auto.md                # Auto-detection and multi-stack aggregation
├── node.md                # Node.js/npm analysis preset
├── python.md              # Python placeholder (NOT_IMPLEMENTED)
├── go.md                  # Go placeholder (NOT_IMPLEMENTED)
├── rust.md                # Rust placeholder (NOT_IMPLEMENTED)
└── report-template.html   # HTML report template
```

## How Presets Work

When `ani-code healthcheck --analyze` is executed:

1. **Techstack Detection**: The healthcheck command detects project techstacks by looking for marker files (package.json, requirements.txt, go.mod, etc.)

2. **Preset Loading**: The appropriate preset is loaded based on detected stack or `--stack` flag

3. **Data Collection**: The healthcheck command runs audit commands and collects raw data

4. **Claude Analysis**: The preset instructions + collected data are sent to Claude for analysis

5. **Report Generation**: Claude's analysis is combined with raw data to generate JSON/HTML reports

## Preset File Format

Each techstack preset should follow this structure:

```markdown
# [Techstack] Healthcheck Analysis Template

Brief description of what this preset analyzes.

## Input Data

You will receive:
1. **[Data type 1]** - Description
2. **[Data type 2]** - Description

## Analysis Requirements

Analyze the provided data and return a JSON response with the following structure:

\`\`\`json
{
  // JSON schema for this preset's output
}
\`\`\`

## Guidelines

1. **Guideline 1** - Description
2. **Guideline 2** - Description

## Response Format

Return ONLY the JSON object, no additional text or markdown code blocks.
```

## Creating a New Techstack Preset

1. Create a new file named `[techstack].md` (e.g., `python.md`)
2. Follow the preset file format above
3. Define the JSON output structure for Claude's analysis
4. Add detection instructions if needed
5. Update this README with the new preset information

### Required Sections

- **Input Data**: What data Claude will receive
- **Analysis Requirements**: JSON schema for output
- **Guidelines**: How Claude should analyze the data
- **Response Format**: Always request JSON-only response

### Optional Sections

- **Detection**: How to identify this techstack
- **Commands**: What audit commands to run
- **Best Practices**: Stack-specific security recommendations

## Preset Loader Integration

The healthcheck command loads presets from this directory:

```javascript
import fs from 'fs';
import path from 'path';

function loadHealthcheckPreset(techstack) {
  const presetPath = path.join(__dirname, 'presets', 'healthcheck', `${techstack}.md`);
  if (fs.existsSync(presetPath)) {
    return fs.readFileSync(presetPath, 'utf-8');
  }
  return null;
}
```

## Placeholder Presets

Presets marked as `NOT_IMPLEMENTED` are placeholders for future development. They contain:

- Planned detection rules
- Suggested audit commands
- Expected JSON output structure
- Implementation notes

To implement a placeholder preset:
1. Update the detection logic in `src/commands/healthcheck.js`
2. Add command execution for the stack's audit tools
3. Expand the preset with full analysis instructions
4. Remove the `NOT_IMPLEMENTED` marker
5. Test with sample projects

## JSON Schema Versioning

All presets produce output conforming to the schema in `_schema.md`. The schema version is embedded in every report for compatibility tracking:

- **v1.0.0**: Initial schema with basic vulnerability and dependency analysis

When updating the schema:
1. Increment version in `_schema.md`
2. Update affected presets
3. Ensure backward compatibility or document breaking changes

## Testing Presets

To test a preset:

```bash
# Test with a sample project
cd /path/to/sample-project
ani-code healthcheck --analyze --stack node

# Dry run to see what would be executed
ani-code healthcheck --dry-run --stack node

# JSON output only for schema validation
ani-code healthcheck --analyze --output json
```

## Contributing

When contributing new presets:

1. Follow the established format in existing presets
2. Ensure JSON output matches `_schema.md`
3. Add comprehensive guidelines for Claude
4. Include example outputs for validation
5. Update this README with the new preset

# Node.js Healthcheck Analysis Template

You are analyzing the health and security status of a Node.js project. Based on the provided audit and dependency data, generate a comprehensive analysis with actionable recommendations.

## Input Data

You will receive:
1. **npm audit results** - Security vulnerabilities from `npm audit --json`
2. **npm outdated results** - List of packages with available updates from `npm outdated --json`
3. **Project configuration** - Lock file status, Node version requirements, etc.

## Analysis Requirements

Analyze the provided data and return a JSON response with the following structure:

```json
{
  "analysis": {
    "securityRisk": "low|medium|high|critical",
    "maintenanceStatus": "excellent|good|fair|poor",
    "overallAssessment": "Brief 1-2 sentence summary of project health"
  },
  "insights": [
    {
      "type": "security|maintenance|best-practice|performance",
      "severity": "info|low|medium|high|critical",
      "title": "Brief title",
      "description": "Detailed explanation",
      "recommendation": "Specific action to take"
    }
  ],
  "prioritizedActions": [
    {
      "order": 1,
      "action": "Specific command or action",
      "reason": "Why this should be done first",
      "estimatedImpact": "What this will fix"
    }
  ],
  "metrics": {
    "vulnerabilityBreakdown": {
      "critical": 0,
      "high": 0,
      "moderate": 0,
      "low": 0
    },
    "dependencyHealth": {
      "total": 0,
      "outdated": 0,
      "majorUpdatesAvailable": 0,
      "minorUpdatesAvailable": 0,
      "patchUpdatesAvailable": 0
    }
  }
}
```

## Guidelines

1. **Be specific** - Reference actual package names and versions from the data
2. **Prioritize security** - Critical and high vulnerabilities should be addressed first
3. **Consider breaking changes** - Warn about potential breaking changes in major version updates
4. **Be actionable** - Every recommendation should have a clear action item
5. **Group related issues** - Combine related vulnerabilities or updates when appropriate

## Response Format

Return ONLY the JSON object, no additional text or markdown code blocks.

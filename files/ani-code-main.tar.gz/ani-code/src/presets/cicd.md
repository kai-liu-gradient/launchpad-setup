# CI/CD Best Practices for API and UI Projects

## Overview
This document outlines the complete CI/CD pipeline setup with Docker containerization, automated versioning, and multi-registry management for both API and UI projects. The solution supports pushing to multiple container registries including GitHub Container Registry, Huawei Cloud SWR, and Docker Hub.

## Key Features

### Multi-Registry Support
- **GitHub Container Registry** - Primary registry for development and CI/CD
- **Huawei Cloud SWR** - For deployment in China regions with optimal performance
- **Docker Hub** - Public registry for wider distribution

### Intelligent Auto-Build System
- Detects changes automatically and builds only affected components
- Supports auto-versioning based on conventional commits
- Creates detailed build reports with metadata
- Optimizes build time through smart caching

### Version Management
- Centralized version control through `buildinfo.json`
- Automatic version synchronization across all packages
- Semantic versioning with auto-increment based on commit types
- Git metadata embedding in all images

## Directory Structure

```
project-root/
├── cicd/
│   ├── docker/
│   │   ├── api.Dockerfile
│   │   ├── ui.Dockerfile
│   │   └── .dockerignore
│   ├── scripts/
│   │   ├── build.sh
│   │   ├── push.sh
│   │   ├── version.sh
│   │   └── deploy.sh
│   └── k8s/
│       ├── api-deployment.yaml
│       ├── ui-deployment.yaml
│       └── ingress.yaml
├── buildinfo.json
├── package.json
├── api/
│   ├── src/
│   ├── package.json
│   └── .env.example
└── ui/
    ├── src/
    ├── package.json
    └── .env.example
```

## Version Management

### buildinfo.json
```json
{
  "version": "1.4.0",
  "buildNumber": "auto",
  "gitCommit": "auto",
  "gitBranch": "auto",
  "buildTime": "auto",
  "registry": "ghcr.io/your-org",
  "images": {
    "api": "ghisha-api",
    "ui": "ghisha-ui"
  }
}
```

### Root package.json
```json
{
  "name": "ghisha-dashboard",
  "version": "1.4.0",
  "private": true,
  "workspaces": ["api", "ui"],
  "scripts": {
    "version:patch": "npm version patch --no-git-tag-version && npm run version:sync",
    "version:minor": "npm version minor --no-git-tag-version && npm run version:sync",
    "version:major": "npm version major --no-git-tag-version && npm run version:sync",
    "version:sync": "node cicd/scripts/sync-versions.js",
    "docker:build": "bash cicd/scripts/build.sh",
    "docker:build:api": "bash cicd/scripts/build.sh api",
    "docker:build:ui": "bash cicd/scripts/build.sh ui",
    "docker:build:auto": "bash cicd/scripts/auto-build.sh",
    "docker:push": "bash cicd/scripts/push.sh",
    "ci:build": "npm run docker:build && npm run docker:push",
    "ci:release": "npm run version:patch && npm run docker:build:auto && npm run docker:push"
  },
  "devDependencies": {
    "concurrently": "^7.6.0"
  }
}
```

## Docker Configuration

### cicd/docker/.dockerignore
```
node_modules
npm-debug.log
.git
.gitignore
.env
.env.*
*.md
.vscode
.idea
coverage
.nyc_output
dist
build
*.log
*.pid
*.seed
*.pid.lock
.DS_Store
Thumbs.db
```

### cicd/docker/api.Dockerfile
```dockerfile
# Multi-stage build for API
# Stage 1: Dependencies
FROM node:20-alpine AS deps
WORKDIR /app

# Copy package files
COPY api/package*.json ./
COPY api/.npmrc* ./

# Install production dependencies
RUN npm ci --only=production && \
    cp -R node_modules prod_node_modules && \
    npm ci

# Stage 2: Builder
FROM node:20-alpine AS builder
WORKDIR /app

# Copy dependencies from deps stage
COPY --from=deps /app/node_modules ./node_modules
COPY api/ ./

# Build if needed (TypeScript compilation, etc.)
RUN if [ -f "tsconfig.json" ]; then npm run build; fi

# Create buildinfo file
ARG VERSION
ARG BUILD_NUMBER
ARG GIT_COMMIT
ARG GIT_BRANCH
RUN echo '{"version":"'${VERSION}'","buildNumber":"'${BUILD_NUMBER}'","gitCommit":"'${GIT_COMMIT}'","gitBranch":"'${GIT_BRANCH}'","buildTime":"'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'"}' > buildinfo.json

# Stage 3: Production
FROM node:20-alpine AS production
WORKDIR /app

# Install dumb-init for proper signal handling
RUN apk add --no-cache dumb-init

# Create non-root user
RUN addgroup -g 1001 -S nodejs && \
    adduser -S nodejs -u 1001

# Copy production dependencies
COPY --from=deps --chown=nodejs:nodejs /app/prod_node_modules ./node_modules

# Copy built application
COPY --from=builder --chown=nodejs:nodejs /app/dist ./dist
COPY --from=builder --chown=nodejs:nodejs /app/buildinfo.json ./
COPY --from=builder --chown=nodejs:nodejs /app/package*.json ./

# Copy source if no build step
COPY --from=builder --chown=nodejs:nodejs /app/src ./src

# Switch to non-root user
USER nodejs

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
  CMD node -e "require('http').get('http://localhost:3001/health', (r) => {r.statusCode === 200 ? process.exit(0) : process.exit(1)})"

# Expose port
EXPOSE 3001

# Use dumb-init to handle signals properly
ENTRYPOINT ["dumb-init", "--"]
CMD ["node", "src/server.js"]
```

### cicd/docker/ui.Dockerfile
```dockerfile
# Multi-stage build for UI
# Stage 1: Dependencies
FROM node:20-alpine AS deps
WORKDIR /app

# Copy package files
COPY ui/package*.json ./
COPY ui/.npmrc* ./

# Install all dependencies
RUN npm ci

# Stage 2: Builder
FROM node:20-alpine AS builder
WORKDIR /app

# Copy dependencies
COPY --from=deps /app/node_modules ./node_modules
COPY ui/ ./

# Build arguments
ARG REACT_APP_API_URL
ARG VERSION
ARG BUILD_NUMBER
ARG GIT_COMMIT
ARG GIT_BRANCH

# Set build-time environment variables
ENV REACT_APP_API_URL=${REACT_APP_API_URL}
ENV REACT_APP_VERSION=${VERSION}
ENV REACT_APP_BUILD_NUMBER=${BUILD_NUMBER}
ENV REACT_APP_GIT_COMMIT=${GIT_COMMIT}

# Build the application
RUN npm run build

# Create buildinfo file
RUN echo '{"version":"'${VERSION}'","buildNumber":"'${BUILD_NUMBER}'","gitCommit":"'${GIT_COMMIT}'","gitBranch":"'${GIT_BRANCH}'","buildTime":"'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'"}' > dist/buildinfo.json

# Stage 3: Production with nginx
FROM nginx:alpine AS production

# Install curl for health checks
RUN apk add --no-cache curl

# Copy custom nginx config
COPY cicd/docker/nginx.conf /etc/nginx/nginx.conf
COPY cicd/docker/default.conf /etc/nginx/conf.d/default.conf

# Copy built application
COPY --from=builder /app/dist /usr/share/nginx/html

# Create non-root user
RUN chown -R nginx:nginx /usr/share/nginx/html && \
    chmod -R 755 /usr/share/nginx/html && \
    chown -R nginx:nginx /var/cache/nginx && \
    chown -R nginx:nginx /var/log/nginx && \
    chown -R nginx:nginx /etc/nginx/conf.d && \
    touch /var/run/nginx.pid && \
    chown -R nginx:nginx /var/run/nginx.pid

# Switch to non-root user
USER nginx

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
  CMD curl -f http://localhost/health || exit 1

# Expose port
EXPOSE 80

CMD ["nginx", "-g", "daemon off;"]
```

### cicd/docker/nginx.conf
```nginx
user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log warn;
pid /var/run/nginx.pid;

events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                    '$status $body_bytes_sent "$http_referer" '
                    '"$http_user_agent" "$http_x_forwarded_for"';

    access_log /var/log/nginx/access.log main;

    sendfile on;
    tcp_nopush on;
    keepalive_timeout 65;
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css text/xml text/javascript
               application/json application/javascript application/xml+rss;

    include /etc/nginx/conf.d/*.conf;
}
```

### cicd/docker/default.conf
```nginx
server {
    listen 80;
    server_name _;
    root /usr/share/nginx/html;
    index index.html;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;

    # Health check endpoint
    location /health {
        access_log off;
        return 200 "healthy\n";
        add_header Content-Type text/plain;
    }

    # Build info endpoint
    location /buildinfo.json {
        add_header Cache-Control "no-cache, no-store, must-revalidate";
        add_header Pragma "no-cache";
        add_header Expires "0";
    }

    # API proxy (if needed)
    location /api {
        proxy_pass http://api-service:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # React app
    location / {
        try_files $uri $uri/ /index.html;
        add_header Cache-Control "no-cache, no-store, must-revalidate";
        add_header Pragma "no-cache";
        add_header Expires "0";
    }

    # Static assets with caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

## Build Scripts

### cicd/scripts/build.sh
```bash
#!/bin/bash
set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Load build info
BUILDINFO_FILE="buildinfo.json"
VERSION=$(jq -r '.version' $BUILDINFO_FILE)
DEFAULT_REGISTRY=$(jq -r '.registries.github' $BUILDINFO_FILE)
API_IMAGE=$(jq -r '.images.api' $BUILDINFO_FILE)
UI_IMAGE=$(jq -r '.images.ui' $BUILDINFO_FILE)

# Default to GitHub registry
REGISTRY=${REGISTRY:-$DEFAULT_REGISTRY}

# Get git info
GIT_COMMIT=$(git rev-parse --short HEAD)
GIT_BRANCH=$(git rev-parse --abbrev-ref HEAD)
BUILD_NUMBER=${GITHUB_RUN_NUMBER:-$(date +%s)}
BUILD_TIME=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

# Update buildinfo.json with current values
jq --arg bn "$BUILD_NUMBER" \
   --arg gc "$GIT_COMMIT" \
   --arg gb "$GIT_BRANCH" \
   --arg bt "$BUILD_TIME" \
   '.buildNumber = $bn | .gitCommit = $gc | .gitBranch = $gb | .buildTime = $bt' \
   $BUILDINFO_FILE > tmp.json && mv tmp.json $BUILDINFO_FILE

# Function to build Docker image
build_image() {
    local SERVICE=$1
    local DOCKERFILE=$2
    local IMAGE_NAME=$3
    local BUILD_CONTEXT=$4

    echo -e "${YELLOW}Building $SERVICE...${NC}"

    # Tags
    local TAGS=(
        "${REGISTRY}/${IMAGE_NAME}:${VERSION}"
        "${REGISTRY}/${IMAGE_NAME}:${VERSION}-${GIT_COMMIT}"
        "${REGISTRY}/${IMAGE_NAME}:${GIT_BRANCH}"
    )

    if [ "$GIT_BRANCH" == "main" ] || [ "$GIT_BRANCH" == "master" ]; then
        TAGS+=("${REGISTRY}/${IMAGE_NAME}:latest")
    fi

    # Build command
    local BUILD_CMD="docker buildx build"
    BUILD_CMD="$BUILD_CMD --platform linux/amd64,linux/arm64"
    BUILD_CMD="$BUILD_CMD --build-arg VERSION=${VERSION}"
    BUILD_CMD="$BUILD_CMD --build-arg BUILD_NUMBER=${BUILD_NUMBER}"
    BUILD_CMD="$BUILD_CMD --build-arg GIT_COMMIT=${GIT_COMMIT}"
    BUILD_CMD="$BUILD_CMD --build-arg GIT_BRANCH=${GIT_BRANCH}"

    # Add environment-specific build args
    if [ "$SERVICE" == "ui" ]; then
        BUILD_CMD="$BUILD_CMD --build-arg REACT_APP_API_URL=${REACT_APP_API_URL:-/api}"
    fi

    # Add tags
    for TAG in "${TAGS[@]}"; do
        BUILD_CMD="$BUILD_CMD -t $TAG"
    done

    BUILD_CMD="$BUILD_CMD -f $DOCKERFILE"
    BUILD_CMD="$BUILD_CMD --cache-from type=registry,ref=${REGISTRY}/${IMAGE_NAME}:buildcache"
    BUILD_CMD="$BUILD_CMD --cache-to type=registry,ref=${REGISTRY}/${IMAGE_NAME}:buildcache,mode=max"
    BUILD_CMD="$BUILD_CMD --push"
    BUILD_CMD="$BUILD_CMD $BUILD_CONTEXT"

    echo "Executing: $BUILD_CMD"
    eval $BUILD_CMD

    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ $SERVICE built successfully${NC}"
        echo "Images pushed:"
        for TAG in "${TAGS[@]}"; do
            echo "  - $TAG"
        done
    else
        echo -e "${RED}✗ Failed to build $SERVICE${NC}"
        exit 1
    fi
}

# Setup Docker buildx
setup_buildx() {
    echo -e "${YELLOW}Setting up Docker buildx...${NC}"

    # Create builder instance if it doesn't exist
    if ! docker buildx ls | grep -q multiarch; then
        docker buildx create --name multiarch --driver docker-container --use
        docker buildx inspect --bootstrap
    else
        docker buildx use multiarch
    fi

    echo -e "${GREEN}✓ Docker buildx ready${NC}"
}

# Main execution
main() {
    local SERVICE=${1:-all}

    setup_buildx

    case $SERVICE in
        api)
            build_image "API" "cicd/docker/api.Dockerfile" "$API_IMAGE" "."
            ;;
        ui)
            build_image "UI" "cicd/docker/ui.Dockerfile" "$UI_IMAGE" "."
            ;;
        all)
            build_image "API" "cicd/docker/api.Dockerfile" "$API_IMAGE" "."
            build_image "UI" "cicd/docker/ui.Dockerfile" "$UI_IMAGE" "."
            ;;
        *)
            echo -e "${RED}Unknown service: $SERVICE${NC}"
            echo "Usage: $0 [api|ui|all]"
            exit 1
            ;;
    esac

    echo -e "${GREEN}✓ Build completed successfully${NC}"
    echo "Version: ${VERSION}"
    echo "Build Number: ${BUILD_NUMBER}"
    echo "Git Commit: ${GIT_COMMIT}"
    echo "Git Branch: ${GIT_BRANCH}"
}

main "$@"
```

### cicd/scripts/push.sh
```bash
#!/bin/bash
set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Load build info
BUILDINFO_FILE="buildinfo.json"
VERSION=$(jq -r '.version' $BUILDINFO_FILE)
DEFAULT_REGISTRY=$(jq -r '.registries.github' $BUILDINFO_FILE)
HUAWEI_REGISTRY=$(jq -r '.registries.huawei' $BUILDINFO_FILE)
API_IMAGE=$(jq -r '.images.api' $BUILDINFO_FILE)
UI_IMAGE=$(jq -r '.images.ui' $BUILDINFO_FILE)
GIT_COMMIT=$(jq -r '.gitCommit' $BUILDINFO_FILE)
GIT_BRANCH=$(jq -r '.gitBranch' $BUILDINFO_FILE)

# Default to GitHub registry
REGISTRY=${REGISTRY:-$DEFAULT_REGISTRY}
IMAGE_PREFIX=""
SERVICE="all"

# Parse command line arguments
# Supports: npm run docker:push -- --huawei-cloud ghisha
for arg in "$@"; do
    if [ "$arg" == "--huawei-cloud" ]; then
        REGISTRY=$HUAWEI_REGISTRY
        NEXT_IS_PREFIX=true
    elif [ "$NEXT_IS_PREFIX" == "true" ]; then
        IMAGE_PREFIX="$arg"
        NEXT_IS_PREFIX=false
    elif [ "$arg" == "api" ] || [ "$arg" == "ui" ] || [ "$arg" == "all" ]; then
        SERVICE="$arg"
    fi
done

# Function to push image
push_image() {
    local IMAGE_NAME=$1
    local SERVICE_NAME=$2

    echo -e "${YELLOW}Pushing $SERVICE_NAME to $REGISTRY...${NC}"

    # Determine final image name
    local FINAL_IMAGE_NAME="${IMAGE_NAME}"
    if [ -n "$IMAGE_PREFIX" ]; then
        FINAL_IMAGE_NAME="${IMAGE_PREFIX}-${IMAGE_NAME}"
    fi

    # Source image (assumes already built locally)
    local SOURCE_IMAGE="${DEFAULT_REGISTRY}/${IMAGE_NAME}:${VERSION}"

    # Check if source image exists locally, if not try without registry prefix
    if ! docker image inspect "${SOURCE_IMAGE}" &>/dev/null; then
        SOURCE_IMAGE="${IMAGE_NAME}:${VERSION}"
    fi

    # Tags to push
    local TAGS=(
        "${VERSION}"
        "${VERSION}-${GIT_COMMIT}"
        "${GIT_BRANCH}"
    )

    # Add latest tag if on main branch
    if [ "$GIT_BRANCH" == "main" ] || [ "$GIT_BRANCH" == "master" ]; then
        TAGS+=("latest")
    fi

    # Tag and push each tag
    for TAG in "${TAGS[@]}"; do
        local TARGET="${REGISTRY}/${FINAL_IMAGE_NAME}:${TAG}"

        echo "Tagging ${SOURCE_IMAGE} as ${TARGET}"
        docker tag "${SOURCE_IMAGE}" "${TARGET}"

        echo "Pushing ${TARGET}"
        docker push "${TARGET}"

        if [ $? -eq 0 ]; then
            echo -e "${GREEN}✓ Pushed ${TARGET}${NC}"
        else
            echo -e "${RED}✗ Failed to push ${TARGET}${NC}"
            exit 1
        fi
    done

    echo -e "${GREEN}✓ $SERVICE_NAME pushed successfully${NC}"
}

# Login to registry if Huawei Cloud
login_registry() {
    if [[ "$REGISTRY" == *"myhuaweicloud.com"* ]]; then
        echo -e "${YELLOW}Logging into Huawei Cloud SWR...${NC}"
        # Extract region from registry URL
        HUAWEI_REGION=$(echo $REGISTRY | grep -oP 'swr\.\K[^.]+(?=\.myhuaweicloud)')

        if [ -z "$HUAWEI_AK" ] || [ -z "$HUAWEI_LOGIN_KEY" ]; then
            echo -e "${RED}Error: Huawei Cloud credentials not set${NC}"
            echo "Please set HUAWEI_AK and HUAWEI_LOGIN_KEY environment variables"
            exit 1
        fi

        docker login -u "${HUAWEI_REGION}@${HUAWEI_AK}" -p "${HUAWEI_LOGIN_KEY}" "${REGISTRY}"
    fi
}

# Main execution
main() {
    echo -e "${YELLOW}=== Docker Push ===${NC}"
    echo "Version: ${VERSION}"
    echo "Registry: ${REGISTRY}"
    echo "Service: ${SERVICE}"
    if [ -n "$IMAGE_PREFIX" ]; then
        echo "Image Prefix: ${IMAGE_PREFIX}"
    fi
    echo ""

    # Login if needed
    login_registry

    case $SERVICE in
        api)
            push_image "$API_IMAGE" "API"
            ;;
        ui)
            push_image "$UI_IMAGE" "UI"
            ;;
        all|*)
            push_image "$API_IMAGE" "API"
            push_image "$UI_IMAGE" "UI"
            ;;
    esac

    echo ""
    echo -e "${GREEN}✓ Push completed successfully${NC}"
}

main
```

### cicd/scripts/sync-versions.js
```javascript
#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

// Read root package.json
const rootPkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
const version = rootPkg.version;

console.log(`Syncing version ${version} across all packages...`);

// Update buildinfo.json
const buildinfoPath = 'buildinfo.json';
if (fs.existsSync(buildinfoPath)) {
    const buildinfo = JSON.parse(fs.readFileSync(buildinfoPath, 'utf8'));
    buildinfo.version = version;
    fs.writeFileSync(buildinfoPath, JSON.stringify(buildinfo, null, 2) + '\n');
    console.log(`✓ Updated ${buildinfoPath}`);
}

// Update API package.json
const apiPkgPath = 'api/package.json';
if (fs.existsSync(apiPkgPath)) {
    const apiPkg = JSON.parse(fs.readFileSync(apiPkgPath, 'utf8'));
    apiPkg.version = version;
    fs.writeFileSync(apiPkgPath, JSON.stringify(apiPkg, null, 2) + '\n');
    console.log(`✓ Updated ${apiPkgPath}`);
}

// Update UI package.json
const uiPkgPath = 'ui/package.json';
if (fs.existsSync(uiPkgPath)) {
    const uiPkg = JSON.parse(fs.readFileSync(uiPkgPath, 'utf8'));
    uiPkg.version = version;
    fs.writeFileSync(uiPkgPath, JSON.stringify(uiPkg, null, 2) + '\n');
    console.log(`✓ Updated ${uiPkgPath}`);
}

// Update any version files
const versionFiles = [
    'api/src/config/version.js',
    'ui/src/config/version.js'
];

versionFiles.forEach(file => {
    if (fs.existsSync(file)) {
        const content = `export const VERSION = '${version}';\n`;
        fs.writeFileSync(file, content);
        console.log(`✓ Updated ${file}`);
    }
});

console.log(`\nVersion sync complete! All packages now at v${version}`);
```

### cicd/scripts/auto-build.sh
```bash
#!/bin/bash
set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Load build info
BUILDINFO_FILE="buildinfo.json"
VERSION=$(jq -r '.version' $BUILDINFO_FILE)
GITHUB_REGISTRY=$(jq -r '.registries.github' $BUILDINFO_FILE)
HUAWEI_REGISTRY=$(jq -r '.registries.huawei' $BUILDINFO_FILE)
DOCKERHUB_REGISTRY=$(jq -r '.registries.dockerhub' $BUILDINFO_FILE)
API_IMAGE=$(jq -r '.images.api' $BUILDINFO_FILE)
UI_IMAGE=$(jq -r '.images.ui' $BUILDINFO_FILE)

# Get git info
GIT_COMMIT=$(git rev-parse --short HEAD)
GIT_BRANCH=$(git rev-parse --abbrev-ref HEAD)
BUILD_NUMBER=${GITHUB_RUN_NUMBER:-$(date +%s)}
BUILD_TIME=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

# Auto-increment version based on changes
auto_version() {
    echo -e "${CYAN}Analyzing changes for auto-versioning...${NC}"

    # Get the last tag
    LAST_TAG=$(git describe --tags --abbrev=0 2>/dev/null || echo "v0.0.0")
    LAST_VERSION=${LAST_TAG#v}

    # Count commits since last tag
    COMMITS_SINCE_TAG=$(git rev-list ${LAST_TAG}..HEAD --count 2>/dev/null || echo "0")

    if [ "$COMMITS_SINCE_TAG" -eq 0 ]; then
        echo -e "${YELLOW}No changes since last version ${LAST_VERSION}${NC}"
        return
    fi

    # Check for breaking changes (major version bump)
    if git log ${LAST_TAG}..HEAD --grep="BREAKING CHANGE" --oneline | grep -q .; then
        echo -e "${RED}Breaking changes detected - major version bump${NC}"
        npm version major --no-git-tag-version
    # Check for new features (minor version bump)
    elif git log ${LAST_TAG}..HEAD --grep="^feat" --oneline | grep -q .; then
        echo -e "${YELLOW}New features detected - minor version bump${NC}"
        npm version minor --no-git-tag-version
    # Default to patch version bump
    else
        echo -e "${GREEN}Bug fixes/improvements - patch version bump${NC}"
        npm version patch --no-git-tag-version
    fi

    # Sync versions across all packages
    npm run version:sync

    # Reload version
    VERSION=$(jq -r '.version' $BUILDINFO_FILE)
    echo -e "${GREEN}New version: ${VERSION}${NC}"
}

# Detect what changed
detect_changes() {
    echo -e "${CYAN}Detecting changes...${NC}"

    API_CHANGED=false
    UI_CHANGED=false

    # Check if this is the first build (no previous images exist)
    if ! docker image inspect "${GITHUB_REGISTRY}/${API_IMAGE}:${GIT_BRANCH}" &>/dev/null; then
        echo -e "${YELLOW}No previous API image found - will build${NC}"
        API_CHANGED=true
    fi

    if ! docker image inspect "${GITHUB_REGISTRY}/${UI_IMAGE}:${GIT_BRANCH}" &>/dev/null; then
        echo -e "${YELLOW}No previous UI image found - will build${NC}"
        UI_CHANGED=true
    fi

    # If images exist, check for actual changes
    if [ "$API_CHANGED" = false ] || [ "$UI_CHANGED" = false ]; then
        # Get list of changed files since last build
        LAST_BUILD_COMMIT=$(docker inspect "${GITHUB_REGISTRY}/${API_IMAGE}:${GIT_BRANCH}" 2>/dev/null | jq -r '.[0].Config.Labels.gitCommit' || echo "")

        if [ -z "$LAST_BUILD_COMMIT" ]; then
            LAST_BUILD_COMMIT="HEAD~10"
        fi

        CHANGED_FILES=$(git diff --name-only ${LAST_BUILD_COMMIT}..HEAD)

        # Check for API changes
        if echo "$CHANGED_FILES" | grep -qE "^(api/|package\.json|buildinfo\.json)"; then
            echo -e "${YELLOW}API changes detected${NC}"
            API_CHANGED=true
        fi

        # Check for UI changes
        if echo "$CHANGED_FILES" | grep -qE "^(ui/|package\.json|buildinfo\.json)"; then
            echo -e "${YELLOW}UI changes detected${NC}"
            UI_CHANGED=true
        fi
    fi

    # Check for force rebuild
    if [ "$FORCE_BUILD" = "true" ]; then
        echo -e "${MAGENTA}Force build requested${NC}"
        API_CHANGED=true
        UI_CHANGED=true
    fi

    echo -e "${CYAN}API needs rebuild: ${API_CHANGED}${NC}"
    echo -e "${CYAN}UI needs rebuild: ${UI_CHANGED}${NC}"
}

# Build images that changed
build_changed() {
    echo -e "${CYAN}=== Starting Auto Build ===${NC}"

    # Setup Docker buildx
    if ! docker buildx ls | grep -q multiarch; then
        docker buildx create --name multiarch --driver docker-container --use
        docker buildx inspect --bootstrap
    else
        docker buildx use multiarch
    fi

    local BUILD_ARGS=""
    BUILD_ARGS="${BUILD_ARGS} --build-arg VERSION=${VERSION}"
    BUILD_ARGS="${BUILD_ARGS} --build-arg BUILD_NUMBER=${BUILD_NUMBER}"
    BUILD_ARGS="${BUILD_ARGS} --build-arg GIT_COMMIT=${GIT_COMMIT}"
    BUILD_ARGS="${BUILD_ARGS} --build-arg GIT_BRANCH=${GIT_BRANCH}"

    # Build API if changed
    if [ "$API_CHANGED" = true ]; then
        echo -e "${YELLOW}Building API...${NC}"

        docker buildx build \
            --platform linux/amd64,linux/arm64 \
            ${BUILD_ARGS} \
            --label "gitCommit=${GIT_COMMIT}" \
            --label "version=${VERSION}" \
            --label "buildTime=${BUILD_TIME}" \
            -t "${GITHUB_REGISTRY}/${API_IMAGE}:${VERSION}" \
            -t "${GITHUB_REGISTRY}/${API_IMAGE}:${GIT_BRANCH}" \
            -t "${GITHUB_REGISTRY}/${API_IMAGE}:${GIT_COMMIT}" \
            -f cicd/docker/api.Dockerfile \
            --cache-from type=registry,ref=${GITHUB_REGISTRY}/${API_IMAGE}:buildcache \
            --cache-to type=registry,ref=${GITHUB_REGISTRY}/${API_IMAGE}:buildcache,mode=max \
            --push \
            .

        echo -e "${GREEN}✓ API built and pushed successfully${NC}"
    else
        echo -e "${BLUE}Skipping API build - no changes detected${NC}"
    fi

    # Build UI if changed
    if [ "$UI_CHANGED" = true ]; then
        echo -e "${YELLOW}Building UI...${NC}"

        docker buildx build \
            --platform linux/amd64,linux/arm64 \
            ${BUILD_ARGS} \
            --build-arg REACT_APP_API_URL=${REACT_APP_API_URL:-/api} \
            --label "gitCommit=${GIT_COMMIT}" \
            --label "version=${VERSION}" \
            --label "buildTime=${BUILD_TIME}" \
            -t "${GITHUB_REGISTRY}/${UI_IMAGE}:${VERSION}" \
            -t "${GITHUB_REGISTRY}/${UI_IMAGE}:${GIT_BRANCH}" \
            -t "${GITHUB_REGISTRY}/${UI_IMAGE}:${GIT_COMMIT}" \
            -f cicd/docker/ui.Dockerfile \
            --cache-from type=registry,ref=${GITHUB_REGISTRY}/${UI_IMAGE}:buildcache \
            --cache-to type=registry,ref=${GITHUB_REGISTRY}/${UI_IMAGE}:buildcache,mode=max \
            --push \
            .

        echo -e "${GREEN}✓ UI built and pushed successfully${NC}"
    else
        echo -e "${BLUE}Skipping UI build - no changes detected${NC}"
    fi
}

# Create build report
create_build_report() {
    echo -e "${CYAN}Creating build report...${NC}"

    REPORT_FILE="build-report-${BUILD_NUMBER}.json"

    cat > $REPORT_FILE <<EOF
{
  "version": "${VERSION}",
  "buildNumber": "${BUILD_NUMBER}",
  "gitCommit": "${GIT_COMMIT}",
  "gitBranch": "${GIT_BRANCH}",
  "buildTime": "${BUILD_TIME}",
  "apiBuilt": ${API_CHANGED},
  "uiBuilt": ${UI_CHANGED},
  "images": {
    "api": "${GITHUB_REGISTRY}/${API_IMAGE}:${VERSION}",
    "ui": "${GITHUB_REGISTRY}/${UI_IMAGE}:${VERSION}"
  }
}
EOF

    echo -e "${GREEN}Build report saved to ${REPORT_FILE}${NC}"

    # Update buildinfo.json with latest build metadata
    jq --arg bn "$BUILD_NUMBER" \
       --arg gc "$GIT_COMMIT" \
       --arg gb "$GIT_BRANCH" \
       --arg bt "$BUILD_TIME" \
       '.buildNumber = $bn | .gitCommit = $gc | .gitBranch = $gb | .buildTime = $bt' \
       $BUILDINFO_FILE > tmp.json && mv tmp.json $BUILDINFO_FILE
}

# Main execution
main() {
    echo -e "${MAGENTA}=== Docker Auto Build System ===${NC}"
    echo "Current Version: ${VERSION}"
    echo "Git Commit: ${GIT_COMMIT}"
    echo "Git Branch: ${GIT_BRANCH}"
    echo "Build Number: ${BUILD_NUMBER}"
    echo ""

    # Parse arguments
    while [[ $# -gt 0 ]]; do
        case $1 in
            --auto-version)
                auto_version
                shift
                ;;
            --force)
                FORCE_BUILD=true
                shift
                ;;
            *)
                echo -e "${RED}Unknown option: $1${NC}"
                echo "Usage: $0 [--auto-version] [--force]"
                exit 1
                ;;
        esac
    done

    # Detect what needs to be built
    detect_changes

    # Build changed components
    if [ "$API_CHANGED" = true ] || [ "$UI_CHANGED" = true ]; then
        build_changed
        create_build_report
    else
        echo -e "${BLUE}No changes detected - nothing to build${NC}"
        echo -e "${YELLOW}Use --force to force a rebuild${NC}"
    fi

    echo ""
    echo -e "${GREEN}✓ Auto build process completed${NC}"
}

main "$@"
```

## Docker Registry Configuration

### Environment Variables for Registry Authentication

Set these environment variables before using the push scripts:

#### GitHub Container Registry
```bash
export GITHUB_TOKEN="your-github-personal-access-token"
export GITHUB_USER="your-github-username"
```

#### Huawei Cloud SWR
```bash
export HUAWEI_AK="your-access-key"
export HUAWEI_LOGIN_KEY="your-login-key"
export HUAWEI_REGION="cn-south-1"  # or your preferred region
```

#### Docker Hub
```bash
export DOCKERHUB_TOKEN="your-dockerhub-access-token"
export DOCKERHUB_USER="your-dockerhub-username"
```

## GitHub Actions Workflow

### .github/workflows/ci-cd.yml
```yaml
name: CI/CD Pipeline

on:
  push:
    branches: [main, develop]
    tags:
      - 'v*'
  pull_request:
    branches: [main]

env:
  REGISTRY: ghcr.io
  IMAGE_NAME: ${{ github.repository }}

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        node-version: [18.x, 20.x]
    steps:
    - uses: actions/checkout@v3

    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: ${{ matrix.node-version }}
        cache: 'npm'

    - name: Install dependencies
      run: |
        npm ci
        cd api && npm ci
        cd ../ui && npm ci

    - name: Run tests
      run: |
        npm test
        cd api && npm test
        cd ../ui && npm test

    - name: Run linting
      run: |
        cd api && npm run lint
        cd ../ui && npm run lint

  build-and-push:
    needs: test
    runs-on: ubuntu-latest
    if: github.event_name == 'push'
    permissions:
      contents: read
      packages: write

    steps:
    - uses: actions/checkout@v3

    - name: Setup QEMU
      uses: docker/setup-qemu-action@v2

    - name: Setup Docker Buildx
      uses: docker/setup-buildx-action@v2

    - name: Login to GitHub Container Registry
      uses: docker/login-action@v2
      with:
        registry: ${{ env.REGISTRY }}
        username: ${{ github.actor }}
        password: ${{ secrets.GITHUB_TOKEN }}

    - name: Extract metadata
      id: meta
      uses: docker/metadata-action@v4
      with:
        images: ${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}

    - name: Build and push API
      uses: docker/build-push-action@v4
      with:
        context: .
        file: cicd/docker/api.Dockerfile
        platforms: linux/amd64,linux/arm64
        push: true
        tags: |
          ${{ env.REGISTRY }}/${{ github.repository }}-api:latest
          ${{ env.REGISTRY }}/${{ github.repository }}-api:${{ github.sha }}
        cache-from: type=registry,ref=${{ env.REGISTRY }}/${{ github.repository }}-api:buildcache
        cache-to: type=registry,ref=${{ env.REGISTRY }}/${{ github.repository }}-api:buildcache,mode=max
        build-args: |
          VERSION=${{ github.ref_name }}
          BUILD_NUMBER=${{ github.run_number }}
          GIT_COMMIT=${{ github.sha }}
          GIT_BRANCH=${{ github.ref_name }}

    - name: Build and push UI
      uses: docker/build-push-action@v4
      with:
        context: .
        file: cicd/docker/ui.Dockerfile
        platforms: linux/amd64,linux/arm64
        push: true
        tags: |
          ${{ env.REGISTRY }}/${{ github.repository }}-ui:latest
          ${{ env.REGISTRY }}/${{ github.repository }}-ui:${{ github.sha }}
        cache-from: type=registry,ref=${{ env.REGISTRY }}/${{ github.repository }}-ui:buildcache
        cache-to: type=registry,ref=${{ env.REGISTRY }}/${{ github.repository }}-ui:buildcache,mode=max
        build-args: |
          VERSION=${{ github.ref_name }}
          BUILD_NUMBER=${{ github.run_number }}
          GIT_COMMIT=${{ github.sha }}
          GIT_BRANCH=${{ github.ref_name }}
          REACT_APP_API_URL=/api

  push-to-huawei:
    needs: build-and-push
    runs-on: ubuntu-latest
    if: github.event_name == 'push' && github.ref == 'refs/heads/main'

    steps:
    - uses: actions/checkout@v3

    - name: Push to Huawei Cloud Registry
      env:
        HUAWEI_AK: ${{ secrets.HUAWEI_AK }}
        HUAWEI_LOGIN_KEY: ${{ secrets.HUAWEI_LOGIN_KEY }}
      run: |
        npm run docker:push -- --huawei-cloud ${{ github.event.repository.name }}
```

## Docker Compose for Local Development

### docker-compose.yml
```yaml
version: '3.8'

services:
  api:
    build:
      context: .
      dockerfile: cicd/docker/api.Dockerfile
      target: production
      args:
        VERSION: dev
        BUILD_NUMBER: local
        GIT_COMMIT: local
        GIT_BRANCH: local
    ports:
      - "3001:3001"
    environment:
      NODE_ENV: development
      DB_PATH: /app/data/dev.db
    volumes:
      - ./api/src:/app/src
      - api-data:/app/data
    networks:
      - app-network
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3001/health"]
      interval: 30s
      timeout: 3s
      retries: 3

  ui:
    build:
      context: .
      dockerfile: cicd/docker/ui.Dockerfile
      target: production
      args:
        VERSION: dev
        BUILD_NUMBER: local
        GIT_COMMIT: local
        GIT_BRANCH: local
        REACT_APP_API_URL: http://localhost:3001
    ports:
      - "3000:80"
    depends_on:
      - api
    networks:
      - app-network
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost/health"]
      interval: 30s
      timeout: 3s
      retries: 3

volumes:
  api-data:

networks:
  app-network:
    driver: bridge
```

## Best Practices Summary

### 1. **Multi-Stage Builds**
- Separate dependency installation, building, and production stages
- Minimize final image size by only copying necessary files
- Use Alpine Linux for smaller base images

### 2. **Layer Caching**
- Order Dockerfile commands from least to most frequently changed
- Copy package files before source code
- Use buildx cache mounts for better caching

### 3. **Security**
- Run containers as non-root user
- Use official base images and keep them updated
- Don't include secrets in images
- Implement health checks

### 4. **Version Management**
- Single source of truth in buildinfo.json
- Automatic version syncing across all packages
- Git commit and build metadata in images
- Semantic versioning support

### 5. **Multi-Architecture Support**
- Build for both amd64 and arm64
- Use Docker buildx for cross-platform builds
- Create and push manifests for multi-arch support

### 6. **CI/CD Integration**
- Automated testing before builds
- Parallel builds for efficiency
- Multi-registry support (GitHub, Huawei, Docker Hub)
- Auto-versioning based on commit messages

### 7. **Registry Management**
- Use registry caching for faster builds
- Tag images with multiple identifiers (version, commit, branch)
- Push latest tag only from main branch
- Use image scanning for vulnerabilities

### 8. **Auto Build System**
- Intelligent change detection
- Build only what changed
- Automatic version bumping
- Build reports and metadata tracking

## Usage Examples

```bash
# Local development
docker-compose up -d

# Version management
npm run version:patch  # 1.4.0 -> 1.4.1
npm run version:minor  # 1.4.0 -> 1.5.0
npm run version:major  # 1.4.0 -> 2.0.0

# Build images
npm run docker:build       # Build all images
npm run docker:build:api   # Build only API
npm run docker:build:ui    # Build only UI
npm run docker:build:auto  # Auto-detect and build only changed components

# Push to registries
npm run docker:push                              # Push to default (GitHub) registry
npm run docker:push -- --huawei-cloud ghisha    # Push to Huawei Cloud with prefix
npm run docker:push -- api                      # Push only API to default registry
npm run docker:push -- ui                       # Push only UI to default registry
npm run docker:push -- ui --huawei-cloud proj   # Push only UI to Huawei with prefix

# Auto build with version management
bash cicd/scripts/auto-build.sh --auto-version  # Auto version and build
bash cicd/scripts/auto-build.sh --force         # Force rebuild everything

# Complete CI/CD cycle
npm run ci:release  # Version bump, auto build, and push
```

## Environment Variables

### Build Time
- `VERSION`: Application version
- `BUILD_NUMBER`: CI build number
- `GIT_COMMIT`: Git commit hash
- `GIT_BRANCH`: Git branch name
- `REACT_APP_API_URL`: API URL for UI builds

### Runtime
- `NODE_ENV`: Node environment (development/production)
- `PORT`: Application port
- `DB_PATH`: Database file path (SQLite)
- `DB_HOST/DB_PORT/DB_NAME`: Database connection (PostgreSQL)
- `JWT_SECRET`: JWT signing secret
- `SESSION_SECRET`: Session encryption secret

## Monitoring and Observability

### Build Info Endpoint
Both API and UI expose `/buildinfo.json` endpoint with:
```json
{
  "version": "1.4.0",
  "buildNumber": "123",
  "gitCommit": "abc123",
  "gitBranch": "main",
  "buildTime": "2024-01-15T10:30:00Z"
}
```

### Health Check Endpoints
- API: `GET /health` returns 200 OK
- UI: `GET /health` returns 200 OK

### Metrics Collection
Consider adding:
- Prometheus metrics endpoint
- Application Performance Monitoring (APM)
- Distributed tracing with OpenTelemetry
- Log aggregation with ELK stack

## Troubleshooting

### Common Issues

1. **Build failures**
   ```bash
   # Clean Docker buildx cache
   docker buildx prune -af

   # Rebuild without cache
   docker build --no-cache -f cicd/docker/api.Dockerfile .
   ```

2. **Registry push failures**
   ```bash
   # Check registry login
   docker login ghcr.io

   # Verify credentials
   echo $CR_PAT | docker login ghcr.io -u USERNAME --password-stdin
   ```

3. **Version sync issues**
   ```bash
   # Manually sync versions
   node cicd/scripts/sync-versions.js

   # Verify all versions match
   grep -r "version" --include="*.json" .
   ```

4. **Huawei Cloud push issues**
   ```bash
   # Check Huawei credentials
   echo $HUAWEI_AK
   echo $HUAWEI_LOGIN_KEY

   # Test push with explicit prefix
   npm run docker:push -- --huawei-cloud myproject

   # Manual login test
   docker login -u "cn-south-1@$HUAWEI_AK" -p "$HUAWEI_LOGIN_KEY" swr.cn-south-1.myhuaweicloud.com
   ```

## Future Enhancements

1. **Advanced Auto-Build Features**
   - Dependency graph analysis
   - Parallel component builds
   - Incremental builds for monorepos
   - Build impact analysis

2. **Registry Management**
   - Image mirroring across regions
   - Automated cleanup of old images
   - Registry health monitoring
   - Cost optimization for storage

3. **Security Scanning**
   - Trivy for vulnerability scanning
   - SAST/DAST integration
   - Policy enforcement with OPA
   - Supply chain security (SBOM)

4. **Performance Optimization**
   - Layer caching strategies
   - Build time reduction
   - Multi-stage optimization
   - Distributed build cache

5. **Deployment Strategies**
   - Docker Swarm integration
   - Nomad deployment support
   - ECS/Fargate deployment
   - Container orchestration agnostic approach
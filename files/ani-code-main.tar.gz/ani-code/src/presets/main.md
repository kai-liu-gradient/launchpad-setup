# Ani-Code Standard Project Template

## Project Structure

```
project-name/
├── pd/                          # Project documentation
│   ├── prd.md                   # Product Requirements Document
│   ├── architecture.md          # System architecture & design
│   ├── goals/                   # Staged project goals
│   │   ├── 001-foundation.md    # Initial setup & infrastructure
│   │   ├── 002-core-features.md # Core functionality implementation
│   │   ├── 003-ui-development.md # User interface development
│   │   ├── 004-api-integration.md # API endpoints & integration
│   │   ├── 005-testing.md       # Testing & quality assurance
│   │   └── 006-deployment.md    # Production readiness
│   └── decisions/               # Architecture Decision Records (ADRs)
├── api/                         # Backend API service
│   ├── src/
│   │   ├── app.js              # Express app configuration
│   │   ├── server.js           # Server entry point
│   │   ├── config/             # Configuration management
│   │   │   └── database.js    # Database configuration
│   │   ├── controllers/        # Route controllers
│   │   ├── models/             # Database models
│   │   ├── routes/             # API routes
│   │   ├── middleware/         # Express middleware
│   │   ├── services/           # Business logic
│   │   ├── utils/              # Utility functions
│   │   └── db/
│   │       ├── migrations/     # Database migrations
│   │       └── seeds/          # Seed data
│   ├── tests/                  # API tests
│   ├── package.json
│   └── .env.example
├── ui/                          # Frontend React application
│   ├── src/
│   │   ├── index.js           # React app entry point
│   │   ├── App.js             # Main App component
│   │   ├── components/         # Reusable components
│   │   ├── pages/             # Page components
│   │   ├── services/          # API service layer
│   │   ├── hooks/             # Custom React hooks
│   │   ├── utils/             # Utility functions
│   │   └── styles/            # Global styles
│   ├── public/
│   ├── package.json
│   ├── vite.config.js         # Vite configuration with proxy
│   └── .env.example
├── scripts/                    # Utility scripts
│   ├── setup.sh               # Initial setup script
│   └── migrate.js             # Database migration runner
├── systemd/                    # Systemd service files
│   ├── project-api.service    # API service configuration
│   └── project-ui.service     # UI service configuration
├── data/                       # SQLite database files (git-ignored)
├── tmp/                        # Temporary files (git-ignored)
├── .env                        # Environment configuration (git-ignored)
├── .gitignore                  # Git ignore rules
├── package.json                # Root package.json for workspace
└── README.md                   # Project readme
```

## Goal File Template (pd/goals/XXX-name.md)

```markdown
# Goal: [Goal Name]

## Objective
[Clear description of what this stage aims to achieve]

## Tasks
- [ ] Task 1 description
- [ ] Task 2 description
- [ ] Task 3 description

## Acceptance Criteria
- Criteria 1
- Criteria 2
- Criteria 3

## Progress
- Status: **Not Started** | In Progress | Completed
- Start Date: -
- Completion Date: -
- Notes: [Any relevant notes or blockers]

## Dependencies
- [List any dependencies on other goals]
```

## Configuration Files

### .gitignore
```gitignore
# Dependencies
node_modules/
package-lock.json
yarn.lock
pnpm-lock.yaml

# Database
*.db
*.sqlite
*.sqlite3
data/

# Environment
.env
.env.local
.env.*.local

# Temporary files
tmp/
temp/
*.tmp
*.log

# Build outputs
dist/
build/
.next/
out/

# IDE
.vscode/
.idea/
*.swp
*.swo
.DS_Store

# Test coverage
coverage/
.nyc_output/
```

### .env Template
```env
# Application
NODE_ENV=development
PORT_API=3001
PORT_UI=3000
HOST=0.0.0.0  # Listen on all interfaces

# Database
DB_TYPE=sqlite
DB_PATH=./data/app.db
# For production PostgreSQL:
# DB_TYPE=postgres
# DB_HOST=localhost
# DB_PORT=5432
# DB_NAME=myapp
# DB_USER=appuser
# DB_PASSWORD=secure_password

# Security
JWT_SECRET=change_this_in_production
SESSION_SECRET=change_this_in_production

# API Configuration
API_BASE_URL=http://0.0.0.0:3001
CORS_ORIGIN=*  # Allow all origins in dev (restrict in production)

# Feature Flags
ENABLE_LOGGING=true
ENABLE_METRICS=false
```

### systemd/project-api.service
```ini
[Unit]
Description=Project API Service
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/path/to/project/api
EnvironmentFile=/path/to/project/.env
# Port is managed via .env file (PORT_API=3001)
# Host binding is managed via .env file (HOST=0.0.0.0)
Environment="NODE_ENV=development"
# Development mode with auto-reload
ExecStart=/usr/bin/npx nodemon src/server.js
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

### systemd/project-ui.service
```ini
[Unit]
Description=Project UI Service
After=network.target project-api.service

[Service]
Type=simple
User=www-data
WorkingDirectory=/path/to/project/ui
EnvironmentFile=/path/to/project/.env
# Port is managed via .env file (PORT_UI=3000)
# Host binding is managed via .env file (HOST=0.0.0.0)
Environment="NODE_ENV=development"
# Vite dev server will use HOST and PORT from .env
ExecStart=/usr/bin/npm run dev
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

## API Structure (api/src/)

### app.js
```javascript
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const routes = require('./routes');
const errorHandler = require('./middleware/errorHandler');

const app = express();

// Middleware
app.use(helmet());
app.use(cors({
  origin: process.env.CORS_ORIGIN || '*'  // Accept all origins in dev
}));
app.use(morgan('combined'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/api', routes);

// Error handling
app.use(errorHandler);

module.exports = app;
```

### server.js
```javascript
const app = require('./app');

const PORT = process.env.PORT_API || 3001;
const HOST = process.env.HOST || '0.0.0.0';

app.listen(PORT, HOST, () => {
  console.log(`API server running on http://${HOST}:${PORT}`);
});
```

### config/database.js
```javascript
const knex = require('knex');
const path = require('path');

const dbConfig = {
  development: {
    client: 'sqlite3',
    connection: {
      filename: process.env.DB_PATH || path.join(__dirname, '../../data/app.db')
    },
    useNullAsDefault: true,
    migrations: {
      directory: path.join(__dirname, '../db/migrations')
    },
    seeds: {
      directory: path.join(__dirname, '../db/seeds')
    },
    // CRITICAL: Enable WAL mode to prevent database corruption during server restarts
    pool: {
      afterCreate: (conn, cb) => {
        conn.run('PRAGMA journal_mode = WAL;', cb);
      }
    }
  },
  production: {
    client: process.env.DB_TYPE || 'postgresql',
    connection: {
      host: process.env.DB_HOST,
      port: process.env.DB_PORT,
      database: process.env.DB_NAME,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD
    },
    pool: {
      min: 2,
      max: 10
    },
    migrations: {
      directory: path.join(__dirname, '../db/migrations')
    }
  }
};

const environment = process.env.NODE_ENV || 'development';
const db = knex(dbConfig[environment]);

module.exports = db;
```

## UI Configuration (ui/)

### vite.config.js
```javascript
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    host: process.env.HOST || '0.0.0.0',  // Listen on all interfaces
    port: parseInt(process.env.PORT_UI) || 3000,
    strictPort: true,  // Exit if port is already in use
    proxy: {
      '/api': {
        target: process.env.API_BASE_URL || 'http://0.0.0.0:3001',
        changeOrigin: true,
        secure: false
      }
    },
    hmr: {
      host: '0.0.0.0'  // Hot Module Reload on all interfaces
    }
  }
});
```

### ui/package.json
```json
{
  "name": "project-ui",
  "version": "1.0.0",
  "scripts": {
    "dev": "vite --host 0.0.0.0",
    "build": "vite build",
    "preview": "vite preview --host 0.0.0.0"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "axios": "^1.4.0"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.0.0",
    "vite": "^4.3.0"
  }
}
```

### api/package.json
```json
{
  "name": "project-api",
  "version": "1.0.0",
  "scripts": {
    "start": "node src/server.js",
    "dev": "nodemon src/server.js",
    "migrate": "knex migrate:latest",
    "seed": "knex seed:run",
    "test": "jest"
  },
  "dependencies": {
    "express": "^4.18.0",
    "cors": "^2.8.5",
    "helmet": "^7.0.0",
    "morgan": "^1.10.0",
    "knex": "^2.4.0",
    "sqlite3": "^5.1.0",
    "dotenv": "^16.0.0"
  },
  "devDependencies": {
    "nodemon": "^2.0.0",
    "jest": "^29.0.0"
  }
}
```

### package.json (root)
```json
{
  "name": "project-name",
  "version": "1.0.0",
  "private": true,
  "workspaces": ["api", "ui"],
  "scripts": {
    "dev": "concurrently \"npm run dev:api\" \"npm run dev:ui\"",
    "dev:api": "cd api && npm run dev",
    "dev:ui": "cd ui && npm run dev",
    "build": "npm run build:api && npm run build:ui",
    "build:api": "cd api && npm run build",
    "build:ui": "cd ui && npm run build",
    "migrate": "cd api && npm run migrate",
    "seed": "cd api && npm run seed",
    "test": "npm run test:api && npm run test:ui",
    "test:api": "cd api && npm test",
    "test:ui": "cd ui && npm test",
    "setup": "bash scripts/setup.sh"
  },
  "devDependencies": {
    "concurrently": "^7.6.0"
  }
}
```

## Database Migration Example

### api/db/migrations/001_initial_schema.js
```javascript
exports.up = function(knex) {
  return knex.schema
    .createTable('users', table => {
      table.increments('id').primary();
      table.string('email').unique().notNullable();
      table.string('username').unique().notNullable();
      table.string('password_hash').notNullable();
      table.timestamps(true, true);
      table.index('email');
      table.index('username');
    })
    .createTable('migration_log', table => {
      table.increments('id').primary();
      table.string('migration_name').notNullable();
      table.timestamp('executed_at').defaultTo(knex.fn.now());
      table.json('metadata');
    });
};

exports.down = function(knex) {
  return knex.schema
    .dropTableIfExists('migration_log')
    .dropTableIfExists('users');
};
```

## Setup Script (scripts/setup.sh)

```bash
#!/bin/bash

echo "Setting up Ani-Code managed project..."

# Create necessary directories
mkdir -p pd/goals pd/decisions api/src ui/src data tmp systemd scripts

# Copy environment file
if [ ! -f .env ]; then
  cp .env.example .env
  echo "Created .env file from template"
fi

# Install dependencies
echo "Installing dependencies..."
npm install
cd api && npm install
cd ../ui && npm install
cd ..

# Setup database
echo "Setting up database..."
cd api && npx knex migrate:latest
cd ..

# Create systemd service files
echo "Creating systemd service files..."
PROJECT_PATH=$(pwd)
sed -i "s|/path/to/project|$PROJECT_PATH|g" systemd/*.service

echo "Setup complete! Run 'npm run dev' to start development servers."
```

## Naming Conventions

### CRITICAL: Consistent Naming Standards

**Variables & Functions (JavaScript/TypeScript)**
• **Variables**: Always use camelCase (e.g., `userName`, `isActive`, `totalCount`)
• **Functions**: Always use camelCase (e.g., `getUserData`, `calculateTotal`, `handleSubmit`)
• **Classes**: Use PascalCase (e.g., `UserController`, `DatabaseService`)
• **Constants**: Use UPPER_SNAKE_CASE (e.g., `MAX_RETRIES`, `API_TIMEOUT`)

**Parameters & Data Exchange (CRITICAL)**
• **API Response Fields**: Always use snake_case (e.g., `user_id`, `created_at`, `total_amount`)
• **API Request Body**: Always use snake_case (e.g., `first_name`, `email_address`)
• **Database Columns**: Always use snake_case (e.g., `user_id`, `created_at`, `is_active`)
• **Query Parameters**: Always use snake_case (e.g., `?page_size=10&sort_order=desc`)
• **JSON Data**: Always use snake_case for keys

**File & Directory Names**
• **Components**: PascalCase (e.g., `UserProfile.jsx`, `NavigationBar.tsx`)
• **Utilities/Helpers**: camelCase (e.g., `dateHelpers.js`, `apiClient.ts`)
• **Directories**: lowercase with hyphens (e.g., `user-management/`, `api-services/`)
• **Config Files**: lowercase with dots (e.g., `database.config.js`, `app.settings.json`)

### Example: API Response Format
```javascript
// API returns snake_case
const apiResponse = {
  user_id: 123,
  first_name: "John",
  last_name: "Doe",
  email_address: "john@example.com",
  created_at: "2024-01-01T00:00:00Z",
  is_active: true,
  account_settings: {
    notification_enabled: true,
    theme_preference: "light"
  }
};

// Convert to camelCase for internal use
const userData = {
  userId: apiResponse.user_id,
  firstName: apiResponse.first_name,
  lastName: apiResponse.last_name,
  emailAddress: apiResponse.email_address,
  createdAt: apiResponse.created_at,
  isActive: apiResponse.is_active
};
```

### Example: Database Schema
```sql
CREATE TABLE users (
  user_id INTEGER PRIMARY KEY,
  first_name VARCHAR(100),
  last_name VARCHAR(100),
  email_address VARCHAR(255) UNIQUE,
  password_hash VARCHAR(255),
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE user_sessions (
  session_id VARCHAR(100) PRIMARY KEY,
  user_id INTEGER REFERENCES users(user_id),
  access_token TEXT,
  refresh_token TEXT,
  expires_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Example: TypeScript Interfaces
```typescript
// API Response Interface (snake_case)
interface ApiUserResponse {
  user_id: number;
  first_name: string;
  last_name: string;
  email_address: string;
  phone_number?: string;
  created_at: string;
  updated_at: string;
  is_active: boolean;
  role_permissions: {
    role_id: number;
    permission_level: string;
  }[];
}

// Internal Application Model (camelCase)
interface User {
  userId: number;
  firstName: string;
  lastName: string;
  emailAddress: string;
  phoneNumber?: string;
  createdAt: Date;
  updatedAt: Date;
  isActive: boolean;
  rolePermissions: RolePermission[];
}

// Conversion utilities
const convertApiToModel = (apiData: ApiUserResponse): User => {
  return {
    userId: apiData.user_id,
    firstName: apiData.first_name,
    lastName: apiData.last_name,
    emailAddress: apiData.email_address,
    phoneNumber: apiData.phone_number,
    createdAt: new Date(apiData.created_at),
    updatedAt: new Date(apiData.updated_at),
    isActive: apiData.is_active,
    rolePermissions: apiData.role_permissions.map(rp => ({
      roleId: rp.role_id,
      permissionLevel: rp.permission_level
    }))
  };
};

const convertModelToApi = (user: User): ApiUserResponse => {
  return {
    user_id: user.userId,
    first_name: user.firstName,
    last_name: user.lastName,
    email_address: user.emailAddress,
    phone_number: user.phoneNumber,
    created_at: user.createdAt.toISOString(),
    updated_at: user.updatedAt.toISOString(),
    is_active: user.isActive,
    role_permissions: user.rolePermissions.map(rp => ({
      role_id: rp.roleId,
      permission_level: rp.permissionLevel
    }))
  };
};
```

### Example: Express API Route
```javascript
// Controller using snake_case for API responses
const getUserById = async (req, res) => {
  const userId = req.params.user_id;  // URL param in snake_case

  try {
    // Internal function uses camelCase
    const userData = await userService.findUserById(userId);

    // Convert to snake_case for API response
    res.json({
      success: true,
      data: {
        user_id: userData.userId,
        first_name: userData.firstName,
        last_name: userData.lastName,
        email_address: userData.emailAddress,
        created_at: userData.createdAt,
        is_active: userData.isActive
      }
    });
  } catch (error) {
    res.status(404).json({
      success: false,
      error_code: 'USER_NOT_FOUND',
      error_message: error.message
    });
  }
};

// Route definition
router.get('/users/:user_id', getUserById);
router.post('/users', createUser);
router.put('/users/:user_id', updateUser);
```

### Naming Convention Summary
| Context | Convention | Example |
|---------|------------|---------|
| JS/TS Variables | camelCase | `userName`, `isValid` |
| JS/TS Functions | camelCase | `getData()`, `handleClick()` |
| API Fields | snake_case | `user_id`, `created_at` |
| DB Columns | snake_case | `email_address`, `is_active` |
| URL Params | snake_case | `/users/:user_id` |
| Query Params | snake_case | `?page_size=10` |
| React Components | PascalCase | `UserProfile.jsx` |
| CSS Classes | kebab-case | `user-profile-card` |

**IMPORTANT**: This convention ensures consistency across the entire stack and prevents confusion when data moves between layers.

## Key Features

### 1. Project Documentation (pd/)
- Centralized documentation in pd/ folder
- Staged goals with progress tracking
- Architecture decision records
- PRD and technical specifications

### 2. Clean Architecture
- Separation of concerns (API/UI)
- Component-based frontend structure
- Service layer for business logic
- Database abstraction layer

### 3. Database Management
- SQLite for development (zero dependencies)
- **CRITICAL: WAL mode MUST be enabled for SQLite to prevent database corruption during server restarts**
- Easy migration to PostgreSQL/MySQL for production
- Migration system with version control
- Migration log tracking

**SQLite WAL Mode (Write-Ahead Logging):**
- Prevents database locks and corruption during server restarts
- Required configuration: `PRAGMA journal_mode = WAL;` on connection initialization
- Without WAL mode, server restarts may cause database corruption and data loss
- WAL mode allows concurrent reads while writes are in progress
- Significantly improves reliability in auto-restart scenarios (systemd services)

### 4. Development Environment
- Auto-reloading in development mode
- Environment-based configuration
- Systemd service integration
- Unified .env configuration

### 5. No External Dependencies
- No Redis requirement
- No Kubernetes dependency
- No external service requirements
- Self-contained development environment

### 6. API/UI Integration
- UI serves API through reverse proxy at /api
- Separate processes for scalability
- CORS configuration accepts all origins in dev
- Shared environment configuration
- Both services listen on 0.0.0.0 (all network interfaces)
- Ports clearly managed via .env file (PORT_API=3001, PORT_UI=3000)

### 7. Best Practices
- Component-based React structure
- Express.js with middleware pattern
- Database migrations
- Environment-based configuration
- Comprehensive .gitignore
- Security headers (helmet)
- Request logging (morgan)
- Error handling middleware
- Services bind to 0.0.0.0 for network accessibility
- Vite configured without domain restrictions
- Clear port management in service files via .env

## Service Management

### Auto-Loading Services
Services configured in systemd are auto-loading and managed by the system. There is **no need for extensive PID checking** or service status verification in application code. The systemd services handle:
- Automatic startup on boot
- Automatic restart on failure (RestartSec=10)
- Process management and logging
- Clean shutdown procedures

### Development Workflow
1. **Focus on Core Tasks**: Complete your implementation with proper syntax checking
2. **Handle Errors Gracefully**: If blocked, provide clear suggestions to the user rather than repeatedly retrying
3. **Trust Service Management**: Services auto-restart if needed - don't implement manual service checking
4. **Verify Code Quality**: Run linting and type checking after changes
5. **Test Functionality**: Ensure features work as expected

### Best Practices
- **Don't Check PIDs**: The service manager handles process lifecycle
- **Don't Restart Services**: Auto-restart is configured in systemd
- **Do Check Syntax**: Verify code correctness with linters/type checkers
- **Do Handle Blocks**: If an operation fails, suggest next steps to the user
- **Do Complete Tasks**: Ensure all requested work is done before stopping

## Git Workflow

### CRITICAL: Never Commit Automatically
**NEVER create git commits automatically without explicit user approval!**

**Forbidden Actions:**
- **NEVER run `git add` or `git commit` automatically**
- **NEVER stage changes without user request**
- **NEVER create commits on behalf of the user**
- **NEVER push to remote repositories automatically**

**When Changes Are Made:**
1. Inform the user what files were modified
2. Let the user review changes with `git diff` or `git status`
3. Let the user decide when to commit
4. Only create commits when explicitly asked by the user

**User Controls Git:**
- User reviews changes before staging
- User decides commit message and timing
- User controls when to push to remote
- Claude assists but never commits automatically

## Usage

1. Initialize project: `bash scripts/setup.sh`
2. Start development: `npm run dev`
3. Run migrations: `npm run migrate`
4. Run tests: `npm test`
5. Build for production: `npm run build`

### Service Commands (Read-Only)
- Check service status: `systemctl status project-api`
- View service logs: `journalctl -u project-api -f`
- **Note**: Services auto-load and restart - manual intervention rarely needed

## Switching to Production Database

Update .env file:
```env
DB_TYPE=postgresql
DB_HOST=your-db-host
DB_PORT=5432
DB_NAME=your-db-name
DB_USER=your-db-user
DB_PASSWORD=your-secure-password
```

Then run migrations: `npm run migrate`
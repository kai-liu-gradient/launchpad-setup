# Database Configuration

## Database Connection
- **Type**: [PostgreSQL/MySQL/MongoDB/SQLite/etc.]
- **Host**: [DATABASE_HOST]
- **Port**: [DATABASE_PORT]
- **Database Name**: [DATABASE_NAME]
- **Username**: [DATABASE_USER]
- **Connection String**: [CONNECTION_STRING_TEMPLATE]

## Schema Information
- **Main Tables/Collections**: [LIST MAIN TABLES]
- **Relationships**: [DESCRIBE KEY RELATIONSHIPS]

## Important Queries
```sql
-- Example queries
[ADD COMMON QUERIES HERE]
```

## Migration Commands
- **Run Migrations**: [MIGRATION COMMAND]
- **Rollback**: [ROLLBACK COMMAND]
- **Create Migration**: [CREATE MIGRATION COMMAND]

## Backup & Restore
- **Backup Command**: [BACKUP COMMAND]
- **Restore Command**: [RESTORE COMMAND]

## Performance Tips
- Always use indexes on frequently queried columns
- Avoid N+1 queries
- Use connection pooling in production

## Notes
[ADD DATABASE-SPECIFIC NOTES HERE]
# Vite HMR Keepalive Fix

## Problem
Vite's HMR (Hot Module Replacement) WebSocket connection times out after ~30 seconds of idle time when behind reverse proxies or HTTPS, causing unexpected page reloads and broken hot reload functionality.

## Solution: HMR Keepalive Plugin

### Core Concept
Push periodic "keepalive" messages from server to browser via WebSocket to prevent idle timeout and maintain active HMR connection.

### Implementation

```javascript
// vite.config.js
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

/**
 * Dev-only: push a tiny HMR "custom" message every N ms so the browser
 * always sees downward traffic and doesn't hit the ~30s idle reload path.
 */
function hmrKeepalive(intervalMs = 20000) {
  return {
    name: 'hmr-keepalive',
    apply: 'serve',
    configureServer(server) {
      const timer = setInterval(() => {
        try {
          server.ws.send({
            type: 'custom',
            event: 'keepalive',
            data: Date.now(),
          });
        } catch {
          /* ignore */
        }
      }, intervalMs);
      server.httpServer?.on('close', () => clearInterval(timer));
    },
  };
}

export default defineConfig({
  plugins: [react(), hmrKeepalive(20000)], // 20s heartbeat
  server: {
    port: 9501,
    host: '0.0.0.0',

    // If reverse-proxied behind HTTPS, declare the public origin
    origin: 'https://your-domain.com',

    hmr: {
      protocol: 'wss',              // Use WSS for HTTPS
      host: 'your-domain.com',      // Public hostname
      clientPort: 443,               // HTTPS port
      timeout: 3600000,              // 1 hour client tolerance
      // path: '/_vite/ws',          // Uncomment only if WS path changed
    },
    proxy: {
      '/api': {
        target: 'http://localhost:3001',
        changeOrigin: true,
      },
    },
  },
  clearScreen: false,
});
```

## Key Configuration Points

### 1. Keepalive Interval
```javascript
hmrKeepalive(20000)  // 20 seconds - below typical 30s timeout
```
- Set below proxy/browser timeout threshold
- Default: 20000ms (20 seconds)
- Adjust based on your infrastructure timeout settings

### 2. HMR Protocol & Host
```javascript
hmr: {
  protocol: 'wss',              // Use 'wss' for HTTPS, 'ws' for HTTP
  host: 'your-domain.com',      // Public domain name
  clientPort: 443,               // 443 for HTTPS, 80 for HTTP
  timeout: 3600000,              // Client-side timeout (1 hour)
}
```

### 3. Origin Declaration
```javascript
origin: 'https://your-domain.com'  // Public URL where app is accessed
```
- Required when behind reverse proxy
- Must match actual public URL
- Omit for local development without proxy

### 4. Server Binding
```javascript
host: '0.0.0.0'  // Listen on all network interfaces
port: 9501        // Dev server port
```

## When to Use This Fix

### Symptoms Requiring Fix
- Page auto-reloads every ~30 seconds during development
- HMR stops working after brief idle period
- WebSocket connection shows as disconnected in browser DevTools
- Console errors: "WebSocket connection to 'wss://...' failed"

### Deployment Scenarios
- ✅ Behind Nginx/Apache reverse proxy
- ✅ Behind Cloudflare or CDN
- ✅ HTTPS-only environments
- ✅ Corporate networks with aggressive timeouts
- ✅ Docker/Kubernetes deployments
- ❌ Local development (usually not needed)

## Configuration Checklist

- [ ] Add `hmrKeepalive` plugin before framework plugins
- [ ] Set `origin` to match public URL
- [ ] Configure `hmr.protocol` ('wss' for HTTPS)
- [ ] Configure `hmr.host` (public domain)
- [ ] Configure `hmr.clientPort` (443 for HTTPS)
- [ ] Set `host: '0.0.0.0'` for network access
- [ ] Adjust keepalive interval if needed (default 20s)
- [ ] Test HMR after 30+ seconds of idle time

## Verification

### Test HMR Connection
1. Start dev server: `npm run dev`
2. Open browser DevTools → Network → WS tab
3. Verify WebSocket connection stays open
4. Wait 30+ seconds without changes
5. Make a code change
6. Verify hot reload works without page refresh

### Monitor Keepalive Messages
```javascript
// In browser console (optional)
window.addEventListener('message', (e) => {
  if (e.data?.type === 'custom' && e.data?.event === 'keepalive') {
    console.log('Keepalive:', new Date(e.data.data));
  }
});
```

## Reverse Proxy Configuration

### Nginx Example
```nginx
location /_vite/ {
    proxy_pass http://localhost:9501;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Host $host;
    proxy_cache_bypass $http_upgrade;
    proxy_read_timeout 3600s;  # Match Vite timeout
}
```

### Apache Example
```apache
<Location /_vite/>
    ProxyPass ws://localhost:9501/_vite/
    ProxyPassReverse ws://localhost:9501/_vite/
    ProxyTimeout 3600
</Location>
```

## Troubleshooting

### Issue: Still Getting Disconnections
- Decrease keepalive interval to 15s or 10s
- Check proxy timeout settings (Nginx `proxy_read_timeout`, Apache `ProxyTimeout`)
- Verify firewall isn't closing idle connections

### Issue: HMR Not Working at All
- Check browser console for WebSocket errors
- Verify `origin` matches actual URL in browser
- Ensure `hmr.host` is publicly resolvable
- Check if reverse proxy is forwarding WebSocket correctly

### Issue: Multiple Reloads
- Check for conflicting HMR configurations
- Ensure only one instance of dev server is running
- Verify no duplicate Vite config files

## Performance Impact
- Negligible: ~50 bytes per 20 seconds
- No impact on production builds (dev-only plugin)
- Minimal CPU usage from timer interval

## Notes
- Only applies to development mode (`apply: 'serve'`)
- Automatically cleans up timer on server close
- Fails silently if WebSocket unavailable
- Compatible with all Vite frameworks (React, Vue, Svelte, etc.)

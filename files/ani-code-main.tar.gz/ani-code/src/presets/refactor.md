# Code Refactoring Best Practices

## When to Refactor

**Refactor a file when:**
- File exceeds 1,000 lines
- Multiple responsibilities mixed together
- Logic duplicated across functions
- Hard to add new features without copy/paste
- Long functions (>100 lines)
- Inline prompts or large string literals
- Similar patterns repeated 3+ times

## Refactoring Strategy: The 4-Module Pattern

### Step 1: Identify What to Extract

**Look for these patterns:**

1. **Prompts/Templates** (→ `src/prompts/`)
   - Long string literals used with LLMs
   - Template builders with variable substitution
   - Similar prompt structures repeated
   - Any string >50 lines

2. **Utilities/Helpers** (→ `src/utils/`)
   - Pure functions (no side effects)
   - Parsing logic
   - Validation functions
   - Formatters and normalizers
   - Status/state management
   - File operations

3. **Processing Logic** (→ `src/utils/*-processor.js`)
   - Core business logic
   - Orchestration of multiple steps
   - Shared workflow patterns
   - Cache management
   - Batch processing
   - State machines

4. **Command Definitions** (→ `src/commands/`)
   - CLI argument parsing
   - User interaction
   - High-level workflow coordination
   - Should be thin wrappers

### Step 2: Module Organization

```
src/
├── commands/
│   └── feature.js              # Thin command definitions (500-1000 lines max)
├── prompts/
│   └── feature-prompts.js      # Centralized prompts (200-500 lines)
├── utils/
│   ├── feature-utils.js        # Pure utilities (400-600 lines)
│   └── feature-processor.js    # Core processing logic (400-700 lines)
└── presets/
    └── refactor.md             # This file
```

### Step 3: Extraction Order

**Extract in this sequence to minimize breakage:**

1. **Extract Prompts First**
   ```javascript
   // Before: Inline 200-line prompt
   const prompt = `Very long prompt...`;

   // After: Clean import
   import { buildFeaturePrompt } from '../prompts/feature-prompts.js';
   const prompt = buildFeaturePrompt(data);
   ```

2. **Extract Pure Utilities Second**
   ```javascript
   // Before: Duplicated validation
   function validateInCommand1() { /* 50 lines */ }
   function validateInCommand2() { /* 50 lines - same logic */ }

   // After: Shared utility
   import { validateData } from '../utils/feature-utils.js';
   ```

3. **Extract Processor Logic Third**
   ```javascript
   // Before: 600-line sync function
   async function syncData() {
     // Complex batching logic
     // Cache management
     // Validation
     // Error handling
   }

   // After: Unified processor
   import { createProcessor } from '../utils/feature-processor.js';
   const processor = createProcessor(options);
   await processor.process();
   ```

4. **Simplify Commands Last**
   ```javascript
   // After extraction: Clean command
   .action(async (options) => {
     const processor = createProcessor(dir, options);
     const result = await processor.process();
     displayResults(result);
   });
   ```

## Detailed Patterns

### Pattern 1: Prompts Module

**Purpose:** Centralize all LLM prompts for easy modification

```javascript
// src/prompts/feature-prompts.js

/**
 * Build main analysis prompt
 * @param {Array} files - Files to analyze
 * @param {Object} context - Additional context
 * @returns {string} Formatted prompt
 */
export function buildAnalysisPrompt(files, context = {}) {
  const filesList = files.map(f => `- ${f}`).join('\n');

  return `Analyze these files and provide structured output.

**Files to Analyze:**
${filesList}

${context.instructions || ''}

**Output Format:**
[Specify exact format expected]

**Important Rules:**
1. Rule one
2. Rule two
3. Rule three`;
}

/**
 * Build validation/fix prompt
 */
export function buildValidationPrompt(issues, files) {
  return `Fix the following issues in these files...`;
}

/**
 * Build execution prompt
 */
export function buildExecutionPrompt(task, context) {
  return `Execute this task with the following context...`;
}
```

**Benefits:**
- All prompts in one place
- Easy to A/B test different prompts
- Version control for prompt engineering
- Consistent formatting across commands

### Pattern 2: Utilities Module

**Purpose:** Pure functions with no side effects

```javascript
// src/utils/feature-utils.js

/**
 * Constants for valid values
 */
export const VALID_STATUSES = ['pending', 'active', 'completed'];
export const COMPLETED_STATUSES = ['completed', 'archived'];

/**
 * Normalize input to standard format
 */
export function normalizeStatus(rawStatus) {
  const normalized = rawStatus.toLowerCase().trim();
  // Normalization logic
  return VALID_STATUSES.includes(normalized) ? normalized : 'pending';
}

/**
 * Parse structured data from content
 */
export function parseContent(content) {
  // Parsing logic
  return {
    id: extractId(content),
    title: extractTitle(content),
    metadata: extractMetadata(content)
  };
}

/**
 * Validate data structure
 */
export function validateData(data, rules = {}) {
  const errors = [];

  // Validation checks
  if (!data.id) errors.push('Missing ID');
  if (!data.title) errors.push('Missing title');

  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Calculate summary statistics
 */
export function calculateSummary(items) {
  return {
    total: items.length,
    completed: items.filter(i => i.status === 'completed').length,
    pending: items.filter(i => i.status === 'pending').length
  };
}

/**
 * Format output for display
 */
export function formatProgressBar(percentage, width = 20) {
  const filled = Math.round((percentage / 100) * width);
  const empty = width - filled;
  return '[' + '█'.repeat(filled) + '░'.repeat(empty) + ']';
}

/**
 * Wait for async task completion
 */
export async function waitForCompletion(client, taskId, timeoutSeconds = 300) {
  const startTime = Date.now();
  const timeoutMs = timeoutSeconds * 1000;

  while (Date.now() - startTime < timeoutMs) {
    const taskInfo = await client.getTask(taskId);
    if (taskInfo && taskInfo.status === 'completed') {
      return true;
    }
    await new Promise(resolve => setTimeout(resolve, 2000));
  }

  return false;
}
```

**Key Principles:**
- Export constants at top
- Pure functions (input → output, no side effects)
- Single responsibility per function
- Clear function names
- JSDoc comments for complex functions

### Pattern 3: Processor Module

**Purpose:** Orchestrate complex workflows with state management

```javascript
// src/utils/feature-processor.js

import { buildAnalysisPrompt, buildValidationPrompt } from '../prompts/feature-prompts.js';
import {
  parseContent,
  validateData,
  calculateSummary,
  waitForCompletion
} from './feature-utils.js';

/**
 * Unified processor for all operations
 */
export class FeatureProcessor {
  constructor(dataDir, options = {}) {
    this.dataDir = dataDir;
    this.workspacePath = this.deriveWorkspacePath(dataDir);
    this.options = options;
    this.batchSize = options.batchSize || 10;
    this.cacheDir = join(this.workspacePath, '.cache');
    this.cacheFile = join(this.cacheDir, 'cache.json');
  }

  /**
   * Load cache from disk
   */
  async loadCache() {
    if (!existsSync(this.cacheFile)) {
      return { data: null, exists: false };
    }

    try {
      const content = readFileSync(this.cacheFile, 'utf8');
      return { data: JSON.parse(content), exists: true };
    } catch (error) {
      return { data: null, exists: false, error: error.message };
    }
  }

  /**
   * Save cache to disk
   */
  async saveCache(data) {
    try {
      mkdirSync(this.cacheDir, { recursive: true });

      if (!data.summary) {
        data.summary = calculateSummary(data.items);
      }

      writeFileSync(this.cacheFile, JSON.stringify(data, null, 2));
      return true;
    } catch (error) {
      console.error('Cache save error:', error.message);
      return false;
    }
  }

  /**
   * Check if cache is valid
   */
  async isCacheValid() {
    const { data: cacheData } = await this.loadCache();

    if (!cacheData || !cacheData.lastUpdated) {
      return { valid: false, reason: 'Cache missing' };
    }

    // Check file modification times
    const cacheTime = new Date(cacheData.lastUpdated).getTime();
    const files = this.findFiles();

    for (const file of files) {
      const stats = statSync(file);
      if (stats.mtimeMs > cacheTime) {
        return { valid: false, reason: 'Files modified' };
      }
    }

    return { valid: true };
  }

  /**
   * Main processing method - unified entry point
   */
  async process(mode = 'sync') {
    const { fullResync, skipFix, fastMode } = this.options;

    // Find files to process
    const files = this.findFiles();
    if (files.length === 0) {
      return { success: false, message: 'No files found' };
    }

    // Check daemon
    if (!this.isDaemonRunning()) {
      return { success: false, message: 'Daemon not running' };
    }

    // Connect to processing service
    const client = new IPCClient();
    await client.connect();

    try {
      // Phase 1: Analysis
      const analysisResult = await this.analyzeInBatches(client, files);
      if (!analysisResult.success) {
        return analysisResult;
      }

      // Save cache
      await this.saveCache(analysisResult.cacheData);

      // Phase 2: Validation (if not skipped)
      if (!skipFix && !fastMode) {
        const validationResult = await this.validateAndFix(
          client,
          analysisResult.cacheData,
          files
        );

        if (validationResult.updated) {
          await this.saveCache(validationResult.cacheData);
        }
      }

      await client.disconnect();
      return { success: true, message: 'Processing complete' };

    } catch (error) {
      await client.disconnect();
      return { success: false, message: error.message };
    }
  }

  /**
   * Analyze files in batches
   */
  async analyzeInBatches(client, files) {
    const totalBatches = Math.ceil(files.length / this.batchSize);
    let accumulated = [];

    for (let i = 0; i < totalBatches; i++) {
      const batch = files.slice(i * this.batchSize, (i + 1) * this.batchSize);

      // Build prompt
      const prompt = buildAnalysisPrompt(batch, { accumulated });

      // Send to LLM
      const task = await client.addTask('analyze', prompt, {
        cwd: this.workspacePath
      });

      // Wait for completion
      const completed = await waitForCompletion(client, task.id);
      if (!completed) {
        return { success: false, message: 'Batch timeout' };
      }

      // Parse results
      const taskInfo = await client.getTask(task.id);
      const batchResults = this.parseResults(taskInfo.output);

      accumulated = [...accumulated, ...batchResults];
    }

    return {
      success: true,
      cacheData: {
        items: accumulated,
        totalItems: files.length,
        lastUpdated: new Date().toISOString()
      }
    };
  }

  /**
   * Validate and fix issues
   */
  async validateAndFix(client, cacheData, files) {
    const validation = validateData(cacheData);

    if (validation.valid) {
      return { updated: false, cacheData };
    }

    // Build fix prompt
    const prompt = buildValidationPrompt(validation.errors, files);

    // Send to LLM for fixes
    const task = await client.addTask('fix', prompt, {
      cwd: this.workspacePath
    });

    await waitForCompletion(client, task.id);

    // Re-parse fixed files
    const fixedData = this.reparse(files);
    cacheData.items = fixedData;

    return { updated: true, cacheData };
  }

  /**
   * Helper methods
   */
  findFiles() {
    // Implementation
  }

  isDaemonRunning() {
    const client = new DaemonClient();
    return client.isDaemonRunning();
  }

  parseResults(output) {
    // Parse LLM output
  }

  reparse(files) {
    // Re-parse files after fixes
  }

  deriveWorkspacePath(dataDir) {
    return dataDir.replace(/\/data\/?$/, '');
  }
}

/**
 * Factory function for convenience
 */
export function createProcessor(dataDir, options = {}) {
  return new FeatureProcessor(dataDir, options);
}
```

**Key Principles:**
- Class-based for state management
- Constructor takes all config
- Single `process()` method as main entry point
- Private helper methods for each phase
- Factory function for easy instantiation
- Clean separation of concerns

### Pattern 4: Simplified Command Module

**Purpose:** Thin wrapper coordinating user interaction

```javascript
// src/commands/feature.js

import { Command } from 'commander';
import chalk from 'chalk';
import { createProcessor } from '../utils/feature-processor.js';
import { formatProgressBar, calculateSummary } from '../utils/feature-utils.js';

/**
 * Main sync command using processor
 */
async function syncCommand(dataDir, options) {
  const processor = createProcessor(dataDir, options);

  // Handle confirmations if needed
  if (options.fullResync) {
    const confirmed = await promptConfirm('This will resync all data. Continue?');
    if (!confirmed) {
      console.log(chalk.gray('Cancelled'));
      return;
    }
    processor.options.autoConfirm = true;
  }

  // Process using unified logic
  const result = await processor.process('sync');

  if (result.success) {
    console.log(chalk.green('✅ Sync completed'));

    // Display summary
    const { data: cacheData } = await processor.loadCache();
    if (cacheData?.summary) {
      displaySummary(cacheData.summary);
    }
  } else {
    console.error(chalk.red(`❌ Error: ${result.message}`));
  }
}

/**
 * List command
 */
async function listCommand(dataDir, options) {
  const processor = createProcessor(dataDir);

  // Refresh if requested
  if (options.refresh) {
    await processor.process('sync');
  }

  // Load and display
  const { data: cacheData } = await processor.loadCache();

  if (!cacheData || !cacheData.items) {
    console.log(chalk.yellow('No data found. Run sync first.'));
    return;
  }

  displayItems(cacheData.items);
  displaySummary(cacheData.summary);
}

/**
 * Display helpers
 */
function displaySummary(summary) {
  console.log(chalk.cyan('\n📊 Summary'));
  console.log(`Total: ${summary.total}`);
  console.log(`Completed: ${summary.completed}`);
  console.log(`Pending: ${summary.pending}`);
}

function displayItems(items) {
  items.forEach(item => {
    const icon = item.status === 'completed' ? '✅' : '⏳';
    console.log(`${icon} ${item.id}. ${item.title}`);
    console.log(`   Status: ${item.status}`);
  });
}

/**
 * Command definition
 */
export default function createFeatureCommand() {
  const cmd = new Command('feature')
    .description('Manage feature')
    .option('-d, --dir <directory>', 'Data directory', 'data');

  cmd
    .command('sync')
    .description('Sync data with analysis')
    .option('--full', 'Full resync', false)
    .option('--fast', 'Fast mode', false)
    .option('--no-fix', 'Skip fixes', false)
    .action(async (options) => {
      const dataDir = join(process.cwd(), cmd.opts().dir);
      await syncCommand(dataDir, options);
    });

  cmd
    .command('list')
    .description('List all items')
    .option('-r, --refresh', 'Refresh first', false)
    .action(async (options) => {
      const dataDir = join(process.cwd(), cmd.opts().dir);
      await listCommand(dataDir, options);
    });

  return cmd;
}

// Export helpers for other modules
export { displaySummary, displayItems };
```

**Key Principles:**
- Each command is a simple async function
- Use processor for all heavy lifting
- Display logic separate from business logic
- Commands are 10-30 lines each
- Export display helpers for reuse

## Refactoring Checklist

### Before You Start

- [ ] File is >1,000 lines
- [ ] Identified prompts to extract (>50 lines each)
- [ ] Identified duplicate logic (3+ occurrences)
- [ ] Identified pure utilities to extract
- [ ] Have backup of original file
- [ ] Tests exist or can be created

### During Refactoring

**Phase 1: Extract Prompts**
- [ ] Create `src/prompts/feature-prompts.js`
- [ ] Move all prompt building functions
- [ ] Export each prompt builder
- [ ] Update imports in original file
- [ ] Test: Commands still work

**Phase 2: Extract Utilities**
- [ ] Create `src/utils/feature-utils.js`
- [ ] Move constants and enums
- [ ] Move pure functions (parsing, validation)
- [ ] Move formatters and helpers
- [ ] Export all utilities
- [ ] Update imports
- [ ] Test: Commands still work

**Phase 3: Extract Processor**
- [ ] Create `src/utils/feature-processor.js`
- [ ] Create processor class
- [ ] Move cache management
- [ ] Move batch processing logic
- [ ] Move workflow orchestration
- [ ] Create factory function
- [ ] Update imports
- [ ] Test: Commands still work

**Phase 4: Simplify Commands**
- [ ] Rewrite each command to use processor
- [ ] Remove duplicated logic
- [ ] Keep only UI/UX code
- [ ] Commands are <50 lines each
- [ ] Test: All commands work

### After Refactoring

- [ ] Run syntax checks on all new files
- [ ] Test all commands end-to-end
- [ ] Update exports in main file
- [ ] Check file sizes (main file <1,000 lines)
- [ ] Update documentation
- [ ] Keep backup for 1 week

## Quality Metrics

**Good refactoring achieves:**

- ✅ Main command file <1,000 lines (ideally <700)
- ✅ Prompt module 200-500 lines
- ✅ Utils module 400-600 lines
- ✅ Processor module 400-700 lines
- ✅ Each function <100 lines
- ✅ No code duplication
- ✅ Clear module responsibilities
- ✅ All tests pass
- ✅ Same or better performance

## Common Pitfalls to Avoid

### ❌ Don't Over-Extract
```javascript
// Bad: Too granular
import { addOne } from './math-utils.js';
import { subtractOne } from './math-utils.js';

// Good: Reasonable grouping
import { increment, decrement } from './math-utils.js';
```

### ❌ Don't Create Circular Dependencies
```javascript
// Bad: Commands import processor, processor imports commands
// commands/feature.js
import { processor } from '../utils/processor.js';

// utils/processor.js
import { displayResults } from '../commands/feature.js'; // ❌ Circular!

// Good: Share through common utilities
// utils/display.js
export function displayResults() { }

// Both import from utils
```

### ❌ Don't Mix Concerns in Modules
```javascript
// Bad: Utils file with side effects
export async function validateAndSaveToDb(data) { // ❌ Side effects!
  const valid = validate(data);
  await db.save(data);
  return valid;
}

// Good: Pure validation, side effects elsewhere
export function validate(data) {
  return { valid: true/false, errors: [] };
}
```

### ❌ Don't Extract Too Early
- Wait until you see duplication (3+ times)
- Don't extract single-use functions
- Extract when you need to modify in multiple places

## Success Example: Goals System

**Before:**
- `goals.js`: 4,405 lines
- Prompts inline: ~700 lines
- Duplicated logic: ~800 lines
- Hard to modify or extend

**After:**
- `goals.js`: 696 lines (84% reduction)
- `goals-prompts.js`: 353 lines
- `goals-utils.js`: 516 lines
- `goals-processor.js`: 544 lines
- **Total: 2,109 lines (52% reduction overall)**

**Benefits Achieved:**
- ✅ Easy to modify prompts (1 file)
- ✅ Easy to add commands (use processor)
- ✅ No duplication (DRY throughout)
- ✅ Clear separation of concerns
- ✅ 5x faster to add features

## Quick Reference

### File Size Targets

```
Main Command File:     500-1,000 lines
Prompts Module:        200-500 lines
Utils Module:          400-600 lines
Processor Module:      400-700 lines
Individual Function:   <100 lines
```

### Module Responsibilities

```
commands/    → CLI definitions, user interaction
prompts/     → LLM prompt templates
utils/       → Pure functions, parsing, validation
*-processor/ → Workflows, orchestration, state
```

### Import Structure

```javascript
// Commands import from prompts, utils, processor
import { buildPrompt } from '../prompts/feature-prompts.js';
import { validate, parse } from '../utils/feature-utils.js';
import { createProcessor } from '../utils/feature-processor.js';

// Processor imports from prompts and utils
import { buildPrompt } from '../prompts/feature-prompts.js';
import { validate, parse } from '../utils/feature-utils.js';

// Utils and Prompts are standalone (no cross-imports)
```

## Testing After Refactoring

```bash
# Syntax check
node -c src/commands/feature.js
node -c src/prompts/feature-prompts.js
node -c src/utils/feature-utils.js
node -c src/utils/feature-processor.js

# Functional tests
./src/index.js feature --help
./src/index.js feature sync
./src/index.js feature list
./src/index.js feature <other-commands>

# Line count verification
wc -l src/commands/feature.js  # Should be <1000
wc -l src/prompts/feature-prompts.js
wc -l src/utils/feature-utils.js
wc -l src/utils/feature-processor.js
```

## Conclusion

Follow this pattern to transform any complex command file into a maintainable, modular system. The 4-module pattern (commands, prompts, utils, processor) works well for CLI tools that interact with LLMs and manage complex workflows.

**Remember:** Refactoring is iterative. Start with prompts, then utils, then processor, then simplify commands. Test after each phase!
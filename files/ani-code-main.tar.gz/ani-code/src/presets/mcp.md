# MCP Server Implementation Guide

**Model Context Protocol (MCP)** - Best Practices & Reference Implementation

## Table of Contents
1. [Protocol Overview](#protocol-overview)
2. [Server Implementation](#server-implementation)
3. [JSON Schema Standard](#json-schema-standard)
4. [Transport Types](#transport-types)
5. [Agent Integration](#agent-integration)
6. [Complete Examples](#complete-examples)
7. [Best Practices](#best-practices)

---

## Protocol Overview

### What is MCP?

MCP (Model Context Protocol) is a standardized protocol for exposing tools/functions that AI agents can discover and execute. It enables:

- **Tool Discovery** - Agents can list available functions
- **Schema Validation** - Parameters validated with JSON Schema
- **Type Safety** - Strong typing for inputs/outputs
- **Transport Flexibility** - HTTP REST or STDIO streams

### Protocol Version

Current stable version: **2024-11-05**

### Core Concepts

```
┌─────────────┐         ┌──────────────┐         ┌─────────────┐
│   AI Agent  │ ◄─────► │  MCP Server  │ ◄─────► │  Functions  │
└─────────────┘         └──────────────┘         └─────────────┘
                              │
                              ▼
                        ┌──────────────┐
                        │   Database   │
                        │   Services   │
                        └──────────────┘
```

**Key Components:**
- **Server Info** - Name, version, capabilities
- **Functions/Tools** - Callable operations with schemas
- **Parameters** - JSON Schema validated inputs
- **Results** - Structured output format

---

## Server Implementation

### Minimal MCP Server Structure

```javascript
class MCPServer {
    constructor() {
        this.functions = new Map();
        this.startTime = Date.now();
    }

    // Core MCP Methods
    getMCPInfo() {
        return {
            protocolVersion: '2024-11-05',
            capabilities: {
                tools: {},      // Function execution
                prompts: {},    // Prompt templates (optional)
                resources: {},  // Resource access (optional)
                logging: {}     // Logging support (optional)
            },
            serverInfo: {
                name: 'your-mcp-server',
                version: '1.0.0'
            }
        };
    }

    async initialize(params) {
        // Initialize session, return server info
        return this.getMCPInfo();
    }

    async listFunctions() {
        const tools = [];
        for (const [name, func] of this.functions) {
            tools.push({
                name: func.name,
                description: func.description,
                inputSchema: func.parameters
            });
        }
        return { tools };
    }

    async callFunction(functionName, args) {
        const func = this.functions.get(functionName);
        if (!func) {
            return {
                error: {
                    code: 'FUNCTION_NOT_FOUND',
                    message: `Function '${functionName}' not found`
                }
            };
        }

        try {
            const result = await func.handler(args);
            return {
                content: [{
                    type: 'text',
                    text: JSON.stringify(result, null, 2)
                }]
            };
        } catch (error) {
            return {
                error: {
                    code: 'FUNCTION_ERROR',
                    message: error.message
                }
            };
        }
    }

    registerFunction(func) {
        this.functions.set(func.name, func);
    }
}
```

### Function Registration Pattern

```javascript
// Built-in function with full JSON Schema
server.registerFunction({
    name: 'search_documents',
    description: 'Search for documents matching a query',
    parameters: {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "Search query string"
            },
            "limit": {
                "type": "number",
                "description": "Maximum results to return",
                "default": 10,
                "minimum": 1,
                "maximum": 100
            },
            "filters": {
                "type": "object",
                "properties": {
                    "category": { "type": "string" },
                    "dateFrom": { "type": "string", "format": "date" }
                },
                "additionalProperties": false
            }
        },
        "required": ["query"],
        "additionalProperties": false
    },
    handler: async (params) => {
        const { query, limit = 10, filters = {} } = params;
        // Implementation here
        return { results: [], total: 0 };
    }
});
```

---

## JSON Schema Standard

### Schema Requirements

**CRITICAL:** All MCP function parameters MUST follow JSON Schema Draft-07 standard.

#### Required Fields

```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "type": "object",
  "properties": { ... },
  "required": [],
  "additionalProperties": false
}
```

#### Why `additionalProperties: false`?

Prevents unexpected parameters from being passed. This ensures:
- Type safety
- Clear API contracts
- Better error messages
- Schema validation

### Complete Schema Example

```javascript
{
    "$schema": "http://json-schema.org/draft-07/schema#",
    "type": "object",
    "properties": {
        "fileId": {
            "type": "string",
            "description": "Unique file identifier",
            "pattern": "^[a-zA-Z0-9-_]+$"
        },
        "options": {
            "type": "object",
            "properties": {
                "format": {
                    "type": "string",
                    "enum": ["json", "xml", "text"],
                    "default": "json"
                },
                "includeMetadata": {
                    "type": "boolean",
                    "default": true
                }
            },
            "additionalProperties": false
        },
        "tags": {
            "type": "array",
            "items": { "type": "string" },
            "minItems": 1,
            "uniqueItems": true
        }
    },
    "required": ["fileId"],
    "additionalProperties": false
}
```

### Schema Validation Patterns

```javascript
// Enum validation
{
    "type": "string",
    "enum": ["draft", "published", "archived"],
    "description": "Document status"
}

// Number ranges
{
    "type": "number",
    "minimum": 0,
    "maximum": 100,
    "description": "Percentage value"
}

// String patterns
{
    "type": "string",
    "pattern": "^[0-9]{4}-[0-9]{2}-[0-9]{2}$",
    "description": "Date in YYYY-MM-DD format"
}

// Array constraints
{
    "type": "array",
    "items": { "type": "string" },
    "minItems": 1,
    "maxItems": 50,
    "uniqueItems": true
}

// Nested objects
{
    "type": "object",
    "properties": {
        "user": {
            "type": "object",
            "properties": {
                "id": { "type": "string" },
                "name": { "type": "string" }
            },
            "required": ["id"],
            "additionalProperties": false
        }
    },
    "required": ["user"],
    "additionalProperties": false
}
```

---

## Transport Types

### 1. HTTP/REST Transport

**Best for:** Web applications, remote access, microservices

#### Server Configuration

```javascript
const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

// MCP Info Endpoint
app.get('/api/mcp/info', (req, res) => {
    res.json({
        protocolVersion: '2024-11-05',
        capabilities: { tools: {}, prompts: {}, resources: {}, logging: {} },
        serverInfo: { name: 'my-mcp-server', version: '1.0.0' },
        transport: {
            type: 'http',
            baseUrl: 'https://your-domain.com/api',
            endpoints: {
                initialize: '/api/mcp/initialize',
                list_functions: '/api/mcp/functions/list',
                call_function: '/api/mcp/functions/call',
                health: '/api/mcp/health'
            }
        }
    });
});

// Initialize Session
app.post('/api/mcp/initialize', async (req, res) => {
    const result = await mcpServer.initialize(req.body);
    res.json(result);
});

// List Functions
app.get('/api/mcp/functions/list', async (req, res) => {
    const result = await mcpServer.listFunctions();
    res.json(result);
});

// Both GET and POST support
app.post('/api/mcp/functions/list', async (req, res) => {
    const result = await mcpServer.listFunctions();
    res.json(result);
});

// Call Function
app.post('/api/mcp/functions/call', async (req, res) => {
    const { name, arguments: args } = req.body;
    const result = await mcpServer.callFunction(name, args);
    res.json(result);
});

// Health Check
app.get('/api/mcp/health', async (req, res) => {
    const health = await mcpServer.getHealthStatus();
    res.json(health);
});

app.listen(6701, () => {
    console.log('MCP HTTP Server running on port 6701');
});
```

#### Client Configuration (Claude Desktop / Cursor)

**Option A: Direct HTTP (with mcp-remote bridge)**

```json
{
  "mcpServers": {
    "my-server": {
      "command": "npx",
      "args": ["-y", "mcp-remote", "https://your-domain.com/api/mcp/info"],
      "description": "Your MCP Server"
    }
  }
}
```

**Option B: SSE Transport**

```json
{
  "mcpServers": {
    "my-server": {
      "url": "https://your-domain.com/api/mcp",
      "transport": "sse",
      "description": "Your MCP Server"
    }
  }
}
```

### 2. STDIO Transport

**Best for:** Local CLI tools, Claude Desktop native integration

#### Server Implementation

```javascript
#!/usr/bin/env node

const readline = require('readline');

class MCPStdioServer {
    constructor(mcpServer) {
        this.mcpServer = mcpServer;
        this.rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout,
            terminal: false
        });
    }

    start() {
        this.rl.on('line', async (line) => {
            try {
                const request = JSON.parse(line);
                const response = await this.handleRequest(request);
                console.log(JSON.stringify(response));
            } catch (error) {
                console.log(JSON.stringify({
                    jsonrpc: '2.0',
                    id: null,
                    error: {
                        code: -32700,
                        message: 'Parse error',
                        data: error.message
                    }
                }));
            }
        });
    }

    async handleRequest(request) {
        const { jsonrpc, id, method, params } = request;

        try {
            let result;

            switch (method) {
                case 'initialize':
                    result = await this.mcpServer.initialize(params);
                    break;
                case 'tools/list':
                    result = await this.mcpServer.listFunctions();
                    break;
                case 'tools/call':
                    result = await this.mcpServer.callFunction(
                        params.name,
                        params.arguments
                    );
                    break;
                default:
                    throw new Error(`Unknown method: ${method}`);
            }

            return {
                jsonrpc: '2.0',
                id,
                result
            };
        } catch (error) {
            return {
                jsonrpc: '2.0',
                id,
                error: {
                    code: -32603,
                    message: 'Internal error',
                    data: error.message
                }
            };
        }
    }
}

// Usage
const mcpServer = new MCPServer();
const stdioServer = new MCPStdioServer(mcpServer);
stdioServer.start();
```

#### Client Configuration

```json
{
  "mcpServers": {
    "my-server": {
      "command": "/path/to/your/mcp-stdio-server.js",
      "args": [],
      "description": "Your STDIO MCP Server"
    }
  }
}
```

---

## Agent Integration

### Pattern 1: Direct REST Integration

Agent makes HTTP calls directly to MCP endpoints.

```javascript
class MCPRestClient {
    constructor(baseUrl) {
        this.baseUrl = baseUrl;
        this.initialized = false;
    }

    async initialize() {
        const response = await fetch(`${this.baseUrl}/mcp/initialize`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                protocolVersion: '2024-11-05',
                clientInfo: {
                    name: 'my-agent',
                    version: '1.0.0'
                }
            })
        });
        this.initialized = true;
        return await response.json();
    }

    async listTools() {
        const response = await fetch(`${this.baseUrl}/mcp/functions/list`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });
        return await response.json();
    }

    async callTool(name, args) {
        const response = await fetch(`${this.baseUrl}/mcp/functions/call`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name,
                arguments: args
            })
        });
        return await response.json();
    }
}

// Usage Example
async function main() {
    const client = new MCPRestClient('https://your-domain.com/api');

    // Initialize
    await client.initialize();

    // List available tools
    const { tools } = await client.listTools();
    console.log('Available tools:', tools.map(t => t.name));

    // Call a tool
    const result = await client.callTool('search_documents', {
        query: 'MCP protocol',
        limit: 5
    });
    console.log('Result:', result);
}
```

### Pattern 2: CLI Stream Wrapper

Wrap your HTTP MCP server with a CLI that outputs to stdout.

```javascript
#!/usr/bin/env node

/**
 * MCP CLI Wrapper - Converts HTTP MCP to CLI interface
 * Usage: mcp-cli <command> [args]
 */

const http = require('http');

const BASE_URL = process.env.MCP_BASE_URL || 'http://localhost:6701/api';

async function httpRequest(path, method = 'GET', body = null) {
    const url = new URL(path, BASE_URL);

    return new Promise((resolve, reject) => {
        const options = {
            method,
            headers: { 'Content-Type': 'application/json' }
        };

        const req = http.request(url, options, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try {
                    resolve(JSON.parse(data));
                } catch (e) {
                    resolve(data);
                }
            });
        });

        req.on('error', reject);
        if (body) req.write(JSON.stringify(body));
        req.end();
    });
}

async function main() {
    const [,, command, ...args] = process.argv;

    try {
        let result;

        switch (command) {
            case 'init':
            case 'initialize':
                result = await httpRequest('/mcp/initialize', 'POST', {
                    protocolVersion: '2024-11-05'
                });
                break;

            case 'list':
            case 'list-tools':
                result = await httpRequest('/mcp/functions/list', 'POST');
                break;

            case 'call':
            case 'execute': {
                const [functionName, ...params] = args;
                const parsedArgs = params.length > 0
                    ? JSON.parse(params.join(' '))
                    : {};

                result = await httpRequest('/mcp/functions/call', 'POST', {
                    name: functionName,
                    arguments: parsedArgs
                });
                break;
            }

            case 'health':
                result = await httpRequest('/mcp/health', 'GET');
                break;

            case 'info':
                result = await httpRequest('/mcp/info', 'GET');
                break;

            default:
                console.error('Unknown command:', command);
                console.error('Usage: mcp-cli <init|list|call|health|info> [args]');
                process.exit(1);
        }

        // Output as JSON to stdout
        console.log(JSON.stringify(result, null, 2));

    } catch (error) {
        console.error('Error:', error.message);
        process.exit(1);
    }
}

main();
```

**Usage Examples:**

```bash
# Initialize
./mcp-cli init

# List tools
./mcp-cli list

# Call a function
./mcp-cli call search_documents '{"query": "test", "limit": 5}'

# Check health
./mcp-cli health

# Get server info
./mcp-cli info
```

### Pattern 3: Agent with Tool Registry

```javascript
class AIAgent {
    constructor(mcpClient) {
        this.mcp = mcpClient;
        this.toolRegistry = new Map();
    }

    async initialize() {
        await this.mcp.initialize();
        await this.loadTools();
    }

    async loadTools() {
        const { tools } = await this.mcp.listTools();

        for (const tool of tools) {
            this.toolRegistry.set(tool.name, {
                schema: tool.inputSchema,
                description: tool.description,
                executor: async (args) => await this.mcp.callTool(tool.name, args)
            });
        }

        console.log(`Loaded ${this.toolRegistry.size} tools`);
    }

    async executeTool(name, args) {
        const tool = this.toolRegistry.get(name);
        if (!tool) {
            throw new Error(`Tool '${name}' not found`);
        }

        // Validate args against schema
        this.validateArgs(args, tool.schema);

        // Execute
        return await tool.executor(args);
    }

    validateArgs(args, schema) {
        // Use a JSON Schema validator like 'ajv'
        const Ajv = require('ajv');
        const ajv = new Ajv();
        const validate = ajv.compile(schema);

        if (!validate(args)) {
            throw new Error(`Invalid arguments: ${JSON.stringify(validate.errors)}`);
        }
    }

    listAvailableTools() {
        return Array.from(this.toolRegistry.entries()).map(([name, tool]) => ({
            name,
            description: tool.description,
            parameters: tool.schema.properties
        }));
    }
}

// Usage
async function runAgent() {
    const client = new MCPRestClient('https://your-domain.com/api');
    const agent = new AIAgent(client);

    await agent.initialize();

    // List tools
    const tools = agent.listAvailableTools();
    console.log('Available:', tools);

    // Execute with validation
    const result = await agent.executeTool('search_documents', {
        query: 'MCP best practices',
        limit: 10
    });

    console.log('Search results:', result);
}
```

---

## Complete Examples

### Example 1: Database Query MCP Server

```javascript
const express = require('express');
const sqlite3 = require('sqlite3');
const { promisify } = require('util');

class DatabaseMCPServer {
    constructor(dbPath) {
        this.db = new sqlite3.Database(dbPath);
        this.dbAll = promisify(this.db.all.bind(this.db));
        this.dbGet = promisify(this.db.get.bind(this.db));
        this.functions = new Map();
        this.registerFunctions();
    }

    registerFunctions() {
        // Query function
        this.functions.set('query_database', {
            name: 'query_database',
            description: 'Execute a SELECT query on the database',
            parameters: {
                "$schema": "http://json-schema.org/draft-07/schema#",
                "type": "object",
                "properties": {
                    "table": {
                        "type": "string",
                        "description": "Table name to query",
                        "enum": ["users", "documents", "tasks"]
                    },
                    "filters": {
                        "type": "object",
                        "description": "WHERE clause filters",
                        "additionalProperties": {
                            "type": ["string", "number", "boolean"]
                        }
                    },
                    "limit": {
                        "type": "number",
                        "default": 100,
                        "minimum": 1,
                        "maximum": 1000
                    }
                },
                "required": ["table"],
                "additionalProperties": false
            },
            handler: async (params) => {
                const { table, filters = {}, limit = 100 } = params;

                let query = `SELECT * FROM ${table}`;
                const values = [];

                if (Object.keys(filters).length > 0) {
                    const conditions = Object.entries(filters)
                        .map(([key, value]) => {
                            values.push(value);
                            return `${key} = ?`;
                        });
                    query += ` WHERE ${conditions.join(' AND ')}`;
                }

                query += ` LIMIT ?`;
                values.push(limit);

                const results = await this.dbAll(query, values);
                return { results, count: results.length };
            }
        });

        // Count function
        this.functions.set('count_records', {
            name: 'count_records',
            description: 'Count records in a table',
            parameters: {
                "$schema": "http://json-schema.org/draft-07/schema#",
                "type": "object",
                "properties": {
                    "table": {
                        "type": "string",
                        "enum": ["users", "documents", "tasks"]
                    }
                },
                "required": ["table"],
                "additionalProperties": false
            },
            handler: async (params) => {
                const { table } = params;
                const result = await this.dbGet(
                    `SELECT COUNT(*) as count FROM ${table}`
                );
                return { table, count: result.count };
            }
        });
    }

    async listFunctions() {
        return {
            tools: Array.from(this.functions.values()).map(f => ({
                name: f.name,
                description: f.description,
                inputSchema: f.parameters
            }))
        };
    }

    async callFunction(name, args) {
        const func = this.functions.get(name);
        if (!func) {
            return {
                error: {
                    code: 'FUNCTION_NOT_FOUND',
                    message: `Function '${name}' not found`
                }
            };
        }

        try {
            const result = await func.handler(args);
            return {
                content: [{
                    type: 'text',
                    text: JSON.stringify(result, null, 2)
                }]
            };
        } catch (error) {
            return {
                error: {
                    code: 'EXECUTION_ERROR',
                    message: error.message
                }
            };
        }
    }
}

// Express Setup
const app = express();
app.use(express.json());

const mcpServer = new DatabaseMCPServer('./data.db');

app.get('/api/mcp/info', (req, res) => {
    res.json({
        protocolVersion: '2024-11-05',
        capabilities: { tools: {}, prompts: {}, resources: {}, logging: {} },
        serverInfo: { name: 'database-mcp', version: '1.0.0' }
    });
});

app.post('/api/mcp/functions/list', async (req, res) => {
    const result = await mcpServer.listFunctions();
    res.json(result);
});

app.post('/api/mcp/functions/call', async (req, res) => {
    const { name, arguments: args } = req.body;
    const result = await mcpServer.callFunction(name, args);
    res.json(result);
});

app.listen(6701);
```

### Example 2: File Operations MCP Server

```javascript
const fs = require('fs').promises;
const path = require('path');

class FileMCPServer {
    constructor(basePath) {
        this.basePath = basePath;
        this.functions = new Map();
        this.registerFunctions();
    }

    registerFunctions() {
        // Read file
        this.functions.set('read_file', {
            name: 'read_file',
            description: 'Read contents of a file',
            parameters: {
                "$schema": "http://json-schema.org/draft-07/schema#",
                "type": "object",
                "properties": {
                    "filePath": {
                        "type": "string",
                        "description": "Path to file relative to base directory"
                    },
                    "encoding": {
                        "type": "string",
                        "enum": ["utf8", "base64"],
                        "default": "utf8"
                    }
                },
                "required": ["filePath"],
                "additionalProperties": false
            },
            handler: async (params) => {
                const fullPath = path.join(this.basePath, params.filePath);

                // Security: prevent path traversal
                if (!fullPath.startsWith(this.basePath)) {
                    throw new Error('Access denied');
                }

                const content = await fs.readFile(
                    fullPath,
                    params.encoding || 'utf8'
                );

                return {
                    filePath: params.filePath,
                    size: content.length,
                    content: content
                };
            }
        });

        // List directory
        this.functions.set('list_directory', {
            name: 'list_directory',
            description: 'List contents of a directory',
            parameters: {
                "$schema": "http://json-schema.org/draft-07/schema#",
                "type": "object",
                "properties": {
                    "dirPath": {
                        "type": "string",
                        "description": "Directory path",
                        "default": "."
                    },
                    "recursive": {
                        "type": "boolean",
                        "default": false
                    }
                },
                "required": [],
                "additionalProperties": false
            },
            handler: async (params) => {
                const { dirPath = '.', recursive = false } = params;
                const fullPath = path.join(this.basePath, dirPath);

                if (!fullPath.startsWith(this.basePath)) {
                    throw new Error('Access denied');
                }

                const files = await fs.readdir(fullPath, {
                    withFileTypes: true
                });

                const results = await Promise.all(
                    files.map(async (file) => {
                        const stats = await fs.stat(
                            path.join(fullPath, file.name)
                        );
                        return {
                            name: file.name,
                            type: file.isDirectory() ? 'directory' : 'file',
                            size: stats.size,
                            modified: stats.mtime
                        };
                    })
                );

                return {
                    path: dirPath,
                    items: results
                };
            }
        });
    }

    // ... implement listFunctions() and callFunction() similar to previous example
}
```

---

## Best Practices

### 1. Schema Design

✅ **DO:**
- Always include `$schema` field
- Set `additionalProperties: false`
- Provide clear descriptions
- Use enums for known values
- Set sensible defaults
- Define min/max constraints
- Use `required` array explicitly

❌ **DON'T:**
- Omit schema validation
- Allow arbitrary properties
- Use vague descriptions
- Accept unrestricted inputs
- Skip type definitions

### 2. Error Handling

```javascript
// Good error response
{
    error: {
        code: 'INVALID_PARAMETER',
        message: 'fileId must be a valid UUID',
        data: {
            field: 'fileId',
            provided: 'abc123',
            expected: 'UUID format'
        }
    }
}

// Error codes standard
const ERROR_CODES = {
    FUNCTION_NOT_FOUND: 'FUNCTION_NOT_FOUND',
    INVALID_PARAMETER: 'INVALID_PARAMETER',
    EXECUTION_ERROR: 'EXECUTION_ERROR',
    PERMISSION_DENIED: 'PERMISSION_DENIED',
    RESOURCE_NOT_FOUND: 'RESOURCE_NOT_FOUND',
    RATE_LIMIT_EXCEEDED: 'RATE_LIMIT_EXCEEDED'
};
```

### 3. Logging & Monitoring

```javascript
class MCPUsageLogger {
    async logExecution(data) {
        await db.run(`
            INSERT INTO mcp_executions
            (function_name, parameters, result, duration_ms, timestamp)
            VALUES (?, ?, ?, ?, ?)
        `, [
            data.functionName,
            JSON.stringify(data.parameters),
            JSON.stringify(data.result),
            data.duration,
            Date.now()
        ]);
    }

    async getUsageStats() {
        return await db.all(`
            SELECT
                function_name,
                COUNT(*) as call_count,
                AVG(duration_ms) as avg_duration,
                MAX(timestamp) as last_called
            FROM mcp_executions
            GROUP BY function_name
            ORDER BY call_count DESC
        `);
    }
}
```

### 4. Security

```javascript
// Input sanitization
function sanitizePath(userPath, basePath) {
    const fullPath = path.join(basePath, userPath);
    const normalized = path.normalize(fullPath);

    // Prevent directory traversal
    if (!normalized.startsWith(basePath)) {
        throw new Error('Access denied');
    }

    return normalized;
}

// Rate limiting
const rateLimit = require('express-rate-limit');

const mcpLimiter = rateLimit({
    windowMs: 60 * 1000, // 1 minute
    max: 100, // 100 requests per minute
    message: {
        error: {
            code: 'RATE_LIMIT_EXCEEDED',
            message: 'Too many requests'
        }
    }
});

app.use('/api/mcp', mcpLimiter);

// Authentication
function authMiddleware(req, res, next) {
    const token = req.headers.authorization?.replace('Bearer ', '');

    if (!token || !isValidToken(token)) {
        return res.status(401).json({
            error: {
                code: 'UNAUTHORIZED',
                message: 'Invalid or missing authentication token'
            }
        });
    }

    next();
}

app.use('/api/mcp', authMiddleware);
```

### 5. Testing

```javascript
// Test suite example
const assert = require('assert');

async function testMCPServer() {
    const server = new MCPHttpServer();

    // Test 1: Initialize
    const initResult = await server.initialize({});
    assert.equal(initResult.protocolVersion, '2024-11-05');

    // Test 2: List functions
    const { tools } = await server.listFunctions();
    assert(tools.length > 0);
    assert(tools.every(t => t.name && t.description && t.inputSchema));

    // Test 3: Call function
    const result = await server.callFunction('healthcheck', {});
    assert(result.content || result.error);

    // Test 4: Schema validation
    const invalidResult = await server.callFunction('search_documents', {
        invalid_param: 'test'
    });
    assert(invalidResult.error);
    assert.equal(invalidResult.error.code, 'INVALID_PARAMETER');

    console.log('✅ All tests passed');
}
```

### 6. Performance

```javascript
// Function caching
class CachedMCPServer extends MCPHttpServer {
    constructor() {
        super();
        this.cache = new Map();
        this.cacheTTL = 60000; // 1 minute
    }

    async callFunction(name, args) {
        const cacheKey = `${name}:${JSON.stringify(args)}`;
        const cached = this.cache.get(cacheKey);

        if (cached && Date.now() - cached.timestamp < this.cacheTTL) {
            return cached.result;
        }

        const result = await super.callFunction(name, args);

        this.cache.set(cacheKey, {
            result,
            timestamp: Date.now()
        });

        return result;
    }
}

// Database connection pooling
const { Pool } = require('pg');
const pool = new Pool({
    max: 20,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 2000
});
```

### 7. Documentation

Generate OpenAPI/Swagger from MCP schemas:

```javascript
function generateOpenAPISpec(mcpServer) {
    const spec = {
        openapi: '3.0.0',
        info: {
            title: mcpServer.serverInfo.name,
            version: mcpServer.serverInfo.version
        },
        paths: {}
    };

    for (const [name, func] of mcpServer.functions) {
        spec.paths[`/api/mcp/functions/${name}`] = {
            post: {
                summary: func.description,
                requestBody: {
                    content: {
                        'application/json': {
                            schema: func.parameters
                        }
                    }
                },
                responses: {
                    200: {
                        description: 'Function executed successfully'
                    }
                }
            }
        };
    }

    return spec;
}
```

---

## Summary Checklist

When implementing an MCP server, ensure:

- ✅ Protocol version `2024-11-05` specified
- ✅ All schemas include `$schema` field
- ✅ `additionalProperties: false` on all objects
- ✅ Clear, descriptive function names
- ✅ Comprehensive parameter descriptions
- ✅ Proper error handling with codes
- ✅ Security validation (path traversal, injection, etc.)
- ✅ Rate limiting on public endpoints
- ✅ Usage logging for monitoring
- ✅ Both GET and POST support on list endpoints
- ✅ Health check endpoint
- ✅ Proper CORS configuration
- ✅ Transport info in server response
- ✅ Validation before execution
- ✅ Comprehensive tests

---

## Additional Resources

- **MCP Specification**: https://spec.modelcontextprotocol.io/
- **JSON Schema**: https://json-schema.org/draft-07/schema
- **mcp-remote package**: For bridging HTTP to STDIO
- **Example implementations**: See `mcp-http-server.js` in this repository

---

**Version:** 1.0
**Last Updated:** 2025-10-05
**Protocol Version:** 2024-11-05

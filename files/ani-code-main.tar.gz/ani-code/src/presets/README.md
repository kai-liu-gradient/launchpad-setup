# Preset Templates for /remember Command

This directory contains preset templates that can be used with the `/remember` command using the `@preset.md` syntax.

## Usage

```bash
# Use a preset template
ani-code remember "@coder.md the port of current project is 3000"

# The preset content will be loaded and combined with your additional information
ani-code remember "@api.md base URL is https://api.example.com"

# Use preset alone without additional info
ani-code remember "@database.md"
```

## Available Presets

- **@coder.md** - General project configuration template
- **@api.md** - API endpoint and configuration template
- **@database.md** - Database connection and schema template
- **@security.md** - Security and authentication configuration template
- **@refactor.md** - Code refactoring best practices and patterns (for complex files >1000 lines)

## Healthcheck Presets

The `healthcheck/` subdirectory contains presets for the `ani-code healthcheck` command:

- **healthcheck/auto.md** - Auto-detection and multi-stack aggregation
- **healthcheck/node.md** - Node.js/npm analysis preset
- **healthcheck/python.md** - Python placeholder (NOT_IMPLEMENTED)
- **healthcheck/go.md** - Go placeholder (NOT_IMPLEMENTED)
- **healthcheck/rust.md** - Rust placeholder (NOT_IMPLEMENTED)
- **healthcheck/_schema.md** - JSON output schema v1.0.0
- **healthcheck/report-template.html** - HTML report template

See `healthcheck/README.md` for detailed documentation on creating and modifying healthcheck presets.

## Creating Custom Presets

To create a custom preset:
1. Create a new `.md` file in this directory
2. Use markdown formatting with placeholders like `[SPECIFY VALUE]`
3. The preset can then be used with `@yourpreset.md` syntax

## Example

If you create `myapp.md` in this directory, you can use it like:
```bash
ani-code remember "@myapp.md specific configuration here"
```

The preset content will be loaded and combined with any additional text you provide.
/**
 * Projects Command Module
 * Project discovery and version management for workspaces
 */

import { Command } from 'commander';
import chalk from 'chalk';
import { existsSync, readFileSync, writeFileSync, mkdirSync, readdirSync, statSync } from 'fs';
import { join, relative, basename, dirname } from 'path';

/**
 * Supported manifest types and their detection patterns
 */
const MANIFEST_TYPES = {
  'package.json': {
    techstack: 'node',
    name: 'Node.js',
    priority: 1,
    parser: parsePackageJson
  },
  'pyproject.toml': {
    techstack: 'python',
    name: 'Python (modern)',
    priority: 2,
    parser: parsePyprojectToml
  },
  'setup.py': {
    techstack: 'python',
    name: 'Python (legacy)',
    priority: 3,
    parser: parseSetupPy
  },
  'requirements.txt': {
    techstack: 'python',
    name: 'Python (minimal)',
    priority: 4,
    parser: parseRequirementsTxt
  },
  'Pipfile': {
    techstack: 'python',
    name: 'Python (Pipenv)',
    priority: 5,
    parser: parsePipfile
  },
  'go.mod': {
    techstack: 'go',
    name: 'Go',
    priority: 6,
    parser: parseGoMod
  },
  'Cargo.toml': {
    techstack: 'rust',
    name: 'Rust',
    priority: 7,
    parser: parseCargoToml
  },
  'pom.xml': {
    techstack: 'java',
    name: 'Java (Maven)',
    priority: 8,
    parser: parsePomXml
  },
  'build.gradle': {
    techstack: 'java',
    name: 'Java (Gradle)',
    priority: 9,
    parser: parseBuildGradle
  },
  'build.gradle.kts': {
    techstack: 'java',
    name: 'Java (Gradle Kotlin)',
    priority: 10,
    parser: parseBuildGradle
  },
  'composer.json': {
    techstack: 'php',
    name: 'PHP',
    priority: 11,
    parser: parseComposerJson
  }
};

/**
 * Default exclusion patterns
 */
const DEFAULT_EXCLUSIONS = [
  'node_modules',
  '.git',
  'dist',
  'build',
  '.ani-code',
  'vendor',
  '__pycache__',
  '.venv',
  'venv',
  '.env',
  'target',
  '.gradle',
  '.idea',
  '.vscode',
  'coverage',
  '.next',
  '.nuxt',
  'out'
];

/**
 * Registry schema version
 */
const SCHEMA_VERSION = '1.0.0';

/**
 * Projects directory configuration
 */
const PROJECTS_DIR = '.ani-code/projects';

// ============================================================================
// Manifest Parsers
// ============================================================================

/**
 * Parse package.json manifest
 * @param {string} filePath - Path to package.json
 * @returns {Object} Parsed metadata
 */
function parsePackageJson(filePath) {
  try {
    const content = JSON.parse(readFileSync(filePath, 'utf8'));

    // Count dependencies
    const deps = content.dependencies ? Object.keys(content.dependencies).length : 0;
    const devDeps = content.devDependencies ? Object.keys(content.devDependencies).length : 0;

    // Check for lock files
    const dir = dirname(filePath);
    const hasLockFile = existsSync(join(dir, 'package-lock.json')) ||
                        existsSync(join(dir, 'yarn.lock')) ||
                        existsSync(join(dir, 'pnpm-lock.yaml'));

    return {
      name: content.name || basename(dirname(filePath)),
      description: content.description || '',
      version: content.version || '0.0.0',
      metadata: {
        hasLockFile,
        dependencies: deps,
        devDependencies: devDeps,
        private: content.private || false,
        scripts: content.scripts ? Object.keys(content.scripts) : []
      },
      rawManifest: content
    };
  } catch (error) {
    return {
      name: basename(dirname(filePath)),
      description: '',
      version: '0.0.0',
      error: error.message
    };
  }
}

/**
 * Parse pyproject.toml manifest
 * @param {string} filePath - Path to pyproject.toml
 * @returns {Object} Parsed metadata
 */
function parsePyprojectToml(filePath) {
  try {
    const content = readFileSync(filePath, 'utf8');

    // Simple TOML parsing for common fields
    const nameMatch = content.match(/name\s*=\s*["']([^"']+)["']/);
    const versionMatch = content.match(/version\s*=\s*["']([^"']+)["']/);
    const descMatch = content.match(/description\s*=\s*["']([^"']+)["']/);

    return {
      name: nameMatch ? nameMatch[1] : basename(dirname(filePath)),
      description: descMatch ? descMatch[1] : '',
      version: versionMatch ? versionMatch[1] : '0.0.0',
      metadata: {
        hasPoetryLock: existsSync(join(dirname(filePath), 'poetry.lock')),
        hasUvLock: existsSync(join(dirname(filePath), 'uv.lock'))
      }
    };
  } catch (error) {
    return {
      name: basename(dirname(filePath)),
      description: '',
      version: '0.0.0',
      error: error.message
    };
  }
}

/**
 * Parse setup.py manifest
 * @param {string} filePath - Path to setup.py
 * @returns {Object} Parsed metadata
 */
function parseSetupPy(filePath) {
  try {
    const content = readFileSync(filePath, 'utf8');

    // Extract name and version from setup() call
    const nameMatch = content.match(/name\s*=\s*["']([^"']+)["']/);
    const versionMatch = content.match(/version\s*=\s*["']([^"']+)["']/);
    const descMatch = content.match(/description\s*=\s*["']([^"']+)["']/);

    return {
      name: nameMatch ? nameMatch[1] : basename(dirname(filePath)),
      description: descMatch ? descMatch[1] : '',
      version: versionMatch ? versionMatch[1] : '0.0.0',
      metadata: {}
    };
  } catch (error) {
    return {
      name: basename(dirname(filePath)),
      description: '',
      version: '0.0.0',
      error: error.message
    };
  }
}

/**
 * Parse requirements.txt manifest
 * @param {string} filePath - Path to requirements.txt
 * @returns {Object} Parsed metadata
 */
function parseRequirementsTxt(filePath) {
  try {
    const content = readFileSync(filePath, 'utf8');
    const lines = content.split('\n').filter(l => l.trim() && !l.startsWith('#'));

    return {
      name: basename(dirname(filePath)),
      description: 'Python project (requirements.txt)',
      version: '0.0.0',
      metadata: {
        dependencyCount: lines.length
      }
    };
  } catch (error) {
    return {
      name: basename(dirname(filePath)),
      description: '',
      version: '0.0.0',
      error: error.message
    };
  }
}

/**
 * Parse Pipfile manifest
 * @param {string} filePath - Path to Pipfile
 * @returns {Object} Parsed metadata
 */
function parsePipfile(filePath) {
  try {
    const content = readFileSync(filePath, 'utf8');

    return {
      name: basename(dirname(filePath)),
      description: 'Python project (Pipenv)',
      version: '0.0.0',
      metadata: {
        hasPipfileLock: existsSync(join(dirname(filePath), 'Pipfile.lock'))
      }
    };
  } catch (error) {
    return {
      name: basename(dirname(filePath)),
      description: '',
      version: '0.0.0',
      error: error.message
    };
  }
}

/**
 * Parse go.mod manifest
 * @param {string} filePath - Path to go.mod
 * @returns {Object} Parsed metadata
 */
function parseGoMod(filePath) {
  try {
    const content = readFileSync(filePath, 'utf8');

    // Extract module name
    const moduleMatch = content.match(/module\s+(\S+)/);
    const goVersionMatch = content.match(/go\s+(\d+\.\d+)/);

    // Count require statements
    const requireMatches = content.match(/require\s+\(/g) || [];
    const singleRequires = (content.match(/^require\s+\S+/gm) || []).length;

    return {
      name: moduleMatch ? moduleMatch[1].split('/').pop() : basename(dirname(filePath)),
      description: moduleMatch ? `Go module: ${moduleMatch[1]}` : '',
      version: '0.0.0', // Go uses module versioning, not package versioning
      metadata: {
        module: moduleMatch ? moduleMatch[1] : '',
        goVersion: goVersionMatch ? goVersionMatch[1] : '',
        hasGoSum: existsSync(join(dirname(filePath), 'go.sum'))
      }
    };
  } catch (error) {
    return {
      name: basename(dirname(filePath)),
      description: '',
      version: '0.0.0',
      error: error.message
    };
  }
}

/**
 * Parse Cargo.toml manifest
 * @param {string} filePath - Path to Cargo.toml
 * @returns {Object} Parsed metadata
 */
function parseCargoToml(filePath) {
  try {
    const content = readFileSync(filePath, 'utf8');

    // Simple TOML parsing for common fields
    const nameMatch = content.match(/name\s*=\s*["']([^"']+)["']/);
    const versionMatch = content.match(/version\s*=\s*["']([^"']+)["']/);
    const descMatch = content.match(/description\s*=\s*["']([^"']+)["']/);

    return {
      name: nameMatch ? nameMatch[1] : basename(dirname(filePath)),
      description: descMatch ? descMatch[1] : '',
      version: versionMatch ? versionMatch[1] : '0.0.0',
      metadata: {
        hasCargoLock: existsSync(join(dirname(filePath), 'Cargo.lock'))
      }
    };
  } catch (error) {
    return {
      name: basename(dirname(filePath)),
      description: '',
      version: '0.0.0',
      error: error.message
    };
  }
}

/**
 * Parse pom.xml manifest
 * @param {string} filePath - Path to pom.xml
 * @returns {Object} Parsed metadata
 */
function parsePomXml(filePath) {
  try {
    const content = readFileSync(filePath, 'utf8');

    // Simple XML parsing for common fields
    const artifactMatch = content.match(/<artifactId>([^<]+)<\/artifactId>/);
    const versionMatch = content.match(/<version>([^<]+)<\/version>/);
    const nameMatch = content.match(/<name>([^<]+)<\/name>/);
    const descMatch = content.match(/<description>([^<]+)<\/description>/);

    return {
      name: artifactMatch ? artifactMatch[1] : basename(dirname(filePath)),
      description: descMatch ? descMatch[1] : (nameMatch ? nameMatch[1] : ''),
      version: versionMatch ? versionMatch[1] : '0.0.0',
      metadata: {
        artifactId: artifactMatch ? artifactMatch[1] : ''
      }
    };
  } catch (error) {
    return {
      name: basename(dirname(filePath)),
      description: '',
      version: '0.0.0',
      error: error.message
    };
  }
}

/**
 * Parse build.gradle or build.gradle.kts manifest
 * @param {string} filePath - Path to build.gradle
 * @returns {Object} Parsed metadata
 */
function parseBuildGradle(filePath) {
  try {
    const content = readFileSync(filePath, 'utf8');

    // Extract version and group
    const versionMatch = content.match(/version\s*[=:]\s*["']([^"']+)["']/);
    const groupMatch = content.match(/group\s*[=:]\s*["']([^"']+)["']/);

    // Check for settings.gradle to get project name
    const settingsPath = join(dirname(filePath), 'settings.gradle');
    const settingsKtsPath = join(dirname(filePath), 'settings.gradle.kts');
    let projectName = basename(dirname(filePath));

    if (existsSync(settingsPath)) {
      const settingsContent = readFileSync(settingsPath, 'utf8');
      const nameMatch = settingsContent.match(/rootProject\.name\s*=\s*["']([^"']+)["']/);
      if (nameMatch) projectName = nameMatch[1];
    } else if (existsSync(settingsKtsPath)) {
      const settingsContent = readFileSync(settingsKtsPath, 'utf8');
      const nameMatch = settingsContent.match(/rootProject\.name\s*=\s*["']([^"']+)["']/);
      if (nameMatch) projectName = nameMatch[1];
    }

    return {
      name: projectName,
      description: groupMatch ? `${groupMatch[1]}.${projectName}` : '',
      version: versionMatch ? versionMatch[1] : '0.0.0',
      metadata: {
        group: groupMatch ? groupMatch[1] : ''
      }
    };
  } catch (error) {
    return {
      name: basename(dirname(filePath)),
      description: '',
      version: '0.0.0',
      error: error.message
    };
  }
}

/**
 * Parse composer.json manifest
 * @param {string} filePath - Path to composer.json
 * @returns {Object} Parsed metadata
 */
function parseComposerJson(filePath) {
  try {
    const content = JSON.parse(readFileSync(filePath, 'utf8'));

    // Count dependencies
    const deps = content.require ? Object.keys(content.require).length : 0;
    const devDeps = content['require-dev'] ? Object.keys(content['require-dev']).length : 0;

    return {
      name: content.name || basename(dirname(filePath)),
      description: content.description || '',
      version: content.version || '0.0.0',
      metadata: {
        hasLockFile: existsSync(join(dirname(filePath), 'composer.lock')),
        dependencies: deps,
        devDependencies: devDeps
      },
      rawManifest: content
    };
  } catch (error) {
    return {
      name: basename(dirname(filePath)),
      description: '',
      version: '0.0.0',
      error: error.message
    };
  }
}

// ============================================================================
// Scanner Functions
// ============================================================================

/**
 * Check if a path should be excluded
 * @param {string} pathName - Directory or file name
 * @param {string[]} exclusions - Array of exclusion patterns
 * @returns {boolean} True if should be excluded
 */
function shouldExclude(pathName, exclusions) {
  return exclusions.some(pattern => {
    // Support simple glob patterns
    if (pattern.includes('*')) {
      const regex = new RegExp('^' + pattern.replace(/\*/g, '.*') + '$');
      return regex.test(pathName);
    }
    return pathName === pattern;
  });
}

/**
 * Recursively scan directory for project manifests
 * @param {string} dir - Directory to scan
 * @param {string} workspacePath - Root workspace path
 * @param {string[]} exclusions - Exclusion patterns
 * @param {number} maxDepth - Maximum scan depth
 * @param {number} currentDepth - Current depth
 * @returns {Array} Array of discovered projects
 */
function scanDirectory(dir, workspacePath, exclusions, maxDepth, currentDepth = 0) {
  const projects = [];

  if (currentDepth > maxDepth) {
    return projects;
  }

  try {
    const entries = readdirSync(dir, { withFileTypes: true });

    // First, check for manifest files in current directory
    for (const entry of entries) {
      if (entry.isFile() && MANIFEST_TYPES[entry.name]) {
        const manifestPath = join(dir, entry.name);
        const manifestType = MANIFEST_TYPES[entry.name];
        const parsed = manifestType.parser(manifestPath);

        // Generate unique ID
        const relativePath = relative(workspacePath, dir);
        const projectId = relativePath ?
          relativePath.replace(/[/\\]/g, '-').toLowerCase() :
          parsed.name.toLowerCase();

        // Check if this project already exists (avoid duplicates for same directory)
        const existingIndex = projects.findIndex(p => p.path === (relativePath || '.'));

        if (existingIndex === -1 || MANIFEST_TYPES[projects[existingIndex].manifestType]?.priority > manifestType.priority) {
          const project = {
            id: projectId,
            name: parsed.name,
            description: parsed.description,
            version: parsed.version,
            path: relativePath || '.',
            manifestPath: relative(workspacePath, manifestPath),
            manifestType: entry.name,
            techstack: manifestType.techstack,
            lastModified: statSync(manifestPath).mtime.toISOString(),
            metadata: parsed.metadata || {}
          };

          if (existingIndex !== -1) {
            projects[existingIndex] = project;
          } else {
            projects.push(project);
          }
        }
      }
    }

    // Then recursively scan subdirectories
    for (const entry of entries) {
      if (entry.isDirectory() && !shouldExclude(entry.name, exclusions)) {
        const subDir = join(dir, entry.name);
        const subProjects = scanDirectory(subDir, workspacePath, exclusions, maxDepth, currentDepth + 1);
        projects.push(...subProjects);
      }
    }
  } catch (error) {
    // Ignore permission errors and continue
    if (error.code !== 'EACCES' && error.code !== 'ENOENT') {
      console.error(chalk.yellow(`  Warning: Could not scan ${dir}: ${error.message}`));
    }
  }

  return projects;
}

/**
 * Ensure projects output directory exists
 * @param {string} workspacePath - Workspace path
 * @returns {string} Full path to projects directory
 */
function ensureProjectsDirectory(workspacePath) {
  const outputDir = join(workspacePath, PROJECTS_DIR);
  if (!existsSync(outputDir)) {
    mkdirSync(outputDir, { recursive: true });
  }
  return outputDir;
}

/**
 * Load existing registry if present
 * @param {string} workspacePath - Workspace path
 * @returns {Object|null} Existing registry or null
 */
function loadRegistry(workspacePath) {
  const registryPath = join(workspacePath, PROJECTS_DIR, 'registry.json');
  if (existsSync(registryPath)) {
    try {
      return JSON.parse(readFileSync(registryPath, 'utf8'));
    } catch (error) {
      return null;
    }
  }
  return null;
}

/**
 * Save registry to file
 * @param {string} workspacePath - Workspace path
 * @param {Object} registry - Registry data
 */
function saveRegistry(workspacePath, registry) {
  const outputDir = ensureProjectsDirectory(workspacePath);
  const registryPath = join(outputDir, 'registry.json');
  writeFileSync(registryPath, JSON.stringify(registry, null, 2));
}

/**
 * Save individual project file
 * @param {string} workspacePath - Workspace path
 * @param {Object} project - Project data
 */
function saveProjectFile(workspacePath, project) {
  const outputDir = ensureProjectsDirectory(workspacePath);
  const projectPath = join(outputDir, `${project.id}.json`);

  const projectData = {
    ...project,
    versionHistory: []
  };

  // Load existing project file to preserve version history
  if (existsSync(projectPath)) {
    try {
      const existing = JSON.parse(readFileSync(projectPath, 'utf8'));
      if (existing.versionHistory) {
        projectData.versionHistory = existing.versionHistory;
      }
      // Add current version to history if it changed
      if (existing.version !== project.version) {
        projectData.versionHistory.push({
          version: existing.version,
          timestamp: existing.lastModified || new Date().toISOString(),
          source: 'scan'
        });
      }
    } catch (e) {
      // Ignore
    }
  }

  writeFileSync(projectPath, JSON.stringify(projectData, null, 2));
}

// ============================================================================
// Version Management Functions
// ============================================================================

/**
 * Increment semantic version
 * @param {string} version - Current version
 * @param {string} part - Part to increment (major, minor, patch)
 * @returns {string} New version
 */
function incrementVersion(version, part = 'patch') {
  // Handle common version formats
  const match = version.match(/^(\d+)\.(\d+)\.(\d+)(.*)$/);
  if (!match) {
    // If not semver, try to add .0.1 or increment last number
    const numMatch = version.match(/(\d+)$/);
    if (numMatch) {
      const num = parseInt(numMatch[1], 10);
      return version.replace(/\d+$/, String(num + 1));
    }
    return version + '.0.1';
  }

  let [, major, minor, patch, suffix] = match;
  major = parseInt(major, 10);
  minor = parseInt(minor, 10);
  patch = parseInt(patch, 10);

  switch (part) {
    case 'major':
      return `${major + 1}.0.0${suffix}`;
    case 'minor':
      return `${major}.${minor + 1}.0${suffix}`;
    case 'patch':
    default:
      return `${major}.${minor}.${patch + 1}${suffix}`;
  }
}

/**
 * Update version in manifest file
 * @param {string} manifestPath - Full path to manifest file
 * @param {string} manifestType - Type of manifest (package.json, etc.)
 * @param {string} newVersion - New version to set
 * @returns {boolean} Success
 */
function updateManifestVersion(manifestPath, manifestType, newVersion) {
  try {
    const content = readFileSync(manifestPath, 'utf8');
    let newContent;

    switch (manifestType) {
      case 'package.json':
      case 'composer.json': {
        const json = JSON.parse(content);
        json.version = newVersion;
        newContent = JSON.stringify(json, null, 2) + '\n';
        break;
      }

      case 'pyproject.toml':
      case 'Cargo.toml': {
        newContent = content.replace(
          /version\s*=\s*["'][^"']+["']/,
          `version = "${newVersion}"`
        );
        break;
      }

      case 'setup.py': {
        newContent = content.replace(
          /version\s*=\s*["'][^"']+["']/,
          `version="${newVersion}"`
        );
        break;
      }

      case 'pom.xml': {
        // Only update first <version> (project version, not parent)
        let replaced = false;
        newContent = content.replace(
          /<version>([^<]+)<\/version>/,
          (match) => {
            if (!replaced) {
              replaced = true;
              return `<version>${newVersion}</version>`;
            }
            return match;
          }
        );
        break;
      }

      case 'build.gradle':
      case 'build.gradle.kts': {
        newContent = content.replace(
          /version\s*[=:]\s*["'][^"']+["']/,
          `version = '${newVersion}'`
        );
        break;
      }

      default:
        return false;
    }

    if (newContent && newContent !== content) {
      writeFileSync(manifestPath, newContent);
      return true;
    }

    return false;
  } catch (error) {
    console.error(chalk.red(`  Error updating ${manifestPath}: ${error.message}`));
    return false;
  }
}

/**
 * Find project by name or ID in registry
 * @param {Object} registry - Registry data
 * @param {string} query - Project name or ID
 * @returns {Object|null} Project or null
 */
function findProject(registry, query) {
  if (!registry || !registry.projects) return null;

  const lowerQuery = query.toLowerCase();
  return registry.projects.find(p =>
    p.id.toLowerCase() === lowerQuery ||
    p.name.toLowerCase() === lowerQuery
  );
}

// ============================================================================
// Command Actions
// ============================================================================

/**
 * Run project scan
 * @param {string} workspacePath - Workspace path
 * @param {Object} options - Command options
 */
async function runScan(workspacePath, options) {
  const { exclude, depth, force } = options;

  console.log(chalk.cyan('\n📁 Scanning for Projects'));
  console.log(chalk.gray('═'.repeat(60)));
  console.log(chalk.gray(`Workspace: ${workspacePath}`));
  console.log(chalk.gray(`Max Depth: ${depth}`));

  // Check for existing registry
  if (!force) {
    const existing = loadRegistry(workspacePath);
    if (existing) {
      const age = Date.now() - new Date(existing.lastScan).getTime();
      const ageMinutes = Math.floor(age / 60000);
      if (ageMinutes < 5) {
        console.log(chalk.yellow(`\n⚠ Registry is ${ageMinutes} minute(s) old. Use --force to rescan.`));
        console.log(chalk.gray(`Last scan: ${existing.lastScan}`));
        console.log(chalk.gray(`Projects: ${existing.projectCount}`));
        return existing;
      }
    }
  }

  // Build exclusion list
  const exclusions = [...DEFAULT_EXCLUSIONS];
  if (exclude) {
    exclusions.push(...exclude.split(',').map(s => s.trim()));
  }
  console.log(chalk.gray(`Exclusions: ${exclusions.length} patterns`));

  // Scan for projects
  console.log(chalk.gray('\nScanning...'));
  const startTime = Date.now();
  const projects = scanDirectory(workspacePath, workspacePath, exclusions, depth);
  const scanTime = Date.now() - startTime;

  console.log(chalk.green(`\n✓ Found ${projects.length} project(s) in ${scanTime}ms`));

  // Build registry
  const registry = {
    version: SCHEMA_VERSION,
    lastScan: new Date().toISOString(),
    workspacePath,
    scanDepth: depth,
    exclusions,
    projectCount: projects.length,
    projects
  };

  // Save registry and individual project files
  saveRegistry(workspacePath, registry);
  for (const project of projects) {
    saveProjectFile(workspacePath, project);
  }

  // Display results
  if (projects.length > 0) {
    console.log(chalk.cyan('\nDiscovered Projects:'));
    console.log(chalk.gray('─'.repeat(60)));

    // Group by techstack
    const byStack = {};
    for (const project of projects) {
      if (!byStack[project.techstack]) {
        byStack[project.techstack] = [];
      }
      byStack[project.techstack].push(project);
    }

    for (const [stack, stackProjects] of Object.entries(byStack)) {
      console.log(chalk.yellow(`\n${stack.toUpperCase()} (${stackProjects.length}):`));
      for (const p of stackProjects) {
        console.log(`  ${chalk.white(p.name)} ${chalk.gray(`v${p.version}`)} ${chalk.gray(`(${p.path})`)}`);
      }
    }
  }

  console.log(chalk.green(`\n✅ Registry saved to ${PROJECTS_DIR}/registry.json`));

  return registry;
}

/**
 * List all projects
 * @param {string} workspacePath - Workspace path
 * @param {Object} options - Command options
 */
async function listProjects(workspacePath, options) {
  const { json, tree } = options;

  const registry = loadRegistry(workspacePath);
  if (!registry) {
    console.log(chalk.yellow('No project registry found. Run "ani-code projects scan" first.'));
    return;
  }

  if (json) {
    console.log(JSON.stringify(registry.projects, null, 2));
    return;
  }

  if (tree) {
    console.log(chalk.cyan('\n📁 Project Tree'));
    console.log(chalk.gray('═'.repeat(60)));

    // Build tree structure
    const tree = {};
    for (const project of registry.projects) {
      const parts = project.path.split(/[/\\]/);
      let current = tree;
      for (const part of parts) {
        if (!current[part]) {
          current[part] = {};
        }
        current = current[part];
      }
      current.__project__ = project;
    }

    // Print tree
    function printTree(node, prefix = '') {
      const keys = Object.keys(node).filter(k => k !== '__project__');

      if (node.__project__) {
        const p = node.__project__;
        console.log(`${prefix}📦 ${chalk.white(p.name)} ${chalk.gray(`v${p.version}`)} ${chalk.cyan(`[${p.techstack}]`)}`);
      }

      keys.forEach((key, i) => {
        const isLast = i === keys.length - 1;
        const newPrefix = prefix + (isLast ? '└── ' : '├── ');
        const childPrefix = prefix + (isLast ? '    ' : '│   ');

        if (!node[key].__project__) {
          console.log(`${newPrefix}${key}/`);
        }
        printTree(node[key], childPrefix);
      });
    }

    printTree(tree);
    return;
  }

  // Default list view
  console.log(chalk.cyan('\n📁 Project Registry'));
  console.log(chalk.gray('═'.repeat(60)));
  console.log(chalk.gray(`Last scan: ${registry.lastScan}`));
  console.log(chalk.gray(`Projects: ${registry.projectCount}`));
  console.log('');

  // Table header
  console.log(
    chalk.bold('Name'.padEnd(25)) +
    chalk.bold('Version'.padEnd(12)) +
    chalk.bold('Stack'.padEnd(10)) +
    chalk.bold('Path')
  );
  console.log(chalk.gray('─'.repeat(70)));

  for (const p of registry.projects) {
    console.log(
      p.name.padEnd(25).substring(0, 24) +
      p.version.padEnd(12).substring(0, 11) +
      p.techstack.padEnd(10) +
      chalk.gray(p.path)
    );
  }
}

/**
 * Show project details
 * @param {string} projectName - Project name or ID
 * @param {string} workspacePath - Workspace path
 * @param {Object} options - Command options
 */
async function showProject(projectName, workspacePath, options) {
  const { json } = options;

  const registry = loadRegistry(workspacePath);
  if (!registry) {
    console.log(chalk.yellow('No project registry found. Run "ani-code projects scan" first.'));
    return;
  }

  const project = findProject(registry, projectName);
  if (!project) {
    console.log(chalk.red(`Project "${projectName}" not found.`));
    console.log(chalk.gray('Available projects:'));
    for (const p of registry.projects) {
      console.log(chalk.gray(`  - ${p.name} (${p.id})`));
    }
    return;
  }

  // Load detailed project file
  const projectPath = join(workspacePath, PROJECTS_DIR, `${project.id}.json`);
  let projectData = project;
  if (existsSync(projectPath)) {
    try {
      projectData = JSON.parse(readFileSync(projectPath, 'utf8'));
    } catch (e) {
      // Use registry data
    }
  }

  if (json) {
    console.log(JSON.stringify(projectData, null, 2));
    return;
  }

  console.log(chalk.cyan(`\n📦 ${projectData.name}`));
  console.log(chalk.gray('═'.repeat(60)));
  console.log(`ID:          ${projectData.id}`);
  console.log(`Version:     ${chalk.green(projectData.version)}`);
  console.log(`Techstack:   ${chalk.cyan(projectData.techstack)}`);
  console.log(`Path:        ${projectData.path}`);
  console.log(`Manifest:    ${projectData.manifestPath}`);
  console.log(`Last Modified: ${projectData.lastModified}`);

  if (projectData.description) {
    console.log(`\nDescription: ${projectData.description}`);
  }

  if (projectData.metadata) {
    console.log(chalk.cyan('\nMetadata:'));
    for (const [key, value] of Object.entries(projectData.metadata)) {
      if (Array.isArray(value)) {
        console.log(`  ${key}: ${value.join(', ')}`);
      } else if (typeof value === 'object') {
        console.log(`  ${key}: ${JSON.stringify(value)}`);
      } else {
        console.log(`  ${key}: ${value}`);
      }
    }
  }

  if (projectData.versionHistory && projectData.versionHistory.length > 0) {
    console.log(chalk.cyan('\nVersion History:'));
    for (const h of projectData.versionHistory.slice(-5)) {
      console.log(`  ${h.version} - ${h.timestamp} (${h.source})`);
    }
  }
}

/**
 * Set project version
 * @param {string} projectName - Project name or ID
 * @param {string} newVersion - New version
 * @param {string} workspacePath - Workspace path
 * @param {Object} options - Command options
 */
async function setVersion(projectName, newVersion, workspacePath, options) {
  const { dryRun } = options;

  const registry = loadRegistry(workspacePath);
  if (!registry) {
    console.log(chalk.yellow('No project registry found. Run "ani-code projects scan" first.'));
    return;
  }

  const project = findProject(registry, projectName);
  if (!project) {
    console.log(chalk.red(`Project "${projectName}" not found.`));
    return;
  }

  const manifestPath = join(workspacePath, project.manifestPath);

  console.log(chalk.cyan(`\n📦 Setting version for ${project.name}`));
  console.log(chalk.gray(`  Current: ${project.version}`));
  console.log(chalk.gray(`  New:     ${newVersion}`));
  console.log(chalk.gray(`  File:    ${project.manifestPath}`));

  if (dryRun) {
    console.log(chalk.yellow('\n[Dry Run] No changes made.'));
    return;
  }

  const success = updateManifestVersion(manifestPath, project.manifestType, newVersion);

  if (success) {
    // Update registry
    project.version = newVersion;
    project.lastModified = new Date().toISOString();
    saveRegistry(workspacePath, registry);
    saveProjectFile(workspacePath, project);

    console.log(chalk.green(`\n✅ Version updated to ${newVersion}`));
  } else {
    console.log(chalk.red('\n✗ Failed to update version.'));
  }
}

/**
 * Bump (burst) project version
 * @param {string} projectName - Project name or ID
 * @param {string} workspacePath - Workspace path
 * @param {Object} options - Command options
 */
async function burstVersion(projectName, workspacePath, options) {
  const { dryRun } = options;

  const registry = loadRegistry(workspacePath);
  if (!registry) {
    console.log(chalk.yellow('No project registry found. Run "ani-code projects scan" first.'));
    return;
  }

  const project = findProject(registry, projectName);
  if (!project) {
    console.log(chalk.red(`Project "${projectName}" not found.`));
    return;
  }

  const newVersion = incrementVersion(project.version, 'patch');
  await setVersion(projectName, newVersion, workspacePath, options);
}

/**
 * Burst all project versions
 * @param {string} workspacePath - Workspace path
 * @param {Object} options - Command options
 */
async function burstAllVersions(workspacePath, options) {
  const { dryRun } = options;

  const registry = loadRegistry(workspacePath);
  if (!registry) {
    console.log(chalk.yellow('No project registry found. Run "ani-code projects scan" first.'));
    return;
  }

  console.log(chalk.cyan(`\n📦 Bursting all project versions`));
  console.log(chalk.gray('═'.repeat(60)));

  if (dryRun) {
    console.log(chalk.yellow('[Dry Run] Would update the following:'));
  }

  let updated = 0;
  for (const project of registry.projects) {
    const newVersion = incrementVersion(project.version, 'patch');
    console.log(`  ${project.name}: ${project.version} → ${newVersion}`);

    if (!dryRun) {
      const manifestPath = join(workspacePath, project.manifestPath);
      const success = updateManifestVersion(manifestPath, project.manifestType, newVersion);

      if (success) {
        project.version = newVersion;
        project.lastModified = new Date().toISOString();
        saveProjectFile(workspacePath, project);
        updated++;
      }
    }
  }

  if (!dryRun) {
    saveRegistry(workspacePath, registry);
    console.log(chalk.green(`\n✅ Updated ${updated}/${registry.projects.length} projects`));
  }
}

/**
 * Refresh registry without full rescan
 * @param {string} workspacePath - Workspace path
 */
async function refreshRegistry(workspacePath) {
  const registry = loadRegistry(workspacePath);
  if (!registry) {
    console.log(chalk.yellow('No project registry found. Run "ani-code projects scan" first.'));
    return;
  }

  console.log(chalk.cyan('\n🔄 Refreshing project registry'));
  console.log(chalk.gray('═'.repeat(60)));

  let updated = 0;
  for (const project of registry.projects) {
    const manifestPath = join(workspacePath, project.manifestPath);

    if (!existsSync(manifestPath)) {
      console.log(chalk.yellow(`  ⚠ Missing: ${project.name} (${project.manifestPath})`));
      continue;
    }

    const manifestType = MANIFEST_TYPES[project.manifestType];
    if (manifestType && manifestType.parser) {
      const parsed = manifestType.parser(manifestPath);

      if (parsed.version !== project.version) {
        console.log(`  ${project.name}: ${project.version} → ${parsed.version}`);
        project.version = parsed.version;
        project.lastModified = new Date().toISOString();
        saveProjectFile(workspacePath, project);
        updated++;
      }
    }
  }

  registry.lastScan = new Date().toISOString();
  saveRegistry(workspacePath, registry);

  console.log(chalk.green(`\n✅ Refreshed ${registry.projectCount} projects (${updated} updated)`));
}

// ============================================================================
// Command Definition
// ============================================================================

/**
 * Create projects command
 */
export default function createProjectsCommand() {
  const projectsCommand = new Command('projects')
    .description('Project discovery and version management')
    .option('-w, --workspace <path>', 'Workspace path', process.cwd());

  // Default action (scan)
  projectsCommand
    .action(async (options) => {
      await runScan(options.workspace, { ...options, depth: 5, exclude: '', force: false });
    });

  // Scan subcommand
  projectsCommand
    .command('scan')
    .description('Scan workspace for project manifests')
    .option('-w, --workspace <path>', 'Workspace path', process.cwd())
    .option('-e, --exclude <patterns>', 'Additional exclusion patterns (comma-separated)')
    .option('-d, --depth <number>', 'Maximum scan depth', (val) => parseInt(val, 10), 5)
    .option('-f, --force', 'Force rescan even if cache exists', false)
    .action(async (options) => {
      await runScan(options.workspace, options);
    });

  // List subcommand
  projectsCommand
    .command('list')
    .description('List all discovered projects')
    .option('-w, --workspace <path>', 'Workspace path', process.cwd())
    .option('-j, --json', 'Output as JSON', false)
    .option('-t, --tree', 'Show project hierarchy as tree', false)
    .action(async (options) => {
      await listProjects(options.workspace, options);
    });

  // Show subcommand
  projectsCommand
    .command('show <name>')
    .description('Show project details')
    .option('-w, --workspace <path>', 'Workspace path', process.cwd())
    .option('-j, --json', 'Output as JSON', false)
    .action(async (name, options) => {
      await showProject(name, options.workspace, options);
    });

  // Refresh subcommand
  projectsCommand
    .command('refresh')
    .description('Refresh registry from manifest files')
    .option('-w, --workspace <path>', 'Workspace path', process.cwd())
    .action(async (options) => {
      await refreshRegistry(options.workspace);
    });

  // Version management - set-version
  projectsCommand
    .command('set-version <name> <version>')
    .description('Set project version')
    .option('-w, --workspace <path>', 'Workspace path', process.cwd())
    .option('-n, --dry-run', 'Preview changes without writing', false)
    .action(async (name, version, options) => {
      await setVersion(name, version, options.workspace, options);
    });

  // Version management - burst (increment patch)
  projectsCommand
    .command('burst <name>')
    .description('Increment project patch version')
    .option('-w, --workspace <path>', 'Workspace path', process.cwd())
    .option('-n, --dry-run', 'Preview changes without writing', false)
    .action(async (name, options) => {
      await burstVersion(name, options.workspace, options);
    });

  // Version management - burst-all
  projectsCommand
    .command('burst-all')
    .description('Increment all project patch versions')
    .option('-w, --workspace <path>', 'Workspace path', process.cwd())
    .option('-n, --dry-run', 'Preview changes without writing', false)
    .action(async (options) => {
      await burstAllVersions(options.workspace, options);
    });

  return projectsCommand;
}

// Export utilities for testing
export {
  MANIFEST_TYPES,
  DEFAULT_EXCLUSIONS,
  SCHEMA_VERSION,
  scanDirectory,
  incrementVersion,
  updateManifestVersion,
  findProject,
  loadRegistry,
  saveRegistry
};

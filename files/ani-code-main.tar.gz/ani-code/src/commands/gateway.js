import { Command } from 'commander';
import chalk from 'chalk';
import { gatewayClient } from '../gateway-client.js';
import { IPCClient } from '../ipc-client.js';

const gatewayCommand = new Command('gateway')
  .description('Manage gateway integration')
  .configureHelp({
    sortSubcommands: true,
    subcommandTerm: (cmd) => cmd.name() + (cmd.alias() ? ` (${cmd.alias()})` : '')
  })
  .addHelpText('after', `
${chalk.bold('Gateway Integration:')}
  Gateway mode allows ani-code to register with ani-code-gateway
  for multi-instance routing and centralized token management.

${chalk.bold('Configuration:')}
  Set these environment variables to enable gateway mode:
    ${chalk.cyan('GATEWAY_URL')}=http://your-gateway:6555
    ${chalk.cyan('ANI_CODE_URL')}=http://your-instance:6501
    ${chalk.cyan('GATEWAY_API_KEY')}=your-key (optional)

${chalk.bold('Examples:')}
  ${chalk.gray('# Check current gateway status')}
  $ ani-code gateway status

  ${chalk.gray('# Test gateway connectivity')}
  $ ani-code gateway test

  ${chalk.gray('# Show gateway configuration')}
  $ ani-code gateway config

  ${chalk.gray('# Run diagnostics when having issues')}
  $ ani-code gateway diagnose
`);

// Status command
gatewayCommand
  .command('status')
  .alias('st')
  .description('Show current gateway registration status')
  .option('-v, --verbose', 'Show detailed information')
  .option('-j, --json', 'Output as JSON')
  .action(async (options) => {
    try {
      // Connect to daemon to get actual gateway status
      const ipcClient = new IPCClient();
      let status;
      try {
        await ipcClient.connect();
        status = await ipcClient.getGatewayStatus();
      } catch (error) {
        // If daemon is not running, fall back to local check
        if (error.message.includes('Daemon IPC port file not found') ||
            error.message.includes('Failed to connect to daemon')) {
          console.error(chalk.yellow('\n⚠ Warning: Could not connect to daemon'));
          console.error(chalk.gray('  Gateway status requires the daemon to be running'));
          console.error(chalk.gray('  Start the daemon with: ani-code daemon --start\n'));
          process.exit(1);
        }
        throw error;
      } finally {
        ipcClient.disconnect();
      }

      if (options.json) {
        console.log(JSON.stringify(status, null, 2));
        return;
      }

      // Display inline text status
      console.log(chalk.bold('\n🌐 Gateway Status'));
      console.log(`Gateway Mode: ${status.enabled ? chalk.green('✓ Enabled') : chalk.yellow('✗ Disabled')}`);

      if (status.enabled) {
        console.log(`Gateway URL: ${status.gatewayUrl || chalk.gray('Not configured')}`);
        console.log(`Instance URL: ${chalk.cyan(status.instanceUrl)}`);

        if (status.projectId || status.workspaceId || status.podName) {
          console.log(`Project ID: ${status.projectId || chalk.gray('Not set')}`);
          console.log(`Workspace ID: ${status.workspaceId || chalk.gray('Not set')}`);
          console.log(`Pod Name: ${status.podName || chalk.gray('Not set')}`);
        }

        console.log(`\nRegistered: ${status.registered ? chalk.green('✓ Yes') : chalk.red('✗ No')}`);
        if (status.instanceId) {
          console.log(`Instance ID: ${status.instanceId}`);
        }
        console.log(`Heartbeat: ${status.heartbeatActive ? chalk.green('✓ Active') : chalk.red('✗ Inactive')}`);

        if (status.gatewayHealthy !== undefined) {
          console.log(`Gateway Health: ${status.gatewayHealthy ? chalk.green('✓ Healthy') : chalk.red('✗ Unhealthy')}`);
          if (status.gatewayError) {
            console.log(chalk.red(`  Error: ${status.gatewayError}`));
          }
        }

        // Registration details (verbose mode)
        if (options.verbose && status.registrationDetails) {
          const details = status.registrationDetails;
          console.log(chalk.bold('\n📋 Registration Details'));
          console.log(`ID: ${details.id}`);
          console.log(`URL: ${details.url}`);
          console.log(`Status: ${details.status === 'healthy' ? chalk.green(details.status) : chalk.yellow(details.status)}`);
          console.log(`Last Seen: ${details.lastSeen || chalk.gray('Unknown')}`);

          if (details.metadata) {
            console.log(`Version: ${details.metadata.version || chalk.gray('Unknown')}`);
            console.log(`Capabilities: ${Array.isArray(details.metadata.capabilities) ? details.metadata.capabilities.join(', ') : chalk.gray('Unknown')}`);
          }
        }

        // Warnings and errors
        if (status.registrationWarning) {
          console.log(chalk.yellow(`\n⚠ Warning: ${status.registrationWarning}`));
        }

        if (status.registrationError) {
          console.log(chalk.red(`\n✗ Registration Error: ${status.registrationError}`));
        }

        // Recommendations
        if (!status.registered && status.enabled) {
          console.log(chalk.yellow('\n💡 Gateway is configured but instance is not registered.'));
        }

        if (!status.heartbeatActive && status.registered) {
          console.log(chalk.yellow('\n⚠ Heartbeat is not active. Instance may be removed from gateway registry.'));
        }

        if (!status.gatewayHealthy) {
          console.log(chalk.red('\n✗ Gateway is not responding.'));
        }
      } else {
        console.log(chalk.yellow('\nGateway mode is disabled (standalone mode).'));
        console.log(chalk.gray('To enable, set GATEWAY_URL and ANI_CODE_URL environment variables.'));
      }

      console.log(); // Empty line at end
    } catch (error) {
      console.error(chalk.red(`\n✗ Failed to get gateway status: ${error.message}`));
      process.exit(1);
    }
  });

// Test command
gatewayCommand
  .command('test')
  .description('Test gateway connectivity and registration')
  .action(async () => {
    try {
      // Get daemon status first
      const ipcClient = new IPCClient();
      let status;
      try {
        await ipcClient.connect();
        status = await ipcClient.getGatewayStatus();
      } catch (error) {
        if (error.message.includes('Daemon IPC port file not found') ||
            error.message.includes('Failed to connect to daemon')) {
          console.error(chalk.red('\n✗ Daemon not running'));
          console.error(chalk.gray('  Start daemon: ani-code daemon --start\n'));
          process.exit(1);
        }
        throw error;
      } finally {
        ipcClient.disconnect();
      }

      if (!status.enabled) {
        console.log(chalk.yellow('\n✗ Gateway mode disabled\n'));
        return;
      }

      console.log(chalk.bold('\n🔍 Gateway Connectivity Test\n'));
      console.log(chalk.gray(`Gateway: ${status.gatewayUrl}\n`));

      const axios = (await import('axios')).default;
      const os = (await import('os')).default;
      const userAgent = `${os.hostname()} ani-code-daemon`;
      const apiKey = status.apiKey || 'dev-key-1';

      // Test 1: Health check
      process.stdout.write('Health check... ');
      try {
        await axios.get(`${status.gatewayUrl}/api/health`, {
          timeout: 5000,
          headers: { 'User-Agent': userAgent }
        });
        console.log(chalk.green('✓'));
      } catch (error) {
        console.log(chalk.red('✗'));
        console.log(chalk.red(`\n✗ Gateway unreachable: ${error.message}\n`));
        return;
      }

      // Test 2: Registration check
      process.stdout.write('Registration... ');
      try {
        const checkResponse = await axios.get(
          `${status.gatewayUrl}/api/registry/instance/check`,
          {
            params: {
              instanceId: status.projectId || 'unknown',
              url: status.instanceUrl
            },
            headers: {
              'x-api-key': apiKey,
              'User-Agent': userAgent
            },
            timeout: 5000
          }
        );

        const { registered, instance } = checkResponse.data;

        if (registered && instance) {
          console.log(chalk.green('✓'));
          console.log(chalk.gray(`\nInstance: ${instance.id}`));
          console.log(chalk.gray(`Status: ${instance.status || 'active'}`));
          console.log(chalk.gray(`Last seen: ${instance.lastSeen || 'now'}`));
        } else {
          console.log(chalk.yellow('⚠'));
          console.log(chalk.yellow('\nNot registered - daemon will register soon'));
        }
      } catch (error) {
        console.log(chalk.red('✗'));
        console.log(chalk.red(`Error: ${error.message}`));
      }

      console.log(chalk.green('\n✓ Test complete\n'));
    } catch (error) {
      console.error(chalk.red(`\n✗ Test failed: ${error.message}\n`));
      process.exit(1);
    }
  });

// Config command
gatewayCommand
  .command('config')
  .description('Show gateway configuration from daemon')
  .action(async () => {
    try {
      // Get configuration from daemon
      const ipcClient = new IPCClient();
      let status;
      try {
        await ipcClient.connect();
        status = await ipcClient.getGatewayStatus();
      } catch (error) {
        if (error.message.includes('Daemon IPC port file not found') ||
            error.message.includes('Failed to connect to daemon')) {
          console.error(chalk.yellow('\n⚠ Warning: Could not connect to daemon'));
          console.error(chalk.gray('  Gateway configuration requires the daemon to be running\n'));
          process.exit(1);
        }
        throw error;
      } finally {
        ipcClient.disconnect();
      }

      console.log(chalk.bold('\n⚙️  Gateway Configuration\n'));
      console.log(`Gateway Mode: ${status.enabled ? chalk.green('Enabled') : chalk.yellow('Disabled')}`);
      console.log(`GATEWAY_URL: ${status.gatewayUrl || chalk.gray('Not set')}`);
      console.log(`ANI_CODE_URL: ${status.instanceUrl || chalk.gray('Not set')}`);
      console.log(`GATEWAY_API_KEY: ${status.apiKey ? chalk.gray('***' + status.apiKey.slice(-4)) : chalk.gray('Not set')}`);
      console.log(`PROJECT_ID: ${status.projectId || chalk.gray('Not set')}`);
      console.log(`WORKSPACE_ID: ${status.workspaceId || chalk.gray('Not set')}`);
      console.log(`POD_NAME: ${status.podName || chalk.gray('Not set')}`);
      console.log(`Instance ID: ${status.instanceId || chalk.gray('Not assigned')}`);

      console.log();
      if (status.enabled) {
        console.log(chalk.green('✓ Gateway mode is enabled'));
        console.log(chalk.gray('Run "ani-code gateway status" for detailed registration status'));
      } else {
        console.log(chalk.yellow('⚠ Gateway mode is disabled'));
        console.log(chalk.gray('Set GATEWAY_URL in daemon environment to enable'));
      }
      console.log();
    } catch (error) {
      console.error(chalk.red(`\n✗ Failed to get gateway configuration: ${error.message}\n`));
      process.exit(1);
    }
  });

// Diagnose command
gatewayCommand
  .command('diagnose')
  .alias('diag')
  .description('Run comprehensive gateway diagnostics')
  .option('-j, --json', 'Output as JSON')
  .option('-v, --verbose', 'Show detailed diagnostic information')
  .action(async (options) => {
    const results = {
      timestamp: new Date().toISOString(),
      checks: [],
      recommendations: [],
      summary: { passed: 0, failed: 0, warnings: 0 }
    };

    const addCheck = (name, status, message, details = null) => {
      const check = { name, status, message };
      if (details) check.details = details;
      results.checks.push(check);
      if (status === 'pass') results.summary.passed++;
      else if (status === 'fail') results.summary.failed++;
      else if (status === 'warn') results.summary.warnings++;
    };

    const addRecommendation = (priority, message) => {
      results.recommendations.push({ priority, message });
    };

    if (!options.json) {
      console.log(chalk.bold('\n🔬 Gateway Diagnostics\n'));
    }

    // Check 1: Daemon connectivity
    if (!options.json) process.stdout.write('Checking daemon connectivity... ');
    const ipcClient = new IPCClient();
    let status;
    try {
      await ipcClient.connect();
      status = await ipcClient.getGatewayStatus();
      if (!options.json) console.log(chalk.green('✓'));
      addCheck('daemon_connectivity', 'pass', 'Daemon is running and responsive');
    } catch (error) {
      if (!options.json) console.log(chalk.red('✗'));
      addCheck('daemon_connectivity', 'fail', 'Cannot connect to daemon', error.message);
      addRecommendation('critical', 'Start the daemon with: ani-code daemon --start');

      if (options.json) {
        console.log(JSON.stringify(results, null, 2));
      } else {
        console.log(chalk.red(`\n✗ Daemon not running: ${error.message}`));
        console.log(chalk.yellow('\n💡 Recommendation: Start daemon with "ani-code daemon --start"\n'));
      }
      process.exit(1);
    } finally {
      ipcClient.disconnect();
    }

    // Check 2: Gateway mode enabled
    if (!options.json) process.stdout.write('Checking gateway mode... ');
    if (status.enabled) {
      if (!options.json) console.log(chalk.green('✓ Enabled'));
      addCheck('gateway_mode', 'pass', 'Gateway mode is enabled');
    } else {
      if (!options.json) console.log(chalk.yellow('⚠ Disabled'));
      addCheck('gateway_mode', 'warn', 'Gateway mode is disabled (standalone mode)');
      addRecommendation('info', 'Set GATEWAY_URL and ANI_CODE_URL to enable gateway mode');

      if (options.json) {
        console.log(JSON.stringify(results, null, 2));
      } else {
        console.log(chalk.yellow('\n⚠ Gateway mode is disabled.'));
        console.log(chalk.gray('Set GATEWAY_URL and ANI_CODE_URL environment variables to enable.\n'));
      }
      return;
    }

    // Check 3: Required configuration
    if (!options.json) process.stdout.write('Checking configuration... ');
    const configIssues = [];
    if (!status.gatewayUrl) configIssues.push('GATEWAY_URL not set');
    if (!status.instanceUrl) configIssues.push('ANI_CODE_URL not set');
    if (!status.projectId) configIssues.push('PROJECT_ID not set');

    if (configIssues.length === 0) {
      if (!options.json) console.log(chalk.green('✓'));
      addCheck('configuration', 'pass', 'All required configuration present');
    } else {
      if (!options.json) console.log(chalk.red('✗'));
      addCheck('configuration', 'fail', 'Missing configuration', configIssues);
      configIssues.forEach(issue => addRecommendation('critical', `Set ${issue.split(' ')[0]} environment variable`));
    }

    // Check 4: Gateway URL reachability
    if (!options.json) process.stdout.write('Checking gateway reachability... ');
    const axios = (await import('axios')).default;
    const os = (await import('os')).default;
    const userAgent = `${os.hostname()} ani-code-daemon`;

    let gatewayReachable = false;
    let gatewayHealthy = false;
    try {
      const healthResponse = await axios.get(`${status.gatewayUrl}/api/health`, {
        timeout: 10000,
        headers: { 'User-Agent': userAgent }
      });
      gatewayReachable = true;
      gatewayHealthy = healthResponse.status === 200;
      if (!options.json) console.log(chalk.green('✓'));
      addCheck('gateway_reachability', 'pass', 'Gateway is reachable', {
        url: status.gatewayUrl,
        responseTime: `${healthResponse.headers['x-response-time'] || 'N/A'}`
      });
    } catch (error) {
      if (!options.json) console.log(chalk.red('✗'));
      const errorDetails = {
        url: status.gatewayUrl,
        error: error.code || error.message
      };
      if (error.code === 'ECONNREFUSED') {
        addCheck('gateway_reachability', 'fail', 'Gateway connection refused', errorDetails);
        addRecommendation('critical', 'Verify gateway is running and GATEWAY_URL is correct');
      } else if (error.code === 'ENOTFOUND') {
        addCheck('gateway_reachability', 'fail', 'Gateway hostname not found', errorDetails);
        addRecommendation('critical', 'Check DNS resolution for gateway hostname');
      } else if (error.code === 'ETIMEDOUT') {
        addCheck('gateway_reachability', 'fail', 'Gateway connection timed out', errorDetails);
        addRecommendation('critical', 'Check network connectivity and firewall rules');
      } else {
        addCheck('gateway_reachability', 'fail', `Gateway unreachable: ${error.message}`, errorDetails);
        addRecommendation('critical', 'Investigate network connectivity to gateway');
      }
    }

    // Check 5: Instance URL accessibility (callback endpoint)
    if (!options.json) process.stdout.write('Checking callback endpoint... ');
    try {
      // Try to reach the instance URL from daemon's perspective
      const callbackUrl = `${status.instanceUrl}`;
      const instanceResponse = await axios.get(`${callbackUrl}`, {
        timeout: 5000,
        headers: { 'User-Agent': userAgent },
        validateStatus: () => true // Accept any status
      });
      if (!options.json) console.log(chalk.green('✓'));
      addCheck('callback_endpoint', 'pass', 'Callback endpoint is accessible', {
        url: callbackUrl,
        status: instanceResponse.status
      });
    } catch (error) {
      if (!options.json) console.log(chalk.yellow('⚠'));
      addCheck('callback_endpoint', 'warn', 'Cannot verify callback endpoint', {
        url: status.instanceUrl,
        error: error.message
      });
      addRecommendation('info', 'Verify ANI_CODE_URL is accessible from gateway network');
    }

    // Check 6: Registration status
    if (!options.json) process.stdout.write('Checking registration status... ');
    if (status.registered) {
      if (!options.json) console.log(chalk.green('✓ Registered'));
      addCheck('registration', 'pass', 'Instance is registered with gateway', {
        instanceId: status.instanceId
      });
    } else {
      if (!options.json) console.log(chalk.red('✗ Not registered'));
      addCheck('registration', 'fail', 'Instance is not registered with gateway');

      if (gatewayReachable) {
        addRecommendation('high', 'Registration may be in progress - wait 30 seconds and re-run diagnose');
        addRecommendation('high', 'Check daemon logs: journalctl -u ani-code --since "5 minutes ago" | grep -i register');
      }
    }

    // Check 7: Heartbeat status
    if (!options.json) process.stdout.write('Checking heartbeat... ');
    if (status.heartbeatActive) {
      if (!options.json) console.log(chalk.green('✓ Active'));
      addCheck('heartbeat', 'pass', 'Heartbeat is active');
    } else {
      if (!options.json) console.log(chalk.yellow('⚠ Inactive'));
      addCheck('heartbeat', 'warn', 'Heartbeat is not active');
      if (status.registered) {
        addRecommendation('high', 'Heartbeat stopped - instance may be removed from gateway soon');
      }
    }

    // Check 8: Signing key (security)
    if (!options.json) process.stdout.write('Checking callback signing... ');
    if (status.signingEnabled || process.env.PROJECT_GATEWAY_KEY) {
      if (!options.json) console.log(chalk.green('✓ Enabled'));
      addCheck('callback_signing', 'pass', 'Callback signing is enabled (secure mode)');
    } else {
      if (!options.json) console.log(chalk.yellow('⚠ Disabled'));
      addCheck('callback_signing', 'warn', 'Callback signing is disabled (legacy mode)');
      addRecommendation('medium', 'Set PROJECT_GATEWAY_KEY for secure callback signing');
    }

    // Check 9: Gateway registry verification (if reachable)
    if (gatewayReachable && status.projectId) {
      if (!options.json) process.stdout.write('Verifying gateway registry... ');
      try {
        const apiKey = status.apiKey || 'dev-key-1';
        const checkResponse = await axios.get(
          `${status.gatewayUrl}/api/registry/instance/check`,
          {
            params: {
              instanceId: status.projectId,
              url: status.instanceUrl
            },
            headers: {
              'x-api-key': apiKey,
              'User-Agent': userAgent
            },
            timeout: 5000
          }
        );

        const { registered, instance } = checkResponse.data;
        if (registered && instance) {
          if (!options.json) console.log(chalk.green('✓ Verified'));
          addCheck('registry_verification', 'pass', 'Instance found in gateway registry', {
            instanceId: instance.id,
            status: instance.status,
            lastSeen: instance.lastSeen
          });
        } else {
          if (!options.json) console.log(chalk.yellow('⚠ Not found'));
          addCheck('registry_verification', 'warn', 'Instance not found in gateway registry');
          addRecommendation('high', 'Wait for automatic re-registration or restart daemon');
        }
      } catch (error) {
        if (!options.json) console.log(chalk.yellow('⚠'));
        addCheck('registry_verification', 'warn', 'Could not verify registry', error.message);
      }
    }

    // Sort recommendations by priority
    const priorityOrder = { critical: 0, high: 1, medium: 2, info: 3 };
    results.recommendations.sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);

    // Output results
    if (options.json) {
      console.log(JSON.stringify(results, null, 2));
    } else {
      // Summary
      console.log(chalk.bold('\n📊 Summary'));
      console.log(`Passed: ${chalk.green(results.summary.passed)} | Failed: ${chalk.red(results.summary.failed)} | Warnings: ${chalk.yellow(results.summary.warnings)}`);

      // Verbose details
      if (options.verbose) {
        console.log(chalk.bold('\n📋 Detailed Results'));
        for (const check of results.checks) {
          const icon = check.status === 'pass' ? chalk.green('✓') :
                       check.status === 'fail' ? chalk.red('✗') : chalk.yellow('⚠');
          console.log(`${icon} ${check.name}: ${check.message}`);
          if (check.details) {
            const details = typeof check.details === 'string' ? check.details : JSON.stringify(check.details, null, 2);
            console.log(chalk.gray(`   ${details.split('\n').join('\n   ')}`));
          }
        }
      }

      // Recommendations
      if (results.recommendations.length > 0) {
        console.log(chalk.bold('\n💡 Recommendations'));
        for (const rec of results.recommendations) {
          const priorityColor = rec.priority === 'critical' ? chalk.red :
                               rec.priority === 'high' ? chalk.yellow :
                               rec.priority === 'medium' ? chalk.cyan : chalk.gray;
          console.log(`${priorityColor(`[${rec.priority.toUpperCase()}]`)} ${rec.message}`);
        }
      }

      // Overall status
      if (results.summary.failed === 0 && results.summary.warnings === 0) {
        console.log(chalk.green('\n✓ All checks passed - gateway integration is healthy\n'));
      } else if (results.summary.failed === 0) {
        console.log(chalk.yellow('\n⚠ Some warnings - review recommendations above\n'));
      } else {
        console.log(chalk.red('\n✗ Issues detected - follow recommendations to resolve\n'));
        process.exit(1);
      }
    }
  });

export default gatewayCommand;

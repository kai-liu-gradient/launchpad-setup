import { Command } from 'commander';
import chalk from 'chalk';
import { IPCClient } from '../ipc-client.js';

// Helper function to communicate with daemon for provider operations
async function withDaemonProvider(operation, data = {}) {
  const client = new IPCClient();
  try {
    await client.connect();
    const response = await client.sendMessage(operation, data);

    // For provider operations, the daemon returns raw data directly
    // not wrapped in { success, data } format
    return response;
  } finally {
    client.disconnect();
  }
}

const providerCommand = new Command('provider')
  .description('Manage CLI providers (Claude, Cursor, Codeium, etc.)')
  .addHelpText('after', `
Examples:
  $ ani-code provider list                    # List available providers
  $ ani-code provider current                 # Show current provider
  $ ani-code provider switch cursor          # Switch to Cursor provider
  $ ani-code provider info claude            # Show Claude provider details
  $ ani-code provider test                   # Test current provider
  `);

// List all available providers
providerCommand
  .command('list')
  .description('List all configured providers')
  .action(async () => {
    try {
      const providers = await withDaemonProvider('provider_list');

      console.log(chalk.bold('📦 CLI Providers\n'));

      providers.forEach(provider => {
        const marker = provider.current ? chalk.green('✓') : ' ';
        const name = provider.current
          ? chalk.green.bold(provider.name)
          : chalk.white(provider.name);

        const availability = provider.available ? chalk.green('(available)') : chalk.gray('(not available)');

        console.log(`${marker} ${name} ${availability}`);
      });

      console.log();
    } catch (error) {
      if (error.message.includes('ECONNREFUSED') || error.message.includes('connect')) {
        console.error(chalk.red('Error: Daemon is not running. Start the daemon first:'));
        console.error(chalk.gray('  ani-code daemon'));
      } else {
        console.error(chalk.red('Error listing providers:'), error.message);
      }
      process.exit(1);
    }
  });

// Show current provider
providerCommand
  .command('current')
  .description('Show the current active provider')
  .action(async () => {
    try {
      const info = await withDaemonProvider('provider_current');

      if (!info) {
        console.log(chalk.yellow('No provider currently configured'));
        return;
      }

      console.log(chalk.bold('\n🎯 Current CLI Provider\n'));
      console.log(`Name: ${chalk.green.bold(info.name)}`);
      console.log(`ID: ${info.id}`);
      console.log(`Binary: ${chalk.cyan(info.binary)}`);

      if (info.args && info.args.length > 0) {
        console.log(`Custom Args: ${chalk.gray(info.args.join(' '))}`);
      }

      // Show capabilities
      const caps = info.capabilities;
      console.log('\n' + chalk.bold('Capabilities:'));
      console.log(`  ✓ Create Tasks: ${caps.supportsCreate ? chalk.green('Yes') : chalk.red('No')}`);
      console.log(`  ✓ Continue Tasks: ${caps.supportsContinue ? chalk.green('Yes') : chalk.red('No')}`);
      console.log(`  ✓ Greenlight Mode: ${caps.supportsGreenlight ? chalk.green('Yes') : chalk.red('No')}`);
      console.log(`  ✓ Model Selection: ${caps.supportsModels ? chalk.green('Yes') : chalk.red('No')}`);
      console.log(`  ✓ Print Mode: ${caps.supportsPrintMode ? chalk.green('Yes') : chalk.red('No')}`);
      console.log(`  ✓ Interactive: ${caps.supportsInteractive ? chalk.green('Yes') : chalk.red('No')}`);

      console.log();
    } catch (error) {
      if (error.message.includes('ECONNREFUSED') || error.message.includes('connect')) {
        console.error(chalk.red('Error: Daemon is not running. Start the daemon first:'));
        console.error(chalk.gray('  ani-code daemon'));
      } else {
        console.error(chalk.red('Error getting current provider:'), error.message);
      }
      process.exit(1);
    }
  });

// Switch to a different provider
providerCommand
  .command('switch <providerId>')
  .description('Switch to a different provider')
  .action(async (providerId) => {
    try {
      const result = await withDaemonProvider('provider_switch', { providerId });

      console.log(chalk.green(`✅ Switched to provider: ${result.name} (${result.id})`));
    } catch (error) {
      if (error.message.includes('ECONNREFUSED') || error.message.includes('connect')) {
        console.error(chalk.red('Error: Daemon is not running. Start the daemon first:'));
        console.error(chalk.gray('  ani-code daemon'));
      } else {
        console.error(chalk.red('Error switching provider:'), error.message);
      }
      process.exit(1);
    }
  });

// Show provider info
providerCommand
  .command('info <providerId>')
  .description('Show detailed information about a provider')
  .action(async (providerId) => {
    try {
      const manager = await getProviderManager();
      const handler = manager.getHandler(providerId);

      if (!handler) {
        console.error(chalk.red(`Provider '${providerId}' not found`));
        process.exit(1);
      }

      const info = handler.getInfo();

      console.log(chalk.bold(`\n📦 Provider: ${info.name}\n`));
      console.log(`ID: ${info.id}`);
      console.log(`Binary: ${chalk.cyan(info.binary)}`);
      console.log(`Handler Type: ${handler.constructor.name}`);

      if (info.args && info.args.length > 0) {
        console.log(`Custom Args: ${chalk.gray(info.args.join(' '))}`);
      }

      if (info.env && Object.keys(info.env).length > 0) {
        console.log(`Environment Variables:`);
        Object.entries(info.env).forEach(([key, value]) => {
          console.log(`  ${key}=${value}`);
        });
      }

      // Show capabilities
      const caps = info.capabilities;
      console.log('\n' + chalk.bold('Capabilities:'));
      console.log(`  Create Tasks: ${caps.supportsCreate ? chalk.green('✓') : chalk.red('✗')}`);
      console.log(`  Continue Tasks: ${caps.supportsContinue ? chalk.green('✓') : chalk.red('✗')}`);
      console.log(`  Greenlight Mode: ${caps.supportsGreenlight ? chalk.green('✓') : chalk.red('✗')}`);
      console.log(`  Model Selection: ${caps.supportsModels ? chalk.green('✓') : chalk.red('✗')}`);
      console.log(`  Print Mode: ${caps.supportsPrintMode ? chalk.green('✓') : chalk.red('✗')}`);
      console.log(`  Interactive: ${caps.supportsInteractive ? chalk.green('✓') : chalk.red('✗')}`);

      console.log();
    } catch (error) {
      console.error(chalk.red('Error getting provider info:'), error.message);
      process.exit(1);
    }
  });

// Test provider
providerCommand
  .command('test')
  .description('Test the current provider configuration')
  .action(async () => {
    try {
      const manager = await getProviderManager();
      const handler = manager.getCurrentHandler();

      if (!handler) {
        console.error(chalk.red('No provider currently configured'));
        process.exit(1);
      }

      console.log(chalk.bold(`\n🧪 Testing Provider: ${handler.name}\n`));

      // Test validation
      try {
        handler.validate();
        console.log(chalk.green('✓ Provider validation passed'));
      } catch (error) {
        console.log(chalk.red('✗ Provider validation failed:'), error.message);
        process.exit(1);
      }

      // Test a simple command
      console.log(chalk.gray('\nTesting simple echo command...'));

      try {
        const child = await handler.createTask({
          command: 'echo "Hello from provider test"',
          workingDir: process.cwd(),
          interactive: false
        });

        // Wait for process to complete
        await new Promise((resolve, reject) => {
          let output = '';

          child.stdout.on('data', (data) => {
            output += data.toString();
          });

          child.stderr.on('data', (data) => {
            output += data.toString();
          });

          child.on('close', (code) => {
            if (code === 0) {
              console.log(chalk.green('✓ Test command executed successfully'));
              if (output) {
                console.log(chalk.gray('Output preview:'));
                console.log(output.substring(0, 200));
              }
              resolve();
            } else {
              reject(new Error(`Process exited with code ${code}`));
            }
          });

          child.on('error', (err) => {
            reject(err);
          });

          // Timeout after 10 seconds
          setTimeout(() => {
            child.kill();
            reject(new Error('Test timed out'));
          }, 10000);
        });

        console.log(chalk.green.bold('\n✅ Provider test completed successfully!\n'));
      } catch (error) {
        console.log(chalk.red('✗ Test command failed:'), error.message);
        process.exit(1);
      }
    } catch (error) {
      console.error(chalk.red('Error testing provider:'), error.message);
      process.exit(1);
    }
  });

export default providerCommand;
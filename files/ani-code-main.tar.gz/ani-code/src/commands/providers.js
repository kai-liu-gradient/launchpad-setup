import { Command } from 'commander';
import chalk from 'chalk';
import { IPCClient } from '../ipc-client.js';
import { WorkspaceManager } from '../workspace-manager.js';

// Helper function to communicate with daemon for provider operations
async function withDaemonProvider(operation, data = {}) {
  const client = new IPCClient();
  try {
    await client.connect();
    const response = await client.sendMessage(operation, data);
    return response;
  } finally {
    client.disconnect();
  }
}

// Get current workspace if exists
async function getCurrentWorkspace() {
  try {
    const manager = new WorkspaceManager();
    await manager.initialize();
    const currentPath = process.cwd();
    const workspaces = await manager.listWorkspaces();
    const workspace = workspaces.find(w => w.path === currentPath);
    return { manager, workspace };
  } catch (err) {
    return { manager: null, workspace: null };
  }
}

const providersCommand = new Command('providers')
  .description('List and switch CLI providers')
  .argument('[provider]', 'Provider ID to switch to')
  .option('-s, --save', 'Save as default provider for current workspace')
  .option('-g, --global', 'Show global provider (ignore workspace setting)')
  .option('-a, --all', 'Show all providers including unavailable ones')
  .addHelpText('after', `
Examples:
  $ ani-code providers                    # List all providers, show current
  $ ani-code providers claude             # Switch to Claude provider
  $ ani-code providers copilot --save     # Switch to Copilot and save to workspace
  $ ani-code providers --all              # Show all providers including unavailable
  `)
  .action(async (providerId, options) => {
    try {
      if (providerId) {
        // Switch to specified provider
        await switchProvider(providerId, options);
      } else {
        // List all providers
        await listProviders(options);
      }
    } catch (error) {
      if (error.message.includes('ECONNREFUSED') || error.message.includes('connect')) {
        console.error(chalk.red('Error: Daemon is not running. Start the daemon first:'));
        console.error(chalk.gray('  ani-code daemon'));
      } else {
        console.error(chalk.red('Error:'), error.message);
      }
      process.exit(1);
    }
  });

async function listProviders(options) {
  // Get providers from daemon
  let providers;
  try {
    providers = await withDaemonProvider('provider_list');
  } catch (err) {
    // Fallback: try to get provider info directly
    const { getProviderManager } = await import('../providers/providerManager.js');
    const manager = await getProviderManager();
    providers = manager.listProviders();
  }

  // Get workspace provider setting
  const { manager, workspace } = await getCurrentWorkspace();
  let workspaceProvider = null;
  if (workspace && manager) {
    workspaceProvider = await manager.getWorkspaceMeta(workspace.id, 'cliProvider');
  }

  // Header
  console.log(chalk.bold('\nCLI Providers\n'));

  // Show workspace info if applicable
  if (workspace && !options.global) {
    if (workspaceProvider) {
      console.log(chalk.gray(`Workspace: ${workspace.name}`));
      console.log(chalk.gray(`Default provider: ${workspaceProvider}\n`));
    } else {
      console.log(chalk.gray(`Workspace: ${workspace.name} (no default set)\n`));
    }
  }

  // Get all providers if --all flag is set
  let allProviders = providers;
  if (options.all) {
    try {
      const { getProviderManager } = await import('../providers/providerManager.js');
      const providerManager = await getProviderManager();
      // Get all handlers including unavailable ones
      allProviders = [];
      providerManager.handlers.forEach((handler, id) => {
        const available = handler.isAvailable();
        allProviders.push({
          id,
          name: handler.name,
          current: handler === providerManager.currentHandler,
          available,
          info: handler.getInfo()
        });
      });
    } catch (err) {
      // Keep using filtered list
    }
  }

  if (!allProviders || allProviders.length === 0) {
    console.log(chalk.yellow('No providers available'));
    return;
  }

  // Display providers
  allProviders.forEach(provider => {
    const isCurrent = provider.current;
    const isWorkspaceDefault = workspaceProvider === provider.id;

    // Build status indicators
    let markers = '';
    if (isCurrent) {
      markers += chalk.green(' (active)');
    }
    if (isWorkspaceDefault && !isCurrent) {
      markers += chalk.blue(' (workspace default)');
    }

    // Availability indicator
    const availability = provider.available
      ? ''
      : chalk.red(' [not installed]');

    // Provider name with formatting
    let name;
    if (isCurrent) {
      name = chalk.green.bold(`● ${provider.id}`);
    } else if (provider.available) {
      name = chalk.white(`  ${provider.id}`);
    } else {
      name = chalk.gray(`  ${provider.id}`);
    }

    // Show provider line
    const displayName = provider.name !== provider.id ? chalk.gray(` (${provider.name})`) : '';
    console.log(`${name}${displayName}${markers}${availability}`);
  });

  console.log();

  // Show usage hint
  console.log(chalk.gray('Usage: ani-code providers <id> to switch'));
  console.log(chalk.gray('       ani-code providers <id> --save to set as workspace default'));
}

async function switchProvider(providerId, options) {
  // Validate provider exists
  let providers;
  try {
    providers = await withDaemonProvider('provider_list');
  } catch (err) {
    const { getProviderManager } = await import('../providers/providerManager.js');
    const manager = await getProviderManager();
    providers = manager.listProviders();
  }

  // Check if provider exists (include unavailable if we need to)
  const { getProviderManager } = await import('../providers/providerManager.js');
  const providerManager = await getProviderManager();
  const handler = providerManager.getHandler(providerId);

  if (!handler) {
    console.error(chalk.red(`Provider '${providerId}' not found`));
    console.log(chalk.gray('\nAvailable providers:'));
    providers.forEach(p => {
      console.log(chalk.gray(`  - ${p.id}`));
    });
    process.exit(1);
  }

  // Check availability
  if (!handler.isAvailable()) {
    console.error(chalk.yellow(`Warning: Provider '${providerId}' binary not found in PATH`));
    console.log(chalk.gray(`Expected binary: ${handler.binary}`));
    if (!options.save) {
      console.log(chalk.gray('\nContinuing anyway...'));
    }
  }

  // Switch provider in daemon
  try {
    await withDaemonProvider('provider_switch', { providerId });
  } catch (err) {
    // If daemon not available, switch locally
    providerManager.switchProvider(providerId);
  }

  console.log(chalk.green(`✓ Switched to ${handler.name} (${providerId})`));

  // Save to workspace if requested
  if (options.save) {
    const { manager, workspace } = await getCurrentWorkspace();

    if (!workspace) {
      console.log(chalk.yellow('  No workspace found for current directory'));
      console.log(chalk.gray('  Use "ani-code workspace create" to create one first'));
    } else {
      await manager.setWorkspaceMeta(workspace.id, 'cliProvider', providerId);
      console.log(chalk.green(`✓ Saved as default for workspace: ${workspace.name}`));
    }
  }

  // Show provider info
  const info = handler.getInfo();
  console.log(chalk.gray(`  Binary: ${info.binary}`));

  const caps = info.capabilities;
  const capsList = [];
  if (caps.supportsCreate) capsList.push('create');
  if (caps.supportsContinue) capsList.push('continue');
  if (caps.supportsGreenlight) capsList.push('greenlight');
  if (caps.supportsModels) capsList.push('models');

  if (capsList.length > 0) {
    console.log(chalk.gray(`  Capabilities: ${capsList.join(', ')}`));
  }
}

export default providersCommand;

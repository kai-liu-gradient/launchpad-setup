/**
 * Goals Command Module (Refactored)
 * Simplified implementation using unified processor and utilities
 */

import { Command } from 'commander';
import chalk from 'chalk';
import { existsSync, readFileSync, writeFileSync, mkdirSync } from 'fs';
import { join, basename } from 'path';
import { createInterface } from 'readline';
import { DaemonClient } from '../daemon-client.js';
import { IPCClient } from '../ipc-client.js';
import { WorkspaceManager } from '../workspace-manager.js';
import { createGoalsProcessor } from '../utils/goals-processor.js';
import {
  findGoalFiles,
  extractGoalId,
  findGoalFileById,
  parseGoalFile,
  generateProgressBar,
  calculateSummary,
  quickScanGoalStatus,
  addIterationToHistory,
  getRecentIterations,
  getIterationHistoryPath,
  getLastIterationInfo,
  clearAnicodeBreak,
  formatIterationHistoryForPrompt,
  VALID_STATUSES,
  COMPLETED_STATUSES
} from '../utils/goals-utils.js';
import {
  buildAddGoalPrompt,
  buildGoalExecutionPrompt,
  buildProgressUpdatePrompt,
  buildGoalReviewPrompt
} from '../prompts/goals-prompts.js';
import { extractProviderFromPrompt, stripPatternsFromPrompt } from '../model-utils.js';
import { getProviderManager } from '../providers/providerManager.js';

/**
 * Detect __ANICODE_BREAK pattern in output and extract reason
 * @param {string} output - Task output to analyze
 * @returns {Object|null} { detected: true, reason: string } or null if not found
 */
function detectAnicodeBreak(output) {
  if (!output || typeof output !== 'string') {
    return null;
  }

  // Pattern: __ANICODE_BREAK(reason here)
  const pattern = /__ANICODE_BREAK\(([^)]*)\)/;
  const match = output.match(pattern);

  if (match) {
    const reason = match[1] ? match[1].trim() : 'Unknown reason';
    return {
      detected: true,
      reason: reason || 'Unknown reason'
    };
  }

  return null;
}

/**
 * Prompt user for yes/no confirmation
 */
function promptConfirm(question) {
  return new Promise((resolve) => {
    const rl = createInterface({
      input: process.stdin,
      output: process.stdout
    });

    rl.question(question + ' (y/N): ', (answer) => {
      rl.close();
      resolve(answer.toLowerCase() === 'y' || answer.toLowerCase() === 'yes');
    });
  });
}

/**
 * Get workspace manager instance
 */
async function getWorkspaceManager() {
  const workspaceManager = new WorkspaceManager();
  await workspaceManager.initialize();
  return workspaceManager;
}

/**
 * Get current workspace ID from working directory
 */
async function getCurrentWorkspace(workspacePath = null) {
  const workspaceManager = await getWorkspaceManager();
  const targetPath = workspacePath || process.cwd();
  const workspaces = await workspaceManager.listWorkspaces();
  const workspace = workspaces.find(w => w.path === targetPath);
  return workspace || null;
}

/**
 * Sync goals cache using the unified processor
 */
async function syncGoalsCache(goalsDir, fullResync = false, syncOptions = {}) {
  const processor = createGoalsProcessor(goalsDir, {
    fullResync,
    ...syncOptions,
    autoConfirm: false
  });

  // Handle full resync confirmation
  if (fullResync) {
    const { data: existingCache } = await processor.loadCache();
    if (existingCache && existingCache.goals && existingCache.goals.length > 0) {
      console.log(chalk.yellow('\n⚠ Warning: Full resync mode enabled'));
      console.log(chalk.gray(`  Existing cache contains ${existingCache.goals.length} goal(s)`));
      console.log(chalk.yellow('  This will re-analyze all goals and override the cache.\n'));

      const confirmed = await promptConfirm(chalk.cyan('Continue with full resync?'));
      if (!confirmed) {
        console.log(chalk.gray('\nCancelled. Use without --full flag for incremental sync.'));
        return;
      }

      // Update options with confirmation
      processor.options.autoConfirm = true;
    }
  }

  // Process goals
  const result = await processor.processGoals('sync');

  if (result.success) {
    console.log(chalk.green('\n✅ Goals sync completed successfully'));

    // Display summary
    const { data: cacheData } = await processor.loadCache();
    if (cacheData && cacheData.summary) {
      displaySummary(cacheData.summary);
    }
  } else if (result.needsConfirmation) {
    // Should not reach here as we handle confirmation above
    console.error(chalk.red('Error: Unexpected confirmation requirement'));
  } else {
    console.error(chalk.red(`\n❌ Sync failed: ${result.message}`));
  }
}

/**
 * Display goals summary
 */
function displaySummary(summary) {
  console.log(chalk.cyan('\nGoals Summary'));
  console.log(chalk.gray('─'.repeat(40)));

  const { statusCounts, overallCompletion, tasksComplete, totalTasks } = summary;

  // Status breakdown
  Object.entries(statusCounts).forEach(([status, count]) => {
    if (count > 0) {
      let statusColor;
      if (status === 'Completed') {
        statusColor = chalk.green;
      } else if (status === 'In Progress') {
        statusColor = chalk.yellow;
      } else if (status === 'Not Started') {
        statusColor = chalk.white;
      } else if (status === 'Cancelled') {
        statusColor = chalk.gray.dim;
      } else if (status === 'Abandoned') {
        statusColor = chalk.red;
      } else {
        statusColor = chalk.white;
      }
      console.log(statusColor(`${status}: ${count}`));
    }
  });
}

/**
 * List all goals with summary
 */
async function listGoals(goalsDir, forceRefresh = false) {
  const processor = createGoalsProcessor(goalsDir);

  // Check if cache needs refresh
  if (forceRefresh) {
    console.log(chalk.cyan('Refreshing goals cache...'));
    await processor.processGoals('sync');
  }

  // Load cache
  let { data: cacheData, exists } = await processor.loadCache();

  if (!exists || !cacheData) {
    console.error(chalk.red('Error: No cache found'));
    console.log(chalk.yellow('Run sync first: ') + chalk.cyan('ani-code goals sync'));
    console.log(chalk.gray('Or use --refresh flag to sync and list'));
    process.exit(1);
  }

  // Display goals
  if (!cacheData.goals || cacheData.goals.length === 0) {
    console.log(chalk.yellow('No goals found'));
    return;
  }

  console.log(chalk.cyan('\nProject Goals'));
  console.log(chalk.gray('═'.repeat(60)));

  // Sort goals by ID to maintain order
  const sortedGoals = [...cacheData.goals].sort((a, b) => (a.id || 0) - (b.id || 0));

  sortedGoals.forEach(goal => {
    const status = goal.status || goal.progress?.status || 'Unknown';
    const completion = goal.completionPercentage || 0;

    // Abbreviate status
    let statusAbbrev;
    if (status === 'Completed') {
      statusAbbrev = 'COMP';
    } else if (status === 'In Progress') {
      statusAbbrev = 'PROG';
    } else if (status === 'Not Started') {
      statusAbbrev = 'TODO';
    } else if (status === 'Abandoned') {
      statusAbbrev = 'ABAND';
    } else if (status === 'Cancelled') {
      statusAbbrev = 'CNCL';
    } else if (status === 'On Hold') {
      statusAbbrev = 'HOLD';
    } else {
      statusAbbrev = 'UNKN';
    }

    // Color based on status
    let lineColor;
    if (status === 'Completed') {
      lineColor = chalk.green;
    } else if (status === 'In Progress') {
      lineColor = chalk.yellow;
    } else if (status === 'Not Started') {
      lineColor = chalk.white;
    } else if (status === 'Cancelled') {
      lineColor = chalk.gray.dim;
    } else if (status === 'Abandoned') {
      lineColor = chalk.red;
    } else {
      lineColor = chalk.white;
    }

    // Build format: STATUS - ID - FILENAME [PERCENTAGE]
    const idStr = String(goal.id).padStart(3, ' ');
    let line = `${statusAbbrev.padEnd(5)} - ${idStr} - ${goal.file}`;

    // Add progress percentage only for non-completed goals
    if (status !== 'Completed') {
      line += ` (${completion}%)`;
    }

    console.log(lineColor(line));
  });

  // Display summary
  if (cacheData.summary) {
    displaySummary(cacheData.summary);
  }
}

/**
 * Show detailed information about a specific goal
 */
async function showGoal(goalId, goalsDir) {
  const processor = createGoalsProcessor(goalsDir);
  const { data: cacheData } = await processor.loadCache();

  if (!cacheData || !cacheData.goals) {
    console.error(chalk.red('Error: No cache found'));
    console.log(chalk.yellow('Run sync first: ') + chalk.cyan('ani-code goals sync'));
    process.exit(1);
  }

  // Find goal by ID or filename
  const goal = cacheData.goals.find(g =>
    g.id === parseInt(goalId) ||
    g.file.includes(goalId) ||
    g.file === goalId
  );

  if (!goal) {
    console.error(chalk.red(`Goal "${goalId}" not found`));
    return;
  }

  // Display detailed information
  console.log(chalk.cyan('\n📄 Goal Details'));
  console.log(chalk.gray('═'.repeat(60)));
  console.log(chalk.bold(`ID: ${goal.id}`));
  console.log(chalk.bold(`File: ${goal.file}`));
  console.log(chalk.bold(`Status: ${goal.status || goal.progress?.status}`));
  console.log(chalk.bold(`Progress: ${goal.completionPercentage || 0}%`));

  if (goal.progress) {
    console.log(chalk.bold('\n📅 Timeline:'));
    console.log(`  Start Date: ${goal.progress.startDate || '-'}`);
    console.log(`  Completion Date: ${goal.progress.completionDate || '-'}`);
  }

  if (goal.taskCount > 0) {
    console.log(chalk.bold('\n✅ Tasks:'));
    console.log(`  Completed: ${goal.tasksComplete}/${goal.taskCount}`);
    console.log(`  Progress: ${generateProgressBar(goal.completionPercentage || 0)}`);
  }

  if (goal.phaseCount > 0) {
    console.log(chalk.bold('\n🎯 Phases:'));
    console.log(`  Completed: ${goal.phasesComplete}/${goal.phaseCount}`);
    console.log(`  Progress: ${generateProgressBar(goal.completionPercentage || 0)}`);
  }

  // Read and display full content if requested
  if (goal.path && existsSync(goal.path)) {
    console.log(chalk.gray('\n' + '─'.repeat(60)));
    console.log(chalk.gray('Full content available at:'), chalk.cyan(goal.path));
  }
}

/**
 * Export goals data to JSON
 */
function exportGoals(goalsDir, outputFile) {
  const processor = createGoalsProcessor(goalsDir);
  const outputPath = outputFile || join(process.cwd(), '.ani-code', 'goals-export.json');

  processor.loadCache().then(({ data: cacheData }) => {
    if (!cacheData) {
      console.error(chalk.red('No cache found. Please run sync first.'));
      return;
    }

    // Prepare export data
    const exportData = {
      exported: new Date().toISOString(),
      workspace: process.cwd(),
      ...cacheData
    };

    // Write to file
    writeFileSync(outputPath, JSON.stringify(exportData, null, 2));
    console.log(chalk.green(`✅ Exported ${cacheData.goals.length} goals to ${outputPath}`));
  });
}

/**
 * Generate smart filename from goal description
 * @param {string} description - User's goal description
 * @returns {string} Suggested filename slug
 */
function generateSmartFilename(description) {
  if (!description || description.trim().length === 0) {
    return 'new-goal';
  }

  // Extract key terms and create filename
  let slug = description
    .toLowerCase()
    .trim()
    // Remove common prefixes
    .replace(/^(implement|create|add|build|develop|setup|configure|fix|update)\s+/i, '')
    // Remove articles and common words
    .replace(/\b(a|an|the|for|with|and|or|in|on|at|to|from)\b/g, ' ')
    // Replace special characters with spaces
    .replace(/[^a-z0-9\s-]/g, ' ')
    // Collapse multiple spaces
    .replace(/\s+/g, ' ')
    .trim()
    // Take first 3-4 meaningful words
    .split(' ')
    .slice(0, 4)
    .join('-')
    // Remove trailing/leading dashes
    .replace(/^-+|-+$/g, '');

  // Fallback if slug is too short
  if (slug.length < 3) {
    return 'new-goal';
  }

  // Limit length to 40 characters
  if (slug.length > 40) {
    slug = slug.substring(0, 40).replace(/-[^-]*$/, '');
  }

  return slug || 'new-goal';
}

/**
 * Add or update a goal with Claude's help
 */
async function addGoal(description, goalsDir, options) {
  try {
    // Validate description length (skip validation in update mode)
    if (!options.update && (!description || description.trim().length < 25)) {
      console.log(chalk.yellow('\n⚠ Insufficient information provided'));
      console.log(chalk.gray('Please provide a more detailed description (at least 25 characters)'));
      console.log(chalk.cyan('\nExample:'));
      console.log(chalk.gray('  ani-code goals add "Implement user authentication with JWT tokens"'));
      console.log(chalk.gray('  ani-code goals add "Create REST API endpoints for product management"'));
      return;
    }

    // Create goals directory if needed
    mkdirSync(goalsDir, { recursive: true });

    const goalFiles = findGoalFiles(goalsDir);
    let targetFile = null;
    let existingContent = '';
    let goalId = null;

    // Handle update mode
    if (options.update) {
      const updateId = options.update;

      // Try to parse as number
      const numId = parseInt(updateId);
      if (!isNaN(numId)) {
        targetFile = findGoalFileById(numId, goalFiles);
        goalId = numId;
      } else {
        // Search by description
        for (const file of goalFiles) {
          const content = readFileSync(file, 'utf8');
          if (content.toLowerCase().includes(updateId.toLowerCase())) {
            targetFile = file;
            goalId = extractGoalId(basename(file));
            break;
          }
        }
      }

      if (!targetFile || !existsSync(targetFile)) {
        console.error(chalk.red(`Error: Could not find goal matching "${updateId}"`));
        return;
      }

      if (options.merge) {
        existingContent = readFileSync(targetFile, 'utf8');
      }
    } else {
      // Create new goal - assign index and generate smart filename
      const existingIds = goalFiles.map(f => extractGoalId(basename(f))).filter(id => id !== null);
      goalId = existingIds.length > 0 ? Math.max(...existingIds) + 1 : 1;
      const paddedId = String(goalId).padStart(3, '0');

      // Generate smart filename from description
      const suggestedName = generateSmartFilename(description);
      const filename = `${paddedId}-${suggestedName}.md`;
      targetFile = join(goalsDir, filename);

      // Create placeholder in cache immediately to reserve index
      const processor = createGoalsProcessor(goalsDir);
      const { data: existingCache } = await processor.loadCache();
      const placeholderGoal = {
        id: goalId,
        file: filename,
        path: targetFile,
        status: 'Not Started',
        completionPercentage: 0,
        phaseCount: 0,
        phasesComplete: 0,
        taskCount: 0,
        tasksComplete: 0,
        progress: {
          status: 'Not Started',
          startDate: '-',
          completionDate: '-',
          notes: 'Goal creation in progress...'
        },
        _placeholder: true,
        _suggestedFilename: filename
      };

      if (existingCache && existingCache.goals) {
        existingCache.goals.push(placeholderGoal);
        await processor.saveCache(existingCache);
      } else {
        await processor.saveCache({
          goals: [placeholderGoal],
          totalGoals: 1,
          lastUpdated: new Date().toISOString()
        });
      }

      // Display assigned index immediately
      console.log(chalk.green(`\n✅ Reserved goal index: #${goalId}`));
      console.log(chalk.gray(`Suggested file: ${filename}`));
      console.log(chalk.cyan('Use this index to track progress\n'));
    }

    // Get PRD content if exists
    const prdPath = join(process.cwd(), 'pd', 'prd.md');
    const prdContent = existsSync(prdPath) ? readFileSync(prdPath, 'utf8') : '';

    // Get existing goal titles for context
    const existingGoalTitles = goalFiles.map(f => basename(f));

    // Build prompt
    const prompt = buildAddGoalPrompt(description, {
      existingContent,
      prdContent,
      goalId,
      targetFile,
      existingGoalTitles,
      merge: options.merge
    });

    // Check daemon
    const daemonClient = new DaemonClient();
    if (!daemonClient.isDaemonRunning()) {
      console.error(chalk.red('Error: Daemon is not running'));
      console.log(chalk.yellow('Start the daemon with: ani-code daemon --start'));
      return;
    }

    // Send to Claude
    console.log(chalk.cyan(`${options.update ? 'Updating' : 'Creating'} goal with Claude...`));

    const client = new IPCClient();
    await client.connect();

    const task = await client.addTask('goal-add', prompt, { cwd: process.cwd() });

    // Wait for completion
    console.log(chalk.gray('Waiting for Claude to generate goal...'));

    let complete = false;
    const timeout = 60000; // 60 seconds
    const startTime = Date.now();

    while (!complete && Date.now() - startTime < timeout) {
      const taskInfo = await client.getTask(task.id);
      if (taskInfo && (taskInfo.status === 'completed' || taskInfo.status === 'failed')) {
        complete = true;

        if (taskInfo.status === 'completed' && taskInfo.output) {
          // Write goal file
          writeFileSync(targetFile, taskInfo.output);

          // Check if Claude created a different filename
          const actualFiles = findGoalFiles(goalsDir);
          const newGoalFiles = actualFiles.filter(f => !goalFiles.includes(f));
          let actualFile = targetFile;

          if (newGoalFiles.length > 0) {
            // Claude created a file with different name
            const createdFile = newGoalFiles.find(f => extractGoalId(basename(f)) === goalId);
            if (createdFile && createdFile !== targetFile) {
              actualFile = createdFile;
              console.log(chalk.gray(`Claude renamed to: ${basename(createdFile)}`));
            }
          }

          console.log(chalk.green(`✅ Goal ${options.update ? 'updated' : 'created'}: ${basename(actualFile)}`));

          // Update placeholder with real file info (skip full sync - goalloop will sync after)
          const processor = createGoalsProcessor(goalsDir);
          const { data: currentCache } = await processor.loadCache();
          if (currentCache && currentCache.goals) {
            const goalIndex = currentCache.goals.findIndex(g => g.id === goalId);
            if (goalIndex !== -1) {
              // Quick scan to get basic status from the file
              const quickStatus = quickScanGoalStatus(actualFile);

              // Update placeholder with real data, remove _placeholder flag
              currentCache.goals[goalIndex] = {
                ...currentCache.goals[goalIndex],
                file: basename(actualFile),
                path: actualFile,
                status: quickStatus.status || 'Not Started',
                completionPercentage: 0,
                _placeholder: false  // Mark as ready for goalloop
              };
              currentCache.lastUpdated = new Date().toISOString();
              await processor.saveCache(currentCache);
              console.log(chalk.gray('Cache updated (full sync will run after goalloop iteration)'));
            }
          }

          // Display final confirmation with index
          if (!options.update) {
            console.log(chalk.green(`\n✅ Goal #${goalId} created successfully`));
            console.log(chalk.gray(`Track progress with: ani-code goals show ${goalId}`));
            console.log(chalk.gray(`Start working: ani-code goals loop --goal ${goalId}`));
          }
        } else {
          console.error(chalk.red('Failed to generate goal'));

          // Clean up placeholder from cache on failure
          if (!options.update) {
            const processor = createGoalsProcessor(goalsDir);
            const { data: cacheData } = await processor.loadCache();
            if (cacheData && cacheData.goals) {
              cacheData.goals = cacheData.goals.filter(g => !(g._placeholder && g.id === goalId));
              await processor.saveCache(cacheData);
            }
          }
        }
      }

      if (!complete) {
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
    }

    if (!complete) {
      console.error(chalk.red('Timeout waiting for Claude'));

      // Clean up placeholder from cache on timeout
      if (!options.update) {
        const processor = createGoalsProcessor(goalsDir);
        const { data: cacheData } = await processor.loadCache();
        if (cacheData && cacheData.goals) {
          cacheData.goals = cacheData.goals.filter(g => !(g._placeholder && g.id === goalId));
          await processor.saveCache(cacheData);
        }
      }
    }

    await client.disconnect();

  } catch (error) {
    console.error(chalk.red('Error:'), error.message);
  }
}

/**
 * Execute automated goal loop
 */
async function executeGoalLoop(goalsDir, options) {
  console.log(chalk.cyan('🔄 Starting automated goal execution loop'));
  console.log(chalk.gray('─'.repeat(60)));

  // Load goals
  const processor = createGoalsProcessor(goalsDir);
  const { data: cacheData } = await processor.loadCache();

  if (!cacheData || !cacheData.goals) {
    console.error(chalk.red('Error: No cache found'));
    console.log(chalk.yellow('Run sync first: ') + chalk.cyan('ani-code goals sync'));
    process.exit(1);
  }

  // Filter goals to work on
  let targetGoals = cacheData.goals.filter(g => {
    const status = g.status || g.progress?.status;
    return status === 'In Progress' || status === 'Not Started';
  });

  // Filter by specific goal if requested
  if (options.goal) {
    const goalId = options.goal;
    targetGoals = targetGoals.filter(g =>
      g.id === parseInt(goalId) ||
      g.file.includes(goalId) ||
      (g.title && g.title.toLowerCase().includes(goalId.toLowerCase()))
    );

    if (targetGoals.length === 0) {
      console.error(chalk.red(`No matching goal found for "${goalId}"`));
      return;
    }
  }

  if (targetGoals.length === 0) {
    // Auto-sync first in case user forgot to sync new/updated goals
    console.log(chalk.cyan('🔄 No pending goals found - running goalsync --fast to check for updates...'));
    await processor.processGoals('sync', { fast: true });

    // Reload cache after sync
    const { data: refreshedCache } = await processor.loadCache();
    if (refreshedCache && refreshedCache.goals) {
      targetGoals = refreshedCache.goals.filter(g => {
        const status = g.status || g.progress?.status;
        return status === 'In Progress' || status === 'Not Started';
      });

      // Re-apply goal filter if specified
      if (options.goal) {
        const goalId = options.goal;
        targetGoals = targetGoals.filter(g =>
          g.id === parseInt(goalId) ||
          g.file.includes(goalId) ||
          (g.title && g.title.toLowerCase().includes(goalId.toLowerCase()))
        );
      }
    }

    // Check again after sync
    if (targetGoals.length === 0) {
      console.log(chalk.green('✅ All goals are completed!'));
      return;
    }

    console.log(chalk.green(`✓ Found ${targetGoals.length} goal(s) after sync`));
  }

  // Get PRD for context
  const prdPath = join(process.cwd(), 'pd', 'prd.md');
  const prdContent = existsSync(prdPath) ? readFileSync(prdPath, 'utf8') : '';

  // Check daemon
  const daemonClient = new DaemonClient();
  if (!daemonClient.isDaemonRunning()) {
    console.error(chalk.red('Error: Daemon is not running'));
    console.log(chalk.yellow('Start the daemon with: ani-code daemon --start'));
    return;
  }

  // Connect to Claude
  const client = new IPCClient();
  await client.connect();

  try {
    const limit = options.limit || 5;
    let iterations = 0;
    const overallTimeout = 21600000; // 6 hours total (matching Telegram goalloop)
    const loopStartTime = Date.now();

    // Track cumulative statistics
    const { execSync, exec } = await import('child_process');
    const { promisify } = await import('util');
    const execAsync = promisify(exec);
    const loopStartCommits = parseInt(execSync('git rev-list --count HEAD', { cwd: process.cwd() }).toString().trim());
    let totalTokensUsed = 0;
    let totalCostUsd = 0;
    let totalCommitsMade = 0;

    // Track loop-wide cumulative snapshot (for final reporting)
    let loopInitialInputTokens = 0;
    let loopInitialOutputTokens = 0;
    let loopInitialCacheRead = 0;
    let loopInitialCacheCreation = 0;

    // Track iteration-specific snapshot (refreshed each iteration)
    let iterationInputTokens = 0;
    let iterationOutputTokens = 0;
    let iterationCacheRead = 0;
    let iterationCacheCreation = 0;

    try {
      const { stdout } = await execAsync('npx ccusage -j --breakdown --since ' + new Date().toISOString().split('T')[0].replace(/-/g, ''), { encoding: 'utf8', timeout: 5000 });
      const initialSnapshot = JSON.parse(stdout);
      if (initialSnapshot && initialSnapshot.totals) {
        loopInitialInputTokens = initialSnapshot.totals.inputTokens || 0;
        loopInitialOutputTokens = initialSnapshot.totals.outputTokens || 0;
        loopInitialCacheRead = initialSnapshot.totals.cacheReadTokens || 0;
        loopInitialCacheCreation = initialSnapshot.totals.cacheCreationTokens || 0;

        // Initialize iteration snapshot
        iterationInputTokens = loopInitialInputTokens;
        iterationOutputTokens = loopInitialOutputTokens;
        iterationCacheRead = loopInitialCacheRead;
        iterationCacheCreation = loopInitialCacheCreation;
      }
    } catch (e) {
      // Initial snapshot not available - will start from 0
    }

    while (iterations < limit) {
      // Check if all goals are completed
      if (targetGoals.length === 0) {
        console.log(chalk.green('\n✅ All goals completed!'));
        break;
      }
      // Check overall timeout
      if (Date.now() - loopStartTime > overallTimeout) {
        console.log(chalk.yellow('\n⏰ Overall timeout reached (6 hours)'));
        console.log(chalk.gray('Stopping goalloop gracefully...'));
        break;
      }
      iterations++;
      console.log(chalk.cyan(`\n📍 Iteration ${iterations}/${limit}`));
      console.log(chalk.gray('─'.repeat(40)));

      // Refresh iteration snapshot at the start of each iteration for minute-level delta tracking
      try {
        const { stdout } = await execAsync('npx ccusage -j --breakdown --since ' + new Date().toISOString().split('T')[0].replace(/-/g, ''), { encoding: 'utf8', timeout: 5000 });
        const iterationSnapshot = JSON.parse(stdout);
        if (iterationSnapshot && iterationSnapshot.totals) {
          iterationInputTokens = iterationSnapshot.totals.inputTokens || 0;
          iterationOutputTokens = iterationSnapshot.totals.outputTokens || 0;
          iterationCacheRead = iterationSnapshot.totals.cacheReadTokens || 0;
          iterationCacheCreation = iterationSnapshot.totals.cacheCreationTokens || 0;
        }
      } catch (e) {
        // Snapshot refresh failed - continue with existing values
      }

      // Pick next goal to work on
      const goal = targetGoals[0];

      // Check git dirty status
      let gitStatus = '';
      try {
        const gitStatusOutput = execSync('git status --porcelain', { cwd: process.cwd() }).toString().trim();
        gitStatus = gitStatusOutput ? 'dirty' : 'clean';
      } catch (e) {
        gitStatus = 'unknown';
      }

      // Show cumulative stats (only after first iteration when we have data)
      if (iterations > 1) {
        console.log(chalk.gray(`📈 Loop Progress: 💰 $${totalCostUsd.toFixed(4)} | 🔤 ${totalTokensUsed.toLocaleString()} | ${gitStatus}`));
      }

      console.log(chalk.bold(`Working on: ${goal.file}`));
      console.log(`Status: ${goal.status || goal.progress?.status}`);
      console.log(`Progress: ${goal.completionPercentage || 0}%`);

      // Show remaining goals count
      const remainingGoals = targetGoals.length;
      const completedGoals = cacheData.goals.filter(g => {
        const status = g.status || g.progress?.status;
        return COMPLETED_STATUSES.includes(status);
      }).length;
      console.log(chalk.gray(`Goals: ${completedGoals} completed, ${remainingGoals} remaining`));

      // Get iteration history path and context
      const iterationHistoryPath = getIterationHistoryPath(process.cwd(), goal.id);
      const lastIterationInfo = getLastIterationInfo(process.cwd(), goal.id);
      const isFreshStart = !lastIterationInfo;

      // Check if previous iteration ended with ANICODE_BREAK - skip once then allow retry
      if (lastIterationInfo && lastIterationInfo.failureReason &&
          lastIterationInfo.failureReason.includes('ANICODE_BREAK') &&
          !lastIterationInfo.failureReason.includes('ANICODE_BREAK_HANDLED')) {
        console.log(chalk.red('\n🛑 Previous iteration ended with ANICODE_BREAK'));
        console.log(chalk.yellow(`Reason: ${lastIterationInfo.failureReason.replace('ANICODE_BREAK: ', '')}`));
        console.log(chalk.gray('Skipping this goal for now. It will be retried on the next goalloop run.'));

        // Clear the break marker so next goalloop invocation can retry
        clearAnicodeBreak(process.cwd(), goal.id);

        // Skip this goal and continue with next one if available
        if (targetGoals.length > 1) {
          console.log(chalk.cyan('\n➡️ Skipping to next goal...'));
          targetGoals.shift(); // Remove this goal from queue
          continue;
        } else {
          console.log(chalk.yellow('\nNo other goals to work on. Stopping goal loop.'));
          break;
        }
      }

      // Format iteration history for prompt injection (only for non-fresh starts)
      let iterationHistoryContent = '';
      if (!isFreshStart) {
        iterationHistoryContent = formatIterationHistoryForPrompt(process.cwd(), goal.id, 3);
        console.log(chalk.gray(`📜 Iteration history: ${lastIterationInfo.totalIterations} previous iteration(s)`));
        if (lastIterationInfo.status === 'failed') {
          console.log(chalk.yellow(`⚠ Last iteration FAILED - context will be provided to Claude`));
        }

        // Note: Secondary ANICODE_BREAK detection removed - the primary check on
        // failureReason (above) is sufficient. Scanning raw output/history content
        // caused false positives after the break was already handled.
      } else {
        console.log(chalk.gray(`📜 Fresh start - no previous iterations`));
      }

      // Build execution prompt with iteration history path and context
      let prompt = buildGoalExecutionPrompt(goal, prdContent, {
        iterationHistoryPath,
        iterationHistoryContent,
        isFreshStart,
        lastIteration: lastIterationInfo
      });

      // Extract provider from prompt inline syntax (@@provider)
      const inlineProvider = extractProviderFromPrompt(prompt);

      // Provider priority: 1. CLI option, 2. Goal cache provider, 3. Inline prompt
      const goalProvider = goal.provider; // From set-provider command
      const effectiveProvider = options.provider || goalProvider || inlineProvider;

      // Strip provider patterns from prompt (inline ones)
      if (inlineProvider) {
        prompt = stripPatternsFromPrompt(prompt);
      }

      // If goal has a provider set via set-provider, append @@provider to prompt
      // This ensures provider tag is included even when prompt is packed into file
      if (goalProvider && !options.provider) {
        prompt = prompt.trim() + ` @@${goalProvider}`;
      }

      // Send to Claude with descriptive task name
      const taskName = `goal-execute: ${goal.file.replace('.md', '')}`;
      const taskOptions = { cwd: process.cwd() };

      // Add provider to task options if specified
      if (effectiveProvider) {
        taskOptions.providerId = effectiveProvider;
        const providerSource = options.provider ? 'CLI option' : (goalProvider ? 'goal setting' : 'inline prompt');
        console.log(chalk.gray(`Using provider: ${effectiveProvider} (${providerSource})`));
      }

      const task = await client.addTask(taskName, prompt, taskOptions);

      // Wait for completion
      console.log(chalk.gray('\n⏳ Claude is working on implementation...'));

      // Track statistics for this iteration
      const initialCommitCount = parseInt(execSync('git rev-list --count HEAD', { cwd: process.cwd() }).toString().trim());

      let complete = false;
      const timeout = 1800000; // 30 minutes per task (matching Telegram goalloop)
      const startTime = Date.now();
      let lastStatusUpdate = Date.now();
      const statusUpdateInterval = 60000; // Show status every minute
      let lastCommits = 0;
      let lastTokens = 0;
      let lastCost = 0;

      while (!complete && Date.now() - startTime < timeout) {
        const taskInfo = await client.getTask(task.id);

        // Show periodic status updates with statistics
        if (Date.now() - lastStatusUpdate > statusUpdateInterval) {
          const elapsed = Math.floor((Date.now() - startTime) / 1000);
          const minutes = Math.floor(elapsed / 60);
          const seconds = elapsed % 60;

          // Get current statistics (loop-wide, not iteration-specific)
          const currentCommitCount = parseInt(execSync('git rev-list --count HEAD', { cwd: process.cwd() }).toString().trim());
          const commitsMade = currentCommitCount - loopStartCommits;

          let tokensUsed = 0;
          let costUsd = 0;
          let tokenStatus = '';
          let hasUsageData = false;

          // Try to get real-time usage from snapshot
          try {
            const { stdout } = await execAsync('npx ccusage -j --breakdown --since ' + new Date().toISOString().split('T')[0].replace(/-/g, ''), { encoding: 'utf8', timeout: 5000 });
            const currentSnapshot = JSON.parse(stdout);

            if (currentSnapshot && currentSnapshot.totals) {
              const inputTokens = currentSnapshot.totals.inputTokens || 0;
              const outputTokens = currentSnapshot.totals.outputTokens || 0;
              const cacheRead = currentSnapshot.totals.cacheReadTokens || 0;
              const cacheCreation = currentSnapshot.totals.cacheCreationTokens || 0;

              // Calculate incremental tokens from ITERATION START snapshot (for minute-level deltas)
              const inputDiff = inputTokens - iterationInputTokens;
              const outputDiff = outputTokens - iterationOutputTokens;
              const cacheReadDiff = cacheRead - iterationCacheRead;
              const cacheCreationDiff = cacheCreation - iterationCacheCreation;
              tokensUsed = inputDiff + outputDiff + cacheReadDiff + cacheCreationDiff;

              // Calculate cost (sonnet-4.5 pricing)
              const inputCost = (inputDiff * 3 / 1000000);  // $3 per 1M tokens
              const outputCost = (outputDiff * 15 / 1000000); // $15 per 1M tokens
              const cacheReadCost = (cacheReadDiff * 0.3 / 1000000); // $0.30 per 1M tokens
              const cacheCreationCost = (cacheCreationDiff * 3.75 / 1000000); // $3.75 per 1M tokens
              costUsd = inputCost + outputCost + cacheReadCost + cacheCreationCost;
              hasUsageData = true;
            }
          } catch (err) {
            // Fallback: ccusage not available, token tracking will be unavailable
            // We don't use taskInfo.usage as it only shows task-specific usage, not iteration-specific
          }

          // Calculate deltas
          const commitDelta = commitsMade - lastCommits;
          const tokenDelta = tokensUsed - lastTokens;
          const costDelta = costUsd - lastCost;

          // Check git dirty status
          let currentGitStatus = 'unknown';
          try {
            const gitStatusOutput = execSync('git status --porcelain', { cwd: process.cwd() }).toString().trim();
            currentGitStatus = gitStatusOutput ? 'dirty' : 'clean';
          } catch (e) {
            currentGitStatus = 'unknown';
          }

          // Build standard prefix: [Iter#X Goal#Y MM:SS]
          const prefix = chalk.cyan(`[Iter#${iterations} Goal#${goal.id} ${minutes}:${seconds.toString().padStart(2, '0')}]`);

          // Build single-line status with deltas (format: Cost | Tokens | Git Status)
          let statusLine = `${prefix} ⏳ Still working...`;

          // Show cost and token info based on availability
          if (hasUsageData) {
            statusLine += ` | 💰 $${costUsd.toFixed(4)}`;
            if (costDelta > 0) statusLine += chalk.green(` (+$${costDelta.toFixed(4)})`);

            statusLine += ` | 🔤 ${tokensUsed.toLocaleString()}`;
            if (tokenDelta > 0) statusLine += chalk.green(` (+${tokenDelta.toLocaleString()})`);
          } else {
            statusLine += ` | Tokens: calculating...`;
          }

          // Show file/line changes if available
          try {
            const diffStats = execSync('git diff --shortstat', { cwd: process.cwd() }).toString().trim();
            if (diffStats && currentGitStatus === 'dirty') {
              // Parse: "2 files changed, 50 insertions(+), 14 deletions(-)"
              const fileMatch = diffStats.match(/(\d+)\s+files?\s+changed/);
              const insertMatch = diffStats.match(/(\d+)\s+insertion/);
              const deleteMatch = diffStats.match(/(\d+)\s+deletion/);

              const files = fileMatch ? fileMatch[1] : '0';
              const adds = insertMatch ? insertMatch[1] : '0';
              const dels = deleteMatch ? deleteMatch[1] : '0';

              statusLine += ` | Git Status (${files} files: +${adds}/-${dels})`;
            } else {
              statusLine += ` | Git: ${currentGitStatus}`;
            }
          } catch (e) {
            statusLine += ` | Git: ${currentGitStatus}`;
          }

          console.log(chalk.gray(statusLine));

          // Update last values
          lastCommits = commitsMade;
          lastTokens = tokensUsed;
          lastCost = costUsd;
          lastStatusUpdate = Date.now();
        }

        if (taskInfo && (taskInfo.status === 'completed' || taskInfo.status === 'failed')) {
          complete = true;

          if (taskInfo.status === 'completed') {
            // Calculate final statistics
            const currentCommitCount = parseInt(execSync('git rev-list --count HEAD', { cwd: process.cwd() }).toString().trim());
            const commitsMade = currentCommitCount - initialCommitCount;

            let tokensUsed = 0;
            let costUsd = 0;
            if (taskInfo && taskInfo.usage) {
              const inputTokens = taskInfo.usage.inputTokens || 0;
              const outputTokens = taskInfo.usage.outputTokens || 0;
              const cacheRead = taskInfo.usage.cacheReadInputTokens || 0;
              const cacheCreation = taskInfo.usage.cacheCreationInputTokens || 0;

              // Use absolute token counts (not incremental - taskInfo.usage already contains iteration-specific data)
              tokensUsed = inputTokens + outputTokens + cacheRead + cacheCreation;

              // Calculate cost (sonnet-4.5 pricing)
              const inputCost = (inputTokens * 3 / 1000000);  // $3 per 1M tokens
              const outputCost = (outputTokens * 15 / 1000000); // $15 per 1M tokens
              const cacheReadCost = (cacheRead * 0.3 / 1000000); // $0.30 per 1M tokens
              const cacheCreationCost = (cacheCreation * 3.75 / 1000000); // $3.75 per 1M tokens
              costUsd = inputCost + outputCost + cacheReadCost + cacheCreationCost;
            }

            const elapsed = Math.floor((Date.now() - startTime) / 1000);
            const minutes = Math.floor(elapsed / 60);
            const seconds = elapsed % 60;

            console.log(chalk.green('\n✅ Task completed'));
            console.log(chalk.cyan(`\n📊 Iteration Statistics:`));
            console.log(chalk.gray(`  ⏱️  Duration: ${minutes}m ${seconds}s`));
            console.log(chalk.gray(`  💰 Cost: $${costUsd.toFixed(4)}`));
            console.log(chalk.gray(`  🔤 Tokens: ${tokensUsed.toLocaleString()}`));
            console.log(chalk.gray(`  💾 Commits: ${commitsMade}`));

            // Accumulate statistics
            totalCommitsMade += commitsMade;
            totalTokensUsed += tokensUsed;
            totalCostUsd += costUsd;

            if (taskInfo.output) {
              console.log(chalk.gray('\nClaude\'s summary:'));
              console.log(taskInfo.output);
            }

            // Check for __ANICODE_BREAK pattern in output (repeat failure detection)
            const breakDetection = detectAnicodeBreak(taskInfo.output);
            if (breakDetection) {
              console.log(chalk.red('\n🛑 ANICODE_BREAK detected!'));
              console.log(chalk.yellow(`Reason: ${breakDetection.reason}`));
              console.log(chalk.gray('Stopping goal loop due to repeat failure pattern.'));

              // Record as failed iteration with break reason
              const breakElapsed = Math.floor((Date.now() - startTime) / 1000);
              addIterationToHistory(process.cwd(), goal, {
                duration: breakElapsed,
                tokensUsed,
                commitsMade,
                output: taskInfo.output || '',
                status: 'failed',
                failureReason: `ANICODE_BREAK: ${breakDetection.reason}`,
                conclusion: `Goal loop stopped due to repeat failure: ${breakDetection.reason}`,
                iterationType: 'goalloop',
                taskId: task.id
              });
              console.log(chalk.gray('✓ Break recorded in iteration history'));
              break; // Exit the main loop
            }

            // Store iteration in history file
            addIterationToHistory(process.cwd(), goal, {
              duration: elapsed,
              tokensUsed,
              commitsMade,
              output: taskInfo.output || '',
              status: 'completed',
              iterationType: 'goalloop',
              taskId: task.id
            });
            console.log(chalk.gray('✓ Iteration history saved'));

            // Re-sync to update progress
            console.log(chalk.cyan('\n📊 Syncing goals (fast mode)...'));
            await processor.processGoals('sync', { fast: true });

            // Check if there are changes to commit
            let hasChanges = false;
            try {
              const gitStatusOutput = execSync('git status --porcelain', { cwd: process.cwd() }).toString().trim();
              hasChanges = gitStatusOutput.length > 0;
            } catch (e) {
              // Failed to check git status
            }

            if (hasChanges) {
              // Commit changes using ani-code commit workflow
              console.log(chalk.cyan('💾 Committing changes...'));
              try {
                const commitOutput = execSync('timeout 60 ani-code commit -y', {
                  cwd: process.cwd(),
                  encoding: 'utf8',
                  stdio: 'pipe'
                });

                console.log(chalk.green('✅ Changes committed'));

                // Display the last commit message as iteration conclusion
                try {
                  const lastCommitMsg = execSync('git log -1 --pretty=%B', { cwd: process.cwd() }).toString().trim();
                  console.log(chalk.cyan('\n📝 Commit Message:'));
                  console.log(chalk.gray(lastCommitMsg));
                } catch (err) {
                  // Failed to get commit message - continue silently
                }
              } catch (err) {
                console.log(chalk.yellow('⚠ Commit failed, continuing...'));
              }
            } else {
              console.log(chalk.gray('No changes to commit'));
            }

            // Reload goals for next iteration
            const { data: updatedCache } = await processor.loadCache();
            targetGoals = updatedCache.goals.filter(g => {
              const status = g.status || g.progress?.status;
              return status === 'In Progress' || status === 'Not Started';
            });

            if (options.goal) {
              const goalId = options.goal;
              targetGoals = targetGoals.filter(g =>
                g.id === parseInt(goalId) ||
                g.file.includes(goalId)
              );
            }
          } else {
            console.error(chalk.red('\n❌ Task failed'));

            // Record failure in iteration history for future awareness
            const failedElapsed = Math.floor((Date.now() - startTime) / 1000);
            addIterationToHistory(process.cwd(), goal, {
              duration: failedElapsed,
              tokensUsed: taskInfo?.usage ?
                (taskInfo.usage.inputTokens || 0) + (taskInfo.usage.outputTokens || 0) : 0,
              commitsMade: 0,
              output: taskInfo?.output || '',
              status: 'failed',
              failureReason: taskInfo?.error || 'Task execution failed',
              conclusion: taskInfo?.output || taskInfo?.error || 'Task failed without detailed output',
              iterationType: 'goalloop',
              taskId: task.id
            });
            console.log(chalk.gray('✓ Failure recorded in iteration history'));
            break;
          }
        }

        if (!complete) {
          await new Promise(resolve => setTimeout(resolve, 3000));
        }
      }

      if (!complete) {
        console.error(chalk.red('\n⏰ Task timed out'));

        // Record timeout in iteration history
        const timeoutElapsed = Math.floor((Date.now() - startTime) / 1000);
        addIterationToHistory(process.cwd(), goal, {
          duration: timeoutElapsed,
          tokensUsed: 0,
          commitsMade: 0,
          output: '',
          status: 'failed',
          failureReason: 'Task timed out after 30 minutes',
          conclusion: 'Task execution timed out - no response received within timeout period',
          iterationType: 'goalloop',
          taskId: task.id
        });
        console.log(chalk.gray('✓ Timeout recorded in iteration history'));
        break;
      }
    }

    // Final summary
    const loopElapsed = Math.floor((Date.now() - loopStartTime) / 1000);
    const loopMinutes = Math.floor(loopElapsed / 60);
    const loopSeconds = loopElapsed % 60;

    console.log(chalk.cyan('\n📊 Loop Summary'));
    console.log(chalk.gray('═'.repeat(60)));
    console.log(`Iterations completed: ${iterations}`);

    // Display cumulative statistics
    console.log(chalk.cyan('\n📈 Cumulative Statistics:'));
    console.log(chalk.gray(`  ⏱️  Total Duration: ${loopMinutes}m ${loopSeconds}s`));
    console.log(chalk.gray(`  💰 Total Cost: $${totalCostUsd.toFixed(4)}`));
    console.log(chalk.gray(`  🔤 Total Tokens: ${totalTokensUsed.toLocaleString()}`));
    console.log(chalk.gray(`  💾 Total Commits: ${totalCommitsMade}`));
    if (iterations > 0) {
      console.log(chalk.gray(`  📊 Avg Cost/Iteration: $${(totalCostUsd / iterations).toFixed(4)}`));
      console.log(chalk.gray(`  📊 Avg Tokens/Iteration: ${Math.round(totalTokensUsed / iterations).toLocaleString()}`));
    }

    const { data: finalCache } = await processor.loadCache();
    if (finalCache && finalCache.summary) {
      displaySummary(finalCache.summary);
    }

  } finally {
    await client.disconnect();
  }
}

/**
 * Review a goal to verify if it's actually completed or accidentally marked
 * @param {string} goalIdentifier - Goal ID or filename
 * @param {string} userConcern - User's concern or comment about the goal
 * @param {string} goalsDir - Goals directory path
 * @param {Object} options - Command options
 */
async function reviewGoal(goalIdentifier, userConcern, goalsDir, options) {
  try {
    const processor = createGoalsProcessor(goalsDir);
    const { data: cacheData } = await processor.loadCache();

    if (!cacheData || !cacheData.goals) {
      console.error(chalk.red('Error: No cache found'));
      console.log(chalk.yellow('Run sync first: ') + chalk.cyan('ani-code goals sync'));
      process.exit(1);
    }

    // Find goal by ID or filename
    let goal = null;
    const numId = parseInt(goalIdentifier);

    if (!isNaN(numId)) {
      // Search by numeric ID
      goal = cacheData.goals.find(g => g.id === numId);
    }

    if (!goal) {
      // Search by filename (partial or full match)
      goal = cacheData.goals.find(g =>
        g.file === goalIdentifier ||
        g.file.includes(goalIdentifier) ||
        (g.title && g.title.toLowerCase().includes(goalIdentifier.toLowerCase()))
      );
    }

    if (!goal) {
      console.error(chalk.red(`Goal "${goalIdentifier}" not found`));
      console.log(chalk.yellow('\nAvailable goals:'));
      cacheData.goals.forEach(g => {
        console.log(chalk.gray(`  ${g.id}: ${g.file}`));
      });
      return;
    }

    // Get goal file path
    const goalFilePath = goal.path || join(goalsDir, goal.file);

    if (!existsSync(goalFilePath)) {
      console.error(chalk.red(`Goal file not found: ${goalFilePath}`));
      return;
    }

    // Read goal content
    const goalContent = readFileSync(goalFilePath, 'utf8');

    // Get PRD content if exists
    const prdPath = join(process.cwd(), 'pd', 'prd.md');
    const prdContent = existsSync(prdPath) ? readFileSync(prdPath, 'utf8') : '';

    // Get iteration history if exists
    const iterationHistoryPath = getIterationHistoryPath(process.cwd(), goal.id);
    let iterationHistory = '';
    if (existsSync(iterationHistoryPath)) {
      try {
        const historyData = JSON.parse(readFileSync(iterationHistoryPath, 'utf8'));
        if (historyData.iterations && historyData.iterations.length > 0) {
          // Get last 5 iterations
          const recentIterations = historyData.iterations.slice(-5);
          iterationHistory = recentIterations.map(iter => {
            return `- ${iter.timestamp}: ${iter.status} - ${iter.output?.substring(0, 200) || 'No output'}...`;
          }).join('\n');
        }
      } catch (e) {
        // Ignore history parsing errors
      }
    }

    // Display goal info
    console.log(chalk.cyan('\n🔍 Goal Review'));
    console.log(chalk.gray('═'.repeat(60)));
    console.log(chalk.bold(`Goal ID: ${goal.id}`));
    console.log(chalk.bold(`File: ${goal.file}`));
    console.log(chalk.bold(`Current Status: ${goal.status || goal.progress?.status}`));
    console.log(chalk.bold(`Current Progress: ${goal.completionPercentage || 0}%`));

    if (userConcern) {
      console.log(chalk.yellow(`\nUser Concern: ${userConcern}`));
    }

    // Check daemon
    const daemonClient = new DaemonClient();
    if (!daemonClient.isDaemonRunning()) {
      console.error(chalk.red('\nError: Daemon is not running'));
      console.log(chalk.yellow('Start the daemon with: ani-code daemon --start'));
      return;
    }

    // Build review prompt
    const prompt = buildGoalReviewPrompt(goal, goalContent, userConcern, {
      prdContent,
      iterationHistory
    });

    // Send to Claude
    console.log(chalk.cyan('\n⏳ Claude is reviewing the goal...'));

    const client = new IPCClient();
    await client.connect();

    const taskName = `goal-review: ${goal.file.replace('.md', '')}`;
    const task = await client.addTask(taskName, prompt, { cwd: process.cwd() });

    // Wait for completion
    let complete = false;
    const timeout = 300000; // 5 minutes
    const startTime = Date.now();

    while (!complete && Date.now() - startTime < timeout) {
      const taskInfo = await client.getTask(task.id);

      if (taskInfo && (taskInfo.status === 'completed' || taskInfo.status === 'failed')) {
        complete = true;

        if (taskInfo.status === 'completed') {
          console.log(chalk.green('\n✅ Review completed'));

          if (taskInfo.output) {
            console.log(chalk.cyan('\n📋 Review Results:'));
            console.log(chalk.gray('─'.repeat(60)));
            console.log(taskInfo.output);
          }

          // Trigger sync to update cache
          console.log(chalk.cyan('\n📊 Syncing goals cache...'));
          await processor.processGoals('sync', { fast: true });

          // Show updated status
          const { data: updatedCache } = await processor.loadCache();
          const updatedGoal = updatedCache.goals.find(g => g.id === goal.id);

          if (updatedGoal) {
            console.log(chalk.cyan('\n📊 Updated Status:'));
            console.log(chalk.gray('─'.repeat(60)));
            console.log(`Status: ${updatedGoal.status || updatedGoal.progress?.status}`);
            console.log(`Progress: ${updatedGoal.completionPercentage || 0}%`);
            console.log(`Tasks: ${updatedGoal.tasksComplete || 0}/${updatedGoal.taskCount || 0}`);
          }
        } else {
          console.error(chalk.red('\n❌ Review failed'));
          if (taskInfo.error) {
            console.error(chalk.red(taskInfo.error));
          }
        }
      }

      if (!complete) {
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
    }

    if (!complete) {
      console.error(chalk.red('\n⏰ Review timed out'));
    }

    await client.disconnect();

  } catch (error) {
    console.error(chalk.red('Error:'), error.message);
  }
}

/**
 * Update goal status manually - ONLY updates cache with manual override
 * Does NOT modify goal files - only sync operations should edit files
 */
async function updateGoalStatus(goalId, newStatus, goalsDir) {
  const processor = createGoalsProcessor(goalsDir);
  const goalFiles = findGoalFiles(goalsDir);

  if (goalFiles.length === 0) {
    console.log(chalk.yellow('No goal files found in'), chalk.cyan(goalsDir));
    return;
  }

  // Parse goal ID - now expects goal ID from filename (e.g., 42 for "042-api.md")
  let targetFile;
  if (/^\d+$/.test(goalId)) {
    // Numeric input - treat as goal ID
    targetFile = findGoalFileById(parseInt(goalId), goalFiles);
    if (!targetFile) {
      console.log(chalk.red(`Goal ID ${goalId} not found`));
      console.log(chalk.yellow(`Available goal IDs: ${goalFiles.map(f => extractGoalId(f)).filter(id => id).join(', ')}`));
      return;
    }
  } else {
    // Filename input
    targetFile = goalFiles.find(f => basename(f) === goalId || basename(f, '.md') === goalId);
    if (!targetFile) {
      console.log(chalk.red(`Goal not found: ${goalId}`));
      return;
    }
  }

  // Status abbreviation mapping
  const statusAbbreviations = {
    'todo': 'Not Started',
    'ns': 'Not Started',
    'progress': 'In Progress',
    'ip': 'In Progress',
    'wip': 'In Progress',
    'done': 'Completed',
    'complete': 'Completed',
    'abandon': 'Abandoned',
    'cancel': 'Cancelled',
    'hold': 'On Hold',
    'pause': 'On Hold'
  };

  // Resolve abbreviation to full status
  const resolvedStatus = statusAbbreviations[newStatus.toLowerCase()] || newStatus;

  // Validate status
  if (!VALID_STATUSES.includes(resolvedStatus)) {
    console.log(chalk.red(`Invalid status: ${newStatus}`));
    console.log(chalk.yellow(`Valid statuses: ${VALID_STATUSES.join(', ')}`));
    console.log(chalk.gray(`Shortcuts: todo/ns, progress/ip/wip, done/complete, abandon, cancel, hold/pause`));
    return;
  }

  // Use resolved status from here
  newStatus = resolvedStatus;

  // Update cache ONLY - do NOT modify the goal file
  try {
    const { data: cache } = await processor.loadCache();
    if (!cache || !cache.goals) {
      console.log(chalk.red('Error Cache not found'));
      console.log(chalk.yellow(' Run: ani-code goals sync'));
      return;
    }

    const filename = basename(targetFile);
    const goalIndex = cache.goals.findIndex(g => g.file === filename);

    if (goalIndex === -1) {
      console.log(chalk.red(`Error Goal not found in cache: ${filename}`));
      console.log(chalk.yellow(' Run: ani-code goals sync'));
      return;
    }

    const now = new Date().toISOString().split('T')[0];

    // Update status and mark as manual override (minimal cache format)
    cache.goals[goalIndex].status = newStatus;
    cache.goals[goalIndex].manualOverride = true;
    cache.goals[goalIndex].manualOverrideDate = now;

    // Update dates in cache
    if (newStatus === 'In Progress' && !cache.goals[goalIndex].startDate) {
      cache.goals[goalIndex].startDate = now;
    } else if (newStatus === 'Completed' || newStatus === 'Abandoned' || newStatus === 'Cancelled') {
      cache.goals[goalIndex].completionDate = now;
    }

    // Recalculate summary
    cache.summary = calculateSummary(cache.goals, cache.totalGoals || cache.goals.length);
    cache.lastUpdated = new Date().toISOString();

    await processor.saveCache(cache);

    console.log(chalk.green('OK Goal status updated in cache'));
    console.log(chalk.gray(`  Goal: ${filename}`));
    console.log(chalk.gray(`  Status: ${newStatus}`));
    console.log(chalk.yellow('  [MANUAL] Status override set - will persist through sync'));
    console.log(chalk.dim('  Note: Goal file unchanged - only cache updated'));
  } catch (error) {
    console.error(chalk.red('Error Failed to update cache:', error.message));
  }
}

/**
 * Set provider for a goal - stores in cache, used by goalloop
 * @param {string} goalId - Goal ID or filename
 * @param {string} providerId - Provider ID (e.g., claude, copilot, opencode)
 * @param {string} goalsDir - Goals directory path
 */
async function setGoalProvider(goalId, providerId, goalsDir) {
  const processor = createGoalsProcessor(goalsDir);
  const goalFiles = findGoalFiles(goalsDir);

  if (goalFiles.length === 0) {
    console.log(chalk.yellow('No goal files found in'), chalk.cyan(goalsDir));
    return;
  }

  // Find goal by ID or filename
  let targetFile;
  const numId = parseInt(goalId);
  if (!isNaN(numId)) {
    targetFile = findGoalFileById(numId, goalFiles);
    if (!targetFile) {
      console.log(chalk.red(`Goal ID ${goalId} not found`));
      console.log(chalk.yellow(`Available goal IDs: ${goalFiles.map(f => extractGoalId(basename(f))).filter(id => id).join(', ')}`));
      return;
    }
  } else {
    targetFile = goalFiles.find(f => basename(f) === goalId || basename(f, '.md') === goalId);
    if (!targetFile) {
      console.log(chalk.red(`Goal not found: ${goalId}`));
      return;
    }
  }

  // Validate provider ID
  const providerManager = await getProviderManager();
  const availableProviders = providerManager.listProviders(true);
  const validProviderIds = availableProviders.map(p => p.id);

  // Handle clear/remove provider
  if (providerId === 'clear' || providerId === 'none' || providerId === 'remove') {
    // Remove provider from cache
    const { data: cache } = await processor.loadCache();
    if (!cache || !cache.goals) {
      console.log(chalk.red('Error: Cache not found'));
      console.log(chalk.yellow('Run: ani-code goals sync'));
      return;
    }

    const filename = basename(targetFile);
    const goalIndex = cache.goals.findIndex(g => g.file === filename);

    if (goalIndex === -1) {
      console.log(chalk.red(`Error: Goal not found in cache: ${filename}`));
      console.log(chalk.yellow('Run: ani-code goals sync'));
      return;
    }

    // Remove provider field
    delete cache.goals[goalIndex].provider;
    cache.lastUpdated = new Date().toISOString();

    await processor.saveCache(cache);

    console.log(chalk.green('OK Provider removed from goal'));
    console.log(chalk.gray(`  Goal: ${filename}`));
    console.log(chalk.gray('  Provider: (default - will use active provider)'));
    return;
  }

  // Validate provider exists
  if (!validProviderIds.includes(providerId)) {
    console.log(chalk.red(`Invalid provider: ${providerId}`));
    console.log(chalk.yellow(`Available providers: ${validProviderIds.join(', ')}`));
    return;
  }

  // Check if provider is available
  const providerInfo = availableProviders.find(p => p.id === providerId);
  if (!providerInfo.available) {
    console.log(chalk.yellow(`Warning: Provider '${providerId}' binary not found`));
    console.log(chalk.gray('  The provider may not work until the binary is installed'));
  }

  // Update cache with provider
  const { data: cache } = await processor.loadCache();
  if (!cache || !cache.goals) {
    console.log(chalk.red('Error: Cache not found'));
    console.log(chalk.yellow('Run: ani-code goals sync'));
    return;
  }

  const filename = basename(targetFile);
  const goalIndex = cache.goals.findIndex(g => g.file === filename);

  if (goalIndex === -1) {
    console.log(chalk.red(`Error: Goal not found in cache: ${filename}`));
    console.log(chalk.yellow('Run: ani-code goals sync'));
    return;
  }

  // Set provider field
  cache.goals[goalIndex].provider = providerId;
  cache.lastUpdated = new Date().toISOString();

  await processor.saveCache(cache);

  console.log(chalk.green('OK Goal provider set'));
  console.log(chalk.gray(`  Goal: ${filename}`));
  console.log(chalk.gray(`  Provider: ${providerId} (${providerInfo.name})`));
  console.log(chalk.dim('  Note: Goalloop will use @@' + providerId + ' for this goal\'s tasks'));
}

/**
 * Check goals status
 */
async function checkGoals(goalsDir, options) {
  const processor = createGoalsProcessor(goalsDir);
  const { data: cacheData } = await processor.loadCache();

  if (!cacheData || !cacheData.goals) {
    console.error(chalk.red('Error: No cache found'));
    console.log(chalk.yellow('Run sync first: ') + chalk.cyan('ani-code goals sync'));
    process.exit(1);
  }

  // Display check results
  console.log(chalk.cyan('\n✅ Goals Check'));
  console.log(chalk.gray('═'.repeat(60)));

  const summary = cacheData.summary || calculateSummary(cacheData.goals, cacheData.goals.length);
  displaySummary(summary);

  if (options.verbose && cacheData.goals) {
    console.log(chalk.cyan('\n📝 Detailed Breakdown:'));
    console.log(chalk.gray('─'.repeat(60)));

    cacheData.goals.forEach(goal => {
      const status = goal.status || goal.progress?.status;
      if (status === 'In Progress' || status === 'Not Started') {
        console.log(`\n${chalk.bold(goal.file)}`);
        console.log(`  Status: ${status}`);
        console.log(`  Progress: ${goal.completionPercentage || 0}%`);
        if (goal.taskCount > 0) {
          console.log(`  Tasks: ${goal.tasksComplete}/${goal.taskCount}`);
        }
        if (goal.phaseCount > 0) {
          console.log(`  Phases: ${goal.phasesComplete}/${goal.phaseCount}`);
        }
      }
    });
  }
}

/**
 * Create goals command
 */
export default function createGoalsCommand() {
  const goalsCommand = new Command('goals')
    .description('Manage and track project goals')
    .option('-d, --dir <directory>', 'Goals directory', 'pd/goals');

  goalsCommand
    .command('sync')
    .alias('refresh')
    .description('Analyze goal files with Claude and update cache')
    .option('--full', 'Force full resync (analyze all goals)', false)
    .option('--no-fix', 'Skip auto-fix phase', false)
    .option('--fast', 'Fast mode - skip fixes and reuse cached completed goals', false)
    .action(async (options) => {
      const goalsDir = join(process.cwd(), goalsCommand.opts().dir);
      await syncGoalsCache(goalsDir, options.full, {
        skipFix: !options.fix,
        fastMode: options.fast
      });
    });

  goalsCommand
    .command('list')
    .alias('ls')
    .description('List all goals with summary')
    .option('-r, --refresh', 'Force refresh from source files', false)
    .action(async (options) => {
      const goalsDir = join(process.cwd(), goalsCommand.opts().dir);
      await listGoals(goalsDir, options.refresh);
    });

  goalsCommand
    .command('show <goal-id>')
    .alias('view')
    .description('Show detailed information about a specific goal')
    .action(async (goalId) => {
      const goalsDir = join(process.cwd(), goalsCommand.opts().dir);
      await showGoal(goalId, goalsDir);
    });

  goalsCommand
    .command('export')
    .description('Export goals data to JSON format')
    .option('-o, --output <file>', 'Output file path')
    .action((options) => {
      const goalsDir = join(process.cwd(), goalsCommand.opts().dir);
      exportGoals(goalsDir, options.output);
    });

  goalsCommand
    .command('add [description]')
    .description('Add or update a goal with Claude\'s help')
    .option('-u, --update <goal-id>', 'Update existing goal')
    .option('-m, --merge', 'Merge with existing content', false)
    .action(async (description, options) => {
      const goalsDir = join(process.cwd(), goalsCommand.opts().dir);
      await addGoal(description, goalsDir, options);
    });

  goalsCommand
    .command('loop')
    .description('Automated goal execution loop')
    .option('-g, --goal <id>', 'Focus on specific goal')
    .option('-l, --limit <n>', 'Limit iterations', parseInt, 5)
    .option('-p, --provider <provider>', 'Specify provider (e.g., opus, glm)')
    .option('-s, --skip-validation', 'Skip validation', false)
    .action(async (options) => {
      const goalsDir = join(process.cwd(), goalsCommand.opts().dir);
      await executeGoalLoop(goalsDir, options);
    });

  goalsCommand
    .command('check')
    .description('Check goal completion status')
    .option('-v, --verbose', 'Show detailed breakdown', false)
    .action(async (options) => {
      const goalsDir = join(process.cwd(), goalsCommand.opts().dir);
      await checkGoals(goalsDir, options);
    });

  goalsCommand
    .command('update <goal-id> <status>')
    .description('Update goal status manually (use index number or filename)\n  Statuses: Not Started, In Progress, Completed, Abandoned, Cancelled, On Hold\n  Shortcuts: todo/ns, progress/ip/wip, done, abandon, cancel, hold/pause')
    .action(async (goalId, status) => {
      const goalsDir = join(process.cwd(), goalsCommand.opts().dir);
      await updateGoalStatus(goalId, status, goalsDir);
    });

  goalsCommand
    .command('review <goal-id> [concern...]')
    .alias('verify')
    .description('Review a goal to verify if completion status is accurate')
    .action(async (goalId, concernParts) => {
      const goalsDir = join(process.cwd(), goalsCommand.opts().dir);
      // Join concern parts into a single string (handles multi-word concerns)
      const userConcern = concernParts && concernParts.length > 0 ? concernParts.join(' ') : '';
      await reviewGoal(goalId, userConcern, goalsDir, {});
    });

  goalsCommand
    .command('set-provider <goal-id> <provider-id>')
    .description('Set CLI provider for a goal (used by goalloop)\n  Provider IDs: claude, copilot, opencode, gemini, codex, cursor\n  Use "clear" or "none" to remove provider setting')
    .action(async (goalId, providerId) => {
      const goalsDir = join(process.cwd(), goalsCommand.opts().dir);
      await setGoalProvider(goalId, providerId, goalsDir);
    });

  return goalsCommand;
}

// Export helper functions
export {
  findGoalFiles,
  parseGoalFile,
  generateProgressBar,
  checkGoals,
  reviewGoal
};
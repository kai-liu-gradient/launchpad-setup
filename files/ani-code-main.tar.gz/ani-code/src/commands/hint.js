import { Command } from 'commander';
import chalk from 'chalk';
import { readFileSync, existsSync } from 'fs';
import { createInterface } from 'readline';
import { HintManager } from '../hint-manager.js';

/**
 * Read input from stdin (for piped input)
 * @returns {Promise<string>} Content from stdin
 */
async function readStdin() {
  return new Promise((resolve, reject) => {
    let data = '';
    const timeout = setTimeout(() => {
      // If no data after 100ms, assume no piped input
      if (data === '') {
        resolve(null);
      }
    }, 100);

    process.stdin.setEncoding('utf8');
    process.stdin.on('data', chunk => {
      clearTimeout(timeout);
      data += chunk;
    });
    process.stdin.on('end', () => {
      clearTimeout(timeout);
      resolve(data.trim() || null);
    });
    process.stdin.on('error', err => {
      clearTimeout(timeout);
      reject(err);
    });

    // Check if stdin is a TTY (interactive terminal)
    if (process.stdin.isTTY) {
      clearTimeout(timeout);
      resolve(null);
    }
  });
}

/**
 * Prompt user for multi-line input
 * @returns {Promise<string>} User input
 */
async function promptMultilineInput() {
  return new Promise((resolve) => {
    const rl = createInterface({
      input: process.stdin,
      output: process.stdout
    });

    console.log(chalk.gray('Enter hint content (press Ctrl+D or type "EOF" on a new line to finish):'));

    let lines = [];
    rl.on('line', (line) => {
      if (line.trim().toUpperCase() === 'EOF') {
        rl.close();
      } else {
        lines.push(line);
      }
    });

    rl.on('close', () => {
      resolve(lines.join('\n').trim());
    });
  });
}

const hintCommand = new Command('hint')
  .description('Manage transient contextual hints for task iterations')
  .argument('[content...]', 'Hint content (inline)')
  .option('-f, --file <path>', 'Read hint content from file')
  .option('-l, --list', 'List all active hints')
  .option('-a, --ack <id>', 'Acknowledge/resolve a hint by ID')
  .option('--clear', 'Clear all active hints')
  .option('-w, --workspace <path>', 'Workspace path (default: current directory)')
  .addHelpText('after', `
Examples:
  $ ani-code hint "Browser console shows TypeError: undefined is not a function"
  $ ani-code hint -f error-log.txt              # Create hint from file
  $ cat console.log | ani-code hint             # Create hint from piped input
  $ ani-code hint --list                        # List all active hints
  $ ani-code hint --ack ab12                    # Acknowledge hint by ID
  $ ani-code hint --clear                       # Clear all active hints

Hints are automatically injected into subsequent task prompts and expire after 1 hour.
Use hints to provide context about runtime errors, discoveries, or environment changes.
  `)
  .action(async (content, options) => {
    try {
      const workspacePath = options.workspace || process.cwd();
      const hintManager = new HintManager(workspacePath);

      // Handle --list option
      if (options.list) {
        await listHints(hintManager);
        return;
      }

      // Handle --ack option
      if (options.ack) {
        await ackHint(hintManager, options.ack);
        return;
      }

      // Handle --clear option
      if (options.clear) {
        await clearHints(hintManager);
        return;
      }

      // Get hint content from various sources
      let hintContent = null;

      // 1. From file if specified
      if (options.file) {
        if (!existsSync(options.file)) {
          console.error(chalk.red(`File not found: ${options.file}`));
          process.exit(1);
        }
        hintContent = readFileSync(options.file, 'utf8').trim();
      }
      // 2. From inline argument
      else if (content && content.length > 0) {
        hintContent = content.join(' ').trim();
      }
      // 3. From piped stdin
      else {
        const stdinContent = await readStdin();
        if (stdinContent) {
          hintContent = stdinContent;
        }
      }

      // 4. Interactive multi-line input if no content yet and TTY
      if (!hintContent && process.stdin.isTTY) {
        hintContent = await promptMultilineInput();
      }

      // Validate we have content
      if (!hintContent) {
        console.error(chalk.red('No hint content provided'));
        console.log(chalk.gray('\nUsage:'));
        console.log(chalk.gray('  ani-code hint "your hint message"'));
        console.log(chalk.gray('  ani-code hint -f error.log'));
        console.log(chalk.gray('  cat console.log | ani-code hint'));
        process.exit(1);
      }

      // Create the hint
      await createHint(hintManager, hintContent);

    } catch (error) {
      console.error(chalk.red('Error:'), error.message);
      process.exit(1);
    }
  });

/**
 * Create a new hint
 * @param {HintManager} hintManager
 * @param {string} content
 */
async function createHint(hintManager, content) {
  const result = await hintManager.createHint(content, 'cli');

  console.log(chalk.green('✓ Hint created successfully'));
  console.log();
  console.log(chalk.gray(`  ID:      ${chalk.cyan(result.id)}`));
  console.log(chalk.gray(`  Expires: ${result.expires.toLocaleString()}`));
  console.log();

  // Show preview
  const preview = content.length > 100 ? content.substring(0, 100) + '...' : content;
  console.log(chalk.gray('  Content:'));
  console.log(chalk.white(`  ${preview.split('\n').join('\n  ')}`));
  console.log();

  console.log(chalk.gray('This hint will be injected into subsequent task prompts.'));
  console.log(chalk.gray(`To acknowledge: ani-code hint --ack ${result.id}`));
}

/**
 * List all active hints
 * @param {HintManager} hintManager
 */
async function listHints(hintManager) {
  const hints = await hintManager.getActiveHints();

  console.log(chalk.bold('\nActive Hints\n'));

  if (hints.length === 0) {
    console.log(chalk.gray('No active hints.'));
    console.log(chalk.gray('\nCreate a hint with: ani-code hint "your message"'));
    return;
  }

  hints.forEach((hint, index) => {
    console.log(chalk.cyan(`[${hint.id}]`) + chalk.gray(` - ${hint.ageText} (expires: ${hint.expires.toLocaleTimeString()})`));

    // Show preview
    const preview = hint.content.length > 80 ? hint.content.substring(0, 80) + '...' : hint.content;
    const lines = preview.split('\n');
    lines.forEach((line, i) => {
      if (i === 0) {
        console.log(chalk.white(`  ${line}`));
      } else if (i < 3) {
        console.log(chalk.gray(`  ${line}`));
      }
    });

    if (index < hints.length - 1) {
      console.log();
    }
  });

  console.log(chalk.gray(`\n${hints.length} active hint(s)`));
  console.log(chalk.gray('To acknowledge: ani-code hint --ack <id>'));
  console.log(chalk.gray('To clear all:   ani-code hint --clear'));
}

/**
 * Acknowledge a hint
 * @param {HintManager} hintManager
 * @param {string} hintId
 */
async function ackHint(hintManager, hintId) {
  const success = await hintManager.ackHint(hintId);

  if (success) {
    console.log(chalk.green(`✓ Hint ${hintId} acknowledged`));
    console.log(chalk.gray('The hint will no longer be injected into task prompts.'));
  } else {
    console.error(chalk.red(`Hint ${hintId} not found`));
    console.log(chalk.gray('Use "ani-code hint --list" to see active hints.'));
    process.exit(1);
  }
}

/**
 * Clear all active hints
 * @param {HintManager} hintManager
 */
async function clearHints(hintManager) {
  const count = await hintManager.clearHints();

  if (count > 0) {
    console.log(chalk.green(`✓ Cleared ${count} hint(s)`));
  } else {
    console.log(chalk.gray('No active hints to clear.'));
  }
}

export default hintCommand;

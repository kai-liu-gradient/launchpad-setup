#!/usr/bin/env node

import crypto from 'crypto';
import { promises as fs } from 'fs';
import path from 'path';
import os from 'os';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';

// Get the directory of this plugin.js file
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load .env from the ani-code project root directory
const envPath = path.resolve(__dirname, '..', '..', '.env');
dotenv.config({ path: envPath });

class PluginCommand {
  constructor() {
    this.tokenFile = path.join(os.homedir(), '.anicode', 'plugin-tokens.json');
  }

  async execute(args) {
    const command = args[0];
    
    switch (command) {
      case '--new-token':
      case 'new-token':
        return await this.generateToken();
      
      case '--list':
      case 'list':
        return await this.listTokens();
      
      case '--revoke':
      case 'revoke':
        return await this.revokeToken(args[1]);
      
      case '--revoke-all':
      case 'revoke-all':
        return await this.revokeAllTokens();
      
      case '--help':
      case 'help':
      default:
        return this.showHelp();
    }
  }

  async generateToken() {
    try {
      // Get current project info
      const projectPath = process.cwd();
      const projectName = path.basename(projectPath);
      
      // Determine server URL from environment or config
      const serverUrl = process.env.ANICODE_PLUGIN_URL || 'ws://localhost:6502/socket';
      
      // Generate secure token with optional seed
      const tokenSeed = process.env.ANICODE_TOKEN_SEED || os.hostname();
      const seedHash = crypto.createHash('sha256').update(tokenSeed + Date.now()).digest();
      const tokenId = crypto.createHash('md5').update(seedHash).digest('hex').substring(0, 32);
      const secret = crypto.randomBytes(32).toString('hex');
      
      // Create token payload
      const payload = {
        id: tokenId,
        project: projectName,
        projectPath: projectPath,
        serverUrl: serverUrl,
        createdAt: Date.now(),
        expiresAt: Date.now() + (7 * 24 * 60 * 60 * 1000), // 7 days
        hostname: os.hostname(),
        user: os.userInfo().username
      };
      
      // Encode payload with secret
      const encodedPayload = Buffer.from(JSON.stringify(payload)).toString('base64');
      const signature = crypto
        .createHmac('sha256', secret)
        .update(encodedPayload)
        .digest('hex');
      
      // Create final token (payload.signature.secret)
      const token = `${encodedPayload}.${signature}.${secret}`;
      
      // Save token locally for validation
      await this.saveToken(tokenId, payload, secret);
      
      // Create the connection config for Chrome extension
      const connectionConfig = {
        project: projectName,
        url: serverUrl,
        token: token
      };
      
      // Encode the config for easy copy/paste
      const encodedConfig = Buffer.from(JSON.stringify(connectionConfig)).toString('base64');
      
      // Display token and instructions
      console.log('\n' + '='.repeat(60));
      console.log('🔐 Chrome Plugin Connection Token Generated');
      console.log('='.repeat(60));
      console.log();
      console.log('Project:    ', projectName);
      console.log('Path:       ', projectPath);
      console.log('Server:     ', serverUrl);
      console.log('Expires:    ', new Date(payload.expiresAt).toLocaleString());
      console.log();
      console.log('📋 Copy this token to your Chrome plugin:');
      console.log();
      console.log('─'.repeat(60));
      console.log(encodedConfig);
      console.log('─'.repeat(60));
      console.log();
      console.log('Instructions:');
      console.log('1. Click the AniCode extension icon in Chrome');
      console.log('2. Paste the token above in the "Connection Token" field');
      console.log('3. Click "Connect" to establish connection');
      console.log();
      console.log('Note: The extension accepts both this encoded format and raw JWT tokens');
      console.log();
      console.log('⚠️  This token expires in 7 days');
      console.log('⚠️  Keep this token secure - it provides access to your project');
      console.log();
      
      // Show debug info if requested
      if (process.env.DEBUG || process.argv.includes('--debug')) {
        console.log('Debug Information:');
        console.log('─'.repeat(60));
        console.log('Raw token (for manual testing):');
        console.log(token);
        console.log();
        console.log('Decoded config:');
        console.log(JSON.stringify(connectionConfig, null, 2));
        console.log('─'.repeat(60));
        console.log();
      }
      
      return encodedConfig;
    } catch (error) {
      console.error('Failed to generate token:', error);
      process.exit(1);
    }
  }

  async saveToken(tokenId, payload, secret) {
    try {
      // Ensure directory exists
      const dir = path.dirname(this.tokenFile);
      await fs.mkdir(dir, { recursive: true });
      
      // Load existing tokens
      let tokens = {};
      try {
        const data = await fs.readFile(this.tokenFile, 'utf8');
        tokens = JSON.parse(data);
      } catch (e) {
        // File doesn't exist yet
      }
      
      // Add new token
      tokens[tokenId] = {
        ...payload,
        secretHash: crypto.createHash('sha256').update(secret).digest('hex')
      };
      
      // Save tokens
      await fs.writeFile(this.tokenFile, JSON.stringify(tokens, null, 2));
    } catch (error) {
      console.error('Failed to save token:', error);
    }
  }

  async listTokens() {
    try {
      const data = await fs.readFile(this.tokenFile, 'utf8');
      const tokens = JSON.parse(data);
      
      console.log('\n📋 Active Plugin Tokens:');
      console.log('─'.repeat(60));
      
      const now = Date.now();
      let hasTokens = false;
      
      for (const [id, token] of Object.entries(tokens)) {
        hasTokens = true;
        const expired = now > token.expiresAt;
        const status = expired ? '❌ EXPIRED' : '✅ ACTIVE';
        
        console.log(`\nToken ID:    ${id.substring(0, 8)}...`);
        console.log(`Project:     ${token.project}`);
        console.log(`Path:        ${token.projectPath}`);
        console.log(`Created:     ${new Date(token.createdAt).toLocaleString()}`);
        console.log(`Expires:     ${new Date(token.expiresAt).toLocaleString()}`);
        console.log(`Status:      ${status}`);
      }
      
      if (!hasTokens) {
        console.log('No tokens found. Use "plugin new-token" to generate one.');
      }
      
      console.log('\n' + '─'.repeat(60));
      
      // Clean expired tokens
      await this.cleanExpiredTokens(tokens);
      
    } catch (error) {
      if (error.code === 'ENOENT') {
        console.log('No tokens found. Use "plugin new-token" to generate one.');
      } else {
        console.error('Failed to list tokens:', error);
      }
    }
  }

  async revokeToken(tokenId) {
    if (!tokenId) {
      console.error('Please provide a token ID to revoke');
      console.log('Usage: plugin revoke <token-id>');
      return;
    }
    
    try {
      const data = await fs.readFile(this.tokenFile, 'utf8');
      const tokens = JSON.parse(data);
      
      // Find token by partial ID
      let fullTokenId = null;
      for (const id of Object.keys(tokens)) {
        if (id.startsWith(tokenId)) {
          fullTokenId = id;
          break;
        }
      }
      
      if (!fullTokenId) {
        console.error(`Token not found: ${tokenId}`);
        return;
      }
      
      const token = tokens[fullTokenId];
      delete tokens[fullTokenId];
      
      await fs.writeFile(this.tokenFile, JSON.stringify(tokens, null, 2));
      
      console.log(`✅ Token revoked for project: ${token.project}`);
    } catch (error) {
      console.error('Failed to revoke token:', error);
    }
  }

  async revokeAllTokens() {
    try {
      // Get current project info
      const currentProject = await this.detectProject();
      const projectPath = currentProject.path;
      
      const data = await fs.readFile(this.tokenFile, 'utf8');
      const tokens = JSON.parse(data);
      
      // Filter tokens for the current workspace
      const workspaceTokens = Object.entries(tokens).filter(([id, token]) => {
        return token.projectPath === projectPath;
      });
      
      if (workspaceTokens.length === 0) {
        console.log('No tokens to revoke for current workspace.');
        return;
      }
      
      // Remove only workspace tokens
      for (const [id, token] of workspaceTokens) {
        delete tokens[id];
      }
      
      await fs.writeFile(this.tokenFile, JSON.stringify(tokens, null, 2));
      
      const count = workspaceTokens.length;
      console.log(`✅ Workspace tokens revoked (${count} token${count > 1 ? 's' : ''} removed)`);
      console.log(`Chrome plugin connections for ${currentProject.name} have been invalidated.`);
    } catch (error) {
      if (error.code === 'ENOENT') {
        console.log('No tokens to revoke.');
      } else {
        console.error('Failed to revoke workspace tokens:', error);
      }
    }
  }

  async cleanExpiredTokens(tokens) {
    const now = Date.now();
    let cleaned = false;
    
    for (const [id, token] of Object.entries(tokens)) {
      if (now > token.expiresAt) {
        delete tokens[id];
        cleaned = true;
      }
    }
    
    if (cleaned) {
      await fs.writeFile(this.tokenFile, JSON.stringify(tokens, null, 2));
    }
  }

  validateToken(tokenString) {
    try {
      const [encodedPayload, signature, secret] = tokenString.split('.');
      
      if (!encodedPayload || !signature || !secret) {
        return { valid: false, error: 'Invalid token format' };
      }
      
      // Verify signature
      const expectedSignature = crypto
        .createHmac('sha256', secret)
        .update(encodedPayload)
        .digest('hex');
      
      if (signature !== expectedSignature) {
        return { valid: false, error: 'Invalid token signature' };
      }
      
      // Decode payload
      const payload = JSON.parse(Buffer.from(encodedPayload, 'base64').toString());
      
      // Check expiry
      if (Date.now() > payload.expiresAt) {
        return { valid: false, error: 'Token expired' };
      }
      
      return { valid: true, payload };
    } catch (error) {
      return { valid: false, error: error.message };
    }
  }

  showHelp() {
    console.log(`
AniCode Chrome Plugin Token Management

Usage: anicode plugin <command> [options]

Commands:
  new-token    Generate a new connection token for Chrome plugin
  list         List all active tokens
  revoke <id>  Revoke a specific token
  revoke-all   Revoke all active tokens
  help         Show this help message

Examples:
  anicode plugin new-token     # Generate new token for current project
  anicode plugin list          # List all tokens
  anicode plugin revoke abc123 # Revoke token starting with abc123
  anicode plugin revoke-all   # Revoke all tokens

Environment Variables:
  ANICODE_PLUGIN_URL    WebSocket URL for plugin connections (default: ws://localhost:6502)
  ANICODE_TOKEN_SEED    Seed for token generation (default: hostname)

Notes:
  - Tokens expire after 7 days for security
  - Each token is tied to a specific project directory
  - Copy the entire token string to Chrome plugin for connection
    `);
  }
}

// Export for use in main CLI
export default PluginCommand;

// Allow direct execution
if (import.meta.url === `file://${process.argv[1]}`) {
  const command = new PluginCommand();
  command.execute(process.argv.slice(2));
}
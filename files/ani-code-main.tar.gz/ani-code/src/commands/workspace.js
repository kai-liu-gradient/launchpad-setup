import { Command } from 'commander';
import chalk from 'chalk';
import { WorkspaceManager } from '../workspace-manager.js';
import { logger } from '../logger.js';
import { isValidModel, normalizeModel, createInvalidModelError } from '../model-utils.js';
import Table from 'cli-table3';
import readline from 'readline';
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import { execSync, spawn } from 'child_process';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const workspaceCommand = new Command('workspace')
  .description('Manage workspaces and access tokens')
  .configureHelp({ 
    sortSubcommands: true,
    subcommandTerm: (cmd) => cmd.name() + (cmd.alias() ? ` (${cmd.alias()})` : '')
  })
  .addHelpText('after', `
${chalk.bold('Quick Start:')}
  ${chalk.cyan('workspace create <name>')}     Create workspace in current dir
  ${chalk.cyan('workspace list')}              List all workspaces  
  ${chalk.cyan('workspace token gen')}         Generate token for current workspace
  ${chalk.cyan('workspace info')}              Show current workspace info
  ${chalk.cyan('workspace chat show')}         Show chat-workspace connections

${chalk.bold('Connecting Lark Chat:')}
  ${chalk.gray('# 1. Generate a token for your workspace')}
  $ ani-code workspace token gen my-project -n "Lark Bot"

  ${chalk.gray('# 2. In Lark, connect using the token')}
  @ AniCode Bot: /connect <token>

  ${chalk.gray('# 3. Verify the connection')}
  $ ani-code workspace chat show

${chalk.bold('Examples:')}
  ${chalk.gray('# Create workspace for current project')}
  $ ani-code workspace create my-project

  ${chalk.gray('# Generate token (from within workspace dir)')}
  $ cd /path/to/workspace
  $ ani-code workspace token gen -n "Lark Connection"

  ${chalk.gray('# View all chat connections')}
  $ ani-code workspace chat show
`);

// Helper to format date
function formatDate(dateStr) {
  if (!dateStr) return 'Never';
  const date = new Date(dateStr);
  return date.toLocaleString();
}

// Helper to format permissions
function formatPermissions(permissions) {
  if (typeof permissions === 'string') {
    try {
      permissions = JSON.parse(permissions);
    } catch {
      return permissions;
    }
  }
  return Array.isArray(permissions) ? permissions.join(', ') : 'none';
}

// Initialize workspace manager
async function getWorkspaceManager() {
  const manager = new WorkspaceManager();
  await manager.initialize();
  return manager;
}

// Create workspace command
workspaceCommand
  .command('create [name]')
  .description('Create workspace with access token')
  .option('-p, --path <path>', 'Directory path (default: current)')
  .option('-d, --description <desc>', 'Description')
  .option('-f, --force', 'Force create by deleting existing workspace with same name')
  .action(async (name, options) => {
    try {
      const manager = await getWorkspaceManager();
      const workspacePath = options.path || process.cwd();
      
      // If no name provided, ask if user wants to use current directory name
      if (!name) {
        const currentDirName = path.basename(workspacePath);
        
        const rl = readline.createInterface({
          input: process.stdin,
          output: process.stdout
        });
        
        const answer = await new Promise((resolve) => {
          rl.question(chalk.cyan(`No workspace name provided. Use current directory name "${currentDirName}"? (yes/no): `), resolve);
        });
        
        if (answer.toLowerCase() === 'yes' || answer.toLowerCase() === 'y') {
          name = currentDirName;
        } else {
          const customName = await new Promise((resolve) => {
            rl.question(chalk.cyan('Enter workspace name: '), resolve);
          });
          name = customName.trim();
        }
        
        rl.close();
        
        if (!name) {
          console.error(chalk.red('Workspace name is required'));
          await manager.close();
          process.exit(1);
        }
      }
      
      // Handle force flag - delete existing workspace if it exists
      if (options.force) {
        try {
          // Check for any workspace with this name (active or inactive)
          const existingWorkspace = await manager.getAnyWorkspace(name);
          if (existingWorkspace) {
            console.log(chalk.yellow(`Found existing workspace: ${name} (active: ${existingWorkspace.is_active})`));
            // Use force delete by name to ensure all related data is cleaned up
            const deleted = await manager.forceDeleteByName(name);
            if (deleted) {
              console.log(chalk.green(`✓ Force deleted workspace and all related data`));
            }
          } else {
            // Even if not found, try force delete in case of orphaned entries
            const deleted = await manager.forceDeleteByName(name);
            if (deleted) {
              console.log(chalk.green(`✓ Removed orphaned workspace entry: ${name}`));
            }
          }
        } catch (error) {
          console.log(chalk.yellow(`Warning during force delete: ${error.message}`));
          // Continue anyway since we're forcing
        }
      }
      
      // Try to create workspace, handle constraint errors with force logic
      let workspace;
      try {
        workspace = await manager.createWorkspace(
          name,
          workspacePath,
          options.description
        );
      } catch (error) {
        // If we get a unique constraint error and force flag is set, try harder
        if (error.message.includes('UNIQUE constraint failed') && options.force) {
          console.log(chalk.yellow(`Workspace "${name}" exists but wasn't detected. Force removing...`));
          const deleted = await manager.forceDeleteByName(name);
          if (deleted) {
            console.log(chalk.green(`✓ Removed conflicting workspace entry`));
            // Try creating again after force delete
            workspace = await manager.createWorkspace(
              name,
              workspacePath,
              options.description
            );
          } else {
            throw error; // Re-throw if we couldn't delete
          }
        } else {
          throw error; // Re-throw if not a constraint error or no force flag
        }
      }
      
      console.log(chalk.green(`✓ Created workspace: ${workspace.name}`));
      console.log(chalk.gray(`  ID: ${workspace.id}`));
      console.log(chalk.gray(`  Path: ${workspace.path}`));
      
      // Generate initial token
      console.log(chalk.yellow('\nGenerating access token...'));
      const tokenData = await manager.generateToken(
        workspace.id,
        'Initial token',
        'api',
        ['read', 'write'],
        null // No expiration
      );
      
      console.log(chalk.green('\n✓ Access token generated:'));
      console.log(chalk.cyan(`  ${tokenData.token}`));
      console.log(chalk.gray('\n  Save this token securely. It won\'t be shown again.'));

      // Register with gateway if enabled
      const { gatewayRegistration } = await import('../services/gatewayRegistration.js');
      if (gatewayRegistration.isEnabled()) {
        console.log(chalk.yellow('\nRegistering with gateway...'));
        const gatewayResult = await gatewayRegistration.registerToken(
          tokenData.token,
          workspace.name,
          { description: options.description }
        );

        if (gatewayResult) {
          console.log(chalk.green('✓ Registered with gateway'));
          console.log(chalk.cyan(`  Gateway Token: ${gatewayResult.gatewayToken}`));
          console.log(chalk.gray('\n  Telegram users should use: /start ' + gatewayResult.gatewayToken));
        } else {
          console.log(chalk.yellow('⚠ Gateway registration failed (non-critical)'));
        }
      }

      await manager.close();
    } catch (error) {
      console.error(chalk.red(`Failed to create workspace: ${error.message}`));
      process.exit(1);
    }
  });

// List workspaces command
workspaceCommand
  .command('list')
  .alias('ls')
  .description('List workspaces')
  .option('-a, --all', 'Include inactive')
  .option('-v, --verbose', 'Detailed view')
  .action(async (options) => {
    try {
      const manager = await getWorkspaceManager();
      const workspaces = await manager.listWorkspaces(options.all);
      
      if (workspaces.length === 0) {
        console.log(chalk.yellow('No workspaces found.'));
        await manager.close();
        return;
      }
      
      if (options.verbose) {
        const table = new Table({
          head: ['Name', 'ID', 'Path', 'Active', 'Created', 'Updated'],
          style: { head: ['cyan'] }
        });
        
        for (const ws of workspaces) {
          table.push([
            ws.name,
            ws.id.substring(0, 8) + '...',
            ws.path,
            ws.is_active ? chalk.green('Yes') : chalk.red('No'),
            formatDate(ws.created_at),
            formatDate(ws.updated_at)
          ]);
        }
        
        console.log(table.toString());
      } else {
        console.log(chalk.blue.bold('\nWorkspaces:'));
        for (const ws of workspaces) {
          const status = ws.is_active ? chalk.green('[Active]') : chalk.red('[Inactive]');
          console.log(`  ${chalk.green(ws.name)} ${status} - ${ws.path}`);
          if (ws.description) {
            console.log(chalk.gray(`    ${ws.description}`));
          }
        }
      }
      
      await manager.close();
    } catch (error) {
      console.error(chalk.red(`Failed to list workspaces: ${error.message}`));
      process.exit(1);
    }
  });

// Get workspace details
workspaceCommand
  .command('info [name-or-id]')
  .description('Show workspace details (uses current if not specified)')
  .action(async (nameOrId) => {
    try {
      const manager = await getWorkspaceManager();
      
      // If no workspace specified, try to use current directory's workspace
      if (!nameOrId) {
        const currentWorkspace = await manager.getCurrentWorkspace();
        if (!currentWorkspace) {
          console.error(chalk.red('No workspace specified and not in a workspace directory'));
          await manager.close();
          return;
        }
        nameOrId = currentWorkspace.id;
      }
      
      const workspace = await manager.getWorkspace(nameOrId);
      
      if (!workspace) {
        console.log(chalk.red(`Workspace not found: ${nameOrId}`));
        await manager.close();
        return;
      }
      
      console.log(chalk.blue.bold('\nWorkspace Details:'));
      console.log(`  ${chalk.cyan('Name:')} ${workspace.name}`);
      console.log(`  ${chalk.cyan('ID:')} ${workspace.id}`);
      console.log(`  ${chalk.cyan('Path:')} ${workspace.path}`);
      console.log(`  ${chalk.cyan('Active:')} ${workspace.is_active ? chalk.green('Yes') : chalk.red('No')}`);
      console.log(`  ${chalk.cyan('Created:')} ${formatDate(workspace.created_at)}`);
      console.log(`  ${chalk.cyan('Updated:')} ${formatDate(workspace.updated_at)}`);
      
      if (workspace.description) {
        console.log(`  ${chalk.cyan('Description:')} ${workspace.description}`);
      }
      
      // Show active tokens
      const tokens = await manager.listTokens(workspace.id);
      if (tokens.length > 0) {
        console.log(chalk.blue.bold('\nActive Tokens:'));
        for (const token of tokens) {
          const name = token.name || 'Unnamed';
          const expires = token.expires_at ? ` (expires: ${formatDate(token.expires_at)})` : '';
          console.log(`  - ${name} [${token.type}]${expires}`);
          console.log(chalk.gray(`    ID: ${token.id}`));
          console.log(chalk.gray(`    Permissions: ${formatPermissions(token.permissions)}`));
          if (token.last_used_at) {
            console.log(chalk.gray(`    Last used: ${formatDate(token.last_used_at)}`));
          }
        }
      } else {
        console.log(chalk.yellow('\nNo active tokens.'));
      }
      
      // Show active connections
      const connections = await manager.getActiveConnections(workspace.id);
      if (connections.length > 0) {
        console.log(chalk.blue.bold('\nActive Connections:'));
        for (const conn of connections) {
          console.log(`  - Connection ${conn.id.substring(0, 8)}...`);
          console.log(chalk.gray(`    Connected: ${formatDate(conn.connected_at)}`));
          if (conn.client_info) {
            console.log(chalk.gray(`    Client: ${JSON.stringify(conn.client_info)}`));
          }
        }
      }
      
      await manager.close();
    } catch (error) {
      console.error(chalk.red(`Failed to get workspace info: ${error.message}`));
      process.exit(1);
    }
  });

// Update workspace
workspaceCommand
  .command('update [name-or-id]')
  .description('Update workspace (uses current if not specified)')
  .option('-n, --name <name>', 'New name')
  .option('-d, --description <desc>', 'New description')
  .option('-p, --path <path>', 'New path')
  .action(async (nameOrId, options) => {
    try {
      const manager = await getWorkspaceManager();
      
      // If no workspace specified, try to use current directory's workspace
      if (!nameOrId) {
        const currentWorkspace = await manager.getCurrentWorkspace();
        if (!currentWorkspace) {
          console.error(chalk.red('No workspace specified and not in a workspace directory'));
          await manager.close();
          return;
        }
        nameOrId = currentWorkspace.id;
        console.log(chalk.gray(`Updating workspace: ${currentWorkspace.name}`));
      }
      
      const updates = {};
      if (options.name) updates.name = options.name;
      if (options.description) updates.description = options.description;
      if (options.path) updates.path = path.resolve(options.path);
      
      if (Object.keys(updates).length === 0) {
        console.log(chalk.yellow('No updates specified.'));
        await manager.close();
        return;
      }
      
      const success = await manager.updateWorkspace(nameOrId, updates);
      
      if (success) {
        console.log(chalk.green(`✓ Workspace updated successfully`));
      } else {
        console.log(chalk.red(`Failed to update workspace`));
      }
      
      await manager.close();
    } catch (error) {
      console.error(chalk.red(`Failed to update workspace: ${error.message}`));
      process.exit(1);
    }
  });

// Delete workspace
workspaceCommand
  .command('delete <name-or-id>')
  .alias('rm')
  .description('Delete workspace')
  .option('-f, --force', 'Skip confirmation')
  .action(async (nameOrId, options) => {
    try {
      const manager = await getWorkspaceManager();
      
      if (!options.force) {
        const rl = readline.createInterface({
          input: process.stdin,
          output: process.stdout
        });
        
        const answer = await new Promise((resolve) => {
          rl.question(chalk.yellow(`Are you sure you want to delete workspace "${nameOrId}"? (yes/no): `), resolve);
        });
        rl.close();
        
        if (answer.toLowerCase() !== 'yes' && answer.toLowerCase() !== 'y') {
          console.log(chalk.gray('Operation cancelled.'));
          await manager.close();
          return;
        }
      }
      
      const success = await manager.deleteWorkspace(nameOrId);
      
      if (success) {
        console.log(chalk.green(`✓ Workspace deleted successfully`));
      } else {
        console.log(chalk.red(`Failed to delete workspace`));
      }
      
      await manager.close();
    } catch (error) {
      console.error(chalk.red(`Failed to delete workspace: ${error.message}`));
      process.exit(1);
    }
  });

// Token management subcommands
const tokenCommand = workspaceCommand
  .command('token')
  .alias('t')
  .description('Manage access tokens')
  .addHelpText('after', `
${chalk.bold('Common token operations:')}
  ${chalk.cyan('token gen')}         Generate token (current workspace)
  ${chalk.cyan('token list')}        List tokens (current workspace)
  ${chalk.cyan('token revoke <id>')} Revoke a token (supports prefix matching)

${chalk.gray('Note: Commands auto-detect current workspace when not specified')}
`);

// Generate token
tokenCommand
  .command('generate [workspace]')
  .alias('gen')
  .description('Generate access token (uses current workspace if not specified)')
  .option('-n, --name <name>', 'Token name')
  .option('-t, --type <type>', 'Type: api|plugin|cli', 'api')
  .option('-p, --permissions <perms>', 'Permissions', 'read,write')
  .option('-e, --expires <days>', 'Expires in days')
  .action(async (workspace, options) => {
    try {
      const manager = await getWorkspaceManager();
      
      // If no workspace specified, try to use current directory's workspace
      if (!workspace) {
        const currentWorkspace = await manager.getCurrentWorkspace();
        if (!currentWorkspace) {
          console.error(chalk.red('No workspace specified and not in a workspace directory'));
          console.log(chalk.yellow('Hint: Run this command from a workspace directory or specify workspace name'));
          await manager.close();
          return;
        }
        workspace = currentWorkspace.id;
        console.log(chalk.gray(`Using workspace: ${currentWorkspace.name}`));
      }
      
      const permissions = options.permissions.split(',').map(p => p.trim());
      const expiresInDays = options.expires ? parseInt(options.expires) : null;
      
      const tokenData = await manager.generateToken(
        workspace,
        options.name,
        options.type,
        permissions,
        expiresInDays
      );
      
      console.log(chalk.green('\n✓ Token generated successfully:'));
      console.log(chalk.cyan(`  ${tokenData.token}`));
      console.log(chalk.gray('\n  Token details:'));
      console.log(chalk.gray(`    ID: ${tokenData.id}`));
      console.log(chalk.gray(`    Workspace: ${tokenData.workspace_name}`));
      console.log(chalk.gray(`    Type: ${tokenData.type}`));
      console.log(chalk.gray(`    Permissions: ${tokenData.permissions.join(', ')}`));
      if (tokenData.expires_at) {
        console.log(chalk.gray(`    Expires: ${formatDate(tokenData.expires_at)}`));
      }
      console.log(chalk.yellow('\n  Save this token securely. It won\'t be shown again.'));

      // Register with gateway if enabled
      const { gatewayRegistration } = await import('../services/gatewayRegistration.js');
      if (gatewayRegistration.isEnabled()) {
        console.log(chalk.yellow('\nRegistering with gateway...'));
        const gatewayResult = await gatewayRegistration.registerToken(
          tokenData.token,
          tokenData.workspace_name,
          {
            description: options.name,
            owner: options.type
          }
        );

        if (gatewayResult) {
          console.log(chalk.green('✓ Registered with gateway'));
          console.log(chalk.cyan(`  Gateway Token: ${gatewayResult.gatewayToken}`));
          console.log(chalk.gray('\n  For Telegram: /start ' + gatewayResult.gatewayToken));
          if (gatewayResult.webhookUrl) {
            console.log(chalk.gray(`  Webhook URL: ${gatewayResult.webhookUrl}`));
          }
        } else {
          console.log(chalk.yellow('⚠ Gateway registration failed (non-critical)'));
          console.log(chalk.gray('  Token is still valid for direct connections'));
        }
      }

      await manager.close();
    } catch (error) {
      console.error(chalk.red(`Failed to generate token: ${error.message}`));
      process.exit(1);
    }
  });

// List tokens
tokenCommand
  .command('list [workspace]')
  .alias('ls')
  .description('List tokens (current workspace if not specified)')
  .action(async (workspace) => {
    try {
      const manager = await getWorkspaceManager();
      
      // If no workspace specified, try to use current directory's workspace
      if (!workspace) {
        const currentWorkspace = await manager.getCurrentWorkspace();
        if (currentWorkspace) {
          workspace = currentWorkspace.id;
          console.log(chalk.gray(`Showing tokens for workspace: ${currentWorkspace.name}\n`));
        }
      }
      
      const tokens = await manager.listTokens(workspace);
      
      if (tokens.length === 0) {
        console.log(chalk.yellow('No tokens found.'));
        await manager.close();
        return;
      }
      
      const table = new Table({
        head: ['ID', 'Name', 'Workspace', 'Type', 'Permissions', 'Last Used', 'Expires'],
        style: { head: ['cyan'] }
      });
      
      for (const token of tokens) {
        table.push([
          token.id,
          token.name || 'Unnamed',
          token.workspace_name,
          token.type,
          formatPermissions(token.permissions),
          formatDate(token.last_used_at),
          formatDate(token.expires_at)
        ]);
      }
      
      console.log(table.toString());
      await manager.close();
    } catch (error) {
      console.error(chalk.red(`Failed to list tokens: ${error.message}`));
      process.exit(1);
    }
  });

// Validate token
tokenCommand
  .command('validate <token>')
  .alias('check')
  .description('Validate token')
  .action(async (token) => {
    try {
      const manager = await getWorkspaceManager();
      const result = await manager.validateToken(token);
      
      if (result.valid) {
        console.log(chalk.green('✓ Token is valid'));
        console.log(chalk.gray('  Token details:'));
        console.log(chalk.gray(`    Token ID: ${result.token_id}`));
        console.log(chalk.gray(`    Workspace: ${result.workspace_name} (${result.workspace_id})`));
        console.log(chalk.gray(`    Path: ${result.workspace_path}`));
        console.log(chalk.gray(`    Type: ${result.type}`));
        console.log(chalk.gray(`    Permissions: ${result.permissions.join(', ')}`));
      } else {
        console.log(chalk.red(`✗ Token is invalid: ${result.error}`));
      }
      
      await manager.close();
    } catch (error) {
      console.error(chalk.red(`Failed to validate token: ${error.message}`));
      process.exit(1);
    }
  });

// Revoke token
tokenCommand
  .command('revoke <token-id>')
  .alias('rm')
  .description('Revoke token (supports ID prefix matching)')
  .action(async (tokenId) => {
    try {
      const manager = await getWorkspaceManager();
      const success = await manager.revokeToken(tokenId);
      
      if (success) {
        console.log(chalk.green(`✓ Token revoked successfully`));
      } else {
        console.log(chalk.red(`Failed to revoke token (not found or already revoked)`));
      }
      
      await manager.close();
    } catch (error) {
      console.error(chalk.red(`Failed to revoke token: ${error.message}`));
      process.exit(1);
    }
  });

// Chat mapping subcommands
const chatCommand = workspaceCommand
  .command('chat')
  .description('View chat-workspace mappings')
  .addHelpText('after', `
${chalk.bold('Note:')} Chat mappings are created automatically when you use the /connect command in Lark.

${chalk.bold('How to connect a Lark chat:')}
  1. Generate a token: ${chalk.cyan('ani-code workspace token gen <workspace-name>')}
  2. In Lark, use: ${chalk.cyan('/connect <token>')}
  3. The chat will be automatically linked to the workspace
`);

// Show chat mappings
chatCommand
  .command('show')
  .alias('list')
  .alias('ls')
  .description('Show all chat-workspace mappings')
  .action(async () => {
    try {
      const manager = await getWorkspaceManager();
      const mappings = await manager.getChatWorkspaceMappings();
      
      if (mappings.length === 0) {
        console.log(chalk.yellow('No chat mappings found.'));
        await manager.close();
        return;
      }
      
      const table = new Table({
        head: ['Chat ID', 'Workspace', 'Path', 'Created'],
        style: { head: ['cyan'] }
      });
      
      for (const mapping of mappings) {
        table.push([
          mapping.chat_id,
          mapping.workspace_name,
          mapping.workspace_path,
          formatDate(mapping.created_at)
        ]);
      }
      
      console.log(table.toString());
      await manager.close();
    } catch (error) {
      console.error(chalk.red(`Failed to list chat mappings: ${error.message}`));
      process.exit(1);
    }
  });

// Migration command
workspaceCommand
  .command('migrate')
  .description('Migrate from legacy settings')
  .option('-f, --file <path>', 'Settings file path')
  .action(async (options) => {
    try {
      const manager = await getWorkspaceManager();
      
      // Try to find the chat settings file
      let settingsPath = options.file;
      if (!settingsPath) {
        const aniCodeRoot = path.resolve(path.dirname(new URL(import.meta.url).pathname), '../..');
        settingsPath = path.join(aniCodeRoot, '.ani-code-chat-settings.json');
      }
      
      // Check if file exists
      try {
        await fs.access(settingsPath);
      } catch {
        console.log(chalk.yellow(`Chat settings file not found: ${settingsPath}`));
        await manager.close();
        return;
      }
      
      console.log(chalk.blue(`Migrating from ${settingsPath}...`));
      const count = await manager.migrateFromChatSettings(settingsPath);
      
      console.log(chalk.green(`✓ Successfully migrated ${count} chat-workspace mappings`));
      
      await manager.close();
    } catch (error) {
      console.error(chalk.red(`Migration failed: ${error.message}`));
      process.exit(1);
    }
  });

// Clear chat associations command
workspaceCommand
  .command('clear-chats <name-or-id>')
  .description('Clear all chat associations for a workspace')
  .action(async (nameOrId) => {
    try {
      const manager = await getWorkspaceManager();
      
      // Ask for confirmation
      const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
      });
      
      const answer = await new Promise((resolve) => {
        rl.question(chalk.yellow(`Are you sure you want to clear all chat associations for workspace "${nameOrId}"? (yes/no): `), resolve);
      });
      
      rl.close();
      
      if (answer.toLowerCase() !== 'yes' && answer.toLowerCase() !== 'y') {
        console.log(chalk.gray('Operation cancelled'));
        await manager.close();
        return;
      }
      
      const count = await manager.clearChatAssociations(nameOrId);
      
      if (count > 0) {
        console.log(chalk.green(`✓ Cleared ${count} chat association(s) for workspace "${nameOrId}"`));
        console.log(chalk.gray('Chats will need to reconnect using /connect command'));
      } else {
        console.log(chalk.yellow(`No chat associations found for workspace "${nameOrId}"`));
      }
      
      await manager.close();
    } catch (error) {
      console.error(chalk.red(`Failed to clear chat associations: ${error.message}`));
      process.exit(1);
    }
  });

// Metadata management command
workspaceCommand
  .command('meta <action> [key] [value...]')
  .description('Manage workspace metadata (homepage, etc.)')
  .addHelpText('after', `
${chalk.bold('Examples:')}
  ${chalk.cyan('workspace meta set homepage https://example.com')}  Set homepage URL
  ${chalk.cyan('workspace meta get homepage')}                      Get homepage URL
  ${chalk.cyan('workspace meta list')}                               List all metadata
  ${chalk.cyan('workspace meta remove homepage')}                    Remove homepage URL
  ${chalk.cyan('workspace meta set model opus')}                     Set default model to opus

${chalk.bold('Available metadata keys:')}
  • homepage     - The website URL to open after task completion
  • repo         - Git repository URL
  • docs         - Documentation URL
  • checklist    - Custom completion checklist prompt for /check command
  • showprogress - Set to "autopin" (default) to auto-show and pin progress messages until completion
                   Set to "auto" to auto-show progress without pinning
                   Set to "off" to disable automatic progress tracking
  • model        - Default model preference for tasks (sonnet or opus)
                   Note: Tasks can also auto-detect models from @@opus or @@sonnet in prompts
`)
  .action(async (action, key, valueArray) => {
    try {
      const manager = await getWorkspaceManager();
      
      // Get current workspace
      const currentWorkspace = await manager.getCurrentWorkspace();
      if (!currentWorkspace) {
        console.log(chalk.yellow('No workspace found in current directory'));
        console.log(chalk.gray('Use "workspace create" or navigate to a workspace directory'));
        await manager.close();
        return;
      }
      
      const settings = currentWorkspace.settings || {};
      
      switch (action) {
        case 'set':
          if (!key) {
            console.log(chalk.red('Usage: workspace meta set <key> <value>'));
            await manager.close();
            return;
          }
          
          // Join array of values into a single string
          let value = Array.isArray(valueArray) ? valueArray.join(' ') : valueArray;
          
          // Special handling for checklist - allow multiline input from stdin
          if (key === 'checklist' && !value) {
            console.log(chalk.cyan('Enter your custom checklist prompt (press Ctrl+D when done):'));
            
            const rl = readline.createInterface({
              input: process.stdin,
              output: process.stdout,
              terminal: false
            });
            
            let checklistContent = '';
            
            rl.on('line', (line) => {
              checklistContent += line + '\n';
            });
            
            await new Promise((resolve) => {
              rl.on('close', resolve);
            });
            
            value = checklistContent.trim();
            
            if (!value) {
              console.log(chalk.yellow('No checklist content provided'));
              await manager.close();
              return;
            }
          } else if (!value) {
            console.log(chalk.red('Usage: workspace meta set <key> <value>'));
            await manager.close();
            return;
          }
          
          // Special validation for model setting
          if (key === 'model') {
            if (!isValidModel(value)) {
              console.log(chalk.red(createInvalidModelError(value).message));
              await manager.close();
              return;
            }
            value = normalizeModel(value);
          }

          // Update settings
          settings[key] = value;
          await manager.updateWorkspace(currentWorkspace.id, { settings });
          
          // Display differently for checklist
          if (key === 'checklist') {
            console.log(chalk.green(`✓ Set custom checklist for workspace`));
            console.log(chalk.gray(`Length: ${value.length} characters`));
          } else {
            console.log(chalk.green(`✓ Set ${key} = ${value}`));
          }
          console.log(chalk.gray(`Workspace: ${currentWorkspace.name}`));
          break;
          
        case 'get':
          if (!key) {
            console.log(chalk.red('Usage: workspace meta get <key>'));
            await manager.close();
            return;
          }
          
          if (settings[key]) {
            console.log(`${key}: ${settings[key]}`);
          } else {
            console.log(chalk.yellow(`No value set for "${key}"`));
          }
          break;
          
        case 'list':
        case 'ls':
          // Check if we're listing macros specifically
          const listPrefix = key; // Use key as optional prefix filter

          // Get metadata using new methods
          const meta = await manager.getWorkspaceMeta(currentWorkspace.id);
          const macros = {};
          const otherMeta = {};

          // Separate macros from other metadata
          for (const [k, v] of Object.entries(meta)) {
            if (k.startsWith('macro-')) {
              macros[k] = v;
            } else {
              otherMeta[k] = v;
            }
          }

          // Also include settings from the old format (but exclude 'meta' since we show it separately)
          const oldSettings = { ...settings };
          delete oldSettings.meta; // Don't show meta in old settings - we already display it above
          const hasOldSettings = Object.keys(oldSettings).length > 0;

          if (Object.keys(macros).length === 0 && Object.keys(otherMeta).length === 0 && !hasOldSettings) {
            console.log(chalk.yellow('No metadata set for this workspace'));
          } else {
            console.log(chalk.bold(`\nMetadata for workspace "${currentWorkspace.name}":\n`));

            // Show macros if any
            if (Object.keys(macros).length > 0) {
              console.log(chalk.cyan('📝 Macros:'));
              for (const [k, v] of Object.entries(macros)) {
                const macroName = k.replace('macro-', '');
                const displayValue = typeof v === 'object' ? JSON.stringify(v, null, 2) : v;
                console.log(`  ${chalk.green('$' + macroName)}: ${displayValue}`);
              }
              console.log('');
            }

            // Show other metadata
            if (Object.keys(otherMeta).length > 0) {
              console.log(chalk.cyan('🔧 Other Metadata:'));
              for (const [k, v] of Object.entries(otherMeta)) {
                // Format value based on type
                let displayValue;
                if (typeof v === 'object' && v !== null) {
                  // For objects, show compact summary or full JSON based on size
                  if (k === 'goalsCache' && v.goals) {
                    // Special handling for goalsCache - show summary
                    displayValue = `${v.totalGoals || 0} goals (${v.summary?.completed || 0} completed)`;
                  } else {
                    // For other objects, show JSON
                    displayValue = JSON.stringify(v, null, 2);
                  }
                } else {
                  displayValue = v;
                }
                console.log(`  ${chalk.cyan(k)}: ${displayValue}`);
              }
              console.log('');
            }

            // Show old-style settings
            if (hasOldSettings) {
              console.log(chalk.cyan('⚙️  Settings:'));
              for (const [k, v] of Object.entries(oldSettings)) {
                const displayValue = typeof v === 'object' && v !== null ? JSON.stringify(v, null, 2) : v;
                console.log(`  ${chalk.cyan(k)}: ${displayValue}`);
              }
            }
          }
          break;
          
        case 'remove':
        case 'rm':
        case 'delete':
          if (!key) {
            console.log(chalk.red('Usage: workspace meta remove <key>'));
            await manager.close();
            return;
          }

          // Try to remove from new metadata system
          const deleted = await manager.deleteWorkspaceMeta(currentWorkspace.id, key);

          if (deleted) {
            console.log(chalk.green(`✓ Removed "${key}"`));
          } else {
            // Fallback: try old settings format
            if (settings[key]) {
              delete settings[key];
              await manager.updateWorkspace(currentWorkspace.id, { settings });
              console.log(chalk.green(`✓ Removed "${key}"`));
            } else {
              console.log(chalk.yellow(`Key "${key}" not found`));
            }
          }
          break;
          
        default:
          console.log(chalk.red(`Unknown action: ${action}`));
          console.log('Valid actions: set, get, list, remove');
      }
      
      await manager.close();
    } catch (error) {
      console.error(chalk.red(`Failed to manage metadata: ${error.message}`));
      process.exit(1);
    }
  });

// Macro management command
workspaceCommand
  .command('macro')
  .description('Manage Telegram command macros')
  .argument('[action]', 'Action: list, set, remove')
  .argument('[name]', 'Macro name (without $)')
  .argument('[command...]', 'Command to store')
  .action(async (action, name, commandArray) => {
    try {
      const manager = await getWorkspaceManager();

      // Get current workspace
      const currentWorkspace = await manager.getCurrentWorkspace();
      if (!currentWorkspace) {
        console.log(chalk.yellow('No workspace found in current directory'));
        console.log(chalk.gray('Use "workspace create" or navigate to a workspace directory'));
        await manager.close();
        return;
      }

      action = action || 'list';

      switch (action) {
        case 'list':
        case 'ls':
          const allMeta = await manager.listWorkspaceMeta(currentWorkspace.id, 'macro-');
          const macros = Object.entries(allMeta);

          if (macros.length === 0) {
            console.log(chalk.yellow('No macros defined for this workspace'));
            console.log(chalk.gray('\nCreate a macro with: ani-code workspace macro set <name> <command>'));
            console.log(chalk.gray('Example: ani-code workspace macro set progress "/add what is the current progress"'));
          } else {
            console.log(chalk.bold(`\n📝 Macros for workspace "${currentWorkspace.name}":\n`));
            for (const [key, value] of macros) {
              const macroName = key.replace('macro-', '');
              console.log(`  ${chalk.green('$' + macroName)}`);
              console.log(`    ${chalk.gray('→')} ${value}`);
              console.log('');
            }
            console.log(chalk.gray(`\nExecute in Telegram with: /$<name>`));
            console.log(chalk.gray(`Example: /$progress`));
          }
          break;

        case 'set':
        case 'add':
          if (!name) {
            console.log(chalk.red('Usage: workspace macro set <name> <command>'));
            console.log(chalk.gray('Example: ani-code workspace macro set test "/add run the test suite"'));
            await manager.close();
            return;
          }

          if (!commandArray || commandArray.length === 0) {
            console.log(chalk.red('Please provide a command for the macro'));
            await manager.close();
            return;
          }

          const command = commandArray.join(' ');
          const metaKey = `macro-${name}`;
          await manager.setWorkspaceMeta(currentWorkspace.id, metaKey, command);

          console.log(chalk.green(`✓ Macro created: $${name}`));
          console.log(chalk.gray(`  Command: ${command}`));
          console.log(chalk.gray(`\nExecute in Telegram with: /$${name}`));
          break;

        case 'remove':
        case 'rm':
        case 'delete':
          if (!name) {
            console.log(chalk.red('Usage: workspace macro remove <name>'));
            await manager.close();
            return;
          }

          const deleteKey = `macro-${name}`;
          const deleted = await manager.deleteWorkspaceMeta(currentWorkspace.id, deleteKey);

          if (deleted) {
            console.log(chalk.green(`✓ Removed macro: $${name}`));
          } else {
            console.log(chalk.yellow(`Macro not found: $${name}`));
          }
          break;

        default:
          console.log(chalk.red(`Unknown action: ${action}`));
          console.log('Valid actions: list, set, remove');
          console.log('');
          console.log('Examples:');
          console.log('  ani-code workspace macro list');
          console.log('  ani-code workspace macro set test "/add run tests"');
          console.log('  ani-code workspace macro remove test');
      }

      await manager.close();
    } catch (error) {
      console.error(chalk.red(`Failed to manage macros: ${error.message}`));
      process.exit(1);
    }
  });

// CLI provider management
workspaceCommand
  .command('provider [provider]')
  .description('Set or show the CLI provider for this workspace')
  .addHelpText('after', `
${chalk.bold('Available providers:')}
  • claude     - Claude Code (default)
  • cursor     - Cursor Agent
  • codex      - OpenAI Codex
  • ccr        - CCR Code Router (configure via ~/.claude-code-router/config.json)
  • <custom>   - Any custom provider configured in .env

${chalk.bold('Examples:')}
  ${chalk.cyan('workspace provider')}           Show current provider
  ${chalk.cyan('workspace provider cursor')}    Set workspace to use Cursor
  ${chalk.cyan('workspace provider claude')}    Set workspace to use Claude
  ${chalk.cyan('workspace provider ccr')}       Set workspace to use CCR
`)
  .action(async (provider) => {
    try {
      const manager = await getWorkspaceManager();
      const { getProviderManager } = await import('../providers/providerManager.js');
      const providerManager = await getProviderManager();

      // Get current workspace
      const currentWorkspace = await manager.getCurrentWorkspace();
      if (!currentWorkspace) {
        console.log(chalk.yellow('No workspace found in current directory'));
        console.log(chalk.gray('Use "workspace create" or navigate to a workspace directory'));
        await manager.close();
        return;
      }

      if (!provider) {
        // Show current provider
        const currentProvider = await manager.getWorkspaceMeta(currentWorkspace.id, 'cliProvider');
        const activeHandler = providerManager.getCurrentHandler();

        console.log(chalk.bold('Workspace CLI Provider Settings:'));
        console.log(`  Workspace: ${chalk.cyan(currentWorkspace.name)}`);
        console.log(`  Configured: ${currentProvider ? chalk.green(currentProvider) : chalk.gray('not set (using default)')}`);
        console.log(`  Active: ${chalk.green(activeHandler.name)} (${activeHandler.id})`);

        console.log('\n' + chalk.bold('Available providers:'));
        const providers = providerManager.listProviders();

        // Check status of each provider
        for (const p of providers) {
          const handler = providerManager.getHandler(p.id);
          let status = '';
          let statusIcon = '⚪';

          try {
            // Check if binary exists
            execSync(`which ${handler.binary}`, { encoding: 'utf8', stdio: 'pipe' });
            status = chalk.green('ready');
            statusIcon = '✅';
          } catch (err) {
            status = chalk.yellow('not installed');
            statusIcon = '⚠️';
          }

          const marker = p.current ? chalk.cyan(' ← active') : '';
          console.log(`  ${statusIcon} ${p.id.padEnd(10)} - ${p.name.padEnd(20)} ${status}${marker}`);
        }

        console.log('\n' + chalk.gray('Tip: Use "workspace provider <name>" to switch providers'));
      } else {
        // Set provider
        const availableProviders = providerManager.listProviders();
        const providerExists = availableProviders.some(p => p.id === provider);

        if (!providerExists && provider !== 'ccr') {
          console.log(chalk.red(`Provider "${provider}" not found`));
          console.log('\nAvailable providers:');
          availableProviders.forEach(p => {
            console.log(`  • ${p.id.padEnd(10)} - ${p.name}`);
          });
          await manager.close();
          return;
        }

        await manager.setWorkspaceMeta(currentWorkspace.id, 'cliProvider', provider);
        console.log(chalk.green(`✓ Set workspace provider to: ${provider}`));
        console.log(chalk.gray('This will be used for all tasks in this workspace'));

        // Get the handler to test
        const handler = providerManager.getHandler(provider) ||
                       providerManager.createCustomProvider({
                         id: provider,
                         handler: 'customClaude',
                         name: provider
                       });

        // Check if binary exists and offer to test it
        let binaryExists = false;
        try {
          execSync(`which ${handler.binary}`, { encoding: 'utf8', stdio: 'pipe' });
          binaryExists = true;
        } catch (err) {
          console.log(chalk.yellow(`\n⚠️  Provider binary not found: ${handler.binary}`));
          console.log(chalk.gray(`Please install ${handler.binary} to use this provider`));
        }

        if (binaryExists) {
          console.log(`\n${chalk.bold('Provider requires authentication/authorization:')}`);
          console.log(chalk.cyan(`Opening ${handler.name} for setup...`));
          console.log(chalk.gray('Please grant permissions and complete the setup\n'));

          await manager.close();

          // Prepare the command
          const args = [];
          if (handler.args && handler.args.length > 0) {
            args.push(...handler.args);
          }

          // Show the command being executed
          console.log(chalk.gray(`Executing: ${handler.binary} ${args.join(' ')}\n`));

          // Replace current process with the provider binary
          // This allows the provider to take over the terminal for auth/setup
          const child = spawn(handler.binary, args, {
            stdio: 'inherit',
            env: { ...process.env, ...handler.env },
            cwd: currentWorkspace.path
          });

          child.on('error', (err) => {
            console.error(chalk.red(`Failed to launch ${handler.name}: ${err.message}`));
            process.exit(1);
          });

          child.on('exit', (code) => {
            if (code === 0) {
              console.log(chalk.green(`\n✓ ${handler.name} setup completed`));
              console.log(chalk.gray(`You can now use: ani-code add "your prompt"`));
            } else {
              console.log(chalk.yellow(`\n${handler.name} exited with code ${code}`));
            }
            process.exit(code || 0);
          });

          return; // Don't close manager or exit, let child process handle it
        }
      }

      await manager.close();
    } catch (error) {
      console.error(chalk.red(`Failed to manage provider: ${error.message}`));
      process.exit(1);
    }
  });

export default workspaceCommand;
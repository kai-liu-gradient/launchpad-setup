import { Command } from 'commander';
import chalk from 'chalk';
import { VALID_DISPLAY_MODES, resolveDisplayMode, DisplayModeManager } from '../display-mode.js';

const chatUICommand = new Command('chatui')
  .description('Configure chat display mode for task notifications')
  .argument('[mode]', 'Display mode: full, simple, or default')
  .option('-c, --chat <chatId>', 'Chat ID to configure (default: global)')
  .addHelpText('after', `
Examples:
  $ ani-code chatui                  # Show current display mode
  $ ani-code chatui simple           # Switch to simple mode
  $ ani-code chatui full             # Switch to full mode
  $ ani-code chatui default          # Reset to default (full)

Display Modes:
  full     All output: headers, git status, cost/tokens, footer
  simple   Streamlined: task output + brief completion line only
  default  Alias for full mode
  `)
  .action(async (mode, options) => {
    try {
      const chatId = options.chat || 'global';

      // Show current mode if no argument
      if (!mode) {
        const envMode = process.env.CHAT_DISPLAY_MODE;
        const effectiveMode = envMode && VALID_DISPLAY_MODES.includes(envMode)
          ? resolveDisplayMode(envMode) : 'full';

        console.log(chalk.bold('\nChat Display Mode\n'));
        console.log(`  Current mode: ${chalk.cyan(effectiveMode)}`);

        if (envMode) {
          console.log(`  Source: ${chalk.gray('CHAT_DISPLAY_MODE env var')}`);
        } else {
          console.log(`  Source: ${chalk.gray('default')}`);
        }

        console.log();
        console.log(chalk.gray('Available modes:'));
        const modes = DisplayModeManager.getAvailableModes();
        for (const m of modes) {
          const marker = m.id === effectiveMode || (m.id === 'default' && effectiveMode === 'full') ? chalk.green('●') : chalk.gray('○');
          console.log(`  ${marker} ${chalk.bold(m.id)} - ${chalk.gray(m.description)}`);
        }
        console.log();
        console.log(chalk.gray('Switch mode: ani-code chatui <mode>'));
        return;
      }

      // Validate mode
      if (!VALID_DISPLAY_MODES.includes(mode)) {
        console.error(chalk.red(`Invalid display mode: ${mode}`));
        console.log(chalk.gray(`Valid modes: ${VALID_DISPLAY_MODES.join(', ')}`));
        process.exit(1);
      }

      const resolved = resolveDisplayMode(mode);

      if (mode === 'default') {
        console.log(chalk.green(`✓ Display mode reset to default: ${resolved}`));
      } else {
        console.log(chalk.green(`✓ Display mode set to: ${resolved}`));
      }

      console.log();
      console.log(chalk.gray('Note: This setting applies via the CHAT_DISPLAY_MODE env var or per-chat via Telegram /chatui command.'));
    } catch (error) {
      console.error(chalk.red('Error:'), error.message);
      process.exit(1);
    }
  });

export default chatUICommand;

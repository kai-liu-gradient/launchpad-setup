#!/usr/bin/env node

const fs = require('fs').promises;
const path = require('path');
const babel = require('@babel/core');
const parser = require('@babel/parser');
const traverse = require('@babel/traverse').default;
const generate = require('@babel/generator').default;
const t = require('@babel/types');

class BuildAnnotator {
  constructor(options = {}) {
    this.options = {
      framework: options.framework || 'react', // react, vue, angular
      srcDir: options.srcDir || './src',
      extensions: options.extensions || ['.jsx', '.tsx', '.js', '.ts', '.vue'],
      prefix: options.prefix || 'data-ac-',
      verbose: options.verbose || false,
      ...options
    };
    
    this.annotatedFiles = 0;
    this.annotatedComponents = 0;
  }

  async execute(args) {
    const command = args[0];
    
    switch (command) {
      case 'annotate':
        return await this.annotateProject();
      
      case 'clean':
        return await this.cleanAnnotations();
      
      case 'check':
        return await this.checkAnnotations();
      
      case '--help':
      case 'help':
      default:
        return this.showHelp();
    }
  }

  async annotateProject() {
    console.log('🏷️  Annotating components for AniCode Chrome plugin...');
    console.log(`Framework: ${this.options.framework}`);
    console.log(`Source directory: ${this.options.srcDir}`);
    console.log();
    
    const files = await this.findSourceFiles(this.options.srcDir);
    
    for (const file of files) {
      await this.annotateFile(file);
    }
    
    console.log(`\n✅ Annotation complete!`);
    console.log(`   Files processed: ${this.annotatedFiles}`);
    console.log(`   Components annotated: ${this.annotatedComponents}`);
    
    // Save annotation map
    await this.saveAnnotationMap();
  }

  async findSourceFiles(dir) {
    const files = [];
    const entries = await fs.readdir(dir, { withFileTypes: true });
    
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      
      if (entry.isDirectory() && !entry.name.startsWith('.') && entry.name !== 'node_modules') {
        const subFiles = await this.findSourceFiles(fullPath);
        files.push(...subFiles);
      } else if (entry.isFile()) {
        const ext = path.extname(entry.name);
        if (this.options.extensions.includes(ext)) {
          files.push(fullPath);
        }
      }
    }
    
    return files;
  }

  async annotateFile(filePath) {
    try {
      const content = await fs.readFile(filePath, 'utf8');
      const ext = path.extname(filePath);
      
      let annotated;
      if (ext === '.vue') {
        annotated = await this.annotateVueFile(content, filePath);
      } else {
        annotated = await this.annotateJSFile(content, filePath);
      }
      
      if (annotated && annotated !== content) {
        await fs.writeFile(filePath, annotated);
        this.annotatedFiles++;
        
        if (this.options.verbose) {
          console.log(`   ✓ ${path.relative(process.cwd(), filePath)}`);
        }
      }
    } catch (error) {
      console.error(`   ✗ Error processing ${filePath}: ${error.message}`);
    }
  }

  async annotateJSFile(content, filePath) {
    const ast = parser.parse(content, {
      sourceType: 'module',
      plugins: ['jsx', 'typescript', 'decorators-legacy', 'classProperties']
    });
    
    let modified = false;
    const relPath = path.relative(process.cwd(), filePath);
    
    if (this.options.framework === 'react') {
      traverse(ast, {
        JSXOpeningElement: (nodePath) => {
          const node = nodePath.node;
          
          // Skip if already annotated
          if (node.attributes.some(attr => 
            t.isJSXAttribute(attr) && 
            attr.name.name?.startsWith(this.options.prefix.replace('data-', ''))
          )) {
            return;
          }
          
          // Find parent component
          const component = this.findParentComponent(nodePath);
          if (!component) return;
          
          // Add annotation attributes
          const annotations = this.createAnnotationAttributes(component, relPath, node.loc?.start.line);
          node.attributes.push(...annotations);
          
          modified = true;
          this.annotatedComponents++;
        }
      });
    }
    
    if (modified) {
      const output = generate(ast, {}, content);
      return output.code;
    }
    
    return content;
  }

  async annotateVueFile(content, filePath) {
    // Parse Vue SFC
    const templateMatch = content.match(/<template>([\s\S]*?)<\/template>/);
    if (!templateMatch) return content;
    
    let template = templateMatch[1];
    const relPath = path.relative(process.cwd(), filePath);
    
    // Extract component name from script
    const scriptMatch = content.match(/<script[^>]*>([\s\S]*?)<\/script>/);
    let componentName = 'Unknown';
    
    if (scriptMatch) {
      const nameMatch = scriptMatch[1].match(/name:\s*['"]([^'"]+)['"]/);
      if (nameMatch) {
        componentName = nameMatch[1];
      } else {
        componentName = path.basename(filePath, path.extname(filePath));
      }
    }
    
    // Add annotations to root elements
    template = template.replace(/(<\w+)([^>]*?)(\/?>)/g, (match, tag, attrs, close) => {
      // Skip if already annotated
      if (attrs.includes(this.options.prefix)) {
        return match;
      }
      
      // Add annotations
      const annotations = `${this.options.prefix}component="${componentName}" ${this.options.prefix}source="${relPath}"`;
      
      this.annotatedComponents++;
      return `${tag} ${annotations}${attrs}${close}`;
    });
    
    return content.replace(/<template>([\s\S]*?)<\/template>/, `<template>${template}</template>`);
  }

  findParentComponent(nodePath) {
    let parent = nodePath;
    
    while (parent) {
      // Check for function component
      if (parent.isFunctionDeclaration() || parent.isArrowFunctionExpression() || parent.isFunctionExpression()) {
        const parentNode = parent.parent;
        if (parentNode && parentNode.type === 'VariableDeclarator') {
          return parentNode.id.name;
        }
        if (parent.node.id) {
          return parent.node.id.name;
        }
      }
      
      // Check for class component
      if (parent.isClassDeclaration()) {
        return parent.node.id.name;
      }
      
      parent = parent.parentPath;
    }
    
    return null;
  }

  createAnnotationAttributes(componentName, sourcePath, line) {
    const attributes = [];
    
    // Component name
    attributes.push(
      t.jsxAttribute(
        t.jsxIdentifier(`${this.options.prefix}component`),
        t.stringLiteral(componentName || 'Unknown')
      )
    );
    
    // Source file
    attributes.push(
      t.jsxAttribute(
        t.jsxIdentifier(`${this.options.prefix}source`),
        t.stringLiteral(sourcePath)
      )
    );
    
    // Line number
    if (line) {
      attributes.push(
        t.jsxAttribute(
          t.jsxIdentifier(`${this.options.prefix}line`),
          t.stringLiteral(String(line))
        )
      );
    }
    
    return attributes;
  }

  async cleanAnnotations() {
    console.log('🧹 Removing AniCode annotations...');
    
    const files = await this.findSourceFiles(this.options.srcDir);
    let cleanedFiles = 0;
    
    for (const file of files) {
      const content = await fs.readFile(file, 'utf8');
      
      // Remove data-ac-* attributes
      const cleaned = content.replace(
        new RegExp(`${this.options.prefix}[a-z-]+="[^"]*"\\s*`, 'g'),
        ''
      );
      
      if (cleaned !== content) {
        await fs.writeFile(file, cleaned);
        cleanedFiles++;
        
        if (this.options.verbose) {
          console.log(`   ✓ Cleaned ${path.relative(process.cwd(), file)}`);
        }
      }
    }
    
    console.log(`\n✅ Cleaned ${cleanedFiles} files`);
  }

  async checkAnnotations() {
    console.log('🔍 Checking AniCode annotations...');
    
    const files = await this.findSourceFiles(this.options.srcDir);
    let annotatedFiles = 0;
    let totalAnnotations = 0;
    
    for (const file of files) {
      const content = await fs.readFile(file, 'utf8');
      const matches = content.match(new RegExp(`${this.options.prefix}component=`, 'g'));
      
      if (matches) {
        annotatedFiles++;
        totalAnnotations += matches.length;
        
        if (this.options.verbose) {
          console.log(`   ✓ ${path.relative(process.cwd(), file)}: ${matches.length} annotations`);
        }
      }
    }
    
    console.log(`\n📊 Annotation Status:`);
    console.log(`   Files with annotations: ${annotatedFiles}`);
    console.log(`   Total annotations: ${totalAnnotations}`);
  }

  async saveAnnotationMap() {
    // Save a map of components to source files for reference
    const mapFile = path.join(process.cwd(), '.anicode-annotations.json');
    const map = {
      timestamp: new Date().toISOString(),
      framework: this.options.framework,
      files: this.annotatedFiles,
      components: this.annotatedComponents,
      prefix: this.options.prefix
    };
    
    await fs.writeFile(mapFile, JSON.stringify(map, null, 2));
  }

  showHelp() {
    console.log(`
AniCode Build Annotator

This tool adds metadata attributes to your React/Vue components to enable
better Chrome plugin integration. The metadata helps identify which source
file and component corresponds to each DOM element.

Usage: anicode build-annotate <command> [options]

Commands:
  annotate    Add metadata attributes to components
  clean       Remove all AniCode annotations
  check       Check current annotation status

Options:
  --framework <name>  Framework to annotate (react, vue, angular)
  --src <dir>        Source directory (default: ./src)
  --prefix <prefix>  Attribute prefix (default: data-ac-)
  --verbose          Show detailed output

Examples:
  anicode build-annotate annotate --framework react
  anicode build-annotate clean
  anicode build-annotate check --verbose

Note: Run 'annotate' during development builds and 'clean' for production.
    `);
  }
}

// Export for use in main CLI
module.exports = BuildAnnotator;

// Allow direct execution
if (require.main === module) {
  const annotator = new BuildAnnotator({
    framework: process.argv.includes('--framework') 
      ? process.argv[process.argv.indexOf('--framework') + 1] 
      : 'react',
    srcDir: process.argv.includes('--src')
      ? process.argv[process.argv.indexOf('--src') + 1]
      : './src',
    verbose: process.argv.includes('--verbose')
  });
  
  annotator.execute(process.argv.slice(2));
}
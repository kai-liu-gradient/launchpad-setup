// Webpack plugin for automatic AniCode annotation
class AniCodeWebpackPlugin {
  constructor(options = {}) {
    this.options = {
      enabled: process.env.NODE_ENV === 'development',
      framework: 'react',
      prefix: 'data-ac-',
      verbose: false,
      ...options
    };
  }

  apply(compiler) {
    if (!this.options.enabled) return;

    compiler.hooks.compilation.tap('AniCodeWebpackPlugin', (compilation) => {
      // For webpack 5
      if (compilation.hooks.processAssets) {
        compilation.hooks.processAssets.tapAsync(
          {
            name: 'AniCodeWebpackPlugin',
            stage: compilation.constructor.PROCESS_ASSETS_STAGE_OPTIMIZE
          },
          async (assets, callback) => {
            await this.processAssets(assets);
            callback();
          }
        );
      } else {
        // For webpack 4
        compilation.hooks.optimizeChunkAssets.tapAsync(
          'AniCodeWebpackPlugin',
          async (chunks, callback) => {
            await this.processChunks(compilation, chunks);
            callback();
          }
        );
      }
    });
  }

  async processAssets(assets) {
    for (const [pathname, source] of Object.entries(assets)) {
      if (pathname.endsWith('.js') || pathname.endsWith('.jsx')) {
        const content = source.source();
        const annotated = this.annotateReactCode(content, pathname);
        
        if (annotated !== content) {
          assets[pathname] = {
            source: () => annotated,
            size: () => annotated.length
          };
        }
      }
    }
  }

  async processChunks(compilation, chunks) {
    for (const chunk of chunks) {
      for (const file of chunk.files) {
        if (file.endsWith('.js') || file.endsWith('.jsx')) {
          const asset = compilation.assets[file];
          const content = asset.source();
          const annotated = this.annotateReactCode(content, file);
          
          if (annotated !== content) {
            compilation.assets[file] = {
              source: () => annotated,
              size: () => annotated.length
            };
          }
        }
      }
    }
  }

  annotateReactCode(code, filename) {
    if (this.options.framework === 'react') {
      // Add data attributes to React.createElement calls
      code = code.replace(
        /React\.createElement\s*\(\s*(['"])(\w+)\1/g,
        (match, quote, tag) => {
          return `React.createElement(${quote}${tag}${quote}, {"${this.options.prefix}source": "${filename}"`;
        }
      );

      // Add data attributes to JSX compiled output
      code = code.replace(
        /_jsx\s*\(\s*(['"])(\w+)\1/g,
        (match, quote, tag) => {
          return `_jsx(${quote}${tag}${quote}, {"${this.options.prefix}source": "${filename}"`;
        }
      );
    }

    return code;
  }
}

// Vite plugin for automatic AniCode annotation
class AniCodeVitePlugin {
  constructor(options = {}) {
    this.options = {
      enabled: process.env.NODE_ENV === 'development',
      framework: 'react',
      prefix: 'data-ac-',
      ...options
    };
  }

  transform(code, id) {
    if (!this.options.enabled) return null;
    if (!id.match(/\.(jsx?|tsx?)$/)) return null;

    const babel = require('@babel/core');
    const result = babel.transformSync(code, {
      plugins: [
        [this.createBabelPlugin(), this.options]
      ],
      parserOpts: {
        sourceType: 'module',
        plugins: ['jsx', 'typescript']
      }
    });

    return {
      code: result.code,
      map: result.map
    };
  }

  createBabelPlugin() {
    const t = require('@babel/types');
    const options = this.options;

    return function() {
      return {
        visitor: {
          JSXOpeningElement(path, state) {
            const filename = state.filename || 'unknown';
            const line = path.node.loc?.start.line;
            
            // Check if already has annotations
            const hasAnnotation = path.node.attributes.some(attr =>
              t.isJSXAttribute(attr) &&
              attr.name.name?.startsWith(options.prefix.replace('data-', ''))
            );

            if (!hasAnnotation) {
              // Add source attribute
              path.node.attributes.push(
                t.jsxAttribute(
                  t.jsxIdentifier(`${options.prefix}source`),
                  t.stringLiteral(filename)
                )
              );

              // Add line attribute
              if (line) {
                path.node.attributes.push(
                  t.jsxAttribute(
                    t.jsxIdentifier(`${options.prefix}line`),
                    t.stringLiteral(String(line))
                  )
                );
              }

              // Try to find component name
              const componentName = findComponentName(path);
              if (componentName) {
                path.node.attributes.push(
                  t.jsxAttribute(
                    t.jsxIdentifier(`${options.prefix}component`),
                    t.stringLiteral(componentName)
                  )
                );
              }
            }
          }
        }
      };
    };

    function findComponentName(path) {
      let current = path;
      while (current) {
        if (current.isFunctionDeclaration() || current.isArrowFunctionExpression()) {
          if (current.parent?.id?.name) {
            return current.parent.id.name;
          }
        }
        if (current.isClassDeclaration() && current.node.id?.name) {
          return current.node.id.name;
        }
        current = current.parentPath;
      }
      return null;
    }
  }
}

// Export both plugins
module.exports = {
  AniCodeWebpackPlugin,
  AniCodeVitePlugin
};

// Usage examples in comments
/*
// Webpack configuration
const { AniCodeWebpackPlugin } = require('anicode/build-webpack-plugin');

module.exports = {
  plugins: [
    new AniCodeWebpackPlugin({
      enabled: process.env.NODE_ENV === 'development',
      framework: 'react',
      prefix: 'data-ac-'
    })
  ]
};

// Vite configuration
import { AniCodeVitePlugin } from 'anicode/build-webpack-plugin';

export default {
  plugins: [
    {
      name: 'anicode-annotate',
      ...new AniCodeVitePlugin({
        enabled: process.env.NODE_ENV === 'development',
        framework: 'react'
      })
    }
  ]
};
*/
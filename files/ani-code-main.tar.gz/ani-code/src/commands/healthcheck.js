/**
 * Healthcheck Command Module
 * Comprehensive project health analysis based on techstack detection
 */

import { Command } from 'commander';
import chalk from 'chalk';
import { existsSync, readFileSync, writeFileSync, mkdirSync, readdirSync, statSync, unlinkSync } from 'fs';
import { join, basename, dirname } from 'path';
import { execSync } from 'child_process';
import { fileURLToPath } from 'url';
import { IPCClient } from '../ipc-client.js';

/**
 * Supported techstacks and their detection patterns
 */
const TECHSTACK_DETECTORS = {
  node: {
    name: 'Node.js',
    files: ['package.json'],
    description: 'Node.js/npm project'
  },
  python: {
    name: 'Python',
    files: ['requirements.txt', 'pyproject.toml', 'setup.py', 'Pipfile'],
    description: 'Python project'
  },
  go: {
    name: 'Go',
    files: ['go.mod', 'go.sum'],
    description: 'Go project'
  },
  rust: {
    name: 'Rust',
    files: ['Cargo.toml'],
    description: 'Rust project'
  },
  java: {
    name: 'Java',
    files: ['pom.xml', 'build.gradle', 'build.gradle.kts'],
    description: 'Java/Maven/Gradle project'
  }
};

/**
 * Output directory configuration
 */
const HEALTHCHECK_DIR = '.ani-code/healthcheck';

/**
 * JSON output schema version
 */
const SCHEMA_VERSION = '1.0.0';

/**
 * Detect project techstacks based on configuration files
 * @param {string} workspacePath - Path to analyze
 * @returns {string[]} Array of detected techstack keys
 */
function detectTechstacks(workspacePath) {
  const detected = [];

  for (const [key, config] of Object.entries(TECHSTACK_DETECTORS)) {
    for (const file of config.files) {
      const filePath = join(workspacePath, file);
      if (existsSync(filePath)) {
        detected.push(key);
        break;
      }
    }
  }

  return detected;
}

/**
 * Generate timestamped filename
 * @returns {string} Filename in format healthcheck-YYYY-MM-DD-HHMMSS
 */
function generateTimestampedFilename() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const seconds = String(now.getSeconds()).padStart(2, '0');

  return `healthcheck-${year}-${month}-${day}-${hours}${minutes}${seconds}`;
}

/**
 * Ensure healthcheck output directory exists
 * @param {string} workspacePath - Workspace path
 * @returns {string} Full path to healthcheck directory
 */
function ensureOutputDirectory(workspacePath) {
  const outputDir = join(workspacePath, HEALTHCHECK_DIR);
  if (!existsSync(outputDir)) {
    mkdirSync(outputDir, { recursive: true });
  }
  return outputDir;
}

/**
 * Execute npm audit and parse results
 * @param {string} workspacePath - Path to Node.js project
 * @returns {Object} Parsed audit results
 */
function runNpmAudit(workspacePath) {
  try {
    // Run npm audit in JSON format
    const result = execSync('npm audit --json 2>/dev/null', {
      cwd: workspacePath,
      encoding: 'utf8',
      maxBuffer: 10 * 1024 * 1024
    });

    return JSON.parse(result);
  } catch (error) {
    // npm audit exits with non-zero when vulnerabilities found
    if (error.stdout) {
      try {
        return JSON.parse(error.stdout);
      } catch (e) {
        return { error: 'Failed to parse npm audit output', raw: error.stdout?.substring(0, 500) };
      }
    }
    return { error: error.message };
  }
}

/**
 * Execute npm outdated and parse results
 * @param {string} workspacePath - Path to Node.js project
 * @returns {Object} Parsed outdated packages
 */
function runNpmOutdated(workspacePath) {
  try {
    const result = execSync('npm outdated --json 2>/dev/null', {
      cwd: workspacePath,
      encoding: 'utf8',
      maxBuffer: 10 * 1024 * 1024
    });

    return JSON.parse(result || '{}');
  } catch (error) {
    // npm outdated exits with non-zero when outdated packages found
    if (error.stdout) {
      try {
        return JSON.parse(error.stdout || '{}');
      } catch (e) {
        return {};
      }
    }
    return {};
  }
}

/**
 * Get Node.js project configuration details
 * @param {string} workspacePath - Path to Node.js project
 * @returns {Object} Configuration details
 */
function getNodeConfig(workspacePath) {
  const config = {
    hasLockFile: false,
    lockFileType: null,
    hasNpmrc: false,
    hasNvmrc: false,
    nodeVersion: null,
    enginesDefined: false,
    enginesNode: null
  };

  // Check for lock files
  if (existsSync(join(workspacePath, 'package-lock.json'))) {
    config.hasLockFile = true;
    config.lockFileType = 'npm';
  } else if (existsSync(join(workspacePath, 'yarn.lock'))) {
    config.hasLockFile = true;
    config.lockFileType = 'yarn';
  } else if (existsSync(join(workspacePath, 'pnpm-lock.yaml'))) {
    config.hasLockFile = true;
    config.lockFileType = 'pnpm';
  }

  // Check for .npmrc
  config.hasNpmrc = existsSync(join(workspacePath, '.npmrc'));

  // Check for .nvmrc
  if (existsSync(join(workspacePath, '.nvmrc'))) {
    config.hasNvmrc = true;
    try {
      config.nodeVersion = readFileSync(join(workspacePath, '.nvmrc'), 'utf8').trim();
    } catch (e) {
      // Ignore read errors
    }
  }

  // Check package.json for engines field
  try {
    const pkgPath = join(workspacePath, 'package.json');
    if (existsSync(pkgPath)) {
      const pkg = JSON.parse(readFileSync(pkgPath, 'utf8'));
      if (pkg.engines && pkg.engines.node) {
        config.enginesDefined = true;
        config.enginesNode = pkg.engines.node;
      }
    }
  } catch (e) {
    // Ignore parse errors
  }

  return config;
}

/**
 * Calculate health score from audit results
 * @param {Object} auditData - npm audit results
 * @returns {Object} Score breakdown
 */
function calculateHealthScore(auditData) {
  const severity = {
    critical: 0,
    high: 0,
    moderate: 0,
    low: 0,
    info: 0
  };

  // Parse vulnerabilities from npm audit output
  if (auditData.metadata && auditData.metadata.vulnerabilities) {
    const vuln = auditData.metadata.vulnerabilities;
    severity.critical = vuln.critical || 0;
    severity.high = vuln.high || 0;
    severity.moderate = vuln.moderate || 0;
    severity.low = vuln.low || 0;
    severity.info = vuln.info || 0;
  } else if (auditData.vulnerabilities) {
    // Newer npm audit format
    for (const [name, info] of Object.entries(auditData.vulnerabilities)) {
      const sev = info.severity || 'low';
      if (sev in severity) {
        severity[sev]++;
      }
    }
  }

  // Calculate score (100 - penalties)
  // Critical: -25 each, High: -15 each, Moderate: -5 each, Low: -1 each
  const penalties = (severity.critical * 25) + (severity.high * 15) + (severity.moderate * 5) + (severity.low * 1);
  const score = Math.max(0, 100 - penalties);

  // Determine overall status
  let status = 'pass';
  if (severity.critical > 0) {
    status = 'critical';
  } else if (severity.high > 0) {
    status = 'fail';
  } else if (severity.moderate > 0) {
    status = 'warning';
  } else if (severity.low > 0) {
    status = 'info';
  }

  return {
    healthScore: score,
    status,
    totalIssues: severity.critical + severity.high + severity.moderate + severity.low + severity.info,
    critical: severity.critical,
    high: severity.high,
    medium: severity.moderate,
    low: severity.low,
    info: severity.info
  };
}

/**
 * Generate recommendations based on analysis
 * @param {Object} nodeData - Node.js analysis data
 * @param {Object} config - Node.js config data
 * @returns {Array} Array of recommendations
 */
function generateRecommendations(nodeData, config) {
  const recommendations = [];

  // Vulnerability recommendations
  if (nodeData.audit && nodeData.audit.metadata) {
    const vuln = nodeData.audit.metadata.vulnerabilities || {};

    if (vuln.critical > 0) {
      recommendations.push({
        priority: 'critical',
        action: 'Run npm audit fix --force',
        reason: `${vuln.critical} critical vulnerabilities found`
      });
    }

    if (vuln.high > 0) {
      recommendations.push({
        priority: 'high',
        action: 'Run npm audit fix',
        reason: `${vuln.high} high severity vulnerabilities found`
      });
    }
  }

  // Outdated dependencies
  if (nodeData.outdated && Object.keys(nodeData.outdated).length > 0) {
    const outdatedCount = Object.keys(nodeData.outdated).length;
    recommendations.push({
      priority: outdatedCount > 10 ? 'medium' : 'low',
      action: 'Run npm update or npm outdated to review',
      reason: `${outdatedCount} outdated packages found`
    });
  }

  // Configuration recommendations
  if (!config.hasLockFile) {
    recommendations.push({
      priority: 'high',
      action: 'Run npm install to generate package-lock.json',
      reason: 'No lock file found - dependency versions may vary across installs'
    });
  }

  if (!config.enginesDefined) {
    recommendations.push({
      priority: 'low',
      action: 'Add engines field to package.json',
      reason: 'Node.js version not specified - may cause compatibility issues'
    });
  }

  return recommendations;
}

/**
 * Generate HTML report from JSON data
 * @param {Object} report - JSON report data
 * @returns {string} HTML content
 */
function generateHtmlReport(report) {
  const statusColors = {
    pass: '#22c55e',
    info: '#3b82f6',
    warning: '#f59e0b',
    fail: '#ef4444',
    critical: '#dc2626'
  };

  const statusColor = statusColors[report.summary.status] || '#6b7280';

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Healthcheck Report - ${new Date(report.timestamp).toLocaleDateString()}</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f5f5f5; color: #1f2937; line-height: 1.6; }
    .container { max-width: 1000px; margin: 0 auto; padding: 2rem; }
    header { background: white; border-radius: 8px; padding: 2rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    h1 { font-size: 1.5rem; margin-bottom: 0.5rem; }
    .meta { color: #6b7280; font-size: 0.875rem; }
    .summary { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }
    .card { background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    .card h3 { font-size: 0.875rem; color: #6b7280; text-transform: uppercase; margin-bottom: 0.5rem; }
    .card .value { font-size: 2rem; font-weight: 600; }
    .score { color: ${statusColor}; }
    .status { display: inline-block; padding: 0.25rem 0.75rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; background: ${statusColor}; color: white; }
    .section { background: white; border-radius: 8px; padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    .section h2 { font-size: 1.125rem; margin-bottom: 1rem; padding-bottom: 0.5rem; border-bottom: 1px solid #e5e7eb; }
    .severity { display: inline-block; padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.75rem; font-weight: 500; }
    .severity-critical { background: #fef2f2; color: #dc2626; }
    .severity-high { background: #fef2f2; color: #ef4444; }
    .severity-medium { background: #fffbeb; color: #f59e0b; }
    .severity-low { background: #f0fdf4; color: #22c55e; }
    table { width: 100%; border-collapse: collapse; }
    th, td { padding: 0.75rem; text-align: left; border-bottom: 1px solid #e5e7eb; }
    th { font-weight: 600; color: #6b7280; font-size: 0.75rem; text-transform: uppercase; }
    .recommendation { padding: 1rem; background: #f9fafb; border-radius: 4px; margin-bottom: 0.5rem; }
    .recommendation .action { font-weight: 600; margin-bottom: 0.25rem; }
    .recommendation .reason { color: #6b7280; font-size: 0.875rem; }
    .config-item { display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid #e5e7eb; }
    .config-item:last-child { border-bottom: none; }
    .check { color: #22c55e; }
    .cross { color: #ef4444; }
    footer { text-align: center; color: #9ca3af; font-size: 0.75rem; padding: 1rem; }
  </style>
</head>
<body>
  <div class="container">
    <header>
      <h1>🏥 Project Health Report</h1>
      <p class="meta">Generated: ${new Date(report.timestamp).toLocaleString()} | Path: ${report.projectPath}</p>
      <p class="meta">Detected stacks: ${report.detectedStacks.join(', ')}</p>
    </header>

    <div class="summary">
      <div class="card">
        <h3>Health Score</h3>
        <div class="value score">${report.summary.healthScore}</div>
      </div>
      <div class="card">
        <h3>Status</h3>
        <span class="status">${report.summary.status}</span>
      </div>
      <div class="card">
        <h3>Critical</h3>
        <div class="value" style="color: ${report.summary.critical > 0 ? '#dc2626' : '#22c55e'}">${report.summary.critical}</div>
      </div>
      <div class="card">
        <h3>High</h3>
        <div class="value" style="color: ${report.summary.high > 0 ? '#ef4444' : '#22c55e'}">${report.summary.high}</div>
      </div>
      <div class="card">
        <h3>Medium</h3>
        <div class="value" style="color: ${report.summary.medium > 0 ? '#f59e0b' : '#22c55e'}">${report.summary.medium}</div>
      </div>
      <div class="card">
        <h3>Low</h3>
        <div class="value" style="color: #6b7280">${report.summary.low}</div>
      </div>
    </div>

    ${report.stacks.node ? `
    <div class="section">
      <h2>📦 Node.js Configuration</h2>
      <div class="config-item">
        <span>Lock File</span>
        <span class="${report.stacks.node.config.hasLockFile ? 'check' : 'cross'}">
          ${report.stacks.node.config.hasLockFile ? '✓ ' + report.stacks.node.config.lockFileType : '✗ Missing'}
        </span>
      </div>
      <div class="config-item">
        <span>Node Version Defined</span>
        <span class="${report.stacks.node.config.enginesDefined ? 'check' : 'cross'}">
          ${report.stacks.node.config.enginesDefined ? '✓ ' + report.stacks.node.config.enginesNode : '✗ Not specified'}
        </span>
      </div>
      <div class="config-item">
        <span>.nvmrc</span>
        <span class="${report.stacks.node.config.hasNvmrc ? 'check' : 'cross'}">
          ${report.stacks.node.config.hasNvmrc ? '✓ ' + (report.stacks.node.config.nodeVersion || 'Present') : '✗ Not found'}
        </span>
      </div>
      <div class="config-item">
        <span>.npmrc</span>
        <span class="${report.stacks.node.config.hasNpmrc ? 'check' : 'cross'}">
          ${report.stacks.node.config.hasNpmrc ? '✓ Present' : '✗ Not found'}
        </span>
      </div>
    </div>
    ` : ''}

    ${report.recommendations && report.recommendations.length > 0 ? `
    <div class="section">
      <h2>💡 Recommendations</h2>
      ${report.recommendations.map(rec => `
        <div class="recommendation">
          <span class="severity severity-${rec.priority}">${rec.priority}</span>
          <div class="action">${rec.action}</div>
          <div class="reason">${rec.reason}</div>
        </div>
      `).join('')}
    </div>
    ` : ''}

    <footer>
      Generated by ani-code healthcheck v${SCHEMA_VERSION}
    </footer>
  </div>
</body>
</html>`;
}

/**
 * Write report files (JSON and/or HTML)
 * @param {Object} report - Report data
 * @param {string} outputDir - Output directory
 * @param {string} format - Output format (json, html, all)
 * @returns {Object} Paths of written files
 */
function writeReportFiles(report, outputDir, format) {
  const filename = generateTimestampedFilename();
  const paths = {};

  if (format === 'json' || format === 'all') {
    const jsonPath = join(outputDir, `${filename}.json`);
    writeFileSync(jsonPath, JSON.stringify(report, null, 2));
    paths.json = jsonPath;
  }

  if (format === 'html' || format === 'all') {
    const htmlPath = join(outputDir, `${filename}.html`);
    writeFileSync(htmlPath, generateHtmlReport(report));
    paths.html = htmlPath;
  }

  return paths;
}

/**
 * Load healthcheck prompt template
 * @param {string} templateName - Name of the template (node, auto, etc.)
 * @returns {string} Template content
 */
function loadPromptTemplate(templateName) {
  const __filename = fileURLToPath(import.meta.url);
  const __dirname = dirname(__filename);
  const templatePath = join(__dirname, '..', 'presets', 'healthcheck', `${templateName}.md`);

  if (!existsSync(templatePath)) {
    return null;
  }

  return readFileSync(templatePath, 'utf8');
}

/**
 * Build analysis prompt for Claude
 * @param {string} stackKey - Techstack key (node, python, etc.)
 * @param {Object} stackData - Data collected for the stack
 * @returns {string} Formatted prompt
 */
function buildAnalysisPrompt(stackKey, stackData) {
  const template = loadPromptTemplate(stackKey);

  if (!template) {
    // Fallback to basic prompt if no template exists
    return `Analyze the following ${stackKey} project health data and provide recommendations:

${JSON.stringify(stackData, null, 2)}

Return a JSON response with analysis, insights, and prioritized actions.`;
  }

  // Append the actual data to the template
  return `${template}

## Data to Analyze

\`\`\`json
${JSON.stringify(stackData, null, 2)}
\`\`\`

Analyze this data and return your response as a JSON object.`;
}

/**
 * Submit analysis to Claude via daemon and wait for response
 * @param {string} prompt - Analysis prompt
 * @param {string} workspacePath - Workspace path
 * @param {number} timeout - Timeout in milliseconds
 * @returns {Promise<Object|null>} Parsed analysis response or null
 */
async function submitClaudeAnalysis(prompt, workspacePath, timeout = 120000) {
  const client = new IPCClient();

  try {
    await client.connect();

    const taskName = `healthcheck-analysis-${Date.now()}`;
    const task = await client.addTask(taskName, prompt, {
      cwd: workspacePath,
      source: 'healthcheck'
    });

    // Wait for task completion
    const startTime = Date.now();
    let taskResult = null;

    while (Date.now() - startTime < timeout) {
      await new Promise(resolve => setTimeout(resolve, 2000)); // Poll every 2 seconds

      try {
        taskResult = await client.getTask(task.id);

        if (taskResult.status === 'completed' || taskResult.status === 'failed' || taskResult.status === 'cancelled') {
          break;
        }
      } catch (e) {
        // Ignore polling errors, continue waiting
      }
    }

    client.disconnect();

    if (!taskResult || taskResult.status !== 'completed') {
      return null;
    }

    // Try to parse JSON from the task output
    return parseClaudeResponse(taskResult.output || taskResult.stdout || '');
  } catch (error) {
    console.error(chalk.yellow(`  Warning: Claude analysis unavailable - ${error.message}`));
    client.disconnect();
    return null;
  }
}

/**
 * Parse Claude's JSON response from task output
 * @param {string} output - Raw output from Claude task
 * @returns {Object|null} Parsed JSON or null
 */
function parseClaudeResponse(output) {
  if (!output) return null;

  // Try to find JSON in the output (Claude might add surrounding text)
  const jsonMatch = output.match(/\{[\s\S]*\}/);

  if (jsonMatch) {
    try {
      return JSON.parse(jsonMatch[0]);
    } catch (e) {
      // Try with more aggressive cleanup
      try {
        // Remove any markdown code blocks
        const cleaned = output
          .replace(/```json\n?/g, '')
          .replace(/```\n?/g, '')
          .trim();

        const cleanedMatch = cleaned.match(/\{[\s\S]*\}/);
        if (cleanedMatch) {
          return JSON.parse(cleanedMatch[0]);
        }
      } catch (e2) {
        // Parsing failed
      }
    }
  }

  return null;
}

/**
 * Validate Claude analysis response against expected schema
 * @param {Object} analysis - Parsed analysis object
 * @param {string} stackKey - Techstack key to validate against
 * @returns {Object} Validation result with isValid and errors
 */
function validateAnalysisResponse(analysis, stackKey) {
  const errors = [];

  if (!analysis) {
    return { isValid: false, errors: ['No analysis response received'] };
  }

  // Validate common fields
  if (stackKey === 'node') {
    if (!analysis.analysis) {
      errors.push('Missing analysis field');
    } else {
      if (!analysis.analysis.securityRisk) errors.push('Missing analysis.securityRisk');
      if (!analysis.analysis.maintenanceStatus) errors.push('Missing analysis.maintenanceStatus');
    }

    if (!Array.isArray(analysis.insights)) {
      errors.push('Missing or invalid insights array');
    }

    if (!Array.isArray(analysis.prioritizedActions)) {
      errors.push('Missing or invalid prioritizedActions array');
    }
  } else if (stackKey === 'auto') {
    if (!analysis.projectOverview) {
      errors.push('Missing projectOverview field');
    }

    if (!Array.isArray(analysis.prioritizedActions)) {
      errors.push('Missing or invalid prioritizedActions array');
    }
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

/**
 * Merge Claude analysis into report
 * @param {Object} report - Existing report object
 * @param {Object} claudeAnalysis - Claude's analysis response
 * @param {string} stackKey - Techstack key
 */
function mergeClaudeAnalysis(report, claudeAnalysis, stackKey) {
  if (!claudeAnalysis) return;

  // Add Claude's analysis to the stack data
  if (report.stacks[stackKey]) {
    report.stacks[stackKey].claudeAnalysis = claudeAnalysis;
  }

  // Merge insights into recommendations if present
  if (Array.isArray(claudeAnalysis.insights)) {
    for (const insight of claudeAnalysis.insights) {
      if (insight.recommendation) {
        report.recommendations.push({
          priority: insight.severity || 'low',
          action: insight.recommendation,
          reason: insight.description || insight.title,
          source: 'claude-analysis'
        });
      }
    }
  }

  // Add prioritized actions
  if (Array.isArray(claudeAnalysis.prioritizedActions)) {
    for (const action of claudeAnalysis.prioritizedActions) {
      // Check if this action already exists
      const exists = report.recommendations.some(r =>
        r.action.toLowerCase().includes(action.action?.toLowerCase().substring(0, 20))
      );

      if (!exists && action.action) {
        report.recommendations.push({
          priority: action.impact === 'high' ? 'high' : action.impact === 'medium' ? 'medium' : 'low',
          action: action.action,
          reason: action.reason || action.estimatedImpact,
          source: 'claude-analysis'
        });
      }
    }
  }

  // Update overall assessment if present
  if (claudeAnalysis.analysis?.overallAssessment) {
    report.claudeAssessment = claudeAnalysis.analysis.overallAssessment;
  }
}

/**
 * Cleanup old report files
 * @param {string} outputDir - Output directory
 * @param {number} daysToKeep - Number of days to keep reports
 * @returns {number} Number of files deleted
 */
function cleanupOldReports(outputDir, daysToKeep) {
  if (!existsSync(outputDir)) {
    return 0;
  }

  const cutoffTime = Date.now() - (daysToKeep * 24 * 60 * 60 * 1000);
  let deletedCount = 0;

  const files = readdirSync(outputDir);
  for (const file of files) {
    if (!file.startsWith('healthcheck-')) continue;

    const filePath = join(outputDir, file);
    const stat = statSync(filePath);

    if (stat.mtime.getTime() < cutoffTime) {
      unlinkSync(filePath);
      deletedCount++;
    }
  }

  return deletedCount;
}

/**
 * Run healthcheck analysis
 * @param {string} workspacePath - Path to analyze
 * @param {Object} options - Command options
 */
async function runHealthcheck(workspacePath, options) {
  const { stack, output, dryRun, analyze } = options;

  console.log(chalk.cyan('\n🏥 Running Project Healthcheck'));
  console.log(chalk.gray('═'.repeat(60)));
  console.log(chalk.gray(`Workspace: ${workspacePath}`));

  // Detect techstacks
  let detectedStacks = [];

  if (stack) {
    // Specific stack requested
    if (TECHSTACK_DETECTORS[stack]) {
      detectedStacks = [stack];
      console.log(chalk.gray(`Stack: ${TECHSTACK_DETECTORS[stack].name} (specified)`));
    } else {
      console.error(chalk.red(`Unknown stack: ${stack}`));
      console.log(chalk.yellow(`Available stacks: ${Object.keys(TECHSTACK_DETECTORS).join(', ')}`));
      process.exit(1);
    }
  } else {
    // Auto-detect
    detectedStacks = detectTechstacks(workspacePath);

    if (detectedStacks.length === 0) {
      console.log(chalk.yellow('\n⚠ No supported techstacks detected'));
      console.log(chalk.gray('Supported: Node.js, Python, Go, Rust, Java'));
      return;
    }

    console.log(chalk.gray(`Detected: ${detectedStacks.map(s => TECHSTACK_DETECTORS[s].name).join(', ')}`));
  }

  // Dry run - show what would be executed
  if (dryRun) {
    console.log(chalk.yellow('\n📋 Dry Run - Commands that would be executed:'));

    for (const stackKey of detectedStacks) {
      console.log(chalk.cyan(`\n${TECHSTACK_DETECTORS[stackKey].name}:`));

      if (stackKey === 'node') {
        console.log(chalk.gray('  npm audit --json'));
        console.log(chalk.gray('  npm outdated --json'));
        if (analyze) {
          console.log(chalk.gray('  [Claude] Analyze results with AI recommendations'));
        }
      }
      // Add other stacks here as implemented
    }

    return;
  }

  // Initialize report structure
  const report = {
    version: SCHEMA_VERSION,
    timestamp: new Date().toISOString(),
    lastUpdate: new Date().toISOString(),
    projectPath: workspacePath,
    detectedStacks,
    summary: {
      healthScore: 100,
      status: 'pass',
      totalIssues: 0,
      critical: 0,
      high: 0,
      medium: 0,
      low: 0
    },
    stacks: {},
    recommendations: []
  };

  // Run checks for each detected stack
  for (const stackKey of detectedStacks) {
    console.log(chalk.cyan(`\n📦 Analyzing ${TECHSTACK_DETECTORS[stackKey].name}...`));

    if (stackKey === 'node') {
      // Node.js specific checks
      console.log(chalk.gray('  Running npm audit...'));
      const auditData = runNpmAudit(workspacePath);

      console.log(chalk.gray('  Running npm outdated...'));
      const outdatedData = runNpmOutdated(workspacePath);

      console.log(chalk.gray('  Checking configuration...'));
      const configData = getNodeConfig(workspacePath);

      // Count outdated packages
      const outdatedList = Object.entries(outdatedData).map(([name, info]) => ({
        name,
        current: info.current,
        wanted: info.wanted,
        latest: info.latest,
        type: info.type
      }));

      report.stacks.node = {
        audit: auditData,
        dependencies: {
          outdated: outdatedList,
          total: 0, // Would need to read package.json to get this
          upToDate: 0
        },
        config: configData
      };

      // Calculate score from audit data
      const scoreData = calculateHealthScore(auditData);
      report.summary = { ...report.summary, ...scoreData };

      // Generate recommendations
      const recs = generateRecommendations(report.stacks.node, configData);
      report.recommendations.push(...recs);

      // Run Claude analysis if requested
      if (analyze) {
        console.log(chalk.gray('  Running Claude analysis...'));
        const prompt = buildAnalysisPrompt('node', {
          audit: auditData,
          outdated: outdatedData,
          config: configData
        });

        try {
          const claudeAnalysis = await submitClaudeAnalysis(prompt, workspacePath);

          if (claudeAnalysis) {
            const validation = validateAnalysisResponse(claudeAnalysis, 'node');

            if (validation.isValid) {
              mergeClaudeAnalysis(report, claudeAnalysis, 'node');
              console.log(chalk.green('  ✓ Claude analysis completed'));
            } else {
              console.log(chalk.yellow(`  ⚠ Claude analysis partial: ${validation.errors.join(', ')}`));
              // Still merge what we got
              mergeClaudeAnalysis(report, claudeAnalysis, 'node');
            }
          } else {
            console.log(chalk.yellow('  ⚠ Claude analysis timed out or unavailable'));
          }
        } catch (analysisError) {
          console.log(chalk.yellow(`  ⚠ Claude analysis failed: ${analysisError.message}`));
        }
      }
    }

    // Additional stacks would be implemented here
  }

  // Display summary
  console.log(chalk.cyan('\n📊 Summary'));
  console.log(chalk.gray('─'.repeat(40)));

  const scoreColor = report.summary.healthScore >= 80 ? chalk.green :
                     report.summary.healthScore >= 60 ? chalk.yellow : chalk.red;

  console.log(`Health Score: ${scoreColor(report.summary.healthScore)}/100`);
  console.log(`Status: ${chalk.bold(report.summary.status.toUpperCase())}`);

  if (report.summary.critical > 0) {
    console.log(chalk.red(`Critical: ${report.summary.critical}`));
  }
  if (report.summary.high > 0) {
    console.log(chalk.red(`High: ${report.summary.high}`));
  }
  if (report.summary.medium > 0) {
    console.log(chalk.yellow(`Medium: ${report.summary.medium}`));
  }
  if (report.summary.low > 0) {
    console.log(chalk.gray(`Low: ${report.summary.low}`));
  }

  // Show Claude's assessment if available
  if (report.claudeAssessment) {
    console.log(chalk.cyan('\n🤖 AI Assessment'));
    console.log(chalk.gray('─'.repeat(40)));
    console.log(chalk.white(report.claudeAssessment));
  }

  // Show recommendations
  if (report.recommendations.length > 0) {
    console.log(chalk.cyan('\n💡 Recommendations'));
    console.log(chalk.gray('─'.repeat(40)));

    for (const rec of report.recommendations) {
      const priorityColor = rec.priority === 'critical' ? chalk.red :
                           rec.priority === 'high' ? chalk.red :
                           rec.priority === 'medium' ? chalk.yellow : chalk.gray;

      console.log(`${priorityColor(`[${rec.priority.toUpperCase()}]`)} ${rec.action}`);
      console.log(chalk.gray(`  └─ ${rec.reason}`));
    }
  }

  // Write reports
  const outputDir = ensureOutputDirectory(workspacePath);
  const outputFormat = output || 'all';
  const paths = writeReportFiles(report, outputDir, outputFormat);

  console.log(chalk.green('\n✅ Reports generated:'));
  if (paths.json) {
    console.log(chalk.gray(`  JSON: ${paths.json}`));
  }
  if (paths.html) {
    console.log(chalk.gray(`  HTML: ${paths.html}`));
  }

  // Exit with appropriate code
  if (report.summary.critical > 0) {
    process.exit(2);
  } else if (report.summary.high > 0) {
    process.exit(1);
  }
}

/**
 * Create healthcheck command
 */
export default function createHealthcheckCommand() {
  const healthcheckCommand = new Command('healthcheck')
    .description('Analyze project health and security vulnerabilities')
    .option('-w, --workspace <path>', 'Workspace path to analyze', process.cwd())
    .option('-s, --stack <techstack>', 'Specify techstack (node, python, go, rust, java)')
    .option('-o, --output <format>', 'Output format (json, html, all)', 'all')
    .option('-a, --analyze', 'Enable Claude AI analysis for enhanced recommendations', false)
    .option('--cleanup <days>', 'Remove reports older than N days', parseInt)
    .option('--dry-run', 'Preview commands without execution', false);

  // Default action (auto mode)
  healthcheckCommand
    .action(async (options) => {
      const workspacePath = options.workspace;

      // Handle cleanup
      if (options.cleanup) {
        const outputDir = join(workspacePath, HEALTHCHECK_DIR);
        const deleted = cleanupOldReports(outputDir, options.cleanup);
        console.log(chalk.green(`✅ Cleaned up ${deleted} old report(s)`));
        return;
      }

      await runHealthcheck(workspacePath, options);
    });

  // Auto subcommand (explicit auto-detection mode)
  healthcheckCommand
    .command('auto')
    .description('Auto-detect techstacks and run all applicable healthchecks')
    .option('-w, --workspace <path>', 'Workspace path to analyze', process.cwd())
    .option('-o, --output <format>', 'Output format (json, html, all)', 'all')
    .option('-a, --analyze', 'Enable Claude AI analysis for enhanced recommendations', false)
    .option('--dry-run', 'Preview commands without execution', false)
    .action(async (options) => {
      await runHealthcheck(options.workspace, { ...options, stack: null });
    });

  return healthcheckCommand;
}

// Export utilities for testing
export {
  detectTechstacks,
  generateTimestampedFilename,
  runNpmAudit,
  runNpmOutdated,
  getNodeConfig,
  calculateHealthScore,
  generateRecommendations,
  cleanupOldReports,
  loadPromptTemplate,
  buildAnalysisPrompt,
  parseClaudeResponse,
  validateAnalysisResponse,
  mergeClaudeAnalysis,
  TECHSTACK_DETECTORS,
  SCHEMA_VERSION
};

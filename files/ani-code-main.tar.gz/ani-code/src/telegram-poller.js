import { config } from './config.js';
import { logger } from './logger.js';
import { TelegramAPI } from './telegram-api.js';

export class TelegramPoller {
  constructor(httpServer) {
    this.httpServer = httpServer;
    this.botToken = config.telegram?.botToken;
    this.offset = 0;
    this.polling = false;
    this.pollInterval = null;
    this.botUsername = null; // Store bot username for mention detection
    
    // Initialize Telegram API client if bot token is available
    if (this.botToken) {
      this.api = new TelegramAPI(this.botToken);
    }
  }

  async start() {
    if (!this.botToken) {
      logger.warn('Telegram bot token not configured, skipping polling');
      return;
    }

    // Get bot info
    try {
      const data = await this.api.getMe();
      if (data.ok) {
        this.botUsername = data.result.username; // Store bot username
        this.httpServer.telegramBotUsername = this.botUsername; // Share with HTTP server
        logger.info(`Telegram bot connected: @${data.result.username} (ID: ${data.result.id})`);
      } else {
        logger.error('Failed to get bot info:', data);
        return;
      }
    } catch (error) {
      logger.error('Failed to connect to Telegram bot:', error);
      return;
    }

    if (config.telegram?.useWebhook) {
      logger.info('Telegram webhook mode enabled, registering webhook...');
      const webhookSet = await this.registerWebhook();
      if (!webhookSet) {
        logger.error('Failed to register webhook, falling back to polling mode');
        this.polling = true;
        this.pollUpdates();
      } else {
        logger.info('Webhook registered successfully');
      }
      return;
    }

    // Delete any existing webhook before starting polling
    await this.deleteWebhook();
    
    this.polling = true;
    logger.info('Starting Telegram polling...');
    
    // Start polling loop
    this.pollUpdates();
  }

  async pollUpdates() {
    if (!this.polling) return;

    try {
      const data = await this.api.getUpdates({
        offset: this.offset,
        timeout: 30,  // Long polling timeout
        allowed_updates: ['message', 'callback_query', 'my_chat_member']
      });
      
      if (data.ok && data.result.length > 0) {
        for (const update of data.result) {
          // Update offset to acknowledge this update
          this.offset = update.update_id + 1;
          
          // Process the update through our HTTP server handler
          await this.processUpdate(update);
        }
      }
    } catch (error) {
      logger.error('Telegram polling error:', error);
      // Wait before retrying on error
      await new Promise(resolve => setTimeout(resolve, 5000));
    }

    // Continue polling if still active
    if (this.polling) {
      // Use setImmediate to avoid blocking
      setImmediate(() => this.pollUpdates());
    }
  }

  async processUpdate(update) {
    // Determine update type
    let updateType = 'unknown';
    if (update.message) updateType = 'message';
    else if (update.callback_query) updateType = 'callback_query';
    else if (update.edited_message) updateType = 'edited_message';
    else if (update.channel_post) updateType = 'channel_post';
    else if (update.edited_channel_post) updateType = 'edited_channel_post';
    else if (update.inline_query) updateType = 'inline_query';
    else if (update.chosen_inline_result) updateType = 'chosen_inline_result';
    else if (update.my_chat_member) updateType = 'my_chat_member';
    else if (update.chat_member) updateType = 'chat_member';
    else if (update.chat_join_request) updateType = 'chat_join_request';
    
    const chatInfo = update.message?.chat || update.callback_query?.message?.chat || 
                     update.channel_post?.chat || update.my_chat_member?.chat ||
                     update.chat_member?.chat;
    
    logger.debug('Processing Telegram update:', {
      update_id: update.update_id,
      type: updateType,
      chat_id: chatInfo?.id,
      chat_type: chatInfo?.type,
      user_id: update.message?.from?.id || update.callback_query?.from?.id || 
               update.my_chat_member?.from?.id || update.chat_member?.from?.id,
      username: update.message?.from?.username || update.callback_query?.from?.username ||
                update.my_chat_member?.from?.username || update.chat_member?.from?.username
    });
    
    // Create a fake request/response to pass to our existing handler
    const fakeReq = {
      method: 'POST',
      url: '/callback/telegram',
      headers: {},
      on: () => {},  // Stub for event handlers
      setEncoding: () => {},
    };
    
    const fakeRes = {
      writeHead: () => {},
      end: () => {},
      headersSent: false,
      setHeader: () => {},
    };
    
    // Process through existing Telegram callback handler
    try {
      if (update.message) {
        logger.info(`Processing message from ${update.message.from?.username || 'unknown'} in chat ${chatInfo?.id}`);
        await this.httpServer.processTelegramMessage(update.message);
      } else if (update.callback_query) {
        logger.info(`Processing callback query from ${update.callback_query.from?.username || 'unknown'}`);
        await this.httpServer.processTelegramCallback(update.callback_query);
      } else if (update.edited_message) {
        // Ignore edited messages for now
        logger.debug('Ignoring edited message from Telegram');
      } else if (update.channel_post) {
        // Handle channel posts if needed
        logger.debug('Ignoring channel post from Telegram');
      } else if (update.my_chat_member || update.chat_member) {
        // Handle chat member updates (bot added/removed from chat)
        logger.info(`Chat member update: ${updateType}`, {
          chat_id: chatInfo?.id,
          new_status: update.my_chat_member?.new_chat_member?.status || update.chat_member?.new_chat_member?.status
        });
      } else {
        // Log other update types with more detail
        logger.debug(`Ignoring ${updateType} update from Telegram`);
      }
    } catch (error) {
      logger.error('Error processing Telegram update:', error);
    }
  }

  stop() {
    this.polling = false;
    if (this.pollInterval) {
      clearInterval(this.pollInterval);
      this.pollInterval = null;
    }
    logger.info('Telegram polling stopped');
  }

  async registerWebhook() {
    if (!config.telegram?.webhookUrl) {
      logger.error('Webhook URL not configured');
      return false;
    }

    let webhookUrl = `${config.telegram.webhookUrl}/callback/telegram`;
    
    // Add verification token to webhook URL if configured
    if (config.telegram.verificationToken) {
      const separator = webhookUrl.includes('?') ? '&' : '?';
      webhookUrl += `${separator}token=${config.telegram.verificationToken}`;
    }
    
    logger.info(`Registering webhook: ${webhookUrl}`);
    
    try {
      // First check current webhook status
      const webhookInfo = await this.api.getWebhookInfo();
      
      if (webhookInfo.ok) {
        logger.debug('Current webhook info:', {
          url: webhookInfo.result.url,
          has_custom_certificate: webhookInfo.result.has_custom_certificate,
          pending_update_count: webhookInfo.result.pending_update_count,
          last_error_message: webhookInfo.result.last_error_message
        });
        
        if (webhookInfo.result.url === webhookUrl) {
          logger.info('Webhook already registered with same URL');
          return true;
        }
      }
      
      // Register new webhook
      const data = await this.api.setWebhook(webhookUrl, {
        allowed_updates: ['message', 'callback_query', 'my_chat_member'],
        drop_pending_updates: false
      });
      
      if (data.ok) {
        logger.info(`Telegram webhook registered successfully`);
        
        // Verify webhook was set
        const verifyData = await this.api.getWebhookInfo();
        if (verifyData.ok) {
          logger.debug('Webhook verification:', {
            url: verifyData.result.url,
            pending_updates: verifyData.result.pending_update_count
          });
        }
        
        return true;
      } else {
        logger.error('Failed to set Telegram webhook:', data);
        return false;
      }
    } catch (error) {
      logger.error('Error registering Telegram webhook:', error);
      return false;
    }
  }

  async setWebhook(url) {
    if (!this.botToken) {
      logger.warn('Cannot set webhook: Telegram bot token not configured');
      return false;
    }

    try {
      let webhookUrl = url || `${config.telegram.webhookUrl}/callback/telegram`;
      
      // Add verification token to webhook URL if configured
      if (config.telegram.verificationToken) {
        const separator = webhookUrl.includes('?') ? '&' : '?';
        webhookUrl += `${separator}token=${config.telegram.verificationToken}`;
      }
      
      const data = await this.api.setWebhook(webhookUrl, {
        allowed_updates: ['message', 'callback_query', 'my_chat_member']
      });
      if (data.ok) {
        logger.info(`Telegram webhook set to: ${webhookUrl}`);
        return true;
      } else {
        logger.error('Failed to set Telegram webhook:', data);
        return false;
      }
    } catch (error) {
      logger.error('Error setting Telegram webhook:', error);
      return false;
    }
  }

  async deleteWebhook() {
    if (!this.botToken) {
      return false;
    }

    try {
      const data = await this.api.deleteWebhook();
      if (data.ok) {
        logger.info('Telegram webhook deleted');
        return true;
      } else {
        logger.error('Failed to delete Telegram webhook:', data);
        return false;
      }
    } catch (error) {
      logger.error('Error deleting Telegram webhook:', error);
      return false;
    }
  }
}
// Convert markdown text to Lark post format
export function convertMarkdownToLarkPost(markdown) {
  const lines = markdown.split('\n');
  const content = [];
  let currentParagraph = [];
  let inCodeBlock = false;
  let codeBlockContent = [];
  let codeBlockLang = '';
  
  function flushParagraph() {
    if (currentParagraph.length > 0) {
      content.push(currentParagraph);
      currentParagraph = [];
    }
  }
  
  function processInlineMarkdown(text) {
    const elements = [];
    let remaining = text;
    let lastIndex = 0;
    
    // Process inline elements with a simple state machine
    const patterns = [
      { regex: /\*\*([^*]+)\*\*/g, tag: 'bold' },           // **bold**
      { regex: /\*([^*]+)\*/g, tag: 'italic' },              // *italic*
      { regex: /_([^_]+)_/g, tag: 'italic' },                // _italic_
      { regex: /`([^`]+)`/g, tag: 'code' },                  // `code`
      { regex: /\[([^\]]+)\]\(([^)]+)\)/g, tag: 'link' },    // [text](url)
    ];
    
    // For simplicity, process each pattern type sequentially
    // In production, you'd want a more sophisticated parser
    
    // Handle bold
    remaining = remaining.replace(/\*\*([^*]+)\*\*/g, (match, p1, offset) => {
      if (offset > lastIndex) {
        elements.push({ tag: 'text', text: remaining.substring(lastIndex, offset) });
      }
      elements.push({ tag: 'text', text: p1, style: ['bold'] });
      lastIndex = offset + match.length;
      return '\x00'; // placeholder
    });
    
    // Handle remaining text after replacements
    const parts = remaining.split('\x00');
    const result = [];
    let elemIndex = 0;
    
    for (let i = 0; i < parts.length; i++) {
      if (parts[i]) {
        // Process other markdown in this part
        let processedText = parts[i];
        
        // Handle italic with *
        processedText = processedText.replace(/\*([^*]+)\*/g, (match, p1) => {
          return p1; // For now, just remove the markers
        });
        
        // Handle code
        processedText = processedText.replace(/`([^`]+)`/g, (match, p1) => {
          return p1; // For now, just remove the markers
        });
        
        // Handle links
        processedText = processedText.replace(/\[([^\]]+)\]\(([^)]+)\)/g, (match, p1, p2) => {
          return p1; // For now, just show link text
        });
        
        if (processedText) {
          result.push({ tag: 'text', text: processedText });
        }
      }
      if (elemIndex < elements.length && elements[elemIndex].text !== '\x00') {
        result.push(elements[elemIndex]);
        elemIndex++;
      }
    }
    
    return result.length > 0 ? result : [{ tag: 'text', text: text }];
  }
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    
    // Handle code blocks
    if (line.startsWith('```')) {
      if (!inCodeBlock) {
        flushParagraph();
        inCodeBlock = true;
        codeBlockLang = line.slice(3).trim();
        codeBlockContent = [];
      } else {
        inCodeBlock = false;
        currentParagraph.push({
          tag: 'text',
          text: codeBlockContent.join('\n'),
          style: ['codeBlock']
        });
        flushParagraph();
      }
      continue;
    }
    
    if (inCodeBlock) {
      codeBlockContent.push(line);
      continue;
    }
    
    // Handle headers
    if (line.startsWith('#')) {
      flushParagraph();
      const match = line.match(/^(#+)\s+(.+)/);
      if (match) {
        const level = match[1].length;
        const text = match[2];
        currentParagraph.push({
          tag: 'text',
          text: text,
          style: ['bold']
        });
        flushParagraph();
      }
      continue;
    }
    
    // Handle bullet points
    if (line.match(/^[\*\-\+]\s+/)) {
      flushParagraph();
      const text = line.replace(/^[\*\-\+]\s+/, '• ');
      currentParagraph = processInlineMarkdown(text);
      flushParagraph();
      continue;
    }
    
    // Handle numbered lists
    if (line.match(/^\d+\.\s+/)) {
      flushParagraph();
      const text = line;
      currentParagraph = processInlineMarkdown(text);
      flushParagraph();
      continue;
    }
    
    // Handle horizontal rules
    if (line.match(/^[\-\*]{3,}$/)) {
      flushParagraph();
      currentParagraph.push({
        tag: 'text',
        text: '─'.repeat(30)
      });
      flushParagraph();
      continue;
    }
    
    // Handle blockquotes
    if (line.startsWith('>')) {
      flushParagraph();
      const text = line.replace(/^>\s*/, '');
      currentParagraph.push({
        tag: 'text',
        text: '▍ ' + text,
        style: ['italic']
      });
      flushParagraph();
      continue;
    }
    
    // Handle empty lines
    if (line.trim() === '') {
      flushParagraph();
      content.push([{ tag: 'text', text: ' ' }]); // Empty line
      continue;
    }
    
    // Regular text
    currentParagraph = processInlineMarkdown(line);
    flushParagraph();
  }
  
  // Flush any remaining paragraph
  flushParagraph();
  
  // Ensure we have at least one element
  if (content.length === 0) {
    content.push([{ tag: 'text', text: markdown }]);
  }
  
  return {
    zh_cn: {
      title: '',
      content: content
    }
  };
}
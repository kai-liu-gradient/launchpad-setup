/**
 * Goals Prompts Factory
 * Centralized prompts for all goal-related operations
 */

import { basename } from 'path';

/**
 * Build the main goal analysis prompt for sync operations
 * @param {Array} goalFiles - Array of goal file paths to analyze
 * @param {Array} completedGoals - Array of already completed goals
 * @returns {string} The formatted prompt for Claude
 */
export function buildGoalAnalysisPrompt(goalFiles, completedGoals = []) {
  // Separate completed goals: simplified analysis vs manual overrides vs normal completed
  const simplifiedGoals = completedGoals.filter(g => g.simplifiedAnalysis);
  const manualOverrideGoals = completedGoals.filter(g => g.manualOverride && !g.simplifiedAnalysis);
  const normalCompletedGoals = completedGoals.filter(g => !g.manualOverride && !g.simplifiedAnalysis);

  // Exclude pre-scanned simplified goals from the files to read
  const simplifiedFileSet = new Set(simplifiedGoals.map(g => basename(g.file)));
  const filesToRead = goalFiles.filter(f => !simplifiedFileSet.has(basename(f)));
  const fileCount = filesToRead.length;
  const filesList = filesToRead.map(file => `- ${file}`).join('\n');

  // Count total cached goals that won't need to be output
  const cachedGoalsCount = simplifiedGoals.length + normalCompletedGoals.length + manualOverrideGoals.length;

  // Build context section for cached goals (for reference only, not output)
  let cachedGoalsContext = '';
  if (cachedGoalsCount > 0) {
    cachedGoalsContext = `
**CACHED GOALS (${cachedGoalsCount} total - DO NOT READ OR OUTPUT THESE):**
The following goals are already cached and will be automatically merged by the system.
You do NOT need to include them in your output - only output the NEW goals you analyze.

`;
    if (simplifiedGoals.length > 0) {
      cachedGoalsContext += `Pre-scanned completed/abandoned/cancelled: ${simplifiedGoals.length} goals (IDs: ${simplifiedGoals.map(g => g.id).join(', ')})\n`;
    }
    if (normalCompletedGoals.length > 0) {
      cachedGoalsContext += `Cached completed goals: ${normalCompletedGoals.length} goals (IDs: ${normalCompletedGoals.map(g => g.id).join(', ')})\n`;
    }
    if (manualOverrideGoals.length > 0) {
      cachedGoalsContext += `Manual override goals: ${manualOverrideGoals.length} goals (IDs: ${manualOverrideGoals.map(g => g.id).join(', ')})\n`;
    }
  }

  return `Analyze the project goal files and output ONLY the newly analyzed goals as CSV.
${cachedGoalsContext}
**Goal Files to Read and Analyze (${fileCount} files in this batch):**
${fileCount > 0 ? filesList : '(None - all goals are pre-scanned)'}

**IMPORTANT - Feel Free to Organize First (OPTIONAL):**
Before analyzing the files listed above, you can (if needed):
- Rename files to follow better naming conventions
- Fix formatting issues in markdown files
- Standardize phase markers if inconsistent
Only organize if files are messy. Skip this step if files are already well-organized.

**CRITICAL - Only Process Goal Files:**
- ONLY process .md files that start with a number (e.g., 001-name.md, 42-api.md)
- SKIP files like CACHE-SUMMARY.md, README.md, or any non-numeric files

**After Organizing (if needed), Analyze Each Goal:**
1. Read each goal file with the Read tool
2. Extract these fields:
   - **id**: Numeric prefix from filename (e.g., "042-api.md" -> 42)
   - **file**: The filename (e.g., "042-api.md")
   - **status**: **CRITICAL - ALWAYS read from Progress section's "Status:" field FIRST**
     - Look for "- Status:" or "- **Status**:" in the Progress/Status section
     - Use this EXPLICIT status value even if tasks/phases show different completion
     - ONLY infer status from task completion if Status field is completely missing or invalid
     - Example: If file says "Status: Completed" but has 0% tasks done, use "Completed"
   - **completionPct**: Calculate from tasks or phases (0-100)
   - **phaseCount**: Total phases (0 if task-based)
   - **phasesComplete**: Completed phases (0 if task-based)
   - **taskCount**: Total tasks (0 if phase-based)
   - **tasksComplete**: Completed tasks (0 if phase-based)
   - **startDate**: From Progress section (YYYY-MM-DD or -)
   - **completionDate**: From Progress section (YYYY-MM-DD or -)

**CRITICAL - Output Format (INCREMENTAL MODE):**
Output ONLY a CSV table containing the ${fileCount} goals you analyzed in this batch.
**DO NOT include the ${cachedGoalsCount} cached goals** - the system will merge them automatically.

\`\`\`csv
id,file,status,completionPct,phaseCount,phasesComplete,taskCount,tasksComplete,startDate,completionDate
2,"002-api.md","In Progress",60,0,0,10,6,2025-01-16,-
42,"042-ui.md","Not Started",0,5,0,0,0,-,-
\`\`\`

**CSV Rules:**
1. NO text before or after the CSV
2. Use quotes for filename and status fields
3. Use "-" for null/empty dates
4. Numbers should be plain (no quotes)
5. **ONLY output the ${fileCount} newly analyzed goals** (NOT the ${cachedGoalsCount} cached ones)
6. Must include header row exactly as shown

**Status Values (NORMALIZE to exact spelling):**
- "Not Started" (for: "Not Started", "Pending", etc.)
- "In Progress" (for: "In Progress", "Ongoing", etc.)
- "Completed" (for: "Completed", "Complete", "COMPLETED", "✅ COMPLETED", "100% Complete", "Done", etc.)
- "Abandoned" (for: "Abandoned", "ABANDONED", etc.)
- "Cancelled" (for: "Cancelled", "Canceled", etc.)
- "On Hold" (for: "On Hold", "Paused", etc.)

**CRITICAL - Status Priority Rules:**
1. **ALWAYS use the explicit "Status:" field** from the Progress/Status section
2. The explicit status is the SOURCE OF TRUTH, even if:
   - Tasks show 0% completion but status says "Completed" → use "Completed"
   - Tasks show 100% completion but status says "In Progress" → use "In Progress"
   - Task counts don't match the status → use the explicit status
3. **ONLY infer status** from task/phase completion if:
   - The Status field is completely missing from the file, OR
   - The Status field contains invalid/unrecognizable text
4. If inferring (Status field missing): 100% → Completed, 1-99% → In Progress, 0% → Not Started

**IMPORTANT:** If the status in the file contains emojis or variations like "✅ COMPLETED", "Complete", or "100%",
normalize it to the standard "Completed" format in your CSV output.

**IMPORTANT:**
- If organizing files, do it silently - don't describe what you did
- Output ONLY the CSV table with ONLY the newly analyzed goals
- The system will automatically merge with cached goals and convert to JSON cache`;
}

/**
 * Build validation/fix prompt for problematic goals
 * @param {Array} problematicGoalFiles - Array of problematic goal filenames
 * @param {Array} validationErrors - Array of validation error messages
 * @param {Map} validationMap - Optional map of filename to specific errors
 * @returns {string} The formatted prompt for Claude
 */
export function buildValidationPrompt(problematicGoalFiles, validationErrors, validationMap = null) {
  // Build detailed file list with specific errors - CRITICAL for fixing
  let filesList;
  if (validationMap && validationMap.size > 0) {
    filesList = problematicGoalFiles.map(file => {
      const filename = basename(file);
      const fileErrors = validationMap.get(filename);
      if (fileErrors && fileErrors.length > 0) {
        // Format each error on its own line with explanation
        const errorDetails = fileErrors.map(err => `    ⚠️ ${err}`).join('\n');
        return `📄 **${file}**\n${errorDetails}`;
      }
      return `📄 **${file}** (validation issue detected)`;
    }).join('\n\n');
  } else {
    filesList = problematicGoalFiles.map(file => `📄 **${file}**`).join('\n');
  }

  // Build common error patterns section for context
  let commonPatternsSection = '';
  if (validationErrors && validationErrors.length > 0) {
    const uniqueErrors = [...new Set(validationErrors)].slice(0, 5);
    commonPatternsSection = `\n**Common Error Patterns Found:**\n${uniqueErrors.map(e => `- ${e}`).join('\n')}\n`;
  }

  return `# Goal File Validation Fix

**CRITICAL:** The files listed below failed validation. You MUST fix the SPECIFIC ERRORS shown for each file.

## Files to Fix (${problematicGoalFiles.length} file(s))

${filesList}
${commonPatternsSection}
## Error Types and How to Fix Them

| Error | Cause | Fix |
|-------|-------|-----|
| "Missing Status line in Progress section" | No \`- Status:\` line in Progress section | Add \`- Status: **Not Started**\` (or appropriate status) to Progress section |
| "Invalid status: X needs normalization" | Status value not in valid list | Change to one of: Not Started, In Progress, Completed, Abandoned, Cancelled, On Hold |
| "N malformed task checkboxes" | Checkboxes not in \`- [ ]\` or \`- [x]\` format | Fix to use standard markdown checkbox format |

## Step-by-Step Fix Process

For EACH file listed above:

1. **Read the file** using Read tool
2. **Identify the EXACT error** from the list above for that file
3. **Apply the specific fix:**
   - For "Missing Status line": Add to Progress section: \`- Status: **In Progress**\` (or infer from task completion)
   - For "Invalid status": Replace with normalized value (e.g., "Complete" → "Completed", "WIP" → "In Progress")
   - For "malformed checkboxes": Ensure format is \`- [ ] task\` or \`- [x] task\`
4. **Verify the fix** addresses the specific error mentioned
5. **Save the file** using Edit tool

## Valid Status Values (use EXACTLY as shown)
- "Not Started"
- "In Progress"
- "Completed"
- "Abandoned"
- "Cancelled"
- "On Hold"

## Status Inference Rules (only if Status field is missing)
- 100% tasks complete → "Completed"
- 1-99% tasks complete → "In Progress"
- 0% tasks complete → "Not Started"

## Output Required

After fixing all files, provide:

\`\`\`
### Fix Summary
- filename.md: [specific error] → [specific fix applied]
- filename2.md: [specific error] → [specific fix applied]
\`\`\`

**IMPORTANT:**
- Fix the EXACT errors listed for each file
- Do NOT generate cache JSON
- Do NOT modify content unrelated to the validation errors`;
}

/**
 * Build prompt for adding new goals
 * @param {string} description - Goal description from user
 * @param {Object} options - Additional options (existing content, PRD, etc.)
 * @returns {string} The formatted prompt for Claude
 */
export function buildAddGoalPrompt(description, options = {}) {
  const { existingContent, prdContent, goalId, targetFile, existingGoalTitles, multi } = options;

  let prompt = '';

  if (existingContent) {
    prompt = `You are helping to ${options.merge ? 'merge updates into' : 'update'} an existing goal file.

**Current Goal Content:**
${existingContent}

**Updates Requested:**
${description || 'No specific updates provided'}

${options.merge ? '**IMPORTANT:** Merge the updates intelligently. Do not replace everything. Keep existing completed tasks and progress while adding new requirements.' : '**IMPORTANT:** Replace the entire content with an updated version based on the request.'}

Update the goal file following the standard template structure. Ensure all sections are present and properly formatted.

## ⚠️ CRITICAL - Repeat Failure Detection (MANDATORY)
**After 3 FAILED ATTEMPTS of the same operation, you MUST stop and break:**
1. **Count failures** - Track how many times the same operation fails
2. **After 3 failures: STOP immediately** - do not attempt a 4th time
3. **Output the break signal**: \`__ANICODE_BREAK(your reason here)\`
4. The reason should describe what is failing and why you cannot proceed

**Failure Types to Track:**
- File write/edit permission denied
- File read permission denied
- Command execution failures
- Any repeated error pattern

**Examples:**
- \`__ANICODE_BREAK(Cannot write to goal file - permission denied after 3 attempts)\`
- \`__ANICODE_BREAK(Tool permission not granted for Write commands)\`

**DO NOT continue attempting the same failing operation beyond 3 tries.**`;
  } else {
    // New goal creation - comprehensive analysis approach
    prompt = `Please consider the following implementation plan, review what is needed, and identify any conflicts or improvements to the pd/goals stage and goal. Update the related goal file or create a new one as necessary. Always follow CLAUDE.md guidance when preparing the goal plan.

**Implementation Request:**
${description}

${prdContent ? `**Project Requirements Document (PRD):**
${prdContent}

Review the PRD to ensure the goal aligns with project objectives and architecture.` : ''}

${existingGoalTitles.length > 0 ? `**Existing Goals in Project:** ${existingGoalTitles.length} goal files exist in pd/goals/

**IMPORTANT - Discover Goals Dynamically:**
Before creating a new goal, you MUST:
1. **List the goals folder**: Use Glob or LS tool to list files in pd/goals/*.md
2. **Review relevant goals**: Read any goal files that might overlap with this request
3. **DO NOT rely on this list** - always check the actual folder for current state

**Analysis Required:**
1. **Check for Conflicts:** Review existing goals to identify:
   - Duplicate or overlapping functionality
   - Conflicting approaches or architectures
   - Dependencies that should be referenced

2. **Identify Improvements:** Consider:
   - Should this merge with an existing goal instead of creating new?
   - Are there missing prerequisites that need separate goals?
   - Does this goal need to be split into multiple stages?

3. **Determine Action:** Decide whether to:
   - Create a new goal (if truly distinct)
   - Suggest updating an existing goal (if overlapping)
   - Recommend splitting into multiple goals (if too broad)` : ''}

**Your Task:**
1. **Analyze Requirements:** Understand what needs to be implemented
2. **Review Context:** Check PRD and existing goals for alignment
3. **Determine Filename:** Review the suggested filename below and decide if it needs improvement
4. **Plan Structure:** Determine appropriate goal organization
5. **Follow Standards:** Adhere to CLAUDE.md goal template standards
6. **Create Goal File:** Use Write tool to create the complete, actionable goal document

**Goal ID:** ${goalId}
**Suggested Target File:** ${targetFile}

**IMPORTANT - Filename Flexibility:**
The filename above is auto-generated from your description. You can:
- Use it as-is if it accurately describes the goal
- Rename it to better match the goal's purpose (e.g., "042-user-auth.md" → "042-jwt-authentication.md")
- Keep the numeric prefix (${String(goalId).padStart(3, '0')}-) but change the descriptive part
- Follow conventions: lowercase, hyphens, descriptive (e.g., "042-api-endpoints.md")

The goal index (#${goalId}) is already reserved in the cache, so feel free to optimize the filename for clarity.

**Standard Goal Template (follow CLAUDE.md):**

# Goal: [Clear, Concise Goal Title]

## Objective
[2-3 sentences describing what this goal aims to achieve and why it's important.
Reference PRD sections if applicable. Explain business value and technical rationale.]

## Tasks
[Create specific, actionable tasks. Use checkboxes for trackable items.
Break down into implementable chunks. Each task should be clear and testable.]
- [ ] Task 1: [Specific action with clear deliverable]
- [ ] Task 2: [Specific action with clear deliverable]
- [ ] Task 3: [Specific action with clear deliverable]
[Add 5-15 tasks as needed for complete implementation]

## Acceptance Criteria
[List specific, measurable criteria that define when this goal is complete.
Should be testable and verifiable.]
- [Criterion 1: Specific, measurable outcome]
- [Criterion 2: Specific, measurable outcome]
- [Criterion 3: Specific, measurable outcome]

## Progress
- Status: **Not Started**
- Start Date: -
- Completion Date: -
- Notes: [Any relevant notes, blockers, or considerations]

## Dependencies
- [List any dependencies on other goals by ID/name]
- [List any external dependencies (APIs, services, tools)]
- [Use "None" if no dependencies]

**Quality Checklist Before Output:**
- [ ] Goal aligns with PRD requirements
- [ ] No conflicts with existing goals
- [ ] Tasks are specific and actionable
- [ ] Acceptance criteria are measurable
- [ ] Dependencies are identified
- [ ] Follows CLAUDE.md template standards${multi ? `

**IMPORTANT - Multi-Goal Mode:**
You might create several goals for this need. If the request is broad or covers multiple distinct areas, split it into separate goal files with appropriate IDs (${goalId}, ${goalId + 1}, ${goalId + 2}, etc.). Each goal should be focused and self-contained.

**⚠️ CRITICAL - Goal Execution Order & Dependency Rules:**
Goals are executed in **index order** (lowest ID first: ${goalId}, then ${goalId + 1}, then ${goalId + 2}, etc.).
A goal must NEVER depend on a goal with a higher ID, as that goal has not been executed yet — this creates a **dependency deadlock**.

**Dependency Rules:**
- ✅ Goal ${goalId + 1} CAN depend on goal ${goalId} (earlier goal, already executed)
- ❌ Goal ${goalId} must NOT depend on goal ${goalId + 1} (later goal, not yet executed)
- Structure goals so foundational/prerequisite work has lower IDs

**After creating all goals, review the full set:**
1. Check that no goal references a higher-numbered goal as a dependency
2. Reorder or renumber goals if dependency flow is incorrect
3. Ensure the dependency chain flows forward (low ID → high ID), never backward` : ''}

## ⚠️ CRITICAL - Repeat Failure Detection (MANDATORY)
**After 3 FAILED ATTEMPTS of the same operation, you MUST stop and break:**
1. **Count failures** - Track how many times the same operation fails
2. **After 3 failures: STOP immediately** - do not attempt a 4th time
3. **Output the break signal**: \`__ANICODE_BREAK(your reason here)\`
4. The reason should describe what is failing and why you cannot proceed

**Failure Types to Track:**
- File write/edit permission denied
- File read permission denied
- Command execution failures
- Any repeated error pattern

**Examples of when to use __ANICODE_BREAK:**
- Same file write failing 3x: \`__ANICODE_BREAK(Cannot write to pd/goals/042-feature.md - permission denied after 3 attempts)\`
- Goal folder access denied: \`__ANICODE_BREAK(Cannot access pd/goals/ folder - permission denied)\`
- Stuck on permission issue: \`__ANICODE_BREAK(Tool permission not granted for Write/Read commands)\`

**DO NOT:**
- Continue attempting the same failing operation beyond 3 tries
- Silently ignore permission failures
- Keep retrying indefinitely`;
  }

  return prompt;
}

/**
 * Build prompt for goal loop execution
 * @param {Object} goal - The goal object to work on
 * @param {string} prdContent - PRD content for context
 * @param {Object} options - Optional settings for prompt customization
 * @param {boolean} options.autonomous - Enable autonomous mode (no user decisions)
 * @param {boolean} options.autoCommit - Include auto-commit instructions
 * @param {boolean} options.detailedSummary - Request detailed summary at end
 * @param {string} options.iterationHistoryPath - Path to iteration history file
 * @param {string} options.iterationHistoryContent - Formatted iteration history for context
 * @param {boolean} options.isFreshStart - Whether this is a fresh start (no previous iterations)
 * @param {Object} options.lastIteration - Last iteration info for context awareness
 * @returns {string} The formatted prompt for Claude
 */
export function buildGoalExecutionPrompt(goal, prdContent, options = {}) {
  const {
    iterationHistoryPath,
    iterationHistoryContent,
    isFreshStart,
    lastIteration
  } = options;

  // Build goal file reference
  const goalFileRef = goal.path
    ? (goal.path.startsWith('pd/goals/') ? goal.path : `pd/goals/${basename(goal.path)}`)
    : (goal.file ? `pd/goals/${goal.file}` : null);

  // Build iteration context section
  let iterationContextSection = '';
  if (!isFreshStart && iterationHistoryContent) {
    iterationContextSection = `
## 📜 Iteration History Context
**This is NOT a fresh start.** Previous iterations have been attempted on this goal.
**You MUST read and understand the history below before continuing.**

${iterationHistoryContent}
`;
  }

  // Build last failure warning if applicable
  let lastFailureWarning = '';
  if (lastIteration && lastIteration.status === 'failed') {
    lastFailureWarning = `
## ⚠️ CRITICAL - Last Iteration Failed
**The previous iteration (${lastIteration.iterationNumber}) FAILED!**
${lastIteration.failureReason ? `**Failure Reason:** ${lastIteration.failureReason}` : ''}
${lastIteration.conclusion ? `**Last Output:**\n\`\`\`\n${lastIteration.conclusion.substring(0, 800)}\n\`\`\`` : ''}

**You MUST:**
1. Understand WHY the last iteration failed
2. Avoid repeating the same mistake
3. Take a different approach if necessary
4. Address the root cause, not just the symptoms

`;
  }

  // Determine step numbers based on whether this is a fresh start
  const hasHistory = !isFreshStart && iterationHistoryPath;

  let prompt = `# Automated Goal Implementation

**GOAL FILE:** ${goalFileRef}
${iterationHistoryPath ? `**ITERATION HISTORY:** ${iterationHistoryPath}` : ''}
${!isFreshStart ? `**ITERATION STATUS:** Continuing from previous iterations` : `**ITERATION STATUS:** Fresh start`}
${lastFailureWarning}${iterationContextSection}
## Your Task
1. Read the goal file to see tasks and current progress
${hasHistory ? `2. **IMPORTANT:** Review the iteration history above to understand what was already attempted
3. Learn from previous attempts - don't repeat failed approaches
4. Implement next pending task(s)` : '2. Implement next pending task(s)'}
${hasHistory ? '5. Update goal file with completed tasks [x] and progress notes' : '3. Update goal file with completed tasks [x] and progress notes'}

## Critical Requirements
- **ALWAYS update ${goalFileRef}** after work
- Mark completed tasks with [x]
- Update Progress section (status, dates, notes)
- Document your approach and thinking
${!isFreshStart ? '- **Review iteration history** to avoid repeating mistakes' : ''}
- Services auto-reload - no need to restart
- Follow CLAUDE.md standards

## After Implementation
1. Fix any build/runtime errors
2. **Update goal file** (mark tasks, update status, add notes)
3. **DO NOT commit** - loop handles this

## ⚠️ CRITICAL - Goal File Update Protocol
**BEFORE updating the goal file, you MUST:**
1. **Read ${goalFileRef} from filesystem first** using the Read tool
2. This ensures you have the latest version of the file
3. The file may have been modified by other processes or manually
4. **NEVER update based on cached or stale content**
5. After reading the fresh content, then apply your updates

**Update Procedure:**
1. Read tool → Get latest goal file content
2. Identify which tasks you completed
3. Mark those tasks with [x]
4. Update Progress section (status, completion %, dates, notes)
5. Write/Edit tool → Save the updated content

## ⚠️ CRITICAL - Repeat Failure Detection (MANDATORY)
**After 3 FAILED ATTEMPTS of the same operation, you MUST stop and break:**
1. **Count failures** - Track how many times the same operation fails
2. **After 3 failures: STOP immediately** - do not attempt a 4th time
3. **Output the break signal**: \`__ANICODE_BREAK(your reason here)\`
4. The reason should describe what is failing and why you cannot proceed

**Failure Types to Track:**
- File write/edit permission denied
- File read permission denied
- Command execution failures
- API/network errors
- Any repeated error pattern

**Examples of when to use __ANICODE_BREAK:**
- Same file read/write failing 3x: \`__ANICODE_BREAK(Cannot write to /path/file.js - permission denied after 3 attempts)\`
- Command failing in loop: \`__ANICODE_BREAK(npm install keeps failing with EACCES error)\`
- Stuck on permission issue: \`__ANICODE_BREAK(Tool permission not granted for Bash commands)\`
- Goal file update blocked: \`__ANICODE_BREAK(Goal file update failed 3x - Write permission not granted)\`

**DO NOT:**
- Continue attempting the same failing operation beyond 3 tries
- Bury failures in summary - report them FIRST
- Treat permission denials as minor issues

## Output Format
Provide brief summary:

**⚠️ BLOCKERS FIRST (if any):**
- List ANY permission failures, file write errors, or tool failures AT THE TOP
- If goal file was NOT updated, state: "⚠️ BLOCKER: Could not update goal file - [reason]"
- Failed operations are CRITICAL and must be prominently reported, not buried

**Then provide:**
- Tasks completed
- Implementation notes
- Completion %
- Confirmation you updated goal file (or explicit statement that you COULD NOT)

**CRITICAL - Failure Visibility:**
- Any tool/permission failure must appear in the FIRST line of your summary
- Wrong: "Goal file update attempted - waiting for permission" (buried at end)
- Right: "⚠️ BLOCKER: Write permission denied for goal file after 3 attempts" (first line)

Proceed with implementation.`;

  return prompt;
}

/**
 * Build prompt for progress update operations
 * @param {Object} goal - The goal object
 * @param {string} progressUpdate - Progress update description
 * @returns {string} The formatted prompt for Claude
 */
export function buildProgressUpdatePrompt(goal, progressUpdate) {
  // Always use relative path format to avoid permission issues with absolute paths
  const goalFilePath = goal.path
    ? (goal.path.startsWith('pd/goals/') ? goal.path : `pd/goals/${basename(goal.path)}`)
    : (goal.file ? `pd/goals/${goal.file}` : null);

  return `Update the progress for goal "${goal.title || goal.file}" based on this information:

**Current Goal Status (from cache):**
- File: ${goal.file}
- Status: ${goal.status || goal.progress?.status}
- Completion: ${goal.completionPercentage || 0}%
- Tasks Complete: ${goal.tasksComplete || 0}/${goal.taskCount || 0}

**Progress Update:**
${progressUpdate}

**⚠️ CRITICAL - Read Before Update:**
1. **FIRST: Read the goal file from filesystem** (${goalFilePath})
   - Use the Read tool to get the latest version
   - The cached status above may be stale
   - The file may have been manually edited or modified by other processes
2. **THEN: Apply the updates** based on the progress update above

**Instructions:**
1. Read the current goal file from filesystem (REQUIRED)
2. Update task checkboxes based on the progress description
3. Update the Status field if needed (Not Started, In Progress, Completed)
4. Update dates if milestones are reached
5. Add any relevant notes to the Progress section

**Important:**
- Mark tasks as complete with [x] checkboxes
- Only mark tasks complete if explicitly mentioned in the update
- Update completion percentage based on actual task completion
- Preserve all existing content not related to progress`;
}

/**
 * Build prompt for goal review operations
 * Reviews if a goal is actually completed or was accidentally marked as completed
 * @param {Object} goal - The goal object to review
 * @param {string} goalContent - The full content of the goal file
 * @param {string} userConcern - User's concern or comment about the goal
 * @param {Object} options - Additional options
 * @returns {string} The formatted prompt for Claude
 */
export function buildGoalReviewPrompt(goal, goalContent, userConcern, options = {}) {
  const { prdContent, iterationHistory } = options;

  // Always use relative path format to avoid permission issues with absolute paths
  const goalFilePath = goal.path
    ? (goal.path.startsWith('pd/goals/') ? goal.path : `pd/goals/${basename(goal.path)}`)
    : (goal.file ? `pd/goals/${goal.file}` : null);

  return `# Goal Review & Verification

You are reviewing a goal to verify if its completion status is accurate. The user has concerns about whether this goal was actually completed or accidentally marked as completed.

## Goal Information
- **Goal ID:** ${goal.id}
- **File:** ${goal.file}
- **Path:** ${goalFilePath}
- **Cached Status:** ${goal.status || goal.progress?.status || 'Unknown'}
- **Cached Completion:** ${goal.completionPercentage || 0}%
- **Tasks:** ${goal.tasksComplete || 0}/${goal.taskCount || 0} complete
- **Phases:** ${goal.phasesComplete || 0}/${goal.phaseCount || 0} complete

## Current Goal Content
\`\`\`markdown
${goalContent}
\`\`\`

## User's Concern
${userConcern || 'No specific concern provided - please verify the overall completion status.'}

${prdContent ? `## Project Requirements (PRD)
${prdContent}
` : ''}

${iterationHistory ? `## Recent Iteration History
${iterationHistory}
` : ''}

## Your Review Task

**DEEPLY ANALYZE the goal and user's concern:**

1. **Task-by-Task Verification:**
   - Go through EACH task in the goal
   - For tasks marked [x] (completed), verify:
     - Is the implementation actually done?
     - Can you find evidence in the codebase?
     - Does the implementation meet acceptance criteria?
   - For tasks marked [ ] (incomplete), verify:
     - Are they truly incomplete?
     - Were they perhaps done but not marked?

2. **Status Accuracy Check:**
   - Does the current status reflect reality?
   - If marked "Completed", is ALL work truly done?
   - If marked "In Progress", what's the actual completion level?
   - Are there hidden blockers or issues?

3. **User Concern Analysis:**
   - Carefully consider the user's specific concern
   - Investigate if their suspicion is valid
   - Look for evidence supporting or refuting their concern

4. **Codebase Verification (if needed):**
   - Use Read/Grep/Glob tools to verify implementations
   - Check if features mentioned in tasks actually exist
   - Verify acceptance criteria are met

## Actions Required

After your analysis, you MUST:

1. **Update the Goal File** (${goalFilePath}):
   - Correct any incorrectly marked tasks
   - Update the Status field to reflect actual state
   - Update completion percentage accurately
   - Add detailed notes in the Progress section explaining:
     - What was reviewed
     - What issues were found (if any)
     - What corrections were made
     - Current actual state

2. **Provide Summary:**
   - What was the original status vs actual status?
   - Which tasks needed correction?
   - What evidence supported your findings?
   - What is the corrected completion percentage?

## Output Format

After making corrections, provide a summary:

### Review Summary
- **Original Status:** [status from file]
- **Corrected Status:** [new status if changed, or "No change needed"]
- **Original Completion:** [X]%
- **Corrected Completion:** [Y]%

### Findings
- [List key findings from your review]
- [Note any tasks that were incorrectly marked]
- [Note any missing implementations]

### Actions Taken
- [List changes made to the goal file]
- [Explain rationale for changes]

### Recommendations
- [Any follow-up actions needed]
- [Tasks that should be prioritized]

Proceed with the review.`;
}
/**
 * Healthcheck Prompt Builder
 * Generates techstack-aware prompts for analysis and fixes
 */

/**
 * Fix commands and strategies per techstack
 */
const TECHSTACK_FIX_STRATEGIES = {
  node: {
    name: 'Node.js',
    commands: {
      audit: 'npm audit',
      fix: 'npm audit fix',
      fixForce: 'npm audit fix --force',
      update: 'npm update',
      outdated: 'npm outdated',
      install: 'npm install'
    },
    fixSteps: [
      'Run `npm audit fix` to auto-fix vulnerabilities',
      'For remaining issues, evaluate `npm audit fix --force` (may have breaking changes)',
      'Manually update packages that cannot be auto-fixed',
      'Run `npm audit` to verify fixes',
      'Run tests to ensure nothing is broken'
    ],
    warnings: [
      'Major version updates may introduce breaking changes',
      'Always run tests after fixing',
      'Check package changelogs for migration guides'
    ]
  },
  python: {
    name: 'Python',
    commands: {
      audit: 'pip-audit || safety check',
      fix: 'pip install --upgrade',
      update: 'pip list --outdated',
      install: 'pip install -r requirements.txt'
    },
    fixSteps: [
      'Run `pip-audit` or `safety check` to identify vulnerabilities',
      'Update vulnerable packages with `pip install --upgrade <package>`',
      'If using requirements.txt, update version pins',
      'If using pyproject.toml, update dependency versions',
      'Run `pip-audit` again to verify fixes',
      'Run tests to ensure compatibility'
    ],
    warnings: [
      'Check compatibility with your Python version',
      'Virtual environment should be active',
      'Update requirements.txt/pyproject.toml after fixing'
    ]
  },
  go: {
    name: 'Go',
    commands: {
      audit: 'govulncheck ./...',
      fix: 'go get -u',
      update: 'go get -u ./...',
      tidy: 'go mod tidy'
    },
    fixSteps: [
      'Run `govulncheck ./...` to identify vulnerabilities',
      'Update specific packages with `go get -u <package>@latest`',
      'Run `go mod tidy` to clean up go.mod',
      'Run `govulncheck` again to verify fixes',
      'Run `go test ./...` to ensure nothing is broken'
    ],
    warnings: [
      'Check Go version compatibility',
      'Major version updates may require import path changes',
      'Run go mod tidy after updates'
    ]
  },
  rust: {
    name: 'Rust',
    commands: {
      audit: 'cargo audit',
      fix: 'cargo update',
      update: 'cargo update',
      build: 'cargo build'
    },
    fixSteps: [
      'Run `cargo audit` to identify vulnerabilities',
      'Update dependencies with `cargo update`',
      'For specific packages: `cargo update -p <package>`',
      'Run `cargo audit` again to verify fixes',
      'Run `cargo build` and `cargo test` to verify'
    ],
    warnings: [
      'Check MSRV (Minimum Supported Rust Version)',
      'Semver-compatible updates are usually safe',
      'Major version updates may need Cargo.toml changes'
    ]
  },
  java: {
    name: 'Java',
    commands: {
      audit: 'mvn dependency-check:check || ./gradlew dependencyCheckAnalyze',
      update: 'mvn versions:display-dependency-updates',
      fix: 'mvn versions:use-latest-releases'
    },
    fixSteps: [
      'Run dependency vulnerability scan',
      'Review vulnerable dependencies in pom.xml or build.gradle',
      'Update dependency versions to patched releases',
      'Run `mvn verify` or `./gradlew build` to verify',
      'Run tests to ensure compatibility'
    ],
    warnings: [
      'Check Java version compatibility',
      'Enterprise dependencies may have LTS versions',
      'Update parent POM if using Spring Boot or similar'
    ]
  }
};

/**
 * Build analysis prompt for a techstack
 * @param {string} stackKey - Techstack key (node, python, etc.)
 * @param {Object} data - Healthcheck data
 * @param {string} outputPath - Path to write analysis
 * @returns {string} Analysis prompt
 */
export function buildAnalysisPrompt(stackKey, data, outputPath) {
  const strategy = TECHSTACK_FIX_STRATEGIES[stackKey];
  if (!strategy) {
    return buildGenericAnalysisPrompt(data, outputPath);
  }

  const { summary, vulnerabilities, outdated, config } = data;

  let prompt = `Analyze this ${strategy.name} project healthcheck data and write a detailed analysis report.

## Task
1. Analyze the healthcheck data below
2. For HIGH or CRITICAL vulnerabilities, search the web for:
   - CVE details and exploit information
   - Recommended fixes and patches
   - Whether it's actively exploited
3. Write your analysis to: ${outputPath}

## Output File Format (${outputPath})
Write a markdown file with these sections:
- **Summary**: 2-3 sentence overview
- **Risk Assessment**: Overall risk level (Critical/High/Medium/Low)
- **Critical Findings**: List critical and high severity issues with web research
- **Recommendations**: Prioritized action items
- **Package Updates**: Which packages need immediate attention

## ${strategy.name} Fix Commands Reference
${strategy.fixSteps.map((s, i) => `${i + 1}. ${s}`).join('\n')}

## Healthcheck Data
\`\`\`json
${JSON.stringify(data, null, 2)}
\`\`\`
`;

  if (vulnerabilities && vulnerabilities.length > 0) {
    prompt += `
## IMPORTANT: Web Search Required
Search the web for CVE details on high/critical vulnerabilities:
${vulnerabilities.map(v => `- ${v.name} (${v.severity})`).join('\n')}
`;
  }

  prompt += `
After writing the analysis file, output a brief 3-5 line summary.`;

  return prompt;
}

/**
 * Build fix prompt for a techstack
 * @param {string} stackKey - Techstack key (node, python, etc.)
 * @param {Object} report - Full healthcheck report
 * @returns {string} Fix prompt
 */
export function buildFixPrompt(stackKey, report) {
  const strategy = TECHSTACK_FIX_STRATEGIES[stackKey];
  if (!strategy) {
    return buildGenericFixPrompt(report);
  }

  const { summary } = report;
  const stackData = report.stacks[stackKey] || {};
  const vulnerabilities = stackData.audit?.vulnerabilities || {};

  const highCriticalVulns = Object.entries(vulnerabilities)
    .filter(([_, v]) => v.severity === 'critical' || v.severity === 'high')
    .map(([name, v]) => `${name} (${v.severity})`);

  let prompt = `Fix the security vulnerabilities in this ${strategy.name} project.

## Healthcheck Summary
- Health Score: ${summary.healthScore}/100
- Critical: ${summary.critical}, High: ${summary.high}, Medium: ${summary.medium}, Low: ${summary.low}
${highCriticalVulns.length > 0 ? `- High/Critical packages: ${highCriticalVulns.join(', ')}` : ''}

## Fix Strategy for ${strategy.name}
${strategy.fixSteps.map((s, i) => `${i + 1}. ${s}`).join('\n')}

## Available Commands
${Object.entries(strategy.commands).map(([k, v]) => `- ${k}: \`${v}\``).join('\n')}

## Warnings
${strategy.warnings.map(w => `- ${w}`).join('\n')}

## Tasks
1. Run the appropriate audit/fix commands for ${strategy.name}
2. Evaluate which fixes are safe to apply automatically
3. For breaking changes, document but don't force unless clearly safe
4. Verify fixes by running audit again
5. Run tests if available to ensure nothing is broken

## Important
- Do NOT break the project
- If a fix requires major version bump, note it but be cautious
- Output a summary of what was fixed and what remains

Start by running the audit command and then apply fixes.`;

  return prompt;
}

/**
 * Build generic analysis prompt for unknown techstacks
 */
function buildGenericAnalysisPrompt(data, outputPath) {
  return `Analyze this project healthcheck data and write analysis to ${outputPath}.

## Data
\`\`\`json
${JSON.stringify(data, null, 2)}
\`\`\`

Write a markdown report with: Summary, Risk Assessment, Critical Findings, Recommendations.
After writing, output a brief summary.`;
}

/**
 * Build generic fix prompt for unknown techstacks
 */
function buildGenericFixPrompt(report) {
  return `Fix the security vulnerabilities in this project.

## Summary
- Health Score: ${report.summary.healthScore}/100
- Issues: Critical=${report.summary.critical}, High=${report.summary.high}, Medium=${report.summary.medium}, Low=${report.summary.low}

## Tasks
1. Identify the package manager and audit tools available
2. Run appropriate audit and fix commands
3. Verify fixes were applied
4. Document what was fixed and what remains

Output a summary of actions taken.`;
}

/**
 * Get fix strategy for a techstack
 * @param {string} stackKey - Techstack key
 * @returns {Object|null} Fix strategy or null
 */
export function getFixStrategy(stackKey) {
  return TECHSTACK_FIX_STRATEGIES[stackKey] || null;
}

/**
 * Get all supported techstacks
 * @returns {string[]} Array of techstack keys
 */
export function getSupportedTechstacks() {
  return Object.keys(TECHSTACK_FIX_STRATEGIES);
}

export { TECHSTACK_FIX_STRATEGIES };

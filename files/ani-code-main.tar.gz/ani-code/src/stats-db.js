import Database from 'better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { logger } from './logger.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export class StatsDB {
  constructor(dbPath = null) {
    const defaultPath = path.join(__dirname, '../data/stats.db');
    this.dbPath = dbPath || defaultPath;
    this.db = null;
  }

  initialize() {
    try {
      // Ensure the directory exists before creating the database
      const dbDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dbDir)) {
        fs.mkdirSync(dbDir, { recursive: true });
        logger.debug(`Created stats database directory: ${dbDir}`);
      }

      this.db = new Database(this.dbPath);
      this.db.pragma('journal_mode = WAL');
      this.db.pragma('foreign_keys = ON');

      // Create stats table
      this.db.exec(`
        CREATE TABLE IF NOT EXISTS task_stats (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          task_id TEXT NOT NULL,
          created_at INTEGER NOT NULL,
          completed_at INTEGER,
          cancelled_at INTEGER,
          duration_ms INTEGER,
          workspace TEXT,
          model TEXT,
          provider_id TEXT,
          cost_usd REAL,
          input_tokens INTEGER,
          output_tokens INTEGER,
          total_tokens INTEGER,
          prompt_preview TEXT,
          output_preview TEXT,
          status TEXT CHECK(status IN ('created', 'completed', 'cancelled', 'error')),
          error_message TEXT,
          chat_id TEXT,
          user_id TEXT
        )
      `);

      // Migration: Add provider_id column if it doesn't exist (for existing databases)
      try {
        this.db.exec(`ALTER TABLE task_stats ADD COLUMN provider_id TEXT`);
        logger.info('Added provider_id column to task_stats table');

        // Backfill existing records: assume historical tasks without provider_id are 'claude'
        // This is a reasonable assumption since multi-provider support was added later
        const backfillResult = this.db.prepare(`
          UPDATE task_stats
          SET provider_id = 'claude'
          WHERE provider_id IS NULL
            AND (prompt_preview IS NULL OR prompt_preview NOT LIKE 'shell:%')
        `).run();
        if (backfillResult.changes > 0) {
          logger.info(`Backfilled ${backfillResult.changes} historical task(s) with provider_id='claude'`);
        }
      } catch (e) {
        // Column already exists, ignore error
      }

      // Create task_usage_v2 table for detailed per-model usage tracking
      // One task can use multiple models, each gets its own row
      this.db.exec(`
        CREATE TABLE IF NOT EXISTS task_usage_v2 (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          task_id TEXT NOT NULL,
          model_id TEXT NOT NULL,
          provider_id TEXT,
          input_tokens INTEGER DEFAULT 0,
          input_cached_tokens INTEGER DEFAULT 0,
          output_tokens INTEGER DEFAULT 0,
          cost_usd REAL DEFAULT 0,
          created_at INTEGER NOT NULL
        )
      `);

      // Create indexes for efficient querying
      this.db.exec(`
        CREATE INDEX IF NOT EXISTS idx_task_stats_created_at ON task_stats(created_at);
        CREATE INDEX IF NOT EXISTS idx_task_stats_status ON task_stats(status);
        CREATE INDEX IF NOT EXISTS idx_task_stats_workspace ON task_stats(workspace);
        CREATE INDEX IF NOT EXISTS idx_task_stats_chat_id ON task_stats(chat_id);
        CREATE INDEX IF NOT EXISTS idx_task_usage_v2_task_id ON task_usage_v2(task_id);
        CREATE INDEX IF NOT EXISTS idx_task_usage_v2_model_id ON task_usage_v2(model_id);
        CREATE INDEX IF NOT EXISTS idx_task_usage_v2_provider_id ON task_usage_v2(provider_id);
        CREATE INDEX IF NOT EXISTS idx_task_usage_v2_created_at ON task_usage_v2(created_at);
      `);

      logger.info('Stats database initialized successfully');
    } catch (error) {
      logger.error('Failed to initialize stats database:', error);
      throw error;
    }
  }

  recordTaskCreation(taskId, workspace, prompt, chatId = null, userId = null) {
    if (!this.db) {
      logger.warn('Stats database not initialized, cannot record task creation');
      return null;
    }

    try {
      const stmt = this.db.prepare(`
        INSERT INTO task_stats (
          task_id, created_at, status, workspace,
          prompt_preview, chat_id, user_id
        ) VALUES (?, ?, 'created', ?, ?, ?, ?)
      `);

      const promptPreview = prompt ? prompt.substring(0, 500) : null;
      const result = stmt.run(
        taskId,
        Date.now(),
        workspace,
        promptPreview,
        chatId,
        userId
      );

      return result.lastInsertRowid;
    } catch (error) {
      logger.error('Failed to record task creation:', error);
      return null;
    }
  }

  recordTaskCompletion(taskId, outputPreview, model, cost, tokens, providerId = null) {
    if (!this.db) {
      logger.warn('Stats database not initialized, cannot record task completion');
      return false;
    }

    try {
      const stmt = this.db.prepare(`
        UPDATE task_stats
        SET completed_at = ?,
            duration_ms = ? - created_at,
            status = 'completed',
            output_preview = ?,
            model = ?,
            provider_id = ?,
            cost_usd = ?,
            input_tokens = ?,
            output_tokens = ?,
            total_tokens = ?
        WHERE task_id = ? AND status = 'created'
      `);

      const completedAt = Date.now();
      const result = stmt.run(
        completedAt,
        completedAt,  // Pass completedAt again for duration calculation
        outputPreview ? outputPreview.substring(0, 500) : null,
        model,
        providerId,
        cost,
        tokens?.input || 0,
        tokens?.output || 0,
        tokens?.total || 0,
        taskId
      );

      return result.changes > 0;
    } catch (error) {
      logger.error('Failed to record task completion:', error);
      return false;
    }
  }

  recordTaskCancellation(taskId, reason = null) {
    if (!this.db) {
      logger.warn('Stats database not initialized, cannot record task cancellation');
      return false;
    }

    try {
      const stmt = this.db.prepare(`
        UPDATE task_stats
        SET cancelled_at = ?,
            duration_ms = ? - created_at,
            status = 'cancelled',
            error_message = ?
        WHERE task_id = ? AND status = 'created'
      `);

      const cancelledAt = Date.now();
      const result = stmt.run(cancelledAt, cancelledAt, reason, taskId);

      return result.changes > 0;
    } catch (error) {
      logger.error('Failed to record task cancellation:', error);
      return false;
    }
  }

  recordTaskError(taskId, errorMessage) {
    if (!this.db) {
      logger.warn('Stats database not initialized, cannot record task error');
      return false;
    }

    try {
      const stmt = this.db.prepare(`
        UPDATE task_stats
        SET status = 'error',
            error_message = ?,
            completed_at = ?,
            duration_ms = ? - created_at
        WHERE task_id = ? AND status = 'created'
      `);

      const completedAt = Date.now();
      const result = stmt.run(errorMessage, completedAt, completedAt, taskId);

      return result.changes > 0;
    } catch (error) {
      logger.error('Failed to record task error:', error);
      return false;
    }
  }

  getHourlyStats(hours = 24) {
    if (!this.db) {
      logger.warn('Stats database not initialized, cannot get hourly stats');
      return [];
    }

    try {
      const since = Date.now() - (hours * 60 * 60 * 1000);
      const stmt = this.db.prepare(`
        SELECT
          strftime('%Y-%m-%d %H:00', created_at/1000, 'unixepoch') as hour,
          COUNT(*) as task_count,
          SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_count,
          SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_count,
          SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) as error_count,
          SUM(duration_ms) as total_duration_ms,
          AVG(duration_ms) as avg_duration_ms,
          SUM(cost_usd) as total_cost,
          SUM(total_tokens) as total_tokens,
          workspace
        FROM task_stats
        WHERE created_at >= ?
          AND (prompt_preview IS NULL OR prompt_preview NOT LIKE 'shell:%')
        GROUP BY hour, workspace
        ORDER BY hour DESC
      `);

      return stmt.all(since);
    } catch (error) {
      logger.error('Failed to get hourly stats:', error);
      return [];
    }
  }

  getDailyStats(days = 7) {
    if (!this.db) {
      logger.warn('Stats database not initialized, cannot get daily stats');
      return [];
    }

    try {
      const since = Date.now() - (days * 24 * 60 * 60 * 1000);
      const stmt = this.db.prepare(`
        SELECT
          strftime('%Y-%m-%d', created_at/1000, 'unixepoch') as day,
          COUNT(*) as task_count,
          SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_count,
          SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_count,
          SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) as error_count,
          SUM(duration_ms) as total_duration_ms,
          AVG(duration_ms) as avg_duration_ms,
          SUM(cost_usd) as total_cost,
          SUM(total_tokens) as total_tokens,
          workspace
        FROM task_stats
        WHERE created_at >= ?
          AND (prompt_preview IS NULL OR prompt_preview NOT LIKE 'shell:%')
        GROUP BY day, workspace
        ORDER BY day DESC
      `);

      return stmt.all(since);
    } catch (error) {
      logger.error('Failed to get daily stats:', error);
      return [];
    }
  }

  getMonthlyModelStats(months = 12) {
    if (!this.db) {
      logger.warn('Stats database not initialized, cannot get monthly model stats');
      return [];
    }

    try {
      // Calculate timestamp for N months ago
      const now = new Date();
      const startDate = new Date(now.getFullYear(), now.getMonth() - months, 1);
      const since = startDate.getTime();

      const stmt = this.db.prepare(`
        SELECT
          strftime('%Y-%m', created_at/1000, 'unixepoch') as month,
          model,
          provider_id,
          COUNT(*) as task_count,
          SUM(cost_usd) as total_cost,
          SUM(total_tokens) as total_tokens
        FROM task_stats
        WHERE created_at >= ?
          AND (prompt_preview IS NULL OR prompt_preview NOT LIKE 'shell:%')
        GROUP BY month, model, provider_id
        ORDER BY month DESC
      `);

      return stmt.all(since);
    } catch (error) {
      logger.error('Failed to get monthly model stats:', error);
      return [];
    }
  }

  getWorkspaceStats(workspace, days = 7) {
    if (!this.db) {
      logger.warn('Stats database not initialized, cannot get workspace stats');
      return null;
    }

    try {
      const since = Date.now() - (days * 24 * 60 * 60 * 1000);
      const stmt = this.db.prepare(`
        SELECT
          COUNT(*) as total_tasks,
          SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_tasks,
          SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_tasks,
          SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) as error_tasks,
          AVG(duration_ms) as avg_duration_ms,
          MAX(duration_ms) as max_duration_ms,
          MIN(duration_ms) as min_duration_ms,
          SUM(cost_usd) as total_cost,
          SUM(input_tokens) as total_input_tokens,
          SUM(output_tokens) as total_output_tokens,
          SUM(total_tokens) as total_tokens
        FROM task_stats
        WHERE workspace = ? AND created_at >= ?
      `);

      return stmt.get(workspace, since);
    } catch (error) {
      logger.error('Failed to get workspace stats:', error);
      return null;
    }
  }

  getTotalStats() {
    if (!this.db) {
      logger.warn('Stats database not initialized, cannot get total stats');
      return null;
    }

    try {
      const stmt = this.db.prepare(`
        SELECT
          COUNT(*) as total_tasks,
          SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_tasks,
          SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_tasks,
          SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) as error_tasks,
          AVG(duration_ms) as avg_duration_ms,
          SUM(cost_usd) as total_cost,
          SUM(total_tokens) as total_tokens,
          MIN(created_at) as first_task_at,
          MAX(created_at) as last_task_at
        FROM task_stats
      `);

      return stmt.get();
    } catch (error) {
      logger.error('Failed to get total stats:', error);
      return null;
    }
  }

  getTaskStats(startDate, endDate) {
    if (!this.db) {
      logger.warn('Stats database not initialized, cannot get task stats');
      return null;
    }

    try {
      const startTime = startDate instanceof Date ? startDate.getTime() : startDate;
      const endTime = endDate instanceof Date ? endDate.getTime() : endDate;

      const stmt = this.db.prepare(`
        SELECT
          COUNT(*) as totalTasks,
          SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completedTasks,
          SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelledTasks,
          SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) as errorTasks,
          AVG(duration_ms) as avgDurationMs,
          MIN(duration_ms) as minDurationMs,
          MAX(duration_ms) as maxDurationMs,
          SUM(duration_ms) as totalDurationMs,
          SUM(cost_usd) as totalCost,
          SUM(input_tokens) as totalInputTokens,
          SUM(output_tokens) as totalOutputTokens,
          SUM(total_tokens) as totalTokens
        FROM task_stats
        WHERE created_at >= ? AND created_at <= ?
      `);

      return stmt.get(startTime, endTime);
    } catch (error) {
      logger.error('Failed to get task stats:', error);
      return null;
    }
  }

  /**
   * Record detailed per-model usage for a task (usage v2)
   * @param {string} taskId - The task identifier
   * @param {Array} modelUsages - Array of model usage objects with: modelId, providerId, inputTokens, inputCachedTokens, outputTokens, costUsd
   * @param {string} providerId - The provider identifier (claude, gemini, cursor, codex)
   */
  recordTaskUsageV2(taskId, modelUsages, providerId = null) {
    if (!this.db) {
      logger.warn('Stats database not initialized, cannot record task usage v2');
      return false;
    }

    if (!modelUsages || !Array.isArray(modelUsages) || modelUsages.length === 0) {
      logger.debug(`No model usages to record for task ${taskId}`);
      return false;
    }

    try {
      const stmt = this.db.prepare(`
        INSERT INTO task_usage_v2 (
          task_id, model_id, provider_id, input_tokens, input_cached_tokens,
          output_tokens, cost_usd, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `);

      const createdAt = Date.now();
      const insertMany = this.db.transaction((usages) => {
        for (const usage of usages) {
          stmt.run(
            taskId,
            usage.modelId || usage.modelName || 'unknown',
            usage.providerId || providerId || 'claude',
            usage.inputTokens || usage.input || 0,
            usage.inputCachedTokens || usage.cacheReadTokens || 0,
            usage.outputTokens || usage.output || 0,
            usage.costUsd || usage.cost || 0,
            createdAt
          );
        }
      });

      insertMany(modelUsages);
      logger.debug(`Recorded ${modelUsages.length} model usage(s) for task ${taskId}`);
      return true;
    } catch (error) {
      logger.error('Failed to record task usage v2:', error);
      return false;
    }
  }

  /**
   * Get detailed usage v2 data for a specific task
   * @param {string} taskId - The task identifier
   * @returns {Array} Array of model usage records
   */
  getTaskUsageV2(taskId) {
    if (!this.db) {
      logger.warn('Stats database not initialized, cannot get task usage v2');
      return [];
    }

    try {
      const stmt = this.db.prepare(`
        SELECT
          model_id as modelId,
          provider_id as providerId,
          input_tokens as inputTokens,
          input_cached_tokens as inputCachedTokens,
          output_tokens as outputTokens,
          cost_usd as costUsd,
          created_at as createdAt
        FROM task_usage_v2
        WHERE task_id = ?
        ORDER BY id ASC
      `);

      return stmt.all(taskId);
    } catch (error) {
      logger.error('Failed to get task usage v2:', error);
      return [];
    }
  }

  /**
   * Get aggregated model usage stats for a time period
   * @param {number} days - Number of days to look back (used if since/until not provided)
   * @param {number} since - Unix milliseconds timestamp for range start
   * @param {number} until - Unix milliseconds timestamp for range end
   * @param {string|string[]} providerId - Optional provider ID(s) to filter by (e.g., 'claude', 'gemini', 'codex', or array of providers)
   * @returns {Array} Aggregated usage per model
   */
  getModelUsageStats(days = 7, since = null, until = null, providerId = null) {
    if (!this.db) {
      logger.warn('Stats database not initialized, cannot get model usage stats');
      return [];
    }

    try {
      // Use since/until if provided, otherwise calculate from days
      const startTime = since || (Date.now() - (days * 24 * 60 * 60 * 1000));
      const endTime = until || Date.now();

      // Build query with optional provider filter
      let query = `
        SELECT
          model_id as modelId,
          provider_id as providerId,
          COUNT(DISTINCT task_id) as taskCount,
          SUM(input_tokens) as totalInputTokens,
          SUM(input_cached_tokens) as totalInputCachedTokens,
          SUM(output_tokens) as totalOutputTokens,
          SUM(cost_usd) as totalCost
        FROM task_usage_v2
        WHERE created_at >= ? AND created_at <= ?
      `;

      const params = [startTime, endTime];

      // Add provider filter if specified
      if (providerId) {
        if (Array.isArray(providerId)) {
          const placeholders = providerId.map(() => '?').join(', ');
          query += ` AND provider_id IN (${placeholders})`;
          params.push(...providerId);
        } else {
          query += ` AND provider_id = ?`;
          params.push(providerId);
        }
      }

      query += `
        GROUP BY model_id, provider_id
        ORDER BY totalCost DESC
      `;

      const stmt = this.db.prepare(query);
      return stmt.all(...params);
    } catch (error) {
      logger.error('Failed to get model usage stats:', error);
      return [];
    }
  }

  /**
   * Get daily model usage breakdown
   * @param {number} days - Number of days to look back (used if since/until not provided)
   * @param {number} since - Unix milliseconds timestamp for range start
   * @param {number} until - Unix milliseconds timestamp for range end
   * @param {string|string[]} providerId - Optional provider ID(s) to filter by (e.g., 'claude', 'gemini', 'codex', or array of providers)
   * @returns {Array} Daily usage per model
   */
  getDailyModelUsage(days = 7, since = null, until = null, providerId = null) {
    if (!this.db) {
      logger.warn('Stats database not initialized, cannot get daily model usage');
      return [];
    }

    try {
      // Use since/until if provided, otherwise calculate from days
      const startTime = since || (Date.now() - (days * 24 * 60 * 60 * 1000));
      const endTime = until || Date.now();

      // Build query with optional provider filter
      let query = `
        SELECT
          strftime('%Y-%m-%d', created_at/1000, 'unixepoch') as day,
          model_id as modelId,
          provider_id as providerId,
          COUNT(DISTINCT task_id) as taskCount,
          SUM(input_tokens) as inputTokens,
          SUM(input_cached_tokens) as inputCachedTokens,
          SUM(output_tokens) as outputTokens,
          SUM(cost_usd) as cost
        FROM task_usage_v2
        WHERE created_at >= ? AND created_at <= ?
      `;

      const params = [startTime, endTime];

      // Add provider filter if specified
      if (providerId) {
        if (Array.isArray(providerId)) {
          const placeholders = providerId.map(() => '?').join(', ');
          query += ` AND provider_id IN (${placeholders})`;
          params.push(...providerId);
        } else {
          query += ` AND provider_id = ?`;
          params.push(providerId);
        }
      }

      query += `
        GROUP BY day, model_id, provider_id
        ORDER BY day DESC, cost DESC
      `;

      const stmt = this.db.prepare(query);
      return stmt.all(...params);
    } catch (error) {
      logger.error('Failed to get daily model usage:', error);
      return [];
    }
  }

  /**
   * Get task duration statistics for a time period
   * @param {number} days - Number of days to look back (used if since/until not provided)
   * @param {number} since - Unix milliseconds timestamp for range start
   * @param {number} until - Unix milliseconds timestamp for range end
   * @returns {Object} Duration stats: totalDurationMs, taskCount, completedTasks, failedTasks
   */
  getTaskDurationStats(days = 7, since = null, until = null) {
    if (!this.db) {
      logger.warn('Stats database not initialized, cannot get task duration stats');
      return null;
    }

    try {
      const startTime = since || (Date.now() - (days * 24 * 60 * 60 * 1000));
      const endTime = until || Date.now();

      const stmt = this.db.prepare(`
        SELECT
          COUNT(*) as taskCount,
          SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completedTasks,
          SUM(CASE WHEN status = 'error' OR status = 'cancelled' THEN 1 ELSE 0 END) as failedTasks,
          SUM(duration_ms) as totalDurationMs,
          AVG(duration_ms) as avgDurationMs,
          MIN(duration_ms) as minDurationMs,
          MAX(duration_ms) as maxDurationMs
        FROM task_stats
        WHERE created_at >= ? AND created_at <= ?
          AND (prompt_preview IS NULL OR prompt_preview NOT LIKE 'shell:%')
      `);

      return stmt.get(startTime, endTime);
    } catch (error) {
      logger.error('Failed to get task duration stats:', error);
      return null;
    }
  }

  /**
   * Get aggregated stats grouped by provider for multi-provider reporting
   * @param {number} days - Number of days to look back (used if since/until not provided)
   * @param {number} since - Unix milliseconds timestamp for range start
   * @param {number} until - Unix milliseconds timestamp for range end
   * @returns {Array} Stats per provider with task count, tokens, and cost
   */
  getProviderStats(days = 7, since = null, until = null) {
    if (!this.db) {
      logger.warn('Stats database not initialized, cannot get provider stats');
      return [];
    }

    try {
      const startTime = since || (Date.now() - (days * 24 * 60 * 60 * 1000));
      const endTime = until || Date.now();

      const stmt = this.db.prepare(`
        SELECT
          provider_id as providerId,
          COUNT(DISTINCT task_id) as taskCount,
          COUNT(DISTINCT model_id) as modelCount,
          SUM(input_tokens) as totalInputTokens,
          SUM(input_cached_tokens) as totalInputCachedTokens,
          SUM(output_tokens) as totalOutputTokens,
          SUM(input_tokens + output_tokens) as totalTokens,
          SUM(cost_usd) as totalCost,
          MIN(created_at) as firstUsage,
          MAX(created_at) as lastUsage
        FROM task_usage_v2
        WHERE created_at >= ? AND created_at <= ?
        GROUP BY provider_id
        ORDER BY totalCost DESC
      `);

      return stmt.all(startTime, endTime);
    } catch (error) {
      logger.error('Failed to get provider stats:', error);
      return [];
    }
  }

  /**
   * Get a summary of all providers with their models and usage
   * Useful for dashboard and multi-provider reporting
   * @param {number} days - Number of days to look back (used if since/until not provided)
   * @param {number} since - Unix milliseconds timestamp for range start
   * @param {number} until - Unix milliseconds timestamp for range end
   * @returns {Object} Provider summary with totals and per-provider breakdown
   */
  getProviderSummary(days = 7, since = null, until = null) {
    if (!this.db) {
      logger.warn('Stats database not initialized, cannot get provider summary');
      return null;
    }

    try {
      const startTime = since || (Date.now() - (days * 24 * 60 * 60 * 1000));
      const endTime = until || Date.now();

      // Get totals across all providers
      const totalsStmt = this.db.prepare(`
        SELECT
          COUNT(DISTINCT task_id) as totalTasks,
          COUNT(DISTINCT provider_id) as providerCount,
          COUNT(DISTINCT model_id) as modelCount,
          SUM(input_tokens) as totalInputTokens,
          SUM(output_tokens) as totalOutputTokens,
          SUM(input_tokens + output_tokens) as totalTokens,
          SUM(cost_usd) as totalCost
        FROM task_usage_v2
        WHERE created_at >= ? AND created_at <= ?
      `);

      const totals = totalsStmt.get(startTime, endTime);

      // Get per-provider breakdown with their models
      const providersStmt = this.db.prepare(`
        SELECT
          provider_id as providerId,
          model_id as modelId,
          COUNT(DISTINCT task_id) as taskCount,
          SUM(input_tokens) as inputTokens,
          SUM(output_tokens) as outputTokens,
          SUM(input_tokens + output_tokens) as totalTokens,
          SUM(cost_usd) as cost
        FROM task_usage_v2
        WHERE created_at >= ? AND created_at <= ?
        GROUP BY provider_id, model_id
        ORDER BY provider_id, cost DESC
      `);

      const providerModels = providersStmt.all(startTime, endTime);

      // Group models by provider
      const providers = {};
      for (const row of providerModels) {
        if (!providers[row.providerId]) {
          providers[row.providerId] = {
            providerId: row.providerId,
            models: [],
            totalTasks: 0,
            totalTokens: 0,
            totalCost: 0
          };
        }
        providers[row.providerId].models.push({
          modelId: row.modelId,
          taskCount: row.taskCount,
          inputTokens: row.inputTokens,
          outputTokens: row.outputTokens,
          totalTokens: row.totalTokens,
          cost: row.cost
        });
        providers[row.providerId].totalTasks += row.taskCount;
        providers[row.providerId].totalTokens += row.totalTokens;
        providers[row.providerId].totalCost += row.cost || 0;
      }

      return {
        period: {
          start: new Date(startTime).toISOString(),
          end: new Date(endTime).toISOString(),
          days: Math.ceil((endTime - startTime) / (24 * 60 * 60 * 1000))
        },
        totals: {
          tasks: totals.totalTasks || 0,
          providers: totals.providerCount || 0,
          models: totals.modelCount || 0,
          inputTokens: totals.totalInputTokens || 0,
          outputTokens: totals.totalOutputTokens || 0,
          totalTokens: totals.totalTokens || 0,
          cost: totals.totalCost || 0
        },
        providers: Object.values(providers)
      };
    } catch (error) {
      logger.error('Failed to get provider summary:', error);
      return null;
    }
  }

  /**
   * Get list of distinct providers that have usage data
   * @param {number} days - Number of days to look back (used if since/until not provided)
   * @param {number} since - Unix milliseconds timestamp for range start
   * @param {number} until - Unix milliseconds timestamp for range end
   * @returns {Array} List of provider IDs with first/last usage dates
   */
  getActiveProviders(days = 7, since = null, until = null) {
    if (!this.db) {
      logger.warn('Stats database not initialized, cannot get active providers');
      return [];
    }

    try {
      const startTime = since || (Date.now() - (days * 24 * 60 * 60 * 1000));
      const endTime = until || Date.now();

      const stmt = this.db.prepare(`
        SELECT
          provider_id as providerId,
          COUNT(DISTINCT task_id) as taskCount,
          MIN(created_at) as firstUsage,
          MAX(created_at) as lastUsage
        FROM task_usage_v2
        WHERE created_at >= ? AND created_at <= ?
          AND provider_id IS NOT NULL
        GROUP BY provider_id
        ORDER BY lastUsage DESC
      `);

      return stmt.all(startTime, endTime);
    } catch (error) {
      logger.error('Failed to get active providers:', error);
      return [];
    }
  }

  close() {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

// Singleton instance
let statsDB = null;

export function getStatsDB() {
  if (!statsDB) {
    try {
      statsDB = new StatsDB();
      statsDB.initialize();
    } catch (error) {
      logger.error('Failed to get StatsDB instance:', error);
      // Reset to null so next call will retry initialization
      statsDB = null;
      throw error;
    }
  }
  return statsDB;
}
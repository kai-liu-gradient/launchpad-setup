/**
 * Model preference utilities for Claude command composition
 */

export const VALID_MODELS = {
  SONNET: 'sonnet',
  OPUS: 'opus'
};

export const MODEL_FLAGS = {
  [VALID_MODELS.SONNET]: '--model',
  [VALID_MODELS.OPUS]: '--model'
};

/**
 * Validate if a model is supported
 * @param {string} model - Model name to validate
 * @returns {boolean} True if model is valid
 */
export function isValidModel(model) {
  if (!model) return false;
  return Object.values(VALID_MODELS).includes(model.toLowerCase());
}

/**
 * Normalize model name to lowercase
 * @param {string} model - Model name to normalize
 * @returns {string} Normalized model name
 */
export function normalizeModel(model) {
  if (!model) return null;
  const normalized = model.toLowerCase();
  return isValidModel(normalized) ? normalized : null;
}

/**
 * Get the Claude CLI flag for a given model
 * @param {string} model - Model name
 * @returns {Array<string>} CLI flags for the model, or empty array if invalid
 */
export function getModelFlags(model) {
  const normalizedModel = normalizeModel(model);
  if (!normalizedModel) return [];

  return [MODEL_FLAGS[normalizedModel], normalizedModel];
}

/**
 * Extract model preference from prompt text (@@opus or @@sonnet)
 * @param {string} promptText - The prompt text to search
 * @returns {string|null} Model preference or null
 */
export function extractModelFromPrompt(promptText) {
  if (!promptText || typeof promptText !== 'string') {
    return null;
  }

  // Look for exact matches of @@opus or @@sonnet
  if (promptText.includes('@@opus')) {
    return 'opus';
  }

  if (promptText.includes('@@sonnet')) {
    return 'sonnet';
  }

  return null;
}

/**
 * Extract provider preference from prompt text (@@<providerId>)
 * Dynamically detects any @@<word> pattern and returns the provider ID
 * @param {string} promptText - The prompt text to search
 * @param {Array<string>} validProviders - Optional list of valid provider IDs to check against
 * @returns {string|null} Provider ID or null
 */
export function extractProviderFromPrompt(promptText, validProviders = null) {
  if (!promptText || typeof promptText !== 'string') {
    return null;
  }

  // Match any @@<word> pattern (excluding model patterns like @@opus, @@sonnet)
  const providerPattern = /@@([a-z][a-z0-9\-]*)/gi;
  const matches = promptText.matchAll(providerPattern);

  for (const match of matches) {
    const providerId = match[1].toLowerCase();

    // Skip model patterns
    if (providerId === 'opus' || providerId === 'sonnet') {
      continue;
    }

    // If validProviders list is provided, validate against it
    if (validProviders && !validProviders.includes(providerId)) {
      continue;
    }

    // Return the first valid provider found
    return providerId;
  }

  return null;
}

/**
 * Strip model and provider patterns from prompt text
 * Removes all @@<word> patterns (models and providers)
 * @param {string} promptText - The prompt text to clean
 * @returns {string} Cleaned prompt text
 */
export function stripPatternsFromPrompt(promptText) {
  if (!promptText || typeof promptText !== 'string') {
    return promptText;
  }

  const startsWithPattern = /^[ \t]*@@[a-z][a-z0-9\-]*/i.test(promptText);

  // Strip all @@<word> patterns (both models and providers)
  // This regex matches @@ followed by word characters, hyphens, or numbers
  let cleaned = promptText.replace(/@@[a-z][a-z0-9\-]*/gi, '');

  // Collapse excess intra-line spaces created by removal while preserving indentation
  cleaned = cleaned.replace(/(?<=\S)[ \t]{2,}/g, ' ');

  // Remove stray spaces before line breaks to keep formatting tidy
  cleaned = cleaned.replace(/[ \t]+(\r?\n)/g, '$1');

  // If the original prompt started with a pattern, trim leftover leading spaces once
  if (startsWithPattern) {
    cleaned = cleaned.replace(/^[ \t]+/, '');
  }

  // Drop trailing spaces that might linger at the end of the prompt
  return cleaned.replace(/[ \t]+$/g, '');
}

/**
 * Get model preference from task, workspace metadata, or prompt
 * @param {Object} task - Task object
 * @param {Object} workspaceManager - Workspace manager instance
 * @returns {Promise<{model: string|null, source: string|null}>} Model preference and source
 */
export async function getModelPreference(task, workspaceManager) {
  // Check task-level model preference first
  if (task.model && isValidModel(task.model)) {
    return {
      model: normalizeModel(task.model),
      source: 'task'
    };
  }

  // Check workspace metadata if workspace manager is available
  if (workspaceManager && task.cwd) {
    try {
      const workspace = await workspaceManager.getWorkspaceByPath(task.cwd);
      if (workspace && workspace.settings && workspace.settings.model) {
        const workspaceModel = normalizeModel(workspace.settings.model);
        if (workspaceModel) {
          return {
            model: workspaceModel,
            source: 'workspace'
          };
        }
      }
    } catch (error) {
      // Silently continue if workspace lookup fails
      console.warn(`Failed to get workspace model preference: ${error.message}`);
    }
  }

  // ONLY if no task model and no workspace model, check prompt for @@model patterns
  const promptModel = extractModelFromPrompt(task.command);
  if (promptModel) {
    console.log(`🎯 Detected model preference from prompt: ${promptModel} (found @@${promptModel} in command)`);
    return {
      model: promptModel,
      source: 'prompt'
    };
  }

  // Also check task name if command doesn't have it
  if (task.name && !promptModel) {
    const nameModel = extractModelFromPrompt(task.name);
    if (nameModel) {
      console.log(`🎯 Detected model preference from task name: ${nameModel} (found @@${nameModel} in name)`);
      return {
        model: nameModel,
        source: 'prompt'
      };
    }
  }

  return {
    model: null,
    source: null
  };
}

/**
 * Create task creation error for invalid model
 * @param {string} model - Invalid model name
 * @returns {Error} Error object
 */
export function createInvalidModelError(model) {
  const validModels = Object.values(VALID_MODELS).join(', ');
  return new Error(`Invalid model "${model}". Valid models are: ${validModels}`);
}

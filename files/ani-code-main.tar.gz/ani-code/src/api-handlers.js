import { parse } from 'url';
import { logger } from './logger.js';
import { readFileSync, existsSync, writeFileSync, mkdirSync, statSync, readdirSync } from 'fs';
import { join, dirname, basename } from 'path';
import { fileURLToPath } from 'url';
import { isValidModel, normalizeModel, createInvalidModelError, stripPatternsFromPrompt, extractProviderFromPrompt } from './model-utils.js';
import { createGoalsProcessor } from './utils/goals-processor.js';
import { HintManager } from './hint-manager.js';
import {
  findGoalFiles,
  extractGoalId,
  findGoalFileById,
  parseGoalFile,
  generateProgressBar,
  calculateSummary,
  quickScanGoalStatus,
  VALID_STATUSES,
  COMPLETED_STATUSES
} from './utils/goals-utils.js';
import {
  buildAddGoalPrompt,
  buildGoalExecutionPrompt,
  buildProgressUpdatePrompt
} from './prompts/goals-prompts.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export class APIHandlers {
  constructor(taskMonitor, workspaceManager) {
    this.taskMonitor = taskMonitor;
    this.workspaceManager = workspaceManager;
    // Rate limiting: track requests per workspace
    this.rateLimitMap = new Map();
    // Clean up old entries every minute
    this.rateLimitInterval = setInterval(() => this.cleanupRateLimits(), 60000);
  }

  /**
   * Extract prompt text from task command
   * Handles -c commands, strips @@patterns, and truncates to 150 chars
   * @param {Object} task - Task object with command and name properties
   * @returns {string} Clean prompt text
   */
  extractPromptFromTask(task) {
    let promptText = task.name || '';

    // If command exists, extract the actual prompt
    if (task.command) {
      if (task.command.startsWith('-c')) {
        // Continue command - extract prompt after -c
        promptText = task.command.substring(2).trim()
          .replace('--dangerously-skip-permissions', '').trim() || promptText;
      } else if (!task.command.startsWith('shell:')) {
        // Regular command - use the command itself
        promptText = task.command;
      }
    }

    // Strip @@patterns (providers/models)
    promptText = stripPatternsFromPrompt(promptText);

    // Truncate to 150 chars if needed
    if (promptText.length > 150) {
      promptText = promptText.substring(0, 147) + '...';
    }

    return promptText || task.name || '';
  }

  /**
   * Extract provider slug from task
   * Priority: 1. providerId from task, 2. @@provider from command, 3. default 'anthropic'
   * @param {Object} task - Task object with providerId and command properties
   * @returns {string} Provider slug in lowercase
   */
  extractProviderFromTask(task) {
    // 1. Use task's providerId if available
    if (task.providerId) {
      return task.providerId.toLowerCase();
    }

    // 2. Check for @@provider in command
    if (task.command) {
      const providerFromCommand = extractProviderFromPrompt(task.command);
      if (providerFromCommand) {
        return providerFromCommand.toLowerCase();
      }
    }

    // 3. Check task name for @@provider
    if (task.name) {
      const providerFromName = extractProviderFromPrompt(task.name);
      if (providerFromName) {
        return providerFromName.toLowerCase();
      }
    }

    // 4. Default to anthropic (Claude)
    return 'anthropic';
  }

  sendJSON(res, data, statusCode = 200) {
    // Check if headers already sent to prevent double response
    if (res.headersSent) {
      logger.warn('[API] Attempted to send response after headers already sent', {
        statusCode,
        data
      });
      return;
    }

    res.writeHead(statusCode, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(data));
  }

  sendError(res, statusCode, message) {
    // Check if headers already sent to prevent double response
    if (res.headersSent) {
      logger.warn('[API] Attempted to send error after headers already sent', {
        statusCode,
        message
      });
      return;
    }

    this.sendJSON(res, { success: false, error: message }, statusCode);
  }

  async parseBody(req) {
    return new Promise((resolve, reject) => {
      let body = '';
      req.on('data', chunk => body += chunk);
      req.on('end', () => {
        try {
          resolve(body ? JSON.parse(body) : {});
        } catch (error) {
          reject(error);
        }
      });
      req.on('error', reject);
    });
  }

  async validateAPIKey(apiKey, req) {
    // Import config to check GATEWAY_API_KEY
    const { config } = await import('./config.js');

    if (!config.gateway?.apiKey) {
      logger.warn('[API] Gateway API key not configured in environment');
      return null;
    }

    if (apiKey !== config.gateway.apiKey) {
      logger.warn('[API] Invalid API key provided');
      return null;
    }

    // Extract workspace info from request body for gateway requests
    try {
      const body = await this.parseBody(req);

      // Reconstruct the stream for later use
      req.body = body;

      const workspaceId = body.data?.workspaceId || config.gateway?.workspaceId || 'default';
      const projectId = body.data?.projectId || config.gateway?.projectId || 'default';

      // For gateway requests, use configured workspace path or default
      const workspacePath = process.env.WORKSPACE_PATH || process.cwd();

      return {
        id: workspaceId,
        name: projectId,
        path: workspacePath,
        source: 'gateway'
      };
    } catch (error) {
      logger.error('[API] Failed to parse request body for API key validation:', error);
      // Re-throw SyntaxError so it can be handled as 400 Bad Request
      if (error instanceof SyntaxError) {
        throw error;
      }
      return null;
    }
  }

  async isRequestTrusted(req) {
    const { config } = await import('./config.js');
    if (!config.gateway?.enabled || !config.gateway?.token) {
      return false;
    }
    const gatewayToken = req.headers['x-gateway-token'];
    return gatewayToken === config.gateway.token;
  }

  checkRateLimit(workspaceId) {
    const now = Date.now();
    const windowMs = 60000; // 1 minute
    const maxRequests = 10; // 10 requests per minute

    if (!this.rateLimitMap.has(workspaceId)) {
      this.rateLimitMap.set(workspaceId, []);
    }

    const requests = this.rateLimitMap.get(workspaceId);

    // Remove old requests outside the window
    const validRequests = requests.filter(timestamp => now - timestamp < windowMs);
    this.rateLimitMap.set(workspaceId, validRequests);

    // Check if limit exceeded
    if (validRequests.length >= maxRequests) {
      return {
        allowed: false,
        retryAfter: Math.ceil((validRequests[0] + windowMs - now) / 1000)
      };
    }

    // Add current request
    validRequests.push(now);
    this.rateLimitMap.set(workspaceId, validRequests);

    return {
      allowed: true,
      remaining: maxRequests - validRequests.length
    };
  }

  cleanupRateLimits() {
    const now = Date.now();
    const windowMs = 60000;

    for (const [workspaceId, requests] of this.rateLimitMap.entries()) {
      const validRequests = requests.filter(timestamp => now - timestamp < windowMs);
      if (validRequests.length === 0) {
        this.rateLimitMap.delete(workspaceId);
      } else {
        this.rateLimitMap.set(workspaceId, validRequests);
      }
    }
  }

  async handleAPIRequest(req, res, pathname) {
    const url = parse(req.url, true);

    // Documentation endpoint - no auth required (support GET and HEAD)
    if (pathname.endsWith('/api/docs') && (req.method === 'GET' || req.method === 'HEAD')) {
      await this.handleAPIDocumentation(req, res);
      return;
    }

    // Support both Bearer token and X-API-Key authentication
    const authHeader = req.headers.authorization;
    const apiKey = req.headers['x-api-key'];

    let workspace = null;

    // Try API key authentication first (for gateway integration)
    if (apiKey) {
      try {
        workspace = await this.validateAPIKey(apiKey, req);
        if (!workspace) {
          this.sendError(res, 401, 'Invalid API key');
          return;
        }
      } catch (error) {
        if (error instanceof SyntaxError) {
          this.sendError(res, 400, 'Invalid JSON body: ' + error.message);
        } else {
          this.sendError(res, 500, 'Internal server error during authentication');
        }
        return;
      }
    }
    // Fallback to Bearer token authentication
    else if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7);

      // Validate token with workspace manager
      if (!this.workspaceManager) {
        const { WorkspaceManager } = await import('./workspace-manager.js');
        this.workspaceManager = new WorkspaceManager();
        await this.workspaceManager.initialize();
      }

      const tokenInfo = await this.workspaceManager.validateToken(token);
      if (!tokenInfo.valid) {
        this.sendError(res, 401, 'Invalid or expired token');
        return;
      }

      workspace = {
        id: tokenInfo.workspace_id,
        name: tokenInfo.workspace_name,
        path: tokenInfo.workspace_path
      };
    } else {
      this.sendError(res, 401, 'Authorization required (Bearer token or X-API-Key header)');
      return;
    }

    // Check rate limiting for POST requests
    if (req.method === 'POST') {
      const rateLimit = this.checkRateLimit(workspace.id);
      if (!rateLimit.allowed) {
        res.writeHead(429, {
          'Content-Type': 'application/json',
          'Retry-After': rateLimit.retryAfter.toString()
        });
        res.end(JSON.stringify({
          success: false,
          error: 'Rate limit exceeded',
          retryAfter: rateLimit.retryAfter
        }));
        return;
      }
      // Add rate limit info to response headers
      res.setHeader('X-RateLimit-Remaining', rateLimit.remaining.toString());
    }

    // Route API endpoints
    // Find the /api/ part and extract everything after it
    const apiIndex = pathname.lastIndexOf('/api/');
    const apiPath = apiIndex !== -1 ? pathname.substring(apiIndex + 5) : pathname.substring(5);

    // Task endpoints
    if (apiPath === 'task' && req.method === 'POST') {
      await this.handleAPITaskCreate(req, res, workspace);
    } else if (apiPath.startsWith('task/') && req.method === 'GET') {
      const taskId = apiPath.substring(5);
      if (taskId.endsWith('/checklist')) {
        const actualTaskId = taskId.substring(0, taskId.length - 10);
        await this.handleAPITaskChecklist(req, res, actualTaskId, workspace);
      } else {
        await this.handleAPITaskGet(req, res, taskId, workspace);
      }
    } else if (apiPath.startsWith('task/') && req.method === 'DELETE') {
      const taskId = apiPath.substring(5);
      await this.handleAPITaskCancel(req, res, taskId, workspace);
    } else if (apiPath.startsWith('task/') && apiPath.endsWith('/channel') && req.method === 'PATCH') {
      // PATCH /api/task/:taskId/channel - Update task response channel
      const taskId = apiPath.substring(5, apiPath.length - 8);
      await this.handleAPITaskChannelUpdate(req, res, taskId, workspace);
    } else if (apiPath === 'tasks' && req.method === 'GET') {
      await this.handleAPITasksList(req, res, url.query, workspace);
    }
    // Plan endpoints
    else if (apiPath === 'plan' && req.method === 'POST') {
      await this.handleAPIPlanCreate(req, res, workspace);
    } else if (apiPath.startsWith('plan/') && req.method === 'GET') {
      const planId = apiPath.substring(5);
      await this.handleAPIPlanGet(req, res, planId, workspace);
    } else if (apiPath.startsWith('plan/') && req.method === 'PUT') {
      const planId = apiPath.substring(5);
      await this.handleAPIPlanUpdate(req, res, planId, workspace);
    } else if (apiPath.startsWith('plan/') && req.method === 'DELETE') {
      const planId = apiPath.substring(5);
      await this.handleAPIPlanDelete(req, res, planId, workspace);
    } else if (apiPath === 'plans' && req.method === 'GET') {
      await this.handleAPIPlansList(req, res, url.query, workspace);
    } else if (apiPath === 'plan/execute' && req.method === 'POST') {
      await this.handleAPIPlanExecute(req, res, workspace);
    } else if (apiPath === 'plans/summary' && req.method === 'GET') {
      await this.handleAPIPlansSummary(req, res, workspace);
    }
    // Goal endpoints
    else if (apiPath === 'goals' && req.method === 'GET') {
      await this.handleAPIGoalsList(req, res, url.query, workspace);
    } else if (apiPath === 'goals/running' && req.method === 'GET') {
      await this.handleAPIGoalsRunning(req, res, url.query, workspace);
    } else if (apiPath === 'goals/sync' && req.method === 'POST') {
      await this.handleAPIGoalsSync(req, res, workspace);
    } else if (apiPath.startsWith('goals/') && req.method === 'GET') {
      const goalId = apiPath.substring(6);
      await this.handleAPIGoalGet(req, res, goalId, workspace);
    } else if (apiPath === 'goals' && req.method === 'POST') {
      await this.handleAPIGoalCreate(req, res, workspace);
    } else if (apiPath.startsWith('goals/') && req.method === 'PUT') {
      const goalId = apiPath.substring(6);
      await this.handleAPIGoalUpdate(req, res, goalId, workspace);
    } else if (apiPath.startsWith('goals/') && req.method === 'DELETE') {
      const goalId = apiPath.substring(6);
      await this.handleAPIGoalDelete(req, res, goalId, workspace);
    }
    // Provider endpoints
    else if (apiPath === 'providers' && req.method === 'GET') {
      await this.handleAPIProvidersList(req, res, url.query, workspace);
    } else if (apiPath.match(/^providers\/([^/]+)\/models$/) && req.method === 'GET') {
      const providerId = apiPath.split('/')[1];
      await this.handleAPIProviderModels(req, res, providerId, url.query, workspace);
    } else if (apiPath.match(/^providers\/([^/]+)$/) && req.method === 'GET') {
      const providerId = apiPath.split('/')[1];
      await this.handleAPIProviderGet(req, res, providerId, workspace);
    } else if (apiPath.match(/^providers\/([^/]+)$/) && req.method === 'PATCH') {
      const providerId = apiPath.split('/')[1];
      await this.handleAPIProviderUpdate(req, res, providerId, workspace);
    } else if (apiPath.match(/^providers\/([^/]+)\/models\/(.+)$/) && req.method === 'PATCH') {
      const parts = apiPath.split('/');
      const providerId = parts[1];
      const modelId = parts[3];
      await this.handleAPIProviderModelUpdate(req, res, providerId, modelId, workspace);
    }
    // Hint endpoints
    else if (apiPath === 'hints' && req.method === 'GET') {
      await this.handleAPIHintsList(req, res, url.query, workspace);
    } else if (apiPath === 'hints' && req.method === 'POST') {
      await this.handleAPIHintCreate(req, res, workspace);
    } else if (apiPath === 'hints' && req.method === 'DELETE') {
      await this.handleAPIHintsClear(req, res, workspace);
    } else if (apiPath.match(/^hints\/([a-f0-9]+)$/) && req.method === 'GET') {
      const hintId = apiPath.split('/')[1];
      await this.handleAPIHintGet(req, res, hintId, workspace);
    } else if (apiPath.match(/^hints\/([a-f0-9]+)\/ack$/) && req.method === 'POST') {
      const hintId = apiPath.split('/')[1];
      await this.handleAPIHintAck(req, res, hintId, workspace);
    } else if (apiPath.match(/^hints\/([a-f0-9]+)$/) && req.method === 'DELETE') {
      const hintId = apiPath.split('/')[1];
      await this.handleAPIHintAck(req, res, hintId, workspace); // DELETE same as ack
    }
    // Mode endpoints (Goal 266)
    else if (apiPath === 'mode' && req.method === 'GET') {
      await this.handleAPIModeGet(req, res, workspace);
    } else if (apiPath === 'mode/stop' && req.method === 'POST') {
      await this.handleAPIModeStop(req, res, workspace);
    } else {
      this.sendError(res, 404, 'Endpoint not found');
    }
  }

  async handleAPIDocumentation(req, res) {
    try {
      // Use the configured plugin URL if available, otherwise construct from request
      const pluginUrl = process.env.ANICODE_PLUGIN_URL;
      let baseUrl, wsUrl;
      
      if (pluginUrl) {
        // Parse the plugin URL to get HTTP and WebSocket versions
        // Convert ws/wss to http/https for REST API
        baseUrl = pluginUrl.replace(/^wss:/, 'https:').replace(/^ws:/, 'http:');
        wsUrl = pluginUrl;
      } else {
        // Fallback to constructing from request headers
        const protocol = req.headers['x-forwarded-proto'] || 'http';
        const host = req.headers['x-forwarded-host'] || req.headers.host || 'localhost:6502';
        const fullUrl = req.url;
        const basePath = fullUrl.replace(/\/api\/docs.*$/, '');
        
        baseUrl = `${protocol}://${host}${basePath}`;
        const wsProtocol = protocol === 'https' ? 'wss' : 'ws';
        wsUrl = `${wsProtocol}://${host}${basePath}`;
      }
      
      // Debug logging
      logger.debug('[API] Documentation request details:', {
        pluginUrl,
        baseUrl,
        wsUrl,
        headers: req.headers
      });
      
      // Try to read API documentation file
      const docPath = join(__dirname, '..', 'API_DOCUMENTATION.md');
      if (existsSync(docPath)) {
        let documentation = readFileSync(docPath, 'utf8');
        
        // Replace all localhost references with the actual host and path
        documentation = documentation.replace(/http:\/\/localhost:650[12]/g, baseUrl);
        documentation = documentation.replace(/ws:\/\/localhost:650[12]/g, wsUrl);
        
        res.writeHead(200, { 
          'Content-Type': 'text/markdown',
          'Cache-Control': 'public, max-age=3600'
        });
        // For HEAD requests, don't send body
        if (req.method === 'HEAD') {
          res.end();
        } else {
          res.end(documentation);
        }
      } else {
        // Fallback to inline documentation if file not found
        const fallbackDoc = `# AniCode REST API Documentation

## Quick Start
Visit ${baseUrl}/api/docs for full documentation.

## Authentication
All endpoints require: Authorization: Bearer YOUR_TOKEN

## Main Endpoints
- POST /api/task - Submit new task
- GET /api/task/{id} - Get task status
- GET /api/tasks - List tasks
- DELETE /api/task/{id} - Cancel task
`;
        res.writeHead(200, { 'Content-Type': 'text/markdown' });
        // For HEAD requests, don't send body
        if (req.method === 'HEAD') {
          res.end();
        } else {
          res.end(fallbackDoc);
        }
      }
    } catch (error) {
      logger.error('Failed to serve API documentation:', error);
      this.sendError(res, 500, 'Failed to load documentation');
    }
  }

  async handleAPITaskCreate(req, res, workspace) {
    try {
      // Use pre-parsed body if available (from API key validation)
      const body = req.body || await this.parseBody(req);

      logger.info('[API] Task creation request:', {
        workspace: workspace.name,
        body: body
      });

      // Validate required fields
      if (!body.name && !body.command) {
        logger.warn('[API] Task creation failed: missing required fields', { body });
        this.sendError(res, 400, 'Either name or command is required');
        return;
      }

      // Validate model if provided
      if (body.model && !isValidModel(body.model)) {
        logger.warn('[API] Task creation failed: invalid model', { model: body.model, body });
        this.sendError(res, 400, createInvalidModelError(body.model).message);
        return;
      }

      // Create task with workspace context
      const taskName = body.name || body.command || 'API Task';
      const taskCommand = body.command || `ani-code continue "${taskName}"`;

      // Validate command length
      if (taskCommand.length > 10000) {
        logger.warn('[API] Task creation failed: command too long', {
          length: taskCommand.length,
          workspace: workspace.name
        });
        this.sendError(res, 413, 'Command too long (max 10,000 characters)');
        return;
      }

      // Validate that prompt doesn't start with '/' to avoid CLI parsing issues
      if (taskCommand && taskCommand.trim().startsWith('/')) {
        logger.warn('[API] Task creation failed: prompt starts with "/"', {
          command: taskCommand,
          workspace: workspace.name
        });
        this.sendError(res, 400, 'Task prompt cannot start with "/". Prompts starting with "/" may be parsed incorrectly by different CLIs. Please remove the leading "/" from your prompt.');
        return;
      }

      // Extract attachments from request body
      // Attachments can come from body.attachments or body.data.message.attachments (gateway format)
      const attachments = body.attachments || body.data?.message?.attachments || [];
      const hasImages = attachments.some(a => a.type === 'image' && a.url);

      if (hasImages) {
        logger.info('[API] Task includes image attachments:', {
          count: attachments.filter(a => a.type === 'image').length,
          workspace: workspace.name
        });
      }

      // Set source to 'gateway' if the request came from the gateway
      const isGatewaySource = workspace.source === 'gateway';

      // Get current provider ID for usage tracking
      const { getProviderManager } = await import('./providers/providerManager.js');
      const providerManager = await getProviderManager();
      const currentHandler = providerManager.getCurrentHandler();
      const currentProviderId = currentHandler?.id || 'claude';

      const task = this.taskMonitor.addTask(
        taskName,
        taskCommand,
        {
          priority: body.priority || 'normal',
          source: isGatewaySource ? 'gateway' : 'api',
          workspace: workspace.name,
          cwd: workspace.path,
          model: body.model ? normalizeModel(body.model) : undefined,
          providerId: currentProviderId,  // Track provider for stats extraction (gemini, codex, etc.)
          attachments: hasImages ? attachments : undefined,
          metadata: {
            ...body.metadata,
            api_client: true,
            workspace_id: workspace.id,
            hasImages: hasImages,
            imageCount: hasImages ? attachments.filter(a => a.type === 'image').length : 0,
            // Mark as gateway source so notifications route correctly
            ...(isGatewaySource && { source: 'gateway' })
          }
        }
      );
      
      logger.info('[API] Task created successfully:', {
        taskId: task.id,
        name: taskName,
        status: task.status,
        workspace: workspace.name
      });

      // Ensure status is always defined
      const taskStatus = task.status || 'pending';

      // Return task info
      this.sendJSON(res, {
        success: true,
        taskId: task.id,
        status: taskStatus,
        workspace: workspace.name,
        queuePosition: this.taskMonitor.getQueuePosition(task.id)
      }, 201);
      
    } catch (error) {
      logger.error('[API] Task creation failed:', {
        error: error.message,
        stack: error.stack,
        workspace: workspace?.name
      });
      
      // Check if it's a JSON parsing error
      if (error instanceof SyntaxError) {
        this.sendError(res, 400, 'Invalid JSON in request body');
      } else {
        this.sendError(res, 500, error.message);
      }
    }
  }

  async handleAPITaskGet(req, res, taskId, workspace) {
    try {
      const task = this.taskMonitor.getTaskById(taskId);

      if (!task) {
        this.sendError(res, 404, 'Task not found');
        return;
      }

      // Check if task belongs to workspace
      if (task.workspace !== workspace.name) {
        this.sendError(res, 403, 'Access denied');
        return;
      }

      this.sendJSON(res, {
        success: true,
        task: {
          id: task.id,
          name: task.name,
          status: task.status,
          prompt: this.extractPromptFromTask(task),
          provider: this.extractProviderFromTask(task),
          progress: task.progress || 0,
          createdAt: task.createdAt,
          startedAt: task.startedAt,
          completedAt: task.completedAt,
          elapsedSeconds: task.startedAt ? Math.floor((Date.now() - new Date(task.startedAt).getTime()) / 1000) : 0,
          error: task.error,
          workspace: task.workspace,
          workdir: task.workdir
        }
      });

    } catch (error) {
      logger.error('API task get failed:', error);
      this.sendError(res, 500, error.message);
    }
  }

  async handleAPITaskCancel(req, res, taskId, workspace) {
    try {
      const task = this.taskMonitor.getTaskById(taskId);
      
      if (!task) {
        this.sendError(res, 404, 'Task not found');
        return;
      }
      
      // Check if task belongs to workspace
      if (task.workspace !== workspace.name) {
        this.sendError(res, 403, 'Access denied');
        return;
      }
      
      const cancelled = await this.taskMonitor.cancelTask(taskId);
      
      this.sendJSON(res, {
        success: cancelled,
        message: cancelled ? 'Task cancelled' : 'Failed to cancel task'
      });
      
    } catch (error) {
      logger.error('API task cancel failed:', error);
      this.sendError(res, 500, error.message);
    }
  }

  /**
   * PATCH /api/task/:taskId/channel - Update task response channel
   * Allows redirecting task notifications to a different chat/platform
   *
   * Request body:
   * {
   *   "chatId": "telegram:123456789",  // New chat ID
   *   "source": "telegram"              // Optional: new source identifier
   * }
   */
  async handleAPITaskChannelUpdate(req, res, taskId, workspace) {
    try {
      const body = await this.parseBody(req);
      const { chatId, source } = body;

      if (!chatId) {
        this.sendError(res, 400, 'chatId is required');
        return;
      }

      const taskQueue = this.taskMonitor.taskQueue;
      const task = taskQueue.getTask(taskId);

      if (!task) {
        this.sendError(res, 404, 'Task not found');
        return;
      }

      // Check if task belongs to workspace (skip check for gateway-sourced requests)
      if (workspace.source !== 'gateway' && task.workspace !== workspace.name) {
        this.sendError(res, 403, 'Access denied');
        return;
      }

      const oldChatId = task.chatId;
      const oldSource = task.metadata?.source || task.source;
      const wasGatewayTask = oldSource === 'gateway' || task.metadata?.source === 'gateway';

      const updatedTask = taskQueue.updateTaskChannel(taskId, chatId, source);

      if (!updatedTask) {
        this.sendError(res, 500, 'Failed to update task channel');
        return;
      }

      // Notify gateway about the channel redirect so it can send messages to the new channel
      if (wasGatewayTask && source !== 'gateway') {
        this.taskMonitor.notifyGatewayChannelRedirect(updatedTask, oldChatId, oldSource)
          .catch(error => {
            logger.error(`[API] Failed to notify gateway of channel redirect: ${error.message}`);
          });
      }

      logger.info(`[API] Task ${taskId} channel updated: ${oldChatId} -> ${chatId}, source: ${oldSource} -> ${source || 'unchanged'}`);

      this.sendJSON(res, {
        success: true,
        taskId: taskId,
        chatId: chatId,
        source: source || updatedTask.source,
        previousChatId: oldChatId,
        previousSource: oldSource,
        message: 'Task channel updated successfully'
      });

    } catch (error) {
      logger.error('API task channel update failed:', error);
      this.sendError(res, 500, error.message);
    }
  }

  async handleAPITasksList(req, res, query, workspace) {
    try {
      const limit = parseInt(query.limit) || 10;
      const offset = parseInt(query.offset) || 0;
      const statusFilter = query.status;

      // Get all tasks for workspace
      const status = this.taskMonitor.getStatus();
      const allTasks = [...status.running, ...status.pending, ...status.completed];
      const workspaceTasks = allTasks.filter(t => t.workspace === workspace.name);

      // Filter by status if provided
      const filteredTasks = statusFilter ?
        workspaceTasks.filter(t => t.status === statusFilter) :
        workspaceTasks;

      // Apply pagination
      const paginatedTasks = filteredTasks.slice(offset, offset + limit);

      this.sendJSON(res, {
        success: true,
        tasks: paginatedTasks.map(task => ({
          id: task.id,
          name: task.name,
          status: task.status,
          prompt: this.extractPromptFromTask(task),
          provider: this.extractProviderFromTask(task),
          progress: task.progress || 0,
          createdAt: task.createdAt,
          startedAt: task.startedAt,
          elapsedSeconds: task.startedAt ? Math.floor((Date.now() - new Date(task.startedAt).getTime()) / 1000) : 0,
          workspace: task.workspace
        })),
        total: filteredTasks.length,
        limit,
        offset
      });

    } catch (error) {
      logger.error('API tasks list failed:', error);
      this.sendError(res, 500, error.message);
    }
  }

  async handleAPITaskChecklist(req, res, taskId, workspace) {
    try {
      const task = this.taskMonitor.getTaskById(taskId);
      
      if (!task) {
        this.sendError(res, 404, 'Task not found');
        return;
      }
      
      // Check if task belongs to workspace
      if (task.workspace !== workspace.name) {
        this.sendError(res, 403, 'Access denied');
        return;
      }
      
      // Get checklist from task
      const checklist = task.checklist || [];
      
      this.sendJSON(res, {
        success: true,
        taskId: task.id,
        checklist: checklist.map(item => ({
          text: item.text,
          completed: item.completed
        })),
        progress: Math.round((checklist.filter(i => i.completed).length / checklist.length) * 100) || 0
      });

    } catch (error) {
      logger.error('API task checklist failed:', error);
      this.sendError(res, 500, error.message);
    }
  }

  // Plan API endpoints
  async handleAPIPlanCreate(req, res, workspace) {
    let createdPlanId = null;
    let timeoutId = null;

    try {
      // Set a timeout to prevent hanging requests
      const timeoutPromise = new Promise((_, reject) => {
        timeoutId = setTimeout(() => {
          reject(new Error('Plan creation timeout after 30 seconds'));
        }, 30000); // 30 second timeout
      });

      const body = await Promise.race([
        this.parseBody(req),
        timeoutPromise
      ]);

      // Clear timeout after successful body parsing
      if (timeoutId) clearTimeout(timeoutId);

      logger.info('[API] Plan creation request:', {
        workspace: workspace.name,
        body: body
      });

      // Validate required fields
      if (!body.title) {
        logger.warn('[API] Plan creation failed: missing title', { body });
        this.sendError(res, 400, 'Title is required');
        return;
      }

      if (!body.steps || !Array.isArray(body.steps) || body.steps.length === 0) {
        logger.warn('[API] Plan creation failed: missing or invalid steps', { body });
        this.sendError(res, 400, 'Steps array is required and must not be empty');
        return;
      }

      // Create plan with workspace context
      const planData = {
        title: body.title,
        description: body.description || '',
        steps: body.steps,
        createdBy: 'api',
        metadata: {
          ...body.metadata,
          api_client: true,
          workspace_id: workspace.id
        }
      };

      // Set timeout for plan creation
      timeoutId = setTimeout(() => {
        throw new Error('Plan creation database operation timeout after 10 seconds');
      }, 10000); // 10 second timeout for DB operation

      const result = await this.workspaceManager.createPlan(workspace.id, planData);

      // Clear timeout after successful creation
      if (timeoutId) clearTimeout(timeoutId);

      createdPlanId = result.planId;

      logger.info('[API] Plan created successfully:', {
        planId: result.planId,
        title: body.title,
        workspace: workspace.name
      });

      // Return plan info - wrap in try-catch to detect response sending failures
      try {
        this.sendJSON(res, {
          success: true,
          planId: result.planId,
          workspace: workspace.name,
          status: 'pending'
        }, 201);
      } catch (sendError) {
        // If response sending failed, cleanup the plan
        logger.error('[API] Failed to send plan creation response, cleaning up plan:', {
          planId: createdPlanId,
          error: sendError.message
        });

        try {
          await this.workspaceManager.deletePlan(workspace.id, createdPlanId);
          logger.info('[API] Successfully cleaned up plan after response failure:', createdPlanId);
        } catch (cleanupError) {
          logger.error('[API] Failed to clean up plan after response error:', {
            planId: createdPlanId,
            error: cleanupError.message
          });
        }

        throw sendError; // Re-throw to be caught by outer catch block
      }

    } catch (error) {
      // Clear any pending timeout
      if (timeoutId) clearTimeout(timeoutId);

      logger.error('[API] Plan creation failed:', {
        error: error.message,
        stack: error.stack,
        workspace: workspace?.name,
        createdPlanId
      });

      // If plan was created but error occurred during response, clean it up
      if (createdPlanId) {
        try {
          logger.info('[API] Cleaning up partially created plan:', {
            planId: createdPlanId,
            workspace: workspace.name
          });
          await this.workspaceManager.deletePlan(workspace.id, createdPlanId);
          logger.info('[API] Successfully cleaned up plan:', createdPlanId);
        } catch (cleanupError) {
          logger.error('[API] Failed to clean up plan after creation error:', {
            planId: createdPlanId,
            error: cleanupError.message
          });
        }
      }

      // Determine appropriate error code based on error type
      let statusCode = 500;
      let errorMessage = error.message;

      if (error instanceof SyntaxError) {
        statusCode = 400;
        errorMessage = 'Invalid JSON in request body';
      } else if (error.message.includes('timeout')) {
        statusCode = 408; // Request Timeout
        errorMessage = `Request timeout: ${error.message}`;
      } else if (error.message.includes('Workspace not found')) {
        statusCode = 404;
        errorMessage = error.message;
      }

      this.sendError(res, statusCode, errorMessage);
    }
  }

  async handleAPIPlanGet(req, res, planId, workspace) {
    try {
      const plan = await this.workspaceManager.getPlan(workspace.id, planId);

      if (!plan) {
        this.sendError(res, 404, 'Plan not found');
        return;
      }

      this.sendJSON(res, {
        success: true,
        plan: {
          id: plan.plan_id,
          title: plan.title,
          description: plan.description,
          status: plan.status,
          steps: plan.steps,
          currentStep: plan.current_step,
          createdAt: plan.created_at,
          updatedAt: plan.updated_at,
          completedAt: plan.completed_at,
          createdBy: plan.created_by,
          metadata: plan.metadata,
          workspace: workspace.name
        }
      });

    } catch (error) {
      logger.error('API plan get failed:', error);
      this.sendError(res, 500, error.message);
    }
  }

  async handleAPIPlanUpdate(req, res, planId, workspace) {
    try {
      const body = await this.parseBody(req);

      // Validate updates
      const allowedUpdates = ['title', 'description', 'steps', 'status', 'currentStep'];
      const updates = {};

      for (const key of allowedUpdates) {
        if (body.hasOwnProperty(key)) {
          if (key === 'status') {
            // Map status to internal field name
            const validStatuses = ['pending', 'in_progress', 'completed', 'paused', 'failed'];
            if (!validStatuses.includes(body[key])) {
              this.sendError(res, 400, `Invalid status. Must be one of: ${validStatuses.join(', ')}`);
              return;
            }
            // Use updatePlanStatus for status changes
            const updated = await this.workspaceManager.updatePlanStatus(
              workspace.id,
              planId,
              body[key],
              body.currentStep || null
            );
            if (updated) {
              this.sendJSON(res, {
                success: true,
                message: 'Plan status updated successfully'
              });
            } else {
              this.sendError(res, 404, 'Plan not found or update failed');
            }
            return;
          } else {
            updates[key] = body[key];
          }
        }
      }

      if (Object.keys(updates).length === 0) {
        this.sendError(res, 400, 'No valid updates provided');
        return;
      }

      const result = await this.workspaceManager.updatePlan(workspace.id, planId, updates);

      if (result.success) {
        this.sendJSON(res, {
          success: true,
          message: result.message
        });
      } else {
        this.sendError(res, 400, result.message);
      }

    } catch (error) {
      logger.error('API plan update failed:', error);
      this.sendError(res, 500, error.message);
    }
  }

  async handleAPIPlanDelete(req, res, planId, workspace) {
    try {
      const deleted = await this.workspaceManager.deletePlan(workspace.id, planId);

      if (deleted) {
        this.sendJSON(res, {
          success: true,
          message: 'Plan deleted successfully'
        });
      } else {
        this.sendError(res, 404, 'Plan not found');
      }

    } catch (error) {
      logger.error('API plan delete failed:', error);
      this.sendError(res, 500, error.message);
    }
  }

  async handleAPIPlansList(req, res, query, workspace) {
    try {
      const statusFilter = query.status || null;
      const limit = parseInt(query.limit) || 10;
      const offset = parseInt(query.offset) || 0;

      // Get all plans for workspace
      const plans = await this.workspaceManager.listPlans(workspace.id, statusFilter);

      // Apply pagination
      const paginatedPlans = plans.slice(offset, offset + limit);

      this.sendJSON(res, {
        success: true,
        plans: paginatedPlans.map(plan => ({
          id: plan.plan_id,
          title: plan.title,
          description: plan.description,
          status: plan.status,
          stepsCount: plan.steps.length,
          currentStep: plan.current_step,
          createdAt: plan.created_at,
          updatedAt: plan.updated_at,
          completedAt: plan.completed_at,
          createdBy: plan.created_by,
          workspace: workspace.name
        })),
        total: plans.length,
        limit,
        offset
      });

    } catch (error) {
      logger.error('API plans list failed:', error);
      this.sendError(res, 500, error.message);
    }
  }

  async handleAPIPlanExecute(req, res, workspace) {
    try {
      const body = await this.parseBody(req);

      // Get the next pending plan or specified plan
      let plan;
      if (body.planId) {
        plan = await this.workspaceManager.getPlan(workspace.id, body.planId);
        if (!plan) {
          this.sendError(res, 404, 'Plan not found');
          return;
        }
        if (plan.status !== 'pending') {
          this.sendError(res, 400, `Plan is not in pending status (current: ${plan.status})`);
          return;
        }
      } else {
        plan = await this.workspaceManager.getNextPlan(workspace.id);
        if (!plan) {
          this.sendError(res, 404, 'No pending plans found');
          return;
        }
      }

      // Update plan status to in_progress
      await this.workspaceManager.updatePlanStatus(workspace.id, plan.plan_id, 'in_progress', 0);

      // Create a task to execute the plan
      const taskCommand = `ani-code plan execute ${plan.plan_id}`;
      const isGatewaySource = workspace.source === 'gateway';
      const task = this.taskMonitor.addTask(
        `Execute Plan: ${plan.title}`,
        taskCommand,
        {
          priority: body.priority || 'normal',
          source: isGatewaySource ? 'gateway' : 'api',
          workspace: workspace.name,
          cwd: workspace.path,
          metadata: {
            ...body.metadata,
            api_client: true,
            workspace_id: workspace.id,
            plan_id: plan.plan_id,
            plan_execution: true,
            ...(isGatewaySource && { source: 'gateway' })
          }
        }
      );

      logger.info('[API] Plan execution started:', {
        planId: plan.plan_id,
        taskId: task.id,
        title: plan.title,
        workspace: workspace.name
      });

      this.sendJSON(res, {
        success: true,
        planId: plan.plan_id,
        taskId: task.id,
        title: plan.title,
        status: 'in_progress',
        workspace: workspace.name,
        message: 'Plan execution started'
      });

    } catch (error) {
      logger.error('API plan execute failed:', error);
      this.sendError(res, 500, error.message);
    }
  }

  async handleAPIPlansSummary(req, res, workspace) {
    try {
      const summary = await this.workspaceManager.getPlanSummary(workspace.id);

      if (!summary) {
        this.sendJSON(res, {
          success: true,
          summary: {
            total: 0,
            byStatus: {},
            progress: {
              totalSteps: 0,
              completedSteps: 0,
              percentage: 0
            },
            workspace: workspace.name
          }
        });
        return;
      }

      this.sendJSON(res, {
        success: true,
        summary: {
          ...summary,
          workspace: workspace.name
        }
      });

    } catch (error) {
      logger.error('API plans summary failed:', error);
      this.sendError(res, 500, error.message);
    }
  }

  // Goal API Handlers

  /**
   * GET /api/goals - List all goals with optional filters
   */
  async handleAPIGoalsList(req, res, query, workspace) {
    try {
      logger.info('[API] Goals list request:', {
        workspace: workspace.name,
        query
      });

      // Parse query parameters
      const status = query?.status;
      const limit = parseInt(query?.limit) || 100;
      const offset = parseInt(query?.offset) || 0;

      // Get goals directory
      const goalsDir = join(workspace.path, 'pd', 'goals');

      // Check if goals directory exists
      if (!existsSync(goalsDir)) {
        this.sendJSON(res, {
          goals: [],
          total: 0,
          limit,
          offset
        });
        return;
      }

      // Create processor and load cache
      const processor = createGoalsProcessor(goalsDir);
      const { data: cacheData, exists } = await processor.loadCache();

      // If no cache, sync first (fast mode)
      if (!exists || !cacheData) {
        logger.info('[API] No goals cache found, running sync');
        await processor.processGoals('sync', { fastMode: true });
        const { data: newCache } = await processor.loadCache();
        if (!newCache) {
          this.sendJSON(res, {
            goals: [],
            total: 0,
            limit,
            offset
          });
          return;
        }
        Object.assign(cacheData || {}, newCache);
      }

      let goals = cacheData.goals || [];

      // Filter by status if provided
      if (status) {
        goals = goals.filter(g => {
          const goalStatus = g.status || g.progress?.status || 'Not Started';
          return goalStatus.toLowerCase() === status.toLowerCase();
        });
      }

      // Sort by ID
      goals.sort((a, b) => (a.id || 0) - (b.id || 0));

      // Apply pagination
      const total = goals.length;
      const paginatedGoals = goals.slice(offset, offset + limit);

      // Transform goals for API response
      const transformedGoals = paginatedGoals.map(goal => ({
        id: String(goal.id).padStart(3, '0'),
        goalNumber: goal.id,
        title: goal.title || goal.file.replace(/^\d+-/, '').replace(/\.md$/, '').replace(/-/g, ' '),
        status: goal.status || goal.progress?.status || 'Not Started',
        stage: goal.stage || '',
        progress: goal.completionPercentage || 0,
        startDate: goal.progress?.startDate || null,
        completionDate: goal.progress?.completionDate || null,
        description: goal.description || '',
        objective: goal.objective || '',
        tasks: goal.tasks || [],
        acceptanceCriteria: goal.acceptanceCriteria || [],
        dependencies: goal.dependencies || [],
        tags: goal.tags || [],
        priority: goal.priority || 'medium',
        file: goal.file,
        filePath: goal.path || join(goalsDir, goal.file),
        createdAt: goal.createdAt || null,
        updatedAt: goal.updatedAt || cacheData.lastUpdated || null
      }));

      this.sendJSON(res, {
        goals: transformedGoals,
        total,
        limit,
        offset
      });

    } catch (error) {
      logger.error('[API] Goals list failed:', {
        error: error.message,
        workspace: workspace?.name
      });
      this.sendError(res, 500, error.message);
    }
  }

  /**
   * GET /api/goals/:goalId - Get specific goal details
   */
  async handleAPIGoalGet(req, res, goalId, workspace) {
    try {
      logger.info('[API] Goal get request:', {
        goalId,
        workspace: workspace.name
      });

      const goalsDir = join(workspace.path, 'pd', 'goals');

      if (!existsSync(goalsDir)) {
        this.sendError(res, 404, 'Goals directory not found');
        return;
      }

      // Create processor and load cache
      const processor = createGoalsProcessor(goalsDir);
      const { data: cacheData } = await processor.loadCache();

      if (!cacheData || !cacheData.goals) {
        this.sendError(res, 404, 'No goals found');
        return;
      }

      // Find goal by ID or filename
      const goal = cacheData.goals.find(g =>
        g.id === parseInt(goalId) ||
        String(g.id).padStart(3, '0') === goalId ||
        g.file.includes(goalId) ||
        g.file === goalId
      );

      if (!goal) {
        this.sendError(res, 404, `Goal "${goalId}" not found`);
        return;
      }

      // Read full content if file exists
      let content = '';
      let contentHtml = '';
      if (goal.path && existsSync(goal.path)) {
        content = readFileSync(goal.path, 'utf8');
        // Basic markdown to HTML conversion (could be enhanced)
        contentHtml = content
          .replace(/^### (.*$)/gim, '<h3>$1</h3>')
          .replace(/^## (.*$)/gim, '<h2>$1</h2>')
          .replace(/^# (.*$)/gim, '<h1>$1</h1>')
          .replace(/^\- \[x\] (.*$)/gim, '<li>☑ $1</li>')
          .replace(/^\- \[ \] (.*$)/gim, '<li>☐ $1</li>')
          .replace(/\*\*(.*)\*\*/g, '<strong>$1</strong>')
          .replace(/\n/g, '<br>');
      }

      const transformedGoal = {
        id: String(goal.id).padStart(3, '0'),
        goalNumber: goal.id,
        title: goal.title || goal.file.replace(/^\d+-/, '').replace(/\.md$/, '').replace(/-/g, ' '),
        status: goal.status || goal.progress?.status || 'Not Started',
        stage: goal.stage || '',
        progress: goal.completionPercentage || 0,
        content,
        contentHtml,
        tasks: goal.tasks || [],
        acceptanceCriteria: goal.acceptanceCriteria || [],
        dependencies: goal.dependencies || [],
        metadata: {
          estimatedHours: goal.estimatedHours || null,
          actualHours: goal.actualHours || null,
          assignee: goal.assignee || 'Claude'
        }
      };

      this.sendJSON(res, {
        goal: transformedGoal
      });

    } catch (error) {
      logger.error('[API] Goal get failed:', {
        error: error.message,
        goalId,
        workspace: workspace?.name
      });
      this.sendError(res, 500, error.message);
    }
  }

  /**
   * POST /api/goals - Create new goal
   */
  async handleAPIGoalCreate(req, res, workspace) {
    try {
      const body = req.body || await this.parseBody(req);

      logger.info('[API] Goal create request:', {
        workspace: workspace.name,
        body
      });

      // Validate required fields
      if (!body.title) {
        this.sendError(res, 400, 'Title is required');
        return;
      }

      const goalsDir = join(workspace.path, 'pd', 'goals');
      mkdirSync(goalsDir, { recursive: true });

      // Find existing goals to determine next ID
      const goalFiles = findGoalFiles(goalsDir);
      const existingIds = goalFiles.map(f => extractGoalId(basename(f))).filter(id => id !== null);
      const goalId = existingIds.length > 0 ? Math.max(...existingIds) + 1 : 1;
      const paddedId = String(goalId).padStart(3, '0');

      // Generate filename from title
      const slug = body.title
        .toLowerCase()
        .trim()
        .replace(/^(implement|create|add|build|develop|setup|configure|fix|update)\s+/i, '')
        .replace(/\b(a|an|the|for|with|and|or|in|on|at|to|from)\b/g, ' ')
        .replace(/[^a-z0-9\s-]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .split(' ')
        .slice(0, 4)
        .join('-')
        .replace(/^-+|-+$/g, '') || 'new-goal';

      const filename = `${paddedId}-${slug}.md`;
      const targetFile = join(goalsDir, filename);

      // Build goal content
      let content = `---
title: "${body.title}"
status: ${body.status || 'Not Started'}
progress: ${body.progress || 0}
priority: ${body.priority || 'medium'}
estimatedHours: ${body.estimatedHours || 0}
---

# Goal ${paddedId}: ${body.title}

## Objective
${body.objective || 'To be defined'}

## Stage
${body.stage || 'Planning'}

## Description
${body.description || 'To be defined'}

## Tasks
${(body.tasks || []).map(task =>
  typeof task === 'string'
    ? `- [ ] ${task}`
    : `- [${task.completed ? 'x' : ' '}] ${task.text}`
).join('\n')}

## Acceptance Criteria
${(body.acceptanceCriteria || []).map(criteria => `- ${criteria}`).join('\n')}

## Dependencies
${(body.dependencies || []).map(dep => `- Goal ${dep}`).join('\n')}

## Progress
- Status: **${body.status || 'Not Started'}**
- Start Date: ${new Date().toISOString().split('T')[0]}
- Completion Date: -
- Notes: Goal created via API
`;

      // Write goal file
      writeFileSync(targetFile, content);

      // Update cache
      const processor = createGoalsProcessor(goalsDir);
      await processor.processGoals('sync', { fastMode: true });

      logger.info('[API] Goal created successfully:', {
        goalId,
        filename,
        workspace: workspace.name
      });

      this.sendJSON(res, {
        success: true,
        goal: {
          id: paddedId,
          goalNumber: goalId,
          title: body.title,
          file: filename,
          filePath: targetFile,
          createdAt: new Date().toISOString()
        }
      }, 201);

    } catch (error) {
      logger.error('[API] Goal create failed:', {
        error: error.message,
        workspace: workspace?.name
      });
      this.sendError(res, 500, error.message);
    }
  }

  /**
   * PUT /api/goals/:goalId - Update existing goal
   */
  async handleAPIGoalUpdate(req, res, goalId, workspace) {
    try {
      const body = req.body || await this.parseBody(req);

      logger.info('[API] Goal update request:', {
        goalId,
        workspace: workspace.name,
        body
      });

      const goalsDir = join(workspace.path, 'pd', 'goals');

      if (!existsSync(goalsDir)) {
        this.sendError(res, 404, 'Goals directory not found');
        return;
      }

      // Find goal file
      const goalFiles = findGoalFiles(goalsDir);
      let targetFile = null;

      // Try to parse as number
      const numId = parseInt(goalId);
      if (!isNaN(numId)) {
        targetFile = findGoalFileById(numId, goalFiles);
      }

      // Try by filename match
      if (!targetFile) {
        targetFile = goalFiles.find(f => basename(f).includes(goalId));
      }

      if (!targetFile || !existsSync(targetFile)) {
        this.sendError(res, 404, `Goal "${goalId}" not found`);
        return;
      }

      // Read existing content
      let content = readFileSync(targetFile, 'utf8');

      // Update status if provided
      if (body.status) {
        content = content.replace(
          /^status:\s*.+$/m,
          `status: ${body.status}`
        );
        content = content.replace(
          /^-\s*Status:\s*\*\*.+?\*\*/m,
          `- Status: **${body.status}**`
        );
      }

      // Update progress if provided
      if (body.progress !== undefined) {
        content = content.replace(
          /^progress:\s*\d+/m,
          `progress: ${body.progress}`
        );
      }

      // Update tasks if provided
      if (body.tasks && Array.isArray(body.tasks)) {
        // Find tasks section and replace
        const tasksStart = content.indexOf('## Tasks');
        const tasksEnd = content.indexOf('\n## ', tasksStart + 1);

        if (tasksStart !== -1) {
          const beforeTasks = content.substring(0, tasksStart);
          const afterTasks = tasksEnd !== -1 ? content.substring(tasksEnd) : '';

          const tasksContent = body.tasks.map(task => {
            if (typeof task === 'string') {
              return `- [ ] ${task}`;
            } else {
              return `- [${task.completed ? 'x' : ' '}] ${task.text}`;
            }
          }).join('\n');

          content = beforeTasks + '## Tasks\n' + tasksContent + '\n' + afterTasks;
        }
      }

      // Update notes if provided
      if (body.notes) {
        const notesMatch = content.match(/^-\s*Notes:\s*.+$/m);
        if (notesMatch) {
          content = content.replace(notesMatch[0], `- Notes: ${body.notes}`);
        } else {
          // Add notes after status
          content = content.replace(
            /^-\s*Status:\s*\*\*.+?\*\*$/m,
            `$&\n- Notes: ${body.notes}`
          );
        }
      }

      // Write updated content
      writeFileSync(targetFile, content);

      // Update cache
      const processor = createGoalsProcessor(goalsDir);
      await processor.processGoals('sync', { fastMode: true });

      logger.info('[API] Goal updated successfully:', {
        goalId,
        workspace: workspace.name
      });

      this.sendJSON(res, {
        success: true,
        goal: {
          id: goalId,
          status: body.status,
          progress: body.progress,
          updatedAt: new Date().toISOString()
        }
      });

    } catch (error) {
      logger.error('[API] Goal update failed:', {
        error: error.message,
        goalId,
        workspace: workspace?.name
      });
      this.sendError(res, 500, error.message);
    }
  }

  /**
   * DELETE /api/goals/:goalId - Delete or archive goal
   */
  async handleAPIGoalDelete(req, res, goalId, workspace) {
    try {
      const query = parse(req.url, true).query;
      const archive = query.archive !== 'false'; // Default to archive

      logger.info('[API] Goal delete request:', {
        goalId,
        archive,
        workspace: workspace.name
      });

      const goalsDir = join(workspace.path, 'pd', 'goals');

      if (!existsSync(goalsDir)) {
        this.sendError(res, 404, 'Goals directory not found');
        return;
      }

      // Find goal file
      const goalFiles = findGoalFiles(goalsDir);
      let targetFile = null;

      const numId = parseInt(goalId);
      if (!isNaN(numId)) {
        targetFile = findGoalFileById(numId, goalFiles);
      }

      if (!targetFile) {
        targetFile = goalFiles.find(f => basename(f).includes(goalId));
      }

      if (!targetFile || !existsSync(targetFile)) {
        this.sendError(res, 404, `Goal "${goalId}" not found`);
        return;
      }

      const filename = basename(targetFile);

      if (archive) {
        // Archive the goal
        const archiveDir = join(goalsDir, 'archive');
        mkdirSync(archiveDir, { recursive: true });

        const archivePath = join(archiveDir, filename);
        const content = readFileSync(targetFile, 'utf8');
        writeFileSync(archivePath, content);

        // Delete original
        const { unlinkSync } = await import('fs');
        unlinkSync(targetFile);

        logger.info('[API] Goal archived:', {
          goalId,
          archivePath,
          workspace: workspace.name
        });

        this.sendJSON(res, {
          success: true,
          action: 'archived',
          archivedPath: archivePath
        });
      } else {
        // Delete the goal
        const { unlinkSync } = await import('fs');
        unlinkSync(targetFile);

        logger.info('[API] Goal deleted:', {
          goalId,
          workspace: workspace.name
        });

        this.sendJSON(res, {
          success: true,
          action: 'deleted'
        });
      }

      // Update cache
      const processor = createGoalsProcessor(goalsDir);
      await processor.processGoals('sync', { fastMode: true });

    } catch (error) {
      logger.error('[API] Goal delete failed:', {
        error: error.message,
        goalId,
        workspace: workspace?.name
      });
      this.sendError(res, 500, error.message);
    }
  }

  /**
   * GET /api/goals/running - Get running goals
   */
  async handleAPIGoalsRunning(req, res, query, workspace) {
    try {
      logger.info('[API] Running goals request:', {
        workspace: workspace.name,
        query
      });

      const limit = parseInt(query?.limit) || 50;
      const goalsDir = join(workspace.path, 'pd', 'goals');

      if (!existsSync(goalsDir)) {
        this.sendJSON(res, {
          runningGoals: [],
          total: 0
        });
        return;
      }

      // Create processor and load cache
      const processor = createGoalsProcessor(goalsDir);
      const { data: cacheData } = await processor.loadCache();

      if (!cacheData || !cacheData.goals) {
        this.sendJSON(res, {
          runningGoals: [],
          total: 0
        });
        return;
      }

      // Filter for in-progress goals
      const runningGoals = cacheData.goals
        .filter(g => {
          const status = g.status || g.progress?.status || 'Not Started';
          return status === 'In Progress';
        })
        .slice(0, limit)
        .map(goal => ({
          id: String(goal.id).padStart(3, '0'),
          title: goal.title || goal.file.replace(/^\d+-/, '').replace(/\.md$/, '').replace(/-/g, ' '),
          status: 'in_progress',
          progress: goal.completionPercentage || 0,
          startDate: goal.progress?.startDate || null,
          tasks: goal.tasks || []
        }));

      this.sendJSON(res, {
        runningGoals,
        total: runningGoals.length
      });

    } catch (error) {
      logger.error('[API] Running goals failed:', {
        error: error.message,
        workspace: workspace?.name
      });
      this.sendError(res, 500, error.message);
    }
  }

  /**
   * POST /api/goals/sync - Sync goals from filesystem
   */
  async handleAPIGoalsSync(req, res, workspace) {
    try {
      const body = req.body || await this.parseBody(req);

      logger.info('[API] Goals sync request:', {
        workspace: workspace.name,
        force: body?.force,
        verbose: body?.verbose
      });

      const goalsDir = join(workspace.path, 'pd', 'goals');

      // Create goals directory if it doesn't exist
      mkdirSync(goalsDir, { recursive: true });

      // Create processor with options
      const processor = createGoalsProcessor(goalsDir, {
        fullResync: body?.force || false,
        verbose: body?.verbose || false,
        autoConfirm: true // For API, always auto-confirm
      });

      // Track sync start time
      const startTime = Date.now();

      // Perform sync
      const result = await processor.processGoals('sync', {
        fastMode: !body?.force // Use fast mode unless force is specified
      });

      if (!result.success) {
        this.sendError(res, 500, result.message || 'Sync failed');
        return;
      }

      // Load updated cache for summary
      const { data: cacheData } = await processor.loadCache();

      // Calculate sync statistics
      const goalFiles = findGoalFiles(goalsDir);
      const duration = ((Date.now() - startTime) / 1000).toFixed(1);

      const syncResult = {
        goalsFound: goalFiles.length,
        goalsUpdated: result.goalsUpdated || 0,
        goalsCreated: result.goalsCreated || 0,
        goalsDeleted: result.goalsDeleted || 0,
        errors: result.errors || [],
        duration: `${duration}s`,
        timestamp: new Date().toISOString()
      };

      logger.info('[API] Goals sync completed:', {
        ...syncResult,
        workspace: workspace.name
      });

      this.sendJSON(res, {
        success: true,
        syncResult
      });

    } catch (error) {
      logger.error('[API] Goals sync failed:', {
        error: error.message,
        workspace: workspace?.name
      });
      this.sendError(res, 500, error.message);
    }
  }

  // Provider API Handlers

  /**
   * GET /api/providers - List all available CLI providers
   */
  async handleAPIProvidersList(req, res, query, workspace) {
    try {
      logger.info('[API] Providers list request:', {
        workspace: workspace.name,
        query
      });

      // Get provider manager
      const { getProviderManager } = await import('./providers/providerManager.js');
      const providerManager = await getProviderManager();

      // Check if we should include unavailable providers
      const includeAll = query?.all === 'true' || query?.all === '1';

      // Get providers with full metadata
      const providers = providerManager.listProvidersWithMetadata();

      // Filter unavailable if not requested
      const filteredProviders = includeAll
        ? providers
        : providers.filter(p => p.available);

      // Sort: current first, then by name
      filteredProviders.sort((a, b) => {
        if (a.current && !b.current) return -1;
        if (!a.current && b.current) return 1;
        return a.name.localeCompare(b.name);
      });

      this.sendJSON(res, {
        success: true,
        providers: filteredProviders,
        timestamp: new Date().toISOString()
      });

    } catch (error) {
      logger.error('[API] Providers list failed:', {
        error: error.message,
        workspace: workspace?.name
      });
      this.sendError(res, 500, error.message);
    }
  }

  /**
   * GET /api/providers/:id - Get specific provider details
   */
  async handleAPIProviderGet(req, res, providerId, workspace) {
    try {
      logger.info('[API] Provider get request:', {
        providerId,
        workspace: workspace.name
      });

      // Get provider manager
      const { getProviderManager } = await import('./providers/providerManager.js');
      const providerManager = await getProviderManager();

      // Get provider info
      const providerInfo = providerManager.getHandlerInfo(providerId);

      if (!providerInfo) {
        this.sendError(res, 404, `Provider '${providerId}' not found`);
        return;
      }

      // Get models with pricing
      const models = providerManager.getProviderModelsWithPricing(providerId);

      this.sendJSON(res, {
        success: true,
        provider: {
          ...providerInfo,
          models: models.slice(0, 5).map(m => m.id), // First 5 model IDs as preview
          modelCount: models.length
        },
        timestamp: new Date().toISOString()
      });

    } catch (error) {
      logger.error('[API] Provider get failed:', {
        error: error.message,
        providerId,
        workspace: workspace?.name
      });
      this.sendError(res, 500, error.message);
    }
  }

  /**
   * GET /api/providers/:id/models - Get models for a specific provider
   */
  async handleAPIProviderModels(req, res, providerId, query, workspace) {
    try {
      logger.info('[API] Provider models request:', {
        providerId,
        workspace: workspace.name,
        query
      });

      // Get provider manager
      const { getProviderManager } = await import('./providers/providerManager.js');
      const providerManager = await getProviderManager();

      // Check if provider exists
      const providerInfo = providerManager.getHandlerInfo(providerId);

      if (!providerInfo) {
        this.sendError(res, 404, `Provider '${providerId}' not found`);
        return;
      }

      // Get models with pricing
      const models = providerManager.getProviderModelsWithPricing(providerId);

      // Filter by enabled status if requested
      const enabledFilter = query?.enabled;
      let filteredModels = models;
      if (enabledFilter === 'true' || enabledFilter === '1') {
        filteredModels = models.filter(m => m.enabled);
      } else if (enabledFilter === 'false' || enabledFilter === '0') {
        filteredModels = models.filter(m => !m.enabled);
      }

      // Set default model (first model or env-configured)
      const defaultModel = process.env[`CLI_PROVIDER_${providerId.toUpperCase()}_DEFAULT_MODEL`] || null;
      filteredModels = filteredModels.map(m => ({
        ...m,
        default: defaultModel ? m.id === defaultModel : false
      }));

      // If no default set, mark first model as default
      if (!filteredModels.some(m => m.default) && filteredModels.length > 0) {
        filteredModels[0].default = true;
      }

      this.sendJSON(res, {
        success: true,
        providerId,
        providerName: providerInfo.name,
        models: filteredModels,
        timestamp: new Date().toISOString()
      });

    } catch (error) {
      logger.error('[API] Provider models failed:', {
        error: error.message,
        providerId,
        workspace: workspace?.name
      });
      this.sendError(res, 500, error.message);
    }
  }

  /**
   * PATCH /api/providers/:id - Update provider configuration (enable/disable)
   */
  async handleAPIProviderUpdate(req, res, providerId, workspace) {
    try {
      const body = req.body || await this.parseBody(req);

      logger.info('[API] Provider update request:', {
        providerId,
        workspace: workspace.name,
        body
      });

      // Get provider manager
      const { getProviderManager } = await import('./providers/providerManager.js');
      const providerManager = await getProviderManager();

      // Check if provider exists
      const providerInfo = providerManager.getHandlerInfo(providerId);

      if (!providerInfo) {
        this.sendError(res, 404, `Provider '${providerId}' not found`);
        return;
      }

      // Handle enabled state change
      if (Object.prototype.hasOwnProperty.call(body, 'enabled')) {
        const enabled = !!body.enabled;

        // For now, we track this in memory
        // In future, persist to workspace settings
        logger.info('[API] Provider enabled state changed:', {
          providerId,
          enabled,
          workspace: workspace.name
        });

        // Note: Provider enable/disable would need persistent storage
        // For MVP, we acknowledge the request but don't persist
        this.sendJSON(res, {
          success: true,
          providerId,
          enabled,
          message: enabled ? 'Provider enabled' : 'Provider disabled',
          note: 'Provider state change acknowledged (persistence not yet implemented)'
        });
        return;
      }

      // Handle switching current provider
      if (Object.prototype.hasOwnProperty.call(body, 'current') && body.current === true) {
        try {
          providerManager.switchProvider(providerId);
          this.sendJSON(res, {
            success: true,
            providerId,
            current: true,
            message: `Switched to provider: ${providerId}`
          });
        } catch (err) {
          this.sendError(res, 400, err.message);
        }
        return;
      }

      this.sendError(res, 400, 'No valid updates provided. Use "enabled" or "current" fields.');

    } catch (error) {
      logger.error('[API] Provider update failed:', {
        error: error.message,
        providerId,
        workspace: workspace?.name
      });
      this.sendError(res, 500, error.message);
    }
  }

  /**
   * PATCH /api/providers/:id/models/:modelId - Update model configuration
   */
  async handleAPIProviderModelUpdate(req, res, providerId, modelId, workspace) {
    try {
      const body = req.body || await this.parseBody(req);

      logger.info('[API] Provider model update request:', {
        providerId,
        modelId,
        workspace: workspace.name,
        body
      });

      // Get provider manager
      const { getProviderManager } = await import('./providers/providerManager.js');
      const providerManager = await getProviderManager();

      // Check if provider exists
      const providerInfo = providerManager.getHandlerInfo(providerId);

      if (!providerInfo) {
        this.sendError(res, 404, `Provider '${providerId}' not found`);
        return;
      }

      // Check if model exists
      const models = providerManager.getProviderModelsWithPricing(providerId);
      const decodedModelId = decodeURIComponent(modelId);
      const model = models.find(m => m.id === decodedModelId);

      if (!model) {
        this.sendError(res, 404, `Model '${decodedModelId}' not found for provider '${providerId}'`);
        return;
      }

      // Handle enabled state change
      if (Object.prototype.hasOwnProperty.call(body, 'enabled')) {
        const enabled = !!body.enabled;

        logger.info('[API] Model enabled state changed:', {
          providerId,
          modelId: decodedModelId,
          enabled,
          workspace: workspace.name
        });

        // Note: Model enable/disable would need persistent storage
        this.sendJSON(res, {
          success: true,
          providerId,
          modelId: decodedModelId,
          enabled,
          message: enabled ? 'Model enabled' : 'Model disabled',
          note: 'Model state change acknowledged (persistence not yet implemented)'
        });
        return;
      }

      // Handle setting as default model
      if (Object.prototype.hasOwnProperty.call(body, 'default') && body.default === true) {
        logger.info('[API] Default model changed:', {
          providerId,
          modelId: decodedModelId,
          workspace: workspace.name
        });

        this.sendJSON(res, {
          success: true,
          providerId,
          modelId: decodedModelId,
          default: true,
          message: `Set '${decodedModelId}' as default model for '${providerId}'`,
          note: 'Default model setting acknowledged (persistence not yet implemented)'
        });
        return;
      }

      this.sendError(res, 400, 'No valid updates provided. Use "enabled" or "default" fields.');

    } catch (error) {
      logger.error('[API] Provider model update failed:', {
        error: error.message,
        providerId,
        modelId,
        workspace: workspace?.name
      });
      this.sendError(res, 500, error.message);
    }
  }

  // ==================== Hint Endpoints ====================

  /**
   * GET /api/hints - List active hints
   * Query params: all=true to include acknowledged hints
   */
  async handleAPIHintsList(req, res, query, workspace) {
    try {
      const hintManager = new HintManager(workspace.path);
      const includeAll = query.all === 'true';

      let hints;
      if (includeAll) {
        hints = await hintManager.listAllHints();
      } else {
        hints = await hintManager.getActiveHints();
      }

      // Format hints for API response
      const formattedHints = hints.map(hint => ({
        id: hint.id,
        content: hint.content,
        source: hint.source,
        isActive: hint.isActive !== false,
        created: hint.created.toISOString(),
        expires: hint.expires.toISOString(),
        ageMinutes: hint.ageMinutes,
        ageText: hint.ageText
      }));

      this.sendJSON(res, {
        success: true,
        hints: formattedHints,
        count: formattedHints.length,
        activeCount: formattedHints.filter(h => h.isActive).length,
        timestamp: new Date().toISOString()
      });

    } catch (error) {
      logger.error('[API] Hints list failed:', {
        error: error.message,
        workspace: workspace?.name
      });
      this.sendError(res, 500, error.message);
    }
  }

  /**
   * POST /api/hints - Create a new hint
   * Body: { content: string, source?: string }
   */
  async handleAPIHintCreate(req, res, workspace) {
    try {
      const body = await this.parseBody(req);

      if (!body.content) {
        this.sendError(res, 400, 'Hint content is required');
        return;
      }

      const hintManager = new HintManager(workspace.path);
      const source = body.source || 'api';
      const result = await hintManager.createHint(body.content, source);

      logger.info('[API] Hint created:', {
        hintId: result.id,
        source,
        workspace: workspace.name
      });

      this.sendJSON(res, {
        success: true,
        hint: {
          id: result.id,
          filename: result.filename,
          expires: result.expires.toISOString(),
          created: result.created.toISOString()
        },
        message: 'Hint created successfully'
      });

    } catch (error) {
      logger.error('[API] Hint create failed:', {
        error: error.message,
        workspace: workspace?.name
      });
      this.sendError(res, 500, error.message);
    }
  }

  /**
   * GET /api/hints/:id - Get a specific hint
   */
  async handleAPIHintGet(req, res, hintId, workspace) {
    try {
      const hintManager = new HintManager(workspace.path);
      const hint = await hintManager.getHintById(hintId);

      if (!hint) {
        this.sendError(res, 404, `Hint ${hintId} not found`);
        return;
      }

      this.sendJSON(res, {
        success: true,
        hint: {
          id: hint.id,
          content: hint.content,
          source: hint.source,
          isActive: hint.isActive,
          created: hint.created.toISOString(),
          expires: hint.expires.toISOString()
        }
      });

    } catch (error) {
      logger.error('[API] Hint get failed:', {
        error: error.message,
        hintId,
        workspace: workspace?.name
      });
      this.sendError(res, 500, error.message);
    }
  }

  /**
   * POST /api/hints/:id/ack - Acknowledge a hint
   * DELETE /api/hints/:id - Same as ack
   */
  async handleAPIHintAck(req, res, hintId, workspace) {
    try {
      const hintManager = new HintManager(workspace.path);
      const success = await hintManager.ackHint(hintId);

      if (!success) {
        this.sendError(res, 404, `Hint ${hintId} not found or already acknowledged`);
        return;
      }

      logger.info('[API] Hint acknowledged:', {
        hintId,
        workspace: workspace.name
      });

      this.sendJSON(res, {
        success: true,
        hintId,
        message: 'Hint acknowledged successfully'
      });

    } catch (error) {
      logger.error('[API] Hint ack failed:', {
        error: error.message,
        hintId,
        workspace: workspace?.name
      });
      this.sendError(res, 500, error.message);
    }
  }

  /**
   * DELETE /api/hints - Clear all active hints
   */
  async handleAPIHintsClear(req, res, workspace) {
    try {
      const hintManager = new HintManager(workspace.path);
      const count = await hintManager.clearHints();

      logger.info('[API] Hints cleared:', {
        count,
        workspace: workspace.name
      });

      this.sendJSON(res, {
        success: true,
        cleared: count,
        message: `Cleared ${count} hint(s)`
      });

    } catch (error) {
      logger.error('[API] Hints clear failed:', {
        error: error.message,
        workspace: workspace?.name
      });
      this.sendError(res, 500, error.message);
    }
  }

  /**
   * GET /api/mode - Get current daemon mode state (Goal 266)
   * Returns: { mode: 'chat'|'yolo'|'goal', active: boolean, details: {...} }
   */
  async handleAPIModeGet(req, res, workspace) {
    try {
      const httpServer = global.httpServer;

      // Default mode is chat (normal conversation mode)
      let mode = 'chat';
      let active = false;
      let details = {};

      // Check YOLO mode first (highest priority)
      if (workspace.yolo_mode_active) {
        mode = 'yolo';
        active = true;
        details = {
          startTime: workspace.yolo_start_time,
          plansTotal: workspace.yolo_plans_total,
          plansCompleted: workspace.yolo_plans_completed,
          currentPlan: workspace.yolo_current_plan,
          scheduled: workspace.yolo_scheduled_time ? true : false,
          scheduledTime: workspace.yolo_scheduled_time
        };
      }

      // Check for in-memory YOLO state (more accurate for runtime)
      if (httpServer && httpServer.yoloStates) {
        // Find yolo state for this workspace
        for (const [chatId, state] of httpServer.yoloStates.entries()) {
          if (state.workspaceId === workspace.id && state.isActive) {
            mode = 'yolo';
            active = true;
            details = {
              chatId,
              startTime: state.startTime,
              currentStepIndex: state.currentStepIndex,
              totalSteps: state.totalSteps,
              commits: state.commits?.length || 0,
              usage: state.usage
            };
            break;
          }
        }
      }

      // Check Goal Loop mode
      if (httpServer && httpServer.goalLoopStates) {
        for (const [chatId, state] of httpServer.goalLoopStates.entries()) {
          if (state.workspaceName === workspace.name && state.isActive) {
            mode = 'goal';
            active = true;
            details = {
              chatId,
              startTime: state.startTime,
              currentIteration: state.currentIteration,
              maxIterations: state.maxIterations,
              specificGoalId: state.specificGoalId,
              providerId: state.providerId,
              scheduled: state.scheduledTime ? true : false,
              scheduledTime: state.scheduledTime
            };
            break;
          }
        }
      }

      // Check for scheduled YOLO (protection mode active but not executing yet)
      if (mode === 'chat' && workspace.yolo_scheduled_time) {
        const scheduledTime = new Date(workspace.yolo_scheduled_time);
        if (scheduledTime > new Date()) {
          mode = 'yolo';
          active = false; // scheduled but not running yet
          details = {
            scheduled: true,
            scheduledTime: workspace.yolo_scheduled_time,
            protectionActive: true
          };
        }
      }

      logger.debug('[API] Mode state retrieved:', {
        workspace: workspace.name,
        mode,
        active
      });

      this.sendJSON(res, {
        success: true,
        mode,
        active,
        details,
        workspace: {
          id: workspace.id,
          name: workspace.name
        },
        exitCommands: {
          yolo: '/stopyolo',
          goal: '/stoploop'
        }
      });

    } catch (error) {
      logger.error('[API] Mode get failed:', {
        error: error.message,
        workspace: workspace?.name
      });
      this.sendError(res, 500, error.message);
    }
  }

  /**
   * POST /api/mode/stop - Stop the current active mode (Goal 266)
   * Body: { mode?: 'yolo'|'goal' } - optional, auto-detects if not provided
   * Returns: { success: boolean, stoppedMode: string, message: string }
   */
  async handleAPIModeStop(req, res, workspace) {
    try {
      const body = await this.parseBody(req);
      const httpServer = global.httpServer;

      if (!httpServer) {
        this.sendError(res, 500, 'HTTP server not available');
        return;
      }

      let stoppedMode = null;
      let message = '';
      const requestedMode = body.mode; // optional: 'yolo' or 'goal'

      // Try to stop YOLO mode
      if (!requestedMode || requestedMode === 'yolo') {
        // Check scheduled YOLO first
        if (httpServer.scheduledYoloTimeouts) {
          for (const [chatId, timeout] of httpServer.scheduledYoloTimeouts.entries()) {
            // Find the chat associated with this workspace
            const chatMapping = await this.workspaceManager.getTelegramMapping(chatId);
            if (chatMapping && chatMapping.workspaceId === workspace.id) {
              clearTimeout(timeout);
              httpServer.scheduledYoloTimeouts.delete(chatId);
              await this.workspaceManager.clearYoloProtection(workspace.id);
              stoppedMode = 'yolo';
              message = 'Scheduled YOLO cancelled and protection mode disabled';
              break;
            }
          }
        }

        // Check active YOLO
        if (!stoppedMode && httpServer.yoloStates) {
          for (const [chatId, state] of httpServer.yoloStates.entries()) {
            if (state.workspaceId === workspace.id && state.isActive) {
              state.isActive = false;

              // Clear status update interval
              if (state.statusUpdateInterval) {
                clearInterval(state.statusUpdateInterval);
              }

              // Cancel current task if running
              if (state.currentTaskId) {
                try {
                  const task = this.taskMonitor.getTask(state.currentTaskId);
                  if (task && (task.status === 'pending' || task.status === 'running')) {
                    this.taskMonitor.cancelTask(state.currentTaskId);
                  }
                } catch (e) {
                  logger.warn(`Failed to cancel YOLO task: ${e.message}`);
                }
              }

              // Clear protection mode
              await this.workspaceManager.clearYoloProtection(workspace.id);
              httpServer.yoloStates.delete(chatId);

              stoppedMode = 'yolo';
              message = 'YOLO execution stopped successfully';
              break;
            }
          }
        }

        // Also clear database flag if set
        if (!stoppedMode && workspace.yolo_mode_active) {
          await this.workspaceManager.clearYoloProtection(workspace.id);
          stoppedMode = 'yolo';
          message = 'YOLO protection mode cleared';
        }
      }

      // Try to stop Goal Loop mode
      if (!stoppedMode && (!requestedMode || requestedMode === 'goal')) {
        if (httpServer.goalLoopStates) {
          for (const [chatId, state] of httpServer.goalLoopStates.entries()) {
            if (state.workspaceName === workspace.name && state.isActive) {
              state.isActive = false;

              // Cancel current task if running
              if (state.currentTaskId) {
                try {
                  const task = this.taskMonitor.getTask(state.currentTaskId);
                  if (task && (task.status === 'pending' || task.status === 'running')) {
                    this.taskMonitor.cancelTask(state.currentTaskId);
                  }
                } catch (e) {
                  logger.warn(`Failed to cancel goal loop task: ${e.message}`);
                }
              }

              httpServer.goalLoopStates.delete(chatId);
              stoppedMode = 'goal';
              message = 'Goal loop stopped successfully';
              break;
            }
          }
        }
      }

      if (!stoppedMode) {
        this.sendJSON(res, {
          success: true,
          stoppedMode: null,
          message: 'No active mode to stop - currently in chat mode'
        });
        return;
      }

      logger.info('[API] Mode stopped:', {
        workspace: workspace.name,
        stoppedMode,
        message
      });

      this.sendJSON(res, {
        success: true,
        stoppedMode,
        message,
        currentMode: 'chat'
      });

    } catch (error) {
      logger.error('[API] Mode stop failed:', {
        error: error.message,
        workspace: workspace?.name
      });
      this.sendError(res, 500, error.message);
    }
  }
}
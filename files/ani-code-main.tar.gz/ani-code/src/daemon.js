import { TaskMonitor } from './task-monitor.js';
import { config } from './config.js';
import { logger } from './logger.js';
import { writeFileSync, readFileSync, existsSync, unlinkSync } from 'fs';
import { join, dirname } from 'path';
import { EventEmitter } from 'events';
import { IPCServer } from './ipc-server.js';
import { HTTPServer } from './http-server.js';
import { WSService } from './ws-service/index.js';
import { ChatSettingsManager } from './chat-settings.js';
import { TelegramPoller } from './telegram-poller.js';
import { TelegramNotifier } from './telegram-notifier.js';
import { WorkspaceManager } from './workspace-manager.js';
import { getProviderManager } from './providers/providerManager.js';
import { gatewayClient } from './gateway-client.js';
import { gatewayState } from './gateway-state.js';
import { UnmanagedTaskWatcher } from './unmanaged-task-watcher.js';
import { fileURLToPath } from 'url';

export class AniCodeDaemon extends EventEmitter {
  constructor() {
    super();
    // Use the directory where this script is located as base directory
    const __filename = fileURLToPath(import.meta.url);
    const __dirname = dirname(__filename);
    const baseDir = join(__dirname, '..');

    // Create shared chat settings manager
    this.chatSettings = new ChatSettingsManager();

    // Create workspace manager (initialized lazily)
    this.workspaceManager = new WorkspaceManager();

    this.taskMonitor = new TaskMonitor(this.chatSettings, this.workspaceManager);
    this.pidFile = join(baseDir, '.ani-code-daemon.pid');
    this.ipcServer = null; // Will be created after providerManager is initialized
    this.httpServer = new HTTPServer(this.taskMonitor, this.chatSettings);
    // Make httpServer globally accessible for progress tracking checks
    global.httpServer = this.httpServer;
    this.wsService = new WSService(this.taskMonitor, this.chatSettings);
    this.telegramPoller = null;  // Initialize lazily if configured
    this.telegramNotifier = new TelegramNotifier(); // For error notifications
    this.providerManager = null; // Will be initialized in start()
    this.unmanagedTaskWatcher = new UnmanagedTaskWatcher(this.taskMonitor.taskQueue);
    this.isRunning = false;
    this.setupEventHandlers();
  }

  setupEventHandlers() {
    // Handle graceful shutdown
    process.on('SIGTERM', async () => await this.shutdown());
    process.on('SIGINT', async () => await this.shutdown());
    process.on('SIGUSR1', () => this.reload());
    process.on('SIGUSR2', () => this.status());

    // Handle uncaught exceptions
    process.on('uncaughtException', async (error) => {
      logger.error('Uncaught exception:', error);
      await this.shutdown();
    });

    process.on('unhandledRejection', (reason, promise) => {
      logger.error('🔴 Unhandled rejection at:', {
        promise: promise ? String(promise) : 'unknown',
        reason: reason instanceof Error ? {
          message: reason.message,
          stack: reason.stack,
          name: reason.name
        } : reason
      });
    });
  }

  async start() {
    if (this.isRunning) {
      logger.warn('Daemon is already running');
      return false;
    }

    try {
      // Load persisted gateway token from disk if available
      const savedToken = gatewayState.getGatewayToken();
      if (savedToken) {
        process.env.GATEWAY_TOKEN = savedToken;
        logger.info('Loaded persisted gateway token', {
          tokenPrefix: savedToken.substring(0, 8) + '...'
        });
      }

      // Initialize workspace manager
      await this.workspaceManager.initialize();

      // Load chat settings
      await this.chatSettings.load();

      // Initialize provider manager and keep reference
      this.providerManager = await getProviderManager();

      // Create IPC server now that providerManager is available
      const { IPCServer } = await import('./ipc-server.js');
      this.ipcServer = new IPCServer(this.taskMonitor, this.providerManager);

      // Start IPC server
      const ipcPort = await this.ipcServer.start();
      
      // Start HTTP callback server on port 6501
      const httpPort = await this.httpServer.start();
      
      // Start WebSocket service independently on port 6502
      const wsPort = await this.wsService.start();
      
      // Start Telegram poller if configured and not using webhook
      if (config.telegram?.botToken && !config.telegram?.useWebhook) {
        this.telegramPoller = new TelegramPoller(this.httpServer);
        await this.telegramPoller.start();
      }
      
      // Write PID file
      writeFileSync(this.pidFile, process.pid.toString());
      this.isRunning = true;

      logger.info('Ani Code Daemon started');
      logger.info(`PID: ${process.pid}`);
      logger.info(`IPC server started on port ${ipcPort}`);
      logger.info(`HTTP callback server started on 0.0.0.0:${httpPort}`);
      logger.info(`[WS] WebSocket/API service started on port ${wsPort}`);
      logger.debug(`PID file: ${this.pidFile}`);
      logger.debug(`Max concurrent tasks: ${config.tasks.maxConcurrent}`);
      
      // Log Telegram status
      if (config.telegram?.botToken) {
        if (config.telegram?.useWebhook) {
          logger.info('Telegram: Webhook mode (configure webhook URL separately)');
        } else {
          logger.info('Telegram: Polling mode active');
        }
      }
      
      // Send daemon startup notification to Telegram
      await this.sendStartupNotification(ipcPort, httpPort, wsPort);

      // Register with gateway if configured (NEW GATEWAY MODE REGISTRATION)
      await this.registerWithGateway();

      // Start gateway registration and heartbeat if enabled (NEW K8s INSTANCE REGISTRATION)
      if (gatewayClient.isEnabled()) {
        gatewayClient.startHeartbeat();
        logger.info('Gateway instance registration enabled - heartbeat started');
      }

      // Keep the existing gateway token registration service
      const { gatewayRegistration } = await import('./services/gatewayRegistration.js');
      if (gatewayRegistration.isEnabled()) {
        gatewayRegistration.startHeartbeat();
        logger.info('Gateway token registration enabled - heartbeat started');
      }

      // Start unmanaged task watcher (if enabled)
      this.unmanagedTaskWatcher.start();

      // Keep the process alive
      this.keepAlive();

      return true;
    } catch (error) {
      logger.error('Failed to start daemon:', error);
      
      // Send error notification to default channel if configured
      if (this.telegramNotifier.isEnabled()) {
        this.telegramNotifier.sendErrorNotification(error, {
          source: 'daemon',
          operation: 'Starting daemon',
          suggestion: 'Check daemon logs for more details'
        }).catch(notifyError => {
          logger.error('Failed to send error notification:', notifyError);
        });
      }
      
      return false;
    }
  }

  async registerWithGateway() {
    if (!config.gateway.enabled || !config.gateway.registerOnStartup) {
      logger.debug('Gateway registration skipped (not enabled or disabled)');
      return;
    }

    // Import os and packageJson dynamically
    const os = await import('os');
    const { readFileSync } = await import('fs');
    const { join, dirname } = await import('path');
    const { fileURLToPath } = await import('url');

    const __filename = fileURLToPath(import.meta.url);
    const __dirname = dirname(__filename);
    const packageJsonPath = join(__dirname, '..', 'package.json');
    const packageJson = JSON.parse(readFileSync(packageJsonPath, 'utf8'));

    // Use external URL (ANI_CODE_URL) instead of internal hostname
    const externalUrl = process.env.ANI_CODE_URL || config.gateway.aniCodeUrl || `http://${os.hostname()}:${config.http.port || 6501}`;

    const registrationData = {
      instanceId: config.gateway.instanceId,
      token: config.gateway.token,
      capabilities: [],
      endpoint: externalUrl,
      version: packageJson.version,
      workspaces: Object.keys(config.lark?.workdirs || {}),
      hostname: os.hostname()
    };

    // Determine capabilities based on configuration
    if (config.telegram?.botToken) {
      registrationData.capabilities.push('telegram');
    }
    if (config.lark?.appId) {
      registrationData.capabilities.push('lark');
    }
    registrationData.capabilities.push('cli');

    try {
      logger.info(`Registering with gateway...`, {
        gatewayUrl: config.gateway.url,
        instanceId: config.gateway.instanceId,
        capabilities: registrationData.capabilities
      });

      const response = await fetch(`${config.gateway.url}/api/instances/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': config.gateway.apiKey || config.gateway.token
        },
        body: JSON.stringify(registrationData),
        timeout: 5000 // 5 second timeout for registration
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Registration failed: ${response.status} - ${errorText}`);
      }

      const result = await response.json();
      logger.info(`✓ Successfully registered with gateway`, {
        instanceId: config.gateway.instanceId,
        gatewayUrl: config.gateway.url,
        registered: result.registered,
        capabilities: registrationData.capabilities
      });

      // Store gateway token if returned in response
      if (result.gatewayToken) {
        gatewayState.setGatewayToken(result.gatewayToken);
        logger.info('Stored gateway token from instance registration', {
          tokenPrefix: result.gatewayToken.substring(0, 8) + '...'
        });
      }

      return result;
    } catch (error) {
      logger.error(`✗ Gateway registration failed:`, {
        error: error.message,
        gatewayUrl: config.gateway.url,
        instanceId: config.gateway.instanceId
      });

      // Don't crash the daemon - continue without registration
      // Gateway will use fallback routing or instance discovery
      logger.warn(`⚠️  Continuing without gateway registration (direct mode)`);
    }
  }

  async stop() {
    if (!this.isRunning) {
      logger.warn('Daemon is not running');
      return false;
    }

    try {
      await this.shutdown();
      return true;
    } catch (error) {
      logger.error('Failed to stop daemon:', error);
      return false;
    }
  }

  async shutdown() {
    if (!this.isRunning) return;

    logger.info('Shutting down Ani Code Daemon...');
    
    // Send shutdown notification
    await this.sendShutdownNotification();

    // Stop IPC server
    this.ipcServer.stop();
    
    // Stop HTTP server
    this.httpServer.stop();
    
    // Stop WebSocket service
    this.wsService.stop();
    
    // Stop Telegram poller if running
    if (this.telegramPoller) {
      this.telegramPoller.stop();
    }

    // Stop gateway instance registration and deregister (NEW K8s INSTANCE DEREGISTRATION)
    if (gatewayClient.isEnabled()) {
      await gatewayClient.shutdown();
      logger.info('Gateway instance deregistration complete');
    }

    // Stop gateway token registration heartbeat if running
    const { gatewayRegistration } = await import('./services/gatewayRegistration.js');
    if (gatewayRegistration.isEnabled()) {
      gatewayRegistration.stopHeartbeat();
      logger.info('Gateway token heartbeat stopped');
    }

    // Stop unmanaged task watcher
    this.unmanagedTaskWatcher.stop();

    // Clean up task monitor intervals
    this.taskMonitor.cleanup();

    // Cancel all running tasks
    const status = this.taskMonitor.getStatus();
    status.running.forEach(task => {
      logger.info(`Cancelling task: ${task.name} (${task.id})`);
      this.taskMonitor.cancelTask(task.id);
    });

    // Wait a bit for tasks to finish
    setTimeout(() => {
      // Remove PID file
      if (existsSync(this.pidFile)) {
        unlinkSync(this.pidFile);
      }

      this.isRunning = false;
      logger.info('Ani Code Daemon stopped');
      process.exit(0);
    }, 2000);
  }

  reload() {
    logger.info('Reloading daemon configuration...');
    // Could reload config here if needed
    logger.info('Configuration reloaded');
  }

  status() {
    const status = this.taskMonitor.getStatus();
    logger.info('Daemon Status:');
    logger.info(`  Running tasks: ${status.running.length}`);
    logger.info(`  Pending tasks: ${status.pending.length}`);
    logger.info(`  Max concurrent: ${config.tasks.maxConcurrent}`);
  }

  async sendStartupNotification(ipcPort, httpPort, wsPort) {
    try {
      if (!this.telegramNotifier.isEnabled()) {
        logger.debug('Telegram notifications not enabled, skipping startup notification');
        return;
      }
      
      logger.info('Attempting to send daemon startup notification to Telegram...');
      
      const hostname = config.lark?.hostname || 'Unknown';
      const time = new Date().toLocaleTimeString('en-GB', { 
        hour12: false, 
        timeZone: config.timezone || 'UTC',
        hour: '2-digit',
        minute: '2-digit'
      });
      
      // Get available providers
      const providerManager = await getProviderManager();
      const providers = providerManager.listProviders();
      const currentProvider = providers.find(p => p.current);

      let message = `*🔄 Daemon Restarted*\n\n`;
      message += `\`\`\`\n`;
      message += `STATUS: Online and Ready\n`;
      message += `PID:    ${process.pid}\n`;
      message += `SERVER: ${hostname}\n`;
      message += `TIME:   ${time}\n`;
      message += `\n`;
      message += `CONFIGURATION\n`;
      message += `├─ Max Tasks: ${config.tasks.maxConcurrent}\n`;

      if (config.telegram?.useWebhook) {
        message += `├─ Mode: Webhook\n`;
      } else if (this.telegramPoller) {
        message += `├─ Mode: Polling\n`;
      } else {
        message += `├─ Mode: Standard\n`;
      }

      message += `└─ Current Provider: ${currentProvider?.name || 'Unknown'}\n`;
      message += `\n`;
      message += `AVAILABLE PROVIDERS\n`;

      providers.forEach((provider, index) => {
        const isLast = index === providers.length - 1;
        const prefix = isLast ? '└─' : '├─';
        const marker = provider.current ? '●' : '○';
        message += `${prefix} ${marker} ${provider.name} (${provider.id})\n`;
      });

      message += `\`\`\`\n`;
      message += `Ready to process tasks`;
      
      await this.telegramNotifier.sendMessage(
        this.telegramNotifier.defaultChatId,
        message,
        { parse_mode: 'Markdown' }
      );
      
      logger.info(`✅ Sent daemon startup notification to Telegram chat ${this.telegramNotifier.defaultChatId}`);
    } catch (error) {
      logger.error('Failed to send startup notification to Telegram:', error.message || error);
      logger.debug('Startup notification error details:', error);
      // Don't fail daemon startup if notification fails
    }
  }

  async sendShutdownNotification() {
    try {
      if (!this.telegramNotifier.isEnabled()) {
        logger.debug('Telegram notifications not enabled, skipping shutdown notification');
        return;
      }
      
      logger.info('Attempting to send daemon shutdown notification to Telegram...');
      
      const hostname = config.lark?.hostname || 'Unknown';
      const time = new Date().toLocaleTimeString('en-GB', { 
        hour12: false, 
        timeZone: config.timezone || 'UTC',
        hour: '2-digit',
        minute: '2-digit'
      });
      
      // Get current task status
      const status = this.taskMonitor.getStatus();
      
      let message = `🛑 *Ani-Code Daemon Stopped*\n\n`;
      message += `*Status:* ⏹ Stopped\n`;
      message += `*PID:* ${process.pid}\n`;
      message += `*Hostname:* ${hostname}\n`;
      message += `*Time:* ${time}\n\n`;
      
      if (status.running.length > 0 || status.pending.length > 0) {
        message += `*Tasks Cancelled:*\n`;
        message += `• Running: ${status.running.length}\n`;
        message += `• Pending: ${status.pending.length}\n\n`;
      }
      
      message += `\n━━━━━━━━━━━━━━━\n`;
      message += `🖥 ${hostname} • ⏰ ${time}`;
      
      await this.telegramNotifier.sendMessage(
        this.telegramNotifier.defaultChatId,
        message,
        { parse_mode: 'Markdown' }
      );
      
      logger.info(`✅ Sent daemon shutdown notification to Telegram chat ${this.telegramNotifier.defaultChatId}`);
    } catch (error) {
      logger.error('Failed to send shutdown notification to Telegram:', error.message || error);
      logger.debug('Shutdown notification error details:', error);
      // Don't fail daemon shutdown if notification fails
    }
  }

  keepAlive() {
    // Keep the process alive with a heartbeat
    setInterval(() => {
      if (this.isRunning) {
        logger.debug('Daemon heartbeat');
      }
    }, 30000); // 30 seconds
  }

  getTaskMonitor() {
    return this.taskMonitor;
  }

  static getPid() {
    try {
      const __filename = fileURLToPath(import.meta.url);
      const __dirname = dirname(__filename);
      const baseDir = join(__dirname, '..');
      const pidFile = join(baseDir, '.ani-code-daemon.pid');
      
      if (existsSync(pidFile)) {
        return parseInt(readFileSync(pidFile, 'utf8'));
      }
    } catch (error) {
      // Ignore errors
    }
    return null;
  }

  static isRunning() {
    const pid = this.getPid();
    if (!pid) return false;

    try {
      // Check if process exists
      process.kill(pid, 0);
      return true;
    } catch (error) {
      return false;
    }
  }
}

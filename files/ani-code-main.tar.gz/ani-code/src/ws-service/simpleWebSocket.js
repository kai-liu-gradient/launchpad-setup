import { createServer } from 'http';
import { createHash, randomBytes } from 'crypto';
import { EventEmitter } from 'events';
import { logger } from '../logger.js';

// WebSocket opcodes
const OPCODES = {
  CONTINUATION: 0x0,
  TEXT: 0x1,
  BINARY: 0x2,
  CLOSE: 0x8,
  PING: 0x9,
  PONG: 0xa
};

// WebSocket states
const STATES = {
  CONNECTING: 0,
  OPEN: 1,
  CLOSING: 2,
  CLOSED: 3
};

export class SimpleWebSocket extends EventEmitter {
  constructor(socket, isServer = true) {
    super();
    this.socket = socket;
    this.isServer = isServer;
    this.readyState = STATES.OPEN;
    this.buffer = Buffer.alloc(0);
    
    this.socket.on('data', this.handleData.bind(this));
    this.socket.on('close', this.handleClose.bind(this));
    this.socket.on('error', this.handleError.bind(this));
  }

  handleData(data) {
    this.buffer = Buffer.concat([this.buffer, data]);
    
    while (this.buffer.length >= 2) {
      const frame = this.parseFrame();
      if (!frame) break;
      
      switch (frame.opcode) {
        case OPCODES.TEXT:
          this.emit('message', frame.payload.toString('utf8'));
          break;
        case OPCODES.BINARY:
          this.emit('message', frame.payload);
          break;
        case OPCODES.CLOSE:
          this.close();
          break;
        case OPCODES.PING:
          this.pong(frame.payload);
          this.emit('ping');
          break;
        case OPCODES.PONG:
          this.emit('pong');
          break;
      }
    }
  }

  parseFrame() {
    if (this.buffer.length < 2) return null;
    
    const firstByte = this.buffer[0];
    const secondByte = this.buffer[1];
    
    const fin = !!(firstByte & 0x80);
    const opcode = firstByte & 0x0f;
    const masked = !!(secondByte & 0x80);
    let payloadLength = secondByte & 0x7f;
    
    let offset = 2;
    
    if (payloadLength === 126) {
      if (this.buffer.length < offset + 2) return null;
      payloadLength = this.buffer.readUInt16BE(offset);
      offset += 2;
    } else if (payloadLength === 127) {
      if (this.buffer.length < offset + 8) return null;
      payloadLength = this.buffer.readBigUInt64BE(offset);
      offset += 8;
    }
    
    const maskKey = masked ? this.buffer.slice(offset, offset + 4) : null;
    if (masked) offset += 4;
    
    if (this.buffer.length < offset + payloadLength) return null;
    
    let payload = this.buffer.slice(offset, offset + Number(payloadLength));
    
    if (masked) {
      for (let i = 0; i < payload.length; i++) {
        payload[i] ^= maskKey[i % 4];
      }
    }
    
    this.buffer = this.buffer.slice(offset + Number(payloadLength));
    
    return { fin, opcode, payload };
  }

  send(data) {
    if (this.readyState !== STATES.OPEN) return;
    
    const isBuffer = Buffer.isBuffer(data);
    const payload = isBuffer ? data : Buffer.from(data, 'utf8');
    const opcode = isBuffer ? OPCODES.BINARY : OPCODES.TEXT;
    
    this.sendFrame(opcode, payload);
  }

  sendFrame(opcode, payload = Buffer.alloc(0)) {
    const payloadLength = payload.length;
    
    let frame;
    if (payloadLength < 126) {
      frame = Buffer.allocUnsafe(2);
      frame[0] = 0x80 | opcode;
      frame[1] = payloadLength;
    } else if (payloadLength < 65536) {
      frame = Buffer.allocUnsafe(4);
      frame[0] = 0x80 | opcode;
      frame[1] = 126;
      frame.writeUInt16BE(payloadLength, 2);
    } else {
      frame = Buffer.allocUnsafe(10);
      frame[0] = 0x80 | opcode;
      frame[1] = 127;
      frame.writeBigUInt64BE(BigInt(payloadLength), 2);
    }
    
    if (!this.isServer) {
      // Client must mask
      const masked = Buffer.alloc(4);
      randomBytes(4).copy(masked);
      frame[1] |= 0x80;
      
      const maskedPayload = Buffer.alloc(payload.length);
      for (let i = 0; i < payload.length; i++) {
        maskedPayload[i] = payload[i] ^ masked[i % 4];
      }
      
      this.socket.write(Buffer.concat([frame, masked, maskedPayload]));
    } else {
      this.socket.write(Buffer.concat([frame, payload]));
    }
  }

  ping(data = Buffer.alloc(0)) {
    this.sendFrame(OPCODES.PING, data);
  }

  pong(data = Buffer.alloc(0)) {
    this.sendFrame(OPCODES.PONG, data);
  }

  close(code = 1000, reason = '') {
    if (this.readyState === STATES.CLOSING || this.readyState === STATES.CLOSED) return;
    
    this.readyState = STATES.CLOSING;
    const reasonBuffer = Buffer.from(reason, 'utf8');
    const payload = Buffer.allocUnsafe(2 + reasonBuffer.length);
    payload.writeUInt16BE(code, 0);
    reasonBuffer.copy(payload, 2);
    
    this.sendFrame(OPCODES.CLOSE, payload);
    this.socket.end();
  }

  handleClose() {
    this.readyState = STATES.CLOSED;
    this.emit('close');
  }

  handleError(error) {
    this.emit('error', error);
  }
}

export class SimpleWebSocketServer extends EventEmitter {
  constructor(options = {}) {
    super();
    this.path = options.path || '/ws';
    this.server = options.server;
    this.clients = new Set();
    
    if (this.server) {
      this.server.on('upgrade', this.handleUpgrade.bind(this));
    }
  }

  handleUpgrade(request, socket, head) {
    const { pathname } = new URL(request.url, `http://${request.headers.host}`);
    
    if (pathname !== this.path) {
      socket.end('HTTP/1.1 404 Not Found\r\n\r\n');
      return;
    }
    
    const key = request.headers['sec-websocket-key'];
    const acceptKey = this.generateAcceptKey(key);
    
    const responseHeaders = [
      'HTTP/1.1 101 Switching Protocols',
      'Upgrade: websocket',
      'Connection: Upgrade',
      `Sec-WebSocket-Accept: ${acceptKey}`,
      '',
      ''
    ].join('\r\n');
    
    socket.write(responseHeaders);
    
    const ws = new SimpleWebSocket(socket, true);
    this.clients.add(ws);
    
    ws.on('close', () => {
      this.clients.delete(ws);
    });
    
    this.emit('connection', ws, request);
  }

  generateAcceptKey(key) {
    const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
    return createHash('sha1')
      .update(key + GUID)
      .digest('base64');
  }

  close(callback) {
    this.clients.forEach(client => client.close());
    if (callback) callback();
  }
}
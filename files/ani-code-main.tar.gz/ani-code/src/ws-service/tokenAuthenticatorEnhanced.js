import crypto from 'crypto';
import jwt from 'jsonwebtoken';
import { logger } from '../logger.js';
import { readFileSync, existsSync } from 'fs';
import { join } from 'path';
import { homedir } from 'os';
import { WorkspaceManager } from '../workspace-manager.js';

export class EnhancedTokenAuthenticator {
  constructor() {
    this.tokenFile = join(homedir(), '.anicode', 'plugin-tokens.json');
    this.legacyTokens = new Map();
    this.workspaceManager = null;
    this.loadLegacyTokens();
    this.initWorkspaceManager();
  }

  async initWorkspaceManager() {
    try {
      this.workspaceManager = new WorkspaceManager();
      await this.workspaceManager.initialize();
      logger.debug('Workspace manager initialized for token authentication');
    } catch (error) {
      logger.error('Failed to initialize workspace manager:', error);
    }
  }

  loadLegacyTokens() {
    try {
      // Clear existing tokens before reloading
      this.legacyTokens.clear();
      
      if (existsSync(this.tokenFile)) {
        const data = readFileSync(this.tokenFile, 'utf8');
        const tokens = JSON.parse(data);
        
        // Load legacy tokens into memory
        Object.entries(tokens).forEach(([id, tokenData]) => {
          this.legacyTokens.set(id, tokenData);
        });
        
        logger.info(`Loaded ${this.legacyTokens.size} legacy authentication tokens`);
      }
    } catch (error) {
      logger.error('Failed to load legacy tokens:', error);
    }
  }

  async authenticate(req) {
    try {
      // Extract token from query string or authorization header
      const url = new URL(req.url, `http://${req.headers.host}`);
      let token = url.searchParams.get('token');
      logger.info(`[TOKEN-DEBUG] Token from URL params: ${token ? `${token.substring(0, 50)}...` : 'null'}`);
      
      if (!token && req.headers.authorization) {
        const auth = req.headers.authorization;
        logger.info(`[TOKEN-DEBUG] Authorization header: ${auth ? `${auth.substring(0, 50)}...` : 'null'}`);
        if (auth.startsWith('Bearer ')) {
          token = auth.substring(7);
          logger.info(`[TOKEN-DEBUG] Token from Bearer header: ${token.substring(0, 50)}...`);
        }
      }

      if (!token) {
        logger.warn('[TOKEN-DEBUG] No token found in URL params or Authorization header');
        return {
          success: false,
          error: 'Token required'
        };
      }

      // Log token details for debugging
      logger.info(`[TOKEN-DEBUG] Authenticating token - Length: ${token.length}, Parts: ${token.split('.').length}`);
      logger.info(`[TOKEN-DEBUG] Token preview: ${token.substring(0, 50)}...${token.substring(token.length - 10)}`);
      
      // First, try to validate as JWT workspace token
      if (this.workspaceManager && token.includes('.') && token.split('.').length >= 3) {
        logger.info('[TOKEN-DEBUG] Attempting JWT validation...');
        const jwtValidation = await this.validateJWTToken(token);
        if (jwtValidation.success) {
          logger.info('[TOKEN-DEBUG] JWT validation successful');
          return jwtValidation;
        }
        logger.info(`[TOKEN-DEBUG] JWT validation failed: ${jwtValidation.error}`);
        
        // If JWT validation failed but it looked like a JWT, don't try legacy validation
        const looksLikeJWT = this.looksLikeJWT(token);
        logger.info(`[TOKEN-DEBUG] Token looks like JWT: ${looksLikeJWT}`);
        if (looksLikeJWT) {
          logger.info('[TOKEN-DEBUG] Token looks like JWT, not trying legacy validation');
          return jwtValidation;
        }
      }

      // Fall back to legacy token validation
      logger.info('[TOKEN-DEBUG] Attempting legacy token validation...');
      const legacyValidation = this.validateLegacyToken(token);
      logger.info(`[TOKEN-DEBUG] Legacy validation result: ${legacyValidation.success ? 'SUCCESS' : 'FAILED - ' + legacyValidation.error}`);
      return legacyValidation;
    } catch (error) {
      logger.error('Authentication error:', error);
      return {
        success: false,
        error: 'Authentication failed'
      };
    }
  }

  looksLikeJWT(token) {
    // Basic JWT structure check: header.payload.signature
    const parts = token.split('.');
    if (parts.length !== 3) return false;
    
    try {
      // Try to decode the header to see if it's a valid JWT
      const header = JSON.parse(Buffer.from(parts[0], 'base64').toString());
      // Must have both typ and alg fields to be a JWT
      return (header.typ === 'JWT' && header.alg !== undefined);
    } catch {
      return false;
    }
  }

  async validateJWTToken(token) {
    try {
      if (!this.workspaceManager) {
        return {
          success: false,
          error: 'Workspace manager not initialized'
        };
      }

      const validation = await this.workspaceManager.validateToken(token);
      
      if (!validation.valid) {
        return {
          success: false,
          error: validation.error || 'Invalid JWT token'
        };
      }

      // Map workspace token validation to expected format
      return {
        success: true,
        metadata: {
          id: validation.token_id,
          project: validation.workspace_name,
          projectPath: validation.workspace_path,
          workspaceId: validation.workspace_id,
          permissions: validation.permissions,
          type: validation.type,
          isWorkspaceToken: true,
          createdAt: Date.now(),
          expiresAt: Date.now() + (365 * 24 * 60 * 60 * 1000) // 1 year default
        }
      };
    } catch (error) {
      logger.error('JWT token validation error:', error);
      return {
        success: false,
        error: 'JWT token validation failed'
      };
    }
  }

  validateLegacyToken(token) {
    try {
      logger.debug(`Validating legacy token with length: ${token.length}`);
      
      // Legacy token format: payload.signature.secret
      const parts = token.split('.');
      if (parts.length !== 3) {
        logger.warn(`Legacy token validation failed: Expected 3 parts, got ${parts.length}`);
        return {
          success: false,
          error: `Invalid token format - expected 3 parts separated by dots, got ${parts.length}`
        };
      }

      const [encodedPayload, signature, secret] = parts;
      logger.debug(`Legacy token parts lengths - payload: ${encodedPayload.length}, signature: ${signature.length}, secret: ${secret.length}`);
      
      // Verify signature
      const expectedSignature = crypto
        .createHmac('sha256', secret)
        .update(encodedPayload)
        .digest('hex');
      
      if (signature !== expectedSignature) {
        logger.warn('Legacy token validation failed: Signature mismatch');
        return {
          success: false,
          error: 'Invalid token signature - token may be corrupted or tampered'
        };
      }

      // Decode payload
      let payload;
      try {
        payload = JSON.parse(Buffer.from(encodedPayload, 'base64').toString());
        logger.debug(`Legacy token payload decoded - project: ${payload.project}, id: ${payload.id}`);
      } catch (decodeError) {
        logger.error('Failed to decode legacy token payload:', decodeError.message);
        return {
          success: false,
          error: 'Invalid token payload - unable to decode'
        };
      }
      
      // Check expiration
      if (Date.now() > payload.expiresAt) {
        const expirationDate = new Date(payload.expiresAt).toISOString();
        logger.warn(`Legacy token validation failed: Token expired at ${expirationDate}`);
        return {
          success: false,
          error: `Token expired at ${expirationDate}`
        };
      }

      // Reload tokens from file to ensure we have latest state (handles revoked tokens)
      this.loadLegacyTokens();
      
      // Verify token exists and is valid (if not found, it was revoked)
      if (!this.legacyTokens.has(payload.id)) {
        logger.warn(`Legacy token validation failed: Token ID ${payload.id} not found (possibly revoked)`);
        return {
          success: false,
          error: 'Token has been revoked or is invalid'
        };
      }
      
      const storedToken = this.legacyTokens.get(payload.id);
      const secretHash = crypto.createHash('sha256').update(secret).digest('hex');
      
      if (storedToken.secretHash !== secretHash) {
        logger.warn(`Legacy token validation failed: Secret hash mismatch for token ID ${payload.id}`);
        return {
          success: false,
          error: 'Token verification failed - secret does not match stored token'
        };
      }
      logger.debug(`Legacy token verified successfully against stored token ${payload.id}`);

      return {
        success: true,
        metadata: {
          ...payload,
          isLegacyToken: true
        }
      };
    } catch (error) {
      logger.error('Legacy token validation error:', error);
      return {
        success: false,
        error: 'Token validation failed'
      };
    }
  }

  generateLegacyToken(projectId, metadata = {}) {
    try {
      const tokenId = crypto.randomBytes(16).toString('hex');
      const secret = crypto.randomBytes(32).toString('hex');
      
      const payload = {
        id: tokenId,
        project: projectId,
        projectPath: metadata.projectPath || process.cwd(),
        createdAt: Date.now(),
        expiresAt: Date.now() + (7 * 24 * 60 * 60 * 1000), // 7 days
        hostname: metadata.hostname || require('os').hostname(),
        user: metadata.user || require('os').userInfo().username,
        ...metadata
      };
      
      // Encode payload
      const encodedPayload = Buffer.from(JSON.stringify(payload)).toString('base64');
      
      // Create signature
      const signature = crypto
        .createHmac('sha256', secret)
        .update(encodedPayload)
        .digest('hex');
      
      // Create token
      const token = `${encodedPayload}.${signature}.${secret}`;
      
      // Store token hash
      this.legacyTokens.set(tokenId, {
        ...payload,
        secretHash: crypto.createHash('sha256').update(secret).digest('hex')
      });
      
      return {
        token,
        tokenId,
        expiresAt: payload.expiresAt
      };
    } catch (error) {
      logger.error('Legacy token generation error:', error);
      throw error;
    }
  }

  async generateWorkspaceToken(workspaceIdOrName, tokenName = null, permissions = ['read', 'write']) {
    try {
      if (!this.workspaceManager) {
        throw new Error('Workspace manager not initialized');
      }

      const tokenData = await this.workspaceManager.generateToken(
        workspaceIdOrName,
        tokenName,
        'websocket',
        permissions,
        null // No expiration for WebSocket tokens
      );

      return tokenData;
    } catch (error) {
      logger.error('Workspace token generation error:', error);
      throw error;
    }
  }

  revokeToken(tokenId) {
    if (this.legacyTokens.has(tokenId)) {
      this.legacyTokens.delete(tokenId);
      return true;
    }
    return false;
  }

  getTokenInfo(tokenId) {
    return this.legacyTokens.get(tokenId);
  }

  listLegacyTokens() {
    return Array.from(this.legacyTokens.values()).map(token => ({
      id: token.id,
      project: token.project,
      projectPath: token.projectPath,
      createdAt: token.createdAt,
      expiresAt: token.expiresAt,
      expired: Date.now() > token.expiresAt,
      hostname: token.hostname,
      user: token.user,
      isLegacy: true
    }));
  }

  async listAllTokens() {
    const legacyTokens = this.listLegacyTokens();
    
    if (this.workspaceManager) {
      try {
        const workspaceTokens = await this.workspaceManager.listTokens();
        const formattedWorkspaceTokens = workspaceTokens.map(token => ({
          id: token.id,
          project: token.workspace_name,
          workspaceId: token.workspace_id,
          createdAt: new Date(token.created_at).getTime(),
          expiresAt: token.expires_at ? new Date(token.expires_at).getTime() : null,
          expired: token.expires_at ? Date.now() > new Date(token.expires_at).getTime() : false,
          type: token.type,
          permissions: token.permissions,
          isWorkspace: true
        }));
        
        return [...legacyTokens, ...formattedWorkspaceTokens];
      } catch (error) {
        logger.error('Failed to list workspace tokens:', error);
      }
    }
    
    return legacyTokens;
  }

  async registerConnection(metadata) {
    if (this.workspaceManager && metadata.workspaceId) {
      try {
        const connectionId = await this.workspaceManager.registerWSConnection(
          metadata.workspaceId,
          metadata.id,
          {
            userAgent: metadata.userAgent,
            remoteAddress: metadata.remoteAddress,
            connectedAt: new Date().toISOString()
          }
        );
        return connectionId;
      } catch (error) {
        logger.error('Failed to register WebSocket connection:', error);
      }
    }
    return null;
  }

  async disconnectConnection(connectionId) {
    if (this.workspaceManager && connectionId) {
      try {
        await this.workspaceManager.disconnectWSConnection(connectionId);
      } catch (error) {
        logger.error('Failed to disconnect WebSocket connection:', error);
      }
    }
  }

  async close() {
    if (this.workspaceManager) {
      await this.workspaceManager.close();
    }
  }
}
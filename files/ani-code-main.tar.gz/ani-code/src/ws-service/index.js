import { createServer } from 'http';
import { parse } from 'url';
import { logger } from '../logger.js';
import { config } from '../config.js';
import { ChromePluginHandler } from './chromePluginHandler.js';
import { EnhancedTokenAuthenticator } from './tokenAuthenticatorEnhanced.js';
import { SimpleWebSocketServer } from './simpleWebSocket.js';
import { APIHandlers } from '../api-handlers.js';

export class WSService {
  constructor(taskMonitor, chatSettings = null) {
    this.taskMonitor = taskMonitor;
    this.chatSettings = chatSettings;
    this.server = null;
    this.wss = null;
    this.chromePluginHandler = null;
    this.tokenAuthenticator = new EnhancedTokenAuthenticator();
    this.connections = new Map();
    this.port = parseInt(process.env.ANICODE_WS_PORT || '6502');
    this.apiHandlers = null;
    this.workspaceManager = null;
  }

  async start() {
    return new Promise(async (resolve, reject) => {
      // Initialize workspace manager
      const { WorkspaceManager } = await import('../workspace-manager.js');
      this.workspaceManager = new WorkspaceManager();
      await this.workspaceManager.initialize();
      
      // Initialize API handlers
      this.apiHandlers = new APIHandlers(this.taskMonitor, this.workspaceManager);
      
      // Create HTTP server for WebSocket and API endpoints
      this.server = createServer(async (req, res) => {
        await this.handleHTTPRequest(req, res);
      });

      // Create WebSocket server using the HTTP server
      this.wss = new SimpleWebSocketServer({ 
        server: this.server,
        path: '/socket'
      });

      // Initialize Chrome plugin handler
      this.chromePluginHandler = new ChromePluginHandler(
        this.wss, 
        this.taskMonitor,
        this.chatSettings,
        this.tokenAuthenticator
      );

      // Handle WebSocket connections
      this.wss.on('connection', async (ws, req) => {
        const clientId = this.generateClientId();
        const remoteAddress = req.socket.remoteAddress;
        const userAgent = req.headers['user-agent'] || 'unknown';
        
        logger.info(`[WS] Connection from ${remoteAddress} | ${clientId}`);
        
        // Authenticate connection
        const authResult = await this.tokenAuthenticator.authenticate(req);
        if (!authResult.success) {
          logger.warn(`[WS] Auth failed: ${clientId} | ${authResult.error}`);
          ws.close(1008, authResult.error);
          return;
        }

        // Store connection
        this.connections.set(clientId, {
          ws,
          metadata: authResult.metadata,
          connectedAt: Date.now()
        });

        const expiresAt = authResult.metadata.expiresAt || (Date.now() + 7 * 24 * 60 * 60 * 1000);
        const expDays = Math.round((expiresAt - Date.now()) / 1000 / 60 / 60 / 24);
        const workdir = authResult.metadata.projectPath || process.cwd();
        
        logger.info(`[WS] Auth OK: ${clientId} | ${workdir} | exp:${expDays}d`);

        // Delegate to Chrome plugin handler
        this.chromePluginHandler.handleConnection(ws, authResult.metadata, clientId);

        // Handle disconnection
        ws.on('close', (code, reason) => {
          const connection = this.connections.get(clientId);
          if (connection) {
            const duration = Date.now() - connection.connectedAt;
            logger.info(`[WS] Disconnected: ${clientId} | code:${code} | duration:${Math.round(duration/1000)}s`);
            this.connections.delete(clientId);
          }
        });
      });

      this.server.on('error', (error) => {
        logger.error(`[WS] Server error: ${error.message}`);
        reject(error);
      });

      this.server.listen(this.port, '0.0.0.0', () => {
        logger.debug(`[WS] WebSocket/API service listening on port ${this.port}`);
        resolve(this.port);
      });
    });
  }

  stop() {
    if (this.wss) {
      // Close all connections
      this.connections.forEach(({ ws }, clientId) => {
        if (ws.readyState === 1) { // OPEN state
          ws.close(1000, 'Server shutting down');
        }
      });
      this.connections.clear();

      this.wss.close(() => {
        logger.info('WebSocket server closed');
      });
    }

    if (this.server) {
      this.server.close(() => {
        logger.info('[WS] HTTP server closed');
      });
    }
  }

  async handleHTTPRequest(req, res) {
    const { pathname } = parse(req.url, true);
    
    // Set CORS headers for API endpoints
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    
    // Handle OPTIONS preflight requests
    if (req.method === 'OPTIONS') {
      res.writeHead(200);
      res.end();
      return;
    }
    
    // Health check endpoint
    if (pathname === '/health') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ 
        status: 'healthy',
        connections: this.connections.size,
        timestamp: new Date().toISOString()
      }));
    } 
    // API endpoints
    else if (pathname.includes('/api/')) {
      logger.info(`[WS Service] API request: ${req.method} ${pathname}`);
      try {
        await this.apiHandlers.handleAPIRequest(req, res, pathname);
      } catch (error) {
        logger.error('API request error:', error);
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: false, error: 'Internal server error' }));
      }
    } 
    else {
      res.writeHead(404);
      res.end('Not Found');
    }
  }

  generateClientId() {
    return Math.random().toString(36).substring(2, 15);
  }
}
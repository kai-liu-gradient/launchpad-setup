import { logger } from '../logger.js';
import { exec } from 'child_process';
import { promisify } from 'util';
import path from 'path';

const execAsync = promisify(exec);

export class ChromePluginHandler {
  constructor(wss, taskMonitor, chatSettings, tokenAuthenticator) {
    this.wss = wss;
    this.taskMonitor = taskMonitor;
    this.chatSettings = chatSettings;
    this.tokenAuthenticator = tokenAuthenticator;
    this.sessions = new Map();
  }

  handleConnection(ws, metadata, clientId) {
    const projectPath = metadata.projectPath || process.cwd();
    const expiresAt = metadata.expiresAt || (Date.now() + 7 * 24 * 60 * 60 * 1000);
    const expiresDays = Math.round((expiresAt - Date.now()) / 1000 / 60 / 60 / 24);
    
    logger.info(`[WS] Connected: ${clientId} | ${projectPath} | expires: ${expiresDays}d`);
    
    // Store session with expiration info
    this.sessions.set(clientId, {
      ws,
      metadata,
      projectPath,
      expiresAt,
      connectedAt: Date.now()
    });

    // Send initial connection success message
    ws.send(JSON.stringify({
      type: 'connection',
      status: 'connected',
      clientId,
      projectPath: metadata.projectPath,
      timestamp: new Date().toISOString()
    }));

    // Setup message handlers
    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        logger.debug(`[WS] ${clientId} -> ${data.type}${data.action ? ':' + data.action : ''}`);
        await this.handleMessage(clientId, data);
      } catch (error) {
        logger.error(`[WS] ${clientId} error: ${error.message}`);
        ws.send(JSON.stringify({
          type: 'error',
          error: error.message
        }));
      }
    });

    // Setup heartbeat
    ws.on('pong', () => {
      const session = this.sessions.get(clientId);
      if (session) {
        session.lastPong = Date.now();
      }
    });

    // Start heartbeat interval with error handling
    const heartbeatInterval = setInterval(() => {
      if (ws.readyState === 1) { // OPEN state
        try {
          ws.ping();
        } catch (error) {
          // Connection is broken, clean up silently
          clearInterval(heartbeatInterval);
        }
      } else {
        clearInterval(heartbeatInterval);
      }
    }, 30000);

    // Cleanup on disconnect
    ws.on('close', () => {
      clearInterval(heartbeatInterval);
      const session = this.sessions.get(clientId);
      if (session) {
        const durationSec = Math.round((Date.now() - (session.connectedAt || Date.now())) / 1000);
        logger.info(`[WS] Disconnected: ${clientId} | ${session.projectPath} | ${durationSec}s`);
      }
      this.sessions.delete(clientId);
    });
  }

  async handleMessage(clientId, data) {
    const session = this.sessions.get(clientId);
    if (!session) {
      logger.error(`[WS] Session not found: ${clientId}`);
      return;
    }

    const { ws, projectPath } = session;
    const startTime = Date.now();

    switch (data.type) {
      case 'execute':
        logger.info(`[WS] ${clientId} exec: ${data.command?.substring(0, 50)}...`);
        await this.handleExecute(ws, data, projectPath);
        break;
      
      case 'task':
        logger.info(`[WS] ${clientId} task:${data.action} | ${projectPath} | ${data.taskData?.name || 'unnamed'}`);
        await this.handleTask(ws, data, projectPath);
        break;
      
      case 'git':
        logger.info(`[WS] ${clientId} git:${data.action} | ${projectPath}`);
        await this.handleGit(ws, data, projectPath);
        break;
      
      case 'status':
        logger.debug(`[WS] ${clientId} status check`);
        await this.handleStatus(ws);
        break;
      
      case 'file':
        logger.info(`[WS] ${clientId} file:${data.action} | ${projectPath} | ${data.filePath}`);
        await this.handleFile(ws, data, projectPath);
        break;
      
      case 'ping':
      case 'PING':
        logger.debug(`[WS] ${clientId} ping`);
        ws.send(JSON.stringify({ type: 'PONG', timestamp: Date.now() }));
        break;
      
      case 'GET_TASKS':
        logger.info(`[WS] ${clientId} get_tasks | ${projectPath}`);
        await this.handleGetTasks(ws, projectPath);
        break;
      
      case 'GET_GIT_LOG':
        logger.info(`[WS] ${clientId} git_log | ${projectPath}`);
        await this.handleGetGitLog(ws, projectPath);
        break;
      
      default:
        logger.warn(`[WS] ${clientId} unknown: ${data.type}`);
        ws.send(JSON.stringify({
          type: 'error',
          error: `Unknown message type: ${data.type}`
        }));
    }
    
    const duration = Date.now() - startTime;
    if (duration > 1000) {
      logger.warn(`[WS] ${clientId} slow: ${data.type} ${duration}ms`);
    }
  }

  async handleExecute(ws, data, projectPath) {
    const { command, cwd } = data;
    
    if (!command) {
      ws.send(JSON.stringify({
        type: 'error',
        error: 'Command is required'
      }));
      return;
    }

    try {
      const execCwd = cwd ? path.resolve(projectPath, cwd) : projectPath;
      const { stdout, stderr } = await execAsync(command, {
        cwd: execCwd,
        timeout: 30000
      });

      ws.send(JSON.stringify({
        type: 'execute_result',
        command,
        stdout,
        stderr,
        success: true
      }));
    } catch (error) {
      ws.send(JSON.stringify({
        type: 'execute_result',
        command,
        error: error.message,
        success: false
      }));
    }
  }

  async handleTask(ws, data, projectPath) {
    const { action, taskData } = data;

    switch (action) {
      case 'create':
        const taskName = taskData.name || 'Chrome Plugin Task';
        const taskCommand = taskData.command;
        const taskWorkdir = taskData.cwd || projectPath;
        
        const task = this.taskMonitor.addTask(
          taskName,
          taskCommand,
          {
            cwd: taskWorkdir,
            source: 'chrome_plugin'
          }
        );

        logger.info(`[WS] Task created: ${task.id} | ${taskWorkdir} | ${taskName}`);
        ws.send(JSON.stringify({
          type: 'task_created',
          taskId: task.id,
          task
        }));

        // Monitor task and send updates
        this.monitorTask(ws, task.id);
        break;

      case 'cancel':
        const cancelled = this.taskMonitor.cancelTask(taskData.taskId);
        logger.info(`[WS] Task cancel ${cancelled ? 'OK' : 'FAIL'}: ${taskData.taskId}`);
        ws.send(JSON.stringify({
          type: 'task_cancelled',
          taskId: taskData.taskId,
          success: cancelled
        }));
        break;

      case 'status':
        const taskStatus = this.taskMonitor.getTaskById(taskData.taskId);
        logger.debug(`[WS] Task status: ${taskData.taskId} = ${taskStatus?.status || 'not found'}`);
        ws.send(JSON.stringify({
          type: 'task_status',
          task: taskStatus
        }));
        break;

      default:
        ws.send(JSON.stringify({
          type: 'error',
          error: `Unknown task action: ${action}`
        }));
    }
  }

  async handleGit(ws, data, projectPath) {
    const { action } = data;

    try {
      let result;
      
      switch (action) {
        case 'status':
          const { stdout: gitStatus } = await execAsync('git status --porcelain', {
            cwd: projectPath,
            timeout: 5000
          });
          result = { status: gitStatus };
          break;

        case 'diff':
          const { stdout: gitDiff } = await execAsync('git diff', {
            cwd: projectPath,
            timeout: 10000
          });
          result = { diff: gitDiff };
          break;

        case 'log':
          const { stdout: gitLog } = await execAsync('git log --oneline -10', {
            cwd: projectPath,
            timeout: 5000
          });
          result = { log: gitLog };
          break;

        case 'branch':
          const { stdout: gitBranch } = await execAsync('git branch --show-current', {
            cwd: projectPath,
            timeout: 5000
          });
          result = { branch: gitBranch.trim() };
          break;

        default:
          throw new Error(`Unknown git action: ${action}`);
      }

      ws.send(JSON.stringify({
        type: 'git_result',
        action,
        result,
        success: true
      }));
    } catch (error) {
      ws.send(JSON.stringify({
        type: 'git_result',
        action,
        error: error.message,
        success: false
      }));
    }
  }

  async handleStatus(ws) {
    const status = this.taskMonitor.getStatus();
    ws.send(JSON.stringify({
      type: 'status',
      status
    }));
  }

  async handleFile(ws, data, projectPath) {
    const { action, filePath, content } = data;
    const fs = await import('fs/promises');
    const fullPath = path.resolve(projectPath, filePath);

    try {
      // Security check - ensure path is within project
      const relative = path.relative(projectPath, fullPath);
      if (relative.startsWith('..')) {
        throw new Error('Access denied: Path outside project directory');
      }

      let result;
      
      switch (action) {
        case 'read':
          const fileContent = await fs.readFile(fullPath, 'utf8');
          result = { content: fileContent };
          break;

        case 'write':
          if (!content) {
            throw new Error('Content is required for write action');
          }
          await fs.writeFile(fullPath, content, 'utf8');
          result = { success: true };
          break;

        case 'exists':
          try {
            await fs.access(fullPath);
            result = { exists: true };
          } catch {
            result = { exists: false };
          }
          break;

        case 'list':
          const files = await fs.readdir(fullPath);
          result = { files };
          break;

        default:
          throw new Error(`Unknown file action: ${action}`);
      }

      ws.send(JSON.stringify({
        type: 'file_result',
        action,
        filePath,
        result,
        success: true
      }));
    } catch (error) {
      ws.send(JSON.stringify({
        type: 'file_result',
        action,
        filePath,
        error: error.message,
        success: false
      }));
    }
  }

  monitorTask(ws, taskId) {
    const checkInterval = setInterval(() => {
      const task = this.taskMonitor.getTaskById(taskId);
      
      if (!task) {
        clearInterval(checkInterval);
        return;
      }

      // Send task update
      ws.send(JSON.stringify({
        type: 'task_update',
        task
      }));

      // Stop monitoring if task is complete
      if (task.status === 'completed' || task.status === 'error' || task.status === 'cancelled') {
        logger.info(`[WS] Task done: ${taskId} = ${task.status}`);
        clearInterval(checkInterval);
      }
    }, 1000);

    // Clean up interval after 10 minutes
    setTimeout(() => {
      clearInterval(checkInterval);
    }, 600000);
  }

  // Broadcast task updates to all connected clients
  broadcastTaskUpdate(task) {
    const message = JSON.stringify({
      type: 'task_update',
      task
    });

    this.sessions.forEach(({ ws }) => {
      if (ws.readyState === 1) { // OPEN state
        ws.send(message);
      }
    });
  }
  
  async handleGetTasks(ws, projectPath) {
    try {
      // Get active tasks from the task monitor
      let tasks = [];
      
      if (this.taskMonitor) {
        // getStatus returns { running: [], pending: [], runningByProject: Map }
        const status = this.taskMonitor.getStatus();
        
        if (status) {
          // Combine running and pending tasks
          const allTasks = [
            ...(status.running || []),
            ...(status.pending || [])
          ];
          
          // Filter tasks for the current project path if needed
          // For now, return all tasks
          tasks = allTasks.map(task => ({
            id: task.id,
            name: task.name || task.description || 'Unnamed task',
            status: task.status,
            command: task.command,
            cwd: task.cwd,
            progress: task.progress || 0,
            startedAt: task.startedAt,
            completedAt: task.completedAt,
            error: task.error,
            output: task.output
          }));
          
          logger.info(`[WS] Tasks: ${tasks.length} total (${status.running?.length || 0}R/${status.pending?.length || 0}P) | ${projectPath}`);
        }
      }
      
      ws.send(JSON.stringify({
        type: 'task-list-response',
        tasks: tasks
      }));
    } catch (error) {
      logger.error('Error getting tasks:', error);
      ws.send(JSON.stringify({
        type: 'task-list-response',
        tasks: [],
        error: error.message
      }));
    }
  }
  
  async handleGetGitLog(ws, projectPath) {
    try {
      const { exec } = await import('child_process');
      const { promisify } = await import('util');
      const execAsync = promisify(exec);
      
      // Get git status info
      const gitInfo = {};
      
      try {
        // Get current branch
        const { stdout: branch } = await execAsync('git branch --show-current', { cwd: projectPath });
        gitInfo.branch = branch.trim();
        
        // Get last commit
        const { stdout: lastCommit } = await execAsync('git log -1 --oneline', { cwd: projectPath });
        gitInfo.lastCommit = lastCommit.trim();
        
        // Get uncommitted changes count
        const { stdout: status } = await execAsync('git status --porcelain', { cwd: projectPath });
        const changes = status.split('\n').filter(line => line.trim()).length;
        gitInfo.changes = `${changes} ${changes === 1 ? 'change' : 'changes'}`;
        
        // Get recent commits
        const { stdout: recentCommits } = await execAsync('git log -5 --oneline', { cwd: projectPath });
        gitInfo.recentCommits = recentCommits.trim().split('\n');
        
      } catch (gitError) {
        // Not a git repository or git not available
        logger.debug('Git info not available:', gitError.message);
        gitInfo.branch = 'Not a git repository';
        gitInfo.lastCommit = 'N/A';
        gitInfo.changes = 'N/A';
      }
      
      ws.send(JSON.stringify({
        type: 'git-log-response',
        ...gitInfo
      }));
    } catch (error) {
      logger.error('Error getting git log:', error);
      ws.send(JSON.stringify({
        type: 'git-log-response',
        branch: 'Error',
        lastCommit: 'Error loading git info',
        changes: 'N/A',
        error: error.message
      }));
    }
  }
}
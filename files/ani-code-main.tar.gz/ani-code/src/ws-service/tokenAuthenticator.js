import crypto from 'crypto';
import { logger } from '../logger.js';
import { readFileSync, existsSync } from 'fs';
import { join } from 'path';
import { homedir } from 'os';

export class TokenAuthenticator {
  constructor() {
    this.tokenFile = join(homedir(), '.anicode', 'plugin-tokens.json');
    this.tokens = new Map();
    this.loadTokens();
  }

  loadTokens() {
    try {
      if (existsSync(this.tokenFile)) {
        const data = readFileSync(this.tokenFile, 'utf8');
        const tokens = JSON.parse(data);
        
        // Load tokens into memory
        Object.entries(tokens).forEach(([id, tokenData]) => {
          this.tokens.set(id, tokenData);
        });
        
        logger.info(`Loaded ${this.tokens.size} authentication tokens`);
      }
    } catch (error) {
      logger.error('Failed to load tokens:', error);
    }
  }

  authenticate(req) {
    try {
      // Extract token from query string or authorization header
      const url = new URL(req.url, `http://${req.headers.host}`);
      let token = url.searchParams.get('token');
      
      if (!token && req.headers.authorization) {
        const auth = req.headers.authorization;
        if (auth.startsWith('Bearer ')) {
          token = auth.substring(7);
        }
      }

      if (!token) {
        return {
          success: false,
          error: 'Token required'
        };
      }

      // Parse and validate token
      const validation = this.validateToken(token);
      if (!validation.success) {
        return validation;
      }

      return {
        success: true,
        metadata: validation.payload
      };
    } catch (error) {
      logger.error('Authentication error:', error);
      return {
        success: false,
        error: 'Authentication failed'
      };
    }
  }

  validateToken(token) {
    try {
      logger.debug(`Validating token with length: ${token.length}`);
      
      // Token format: payload.signature.secret
      const parts = token.split('.');
      if (parts.length !== 3) {
        logger.warn(`Token validation failed: Expected 3 parts, got ${parts.length}`);
        return {
          success: false,
          error: `Invalid token format - expected 3 parts separated by dots, got ${parts.length}`
        };
      }

      const [encodedPayload, signature, secret] = parts;
      logger.debug(`Token parts lengths - payload: ${encodedPayload.length}, signature: ${signature.length}, secret: ${secret.length}`);
      
      // Verify signature
      const expectedSignature = crypto
        .createHmac('sha256', secret)
        .update(encodedPayload)
        .digest('hex');
      
      if (signature !== expectedSignature) {
        logger.warn('Token validation failed: Signature mismatch');
        logger.debug(`Expected signature: ${expectedSignature.substring(0, 10)}...`);
        logger.debug(`Received signature: ${signature.substring(0, 10)}...`);
        return {
          success: false,
          error: 'Invalid token signature - token may be corrupted or tampered'
        };
      }

      // Decode payload
      let payload;
      try {
        payload = JSON.parse(Buffer.from(encodedPayload, 'base64').toString());
        logger.debug(`Token payload decoded - project: ${payload.project}, id: ${payload.id}`);
      } catch (decodeError) {
        logger.error('Failed to decode token payload:', decodeError.message);
        return {
          success: false,
          error: 'Invalid token payload - unable to decode'
        };
      }
      
      // Check expiration
      if (Date.now() > payload.expiresAt) {
        const expirationDate = new Date(payload.expiresAt).toISOString();
        logger.warn(`Token validation failed: Token expired at ${expirationDate}`);
        return {
          success: false,
          error: `Token expired at ${expirationDate}`
        };
      }

      // Verify against stored tokens if available
      if (this.tokens.has(payload.id)) {
        const storedToken = this.tokens.get(payload.id);
        const secretHash = crypto.createHash('sha256').update(secret).digest('hex');
        
        if (storedToken.secretHash !== secretHash) {
          logger.warn(`Token validation failed: Secret hash mismatch for token ID ${payload.id}`);
          logger.debug(`Expected hash: ${storedToken.secretHash.substring(0, 10)}...`);
          logger.debug(`Received hash: ${secretHash.substring(0, 10)}...`);
          return {
            success: false,
            error: 'Token verification failed - secret does not match stored token'
          };
        }
        logger.debug(`Token verified successfully against stored token ${payload.id}`);
      } else {
        logger.debug(`Token ID ${payload.id} not found in stored tokens, proceeding with basic validation`);
      }

      return {
        success: true,
        payload
      };
    } catch (error) {
      logger.error('Token validation error:', error);
      return {
        success: false,
        error: 'Token validation failed'
      };
    }
  }

  generateToken(projectId, metadata = {}) {
    try {
      const tokenId = crypto.randomBytes(16).toString('hex');
      const secret = crypto.randomBytes(32).toString('hex');
      
      const payload = {
        id: tokenId,
        project: projectId,
        projectPath: metadata.projectPath || process.cwd(),
        createdAt: Date.now(),
        expiresAt: Date.now() + (7 * 24 * 60 * 60 * 1000), // 7 days
        hostname: metadata.hostname || require('os').hostname(),
        user: metadata.user || require('os').userInfo().username,
        ...metadata
      };
      
      // Encode payload
      const encodedPayload = Buffer.from(JSON.stringify(payload)).toString('base64');
      
      // Create signature
      const signature = crypto
        .createHmac('sha256', secret)
        .update(encodedPayload)
        .digest('hex');
      
      // Create token
      const token = `${encodedPayload}.${signature}.${secret}`;
      
      // Store token hash
      this.tokens.set(tokenId, {
        ...payload,
        secretHash: crypto.createHash('sha256').update(secret).digest('hex')
      });
      
      return {
        token,
        tokenId,
        expiresAt: payload.expiresAt
      };
    } catch (error) {
      logger.error('Token generation error:', error);
      throw error;
    }
  }

  revokeToken(tokenId) {
    if (this.tokens.has(tokenId)) {
      this.tokens.delete(tokenId);
      return true;
    }
    return false;
  }

  getTokenInfo(tokenId) {
    return this.tokens.get(tokenId);
  }

  listTokens() {
    return Array.from(this.tokens.values()).map(token => ({
      id: token.id,
      project: token.project,
      projectPath: token.projectPath,
      createdAt: token.createdAt,
      expiresAt: token.expiresAt,
      expired: Date.now() > token.expiresAt,
      hostname: token.hostname,
      user: token.user
    }));
  }
}
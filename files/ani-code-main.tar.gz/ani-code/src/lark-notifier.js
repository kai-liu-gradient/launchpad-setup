import fetch from 'node-fetch';
import { basename } from 'path';
import { config } from './config.js';
import { logger } from './logger.js';
import { SecureUploader } from './utils/secure-upload.js';
import { normalizeModelNameLowercase } from './utils/model-normalizer.js';
import { gatewayPost } from './utils/gateway-request.js';

export class LarkNotifier {
  constructor() {
    this.webhookUrl = config.lark.webhookUrl;
    this.appId = config.lark.appId;
    this.appSecret = config.lark.appSecret;
    this.groupChatId = config.lark.groupChatId;
    this.accessToken = null;
    this.tokenExpiresAt = 0;
  }

  shortenHostname(hostname) {
    // If hostname has more than 2 parts separated by -, shorten it
    // Example: abc-def-g123 becomes ad-g123
    const parts = hostname.split('-');
    if (parts.length > 2) {
      // Take first letter of each part except the last
      const shortened = parts.slice(0, -1).map(p => p[0]).join('') + '-' + parts[parts.length - 1];
      return shortened;
    }
    return hostname;
  }

  async formatFooter(workdir, options = {}) {
    const time = new Date().toLocaleTimeString('en-GB', {
      hour12: false,
      timeZone: config.timezone,
      hour: '2-digit',
      minute: '2-digit'
    });
    const hostname = this.shortenHostname(config.lark.hostname);

    // Get provider - use provided taskProviderId if available, otherwise get current
    let provider = '';
    if (!options.hideProvider) {
      if (options.taskProviderId) {
        // Use the provider ID from the task
        provider = options.taskProviderId;
      } else {
        // Fall back to current provider
        provider = 'claude'; // default
        try {
          const { getProviderManager } = await import('./providers/providerManager.js');
          const providerManager = await getProviderManager();
          const currentHandler = providerManager.getCurrentHandler();
          if (currentHandler) {
            provider = currentHandler.id;
          }
        } catch (error) {
          logger.debug(`[FOOTER] Could not get provider: ${error.message}`);
        }
      }
    }

    // Build footer - only include provider if not hidden
    const parts = [`🖥️ ${hostname}`, `⏰ ${time}`, `📁 ${workdir}`];
    if (provider) {
      parts.push(`🤖 ${provider}`);
    }

    // Use a cleaner footer format with better visual separation
    return `---\n\n${parts.join(' • ')}`;
  }

  isTemplateStylePrompt(command) {
    // Detect template-style prompts that contain extensive instructions
    const indicators = [
      /^You are a .+\./,  // Starts with "You are a..."
      /IMPORTANT:/,       // Contains "IMPORTANT:"
      /Requirements:/,    // Contains "Requirements:"
      /Your response should/,  // Contains response instructions
      /-.*\n.*-.*\n.*-/,  // Contains multiple bullet points
    ];
    
    // Also check if it's very long (more than 10 lines) and structured
    const lines = command.split('\n');
    const hasMultipleInstructions = lines.length > 10 && 
      (command.includes('Requirements:') || command.includes('IMPORTANT:'));
    
    return indicators.some(pattern => pattern.test(command)) || hasMultipleInstructions;
  }

  getSimplifiedPromptDescription(command, taskName) {
    // Generate simplified descriptions based on task patterns
    
    // Commit message generation
    if (command.includes('git commit message') || taskName.includes('commit-msg')) {
      return '🔄 Generating commit message based on staged changes';
    }
    
    // Git summary
    if (command.includes('git changes') || command.includes('git summary') || taskName.includes('git-summary')) {
      return '📊 Creating git repository summary';
    }
    
    // Code review/analysis
    if (command.includes('code review') || command.includes('analyze')) {
      return '🔍 Analyzing code and providing review';
    }
    
    // Documentation generation
    if (command.includes('documentation') || command.includes('README')) {
      return '📝 Generating documentation';
    }
    
    // Generic template detection
    if (this.isTemplateStylePrompt(command)) {
      const firstLine = command.split('\n')[0];
      if (firstLine.startsWith('You are a ')) {
        const role = firstLine.match(/You are a (.+?)\./)?.[1] || 'specialized assistant';
        return `🤖 Acting as ${role}`;
      }
    }
    
    // Fallback: show first line only
    const firstLine = command.split('\n')[0];
    return firstLine.length > 80 ? firstLine.substring(0, 77) + '...' : firstLine;
  }

  async sendTaskUpdate(task, status, chatId = null, displayMode = 'full') {
    const targetChatId = chatId || task.chatId;
    logger.info(`[CHATID-TRACK] sendTaskUpdate - task ${task.id}, status: ${status}, targetChatId: ${targetChatId || 'default'}, displayMode: ${displayMode}`);
    const message = await this.formatTaskUpdateMessage(task, status, displayMode);
    return this.sendMessage(message, targetChatId);
  }

  async sendTaskSummary(task, result, taskUsage = null, usageReporter = null, chatId = null, pendingCount = 0, displayMode = 'full') {
    const targetChatId = chatId || task.chatId;
    logger.info(`[CHATID-TRACK] sendTaskSummary - task ${task.id}, result: ${result}, targetChatId: ${targetChatId || 'default'}, displayMode: ${displayMode}`);
    const message = await this.formatTaskSummaryMessage(task, result, taskUsage, usageReporter, pendingCount, displayMode);
    return this.sendMessage(message, targetChatId);
  }

  async formatTaskUpdateMessage(task, status, displayMode = 'full') {
    // Simple mode: minimal one-line card with just task description
    if (displayMode === 'simple') {
      let emoji;
      if (status === 'started') emoji = '🚀';
      else if (status === 'queued') emoji = '⏳';
      else emoji = '📝';

      const firstLine = (task.command || '').split('\n')[0] || task.name || 'task';
      const shortPrompt = firstLine.length > 60 ? firstLine.substring(0, 57) + '...' : firstLine;

      return {
        msg_type: 'interactive',
        card: {
          elements: [{
            tag: 'div',
            text: { tag: 'lark_md', content: `${emoji} ${shortPrompt}` }
          }]
        }
      };
    }

    let template, title;
    if (status === 'started') {
      template = 'blue';
      title = `🚀 Task Started - ${task.name}`;
    } else if (status === 'queued') {
      template = 'grey';
      title = `⏳ Task Queued - ${task.name}`;
    } else {
      template = 'grey';
      title = `📝 Task ${status} - ${task.name}`;
    }
    
    // Extract workdir from task - show full path if it's a subfolder
    const workdir = task.cwd ? (task.cwd.includes('/') ? task.cwd.split('/').slice(-2).join('/') : basename(task.cwd)) : 'unknown';
    
    // Build content with task details
    let contentParts = [];
    
    // Add task ID
    contentParts.push(`**Task ID:** ${task.id}`);
    
    // Add PID if available (for started tasks)
    if (task.pid && status === 'started') {
      contentParts.push(`**PID:** ${task.pid}`);
    }
    
    // Add prompt/command information
    contentParts.push(`**Prompt:**`);
    
    // Detect template-style prompts and show simplified message
    if (this.isTemplateStylePrompt(task.command)) {
      contentParts.push(this.getSimplifiedPromptDescription(task.command, task.name));
    } else {
      // Extract and format command (prompt) for regular task start messages
      const commandLines = task.command.split('\n')
        .map(line => line.trim())  // Trim each line
        .filter(line => line.length > 0);  // Remove empty lines
      
      // Join all lines into one and limit to 120 characters
      const fullText = commandLines.join(' ');
      let truncatedCommand;
      
      if (fullText.length > 120) {
        truncatedCommand = fullText.substring(0, 120) + `...(total ${commandLines.length} lines)`;
      } else {
        truncatedCommand = fullText;
      }
      
      contentParts.push(truncatedCommand);
    }
    
    // Join all parts (without footer first)
    let content = contentParts.join('\n');
    
    if (config.lark.keywordPrefix) {
      content = `${config.lark.keywordPrefix} ${content}`;
    }
    
    // Build elements with content first
    const elements = [
      {
        tag: 'div',
        text: {
          tag: 'lark_md',
          content: content
        }
      }
    ];
    
    // Add cancel button for running and queued tasks BEFORE footer
    if ((status === 'started' || status === 'queued') && task.id) {
      const buttonText = status === 'queued' ? '🚫 Cancel Queued Task' : '⏹️ Cancel Task';
      elements.push({
        tag: 'action',
        actions: [
          {
            tag: 'button',
            text: {
              tag: 'plain_text',
              content: buttonText
            },
            type: 'danger',
            value: JSON.stringify({
              action: 'cancel_task',
              taskId: task.id
            })
          }
        ]
      });
    }
    
    // Add footer as a separate element at the bottom
    // Pass task provider ID if available
    elements.push({
      tag: 'div',
      text: {
        tag: 'lark_md',
        content: await this.formatFooter(workdir, { taskProviderId: task.providerId })
      }
    });

    return {
      msg_type: 'interactive',
      card: {
        elements: elements,
        header: {
          title: {
            tag: 'plain_text',
            content: title
          },
          template: template
        }
      }
    };
  }

  async formatTaskSummaryMessage(task, result, taskUsage = null, usageReporter = null, pendingCount = 0, displayMode = 'full') {
    // Simple mode: content + brief completion line
    if (displayMode === 'simple') {
      const duration = task.completedAt - task.startedAt;
      const durationSeconds = Math.round(duration / 1000);

      let emoji;
      if (result === 'success') emoji = '✅';
      else if (result === 'cancelled') emoji = '⏹️';
      else emoji = '❌';

      let contentParts = [];

      // Add output if available — no truncation in simple mode
      if (task.output && task.output.trim()) {
        contentParts.push(task.output.trim());
      }

      if ((result === 'error' || result === 'cancelled') && task.error) {
        contentParts.push(`💬 ${task.error}`);
      }

      contentParts.push(`\n${emoji} Done (${durationSeconds}s) • ${task.id}${pendingCount > 0 ? ` (${pendingCount} pending)` : ''}`);

      return {
        msg_type: 'interactive',
        card: {
          elements: [{
            tag: 'div',
            text: { tag: 'lark_md', content: contentParts.join('\n') }
          }]
        }
      };
    }

    const duration = task.completedAt - task.startedAt;
    const durationSeconds = Math.round(duration / 1000);
    
    // Check if this is a shell command
    const isShellCommand = task.command && task.command.startsWith('shell:');
    const cleanCommand = isShellCommand ? task.command.substring(6).trim() : task.command;
    
    // Check if it's an ani-code related command
    const isAniCodeCommand = cleanCommand && (
      cleanCommand.startsWith('ani-code ') ||
      cleanCommand.startsWith('./ani-code ') ||
      cleanCommand.includes('ani-code/')
    );
    
    // Extract workdir from task - show full path if it's a subfolder
    const workdir = task.cwd ? (task.cwd.includes('/') ? task.cwd.split('/').slice(-2).join('/') : basename(task.cwd)) : 'unknown';
    
    let color, title;
    
    if (result === 'success') {
      color = 'green';
      title = `✅ Task Completed - ${task.name}`;
      // Add pending count to title if there are pending tasks
      if (pendingCount > 0) {
        title += ` (${pendingCount} pending)`;
      }
    } else if (result === 'cancelled') {
      color = 'orange';
      title = `⏹️ Task Cancelled - ${task.name}`;
      // Add pending count to title if there are pending tasks
      if (pendingCount > 0) {
        title += ` (${pendingCount} pending)`;
      }
    } else {
      color = 'red';
      title = `❌ Task Failed - ${task.name}`;
      // Add pending count to title if there are pending tasks
      if (pendingCount > 0) {
        title += ` (${pendingCount} pending)`;
      }
    }
    
    // For shell commands that are NOT ani-code related and succeeded, show simplified format
    if (isShellCommand && !isAniCodeCommand && result === 'success') {
      let contentParts = [];
      
      // Add task ID
      contentParts.push(`**Task ID:** ${task.id}`);
      
      // Only add duration if >= 3 seconds
      if (durationSeconds >= 3) {
        contentParts.push(`**Duration:** ${durationSeconds}s`);
      }
      
      // Add the command
      contentParts.push(`$ ${cleanCommand}`);
      
      // Add output if available
      if (task.output && task.output.trim()) {
        const allLines = task.output.trim().split('\n');
        const totalLines = allLines.length;
        
        // If output is 20 lines or less, show all
        if (totalLines <= 20) {
          contentParts.push(task.output.trim());
        } else {
          // Show first 2 lines, hidden count, and last 18 lines
          const firstLines = allLines.slice(0, 2).join('\n');
          const lastLines = allLines.slice(-18).join('\n');
          const hiddenCount = totalLines - 20;
          
          const truncatedOutput = `${firstLines}\n[...hidden ${hiddenCount} lines...]\n${lastLines}`;
          contentParts.push(truncatedOutput);
        }
      }
      
      // Continue with footer (usage info) processing below
      const content = contentParts.join('\n');
      
      // Build cost/token footer
      let costTokenLine = await this.buildCostTokenLine(taskUsage, usageReporter, task.id);
      
      // Structure the final content with footer
      const parts = [];
      if (content) {
        parts.push(content);
      }
      if (costTokenLine) {
        // Add empty line before cost/token line
        parts.push('');
        parts.push(costTokenLine);
      }
      // Pass task provider ID to footer
      parts.push(await this.formatFooter(workdir, { taskProviderId: task.providerId }));

      const finalContent = parts.join('\n');
      
      // Add keyword prefix if configured
      let prefixedContent = finalContent;
      if (config.lark.keywordPrefix) {
        prefixedContent = `${config.lark.keywordPrefix} ${finalContent}`;
      }
      
      // Build message structure for simplified shell format
      const elements = [
        {
          tag: 'div',
          text: {
            tag: 'lark_md',
            content: prefixedContent
          }
        }
      ];
      
      return {
        msg_type: 'interactive',
        card: {
          elements: elements,
          header: {
            title: {
              tag: 'plain_text',
              content: title
            },
            template: color
          }
        }
      };
    }
    
    // Original format for non-shell or ani-code commands
    let contentParts = [];
    
    // Add task details at the top
    contentParts.push(`**Task ID:** ${task.id}`);
    contentParts.push(`**Duration:** ${durationSeconds}s`);
    
    // Add PID if it was available
    if (task.pid) {
      contentParts.push(`**PID:** ${task.pid}`);
    }
    
    // Add exit code for failed tasks
    if (task.exitCode !== null && task.exitCode !== 0) {
      contentParts.push(`**Exit Code:** ${task.exitCode}`);
    }
    
    // Add output if available
    if (task.output && task.output.trim()) {
      const allLines = task.output.trim().split('\n');
      const totalLines = allLines.length;
      
      // If output is 20 lines or less, show all
      if (totalLines <= 20) {
        contentParts.push(task.output.trim());
      } else {
        // Show first 4 lines and last 16 lines (total 20 visible)
        const firstLines = allLines.slice(0, 4).join('\n').trim();
        const lastLines = allLines.slice(-16).join('\n').trim();
        const hiddenCount = totalLines - 20;
        
        // Only hide if we're actually hiding more lines than we're showing
        if (hiddenCount < 20) {
          // Show all lines if hidden lines are less than shown lines
          contentParts.push(task.output.trim());
        } else {
          const truncatedOutput = `${firstLines}\n[...hidden ${hiddenCount} lines...]\n${lastLines}`;
          contentParts.push(truncatedOutput);
        }
      }
    }
    
    // Add error if present
    if ((result === 'error' || result === 'cancelled') && task.error) {
      contentParts.push(`💬 ${task.error}`);
    }
    
    // Add continue suggestion for failed Claude tasks
    if (result === 'error' && task.exitCode !== null && task.exitCode !== 0) {
      // Check if this is a Claude task (name contains 'claude' or command looks like a Claude prompt)
      const isClaudeTask = task.name.toLowerCase().includes('claude') || 
                          task.command.includes('You are a') ||
                          task.command.includes('IMPORTANT:') ||
                          task.command.includes('Requirements:');
      
      if (isClaudeTask) {
        const continueCmd = `ani-code task-continue`;
        const continueWithProject = task.cwd && task.cwd !== process.cwd() 
          ? `ani-code task-continue ${task.id}` 
          : continueCmd;
        contentParts.push(`💡 To continue this Claude task, run: \`${continueWithProject}\``);
      }
    }
    
    // Build cost/token line using helper method
    let costTokenLine = await this.buildCostTokenLine(taskUsage, usageReporter, task.id);
    
    // Structure: [output] \n\n [cost/token/time line] \n [footer]
    const parts = [];
    if (contentParts.length > 0) {
      parts.push(contentParts.join('\n'));
    }
    if (costTokenLine) {
      // Add empty line before cost/token line
      parts.push('');
      parts.push(costTokenLine);
    }
    // Pass task provider ID to footer
    parts.push(await this.formatFooter(workdir, { taskProviderId: task.providerId }));

    let content = parts.join('\n');
    
    if (config.lark.keywordPrefix) {
      content = `${config.lark.keywordPrefix} ${content}`;
    }
    
    // Build elements
    const elements = [
      {
        tag: 'div',
        text: {
          tag: 'lark_md',
          content: content
        }
      }
    ];
    
    // Add action buttons based on task result
    const actions = [];
    
    if (result === 'success') {
      // Add Check button for successful tasks
      actions.push({
        tag: 'button',
        text: {
          tag: 'plain_text',
          content: '✅ Check'
        },
        type: 'primary',
        value: JSON.stringify({
          action: 'run_check'
        })
      });
      
      // Add commit button for successful tasks, but skip if task name already contains "commit"
      if (!task.name.toLowerCase().includes('commit')) {
        actions.push({
          tag: 'button',
          text: {
            tag: 'plain_text',
            content: '💾 Commit Changes'
          },
          type: 'default',
          value: JSON.stringify({
            action: 'run_task',
            command: 'ani-code commit -y'
          })
        });
      }
      
      // Try to get workspace settings for homepage button
      try {
        if (task.cwd) {
          const { WorkspaceManager } = await import('../workspace-manager.js');
          const manager = new WorkspaceManager();
          await manager.initialize();
          const workspace = await manager.getWorkspaceByPath(task.cwd);
          
          if (workspace && workspace.settings && workspace.settings.homepage) {
            // Validate that homepage is a valid URL
            try {
              const homepageUrl = new URL(workspace.settings.homepage);
              // Only add button if it's a valid http/https URL
              if (homepageUrl.protocol === 'http:' || homepageUrl.protocol === 'https:') {
                actions.push({
                  tag: 'button',
                  text: {
                    tag: 'plain_text',
                    content: '🌐 Open Homepage'
                  },
                  type: 'default',
                  url: workspace.settings.homepage
                });
              } else {
                logger.debug(`Homepage URL has invalid protocol: ${homepageUrl.protocol}`);
              }
            } catch (urlError) {
              logger.debug(`Invalid homepage URL: ${workspace.settings.homepage}`);
            }
          }
          
          await manager.close();
        }
      } catch (error) {
        logger.debug(`Failed to get workspace settings for homepage button: ${error.message}`);
      }
    }
    
    // Removed View Full Logs button since output is already shown in the message
    
    // Add action element if we have any buttons
    if (actions.length > 0) {
      elements.push({
        tag: 'action',
        actions: actions
      });
    }

    return {
      msg_type: 'interactive',
      card: {
        elements: elements,
        header: {
          title: {
            tag: 'plain_text',
            content: title
          },
          template: color
        }
      }
    };
  }

  async buildCostTokenLine(taskUsage, usageReporter, taskId = null) {
    if (!taskUsage || (taskUsage.cost <= 0 && taskUsage.tokens <= 0)) {
      logger.info('No taskUsage or zero cost/tokens, returning empty line');
      return '';
    }
    
    logger.info('Building cost/token line with usage:', JSON.stringify(taskUsage));
    
    // Format tokens with k/m abbreviations
    const formatTokens = (tokens) => {
      if (tokens >= 1000000) {
        return `${(tokens / 1000000).toFixed(1)}m`;
      } else if (tokens >= 1000) {
        return `${(tokens / 1000).toFixed(1)}k`;
      }
      return tokens.toLocaleString();
    };

    // Helper function to format model names for display
    const formatModelName = (modelName) => {
      return normalizeModelNameLowercase(modelName);
    };
    
    // Build token breakdown with actual counts
    const inputTotal = (taskUsage.inputTokens || 0);
    const cachedInput = (taskUsage.cacheReadTokens || 0);
    const outputTotal = (taskUsage.outputTokens || 0);
    
    // Build the comprehensive token line
    const tokenParts = [];
    
    // If we have total tokens but no breakdown, show total
    if (taskUsage.tokens > 0 && inputTotal === 0 && outputTotal === 0) {
      tokenParts.push(`Total: ${formatTokens(taskUsage.tokens)}`);
    } else {
      // Show detailed breakdown when available
      if (inputTotal > 0) {
        tokenParts.push(`In: ${formatTokens(inputTotal)}${cachedInput > 0 ? ` (${formatTokens(cachedInput)} cached)` : ''}`);
      }
      if (outputTotal > 0) {
        tokenParts.push(`Out: ${formatTokens(outputTotal)}`);
      }
    }
    
    // Build model information
    let modelInfo = '';
    if (taskUsage.modelBreakdowns && taskUsage.modelBreakdowns.length > 0) {
      // Sort models by cost (highest first) to show the primary model first
      const sortedModels = taskUsage.modelBreakdowns.sort((a, b) => b.cost - a.cost);
      const modelNames = sortedModels.map(model => formatModelName(model.modelName));
      modelInfo = ` (${modelNames.join(', ')})`;
    } else if (taskUsage.modelsUsed && taskUsage.modelsUsed.length > 0) {
      // Fallback to modelsUsed if modelBreakdowns not available
      const modelNames = taskUsage.modelsUsed.map(model => formatModelName(model));
      modelInfo = ` (${modelNames.join(', ')})`;
    }

    let costTokenLine = `💰 $${taskUsage.cost.toFixed(4)}${modelInfo}`;
    if (tokenParts.length > 0) {
      costTokenLine += ` • ${tokenParts.join(' • ')}`;
    }
    
    // Get original snapshot if available
    if (taskId && usageReporter) {
      const beforeSnapshot = usageReporter.taskSnapshots.get(`${taskId}_before`);
      if (beforeSnapshot) {
        // Validate snapshot data
        if (!beforeSnapshot.totals || typeof beforeSnapshot.totals !== 'object') {
          logger.error(`❌ [LARK_NOTIFIER] BROKEN DATA: beforeSnapshot exists but has invalid totals for task ${taskId}`);
          logger.error(`[LARK_NOTIFIER] beforeSnapshot keys: ${JSON.stringify(Object.keys(beforeSnapshot))}`);
          logger.error(`[LARK_NOTIFIER] beforeSnapshot.totals: ${JSON.stringify(beforeSnapshot.totals)}`);
          costTokenLine += `\n⚠️ Warning: Snapshot data corrupted`;
        } else {
          const originalCost = beforeSnapshot.totals.totalCost;
          const originalTokens = beforeSnapshot.totals.totalTokens;
          costTokenLine += `\n📸 Original: $${originalCost.toFixed(4)} • ${formatTokens(originalTokens)}`;
        }
      }
    }
    
    // Add daily/monthly spending context
    try {
      const { execSync } = await import('child_process');

      // Get today's total spending and tokens
      const today = new Date().toISOString().split('T')[0].replace(/-/g, '');
      const todayOutput = execSync(`npx ccusage -i --offline --since ${today} -j`, { encoding: 'utf8' });
      const todayData = JSON.parse(todayOutput);
      const dailySpent = todayData.totals.totalCost;
      const dailyTokens = todayData.totals.totalTokens;

      // Get this month's total spending and tokens
      const thisMonth = today.slice(0, 6); // YYYYMM
      const monthOutput = execSync(`npx ccusage -i --offline --since ${thisMonth}01 -j`, { encoding: 'utf8' });
      const monthData = JSON.parse(monthOutput);
      const monthlySpent = monthData.totals.totalCost;
      const monthlyTokens = monthData.totals.totalTokens;
      
      costTokenLine += `\n📅 today: $${dailySpent.toFixed(2)} • ${formatTokens(dailyTokens)}, month: $${monthlySpent.toFixed(2)} • ${formatTokens(monthlyTokens)}`;
    } catch (error) {
      // If we can't get spending context, just use the original format
      logger.debug('Could not fetch daily/monthly spending context:', error.message);
    }
    
    return costTokenLine;
  }

  async getAccessToken() {
    // Check if we have a valid cached token
    if (this.accessToken && Date.now() < this.tokenExpiresAt) {
      return this.accessToken;
    }

    if (!this.appId || !this.appSecret) {
      logger.warn('Lark App ID or Secret not configured');
      return null;
    }

    try {
      const response = await fetch('https://open.larksuite.com/open-apis/auth/v3/tenant_access_token/internal', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          app_id: this.appId,
          app_secret: this.appSecret
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const result = await response.json();
      if (result.code !== 0) {
        throw new Error(`Lark API error: ${result.msg}`);
      }

      this.accessToken = result.tenant_access_token;
      // Set expiry to 5 minutes before actual expiry for safety
      this.tokenExpiresAt = Date.now() + ((result.expire - 300) * 1000);
      logger.debug('Lark access token obtained successfully');
      return this.accessToken;
    } catch (error) {
      logger.error('Failed to get Lark access token', error);
      return null;
    }
  }

  async sendMessageToChat(chatId, content, msgType = 'interactive') {
    if (!chatId) {
      logger.warn('Chat ID is required to send message');
      return;
    }

    const accessToken = await this.getAccessToken();
    if (!accessToken) {
      logger.error('Cannot send message without access token');
      return;
    }

    // Mask any sensitive credentials in the content
    const maskedContent = SecureUploader.maskCredentials(content);

    try {
      const response = await fetch('https://open.larksuite.com/open-apis/im/v1/messages?receive_id_type=chat_id', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          receive_id: chatId,
          msg_type: msgType,
          content: maskedContent  // content should already be a string
        })
      });

      if (!response.ok) {
        const errorText = await response.text();
        logger.error('Lark API response error:', errorText);
        throw new Error(`HTTP ${response.status}: ${response.statusText} - ${errorText}`);
      }

      const result = await response.json();
      if (result.code !== 0) {
        logger.error('Lark API error details:', result);
        throw new Error(`Lark API error: ${result.msg} (code: ${result.code})`);
      }

      logger.debug(`Message sent to chat ${chatId} successfully`);
      return result;
    } catch (error) {
      logger.error(`Failed to send message to chat ${chatId}: ${error.message}`);
      // Check if it's an invalid chat ID error
      if (error.message.includes('invalid receive_id') || error.message.includes('230001')) {
        logger.warn(`Chat ID ${chatId} appears to be invalid or inaccessible`);
      }
      throw error;
    }
  }

  async sendMessageToGroup(content, msgType = 'interactive') {
    if (!this.groupChatId) {
      logger.warn('Lark group chat ID not configured');
      return;
    }

    // Use the new sendMessageToChat method
    return this.sendMessageToChat(this.groupChatId, content, msgType);
  }

  async sendViaGateway(platform, chatId, message, options = {}) {
    // Validate required fields before sending
    if (!platform) {
      throw new Error('Platform is required for gateway callback');
    }
    if (!chatId) {
      logger.warn('⚠️  chatId is null/undefined, cannot send via gateway');
      return null; // Signal fallback to direct send
    }
    if (!message) {
      throw new Error('Message is required for gateway callback');
    }

    const payload = {
      platform,
      chatId,
      message: {
        ...message,
        ...options
      },
      instanceId: config.gateway.instanceId,
      timestamp: new Date().toISOString()
    };

    try {
      const response = await gatewayPost(
        `${config.gateway.url}/api/callback/message`,
        payload,
        {
          instanceId: config.gateway.instanceId,
          token: config.gateway.token
        },
        {
          timeout: 10000
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Gateway callback failed: ${response.status} - ${errorText}`);
      }

      const result = await response.json();
      logger.debug(`✓ Message sent via gateway`, {
        platform,
        chatId,
        messageType: message.msg_type
      });

      return result;
    } catch (error) {
      logger.error(`✗ Gateway callback error:`, {
        error: error.message,
        platform,
        chatId,
        gatewayUrl: config.gateway.url
      });

      // Fallback to direct send on gateway failure
      if (platform === 'lark') {
        logger.warn(`⚠️  Falling back to direct lark send for chat ${chatId}`);
        // Fall through to normal send logic
        return null; // Signal to continue with normal flow
      }

      throw error;
    }
  }

  async sendMessage(message, chatId = null) {
    // Route through gateway if in gateway mode
    if (config.gateway.enabled) {
      const targetChatId = chatId || this.groupChatId;

      // In gateway mode with no chatId, try to use Telegram default chat
      if (!targetChatId) {
        // Import TelegramNotifier to get default chatId for gateway fallback
        try {
          const { TelegramNotifier } = await import('./telegram-notifier.js');
          const telegramNotifier = new TelegramNotifier();

          if (telegramNotifier.defaultChatId) {
            logger.info(`[GATEWAY-FALLBACK] No chatId, routing to Telegram default: ${telegramNotifier.defaultChatId}`);
            // Convert Lark message to simple text for Telegram
            let textContent = '';
            if (message.msg_type === 'interactive' && message.card) {
              // Extract text from Lark card
              textContent = this.extractTextFromCard(message.card);
            } else if (message.content) {
              textContent = typeof message.content === 'string' ? message.content : JSON.stringify(message.content);
            } else {
              textContent = JSON.stringify(message);
            }

            return telegramNotifier.sendMessage(telegramNotifier.defaultChatId, textContent, { parse_mode: 'Markdown' });
          }
        } catch (error) {
          logger.warn(`[GATEWAY-FALLBACK] Failed to get Telegram default: ${error.message}`);
        }

        logger.warn('⚠️  No chatId and no Telegram default available, message will not be sent');
        return null;
      }

      const result = await this.sendViaGateway('lark', targetChatId, message);
      if (result !== null) {
        return result; // Gateway send successful
      }
      // If result is null, fallback to direct send
    }

    logger.info(`[CHATID-TRACK] sendMessage called with chatId: ${chatId || 'null'}, will send to: ${chatId || this.groupChatId || 'webhook'}`);

    // Check if this is a Telegram chat ID
    if (chatId && chatId.startsWith('telegram:')) {
      logger.debug(`Skipping Lark notification for Telegram chat: ${chatId}`);
      return null; // Telegram messages are handled by TelegramNotifier
    }
    
    // If a specific chat ID is provided, send to that chat
    if (chatId && this.appId && this.appSecret) {
      try {
        // For interactive cards, we need to stringify the card content
        if (message.msg_type === 'interactive' && message.card) {
          return await this.sendMessageToChat(chatId, JSON.stringify(message.card), 'interactive');
        } else {
          return await this.sendMessageToChat(chatId, JSON.stringify(message), message.msg_type || 'text');
        }
      } catch (error) {
        logger.warn(`Failed to send to specific chat ${chatId}: ${error.message}`);
        logger.warn('Falling back to group chat');
        // Don't return here - continue to try group chat
      }
    }
    
    // Try to send via API to group
    if (this.groupChatId && this.appId && this.appSecret) {
      try {
        // For interactive cards, we need to stringify the card content
        if (message.msg_type === 'interactive' && message.card) {
          return await this.sendMessageToGroup(JSON.stringify(message.card), 'interactive');
        } else {
          return await this.sendMessageToGroup(JSON.stringify(message), message.msg_type || 'text');
        }
      } catch (error) {
        logger.warn('Failed to send via API, falling back to webhook if available');
      }
    }

    // Fallback to webhook if configured
    if (!this.webhookUrl) {
      logger.warn('No Lark notification method available (neither API nor webhook configured)');
      return;
    }

    try {
      const response = await fetch(this.webhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(message)
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const result = await response.json();
      if (result.code !== 0) {
        throw new Error(`Lark API error: ${result.msg}`);
      }

      logger.debug('Lark notification sent successfully');
      return result;
    } catch (error) {
      logger.error('Failed to send Lark notification', error);
      throw error;
    }
  }

  async sendCustomMessage(title, content, color = 'blue', chatId = null) {
    let finalContent = content;

    // Add footer to custom messages if they don't already have one
    if (!content.includes('🖥️') && !content.includes('⏰')) {
      finalContent = `${content}\n\n${await this.formatFooter('system')}`;
    }
    
    if (config.lark.keywordPrefix) {
      finalContent = `${config.lark.keywordPrefix} ${finalContent}`;
    }
    
    const message = {
      msg_type: 'interactive',
      card: {
        elements: [
          {
            tag: 'div',
            text: {
              tag: 'lark_md',
              content: finalContent
            }
          }
        ],
        header: {
          title: {
            tag: 'plain_text',
            content: title
          },
          template: color
        }
      }
    };

    return this.sendMessage(message, chatId);
  }

  /**
   * Extract text content from a Lark interactive card for Telegram fallback
   * @param {Object} card - Lark card object
   * @returns {string} - Plain text representation of the card
   */
  extractTextFromCard(card) {
    let text = '';

    // Extract header title
    if (card.header?.title?.content) {
      text += `*${card.header.title.content}*\n\n`;
    }

    // Extract elements content
    if (card.elements && Array.isArray(card.elements)) {
      for (const element of card.elements) {
        if (element.tag === 'div' && element.text?.content) {
          text += element.text.content + '\n';
        } else if (element.tag === 'markdown' && element.content) {
          text += element.content + '\n';
        } else if (element.tag === 'hr') {
          text += '---\n';
        }
      }
    }

    return text.trim() || JSON.stringify(card);
  }

  async sendInteractiveMessage(title, content, color = 'blue', actions = [], chatId = null) {
    let finalContent = content;

    // Add footer to custom messages if they don't already have one
    if (!content.includes('🖥️') && !content.includes('⏰')) {
      finalContent = `${content}\n\n${await this.formatFooter('system')}`;
    }
    
    if (config.lark.keywordPrefix) {
      finalContent = `${config.lark.keywordPrefix} ${finalContent}`;
    }
    
    const elements = [
      {
        tag: 'div',
        text: {
          tag: 'lark_md',
          content: finalContent
        }
      }
    ];
    
    // Add action buttons if provided
    if (actions && actions.length > 0) {
      elements.push({
        tag: 'action',
        actions: actions
      });
    }
    
    const message = {
      msg_type: 'interactive',
      card: {
        elements: elements,
        header: {
          title: {
            tag: 'plain_text',
            content: title
          },
          template: color
        }
      }
    };
    
    return this.sendMessage(message, chatId);
  }

  async sendUnrecognizedCommandMessage(chatId, unrecognizedText, currentWorkdirName, availableWorkdirs) {
    const currentWorkdirPath = currentWorkdirName ? availableWorkdirs[currentWorkdirName] : null;
    
    // Check if the unrecognized text is empty or just whitespace
    const trimmedText = unrecognizedText.trim();
    if (!trimmedText) {
      // For empty messages, just show status
      const statusButton = {
        tag: 'button',
        text: {
          tag: 'plain_text',
          content: '📊 Show Status'
        },
        type: 'primary',
        value: JSON.stringify({
          action: 'show_status'
        })
      };
      
      const helpButton = {
        tag: 'button',
        text: {
          tag: 'plain_text',
          content: '❓ Show Help'
        },
        type: 'default',
        value: JSON.stringify({
          action: 'show_help'
        })
      };
      
      const elements = [
        {
          tag: 'div',
          text: {
            tag: 'lark_md',
            content: config.lark.keywordPrefix ? 
              `${config.lark.keywordPrefix} **What would you like to do?**` :
              '**What would you like to do?**'
          }
        },
        {
          tag: 'action',
          actions: [statusButton, helpButton]
        }
      ];
      
      // If no workdir is set, show workdir selection
      if (!currentWorkdirName) {
        const workdirButtons = [];
        const workdirEntries = Object.entries(availableWorkdirs);
        
        for (const [name, path] of workdirEntries.slice(0, 3)) {
          workdirButtons.push({
            tag: 'button',
            text: {
              tag: 'plain_text',
              content: `📁 ${name}`
            },
            type: 'default',
            value: JSON.stringify({
              action: 'set_workdir',
              workdir: name
            })
          });
        }
        
        if (workdirButtons.length > 0) {
          elements.push({
            tag: 'div',
            text: {
              tag: 'lark_md',
              content: '**📁 Select a working directory:**'
            }
          });
          
          elements.push({
            tag: 'action',
            actions: workdirButtons
          });
        }
      }
      
      // Send the simplified card for empty input
      const card = {
        config: {
          wide_screen_mode: true
        },
        elements: elements
      };
      
      try {
        // Send the card using the sendMessage method
        const message = {
          msg_type: 'interactive',
          card: card
        };
        await this.sendMessage(message, chatId);
      } catch (error) {
        logger.error('Failed to send empty input card:', error);
      }
      
      return;
    }
    
    // For non-empty messages, show the normal unrecognized command UI
    let helpContent = `❓ **Unrecognized Input:**\n`;
    helpContent += `\`${unrecognizedText}\`\n\n`;
    helpContent += `💡 **What would you like to do with this text?**`;
    
    if (config.lark.keywordPrefix) {
      helpContent = `${config.lark.keywordPrefix} ${helpContent}`;
    }
    
    // Build elements with action buttons
    const elements = [
      {
        tag: 'div',
        text: {
          tag: 'lark_md',
          content: helpContent
        }
      },
      {
        tag: 'div',
        text: {
          tag: 'lark_md',
          content: '**Choose an action:**'
        }
      }
    ];
    
    const actionButtons = [];
    
    // Add Claude task button if workdir is set
    if (currentWorkdirName) {
      actionButtons.push({
        tag: 'button',
        text: {
          tag: 'plain_text',
          content: '🤖 Create Claude Task'
        },
        type: 'primary',
        value: JSON.stringify({
          action: 'create_task',
          command: 'add',
          prompt: unrecognizedText
        })
      });
      
      actionButtons.push({
        tag: 'button',
        text: {
          tag: 'plain_text',
          content: '↪️ Continue Claude Task'
        },
        type: 'primary',
        value: JSON.stringify({
          action: 'create_task',
          command: 'continue',
          prompt: unrecognizedText
        })
      });
      
      // Only add shell command button if there's actual text to run
      actionButtons.push({
        tag: 'button',
        text: {
          tag: 'plain_text',
          content: '⚡ Run as Shell'
        },
        type: 'default',
        value: JSON.stringify({
          action: 'create_task',
          command: 'shell',
          prompt: unrecognizedText
        })
      });
    }
    
    // Add help button
    actionButtons.push({
      tag: 'button',
      text: {
        tag: 'plain_text',
        content: '❓ Show Help'
      },
      type: 'default',
      value: JSON.stringify({
        action: 'show_help'
      })
    });
    
    elements.push({
      tag: 'action',
      actions: actionButtons
    });
    
    // If no workdir is set, show workdir selection
    if (!currentWorkdirName) {
      elements.push({
        tag: 'div',
        text: {
          tag: 'lark_md',
          content: '\n⚠️ **No working directory selected**\nPlease select a directory to enable Claude tasks:'
        }
      });
      
      const workdirButtons = [];
      for (const [name, path] of Object.entries(availableWorkdirs)) {
        workdirButtons.push({
          tag: 'button',
          text: {
            tag: 'plain_text',
            content: name
          },
          type: 'default',
          value: JSON.stringify({
            action: 'set_workdir',
            workdir: name
          })
        });
      }
      
      if (workdirButtons.length > 0) {
        elements.push({
          tag: 'action',
          actions: workdirButtons
        });
      }
    }
    
    const message = {
      msg_type: 'interactive',
      card: {
        elements,
        header: {
          title: {
            tag: 'plain_text',
            content: '❓ Unrecognized Command'
          },
          template: 'orange'
        }
      }
    };
    
    return this.sendMessage(message, chatId);
  }

  async sendHelpMessage(chatId, currentWorkdirName) {
    const currentWorkdirPath = null; // Will be set when connected to workspace
    
    let helpContent = `🤖 **AniCode Bot Commands**\n`;
    helpContent += `**Task Commands:**\n`;
    helpContent += `• **/add [prompt]** - Create a new Claude task\n`;
    helpContent += `• **/continue [prompt]** - Continue previous Claude task\n`;
    helpContent += `• **/check** - Run completion checklist\n`;
    helpContent += `• **/status** - Show running tasks\n`;
    helpContent += `• **/rank** - Show daily usage report\n`;
    helpContent += `• **/usage** - Check Claude API usage (sessions, Opus)\n`;
    helpContent += `• **/usage reset all** - Reset all usage cache (session + opus)\n`;
    helpContent += `• **/usage reset opus** - Reset opus usage cache only\n`;
    helpContent += `• **/branch [name/desc]** - Create or switch git branches\n`;
    helpContent += `\n**Plan Commands:**\n`;
    helpContent += `• **/plan [steps]** - Create a new plan with steps\n`;
    helpContent += `• **/plans** - List all plans for the workspace\n`;
    helpContent += `• **/next [plan-id]** - Execute the next plan or specific plan\n`;
    helpContent += `• **/yolo** - Execute ALL pending plans with commits\n`;
    helpContent += `• **/stopyolo** - Stop ongoing YOLO execution\n`;
    helpContent += `• **/cleanup** - Remove all completed plans\n`;
    helpContent += `• **/purge confirm** - Force reset all plans (⚠️ dangerous)\n`;

    // Show current workdir status
    if (!currentWorkdirName) {
      helpContent += `\n**Workspace Settings:**\n`;
      helpContent += `• **/connect [token]** - Connect this chat to a workspace\n`;
      helpContent += `\n❌ **No workspace connected** - use /connect [token] to connect`;
    } else {
      helpContent += `\n📁 **Working in:** ${currentWorkdirName}`;
    }
    
    if (config.lark.keywordPrefix) {
      helpContent = `${config.lark.keywordPrefix} ${helpContent}`;
    }
    
    // Build elements with quick action buttons
    const elements = [
      {
        tag: 'div',
        text: {
          tag: 'lark_md',
          content: helpContent
        }
      }
    ];
    
    // Add quick action buttons
    const actions = [];
    
    // Add workdir selection buttons if not set
    if (!currentWorkdirName && Object.keys(availableWorkdirs).length > 0) {
      elements.push({
        tag: 'div',
        text: {
          tag: 'lark_md',
          content: '**Quick Setup:**'
        }
      });
      
      const workdirActions = [];
      for (const [name, path] of Object.entries(availableWorkdirs)) {
        if (workdirActions.length < 3) { // Limit to 3 buttons per row
          workdirActions.push({
            tag: 'button',
            text: {
              tag: 'plain_text',
              content: `📁 Set: ${name}`
            },
            type: 'primary',
            value: JSON.stringify({
              action: 'set_workdir',
              workdir: name
            })
          });
        }
      }
      
      if (workdirActions.length > 0) {
        elements.push({
          tag: 'action',
          actions: workdirActions
        });
      }
    }
    
    // Add common task buttons
    elements.push({
      tag: 'div',
      text: {
        tag: 'lark_md',
        content: '**Quick Actions:**'
      }
    });
    
    const quickActions = [];
    
    // Status button
    quickActions.push({
      tag: 'button',
      text: {
        tag: 'plain_text',
        content: '📊 Status'
      },
      type: 'default',
      value: JSON.stringify({
        action: 'show_status'
      })
    });
    
    
    elements.push({
      tag: 'action',
      actions: quickActions
    });
    
    // If workdir is set, add Claude task buttons
    if (currentWorkdirName) {
      // Add Claude task buttons
      elements.push({
        tag: 'div',
        text: {
          tag: 'lark_md',
          content: '**Claude Tasks:**'
        }
      });
      
      const claudeTaskActions = [
        {
          tag: 'button',
          text: {
            tag: 'plain_text',
            content: '🔄 Continue'
          },
          type: 'primary',
          value: JSON.stringify({
            action: 'claude_continue'
          })
        },
        {
          tag: 'button',
          text: {
            tag: 'plain_text',
            content: '💾 Commit'
          },
          type: 'primary',
          value: JSON.stringify({
            action: 'run_task',
            command: 'ani-code commit -y'
          })
        },
        {
          tag: 'button',
          text: {
            tag: 'plain_text',
            content: '📊 What Changed'
          },
          type: 'primary',
          value: JSON.stringify({
            action: 'run_task',
            command: 'ani-code doc -y'
          })
        }
      ];
      
      elements.push({
        tag: 'action',
        actions: claudeTaskActions
      });
    }
    
    // Add footer
    elements.push({
      tag: 'div',
      text: {
        tag: 'lark_md',
        content: await this.formatFooter('help')
      }
    });

    const message = {
      msg_type: 'interactive',
      card: {
        elements: elements,
        header: {
          title: {
            tag: 'plain_text',
            content: '📚 Help'
          },
          template: 'blue'
        }
      }
    };

    return this.sendMessage(message, chatId);
  }
}
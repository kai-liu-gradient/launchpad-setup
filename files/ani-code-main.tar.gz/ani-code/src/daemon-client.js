import { readFileSync, existsSync } from 'fs';
import { join, dirname } from 'path';
import { execSync } from 'child_process';
import { logger } from './logger.js';
import { fileURLToPath } from 'url';
import fetch from 'node-fetch';

export class DaemonClient {
  constructor() {
    // Use the directory where this script is located as base directory
    const __filename = fileURLToPath(import.meta.url);
    const __dirname = dirname(__filename);
    const baseDir = join(__dirname, '..');
    this.pidFile = join(baseDir, '.ani-code-daemon.pid');
    this.serviceName = 'ani-code';
    // Support multiple env vars with priority: ANI_CODE_DAEMON_PORT > HTTP_CALLBACK_PORT > PORT > default
    this.daemonPort = parseInt(process.env.ANI_CODE_DAEMON_PORT || process.env.HTTP_CALLBACK_PORT || process.env.PORT) || 6501;
  }

  async checkVersionCompatibility() {
    // Get CLI version from package.json first (always available)
    const __filename = fileURLToPath(import.meta.url);
    const __dirname = dirname(__filename);
    const packagePath = join(__dirname, '..', 'package.json');
    const packageJson = JSON.parse(readFileSync(packagePath, 'utf8'));
    const cliVersion = packageJson.version;

    try {
      // Get daemon version from HTTP API
      const response = await fetch(`http://127.0.0.1:${this.daemonPort}/version`, {
        timeout: 2000,
        headers: {
          'X-CLI-Version': cliVersion
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to get daemon version: ${response.status}`);
      }

      const data = await response.json();
      const daemonVersion = data.version;

      if (!daemonVersion) {
        throw new Error('Daemon version not available');
      }

      // Compare versions (major.minor.patch)
      const cliParts = cliVersion.split('.').map(Number);
      const daemonParts = daemonVersion.split('.').map(Number);

      // Check major version compatibility (must match)
      if (cliParts[0] !== daemonParts[0]) {
        return {
          compatible: false,
          cliVersion,
          daemonVersion,
          message: `Major version mismatch. CLI: ${cliVersion}, Daemon: ${daemonVersion}. Please update both to the same major version.`
        };
      }

      // Check minor version compatibility (warn if different)
      if (cliParts[1] !== daemonParts[1]) {
        return {
          compatible: true,
          warning: true,
          cliVersion,
          daemonVersion,
          message: `Minor version mismatch. CLI: ${cliVersion}, Daemon: ${daemonVersion}. Consider updating for full compatibility.`
        };
      }

      return {
        compatible: true,
        cliVersion,
        daemonVersion
      };
    } catch (error) {
      // If we can't check version, return with error info
      logger.debug('Failed to check version compatibility:', error.message);
      return {
        compatible: true, // Assume compatible for backward compatibility
        cliVersion,
        daemonVersion: 'unknown',
        error: error.message,
        warning: true,
        message: `Unable to verify daemon version: ${error.message}`
      };
    }
  }

  isDaemonRunning() {
    try {
      if (!existsSync(this.pidFile)) {
        return false;
      }

      const pid = parseInt(readFileSync(this.pidFile, 'utf8'));
      
      // Check if process exists
      process.kill(pid, 0);
      return true;
    } catch (error) {
      return false;
    }
  }

  getDaemonPid() {
    try {
      if (existsSync(this.pidFile)) {
        return parseInt(readFileSync(this.pidFile, 'utf8'));
      }
    } catch (error) {
      // Ignore errors
    }
    return null;
  }

  isServiceInstalled() {
    // Check if systemctl is available first
    try {
      execSync('command -v systemctl', { stdio: 'ignore' });
    } catch (error) {
      // systemctl not available (e.g., pm2-managed or Docker environment)
      return { type: 'none', installed: false };
    }

    try {
      // Check system service
      try {
        execSync(`systemctl is-enabled ${this.serviceName}`, { stdio: ['ignore', 'ignore', 'ignore'] });
        return { type: 'system', installed: true };
      } catch (error) {
        // Check user service
        try {
          execSync(`systemctl --user is-enabled ${this.serviceName}`, { stdio: ['ignore', 'ignore', 'ignore'] });
          return { type: 'user', installed: true };
        } catch (error2) {
          return { type: 'none', installed: false };
        }
      }
    } catch (error) {
      return { type: 'error', installed: false, error: error.message };
    }
  }

  isServiceRunning() {
    // Check if systemctl is available first
    try {
      execSync('command -v systemctl', { stdio: 'ignore' });
    } catch (error) {
      // systemctl not available (e.g., pm2-managed or Docker environment)
      return { type: 'none', running: false, status: 'not-installed' };
    }

    try {
      // Check system service
      try {
        const status = execSync(`systemctl is-active ${this.serviceName}`, {
          encoding: 'utf8',
          stdio: ['ignore', 'pipe', 'ignore']
        }).trim();
        return { type: 'system', running: status === 'active', status };
      } catch (error) {
        // Check user service
        try {
          const status = execSync(`systemctl --user is-active ${this.serviceName}`, {
            encoding: 'utf8',
            stdio: ['ignore', 'pipe', 'ignore']
          }).trim();
          return { type: 'user', running: status === 'active', status };
        } catch (error2) {
          return { type: 'none', running: false, status: 'not-installed' };
        }
      }
    } catch (error) {
      return { type: 'error', running: false, status: 'unknown', error: error.message };
    }
  }

  sendSignal(signal) {
    const pid = this.getDaemonPid();
    if (!pid) {
      throw new Error('Daemon is not running');
    }

    try {
      process.kill(pid, signal);
      return true;
    } catch (error) {
      throw new Error(`Failed to send signal ${signal} to daemon: ${error.message}`);
    }
  }

  async startDaemon() {
    if (this.isDaemonRunning()) {
      logger.warn('Daemon is already running');
      return false;
    }

    // Check if service is installed and running
    const serviceStatus = this.isServiceRunning();
    if (serviceStatus.running) {
      logger.info(`Service is already running (${serviceStatus.type} service)`);
      return true;
    }

    // Check if service is installed but not running
    const serviceInstalled = this.isServiceInstalled();
    if (serviceInstalled.installed) {
      logger.info(`Service is installed but not running. Starting ${serviceInstalled.type} service...`);
      try {
        if (serviceInstalled.type === 'system') {
          execSync(`systemctl start ${this.serviceName}`, { stdio: 'inherit' });
        } else {
          execSync(`systemctl --user start ${this.serviceName}`, { stdio: 'inherit' });
        }
        return true;
      } catch (error) {
        logger.error(`Failed to start ${serviceInstalled.type} service:`, error.message);
        return false;
      }
    }

    // No service installed, start daemon directly
    logger.info('No systemd service installed. Starting daemon directly...');
    try {
      // Start daemon in background
      const { spawn } = await import('child_process');
      const daemonProcess = spawn('node', ['src/daemon-runner.js'], {
        detached: true,
        stdio: 'ignore'
      });

      daemonProcess.unref();

      // Wait a bit for daemon to start
      setTimeout(() => {
        if (this.isDaemonRunning()) {
          logger.info(`Daemon started with PID: ${this.getDaemonPid()}`);
        } else {
          logger.error('Failed to start daemon');
        }
      }, 1000);

      return true;
    } catch (error) {
      logger.error('Failed to start daemon:', error);
      return false;
    }
  }

  stopDaemon() {
    if (!this.isDaemonRunning()) {
      logger.warn('Daemon is not running');
      return false;
    }

    try {
      this.sendSignal('SIGTERM');
      logger.info('Daemon stop signal sent');
      return true;
    } catch (error) {
      logger.error('Failed to stop daemon:', error);
      return false;
    }
  }

  reloadDaemon() {
    if (!this.isDaemonRunning()) {
      throw new Error('Daemon is not running');
    }

    try {
      this.sendSignal('SIGUSR1');
      logger.info('Daemon reload signal sent');
      return true;
    } catch (error) {
      logger.error('Failed to reload daemon:', error);
      return false;
    }
  }

  getDaemonStatus() {
    if (!this.isDaemonRunning()) {
      return { running: false, pid: null };
    }

    try {
      const pid = this.getDaemonPid();
      this.sendSignal('SIGUSR2'); // Request status
      return { running: true, pid };
    } catch (error) {
      return { running: false, pid: null, error: error.message };
    }
  }

  getFullStatus() {
    const daemonRunning = this.isDaemonRunning();
    const serviceInstalled = this.isServiceInstalled();
    const serviceRunning = this.isServiceRunning();

    return {
      daemon: {
        running: daemonRunning,
        pid: daemonRunning ? this.getDaemonPid() : null
      },
      service: {
        installed: serviceInstalled.installed,
        type: serviceInstalled.type,
        running: serviceRunning.running,
        status: serviceRunning.status
      }
    };
  }

  cleanupFailedProcesses(force = false) {
    try {
      // Get failed processes from journalctl
      const journalCmd = 'journalctl -u ani-code.service -n 50 | grep "Failed with result" -A 10 | grep "Unit process" || true';
      const output = execSync(journalCmd, { encoding: 'utf8' });

      if (!output.trim()) {
        return 0;
      }

      let cleanedCount = 0;
      const signal = force ? 'SIGKILL' : 'SIGTERM';
      const lines = output.split('\n').filter(line => line.includes('Unit process'));

      for (const line of lines) {
        // Extract PID from the line
        // Format: "Unit process 12345 (node) remains running after unit stopped"
        const pidMatch = line.match(/process\s+(\d+)/);
        if (pidMatch) {
          const pid = parseInt(pidMatch[1]);
          try {
            // Check if process exists before trying to kill it
            process.kill(pid, 0);
            // Process exists, kill it
            process.kill(pid, signal);
            logger.info(`Cleaned up failed subprocess with PID: ${pid} (${signal})`);
            cleanedCount++;
          } catch (error) {
            // Process doesn't exist or we can't kill it, skip
            if (error.code !== 'ESRCH') {
              logger.warn(`Failed to clean up process ${pid}: ${error.message}`);
            }
          }
        }
      }

      return cleanedCount;
    } catch (error) {
      logger.error('Failed to cleanup failed processes:', error);
      throw error;
    }
  }
}

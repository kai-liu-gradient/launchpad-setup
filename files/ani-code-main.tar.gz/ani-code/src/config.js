import dotenv from 'dotenv';
import { hostname } from 'os';
import path from 'path';
import { fileURLToPath } from 'url';

// Get the directory of this config.js file
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load .env from the ani-code project root directory
const envPath = path.resolve(__dirname, '..', '.env');
dotenv.config({ path: envPath });

// Parse workdirs from comma-separated format: name:path,name:path
function parseWorkdirs(workdirsStr) {
  if (!workdirsStr) return {};
  
  const workdirs = {};
  const pairs = workdirsStr.split(',');
  
  for (const pair of pairs) {
    const [name, path] = pair.trim().split(':');
    if (name && path) {
      workdirs[name.trim()] = path.trim();
    }
  }
  
  return workdirs;
}

export const config = {
  lark: {
    webhookUrl: process.env.LARK_WEBHOOK_URL,
    verificationToken: process.env.LARK_VERIFICATION_TOKEN,
    appId: process.env.LARK_APP_ID,
    appSecret: process.env.LARK_APP_SECRET,
    groupChatId: process.env.LARK_GROUP_CHAT_ID,
    keywordPrefix: process.env.LARK_KEYWORD_PREFIX || null,
    hostname: hostname(),
    workdirs: parseWorkdirs(process.env.LARK_WORKDIRS || ''),
  },
  telegram: {
    botToken: process.env.TELEGRAM_BOT_TOKEN,
    chatId: process.env.TELEGRAM_CHAT_ID,
    useWebhook: process.env.TELEGRAM_USE_WEBHOOK === 'true',
    webhookUrl: process.env.TELEGRAM_WEBHOOK_URL,
    verificationToken: process.env.TELEGRAM_VERIFICATION_TOKEN,
    // Parse allowed chats/users from comma-separated list
    allowedChats: process.env.TELEGRAM_ALLOWED_CHATS ? 
      process.env.TELEGRAM_ALLOWED_CHATS.split(',').map(id => id.trim()) : [],
    // Parse Telegram workdirs same format as Lark
    workdirs: parseWorkdirs(process.env.TELEGRAM_WORKDIRS || process.env.LARK_WORKDIRS || ''),
    // Progress tracking configuration
    progressUpdateInterval: parseInt(process.env.TELEGRAM_PROGRESS_UPDATE_INTERVAL) || 30, // seconds
    progressMaxDuration: parseInt(process.env.TELEGRAM_PROGRESS_MAX_DURATION) || 10, // minutes
  },
  http: {
    // Support multiple env vars with priority: ANI_CODE_DAEMON_PORT > HTTP_CALLBACK_PORT > PORT > default
    port: parseInt(process.env.ANI_CODE_DAEMON_PORT || process.env.HTTP_CALLBACK_PORT || process.env.PORT) || 6501,
    host: process.env.HTTP_CALLBACK_HOST || '0.0.0.0',
  },
  gateway: {
    // New gateway mode configuration
    enabled: process.env.GATEWAY_URL ? true : false,
    url: process.env.GATEWAY_URL,
    // IMPORTANT: Two different token types:
    // 1. apiKey (GATEWAY_API_KEY) - Pre-shared key for authenticating TO the gateway (outbound requests)
    // 2. token (GATEWAY_TOKEN) - Gateway-generated token for validating requests FROM the gateway (inbound requests)

    // Gateway-generated token for validating incoming requests FROM gateway
    // This is set by the gateway during registration and persisted via gatewayState
    // The gatewayState.setGatewayToken() also sets process.env.GATEWAY_TOKEN for runtime access
    get token() {
      return process.env.GATEWAY_TOKEN;
    },
    // API key for authenticating TO the gateway (registration, heartbeat, etc.)
    apiKey: process.env.GATEWAY_API_KEY,
    instanceId: process.env.INSTANCE_ID || hostname(),
    registerOnStartup: process.env.GATEWAY_REGISTER !== 'false',
    // Legacy configuration (backward compatibility)
    callbackUrl: process.env.GATEWAY_URL,
    workspaceId: process.env.WORKSPACE_ID,
    projectId: process.env.PROJECT_ID,
    retryAttempts: parseInt(process.env.GATEWAY_RETRY_ATTEMPTS) || 3,
    retryBaseDelay: parseInt(process.env.GATEWAY_RETRY_BASE_DELAY) || 1000, // 1 second
    // HMAC signing key for callback requests (Goal 269 - Security Hardening)
    // This key is used to sign outbound callback requests for signature validation
    signingKey: process.env.PROJECT_GATEWAY_KEY || null,
  },
  tasks: {
    maxConcurrent: parseInt(process.env.MAX_CONCURRENT_TASKS) || 3,
    timeoutMs: parseInt(process.env.TASK_TIMEOUT_MS) || 3600000, // 1 hour (60 minutes)
    stuckDetectionMs: parseInt(process.env.TASK_STUCK_DETECTION_MS) || 3600000, // 1 hour - effectively disabled for Claude
    // Fatal error timeout - kill process faster when unrecoverable errors are detected
    fatalErrorTimeout: {
      enabled: process.env.TASK_FATAL_ERROR_TIMEOUT_ENABLED !== 'false', // enabled by default
      timeoutMs: parseInt(process.env.TASK_FATAL_ERROR_TIMEOUT_MS) || 300000, // 5 minutes after fatal error
      patterns: [
        'Error: No messages returned',
        'unhandled promise rejection',
        'UnhandledPromiseRejection',
        'FATAL ERROR',
        'heap out of memory',
        'JavaScript heap out of memory',
      ],
    },
    // Stale detection for Claude tasks - detect repeated error patterns
    staleDetection: {
      enabled: process.env.TASK_STALE_DETECTION_ENABLED !== 'false', // enabled by default
      minRunTimeMs: parseInt(process.env.TASK_STALE_MIN_RUNTIME_MS) || 300000, // 5 minutes minimum run time
      repeatThreshold: parseInt(process.env.TASK_STALE_REPEAT_THRESHOLD) || 20, // 20 repeated messages
      checkIntervalMs: parseInt(process.env.TASK_STALE_CHECK_INTERVAL_MS) || 30000, // check every 30 seconds
      errorPatterns: [
        'Error: This command requires approval',
        'permission denied',
        'access denied',
        'EACCES',
        'EPERM',
      ],
    },
  },
  logging: {
    level: process.env.LOG_LEVEL || 'info',
  },
  unmanagedTaskDetection: {
    enabled: process.env.UNMANAGED_TASK_DETECTION_ENABLED === 'true',
    insertStats: process.env.UNMANAGED_TASK_INSERT_STATS === 'true',
    scanIntervalMs: parseInt(process.env.UNMANAGED_TASK_SCAN_INTERVAL_MS) || 60000,
    settleTimeMs: parseInt(process.env.UNMANAGED_TASK_SETTLE_TIME_MS) || 300000,
  },
  timezone: process.env.TIMEZONE || 'Asia/Shanghai',
};

export function validateConfig() {
  // Check if at least one notification method is configured
  const hasLarkWebhook = !!config.lark.webhookUrl;
  const hasLarkAPI = !!(config.lark.appId && config.lark.appSecret && config.lark.groupChatId);
  const hasTelegram = !!config.telegram.botToken;

  // Allow DUMMY mode for gateway control without actual notification services
  const isDummyMode = process.env.ANI_CODE_DUMMY_MODE === 'true' ||
                      process.env.TELEGRAM_BOT_TOKEN === 'DUMMY';

  if (!hasLarkWebhook && !hasLarkAPI && !hasTelegram && !isDummyMode) {
    throw new Error('At least one notification method is required: Lark (webhook/API) or Telegram bot token. Set ANI_CODE_DUMMY_MODE=true or TELEGRAM_BOT_TOKEN=DUMMY for gateway-only operation.');
  }
}
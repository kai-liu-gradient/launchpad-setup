import { execSync, spawn } from 'child_process';
import { existsSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

/**
 * Get Claude API usage information
 * @returns {Promise<Object>} Usage data with session, week, and plan info
 */
export async function getClaudeUsage() {
  const expectScript = join(__dirname, '../expect/claude_get_usage.expect');

  // Check if expect script exists
  if (!existsSync(expectScript)) {
    throw new Error(`Expect script not found: ${expectScript}`);
  }

  // Run expect script using spawn with promise wrapper
  const output = await new Promise((resolve, reject) => {
    let stdout = '';
    let stderr = '';
    let hasResolved = false;
    let timeoutId = null;

    const child = spawn(expectScript, [], {
      timeout: 90000,  // Increased timeout to 90 seconds (expect script waits up to 40s for data)
      killSignal: 'SIGTERM'
    });

    child.stdout.on('data', (data) => {
      stdout += data.toString();
    });

    child.stderr.on('data', (data) => {
      stderr += data.toString();
    });

    child.on('close', (code) => {
      if (hasResolved) return;
      hasResolved = true;

      // Clear timeout
      if (timeoutId) {
        clearTimeout(timeoutId);
      }

      // If we got usage data in stdout, consider it success even if exit code != 0
      // Check for "used" which appears in "X% used" - more reliable than "Current"
      // since Claude CLI may embed ANSI cursor codes within words
      if (stdout.includes('used') || stdout.includes('ession') || stdout.includes('eek')) {
        resolve(stdout);
      } else if (code === 143) {
        // Exit code 143 is SIGTERM (timeout)
        reject(new Error(`Expect script timed out after 90 seconds`));
      } else if (code !== 0) {
        reject(new Error(`Expect script failed with code ${code}: ${stderr}`));
      } else {
        resolve(stdout);
      }
    });

    child.on('error', (err) => {
      if (hasResolved) return;
      hasResolved = true;

      if (timeoutId) {
        clearTimeout(timeoutId);
      }
      reject(err);
    });

    // Kill after timeout
    timeoutId = setTimeout(() => {
      if (!hasResolved && !child.killed) {
        hasResolved = true;
        child.kill('SIGTERM');
        reject(new Error('Expect script timed out after 90 seconds'));
      }
    }, 90000);  // 90 second timeout
  });

  // Strip ANSI escape codes from text (color, cursor movement, etc.)
  // Claude CLI v2.x uses cursor movement codes (\x1b[1C) between words and sometimes
  // within words. Replace all CSI sequences with a space, then normalize.
  const stripAnsi = (str) => str
    .replace(/\x1b\[\??[0-9;]*[A-Za-z]/g, ' ') // All CSI sequences (cursor, color, mode) → space
    .replace(/\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)/g, '') // OSC sequences (window title)
    .replace(/\x1b\[<[a-z]/g, '')             // Mouse/keyboard mode sequences
    .replace(/\x1b[()][0-9A-Za-z]/g, '')      // Character set sequences
    .replace(/[\u2580-\u259F]/g, '')           // Box drawing/block characters
    .replace(/[▀-▟]/g, '')                     // Block elements
    .replace(/[█▓░▌▐]/g, '')                   // Progress bar characters
    .replace(/\r/g, '')                         // Carriage returns
    .replace(/\s+/g, ' ')                       // Normalize whitespace
    .trim();

  // Parse the output to extract usage information
  // Strip ANSI codes from each line before matching - Claude CLI v2.x embeds
  // cursor movement codes (\x1b[1C, \x1b[2C) between characters
  const rawLines = output.split('\n');
  const lines = rawLines.map(stripAnsi);

  // Look for key information patterns
  let currentSession = null;
  let weekAllModels = null;
  let weekOpus = null;
  let currentPlan = null;
  let sessionResetTime = null;
  let weekAllModelsResetTime = null;
  let weekOpusResetTime = null;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    // Match "Current session" - ANSI stripping may leave spaces/missing chars within words
    // e.g., "Curre t session" or "Current session"
    if (line.match(/session/i) && line.match(/curr/i)) {
      // Check same line first, then next lines for percentage
      for (let j = i; j <= i + 2 && j < lines.length; j++) {
        if (currentSession === null) {
          const match = lines[j].match(/(\d+)\s*%\s*used/i);
          if (match) currentSession = parseInt(match[1]);
        }
      }
      // Look for reset time in next few lines
      // Pattern handles garbled "Resets" (e.g., "Rese s", "Reses") and both date/duration formats
      for (let j = i; j <= i + 3 && j < lines.length; j++) {
        if (sessionResetTime === null) {
          const resetMatch = lines[j].match(/Rese[ts\s]*\s+(.+?)(?:\s*$)/i);
          if (resetMatch) {
            sessionResetTime = resetMatch[1].trim();
          }
        }
      }
    }

    // Match "Current week (all models)"
    if (line.match(/week.*all\s*models/i)) {
      for (let j = i; j <= i + 2 && j < lines.length; j++) {
        if (weekAllModels === null) {
          const match = lines[j].match(/(\d+)\s*%\s*used/i);
          if (match) weekAllModels = parseInt(match[1]);
        }
      }
      for (let j = i; j <= i + 3 && j < lines.length; j++) {
        if (weekAllModelsResetTime === null) {
          const resetMatch = lines[j].match(/Rese[ts\s]*\s+(.+?)(?:\s*$)/i);
          if (resetMatch) {
            weekAllModelsResetTime = resetMatch[1].trim();
          }
        }
      }
    }

    // Match "Current week (Opus)" or "Current week (Sonnet only)"
    if (line.match(/week.*(opus|sonnet)/i)) {
      for (let j = i; j <= i + 2 && j < lines.length; j++) {
        if (weekOpus === null) {
          const match = lines[j].match(/(\d+)\s*%\s*used/i);
          if (match) weekOpus = parseInt(match[1]);
        }
      }
      for (let j = i; j <= i + 3 && j < lines.length; j++) {
        if (weekOpusResetTime === null) {
          const resetMatch = lines[j].match(/Rese[ts\s]*\s+(.+?)(?:\s*$)/i);
          if (resetMatch) {
            weekOpusResetTime = resetMatch[1].trim();
          }
        }
      }
    }

    // Match plan information (e.g., "Opus 4.6 · Claude Max")
    if (line.match(/claude\s+(?:max|pro|free)/i)) {
      const match = line.match(/(.+?claude\s+(?:max|pro|free))/i);
      if (match) {
        currentPlan = match[1]
          .trim()
          .replace(/\bMax\b/g, 'Maximum')
          .replace(/\bPro\b/g, 'Professional')
          .replace(/\bFree\b/g, 'Free')
          .replace(/\bClaude\s+/g, '');
      }
    }
  }

  // Calculate reset information for different metrics
  const sessionResetInfo = calculateResetInfo(currentSession, sessionResetTime, 'session');
  const weekAllModelsResetInfo = calculateResetInfo(weekAllModels, weekAllModelsResetTime, 'week');
  const weekOpusResetInfo = calculateResetInfo(weekOpus, weekOpusResetTime, 'week');

  return {
    currentSession,
    weekAllModels,
    weekOpus,
    currentPlan,
    sessionResetTime,
    weekAllModelsResetTime,
    weekOpusResetTime,
    sessionResetInfo,
    weekAllModelsResetInfo,
    weekOpusResetInfo,
    // Keep backward compatibility
    resetInfo: weekOpusResetInfo,
    rawOutput: output
  };
}

/**
 * Calculate reset timing and remaining resets based on current usage
 * @param {number|null} usagePercent - Current usage percentage
 * @param {string|null} resetTimeStr - Reset time string from Claude CLI (e.g., "Oct 16, 8:59am (UTC)")
 * @param {string} resetType - Type of reset period: 'session' or 'week'
 * @returns {Object} Reset information with timing and forecast
 */
function calculateResetInfo(usagePercent, resetTimeStr, resetType = 'week') {
  const now = new Date();

  // If no usage data, return null
  if (usagePercent === null) {
    return null;
  }

  // Parse the reset time from the actual output
  let nextReset = null;
  let resetTimeDisplay = resetTimeStr;

  if (resetTimeStr) {
    try {
      // Parse formats like:
      // - "Oct 16, 12am (UTC)" - date format without year
      // - "Jan 1, 2026, 2:59pm (UTC)" - date format with year
      // - "7 m (UTC)" or "2 h 30 m" - duration format (session resets)
      const cleanTime = resetTimeStr.replace(/\(UTC\)/i, '').trim();
      const currentYear = now.getUTCFullYear();

      // Try duration format first: "Xh", "Xm", "Xh Ym" (with possible spaces from ANSI stripping)
      const durationMatch = cleanTime.match(/^(?:(\d+)\s*h)?\s*(?:(\d+)\s*m)?$/i);
      if (durationMatch && (durationMatch[1] || durationMatch[2])) {
        const durationHours = durationMatch[1] ? parseInt(durationMatch[1]) : 0;
        const durationMinutes = durationMatch[2] ? parseInt(durationMatch[2]) : 0;
        const totalMs = (durationHours * 60 + durationMinutes) * 60 * 1000;
        nextReset = new Date(now.getTime() + totalMs);
        resetTimeDisplay = `${durationHours > 0 ? durationHours + 'h ' : ''}${durationMinutes}m`;
      }

      const monthMap = {
        Jan: 0, Feb: 1, Mar: 2, Apr: 3, May: 4, Jun: 5,
        Jul: 6, Aug: 7, Sep: 8, Oct: 9, Nov: 10, Dec: 11
      };

      let month, day, year, hour, minute;

      if (nextReset) {
        // Duration was parsed, skip date parsing
      } else {

      // Try new format first: "Month Day, Year, Hour:Minute[am/pm]"
      // Example: "Jan 1, 2026, 2:59pm"
      const newFormatMatch = cleanTime.match(/([A-Za-z]+)\s+(\d+),\s*(\d{4}),\s*(\d+):?(\d*)?(am|pm)/i);

      if (newFormatMatch) {
        month = monthMap[newFormatMatch[1]];
        day = parseInt(newFormatMatch[2]);
        year = parseInt(newFormatMatch[3]);
        hour = parseInt(newFormatMatch[4]);
        minute = newFormatMatch[5] ? parseInt(newFormatMatch[5]) : 0;
        const ampm = newFormatMatch[6];

        // Handle AM/PM conversion
        if (ampm) {
          if (ampm.toLowerCase() === 'pm' && hour !== 12) {
            hour += 12;
          } else if (ampm.toLowerCase() === 'am' && hour === 12) {
            hour = 0;
          }
        }

        nextReset = new Date(Date.UTC(year, month, day, hour, minute, 0));
      } else {
        // Try old format: "Month Day, Hour[am/pm]" or "Month Day, Hour:Minute[am/pm]"
        // Example: "Oct 16, 12am" or "Oct 16, 9:30am"
        const oldFormatMatch = cleanTime.match(/([A-Za-z]+)\s+(\d+),?\s*(\d+):?(\d*)?(am|pm)?/i);

        if (oldFormatMatch) {
          month = monthMap[oldFormatMatch[1]];
          day = parseInt(oldFormatMatch[2]);
          hour = parseInt(oldFormatMatch[3]);
          minute = oldFormatMatch[4] ? parseInt(oldFormatMatch[4]) : 0;
          const ampm = oldFormatMatch[5];

          // Handle AM/PM conversion
          if (ampm) {
            if (ampm.toLowerCase() === 'pm' && hour !== 12) {
              hour += 12;
            } else if (ampm.toLowerCase() === 'am' && hour === 12) {
              hour = 0;
            }
          }

          nextReset = new Date(Date.UTC(currentYear, month, day, hour, minute, 0));

          // If the parsed date is in the past, it's probably next year
          if (nextReset < now) {
            nextReset = new Date(Date.UTC(currentYear + 1, month, day, hour, minute, 0));
          }
        } else {
          throw new Error('Could not parse reset time format');
        }
      }
      } // end duration/date else block
    } catch (e) {
      // If parsing fails, fall back to calculating Monday 00:00 UTC
      const dayOfWeek = now.getUTCDay();
      const daysUntilMonday = dayOfWeek === 0 ? 1 : (8 - dayOfWeek) % 7;
      nextReset = new Date(now);
      nextReset.setUTCDate(now.getUTCDate() + daysUntilMonday);
      nextReset.setUTCHours(0, 0, 0, 0);
      resetTimeDisplay = nextReset.toUTCString();
    }
  } else {
    // Fallback: Calculate next Monday 00:00 UTC
    const dayOfWeek = now.getUTCDay();
    const daysUntilMonday = dayOfWeek === 0 ? 1 : (8 - dayOfWeek) % 7;
    nextReset = new Date(now);
    nextReset.setUTCDate(now.getUTCDate() + daysUntilMonday);
    nextReset.setUTCHours(0, 0, 0, 0);
    resetTimeDisplay = nextReset.toUTCString();
  }

  const msUntilReset = nextReset - now;
  const hoursUntilReset = Math.floor(msUntilReset / (1000 * 60 * 60));
  const minutesUntilReset = Math.floor((msUntilReset % (1000 * 60 * 60)) / (1000 * 60));
  const daysUntilReset = Math.floor(hoursUntilReset / 24);

  // Determine the total period hours based on reset type
  let totalPeriodHours;
  if (resetType === 'session') {
    // Session is typically 5 hours according to Claude API
    totalPeriodHours = 5;
  } else {
    // Week is 7 days = 168 hours
    totalPeriodHours = 7 * 24;
  }

  // Calculate time elapsed in current period
  const hoursIntoPeriod = totalPeriodHours - hoursUntilReset;
  const percentTimeElapsed = (hoursIntoPeriod / totalPeriodHours) * 100;

  // Calculate remaining time as percentage
  const percentTimeRemaining = 100 - percentTimeElapsed;

  // Calculate usage velocity (how much faster/slower than time)
  // If we've used 80% but only 40% time has passed, velocity = 80/40 = 2x (using 2x faster than time)
  // If we've used 20% and 40% time has passed, velocity = 20/40 = 0.5x (using half as fast as time)
  let usageVelocity = null;
  if (percentTimeElapsed > 0) {
    usageVelocity = usagePercent / percentTimeElapsed;
  }

  // Calculate remaining resets based on usage rate
  let remainingResets = null;
  let usageRate = null;
  let projectedUsage = null;

  if (usagePercent !== null && usagePercent > 0 && hoursIntoPeriod > 0) {
    // Usage rate: percentage per hour
    usageRate = usagePercent / hoursIntoPeriod;

    // Project usage for full period
    projectedUsage = usageRate * totalPeriodHours;

    // Calculate how many resets we can afford at this rate
    // Each reset gives us 100% more capacity
    if (projectedUsage > 100) {
      // If we use more than 100% per period, calculate how many more periods we can sustain
      // Formula: remaining capacity / excess usage per period
      remainingResets = Math.floor(100 / (projectedUsage - 100));
    } else {
      // If we're projected to use less than 100%, we have infinite resets available
      remainingResets = Infinity;
    }
  }

  return {
    nextResetDate: nextReset.toISOString(),
    resetTimeDisplay, // Original reset time string from CLI
    hoursUntilReset,
    minutesUntilReset,
    daysUntilReset,
    percentTimeElapsed: Math.round(percentTimeElapsed),
    percentTimeRemaining: Math.round(percentTimeRemaining),
    usagePercent,
    usageVelocity: usageVelocity ? usageVelocity.toFixed(2) : null,
    usageRate,
    projectedUsage: projectedUsage ? Math.round(projectedUsage) : null,
    remainingResets,
    resetType
  };
}

/**
 * Helper function to format reset information
 * @param {Object} resetInfo - Reset info object
 * @returns {Array<string>} Formatted lines
 */
function formatResetInfo(resetInfo) {
  const lines = [];

  // Show the actual reset time from CLI
  if (resetInfo.resetTimeDisplay) {
    const days = resetInfo.daysUntilReset;
    const hours = resetInfo.hoursUntilReset % 24;
    const minutes = resetInfo.minutesUntilReset;
    const dayText = days === 1 ? 'day' : 'days';
    const hourText = hours === 1 ? 'hour' : 'hours';
    const minuteText = minutes === 1 ? 'minute' : 'minutes';
    const timeStr = days > 0 ? `${days} ${dayText} ${hours} ${hourText}` : `${hours} ${hourText} ${minutes} ${minuteText}`;
    lines.push(`   Next: ${resetInfo.resetTimeDisplay} (in ${timeStr})`);
  } else {
    const days = resetInfo.daysUntilReset;
    const hours = resetInfo.hoursUntilReset % 24;
    const minutes = resetInfo.minutesUntilReset;
    const dayText = days === 1 ? 'day' : 'days';
    const hourText = hours === 1 ? 'hour' : 'hours';
    const minuteText = minutes === 1 ? 'minute' : 'minutes';
    const timeStr = days > 0 ? `${days} ${dayText} ${hours} ${hourText}` : `${hours} ${hourText} ${minutes} ${minuteText}`;
    lines.push(`   Next: ${timeStr}`);
  }

  // Show usage velocity comparison
  if (resetInfo.usageVelocity !== null) {
    const velocity = parseFloat(resetInfo.usageVelocity);
    let velocityEmoji;
    let velocityDesc;

    if (velocity >= 2.0) {
      velocityEmoji = '🔴';
      velocityDesc = `${velocity.toFixed(1)}x faster than time`;
    } else if (velocity >= 1.5) {
      velocityEmoji = '🟡';
      velocityDesc = `${velocity.toFixed(1)}x faster than time`;
    } else if (velocity >= 1.0) {
      velocityEmoji = '🟡';
      velocityDesc = `${velocity.toFixed(1)}x (on pace)`;
    } else {
      velocityEmoji = '🟢';
      velocityDesc = `${velocity.toFixed(1)}x (under pace)`;
    }

    lines.push(`   ${velocityEmoji} Usage velocity: ${velocityDesc}`);
    lines.push(`   Time remaining: ${resetInfo.percentTimeRemaining}% (${resetInfo.usagePercent}% used)`);
  }

  // Show remaining resets
  if (resetInfo.remainingResets !== null) {
    if (resetInfo.remainingResets === Infinity) {
      lines.push(`   Sustainable: ∞ resets available`);
    } else {
      const resetsEmoji = resetInfo.remainingResets === 0 ? '⚠️' :
                         resetInfo.remainingResets <= 2 ? '🟡' : '🟢';
      lines.push(`   ${resetsEmoji} Resets remaining at current rate: ${resetInfo.remainingResets}`);

      if (resetInfo.projectedUsage) {
        lines.push(`   Projected usage: ${resetInfo.projectedUsage}%`);
      }
    }
  }

  return lines;
}

/**
 * Format usage data as plain text with enhanced table format
 * @param {Object} usage - Usage data from getClaudeUsage()
 * @returns {string} Formatted text
 */
export async function formatUsageText(usage) {
  const lines = [];

  lines.push('```');
  lines.push('CLAUDE API USAGE');
  lines.push('═'.repeat(50));

  // Plan information
  if (usage.currentPlan) {
    lines.push(`Plan: ${usage.currentPlan}`);
    lines.push('');
  }

  // Usage percentages in table format
  lines.push('USAGE METRICS');
  lines.push('─'.repeat(50));

  if (usage.currentSession !== null) {
    const icon = usage.currentSession > 80 ? '!!' : usage.currentSession > 60 ? '! ' : '  ';
    const bar = createProgressBar(usage.currentSession, 30);
    lines.push(`${icon}Session:     ${usage.currentSession.toString().padStart(3)}% ${bar}`);

    if (usage.sessionResetInfo) {
      const resetInfo = usage.sessionResetInfo;
      const hours = resetInfo.hoursUntilReset;
      const minutes = resetInfo.minutesUntilReset;

      // Handle negative times (already expired)
      if (hours < 0 || minutes < 0) {
        lines.push(`  └─ Resets: Expired (refresh pending)`);
      } else {
        const hourText = hours === 1 ? 'hour' : 'hours';
        const minuteText = minutes === 1 ? 'minute' : 'minutes';
        lines.push(`  └─ Resets: ${hours} ${hourText} ${minutes} ${minuteText}`);
      }
    }
  }

  if (usage.weekAllModels !== null) {
    const icon = usage.weekAllModels > 80 ? '!!' : usage.weekAllModels > 60 ? '! ' : '  ';
    const bar = createProgressBar(usage.weekAllModels, 30);
    lines.push(`${icon}Week (All):  ${usage.weekAllModels.toString().padStart(3)}% ${bar}`);

    if (usage.weekAllModelsResetInfo) {
      const resetInfo = usage.weekAllModelsResetInfo;
      const days = resetInfo.daysUntilReset;
      const hours = resetInfo.hoursUntilReset % 24;
      const minutes = resetInfo.minutesUntilReset;
      const dayText = days === 1 ? 'day' : 'days';
      const hourText = hours === 1 ? 'hour' : 'hours';
      const minuteText = minutes === 1 ? 'minute' : 'minutes';

      let timeStr;
      if (days > 0) {
        timeStr = `${days} ${dayText} ${hours} ${hourText}`;
      } else if (hours > 0) {
        timeStr = `${hours} ${hourText} ${minutes} ${minuteText}`;
      } else {
        timeStr = `${minutes} ${minuteText}`;
      }

      lines.push(`  └─ Resets: ${timeStr}`);
    }
  }

  if (usage.weekOpus !== null) {
    const icon = usage.weekOpus > 80 ? '!!' : usage.weekOpus > 60 ? '! ' : '  ';
    const bar = createProgressBar(usage.weekOpus, 30);
    lines.push(`${icon}Week (Opus): ${usage.weekOpus.toString().padStart(3)}% ${bar}`);

    if (usage.weekOpusResetInfo) {
      const resetInfo = usage.weekOpusResetInfo;
      const days = resetInfo.daysUntilReset;
      const hours = resetInfo.hoursUntilReset % 24;
      const minutes = resetInfo.minutesUntilReset;
      const dayText = days === 1 ? 'day' : 'days';
      const hourText = hours === 1 ? 'hour' : 'hours';
      const minuteText = minutes === 1 ? 'minute' : 'minutes';

      let timeStr;
      if (days > 0) {
        timeStr = `${days} ${dayText} ${hours} ${hourText}`;
      } else if (hours > 0) {
        timeStr = `${hours} ${hourText} ${minutes} ${minuteText}`;
      } else {
        timeStr = `${minutes} ${minuteText}`;
      }

      lines.push(`  ├─ Resets: ${timeStr}`);

      // Add velocity and projection info
      if (resetInfo.usageVelocity !== null) {
        const velocity = parseFloat(resetInfo.usageVelocity);
        let velocityIcon = '🟢';
        if (velocity >= 2.0) velocityIcon = '🔴';
        else if (velocity >= 1.5) velocityIcon = '🟡';

        lines.push(`  ├─ Velocity: ${velocity.toFixed(1)}x ${velocityIcon}`);
      }

      // Add depletion estimate if over-consuming
      if (resetInfo.projectedUsage && resetInfo.projectedUsage > 100) {
        const usageRate = usage.weekOpus / resetInfo.percentTimeElapsed * 100;
        const daysUntilDepleted = Math.floor((100 - usage.weekOpus) / (usageRate / 24));
        const hoursUntilDepleted = Math.floor(((100 - usage.weekOpus) / (usageRate / 24) % 1) * 24);
        const depleteDayText = daysUntilDepleted === 1 ? 'day' : 'days';
        const depleteHourText = hoursUntilDepleted === 1 ? 'hour' : 'hours';
        lines.push(`  └─ Estimated Depletion: ${daysUntilDepleted} ${depleteDayText} ${hoursUntilDepleted} ${depleteHourText} ⚠️`);
      } else if (resetInfo.projectedUsage) {
        lines.push(`  └─ Projected: ${resetInfo.projectedUsage}%`);
      }
    }
  }

  // Add task/cost stats for current window
  try {
    const { getStatsDB } = await import('./stats-db.js');
    const statsDB = getStatsDB();

    // Calculate time window based on reset time
    let windowStart = new Date();
    if (usage.weekOpusResetInfo && usage.weekOpusResetInfo.nextResetDate) {
      const nextReset = new Date(usage.weekOpusResetInfo.nextResetDate);
      // Go back 7 days from next reset to get window start
      windowStart = new Date(nextReset.getTime() - 7 * 24 * 60 * 60 * 1000);
    } else {
      // Fallback: last 7 days
      windowStart.setDate(windowStart.getDate() - 7);
    }

    // Get stats for the window
    const windowStats = await statsDB.getTaskStats(windowStart, new Date());
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const todayStats = await statsDB.getTaskStats(todayStart, new Date());

    if (windowStats && todayStats) {
      lines.push('');
      lines.push('TASK & COST STATISTICS');
      lines.push('─'.repeat(50));

      const windowCost = windowStats.totalCost || 0;
      const todayCost = todayStats.totalCost || 0;
      const windowTasks = windowStats.totalTasks || 0;
      const todayTasks = todayStats.totalTasks || 0;

      const windowTaskText = windowTasks === 1 ? 'task' : 'tasks';
      const todayTaskText = todayTasks === 1 ? 'task' : 'tasks';
      lines.push(`Window (7 days): ${windowTasks.toString().padStart(4)} ${windowTaskText} │ $${windowCost.toFixed(2).padStart(7)}`);
      lines.push(`Today:           ${todayTasks.toString().padStart(4)} ${todayTaskText} │ $${todayCost.toFixed(2).padStart(7)}`);
    }
  } catch (error) {
    // Silently skip stats if not available
  }

  if (usage.currentSession === null && usage.weekAllModels === null &&
      usage.weekOpus === null && !usage.currentPlan) {
    lines.push('Could not parse usage data');
  }

  lines.push('═'.repeat(50));
  lines.push('```');

  return lines.join('\n');
}

/**
 * Create a simple ASCII progress bar
 * @param {number} percent - Progress percentage (0-100)
 * @param {number} width - Bar width in characters
 * @returns {string} ASCII progress bar
 */
function createProgressBar(percent, width = 30) {
  const filled = Math.round((percent / 100) * width);
  const empty = width - filled;

  // Choose color/style based on percentage
  let bar;
  if (percent >= 90) {
    bar = '█'.repeat(filled) + '░'.repeat(empty);
  } else if (percent >= 70) {
    bar = '▓'.repeat(filled) + '░'.repeat(empty);
  } else {
    bar = '▓'.repeat(filled) + '░'.repeat(empty);
  }

  return `[${bar}]`;
}

/**
 * Helper function to format reset information for Markdown
 * @param {Object} resetInfo - Reset info object
 * @returns {Array<string>} Formatted lines
 */
function formatResetInfoMarkdown(resetInfo) {
  const lines = [];

  // Show the actual reset time from CLI
  if (resetInfo.resetTimeDisplay) {
    const days = resetInfo.daysUntilReset;
    const hours = resetInfo.hoursUntilReset % 24;
    const minutes = resetInfo.minutesUntilReset;
    const dayText = days === 1 ? 'day' : 'days';
    const hourText = hours === 1 ? 'hour' : 'hours';
    const minuteText = minutes === 1 ? 'minute' : 'minutes';
    const timeStr = days > 0 ? `${days} ${dayText} ${hours} ${hourText}` : `${hours} ${hourText} ${minutes} ${minuteText}`;
    lines.push(`- **Next reset:** ${resetInfo.resetTimeDisplay} (in ${timeStr})`);
  } else {
    const days = resetInfo.daysUntilReset;
    const hours = resetInfo.hoursUntilReset % 24;
    const minutes = resetInfo.minutesUntilReset;
    const dayText = days === 1 ? 'day' : 'days';
    const hourText = hours === 1 ? 'hour' : 'hours';
    const minuteText = minutes === 1 ? 'minute' : 'minutes';
    const timeStr = days > 0 ? `${days} ${dayText} ${hours} ${hourText}` : `${hours} ${hourText} ${minutes} ${minuteText}`;
    lines.push(`- **Next reset:** ${timeStr}`);
  }

  // Show usage velocity comparison
  if (resetInfo.usageVelocity !== null) {
    const velocity = parseFloat(resetInfo.usageVelocity);
    let velocityEmoji;
    let velocityDesc;

    if (velocity >= 2.0) {
      velocityEmoji = '🔴';
      velocityDesc = `${velocity.toFixed(1)}x faster than time`;
    } else if (velocity >= 1.5) {
      velocityEmoji = '🟡';
      velocityDesc = `${velocity.toFixed(1)}x faster than time`;
    } else if (velocity >= 1.0) {
      velocityEmoji = '🟡';
      velocityDesc = `${velocity.toFixed(1)}x (on pace)`;
    } else {
      velocityEmoji = '🟢';
      velocityDesc = `${velocity.toFixed(1)}x (under pace)`;
    }

    lines.push(`- ${velocityEmoji} **Usage velocity:** ${velocityDesc}`);
    lines.push(`- **Time remaining:** ${resetInfo.percentTimeRemaining}% (${resetInfo.usagePercent}% used)`);
  }

  // Show remaining resets
  if (resetInfo.remainingResets !== null) {
    if (resetInfo.remainingResets === Infinity) {
      lines.push(`- **Sustainable:** ∞ resets available`);
    } else {
      const resetsEmoji = resetInfo.remainingResets === 0 ? '⚠️' :
                         resetInfo.remainingResets <= 2 ? '🟡' : '🟢';
      lines.push(`- ${resetsEmoji} **Resets remaining at current rate:** ${resetInfo.remainingResets}`);

      if (resetInfo.projectedUsage) {
        lines.push(`- **Projected usage:** ${resetInfo.projectedUsage}%`);
      }
    }
  }

  return lines;
}

/**
 * Format usage data as Markdown
 * @param {Object} usage - Usage data from getClaudeUsage()
 * @returns {string} Formatted markdown
 */
export async function formatUsageMarkdown(usage) {
  const lines = [];

  lines.push('```');

  if (usage.currentPlan) {
    lines.push(`Plan: ${usage.currentPlan}`);
    lines.push('');
  }

  // Compact format: all on one line
  const parts = [];
  if (usage.currentSession !== null) {
    const icon = usage.currentSession > 80 ? '!!' : usage.currentSession > 60 ? '!' : '';
    parts.push(`Session:${icon}${usage.currentSession}%`);
  }
  if (usage.weekAllModels !== null) {
    const icon = usage.weekAllModels > 80 ? '!!' : usage.weekAllModels > 60 ? '!' : '';
    parts.push(`Week (All):${icon}${usage.weekAllModels}%`);
  }
  if (usage.weekOpus !== null) {
    const icon = usage.weekOpus > 80 ? '!!' : usage.weekOpus > 60 ? '!' : '';
    parts.push(`Opus:${icon}${usage.weekOpus}%`);
  }

  if (parts.length > 0) {
    lines.push(parts.join(' | '));
  }

  // Show separate reset times for Week (All) and Opus
  lines.push(''); // Empty line for separation

  // Week (All Models) reset time
  if (usage.weekAllModelsResetInfo && usage.weekAllModels !== null) {
    const resetInfo = usage.weekAllModelsResetInfo;
    const days = resetInfo.daysUntilReset;
    const hours = resetInfo.hoursUntilReset % 24;
    const minutes = resetInfo.minutesUntilReset;
    const dayText = days === 1 ? 'day' : 'days';
    const hourText = hours === 1 ? 'hour' : 'hours';
    const minuteText = minutes === 1 ? 'minute' : 'minutes';

    let timeStr;
    if (days > 0) {
      timeStr = `${days} ${dayText} ${hours} ${hourText}`;
    } else if (hours > 0) {
      timeStr = `${hours} ${hourText} ${minutes} ${minuteText}`;
    } else {
      timeStr = `${minutes} ${minuteText}`;
    }

    lines.push(`Week (All) resets: ${timeStr}`);
  }

  // Opus reset time - separate line for clarity
  if (usage.weekOpusResetInfo && usage.weekOpus !== null) {
    const resetInfo = usage.weekOpusResetInfo;
    const days = resetInfo.daysUntilReset;
    const hours = resetInfo.hoursUntilReset % 24;
    const minutes = resetInfo.minutesUntilReset;
    const dayText = days === 1 ? 'day' : 'days';
    const hourText = hours === 1 ? 'hour' : 'hours';
    const minuteText = minutes === 1 ? 'minute' : 'minutes';

    let timeStr;
    if (days > 0) {
      timeStr = `${days} ${dayText} ${hours} ${hourText}`;
    } else if (hours > 0) {
      timeStr = `${hours} ${hourText} ${minutes} ${minuteText}`;
    } else {
      timeStr = `${minutes} ${minuteText}`;
    }

    let resetLine = `Opus resets: ${timeStr}`;

    // Add depletion estimate if needed
    if (resetInfo.projectedUsage && resetInfo.projectedUsage > 100) {
      const usageRate = usage.weekOpus / resetInfo.percentTimeElapsed * 100;
      const daysUntilDepleted = Math.floor((100 - usage.weekOpus) / (usageRate / 24));
      const hoursUntilDepleted = Math.floor(((100 - usage.weekOpus) / (usageRate / 24) % 1) * 24);
      const depleteDayText = daysUntilDepleted === 1 ? 'day' : 'days';
      const depleteHourText = hoursUntilDepleted === 1 ? 'hour' : 'hours';
      resetLine += ` | Depletes: ${daysUntilDepleted} ${depleteDayText} ${hoursUntilDepleted} ${depleteHourText}`;
    }

    lines.push(resetLine);
  }

  // Add task/cost stats for current window
  try {
    const { getStatsDB } = await import('./stats-db.js');
    const statsDB = getStatsDB();

    // Calculate time window based on reset time
    let windowStart = new Date();
    if (usage.weekOpusResetInfo && usage.weekOpusResetInfo.nextResetDate) {
      const nextReset = new Date(usage.weekOpusResetInfo.nextResetDate);
      // Go back 7 days from next reset to get window start
      windowStart = new Date(nextReset.getTime() - 7 * 24 * 60 * 60 * 1000);
    } else {
      // Fallback: last 7 days
      windowStart.setDate(windowStart.getDate() - 7);
    }

    // Get stats for the window
    const windowStats = await statsDB.getTaskStats(windowStart, new Date());
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const todayStats = await statsDB.getTaskStats(todayStart, new Date());

    if (windowStats && todayStats) {
      lines.push('');
      // Compact stats format
      const windowCost = windowStats.totalCost || 0;
      const todayCost = todayStats.totalCost || 0;
      const windowTasks = windowStats.totalTasks || 0;
      const todayTasks = todayStats.totalTasks || 0;

      lines.push(`Window: ${windowTasks} tasks | $${windowCost.toFixed(2)}`);
      lines.push(`Today:  ${todayTasks} tasks | $${todayCost.toFixed(2)}`);
    }
  } catch (error) {
    // Silently skip stats if not available
  }

  if (usage.currentSession === null && usage.weekAllModels === null &&
      usage.weekOpus === null && !usage.currentPlan) {
    lines.push('Could not parse usage data');
  }

  lines.push('```');

  return lines.join('\n');
}

/**
 * Reset Claude usage cache
 * @param {string} type - Type of reset: 'all', 'opus', or 'session'
 * @returns {Promise<void>}
 */
export async function resetClaudeUsageCache(type = 'all') {
  // The "reset" functionality in the context of ani-code is to clear the cached
  // usage data so that the next fetch will get fresh data from Claude CLI.
  // This doesn't reset the actual usage limits on Claude's servers - that's
  // impossible. It only clears our local cache.

  // Since getClaudeUsage() doesn't actually use a persistent cache file,
  // but fetches fresh data each time via the expect script, there's nothing
  // to "reset" in terms of cache files.

  // However, we can interpret "reset" as a way to force-refresh the data
  // by running the claude limits command with a reset flag if it exists,
  // or simply return success since each call to getClaudeUsage() is already fresh.

  // For now, we'll implement this as a no-op that returns success,
  // since the data is always fresh. In the future, if caching is added,
  // this function can be extended to clear cache files.

  if (type !== 'all' && type !== 'opus' && type !== 'session') {
    throw new Error(`Invalid reset type: ${type}. Must be 'all', 'opus', or 'session'`);
  }

  // Log the reset action
  console.log(`Claude usage cache reset requested (type: ${type})`);

  // Since we don't have persistent cache, this is a no-op
  // The next call to getClaudeUsage() will fetch fresh data anyway
  return Promise.resolve();
}

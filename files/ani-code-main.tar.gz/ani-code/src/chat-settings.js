import fs from 'fs/promises';
import path from 'path';
import { logger } from './logger.js';
import { config } from './config.js';

export class ChatSettingsManager {
  constructor(settingsPath = null) {
    // Default to .ani-code-chat-settings.json in the ani-code root directory
    const aniCodeRoot = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
    this.settingsPath = settingsPath || path.join(aniCodeRoot, '.ani-code-chat-settings.json');
    this.settings = new Map();  // chatId -> workdirName
    this.workdirToChat = new Map();  // workdirPath -> chatId (last used)
    this.displayMode = null;  // global displayMode ('full' or 'simple')
    this.saveDebounceTimer = null;
  }

  async load() {
    try {
      const data = await fs.readFile(this.settingsPath, 'utf8');
      const parsed = JSON.parse(data);
      
      // Convert the object back to Maps
      if (parsed.chatWorkdirs) {
        this.settings = new Map(Object.entries(parsed.chatWorkdirs));
        logger.info(`Loaded chat settings from ${this.settingsPath}: ${this.settings.size} chats`);
      }
      
      // Load workdir-to-chat mappings
      if (parsed.workdirToChat) {
        this.workdirToChat = new Map(Object.entries(parsed.workdirToChat));
        logger.info(`Loaded workdir-to-chat mappings: ${this.workdirToChat.size} workdirs`);
      }

      // Load global display mode preference
      if (parsed.displayMode) {
        this.displayMode = parsed.displayMode;
        logger.info(`Loaded global display mode: ${this.displayMode}`);
      } else if (parsed.displayModes) {
        // Migrate from per-chat to global: pick the most recent/first value
        const modes = Object.values(parsed.displayModes);
        if (modes.length > 0) {
          this.displayMode = modes[0];
          logger.info(`Migrated per-chat display mode to global: ${this.displayMode}`);
        }
      }
    } catch (error) {
      if (error.code === 'ENOENT') {
        // File doesn't exist yet, that's okay
        logger.info('No existing chat settings file, starting fresh');
        await this.save(); // Create an empty file
      } else {
        logger.error('Failed to load chat settings:', error);
      }
    }
  }

  async save() {
    try {
      // Clear any pending save timer
      if (this.saveDebounceTimer) {
        clearTimeout(this.saveDebounceTimer);
        this.saveDebounceTimer = null;
      }

      // Convert Maps to objects for JSON serialization
      const data = {
        version: '1.2',
        updated: new Date().toISOString(),
        chatWorkdirs: Object.fromEntries(this.settings),
        workdirToChat: Object.fromEntries(this.workdirToChat),
        displayMode: this.displayMode
      };

      await fs.writeFile(this.settingsPath, JSON.stringify(data, null, 2));
      logger.debug(`Saved chat settings to ${this.settingsPath}`);
    } catch (error) {
      logger.error('Failed to save chat settings:', error);
    }
  }

  // Debounced save to avoid too many writes
  async saveDebounced() {
    if (this.saveDebounceTimer) {
      clearTimeout(this.saveDebounceTimer);
    }
    
    this.saveDebounceTimer = setTimeout(() => {
      this.save();
    }, 1000); // Save after 1 second of no changes
  }

  // Get workdir for a chat
  getWorkdir(chatId) {
    const workdir = this.settings.get(chatId);

    // In gateway mode, default to 'workspace' if no workdir is explicitly set
    if (!workdir && config.gateway?.enabled) {
      return 'workspace';
    }

    return workdir;
  }
  
  // Get chat ID for a workdir path
  getChatForWorkdir(workdirPath) {
    // First try to get the specific chat ID for this workdir
    const specificChatId = this.workdirToChat.get(workdirPath);
    if (specificChatId) {
      return specificChatId;
    }
    
    // Check for parent directory matches (prefix matching)
    // Sort workdir paths by length (longest first) to find the most specific match
    const sortedWorkdirs = Array.from(this.workdirToChat.entries())
      .sort((a, b) => b[0].length - a[0].length);
    
    for (const [mappedPath, chatId] of sortedWorkdirs) {
      // Check if the workdirPath starts with the mapped path
      // Ensure we're matching on directory boundaries
      if (workdirPath.startsWith(mappedPath)) {
        // Check if it's a proper subdirectory match
        const remainder = workdirPath.slice(mappedPath.length);
        if (remainder === '' || remainder.startsWith('/')) {
          logger.debug(`Found parent directory match: ${mappedPath} for ${workdirPath}, using chat ID ${chatId}`);
          return chatId;
        }
      }
    }
    
    // Try to match by project name (basename matching)
    // Extract the project name from the workdir path
    const pathParts = workdirPath.split('/');
    const projectName = pathParts[pathParts.length - 1];
    
    // Look through chatWorkdirs to find a matching project name
    for (const [chatId, workdirName] of this.settings.entries()) {
      // Check if the workdir name matches the project name or is contained in it
      if (projectName.includes(workdirName) || workdirName.includes(projectName)) {
        logger.debug(`Found project name match: ${workdirName} for ${projectName} in ${workdirPath}, using chat ID ${chatId}`);
        // Also update the workdirToChat mapping for future lookups
        this.workdirToChat.set(workdirPath, chatId);
        this.saveDebounced();
        return chatId;
      }
    }
    
    // If no specific chat ID found, use fallback logic:
    // 1. Try to find ani-code project's chat ID
    const aniCodePath = '/root/workspace/ani-code';
    const aniCodeChatId = this.workdirToChat.get(aniCodePath);
    if (aniCodeChatId) {
      logger.debug(`No chat ID for ${workdirPath}, using ani-code project chat ID: ${aniCodeChatId}`);
      return aniCodeChatId;
    }
    
    // 2. Otherwise, use the first available chat ID
    if (this.workdirToChat.size > 0) {
      const firstChatId = this.workdirToChat.values().next().value;
      logger.debug(`No chat ID for ${workdirPath}, using first available chat ID: ${firstChatId}`);
      return firstChatId;
    }
    
    // No chat IDs available at all
    logger.debug(`No chat ID found for ${workdirPath} and no fallback available`);
    return null;
  }

  // Set workdir for a chat
  async setWorkdir(chatId, workdirName, workdirPath = null) {
    // Clean up old workdir paths for this chat before setting new one
    const oldWorkdirName = this.settings.get(chatId);
    if (oldWorkdirName && oldWorkdirName !== workdirName) {
      // Remove old workdir path associations for this chat
      for (const [path, associatedChatId] of this.workdirToChat.entries()) {
        if (associatedChatId === chatId) {
          this.workdirToChat.delete(path);
          logger.debug(`Removed old workdir path association: ${path} for chat ${chatId}`);
        }
      }
    }
    
    this.settings.set(chatId, workdirName);
    
    // Also track which chat is using this workdir (last used wins)
    if (workdirPath) {
      // If another chat was using this path, remove it
      const existingChatId = this.workdirToChat.get(workdirPath);
      if (existingChatId && existingChatId !== chatId) {
        logger.debug(`Workdir path ${workdirPath} was used by chat ${existingChatId}, reassigning to ${chatId}`);
      }
      this.workdirToChat.set(workdirPath, chatId);
      logger.debug(`Associated workdir path ${workdirPath} with chat ${chatId}`);
    }
    
    await this.saveDebounced();
    logger.debug(`Set workdir for chat ${chatId}: ${workdirName}`);
  }

  // Remove workdir for a chat
  async removeWorkdir(chatId) {
    const deleted = this.settings.delete(chatId);
    if (deleted) {
      await this.saveDebounced();
      logger.info(`Removed workdir for chat ${chatId}`);
    }
    return deleted;
  }

  // Get all chat settings
  getAllSettings() {
    return new Map(this.settings);
  }

  // Clear all settings
  async clearAll() {
    this.settings.clear();
    await this.save();
    logger.info('Cleared all chat settings');
  }

  // Get global display mode
  getDisplayMode() {
    return this.displayMode || null;
  }

  // Set global display mode
  async setDisplayMode(chatId, mode) {
    this.displayMode = mode;
    await this.saveDebounced();
    logger.debug(`Set global display mode: ${mode}`);
  }

  // Get statistics
  getStats() {
    const workdirCounts = {};
    for (const workdir of this.settings.values()) {
      workdirCounts[workdir] = (workdirCounts[workdir] || 0) + 1;
    }
    
    return {
      totalChats: this.settings.size,
      workdirUsage: workdirCounts
    };
  }
}
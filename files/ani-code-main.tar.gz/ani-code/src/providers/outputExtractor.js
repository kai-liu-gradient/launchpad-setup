/**
 * Output Extractor - Extract conclusions from verbose CLI provider outputs
 */

/**
 * Extract conclusion from Codex output
 * Codex format:
 * [timestamp] OpenAI Codex v...
 * --------
 * workdir: ...
 * ...
 * --------
 * [timestamp] User instructions: ...
 * [timestamp] thinking...
 * [timestamp] codex
 *
 * <ACTUAL ANSWER HERE>
 *
 * [timestamp] tokens used: ...
 *
 * For progress updates with multi-turn conversations, we only want
 * the LAST assistant response, not all responses.
 *
 * @param {string} output - Raw codex output
 * @returns {string} Extracted conclusion (last response only)
 */
export function extractCodexConclusion(output) {
  if (!output || typeof output !== 'string') {
    return output;
  }

  const lines = output.split('\n');

  // Strategy: Find all assistant response blocks (marked by [timestamp] codex/assistant)
  // and return only the last one

  const responseBlocks = [];
  let currentBlock = [];
  let inResponse = false;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    // Check for assistant response marker (e.g., "[timestamp] codex" or "[timestamp] assistant")
    if (/\[\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\]\s+(codex|assistant)/i.test(line)) {
      // Save previous block if it exists
      if (currentBlock.length > 0) {
        responseBlocks.push(currentBlock.join('\n').trim());
      }
      currentBlock = [];
      inResponse = true;
      continue; // Skip the marker line itself
    }

    // Check for end markers (token usage, new user input, etc.)
    if (inResponse) {
      // Stop at token usage line
      if (/\[\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\]\s+tokens used:/i.test(line)) {
        if (currentBlock.length > 0) {
          responseBlocks.push(currentBlock.join('\n').trim());
          currentBlock = [];
        }
        inResponse = false;
        continue;
      }

      // Stop at new user input marker
      if (/\[\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\]\s+User instructions:/i.test(line)) {
        if (currentBlock.length > 0) {
          responseBlocks.push(currentBlock.join('\n').trim());
          currentBlock = [];
        }
        inResponse = false;
        continue;
      }

      // Stop at thinking marker (indicates new turn)
      if (/\[\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\]\s+thinking/i.test(line)) {
        if (currentBlock.length > 0) {
          responseBlocks.push(currentBlock.join('\n').trim());
          currentBlock = [];
        }
        inResponse = false;
        continue;
      }

      // Collect response lines
      currentBlock.push(line);
    }
  }

  // Don't forget the last block
  if (currentBlock.length > 0) {
    responseBlocks.push(currentBlock.join('\n').trim());
  }

  // Return the last non-empty response block
  for (let i = responseBlocks.length - 1; i >= 0; i--) {
    if (responseBlocks[i].trim().length > 0) {
      return responseBlocks[i];
    }
  }

  // If no structured response found, return last 20 lines as fallback
  const lastLines = lines.slice(-20).join('\n').trim();
  if (lastLines) {
    return lastLines;
  }

  return output;
}

/**
 * Extract conclusion from Cursor Agent output
 * Cursor format with --print --output-format text:
 * Usually contains thinking process followed by final answer
 *
 * @param {string} output - Raw cursor-agent output
 * @returns {string} Extracted conclusion
 */
export function extractCursorConclusion(output) {
  if (!output || typeof output !== 'string') {
    return output;
  }

  const lines = output.split('\n');
  const conclusionLines = [];
  let inConclusion = false;

  // Cursor in text mode typically outputs:
  // - Thinking process
  // - Separator or marker
  // - Final answer

  // Look for common conclusion markers
  const conclusionMarkers = [
    /^answer:/i,
    /^result:/i,
    /^conclusion:/i,
    /^summary:/i,
    /^final answer:/i,
    /^response:/i
  ];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    // Check for conclusion markers
    if (!inConclusion) {
      for (const marker of conclusionMarkers) {
        if (marker.test(line)) {
          inConclusion = true;
          // Include the marker line if it has content after the marker
          const content = line.replace(marker, '').trim();
          if (content) {
            conclusionLines.push(content);
          }
          break;
        }
      }
      continue;
    }

    // Once in conclusion, collect all remaining lines
    if (inConclusion) {
      conclusionLines.push(line);
    }
  }

  // If we found conclusion content, return it trimmed
  if (conclusionLines.length > 0) {
    const conclusion = conclusionLines.join('\n').trim();
    if (conclusion) {
      return conclusion;
    }
  }

  // If no explicit conclusion marker found, return the full output
  // Don't try to extract last paragraph as it's too aggressive and loses context
  return output;
}

/**
 * Extract conclusion from Gemini CLI output
 * Gemini format may include:
 * - JSON output with { response: "...", stats: {...} }
 * - Plain text output (legacy)
 *
 * For JSON output, extract the response field.
 * For progress updates, we only want the LAST response block.
 *
 * @param {string} output - Raw Gemini output
 * @returns {string} Extracted conclusion (response text only)
 */
export function extractGeminiConclusion(output) {
  if (!output || typeof output !== 'string') {
    return output;
  }

  // Try to parse as JSON first (new format with -o json)
  const trimmedOutput = output.trim();

  // Look for Gemini JSON object start - it always has "session_id" as first key
  const jsonPatternStart = trimmedOutput.indexOf('{"session_id"');
  // Also try with whitespace after opening brace
  const jsonPatternStart2 = trimmedOutput.indexOf('{\n  "session_id"');
  const jsonPatternStart3 = trimmedOutput.indexOf('{  "session_id"');

  // Use whichever pattern is found first (or -1 if none)
  let jsonStart = -1;
  if (jsonPatternStart !== -1) jsonStart = jsonPatternStart;
  else if (jsonPatternStart2 !== -1) jsonStart = jsonPatternStart2;
  else if (jsonPatternStart3 !== -1) jsonStart = jsonPatternStart3;
  else {
    // Fallback: look for any { that might be JSON start
    jsonStart = trimmedOutput.indexOf('{');
  }

  if (jsonStart !== -1) {
    // Find the matching closing brace by counting depth
    const jsonCandidate = trimmedOutput.substring(jsonStart);
    let depth = 0;
    let inString = false;
    let escaped = false;
    let jsonEnd = -1;

    for (let i = 0; i < jsonCandidate.length; i++) {
      const char = jsonCandidate[i];

      if (escaped) {
        escaped = false;
        continue;
      }

      if (char === '\\' && inString) {
        escaped = true;
        continue;
      }

      if (char === '"' && !escaped) {
        inString = !inString;
        continue;
      }

      if (!inString) {
        if (char === '{') {
          depth++;
        } else if (char === '}') {
          depth--;
          if (depth === 0) {
            jsonEnd = i + 1;
            break;
          }
        }
      }
    }

    if (jsonEnd > 0) {
      try {
        const jsonPart = jsonCandidate.substring(0, jsonEnd);
        const parsed = JSON.parse(jsonPart);

        // Extract response from JSON output
        if (parsed.response) {
          return parsed.response;
        }
      } catch {
        // JSON parse failed, fall through to text parsing
      }
    }
  }

  // Fall back to text parsing for legacy format
  const lines = output.split('\n');

  // Strategy: Find the LAST meaningful response block
  // We look for the last occurrence of content after headers/status messages
  // and collect only that final block

  // First pass: identify all response block boundaries
  const responseBlocks = [];
  let currentBlock = [];
  let inBlock = false;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmedLine = line.trim();

    // Check if this is a header/status line that starts a new context
    const isHeaderLine = (
      /^(gemini|model|thinking|processing)/i.test(trimmedLine) ||
      /^(reading|writing|executing|searching|analyzing)/i.test(trimmedLine) ||
      /^\[tool:/i.test(trimmedLine) ||
      /^tool_use/i.test(trimmedLine) ||
      /^[-=*]{3,}$/.test(trimmedLine) ||
      // Gemini conversation markers
      /^User:/i.test(trimmedLine) ||
      /^Human:/i.test(trimmedLine) ||
      /^Assistant:/i.test(trimmedLine) ||
      /^Gemini:/i.test(trimmedLine) ||
      // Skip credential loading message
      /^Loaded cached credentials/i.test(trimmedLine)
    );

    if (isHeaderLine) {
      // Save current block if non-empty
      if (currentBlock.length > 0) {
        responseBlocks.push(currentBlock.join('\n').trim());
        currentBlock = [];
      }
      inBlock = false;
      continue;
    }

    // Collect content lines
    if (trimmedLine.length > 0) {
      inBlock = true;
      currentBlock.push(line);
    } else if (inBlock && currentBlock.length > 0) {
      // Preserve paragraph breaks within a block
      currentBlock.push(line);
    }
  }

  // Don't forget the last block
  if (currentBlock.length > 0) {
    responseBlocks.push(currentBlock.join('\n').trim());
  }

  // Return the last non-empty response block
  for (let i = responseBlocks.length - 1; i >= 0; i--) {
    if (responseBlocks[i].trim().length > 0) {
      return responseBlocks[i];
    }
  }

  // If no structured conclusion found, return last 20 lines as fallback
  const lastLines = lines.slice(-20).join('\n').trim();
  if (lastLines) {
    return lastLines;
  }

  return output;
}

/**
 * Extract conclusion from GitHub Copilot CLI output
 * Copilot format: TBD - may include thinking process and tool usage
 *
 * For progress updates with multi-turn conversations, we only want
 * the LAST assistant response, not all responses.
 *
 * @param {string} output - Raw copilot output
 * @returns {string} Extracted conclusion (last response only)
 */
export function extractCopilotConclusion(output) {
  if (!output || typeof output !== 'string') {
    return output;
  }

  const lines = output.split('\n');

  // Strategy: Find all assistant response blocks and return only the last one
  // Copilot may use markers like "Copilot:", "Assistant:", or similar

  const responseBlocks = [];
  let currentBlock = [];
  let inResponse = false;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmedLine = line.trim();

    // Check for assistant/copilot response markers
    const isResponseMarker = (
      /^(copilot|assistant):/i.test(trimmedLine) ||
      /^\[copilot\]/i.test(trimmedLine) ||
      /^> copilot/i.test(trimmedLine)
    );

    // Check for user/input markers (end of response)
    const isUserMarker = (
      /^(user|human|input):/i.test(trimmedLine) ||
      /^\[user\]/i.test(trimmedLine) ||
      /^> user/i.test(trimmedLine)
    );

    // Check for tool usage/thinking markers
    const isToolMarker = (
      /^\[tool:/i.test(trimmedLine) ||
      /^tool_use/i.test(trimmedLine) ||
      /^thinking\.\.\./i.test(trimmedLine) ||
      /^processing\.\.\./i.test(trimmedLine)
    );

    if (isResponseMarker) {
      // Save previous block if it exists
      if (currentBlock.length > 0) {
        responseBlocks.push(currentBlock.join('\n').trim());
      }
      currentBlock = [];
      inResponse = true;
      // Include content after the marker if present
      const content = trimmedLine.replace(/^(copilot|assistant):\s*/i, '').trim();
      if (content) {
        currentBlock.push(content);
      }
      continue;
    }

    if (inResponse && (isUserMarker || isToolMarker)) {
      // End of response block
      if (currentBlock.length > 0) {
        responseBlocks.push(currentBlock.join('\n').trim());
        currentBlock = [];
      }
      inResponse = false;
      continue;
    }

    // Collect response lines
    if (inResponse) {
      currentBlock.push(line);
    }
  }

  // Don't forget the last block
  if (currentBlock.length > 0) {
    responseBlocks.push(currentBlock.join('\n').trim());
  }

  // Return the last non-empty response block
  for (let i = responseBlocks.length - 1; i >= 0; i--) {
    if (responseBlocks[i].trim().length > 0) {
      return responseBlocks[i];
    }
  }

  // If no structured response found, return last 20 lines as fallback
  const lastLines = lines.slice(-20).join('\n').trim();
  if (lastLines) {
    return lastLines;
  }

  return output;
}

/**
 * Extract conclusion from OpenCode output
 * OpenCode format: Output from 'opencode run' command
 *
 * OpenCode output may include:
 * - Session information
 * - Model/provider info
 * - Assistant responses
 * - Tool usage
 *
 * For progress updates with multi-turn conversations, we only want
 * the LAST assistant response, not all responses.
 *
 * @param {string} output - Raw opencode output
 * @returns {string} Extracted conclusion (last response only)
 */
export function extractOpencodeConclusion(output) {
  if (!output || typeof output !== 'string') {
    return output;
  }

  const lines = output.split('\n');

  // Strategy: Find all assistant response blocks and return only the last one
  // OpenCode may use markers like "Assistant:", session info, or similar

  const responseBlocks = [];
  let currentBlock = [];
  let inResponse = false;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmedLine = line.trim();

    // Check for assistant/opencode response markers
    const isResponseMarker = (
      /^(assistant|opencode):/i.test(trimmedLine) ||
      /^\[assistant\]/i.test(trimmedLine) ||
      /^> assistant/i.test(trimmedLine) ||
      /^model:/i.test(trimmedLine)
    );

    // Check for user/input markers (end of response)
    const isUserMarker = (
      /^(user|human|input):/i.test(trimmedLine) ||
      /^\[user\]/i.test(trimmedLine) ||
      /^> user/i.test(trimmedLine)
    );

    // Check for tool usage/thinking markers
    const isToolMarker = (
      /^\[tool:/i.test(trimmedLine) ||
      /^tool_use/i.test(trimmedLine) ||
      /^thinking\.\.\./i.test(trimmedLine) ||
      /^processing\.\.\./i.test(trimmedLine) ||
      /^session:/i.test(trimmedLine)
    );

    // Check for stats/info lines to skip
    const isStatsLine = (
      /^tokens?:/i.test(trimmedLine) ||
      /^cost:/i.test(trimmedLine) ||
      /^duration:/i.test(trimmedLine) ||
      /^model used:/i.test(trimmedLine)
    );

    if (isResponseMarker) {
      // Save previous block if it exists
      if (currentBlock.length > 0) {
        responseBlocks.push(currentBlock.join('\n').trim());
      }
      currentBlock = [];
      inResponse = true;
      // Include content after the marker if present
      const content = trimmedLine.replace(/^(assistant|opencode):\s*/i, '').trim();
      if (content) {
        currentBlock.push(content);
      }
      continue;
    }

    if (inResponse && (isUserMarker || isToolMarker || isStatsLine)) {
      // End of response block
      if (currentBlock.length > 0) {
        responseBlocks.push(currentBlock.join('\n').trim());
        currentBlock = [];
      }
      inResponse = false;
      continue;
    }

    // Collect response lines
    if (inResponse) {
      currentBlock.push(line);
    }
  }

  // Don't forget the last block
  if (currentBlock.length > 0) {
    responseBlocks.push(currentBlock.join('\n').trim());
  }

  // Return the last non-empty response block
  for (let i = responseBlocks.length - 1; i >= 0; i--) {
    if (responseBlocks[i].trim().length > 0) {
      return responseBlocks[i];
    }
  }

  // If no structured response found, return last 20 lines as fallback
  const lastLines = lines.slice(-20).join('\n').trim();
  if (lastLines) {
    return lastLines;
  }

  return output;
}

/**
 * Extract conclusion from provider output based on provider type
 *
 * @param {string} output - Raw provider output
 * @param {string} providerId - Provider identifier (codex, cursor, gemini, etc.)
 * @returns {string} Extracted conclusion or original output
 */
export function extractProviderConclusion(output, providerId) {
  if (!output || typeof output !== 'string') {
    return output;
  }

  switch (providerId) {
    case 'codex':
      return extractCodexConclusion(output);
    case 'cursor':
      return extractCursorConclusion(output);
    case 'gemini':
      return extractGeminiConclusion(output);
    case 'copilot':
      return extractCopilotConclusion(output);
    case 'opencode':
      return extractOpencodeConclusion(output);
    default:
      // For other providers (claude, deepseek), return output as-is
      return output;
  }
}

/**
 * Extract tokens from Codex output
 * Codex formats:
 * 1. "[timestamp] tokens used: 197,255" (same line)
 * 2. "tokens used\n10,912" (next line, from stderr)
 *
 * @param {string} output - Raw codex output
 * @returns {number|null} Total tokens used, or null if not found
 */
export function extractCodexTokens(output) {
  if (!output || typeof output !== 'string') {
    return null;
  }

  // Pattern 1: [timestamp] tokens used: 197,255 (same line with colon)
  const timestampPattern = /\[\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\]\s+tokens\s+used:\s*([\d,]+)/i;
  const timestampMatch = output.match(timestampPattern);

  if (timestampMatch && timestampMatch[1]) {
    const tokenCount = parseInt(timestampMatch[1].replace(/,/g, ''), 10);
    if (!isNaN(tokenCount) && tokenCount > 0) {
      return tokenCount;
    }
  }

  // Pattern 2: "tokens used" followed by number on next line (stderr format)
  // May have log prefixes like "WARN: [TASK ...] stderr> " between lines
  const multilinePattern = /tokens\s+used\s*\n(?:.*?>)?\s*([\d,]+)/i;
  const multilineMatch = output.match(multilinePattern);

  if (multilineMatch && multilineMatch[1]) {
    const tokenCount = parseInt(multilineMatch[1].replace(/,/g, ''), 10);
    if (!isNaN(tokenCount) && tokenCount > 0) {
      return tokenCount;
    }
  }

  // Pattern 3: Simple "tokens used: 12345" without timestamp
  const simplePattern = /tokens\s+used:\s*([\d,]+)/i;
  const simpleMatch = output.match(simplePattern);

  if (simpleMatch && simpleMatch[1]) {
    const tokenCount = parseInt(simpleMatch[1].replace(/,/g, ''), 10);
    if (!isNaN(tokenCount) && tokenCount > 0) {
      return tokenCount;
    }
  }

  return null;
}

/**
 * Extract tokens from Cursor output
 * Cursor format: Need to investigate actual format
 *
 * @param {string} output - Raw cursor-agent output
 * @returns {number|null} Total tokens used, or null if not found
 */
export function extractCursorTokens(output) {
  if (!output || typeof output !== 'string') {
    return null;
  }

  // Try multiple patterns for cursor token output
  // Pattern 1: tokens used: 12345
  // Pattern 2: tokens: 12345
  // Pattern 3: Total tokens: 12345
  // Pattern 4: token_count: 12345
  const patterns = [
    /tokens\s+used:\s*([\d,]+)/i,
    /tokens:\s*([\d,]+)/i,
    /total\s+tokens:\s*([\d,]+)/i,
    /token_count:\s*([\d,]+)/i,
    /token\s+count:\s*([\d,]+)/i
  ];

  for (const pattern of patterns) {
    const match = output.match(pattern);
    if (match && match[1]) {
      const tokenCount = parseInt(match[1].replace(/,/g, ''), 10);
      if (!isNaN(tokenCount) && tokenCount > 0) {
        return tokenCount;
      }
    }
  }

  return null;
}

/**
 * Extract tokens from Gemini output
 * Gemini JSON output format includes:
 * {
 *   "stats": {
 *     "models": {
 *       "gemini-2.5-flash-lite": {
 *         "tokens": { "input": 3130, "total": 3229, ... }
 *       }
 *     }
 *   }
 * }
 *
 * @param {string} output - Raw Gemini output
 * @returns {number|null} Total tokens used, or null if not found
 */
export function extractGeminiTokens(output) {
  if (!output || typeof output !== 'string') {
    return null;
  }

  // Try to parse as JSON first (new format with -o json)
  const trimmedOutput = output.trim();

  // Handle case where output starts with "Loaded cached credentials." prefix
  const jsonStart = trimmedOutput.indexOf('{');
  if (jsonStart !== -1) {
    try {
      const jsonPart = trimmedOutput.substring(jsonStart);
      const parsed = JSON.parse(jsonPart);

      // Extract total tokens from JSON stats
      if (parsed.stats?.models) {
        let totalTokens = 0;
        for (const modelName of Object.keys(parsed.stats.models)) {
          const modelStats = parsed.stats.models[modelName];
          if (modelStats?.tokens?.total) {
            totalTokens += modelStats.tokens.total;
          }
        }
        if (totalTokens > 0) {
          return totalTokens;
        }
      }
    } catch {
      // Not valid JSON, fall through to pattern matching
    }
  }

  // Fall back to pattern matching for legacy/text format
  const patterns = [
    /tokens?\s*:?\s*([\d,]+)/i,
    /total\s+tokens?\s*:?\s*([\d,]+)/i,
    /input_tokens?\s*:?\s*([\d,]+)/i,
    /output_tokens?\s*:?\s*([\d,]+)/i
  ];

  for (const pattern of patterns) {
    const match = output.match(pattern);
    if (match && match[1]) {
      const tokenCount = parseInt(match[1].replace(/,/g, ''), 10);
      if (!isNaN(tokenCount) && tokenCount > 0) {
        return tokenCount;
      }
    }
  }

  return null;
}

/**
 * Extract tokens from GitHub Copilot CLI output
 * Copilot may show token usage via /usage command or in output footer
 *
 * Expected patterns:
 * - "tokens: 12345" or "total tokens: 12345"
 * - JSON output with stats.tokens field
 *
 * @param {string} output - Raw copilot output
 * @returns {number|null} Total tokens used, or null if not found
 */
export function extractCopilotTokens(output) {
  if (!output || typeof output !== 'string') {
    return null;
  }

  // Try to parse as JSON first (if Copilot supports JSON output)
  const trimmedOutput = output.trim();
  const jsonStart = trimmedOutput.indexOf('{');
  if (jsonStart !== -1) {
    try {
      const jsonPart = trimmedOutput.substring(jsonStart);
      const parsed = JSON.parse(jsonPart);

      // Extract total tokens from JSON stats if available
      if (parsed.stats?.tokens?.total) {
        return parsed.stats.tokens.total;
      }
      if (parsed.usage?.total_tokens) {
        return parsed.usage.total_tokens;
      }
      if (parsed.tokens) {
        return typeof parsed.tokens === 'number' ? parsed.tokens : null;
      }
    } catch {
      // Not valid JSON, fall through to pattern matching
    }
  }

  // Fall back to pattern matching
  const patterns = [
    /tokens?\s+used:\s*([\d,]+)/i,
    /total\s+tokens?:\s*([\d,]+)/i,
    /tokens?:\s*([\d,]+)/i,
    /token_count:\s*([\d,]+)/i,
    /input_tokens:\s*([\d,]+).*output_tokens:\s*([\d,]+)/i  // Sum input + output
  ];

  for (const pattern of patterns) {
    const match = output.match(pattern);
    if (match) {
      if (match[2]) {
        // Pattern with input and output (sum them)
        const input = parseInt(match[1].replace(/,/g, ''), 10);
        const outputTokens = parseInt(match[2].replace(/,/g, ''), 10);
        if (!isNaN(input) && !isNaN(outputTokens)) {
          return input + outputTokens;
        }
      } else if (match[1]) {
        const tokenCount = parseInt(match[1].replace(/,/g, ''), 10);
        if (!isNaN(tokenCount) && tokenCount > 0) {
          return tokenCount;
        }
      }
    }
  }

  return null;
}

/**
 * Extract tokens from OpenCode output
 * OpenCode may output token usage in various formats:
 * - JSON output with stats
 * - Text format with "tokens: X" or "total tokens: X"
 *
 * @param {string} output - Raw opencode output
 * @returns {number|null} Total tokens used, or null if not found
 */
export function extractOpencodeTokens(output) {
  if (!output || typeof output !== 'string') {
    return null;
  }

  // Try to parse as JSON first (if OpenCode supports JSON output)
  const trimmedOutput = output.trim();
  const jsonStart = trimmedOutput.indexOf('{');
  if (jsonStart !== -1) {
    try {
      const jsonPart = trimmedOutput.substring(jsonStart);
      const parsed = JSON.parse(jsonPart);

      // Extract total tokens from JSON stats if available
      if (parsed.stats?.tokens?.total) {
        return parsed.stats.tokens.total;
      }
      if (parsed.usage?.total_tokens) {
        return parsed.usage.total_tokens;
      }
      if (parsed.tokens) {
        return typeof parsed.tokens === 'number' ? parsed.tokens : null;
      }
      // Check for input/output breakdown
      if (parsed.stats?.input_tokens && parsed.stats?.output_tokens) {
        return parsed.stats.input_tokens + parsed.stats.output_tokens;
      }
    } catch {
      // Not valid JSON, fall through to pattern matching
    }
  }

  // Fall back to pattern matching
  const patterns = [
    /tokens?\s+used:\s*([\d,]+)/i,
    /total\s+tokens?:\s*([\d,]+)/i,
    /tokens?:\s*([\d,]+)/i,
    /token_count:\s*([\d,]+)/i,
    /input_tokens:\s*([\d,]+).*output_tokens:\s*([\d,]+)/i  // Sum input + output
  ];

  for (const pattern of patterns) {
    const match = output.match(pattern);
    if (match) {
      if (match[2]) {
        // Pattern with input and output (sum them)
        const input = parseInt(match[1].replace(/,/g, ''), 10);
        const outputTokens = parseInt(match[2].replace(/,/g, ''), 10);
        if (!isNaN(input) && !isNaN(outputTokens)) {
          return input + outputTokens;
        }
      } else if (match[1]) {
        const tokenCount = parseInt(match[1].replace(/,/g, ''), 10);
        if (!isNaN(tokenCount) && tokenCount > 0) {
          return tokenCount;
        }
      }
    }
  }

  return null;
}

/**
 * Extract tokens from provider output based on provider type
 *
 * @param {string} output - Raw provider output
 * @param {string} providerId - Provider identifier (codex, cursor, gemini, etc.)
 * @returns {number|null} Total tokens used, or null if not found
 */
export function extractProviderTokens(output, providerId) {
  if (!output || typeof output !== 'string') {
    return null;
  }

  switch (providerId) {
    case 'codex':
      return extractCodexTokens(output);
    case 'cursor':
      return extractCursorTokens(output);
    case 'gemini':
      return extractGeminiTokens(output);
    case 'copilot':
      return extractCopilotTokens(output);
    case 'opencode':
      return extractOpencodeTokens(output);
    default:
      // For other providers, return null (they use ccusage API)
      return null;
  }
}

/**
 * Extract model name from Codex output
 * Codex format:
 * model: o3-mini
 * or
 * model: gpt-5.1-codex-max
 *
 * @param {string} output - Raw codex output
 * @returns {string|null} Model name, or null if not found
 */
export function extractCodexModel(output) {
  if (!output || typeof output !== 'string') {
    return null;
  }

  // Look for pattern: model: <model-name>
  const modelPattern = /model:\s*([^\n\r]+)/i;
  const match = output.match(modelPattern);

  if (match && match[1]) {
    const modelName = match[1].trim();
    if (modelName.length > 0) {
      return modelName;
    }
  }

  return null;
}

/**
 * Extract model name(s) from Gemini output
 * Gemini JSON output format includes:
 * {
 *   "stats": {
 *     "models": {
 *       "gemini-2.5-flash-lite": { ... },
 *       "gemini-3-flash-preview": { ... }
 *     }
 *   }
 * }
 *
 * Returns the first model name found, or a comma-separated list if multiple models
 *
 * @param {string} output - Raw Gemini output
 * @returns {string|null} Model name(s), or null if not found
 */
export function extractGeminiModel(output) {
  if (!output || typeof output !== 'string') {
    return null;
  }

  // Try to parse as JSON first (new format with -o json)
  const trimmedOutput = output.trim();

  // Handle case where output starts with "Loaded cached credentials." prefix
  const jsonStart = trimmedOutput.indexOf('{');
  if (jsonStart !== -1) {
    try {
      const jsonPart = trimmedOutput.substring(jsonStart);
      const parsed = JSON.parse(jsonPart);

      // Extract model names from JSON stats
      if (parsed.stats?.models) {
        const modelNames = Object.keys(parsed.stats.models);
        if (modelNames.length > 0) {
          // Return first model if single, or the primary model (one with most tokens)
          if (modelNames.length === 1) {
            return modelNames[0];
          }

          // Find the model with the most total tokens used
          let primaryModel = modelNames[0];
          let maxTokens = 0;

          for (const modelName of modelNames) {
            const modelStats = parsed.stats.models[modelName];
            const totalTokens = modelStats?.tokens?.total || 0;
            if (totalTokens > maxTokens) {
              maxTokens = totalTokens;
              primaryModel = modelName;
            }
          }

          return primaryModel;
        }
      }
    } catch {
      // Not valid JSON, fall through to pattern matching
    }
  }

  // Fall back to pattern matching for legacy/text format
  const modelPattern = /model:\s*([^\n\r]+)/i;
  const match = output.match(modelPattern);

  if (match && match[1]) {
    const modelName = match[1].trim();
    if (modelName.length > 0) {
      return modelName;
    }
  }

  return null;
}

/**
 * Extract model name from GitHub Copilot CLI output
 * Copilot supports multiple models including Claude Sonnet 4, GPT-5, etc.
 *
 * Expected patterns:
 * - "model: gpt-5" or "using model: claude-sonnet-4"
 * - JSON output with model field
 *
 * @param {string} output - Raw copilot output
 * @returns {string|null} Model name, or null if not found
 */
export function extractCopilotModel(output) {
  if (!output || typeof output !== 'string') {
    return null;
  }

  // Try to parse as JSON first (if Copilot supports JSON output)
  const trimmedOutput = output.trim();
  const jsonStart = trimmedOutput.indexOf('{');
  if (jsonStart !== -1) {
    try {
      const jsonPart = trimmedOutput.substring(jsonStart);
      const parsed = JSON.parse(jsonPart);

      // Extract model from JSON if available
      if (parsed.model) {
        return parsed.model;
      }
      if (parsed.stats?.model) {
        return parsed.stats.model;
      }
    } catch {
      // Not valid JSON, fall through to pattern matching
    }
  }

  // Fall back to pattern matching
  const patterns = [
    /model:\s*([^\n\r,]+)/i,
    /using\s+model:\s*([^\n\r,]+)/i,
    /selected\s+model:\s*([^\n\r,]+)/i,
    /current\s+model:\s*([^\n\r,]+)/i
  ];

  for (const pattern of patterns) {
    const match = output.match(pattern);
    if (match && match[1]) {
      const modelName = match[1].trim();
      if (modelName.length > 0) {
        return modelName;
      }
    }
  }

  return null;
}

/**
 * Extract model name from OpenCode output
 * OpenCode uses provider/model format (e.g., anthropic/claude-3-opus)
 *
 * Expected patterns:
 * - "model: anthropic/claude-3-opus" or "using model: openai/gpt-4"
 * - JSON output with model field
 * - Session info with model name
 *
 * @param {string} output - Raw opencode output
 * @returns {string|null} Model name, or null if not found
 */
export function extractOpencodeModel(output) {
  if (!output || typeof output !== 'string') {
    return null;
  }

  // Try to parse as JSON first (if OpenCode supports JSON output)
  const trimmedOutput = output.trim();
  const jsonStart = trimmedOutput.indexOf('{');
  if (jsonStart !== -1) {
    try {
      const jsonPart = trimmedOutput.substring(jsonStart);
      const parsed = JSON.parse(jsonPart);

      // Extract model from JSON if available
      if (parsed.model) {
        return parsed.model;
      }
      if (parsed.stats?.model) {
        return parsed.stats.model;
      }
      if (parsed.session?.model) {
        return parsed.session.model;
      }
    } catch {
      // Not valid JSON, fall through to pattern matching
    }
  }

  // Fall back to pattern matching
  const patterns = [
    /model:\s*([^\n\r,]+)/i,
    /using\s+model:\s*([^\n\r,]+)/i,
    /selected\s+model:\s*([^\n\r,]+)/i,
    /provider\/model:\s*([^\n\r,]+)/i,
    // OpenCode specific patterns
    /\[(anthropic|openai|google|local)\/([^\]]+)\]/i,
    /(anthropic|openai|google)\/([a-z0-9-]+)/i
  ];

  for (const pattern of patterns) {
    const match = output.match(pattern);
    if (match) {
      // Handle patterns that capture provider and model separately
      if (match[2]) {
        return `${match[1]}/${match[2]}`.trim();
      }
      if (match[1]) {
        const modelName = match[1].trim();
        if (modelName.length > 0) {
          return modelName;
        }
      }
    }
  }

  return null;
}

/**
 * Extract model name from provider output based on provider type
 *
 * @param {string} output - Raw provider output
 * @param {string} providerId - Provider identifier (codex, cursor, gemini, etc.)
 * @returns {string|null} Model name, or null if not found
 */
export function extractProviderModel(output, providerId) {
  if (!output || typeof output !== 'string') {
    return null;
  }

  switch (providerId) {
    case 'codex':
      return extractCodexModel(output);
    case 'gemini':
      return extractGeminiModel(output);
    case 'copilot':
      return extractCopilotModel(output);
    case 'opencode':
      return extractOpencodeModel(output);
    default:
      // For other providers (claude, cursor), model info comes from ccusage or config
      return null;
  }
}

/**
 * Extract detailed stats from Gemini CLI JSON output
 * This provides per-model breakdown for usageV2 tracking
 *
 * Gemini JSON output format:
 * {
 *   "session_id": "...",
 *   "response": "...",
 *   "stats": {
 *     "models": {
 *       "gemini-2.5-pro": {
 *         "api": { "totalRequests": 2, "totalErrors": 0, "totalLatencyMs": 28629 },
 *         "tokens": {
 *           "input": 21839,       // Input tokens (prompt)
 *           "prompt": 21839,      // Same as input
 *           "candidates": 67,     // Output tokens (response)
 *           "total": 22133,       // Total tokens
 *           "cached": 0,          // Cached input tokens
 *           "thoughts": 227,      // Thinking/reasoning tokens
 *           "tool": 0             // Tool call tokens
 *         }
 *       }
 *     }
 *   }
 * }
 *
 * @param {string} output - Raw Gemini output
 * @returns {Object|null} Detailed stats object with usageV2 array, or null if not found
 */
export function extractGeminiStats(output) {
  if (!output || typeof output !== 'string') {
    return null;
  }

  // Try to parse as JSON first (new format with -o json)
  const trimmedOutput = output.trim();

  // Look for Gemini JSON object start - it always has "session_id" as first key
  // Handle various formats: {"session_id", { "session_id", {\n  "session_id"
  let jsonStart = trimmedOutput.indexOf('{"session_id"');
  if (jsonStart === -1) {
    jsonStart = trimmedOutput.indexOf('{ "session_id"');
  }
  if (jsonStart === -1) {
    // Look for opening brace followed by newline and session_id
    const match = trimmedOutput.match(/\{\s*\n?\s*"session_id"/);
    if (match) {
      jsonStart = trimmedOutput.indexOf(match[0]);
    }
  }
  if (jsonStart === -1) {
    return null;
  }

  // Find the matching closing brace by counting depth
  const jsonCandidate = trimmedOutput.substring(jsonStart);
  let depth = 0;
  let inString = false;
  let escaped = false;
  let jsonEnd = -1;

  for (let i = 0; i < jsonCandidate.length; i++) {
    const char = jsonCandidate[i];

    if (escaped) {
      escaped = false;
      continue;
    }

    if (char === '\\' && inString) {
      escaped = true;
      continue;
    }

    if (char === '"' && !escaped) {
      inString = !inString;
      continue;
    }

    if (!inString) {
      if (char === '{') {
        depth++;
      } else if (char === '}') {
        depth--;
        if (depth === 0) {
          jsonEnd = i + 1;
          break;
        }
      }
    }
  }

  if (jsonEnd <= 0) {
    return null;
  }

  try {
    const jsonPart = jsonCandidate.substring(0, jsonEnd);
    const parsed = JSON.parse(jsonPart);

    // Extract model stats from JSON
    if (!parsed.stats?.models) {
      return null;
    }

    const usageV2 = [];
    let totalInputTokens = 0;
    let totalOutputTokens = 0;
    let totalCachedTokens = 0;
    let totalTokens = 0;

    for (const [modelName, modelStats] of Object.entries(parsed.stats.models)) {
      const tokens = modelStats.tokens || {};

      // Input tokens: use 'input' or 'prompt' field
      const inputTokens = tokens.input || tokens.prompt || 0;
      // Output tokens: use 'candidates' field (Gemini's term for output)
      const outputTokens = tokens.candidates || 0;
      // Cached tokens
      const cachedTokens = tokens.cached || 0;
      // Total (for verification)
      const modelTotal = tokens.total || (inputTokens + outputTokens);
      // Thinking/reasoning tokens (add to output for cost calculation)
      const thoughtTokens = tokens.thoughts || 0;

      // Accumulate totals
      totalInputTokens += inputTokens;
      totalOutputTokens += outputTokens + thoughtTokens; // Include thoughts in output
      totalCachedTokens += cachedTokens;
      totalTokens += modelTotal;

      usageV2.push({
        modelId: modelName,
        providerId: 'gemini',
        inputTokens: inputTokens,
        inputCachedTokens: cachedTokens,
        outputTokens: outputTokens + thoughtTokens,
        totalTokens: modelTotal,
        // API stats
        apiRequests: modelStats.api?.totalRequests || 0,
        apiLatencyMs: modelStats.api?.totalLatencyMs || 0,
        apiErrors: modelStats.api?.totalErrors || 0
      });
    }

    // Extract session info if available
    const sessionId = parsed.session_id || null;

    return {
      sessionId,
      usageV2,
      totals: {
        inputTokens: totalInputTokens,
        outputTokens: totalOutputTokens,
        cachedTokens: totalCachedTokens,
        totalTokens: totalTokens
      }
    };
  } catch {
    // Not valid JSON, return null
    return null;
  }
}

/**
 * Extract detailed stats from Codex output
 * Codex provides limited info: total token count and model name
 *
 * @param {string} output - Raw codex output
 * @returns {Object|null} Stats object with usageV2 array and totals, or null if not extractable
 */
export function extractCodexStats(output) {
  if (!output || typeof output !== 'string') {
    return null;
  }

  const totalTokens = extractCodexTokens(output);
  if (totalTokens === null) {
    return null;
  }

  const modelName = extractCodexModel(output) || 'codex';

  // Codex only provides total token count, no input/output breakdown
  // Record all as inputTokens since we don't know the actual split
  const usageV2 = [{
    modelId: modelName,
    inputTokens: totalTokens,
    outputTokens: 0,
    cachedTokens: 0,
    totalTokens: totalTokens
  }];

  return {
    sessionId: null,
    usageV2,
    totals: {
      inputTokens: totalTokens,
      outputTokens: 0,
      cachedTokens: 0,
      totalTokens: totalTokens
    }
  };
}

/**
 * Extract detailed stats from provider output based on provider type
 * Returns usageV2 format for direct insertion into stats database
 *
 * @param {string} output - Raw provider output
 * @param {string} providerId - Provider identifier (gemini, codex, cursor, etc.)
 * @returns {Object|null} Stats object with usageV2 array and totals, or null if not extractable
 */
export function extractProviderStats(output, providerId) {
  if (!output || typeof output !== 'string') {
    return null;
  }

  switch (providerId) {
    case 'gemini':
      return extractGeminiStats(output);
    case 'codex':
      return extractCodexStats(output);
    // Future: Add extractCursorStats, etc.
    default:
      return null;
  }
}

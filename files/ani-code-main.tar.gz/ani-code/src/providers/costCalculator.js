/**
 * Cost Calculator - Estimate token costs for various AI providers
 *
 * Pricing data as of January 2026 (subject to change):
 * - Prices are per million tokens
 * - Some providers don't separate input/output pricing
 */

/**
 * Token pricing rates per million tokens (USD)
 * Source: Provider pricing pages
 */
export const MODEL_PRICING = {
  // Google Gemini models
  // https://ai.google.dev/pricing
  gemini: {
    'gemini-2.5-pro': { input: 1.25, output: 10.00, cached: 0.31 },
    'gemini-2.5-flash': { input: 0.15, output: 0.60, cached: 0.0375 },
    'gemini-2.5-flash-lite': { input: 0.075, output: 0.30, cached: 0.01875 },
    'gemini-2.0-flash': { input: 0.10, output: 0.40, cached: 0.025 },
    'gemini-2.0-flash-lite': { input: 0.075, output: 0.30, cached: 0.01875 },
    'gemini-1.5-pro': { input: 1.25, output: 5.00, cached: 0.31 },
    'gemini-1.5-flash': { input: 0.075, output: 0.30, cached: 0.01875 },
    // Gemini 3 preview models (estimated pricing)
    'gemini-3-flash': { input: 0.15, output: 0.60, cached: 0.0375 },
    'gemini-3-flash-preview': { input: 0.15, output: 0.60, cached: 0.0375 },
    'gemini-3-pro': { input: 1.25, output: 10.00, cached: 0.31 },
    'gemini-3-pro-preview': { input: 1.25, output: 10.00, cached: 0.31 },
    // Thinking models
    'gemini-2.5-flash-preview-04-17': { input: 0.15, output: 0.60, cached: 0.0375 },
    'gemini-2.0-flash-thinking-exp': { input: 0.10, output: 0.40, cached: 0.025 },
    // Default fallback for unknown gemini models - use flash pricing as conservative default
    '_default': { input: 0.075, output: 0.30, cached: 0.01875 }
  },

  // OpenAI/Codex models (used by codex CLI)
  // https://openai.com/pricing
  codex: {
    // o-series reasoning models
    'o3-mini': { input: 1.10, output: 4.40, cached: 0.55 },
    'o3': { input: 10.00, output: 40.00, cached: 5.00 },
    'o1': { input: 15.00, output: 60.00, cached: 7.50 },
    'o1-mini': { input: 3.00, output: 12.00, cached: 1.50 },
    'o1-preview': { input: 15.00, output: 60.00, cached: 7.50 },
    // GPT-4 series
    'gpt-4o': { input: 2.50, output: 10.00, cached: 1.25 },
    'gpt-4o-mini': { input: 0.15, output: 0.60, cached: 0.075 },
    'gpt-4-turbo': { input: 10.00, output: 30.00, cached: 5.00 },
    'gpt-4': { input: 30.00, output: 60.00, cached: 15.00 },
    // GPT-3.5
    'gpt-3.5-turbo': { input: 0.50, output: 1.50, cached: 0.25 },
    // Codex-specific models
    'gpt-5.1-codex-max': { input: 5.00, output: 20.00, cached: 2.50 },
    'codex-mini': { input: 1.00, output: 4.00, cached: 0.50 },
    // Default fallback for unknown codex/openai models
    '_default': { input: 2.50, output: 10.00, cached: 1.25 }
  },

  // Cursor-specific models (may use various backends)
  cursor: {
    'cursor-fast': { input: 0.25, output: 1.00, cached: 0.125 },
    'cursor-small': { input: 0.10, output: 0.40, cached: 0.05 },
    // Default fallback
    '_default': { input: 0.50, output: 2.00, cached: 0.25 }
  },

  // Anthropic Claude models (reference, usually from ccusage)
  // https://www.anthropic.com/pricing
  claude: {
    'claude-opus-4-5': { input: 15.00, output: 75.00, cached: 1.875 },
    'claude-opus-4-5-20251101': { input: 15.00, output: 75.00, cached: 1.875 },
    'claude-sonnet-4': { input: 3.00, output: 15.00, cached: 0.375 },
    'claude-sonnet-4-20251014': { input: 3.00, output: 15.00, cached: 0.375 },
    'claude-3-7-sonnet': { input: 3.00, output: 15.00, cached: 0.375 },
    'claude-3-5-sonnet': { input: 3.00, output: 15.00, cached: 0.375 },
    'claude-3-5-sonnet-20241022': { input: 3.00, output: 15.00, cached: 0.375 },
    'claude-3-haiku': { input: 0.25, output: 1.25, cached: 0.03 },
    'claude-3-5-haiku': { input: 0.80, output: 4.00, cached: 0.10 },
    // Default fallback
    '_default': { input: 3.00, output: 15.00, cached: 0.375 }
  },

  // GitHub Copilot models
  // Note: GitHub Copilot uses subscription pricing (Business: $19/user/month, Enterprise: $39/user/month)
  // Token-level pricing is not publicly disclosed, but we can estimate based on underlying models
  // Copilot supports Claude Sonnet 4, GPT-5, and proprietary models
  // These estimates are based on the underlying model costs
  copilot: {
    // GPT-5 and variants (through Copilot)
    'gpt-5': { input: 2.50, output: 10.00, cached: 1.25 },
    'gpt-5-turbo': { input: 1.50, output: 6.00, cached: 0.75 },
    // Claude models (through Copilot)
    'claude-sonnet-4': { input: 3.00, output: 15.00, cached: 0.375 },
    'claude-sonnet': { input: 3.00, output: 15.00, cached: 0.375 },
    // Copilot's default model (estimated)
    'copilot-default': { input: 1.00, output: 4.00, cached: 0.50 },
    'copilot-fast': { input: 0.50, output: 2.00, cached: 0.25 },
    // Default fallback - moderate estimate
    '_default': { input: 1.50, output: 6.00, cached: 0.75 }
  },

  // OpenCode models
  // OpenCode supports multiple backends (OpenAI, Anthropic, Google, local models)
  // Pricing maps to the underlying provider's pricing
  // Model format: provider/model (e.g., anthropic/claude-3-opus)
  opencode: {
    // Anthropic models (via OpenCode)
    'anthropic/claude-opus-4': { input: 15.00, output: 75.00, cached: 1.875 },
    'anthropic/claude-opus-4-20250514': { input: 15.00, output: 75.00, cached: 1.875 },
    'anthropic/claude-sonnet-4': { input: 3.00, output: 15.00, cached: 0.375 },
    'anthropic/claude-sonnet-4-20250514': { input: 3.00, output: 15.00, cached: 0.375 },
    'anthropic/claude-3-5-sonnet': { input: 3.00, output: 15.00, cached: 0.375 },
    'anthropic/claude-3-5-haiku': { input: 0.80, output: 4.00, cached: 0.10 },
    'anthropic/claude-3-5-haiku-20241022': { input: 0.80, output: 4.00, cached: 0.10 },
    // OpenAI models (via OpenCode)
    'openai/gpt-4o': { input: 2.50, output: 10.00, cached: 1.25 },
    'openai/gpt-4o-mini': { input: 0.15, output: 0.60, cached: 0.075 },
    'openai/gpt-4': { input: 30.00, output: 60.00, cached: 15.00 },
    'openai/gpt-4-turbo': { input: 10.00, output: 30.00, cached: 5.00 },
    'openai/o1': { input: 15.00, output: 60.00, cached: 7.50 },
    'openai/o3-mini': { input: 1.10, output: 4.40, cached: 0.55 },
    // Google models (via OpenCode)
    'google/gemini-2.5-pro': { input: 1.25, output: 10.00, cached: 0.31 },
    'google/gemini-2.5-flash': { input: 0.15, output: 0.60, cached: 0.0375 },
    'google/gemini-2.0-flash': { input: 0.10, output: 0.40, cached: 0.025 },
    'google/gemini-pro': { input: 1.25, output: 5.00, cached: 0.31 },
    // Local models (no cost)
    'local/llama': { input: 0, output: 0, cached: 0 },
    'local/codellama': { input: 0, output: 0, cached: 0 },
    'local/mistral': { input: 0, output: 0, cached: 0 },
    // Default fallback - moderate estimate (assumes Anthropic Sonnet-class model)
    '_default': { input: 3.00, output: 15.00, cached: 0.375 }
  }
};

/**
 * Find the best matching pricing for a model
 * Supports partial matching (e.g., "gemini-2.5-flash-exp" matches "gemini-2.5-flash")
 *
 * @param {string} providerId - Provider identifier (gemini, codex, cursor, claude)
 * @param {string} modelId - Model identifier
 * @returns {Object} Pricing object with input, output, cached rates per million tokens
 */
export function getModelPricing(providerId, modelId) {
  const providerPricing = MODEL_PRICING[providerId];

  if (!providerPricing) {
    // Unknown provider, return zeros (no cost estimation)
    return { input: 0, output: 0, cached: 0 };
  }

  // Normalize model ID for matching
  const normalizedModel = (modelId || '').toLowerCase().trim();

  // Try exact match first
  if (providerPricing[normalizedModel]) {
    return providerPricing[normalizedModel];
  }

  // Try prefix matching (for versioned models like gemini-2.5-flash-preview-04-17)
  for (const [key, pricing] of Object.entries(providerPricing)) {
    if (key !== '_default' && normalizedModel.startsWith(key)) {
      return pricing;
    }
  }

  // Try substring matching (for models with suffixes)
  for (const [key, pricing] of Object.entries(providerPricing)) {
    if (key !== '_default' && (normalizedModel.includes(key) || key.includes(normalizedModel))) {
      return pricing;
    }
  }

  // Return provider default if available
  return providerPricing['_default'] || { input: 0, output: 0, cached: 0 };
}

/**
 * Calculate estimated cost for a task based on token usage
 *
 * @param {Object} options - Calculation options
 * @param {string} options.providerId - Provider identifier (gemini, codex, cursor, claude)
 * @param {string} options.modelId - Model identifier
 * @param {number} options.inputTokens - Number of input tokens (optional)
 * @param {number} options.outputTokens - Number of output tokens (optional)
 * @param {number} options.cachedTokens - Number of cached input tokens (optional)
 * @param {number} options.totalTokens - Total tokens if input/output not separated
 * @returns {Object} Cost breakdown: { inputCost, outputCost, cachedCost, totalCost, currency: 'USD' }
 */
export function calculateTokenCost({ providerId, modelId, inputTokens = 0, outputTokens = 0, cachedTokens = 0, totalTokens = 0 }) {
  const pricing = getModelPricing(providerId, modelId);

  // If we have input/output breakdown, use that
  if (inputTokens > 0 || outputTokens > 0) {
    const inputCost = (inputTokens / 1_000_000) * pricing.input;
    const outputCost = (outputTokens / 1_000_000) * pricing.output;
    const cachedCost = (cachedTokens / 1_000_000) * pricing.cached;

    return {
      inputCost: roundCost(inputCost),
      outputCost: roundCost(outputCost),
      cachedCost: roundCost(cachedCost),
      totalCost: roundCost(inputCost + outputCost + cachedCost),
      currency: 'USD',
      estimated: true,
      pricingUsed: pricing
    };
  }

  // If we only have total tokens, estimate 30% input / 70% output ratio
  // This is a rough estimate - actual ratios vary by task type
  if (totalTokens > 0) {
    const estimatedInput = Math.round(totalTokens * 0.3);
    const estimatedOutput = Math.round(totalTokens * 0.7);

    const inputCost = (estimatedInput / 1_000_000) * pricing.input;
    const outputCost = (estimatedOutput / 1_000_000) * pricing.output;

    return {
      inputCost: roundCost(inputCost),
      outputCost: roundCost(outputCost),
      cachedCost: 0,
      totalCost: roundCost(inputCost + outputCost),
      currency: 'USD',
      estimated: true,
      estimatedRatio: '30/70',
      pricingUsed: pricing
    };
  }

  // No tokens, no cost
  return {
    inputCost: 0,
    outputCost: 0,
    cachedCost: 0,
    totalCost: 0,
    currency: 'USD',
    estimated: false
  };
}

/**
 * Round cost to 6 decimal places for precision
 * @param {number} cost - Raw cost
 * @returns {number} Rounded cost
 */
function roundCost(cost) {
  return Math.round(cost * 1_000_000) / 1_000_000;
}

/**
 * Get all known model IDs for a provider
 * @param {string} providerId - Provider identifier
 * @returns {string[]} Array of model IDs (excluding _default)
 */
export function getKnownModels(providerId) {
  const providerPricing = MODEL_PRICING[providerId];
  if (!providerPricing) return [];

  return Object.keys(providerPricing).filter(key => key !== '_default');
}

/**
 * Get all known provider IDs
 * @returns {string[]} Array of provider IDs
 */
export function getKnownProviders() {
  return Object.keys(MODEL_PRICING);
}

/**
 * Check if a provider has pricing data available
 * @param {string} providerId - Provider identifier
 * @returns {boolean} True if pricing data exists
 */
export function hasPricingData(providerId) {
  return MODEL_PRICING[providerId] !== undefined;
}

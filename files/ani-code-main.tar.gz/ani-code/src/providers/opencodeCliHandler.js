import { spawn, execSync } from 'child_process';
import { BaseCliHandler } from './baseCliHandler.js';
import { stripPatternsFromPrompt } from '../model-utils.js';

/**
 * OpenCode CLI Handler - Implementation for OpenCode terminal-based AI assistant
 *
 * OpenCode is an open-source terminal-based AI coding assistant that works with
 * multiple AI backends (OpenAI, Anthropic, Google, local models).
 *
 * Binary: 'opencode'
 *
 * Key features:
 * - Non-interactive mode via 'opencode run [message..]'
 * - Model selection via -m/--model flag in format 'provider/model'
 * - Session continuation via -c/--continue or -s/--session <id>
 * - Stats tracking via 'opencode stats' command
 * - Supports multiple AI backends
 *
 * Installation: See https://github.com/sst/opencode
 */
export class OpenCodeCliHandler extends BaseCliHandler {
  constructor(config = {}) {
    super({
      id: config.id || 'opencode',
      name: config.name || 'OpenCode',
      binary: config.binary || 'opencode',
      args: config.args || [],
      env: config.env || {}
    });
  }

  /**
   * Get default configuration for OpenCode
   * @returns {Object} Default configuration
   */
  static getDefaults() {
    return {
      binary: 'opencode',
      args: [],
      env: {}
    };
  }

  /**
   * Create a new task with OpenCode
   */
  async createTask(options) {
    const {
      command,
      workingDir = process.cwd(),
      modelPreference = null,
      interactive = false,
      taskId = null,
      skipHints = false
    } = options;

    const args = ['run'];

    // Add custom args from config first
    if (this.args.length > 0) {
      args.push(...this.args);
    }

    // Add model preference if specified
    if (modelPreference) {
      args.push(...this.getModelFlags(modelPreference));
    }

    // For non-interactive mode
    if (!interactive) {
      // Strip model/provider patterns from command before sending to CLI
      const cleanedCommand = stripPatternsFromPrompt(command);

      // Add fixed postfix for non-Claude providers to read CLAUDE.md
      const commandWithPostfix = `${cleanedCommand}\n\n(Before you start, read CLAUDE.md in the folder to understand basic rules of the process)`;

      // Process prompt with hints - injects active hints and saves to file if too long
      const { finalPrompt } = await this.processPromptWithHints(commandWithPostfix, workingDir, taskId, { skipHints });

      // Add the prompt as message argument
      args.push(finalPrompt);
    }

    return this.spawnProcess(args, workingDir);
  }

  /**
   * Continue an existing conversation
   *
   * OpenCode supports -c/--continue to resume the last session
   * or -s/--session <id> for specific session continuation.
   * For provider-switching scenarios, we use context simulation.
   */
  async continueTask(options) {
    const {
      prompt = 'continue',
      taskQueue = null,
      taskId = null,
      sessionId = null,
      skipHints = false,
      ...otherOptions
    } = options;

    const workingDir = options.workingDir || process.cwd();
    const cleanedPrompt = stripPatternsFromPrompt(prompt);

    // Build context for continuation
    let command = cleanedPrompt || 'Please continue with the previous task';

    // Build full conversation history context (like other handlers do)
    if (taskQueue && !options.interactive) {
      const conversationHistory = taskQueue.getConversationHistory(workingDir, 5);
      if (conversationHistory.length > 0) {
        // Build context from conversation chain
        const contextParts = conversationHistory.map((turn, index) => {
          return `[Turn ${index + 1}] (Provider: ${turn.providerId || 'unknown'})
User: ${turn.prompt}
Assistant: ${turn.response}`;
        }).join('\n\n');

        command = `Previous conversation history:

${contextParts}

[Current request]
User: ${cleanedPrompt}`;
      }
    }

    // If we have a session ID, use native session continuation
    if (sessionId) {
      return this.continueSession({ ...otherOptions, command, workingDir, taskId, sessionId, skipHints });
    }

    // Otherwise use greenlightTask to execute with context
    return this.greenlightTask({ ...otherOptions, command, workingDir, taskId, skipHints });
  }

  /**
   * Continue a specific OpenCode session
   */
  async continueSession(options) {
    const {
      command,
      workingDir = process.cwd(),
      modelPreference = null,
      sessionId,
      taskId = null,
      skipHints = false
    } = options;

    const args = ['run'];

    // Add custom args from config first
    if (this.args.length > 0) {
      args.push(...this.args);
    }

    // Use session continuation
    if (sessionId) {
      args.push('-s', sessionId);
    } else {
      args.push('-c'); // Continue last session
    }

    // Add model preference if specified
    if (modelPreference) {
      args.push(...this.getModelFlags(modelPreference));
    }

    // Strip model/provider patterns from command before sending to CLI
    const cleanedCommand = stripPatternsFromPrompt(command);

    // Process prompt with hints - injects active hints and saves to file if too long
    const { finalPrompt } = await this.processPromptWithHints(cleanedCommand, workingDir, taskId, { skipHints });

    // Add the prompt as message argument
    args.push(finalPrompt);

    return this.spawnProcess(args, workingDir);
  }

  /**
   * Execute with auto-approve mode (greenlight)
   * OpenCode doesn't have explicit auto-approve flags like some CLIs,
   * so this uses the same execution path as createTask.
   */
  async greenlightTask(options) {
    const {
      command,
      workingDir = process.cwd(),
      modelPreference = null,
      taskId = null,
      skipHints = false
    } = options;

    const args = ['run'];

    // Add custom args from config first
    if (this.args.length > 0) {
      args.push(...this.args);
    }

    // Add model preference if specified
    if (modelPreference) {
      args.push(...this.getModelFlags(modelPreference));
    }

    // Strip model/provider patterns from command before sending to CLI
    const cleanedCommand = stripPatternsFromPrompt(command);

    // Add fixed postfix for non-Claude providers to read CLAUDE.md
    const commandWithPostfix = `${cleanedCommand}\n\n(Before you start, read CLAUDE.md in the folder to understand basic rules of the process)`;

    // Process prompt with hints - injects active hints and saves to file if too long
    const { finalPrompt } = await this.processPromptWithHints(commandWithPostfix, workingDir, taskId, { skipHints });

    // Add the prompt as message argument
    args.push(finalPrompt);

    return this.spawnProcess(args, workingDir);
  }

  /**
   * Get model-specific flags
   * OpenCode supports -m/--model flag with format 'provider/model'
   * e.g., 'openai/gpt-4', 'anthropic/claude-3-opus', 'google/gemini-pro'
   */
  getModelFlags(modelPreference) {
    const flags = [];

    if (!modelPreference) {
      return flags;
    }

    const normalizedModel = modelPreference.toLowerCase().trim();

    // If model preference already includes provider prefix, use as-is
    if (normalizedModel.includes('/')) {
      flags.push('-m', normalizedModel);
      return flags;
    }

    // Map common model preferences to OpenCode format
    switch (normalizedModel) {
      // Anthropic models
      case 'sonnet':
      case 'claude-sonnet':
      case 'claude-sonnet-4':
        flags.push('-m', 'anthropic/claude-sonnet-4-20250514');
        break;
      case 'opus':
      case 'claude-opus':
      case 'claude-opus-4':
        flags.push('-m', 'anthropic/claude-opus-4-20250514');
        break;
      case 'haiku':
      case 'claude-haiku':
        flags.push('-m', 'anthropic/claude-3-5-haiku-20241022');
        break;

      // OpenAI models
      case 'gpt-4':
      case 'gpt4':
        flags.push('-m', 'openai/gpt-4');
        break;
      case 'gpt-4o':
      case 'gpt4o':
        flags.push('-m', 'openai/gpt-4o');
        break;
      case 'o1':
        flags.push('-m', 'openai/o1');
        break;
      case 'o3-mini':
        flags.push('-m', 'openai/o3-mini');
        break;

      // Google models
      case 'gemini':
      case 'gemini-pro':
        flags.push('-m', 'google/gemini-2.0-flash');
        break;
      case 'gemini-flash':
        flags.push('-m', 'google/gemini-2.5-flash');
        break;

      default:
        // Pass through other model names - user may specify provider/model directly
        // or just the model name (OpenCode may auto-detect provider)
        flags.push('-m', normalizedModel);
    }

    return flags;
  }

  /**
   * Spawn the CLI process
   */
  spawnProcess(args, workingDir) {
    console.log(`🔧 Executing: ${this.binary} ${args.join(' ')}`);
    console.log(`📁 Working directory: ${workingDir}`);

    const env = { ...process.env, ...this.env };

    const child = spawn(this.binary, args, {
      stdio: ['pipe', 'pipe', 'pipe'],
      shell: false,
      cwd: workingDir,
      env,
      detached: false
    });

    // Add debug handlers to track process lifecycle
    child.on('exit', (code, signal) => {
      console.log(`[OPENCODE] Process exited with code ${code}, signal ${signal}`);
    });

    child.on('close', (code, signal) => {
      console.log(`[OPENCODE] Process closed with code ${code}, signal ${signal}`);
    });

    child.on('error', (err) => {
      console.error(`[OPENCODE] Process error: ${err.message}`);
    });

    // Close stdin for non-interactive mode
    child.stdin.end();

    return child;
  }

  /**
   * Validate if the handler is properly configured
   */
  validate() {
    try {
      // Try to find opencode in PATH
      execSync(`which ${this.binary}`, { encoding: 'utf8' });
      return true;
    } catch {
      throw new Error(`Binary not found in PATH: ${this.binary}`);
    }
  }

  /**
   * Get handler capabilities
   */
  getCapabilities() {
    return {
      supportsCreate: true,
      supportsContinue: true,
      supportsGreenlight: true,
      supportsModels: true,
      supportsPrintMode: true,  // Uses 'run' command for non-interactive
      supportsInteractive: true,
      supportsCcusage: false,   // OpenCode doesn't use ccusage API
      supportsImages: false,    // Image support TBD
      highPrivilege: true       // Skip permission checks (non-Claude provider)
    };
  }
}

export default OpenCodeCliHandler;

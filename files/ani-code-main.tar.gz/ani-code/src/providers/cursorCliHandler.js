import { spawn, execSync } from 'child_process';
import { BaseCliHandler } from './baseCliHandler.js';
import { stripPatternsFromPrompt } from '../model-utils.js';

/**
 * Cursor CLI Handler - Implementation for Cursor Agent
 */
export class CursorCliHandler extends BaseCliHandler {
  constructor(config = {}) {
    super({
      id: config.id || 'cursor',
      name: config.name || 'Cursor Agent',
      binary: config.binary || 'cursor-agent',
      args: config.args || [],
      env: config.env || {}
    });
  }

  /**
   * Get default configuration for Cursor
   * @param {string} providerId - The provider ID
   * @returns {Object} Default configuration
   */
  static getDefaults(providerId) {
    return {
      binary: 'cursor-agent',
      args: [],
      env: {}
    };
  }

  /**
   * Create a new task with Cursor Agent
   */
  async createTask(options) {
    const {
      command,
      workingDir = process.cwd(),
      modelPreference = null,
      interactive = false,
      logStream = null,
      taskId = null
    } = options;

    const args = [];

    // Use print mode for non-interactive output
    if (!interactive) {
      args.push('--print');
      args.push('--output-format', 'text');
    }

    // Add model preference if specified (e.g., gpt-5, sonnet-4, sonnet-4-thinking)
    if (modelPreference) {
      // Cursor might support different models, pass as-is if recognized
      // For sonnet/opus from our system, map appropriately
      if (modelPreference === 'sonnet' || modelPreference === 'opus') {
        console.warn(`⚠️ Model '${modelPreference}' may not be supported by Cursor, using default`);
        // Don't pass the model flag, let Cursor use its default
      } else {
        args.push('--model', modelPreference);
      }
    }

    // Add custom args from config
    if (this.args.length > 0) {
      args.push(...this.args);
    }

    // Strip model/provider patterns from command before sending to CLI
    const cleanedCommand = stripPatternsFromPrompt(command);

    // Add fixed postfix for non-Claude providers to read CLAUDE.md
    const commandWithPostfix = `${cleanedCommand}\n\n(Before you start, read CLAUDE.md in the folder to understand basic rules of the process)`;

    // Process prompt - save to file if too long to avoid shell exec issues
    const { finalPrompt } = this.processPromptForCli(commandWithPostfix, workingDir, taskId);

    // Add the final prompt (either direct or file reference)
    args.push(finalPrompt);

    return this.spawnProcess(args, workingDir, logStream);
  }

  /**
   * Continue an existing conversation
   *
   * Cursor doesn't support --resume with prompt in daemon mode,
   * so we simulate continuation by creating a new task with previous context.
   */
  async continueTask(options) {
    const {
      prompt = 'continue',
      taskQueue = null,
      taskId = null,
      ...otherOptions
    } = options;

    const workingDir = options.workingDir || process.cwd();
    const cleanedPrompt = stripPatternsFromPrompt(prompt);
    let command = cleanedPrompt || 'Please continue with the previous task';

    // Build full conversation history context
    if (taskQueue && !options.interactive) {
      const conversationHistory = taskQueue.getConversationHistory(workingDir, 5);
      if (conversationHistory.length > 0) {
        // Build context from conversation chain
        const contextParts = conversationHistory.map((turn, index) => {
          return `[Turn ${index + 1}]
User: ${turn.prompt}
Assistant: ${turn.response}`;
        }).join('\n\n');

        command = `Previous conversation history:

${contextParts}

[Current request]
User: ${cleanedPrompt}`;
      }
    }

    // Use createTask to execute as a new task with context
    // (file-based prompt handling happens in createTask)
    return this.createTask({ ...otherOptions, command, workingDir, taskId });
  }

  /**
   * Execute with auto-approve mode (greenlight)
   */
  async greenlightTask(options) {
    const {
      command,
      workingDir = process.cwd(),
      modelPreference = null,
      logStream = null,
      taskId = null
    } = options;

    const args = [];

    // Use print mode for non-interactive output
    args.push('--print');
    args.push('--output-format', 'text');

    // Force flag to allow commands unless explicitly denied
    args.push('--force');

    // Add model preference if specified
    if (modelPreference) {
      // Cursor might support different models, pass as-is if recognized
      // For sonnet/opus from our system, map appropriately
      if (modelPreference === 'sonnet' || modelPreference === 'opus') {
        console.warn(`⚠️ Model '${modelPreference}' may not be supported by Cursor, using default`);
        // Don't pass the model flag, let Cursor use its default
      } else {
        args.push('--model', modelPreference);
      }
    }

    // Add custom args from config
    if (this.args.length > 0) {
      args.push(...this.args);
    }

    // Strip model/provider patterns from command before sending to CLI
    const cleanedCommand = stripPatternsFromPrompt(command);

    // Add fixed postfix for non-Claude providers to read CLAUDE.md
    const commandWithPostfix = `${cleanedCommand}\n\n(Before you start, read CLAUDE.md in the folder to understand basic rules of the process)`;

    // Process prompt - save to file if too long to avoid shell exec issues
    const { finalPrompt } = this.processPromptForCli(commandWithPostfix, workingDir, taskId);

    // Add the final prompt (either direct or file reference)
    args.push(finalPrompt);

    return this.spawnProcess(args, workingDir, logStream);
  }

  /**
   * Spawn the CLI process
   */
  spawnProcess(args, workingDir, logStream) {
    console.log(`🔧 Executing: ${this.binary} ${args.join(' ')}`);
    console.log(`📁 Working directory: ${workingDir}`);

    // Ensure API key is set if needed
    const env = { ...process.env, ...this.env };
    if (!env.CURSOR_API_KEY && this.env.CURSOR_API_KEY) {
      env.CURSOR_API_KEY = this.env.CURSOR_API_KEY;
    }

    const child = spawn(this.binary, args, {
      stdio: ['pipe', 'pipe', 'pipe'],
      shell: false,
      cwd: workingDir,
      env
    });

    // Close stdin for non-interactive mode
    child.stdin.end();

    return child;
  }

  /**
   * Validate if the handler is properly configured
   */
  validate() {
    try {
      // Try to find cursor-agent in PATH
      execSync(`which ${this.binary}`, { encoding: 'utf8' });
      return true;
    } catch (error) {
      throw new Error(`Binary not found in PATH: ${this.binary}`);
    }
  }

  /**
   * Get handler capabilities
   */
  getCapabilities() {
    return {
      supportsCreate: true,
      supportsContinue: true,
      supportsGreenlight: true,
      supportsModels: true,
      supportsPrintMode: true,
      supportsInteractive: true,
      supportsCcusage: false,  // Cursor doesn't support ccusage tracking
      highPrivilege: true  // Skip permission checks for non-Claude provider
    };
  }
}

export default CursorCliHandler;
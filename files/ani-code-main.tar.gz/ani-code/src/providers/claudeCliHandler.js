import { spawn, execSync } from 'child_process';
import { existsSync } from 'fs';
import { BaseCliHandler } from './baseCliHandler.js';
import { stripPatternsFromPrompt } from '../model-utils.js';
import { buildPromptWithImageUrls } from '../services/imageHandler.js';

/**
 * Claude CLI Handler - Default implementation for Claude Code
 */
export class ClaudeCliHandler extends BaseCliHandler {
  constructor(config = {}) {
    super({
      id: config.id || 'claude',
      name: config.name || 'Claude Code',
      binary: config.binary || ClaudeCliHandler.findClaudeBinary(),
      args: config.args || [],
      env: config.env || {}
    });
  }

  /**
   * Find the Claude binary in common locations
   * @returns {string} Path to Claude binary or 'claude' as fallback
   */
  static findClaudeBinary() {
    const commonPaths = [
      '/usr/local/bin/claude',
      '/usr/bin/claude',
      '/opt/homebrew/bin/claude'  // macOS Homebrew ARM
    ];

    // Check common paths first
    for (const path of commonPaths) {
      if (existsSync(path)) {
        return path;
      }
    }

    // Fall back to 'claude' and let which() find it in PATH
    try {
      execSync('which claude', { stdio: 'pipe' });
      return 'claude';
    } catch {
      // If not found anywhere, return default (will fail validation later)
      return '/usr/bin/claude';
    }
  }

  /**
   * Get default configuration based on provider ID
   * @param {string} providerId - The provider ID (e.g., 'claude', 'deepseek', 'ccr', 'glm')
   * @param {string} handlerType - The handler type (e.g., 'claude', 'customClaude')
   * @returns {Object} Default configuration
   */
  static getDefaults(providerId, handlerType = null) {
    // customClaude handlers always use ccr binary by default
    // This allows users to configure providers like 'bygemini' with just:
    //   CLI_PROVIDER_BYGEMINI_HANDLER=customClaude
    //   CLI_PROVIDER_BYGEMINI_NAME=bygemini
    // without needing to specify BINARY and ARGS
    if (handlerType === 'customClaude') {
      return {
        binary: 'ccr',
        args: ['code'],
        env: {}
      };
    }

    // CCR and ccr-* variants use ccr binary
    if (providerId === 'ccr' || providerId.startsWith('ccr-')) {
      return {
        binary: 'ccr',
        args: ['code'],
        env: {}
      };
    }

    // GLM uses ccr binary with code command
    if (providerId === 'glm') {
      return {
        binary: 'ccr',
        args: ['code'],
        env: {}
      };
    }

    // DeepSeek uses ccr binary with code command
    if (providerId === 'deepseek') {
      return {
        binary: 'ccr',
        args: ['code'],
        env: {}
      };
    }

    // Default Claude configuration - use intelligent binary lookup
    return {
      binary: ClaudeCliHandler.findClaudeBinary(),
      args: [],
      env: {}
    };
  }

  /**
   * Create a new task with Claude
   */
  async createTask(options) {
    const {
      command,
      workingDir = process.cwd(),
      modelPreference = null,
      interactive = false,
      logStream = null,
      taskId = null,
      images = [],
      skipHints = false
    } = options;

    const args = [];

    // Add custom args from config FIRST (e.g., 'code' subcommand for ccr)
    if (this.args.length > 0) {
      args.push(...this.args);
    }

    // Add print mode for non-interactive output
    if (!interactive) {
      args.push('--print');
    }

    // Permissions are handled via settings preset from 'ani-code init'
    // Greenlight mode (--dangerously-skip-permissions) is only used when
    // explicitly granted by the user via /grant command

    // Add model preference if specified
    if (modelPreference) {
      args.push(...this.getModelFlags(modelPreference));
    }

    // Strip model/provider patterns from command before sending to CLI
    const cleanedCommand = stripPatternsFromPrompt(command);

    // Build prompt with image URLs if present (uses shared utility)
    const finalCommand = buildPromptWithImageUrls(cleanedCommand, images);
    if (images && images.length > 0) {
      console.log(`📷 Including ${images.length} image URL(s) in prompt`);
    }

    // Process prompt with hints - injects active hints and saves to file if too long
    const { finalPrompt } = await this.processPromptWithHints(finalCommand, workingDir, taskId, { skipHints });

    // Add the final prompt (either direct or file reference)
    args.push(finalPrompt);

    return this.spawnProcess(args, workingDir, logStream);
  }

  /**
   * Continue an existing task/conversation
   */
  async continueTask(options) {
    const {
      prompt = 'continue',
      workingDir = process.cwd(),
      modelPreference = null,
      interactive = false,
      logStream = null,
      taskQueue = null,
      taskId = null,
      images = [],
      skipHints = false,
      skipPermissions = false
    } = options;

    // Check if provider has switched from previous task
    // If provider switched, use context simulation instead of native continue
    if (taskQueue && !interactive) {
      const conversationHistory = taskQueue.getConversationHistory(workingDir, 5);

      // Check if there are previous tasks and if any used a different provider
      if (conversationHistory.length > 0) {
        const hasProviderSwitch = conversationHistory.some(turn =>
          turn.providerId && turn.providerId !== this.id && turn.providerId !== 'claude'
        );

        if (hasProviderSwitch) {
          // Provider switched - use context simulation instead of native -c
          console.log(`⚠️  Provider switch detected - using context simulation for Claude continue`);

          const cleanedPrompt = stripPatternsFromPrompt(prompt);
          const contextParts = conversationHistory.map((turn, index) => {
            return `[Turn ${index + 1}] (Provider: ${turn.providerId || 'unknown'})
User: ${turn.prompt}
Assistant: ${turn.response}`;
          }).join('\n\n');

          const command = `Previous conversation history:

${contextParts}

[Current request]
User: ${cleanedPrompt}`;

          // Use createTask instead of native continue
          return this.createTask({ ...options, command, workingDir, taskId, skipHints });
        }
      }
    }

    // No provider switch - use native Claude continue with -c flag
    const args = [];

    // Add custom args from config FIRST (e.g., 'code' subcommand for ccr)
    if (this.args.length > 0) {
      args.push(...this.args);
    }

    // Add print mode for non-interactive output
    if (!interactive) {
      args.push('--print');
    }

    // Skip permissions when explicitly granted by user via /grant command
    if (skipPermissions) {
      args.push('--dangerously-skip-permissions');
    }

    // Add model preference if specified
    if (modelPreference) {
      args.push(...this.getModelFlags(modelPreference));
    }

    // Strip model/provider patterns from prompt before sending to CLI
    const cleanedPrompt = stripPatternsFromPrompt(prompt);

    // Build prompt with image URLs if present (uses shared utility)
    const finalCommandPrompt = buildPromptWithImageUrls(cleanedPrompt, images);
    if (images && images.length > 0) {
      console.log(`📷 Including ${images.length} image URL(s) in continue prompt`);
    }

    // Process prompt with hints - injects active hints and saves to file if too long
    const { finalPrompt } = await this.processPromptWithHints(finalCommandPrompt, workingDir, taskId, { skipHints });

    // Add continue flag with final prompt (either direct or file reference)
    args.push('-c', finalPrompt);

    return this.spawnProcess(args, workingDir, logStream);
  }

  /**
   * Execute with greenlight mode (auto-approve all actions)
   */
  async greenlightTask(options) {
    const {
      command,
      workingDir = process.cwd(),
      modelPreference = null,
      logStream = null,
      taskId = null,
      images = [],
      skipHints = false
    } = options;

    const args = [];

    // Add custom args from config FIRST (e.g., 'code' subcommand for ccr)
    if (this.args.length > 0) {
      args.push(...this.args);
    }

    // Always add --dangerously-skip-permissions for auto-approval in daemon mode
    args.push('--dangerously-skip-permissions');

    // Add model preference if specified
    if (modelPreference) {
      args.push(...this.getModelFlags(modelPreference));
    }

    // Strip model/provider patterns from command before sending to CLI
    const cleanedCommand = stripPatternsFromPrompt(command);

    // Build prompt with image URLs if present (uses shared utility)
    const finalCommand = buildPromptWithImageUrls(cleanedCommand, images);
    if (images && images.length > 0) {
      console.log(`📷 Including ${images.length} image URL(s) in greenlight prompt`);
    }

    // Process prompt with hints - injects active hints and saves to file if too long
    const { finalPrompt } = await this.processPromptWithHints(finalCommand, workingDir, taskId, { skipHints });

    // Add the final prompt (either direct or file reference)
    args.push(finalPrompt);

    return this.spawnProcess(args, workingDir, logStream);
  }

  /**
   * Get model-specific flags
   */
  getModelFlags(modelPreference) {
    const flags = [];

    if (!modelPreference) {
      return flags;
    }

    // Skip model flags for customClaude providers (they handle model selection internally)
    if (this.isCustomClaude()) {
      return flags;
    }

    // The model preference should already be extracted properly by model-utils.js
    // It should be just 'sonnet' or 'opus' at this point
    switch(modelPreference.toLowerCase()) {
      case 'sonnet':
        flags.push('--model', 'sonnet');
        break;
      case 'opus':
        flags.push('--model', 'opus');
        break;
      default:
        // For unknown models, log a warning and don't pass any model flag
        // This allows the CLI to use its default model
        console.warn(`⚠️ Unknown model preference '${modelPreference}', using CLI default`);
        // Don't add any flags - let CLI use its default
    }

    return flags;
  }

  /**
   * Check if this is a customClaude provider (not the official Claude binary)
   */
  isCustomClaude() {
    // customClaude providers are those that:
    // 1. Don't use the official /usr/bin/claude binary
    // 2. Use alternative binaries like ccr, glm, deepseek, etc.
    return this.id !== 'claude' && this.binary !== '/usr/bin/claude';
  }

  /**
   * Spawn the CLI process
   */
  spawnProcess(args, workingDir, logStream) {
    console.log(`🔧 Executing: ${this.binary} ${args.join(' ')}`);
    console.log(`📁 Working directory: ${workingDir}`);

    const child = spawn(this.binary, args, {
      stdio: ['pipe', 'pipe', 'pipe'],
      shell: false,
      cwd: workingDir,
      env: { ...process.env, ...this.env }
    });

    // Close stdin as Claude doesn't need input in daemon mode
    child.stdin.end();

    return child;
  }

  /**
   * Validate if the handler is properly configured
   */
  validate() {
    // Check if binary exists - handle both absolute paths and PATH binaries
    if (this.binary.includes('/')) {
      // Absolute or relative path - use existsSync
      if (!existsSync(this.binary)) {
        throw new Error(`Binary not found: ${this.binary}`);
      }
    } else {
      // Binary in PATH - use 'which' command to check
      try {
        execSync(`which ${this.binary}`, { stdio: 'pipe' });
      } catch (error) {
        throw new Error(`Binary not found in PATH: ${this.binary}`);
      }
    }

    return true;
  }

  /**
   * Get handler capabilities
   */
  getCapabilities() {
    return {
      supportsCreate: true,
      supportsContinue: true,
      supportsGreenlight: true,
      supportsModels: true,
      supportsPrintMode: true,
      supportsInteractive: true,
      supportsCcusage: true,  // Both claude and ccr (customClaude) use Claude CLI which writes to ccusage-trackable logs
      supportsImages: true    // Claude supports multimodal image input
    };
  }
}

export default ClaudeCliHandler;
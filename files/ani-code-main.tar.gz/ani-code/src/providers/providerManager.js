import { ClaudeCliHandler } from './claudeCliHandler.js';
import { CursorCliHandler } from './cursorCliHandler.js';
import { CodexCliHandler } from './codexCliHandler.js';
import { GeminiCliHandler } from './geminiCliHandler.js';
import { CopilotCliHandler } from './copilotCliHandler.js';
import { OpenCodeCliHandler } from './opencodeCliHandler.js';
import { BaseCliHandler } from './baseCliHandler.js';
import { config } from '../config.js';
import { getKnownModels, getModelPricing, MODEL_PRICING } from './costCalculator.js';
import dotenv from 'dotenv';
import { existsSync } from 'fs';
import { WorkspaceManager } from '../workspace-manager.js';

// Load environment variables
dotenv.config();

/**
 * Provider Manager - Handles CLI provider configuration and instantiation
 */
export class ProviderManager {
  constructor() {
    this.handlers = new Map();
    this.currentHandler = null;
    this.workspaceManager = null;
    this.initialized = false;
    this.loadProviders();
  }

  /**
   * Load providers from environment configuration
   */
  async loadProviders() {
    if (this.initialized) {
      return;
    }

    // Register built-in handlers
    this.registerBuiltInHandlers();

    // Initialize workspace manager
    this.workspaceManager = new WorkspaceManager();
    await this.workspaceManager.initialize();

    // Load all built-in providers with defaults
    this.loadBuiltInProviders();

    // Load custom providers from environment
    this.loadCustomProviders();

    // Determine current provider based on priority:
    // 1. CLI_PROVIDER_ID or PROVIDER_ID env var (for immediate override)
    // 2. Workspace meta setting
    // 3. Default to claude
    await this.selectCurrentProvider();

    this.initialized = true;
  }

  /**
   * Load built-in providers with smart defaults
   */
  loadBuiltInProviders() {
    // Helper function to merge defaults with env config
    const mergeWithEnvConfig = (providerId, defaults) => {
      const envConfig = this.parseProviderConfig(providerId);
      if (envConfig) {
        // Environment config takes precedence
        return {
          ...defaults,
          ...envConfig,
          // Merge env vars (defaults first, then overrides)
          env: { ...defaults.env, ...envConfig.env }
        };
      }
      return defaults;
    };

    // Claude - always available
    const claudeConfig = mergeWithEnvConfig('claude', {
      id: 'claude',
      name: 'Claude Code',
      binary: 'claude'  // Use PATH lookup
    });
    const claude = new ClaudeCliHandler(claudeConfig);
    this.handlers.set('claude', claude);

    // Cursor - with smart defaults
    const cursorConfig = mergeWithEnvConfig('cursor', {
      id: 'cursor',
      name: 'Cursor Agent',
      binary: 'cursor-agent'  // Assumes cursor-agent is in PATH
    });
    const cursor = new CursorCliHandler(cursorConfig);
    this.handlers.set('cursor', cursor);

    // Codex - with smart defaults
    const codexConfig = mergeWithEnvConfig('codex', {
      id: 'codex',
      name: 'OpenAI Codex',
      binary: 'codex'  // Assumes codex is in PATH
    });
    const codex = new CodexCliHandler(codexConfig);
    this.handlers.set('codex', codex);

    // Note: GLM and other customClaude providers should be configured via env vars:
    // CLI_PROVIDER_GLM_HANDLER=customClaude
    // CLI_PROVIDER_GLM_NAME=GLM

    // Gemini - with smart defaults
    const geminiConfig = mergeWithEnvConfig('gemini', {
      id: 'gemini',
      name: 'Gemini CLI',
      binary: 'gemini'  // Assumes gemini is in PATH
    });
    const gemini = new GeminiCliHandler(geminiConfig);
    this.handlers.set('gemini', gemini);

    // Copilot - with smart defaults
    const copilotConfig = mergeWithEnvConfig('copilot', {
      id: 'copilot',
      name: 'GitHub Copilot',
      binary: 'copilot'  // Assumes copilot is in PATH
    });
    const copilot = new CopilotCliHandler(copilotConfig);
    this.handlers.set('copilot', copilot);

    // OpenCode - with smart defaults
    const opencodeConfig = mergeWithEnvConfig('opencode', {
      id: 'opencode',
      name: 'OpenCode',
      binary: 'opencode'  // Assumes opencode is in PATH
    });
    const opencode = new OpenCodeCliHandler(opencodeConfig);
    this.handlers.set('opencode', opencode);

    // Providers will be logged after selection in selectCurrentProvider()
    // Don't log here to avoid duplication
  }

  /**
   * Load custom providers from environment variables
   */
  loadCustomProviders() {
    // Look for any custom provider configurations in env
    // Pattern: CLI_PROVIDER_<ID>_HANDLER=customClaude
    const customProviderIds = new Set();

    Object.keys(process.env).forEach(key => {
      const match = key.match(/^CLI_PROVIDER_([A-Z_]+)_HANDLER$/);
      if (match && process.env[key] === 'customClaude') {
        const id = match[1].toLowerCase().replace(/_/g, '-');
        if (!['claude', 'cursor', 'codex', 'gemini', 'copilot', 'opencode'].includes(id)) {
          customProviderIds.add(id);
        }
      }
    });

    customProviderIds.forEach(id => {
      const config = this.parseProviderConfig(id);
      if (config && config.handler === 'customClaude') {
        this.initializeProvider(config);
      }
    });
  }

  /**
   * Select current provider based on priority
   */
  async selectCurrentProvider() {
    let providerId = null;

    // Priority 1: CLI_PROVIDER_ID or PROVIDER_ID env var (immediate override)
    if (process.env.CLI_PROVIDER_ID || process.env.PROVIDER_ID) {
      providerId = process.env.CLI_PROVIDER_ID || process.env.PROVIDER_ID;
    }
    // Priority 2: Check workspace meta for current directory
    else {
      try {
        const currentPath = process.cwd();
        const workspaces = await this.workspaceManager.listWorkspaces();
        const currentWorkspace = workspaces.find(w => w.path === currentPath);

        if (currentWorkspace) {
          const cliProvider = await this.workspaceManager.getWorkspaceMeta(
            currentWorkspace.id,
            'cliProvider'
          );
          if (cliProvider) {
            providerId = cliProvider;
            console.log(`📁 Using workspace provider: ${cliProvider}`);
          }
        }
      } catch (err) {
        // Workspace meta not available, continue to default
      }
    }

    // Priority 3: Default to claude
    if (!providerId) {
      providerId = 'claude';
    }

    // Set the current handler
    const handler = this.handlers.get(providerId);
    if (handler) {
      this.currentHandler = handler;
      // Log both loaded providers and active provider in one consolidated message
      const loadedProviders = Array.from(this.handlers.keys()).join(', ');
      console.log(`✅ Loaded built-in providers: ${loadedProviders}`);
      console.log(`✅ Active CLI provider: ${handler.name} (${handler.id})`);
    } else {
      console.warn(`⚠️ Provider ${providerId} not found, falling back to Claude`);
      this.currentHandler = this.handlers.get('claude');
    }
  }

  /**
   * Parse provider configuration from environment variables
   */
  parseProviderConfig(providerId = null) {
    // If no providerId specified, try to get from env
    if (!providerId) {
      providerId = process.env.CLI_PROVIDER_ID || process.env.PROVIDER_ID || process.env.ANI_CLI_PROVIDER;
      if (!providerId) {
        return null;
      }
    }

    // Convert provider ID to env var format (replace hyphens with underscores)
    const envPrefix = providerId.toUpperCase().replace(/-/g, '_');

    // Determine handler type
    const handlerType = process.env[`CLI_PROVIDER_${envPrefix}_HANDLER`] || providerId;

    // Get defaults from handler class
    // Pass handlerType so customClaude handlers can default to ccr binary
    const HandlerClass = this.handlerClasses[handlerType] || this.handlerClasses.claude;
    const defaults = HandlerClass.getDefaults ? HandlerClass.getDefaults(providerId, handlerType) : {};

    // Parse env vars
    const envBinary = process.env[`CLI_PROVIDER_${envPrefix}_BINARY`];
    const envArgs = this.parseArgs(process.env[`CLI_PROVIDER_${envPrefix}_ARGS`]);

    // Build config with defaults first, then overlay env vars
    const config = {
      id: providerId,
      name: process.env[`CLI_PROVIDER_${envPrefix}_NAME`] || providerId,
      handler: handlerType,
      binary: envBinary || defaults.binary,
      args: (envArgs && envArgs.length > 0) ? envArgs : defaults.args,
      env: { ...defaults.env, ...this.parseEnv(process.env[`CLI_PROVIDER_${envPrefix}_ENV`]) }
    };

    return config;
  }

  /**
   * Parse arguments string into array
   */
  parseArgs(argsString) {
    if (!argsString) return [];

    // Support JSON array format
    if (argsString.startsWith('[')) {
      try {
        return JSON.parse(argsString);
      } catch (e) {
        console.warn('Failed to parse args as JSON, falling back to space-separated');
      }
    }

    // Support space-separated format
    return argsString.split(' ').filter(arg => arg.trim());
  }

  /**
   * Parse environment variables string into object
   */
  parseEnv(envString) {
    if (!envString) return {};

    // Support JSON object format
    if (envString.startsWith('{')) {
      try {
        return JSON.parse(envString);
      } catch (e) {
        console.warn('Failed to parse env as JSON, falling back to key=value format');
      }
    }

    // Support key=value,key2=value2 format
    const env = {};
    envString.split(',').forEach(pair => {
      const [key, value] = pair.split('=');
      if (key && value) {
        env[key.trim()] = value.trim();
      }
    });

    return env;
  }

  /**
   * Register built-in handlers
   */
  registerBuiltInHandlers() {
    // Register handler classes
    this.handlerClasses = {
      'claude': ClaudeCliHandler,
      'cursor': CursorCliHandler,
      'codex': CodexCliHandler,
      'gemini': GeminiCliHandler,
      'copilot': CopilotCliHandler,
      'opencode': OpenCodeCliHandler,
      'customClaude': ClaudeCliHandler, // Reuse Claude handler for any Claude-compatible CLI (ccr, glm, etc.)
    };
  }

  /**
   * Initialize a provider based on configuration
   */
  initializeProvider(config) {
    const HandlerClass = this.handlerClasses[config.handler] || this.handlerClasses.claude;

    try {
      const handler = new HandlerClass(config);

      // Validate the handler if not in development mode
      if (process.env.NODE_ENV !== 'development') {
        handler.validate();
      }

      this.handlers.set(config.id, handler);

      console.log(`✅ Initialized CLI provider: ${config.name} (${config.id}) - binary: ${config.binary}`);
    } catch (error) {
      console.error(`❌ Failed to initialize provider ${config.id}:`, error.message);

      // Don't set as current handler if initialization fails
      // Just skip this provider
    }
  }

  /**
   * Get current handler
   */
  getCurrentHandler() {
    return this.currentHandler;
  }

  /**
   * Get handler by ID
   */
  getHandler(id) {
    return this.handlers.get(id);
  }

  /**
   * Switch to a different provider
   */
  switchProvider(id) {
    const handler = this.handlers.get(id);
    if (!handler) {
      throw new Error(`Provider ${id} not found`);
    }

    this.currentHandler = handler;
    console.log(`Switched to provider: ${handler.name} (${handler.id})`);
    return handler;
  }

  /**
   * List all available providers
   * @param {boolean} includeUnavailable - Include providers that are not available (binary not found)
   */
  listProviders(includeUnavailable = false) {
    const providers = [];
    this.handlers.forEach((handler, id) => {
      // Check if binary is actually available
      const available = handler.isAvailable();

      // Include unavailable providers if requested
      if (available || includeUnavailable) {
        providers.push({
          id,
          name: handler.name,
          current: handler === this.currentHandler,
          available,
          info: handler.getInfo()
        });
      }
    });
    return providers;
  }

  /**
   * List all providers with full metadata for API responses
   * Includes capabilities, model counts, and enabled status
   */
  listProvidersWithMetadata() {
    const providers = [];
    this.handlers.forEach((handler, id) => {
      const available = handler.isAvailable();
      const capabilities = handler.getCapabilities();
      const info = handler.getInfo();

      // Get models for this provider from pricing data
      const models = this.getProviderModels(id);

      providers.push({
        id,
        name: handler.name,
        binary: handler.binary,
        available,
        enabled: available, // By default, available providers are enabled
        current: handler === this.currentHandler,
        capabilities: {
          supportsCreate: capabilities.supportsCreate || false,
          supportsContinue: capabilities.supportsContinue || false,
          supportsGreenlight: capabilities.supportsGreenlight || false,
          supportsModels: capabilities.supportsModels || false,
          supportsCcusage: capabilities.supportsCcusage || false,
          supportsImages: capabilities.supportsImages || false
        },
        modelCount: models.length
      });
    });
    return providers;
  }

  /**
   * Get handler by ID with full info
   */
  getHandlerInfo(id) {
    const handler = this.handlers.get(id);
    if (!handler) {
      return null;
    }

    const available = handler.isAvailable();
    const capabilities = handler.getCapabilities();
    const info = handler.getInfo();

    return {
      id,
      name: handler.name,
      binary: handler.binary,
      available,
      enabled: available,
      current: handler === this.currentHandler,
      capabilities,
      info
    };
  }

  /**
   * Get list of model IDs for a provider
   * @param {string} providerId - Provider identifier
   * @returns {string[]} Array of model IDs
   */
  getProviderModels(providerId) {
    return getKnownModels(providerId) || [];
  }

  /**
   * Get detailed model information for a provider
   * @param {string} providerId - Provider identifier
   * @returns {Object[]} Array of model objects with pricing
   */
  getProviderModelsWithPricing(providerId) {
    const modelIds = getKnownModels(providerId);
    if (!modelIds || modelIds.length === 0) {
      return [];
    }

    // Define model aliases for common names
    const modelAliases = {
      'claude': {
        'claude-opus-4-5': ['opus', 'claude-opus'],
        'claude-sonnet-4': ['sonnet', 'claude-sonnet'],
        'claude-3-5-haiku': ['haiku', 'claude-haiku']
      },
      'copilot': {
        'gpt-5': ['gpt5'],
        'claude-sonnet-4': ['sonnet'],
        'copilot-default': ['default']
      },
      'opencode': {
        'anthropic/claude-sonnet-4': ['sonnet'],
        'anthropic/claude-opus-4': ['opus'],
        'openai/gpt-4o': ['gpt4o', 'gpt-4o'],
        'google/gemini-2.5-flash': ['gemini', 'gemini-flash']
      },
      'gemini': {
        'gemini-2.5-flash': ['flash', 'gemini-flash'],
        'gemini-2.5-pro': ['pro', 'gemini-pro']
      },
      'codex': {
        'gpt-4o': ['gpt4o'],
        'o3-mini': ['o3'],
        'gpt-5.1-codex-max': ['codex-max', 'max']
      }
    };

    const providerAliases = modelAliases[providerId] || {};

    return modelIds.map(modelId => {
      const pricing = getModelPricing(providerId, modelId);
      const aliases = providerAliases[modelId] || [];

      // Determine a friendly display name
      let displayName = modelId
        .replace(/-/g, ' ')
        .replace(/\//g, ' - ')
        .replace(/\b\w/g, c => c.toUpperCase());

      return {
        id: modelId,
        name: displayName,
        enabled: true, // Default to enabled
        default: false, // Will be set by caller
        pricing: {
          input: pricing.input,
          output: pricing.output,
          cached: pricing.cached
        },
        aliases
      };
    });
  }

  /**
   * Create a custom provider on-the-fly
   */
  createCustomProvider(config) {
    const HandlerClass = this.handlerClasses[config.handler] || ClaudeCliHandler;

    const handler = new HandlerClass(config);
    this.handlers.set(config.id, handler);

    return handler;
  }
}

// Singleton instance
let instance = null;
let initPromise = null;

export async function getProviderManager() {
  if (!instance) {
    instance = new ProviderManager();
  }
  // Always await initialization to ensure providers are loaded
  if (!instance.initialized) {
    if (!initPromise) {
      initPromise = instance.loadProviders().catch(err => {
        console.error('Failed to initialize provider manager:', err);
        // Still return instance even if initialization fails
        // It will fallback to claude
      });
    }
    await initPromise;
  }
  return instance;
}

// Synchronous version for backward compatibility (returns promise)
export function getProviderManagerSync() {
  if (!instance) {
    instance = new ProviderManager();
    // Load providers in background
    instance.loadProviders().catch(err => {
      console.error('Failed to initialize provider manager:', err);
    });
  }
  return instance;
}

export default ProviderManager;
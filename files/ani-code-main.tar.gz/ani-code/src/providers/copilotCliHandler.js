import { spawn, execSync } from 'child_process';
import { BaseCliHandler } from './baseCliHandler.js';
import { stripPatternsFromPrompt } from '../model-utils.js';

/**
 * GitHub Copilot CLI Handler - Implementation for GitHub Copilot CLI
 *
 * GitHub Copilot CLI is the standalone AI coding assistant from GitHub.
 * Binary: 'copilot' (standalone CLI, not the deprecated gh copilot extension)
 *
 * Key features:
 * - Non-interactive mode via --prompt or -p flag
 * - Auto-approve mode via --allow-all-tools, --allow-all-paths, --allow-all-urls
 * - Session continuation via --continue (resume last session)
 * - Model selection via --model flag
 * - Token usage available via /usage command (interactive only)
 *
 * Authentication:
 * - Interactive: /login command
 * - Non-interactive: GH_TOKEN or GITHUB_TOKEN environment variable with Copilot Requests permission
 */
export class CopilotCliHandler extends BaseCliHandler {
  constructor(config = {}) {
    super({
      id: config.id || 'copilot',
      name: config.name || 'GitHub Copilot',
      binary: config.binary || 'copilot',
      args: config.args || [],
      env: config.env || {}
    });
  }

  /**
   * Get default configuration for Copilot
   * @returns {Object} Default configuration
   */
  static getDefaults() {
    return {
      binary: 'copilot',
      args: [],
      env: {}
    };
  }

  /**
   * Create a new task with Copilot
   */
  async createTask(options) {
    const {
      command,
      workingDir = process.cwd(),
      modelPreference = null,
      interactive = false,
      taskId = null,
      skipHints = false
    } = options;

    const args = [];

    // Add custom args from config first
    if (this.args.length > 0) {
      args.push(...this.args);
    }

    // Use non-interactive mode with --prompt flag
    if (!interactive) {
      // Strip model/provider patterns from command before sending to CLI
      const cleanedCommand = stripPatternsFromPrompt(command);

      // Add fixed postfix for non-Claude providers to read CLAUDE.md
      const commandWithPostfix = `${cleanedCommand}\n\n(Before you start, read CLAUDE.md in the folder to understand basic rules of the process)`;

      // Process prompt with hints - injects active hints and saves to file if too long
      const { finalPrompt } = await this.processPromptWithHints(commandWithPostfix, workingDir, taskId, { skipHints });

      // Add --prompt flag with the prompt text
      args.push('--prompt', finalPrompt);
    }

    // Add model preference if specified
    if (modelPreference) {
      args.push(...this.getModelFlags(modelPreference));
    }

    // Allow all paths by default (like --dangerously-skip-permissions for Claude)
    // This is needed for the daemon to work autonomously
    args.push('--allow-all-paths');

    return this.spawnProcess(args, workingDir);
  }

  /**
   * Continue an existing conversation
   *
   * GitHub Copilot CLI supports --continue to resume the last session.
   * However, for provider-switching scenarios, we use context simulation.
   */
  async continueTask(options) {
    const {
      prompt = 'continue',
      taskQueue = null,
      taskId = null,
      skipHints = false,
      ...otherOptions
    } = options;

    const workingDir = options.workingDir || process.cwd();
    const cleanedPrompt = stripPatternsFromPrompt(prompt);

    // Build context for continuation
    let command = cleanedPrompt || 'Please continue with the previous task';

    // Build full conversation history context (like Codex does)
    if (taskQueue && !options.interactive) {
      const conversationHistory = taskQueue.getConversationHistory(workingDir, 5);
      if (conversationHistory.length > 0) {
        // Build context from conversation chain
        const contextParts = conversationHistory.map((turn, index) => {
          return `[Turn ${index + 1}] (Provider: ${turn.providerId || 'unknown'})
User: ${turn.prompt}
Assistant: ${turn.response}`;
        }).join('\n\n');

        command = `Previous conversation history:

${contextParts}

[Current request]
User: ${cleanedPrompt}`;
      }
    }

    // Use greenlightTask to execute with auto-approval
    return this.greenlightTask({ ...otherOptions, command, workingDir, taskId, skipHints });
  }

  /**
   * Execute with auto-approve mode (greenlight)
   * Uses --allow-all-tools, --allow-all-paths, --allow-all-urls for full automation
   */
  async greenlightTask(options) {
    const {
      command,
      workingDir = process.cwd(),
      modelPreference = null,
      taskId = null,
      skipHints = false
    } = options;

    const args = [];

    // Add custom args from config first
    if (this.args.length > 0) {
      args.push(...this.args);
    }

    // Strip model/provider patterns from command before sending to CLI
    const cleanedCommand = stripPatternsFromPrompt(command);

    // Add fixed postfix for non-Claude providers to read CLAUDE.md
    const commandWithPostfix = `${cleanedCommand}\n\n(Before you start, read CLAUDE.md in the folder to understand basic rules of the process)`;

    // Process prompt with hints - injects active hints and saves to file if too long
    const { finalPrompt } = await this.processPromptWithHints(commandWithPostfix, workingDir, taskId, { skipHints });

    // Add --prompt flag for non-interactive execution
    args.push('--prompt', finalPrompt);

    // Add model preference if specified
    if (modelPreference) {
      args.push(...this.getModelFlags(modelPreference));
    }

    // Full auto-approve mode with all permissions
    args.push('--allow-all-tools');
    args.push('--allow-all-paths');
    args.push('--allow-all-urls');

    return this.spawnProcess(args, workingDir);
  }

  /**
   * Get model-specific flags
   * Copilot CLI supports --model flag for model selection
   */
  getModelFlags(modelPreference) {
    const flags = [];

    if (!modelPreference) {
      return flags;
    }

    // Map common model preferences to Copilot models
    // Copilot supports multiple models including Claude Sonnet 4, GPT-5, etc.
    const normalizedModel = modelPreference.toLowerCase().trim();

    // For Copilot, we pass the model preference directly
    // unless it's a Claude-specific model name
    switch (normalizedModel) {
      case 'sonnet':
        flags.push('--model', 'claude-sonnet-4');
        break;
      case 'opus':
        // Copilot may not support Opus, fall back to GPT-5
        console.warn(`⚠️ Model 'opus' may not be available in Copilot, using default`);
        break;
      default:
        // Pass through other model names directly
        flags.push('--model', normalizedModel);
    }

    return flags;
  }

  /**
   * Spawn the CLI process
   */
  spawnProcess(args, workingDir) {
    console.log(`🔧 Executing: ${this.binary} ${args.join(' ')}`);
    console.log(`📁 Working directory: ${workingDir}`);

    const env = { ...process.env, ...this.env };

    const child = spawn(this.binary, args, {
      stdio: ['pipe', 'pipe', 'pipe'],
      shell: false,
      cwd: workingDir,
      env,
      detached: false
    });

    // Add debug handlers to track process lifecycle
    child.on('exit', (code, signal) => {
      console.log(`[COPILOT] Process exited with code ${code}, signal ${signal}`);
    });

    child.on('close', (code, signal) => {
      console.log(`[COPILOT] Process closed with code ${code}, signal ${signal}`);
    });

    child.on('error', (err) => {
      console.error(`[COPILOT] Process error: ${err.message}`);
    });

    // Close stdin for non-interactive mode
    child.stdin.end();

    return child;
  }

  /**
   * Validate if the handler is properly configured
   */
  validate() {
    try {
      // Try to find copilot in PATH
      execSync(`which ${this.binary}`, { encoding: 'utf8' });
      return true;
    } catch {
      throw new Error(`Binary not found in PATH: ${this.binary}`);
    }
  }

  /**
   * Get handler capabilities
   */
  getCapabilities() {
    return {
      supportsCreate: true,
      supportsContinue: true,
      supportsGreenlight: true,
      supportsModels: true,
      supportsPrintMode: true,  // Uses --prompt for non-interactive
      supportsInteractive: true,
      supportsCcusage: false,  // Copilot doesn't use ccusage API
      supportsImages: false,   // Image support TBD
      highPrivilege: true      // Skip permission checks (non-Claude provider)
    };
  }
}

export default CopilotCliHandler;

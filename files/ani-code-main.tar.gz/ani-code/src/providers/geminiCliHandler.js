import { spawn, execSync } from 'child_process';
import { existsSync } from 'fs';
import { BaseCliHandler } from './baseCliHandler.js';
import { stripPatternsFromPrompt } from '../model-utils.js';
import { buildPromptWithImageUrls } from '../services/imageHandler.js';

/**
 * Gemini CLI Handler - Implementation for Google Gemini CLI
 */
export class GeminiCliHandler extends BaseCliHandler {
  constructor(config = {}) {
    super({
      id: config.id || 'gemini',
      name: config.name || 'Gemini CLI',
      binary: config.binary || 'gemini',
      args: config.args || [],
      env: config.env || {}
    });
  }

  /**
   * Get default configuration based on provider ID
   * @param {string} providerId - The provider ID
   * @returns {Object} Default configuration
   */
  static getDefaults(providerId) {
    return {
      binary: 'gemini',
      args: [],
      env: {}
    };
  }

  /**
   * Create a new task with Gemini
   */
  async createTask(options) {
    const {
      command,
      workingDir = process.cwd(),
      modelPreference = null,
      interactive = false,
      logStream = null,
      taskId = null,
      images = []
    } = options;

    const args = [];

    // Add custom args from config FIRST
    if (this.args.length > 0) {
      args.push(...this.args);
    }

    // Always add -y flag for auto-approval (yolo mode)
    args.push('-y');

    // Add model preference if specified
    if (modelPreference) {
      args.push(...this.getModelFlags(modelPreference));
    }

    // Gemini uses -o for output format
    // Use 'json' for non-interactive to get token stats in output
    if (!interactive) {
      args.push('-o', 'json');
    }

    // Strip model/provider patterns from command before sending to CLI
    const cleanedCommand = stripPatternsFromPrompt(command);

    // Build prompt with image URLs if present (uses shared utility)
    const finalCommand = buildPromptWithImageUrls(cleanedCommand, images);
    if (images && images.length > 0) {
      console.log(`📷 Including ${images.length} image URL(s) in Gemini prompt`);
    }

    // Process prompt - save to file if too long to avoid shell exec issues
    const { finalPrompt } = this.processPromptForCli(finalCommand, workingDir, taskId);

    // Add the final prompt (either direct or file reference)
    args.push(finalPrompt);

    return this.spawnProcess(args, workingDir, logStream);
  }

  /**
   * Continue an existing task/conversation
   */
  async continueTask(options) {
    const {
      prompt = 'continue',
      workingDir = process.cwd(),
      modelPreference = null,
      interactive = false,
      logStream = null,
      taskQueue = null,
      taskId = null,
      images = []
    } = options;

    // Gemini doesn't have a native continue flag like Claude's -c
    // We need to simulate context by including conversation history

    let finalCommand = prompt;

    if (taskQueue && !interactive) {
      const conversationHistory = taskQueue.getConversationHistory(workingDir, 5);

      if (conversationHistory.length > 0) {
        const cleanedPrompt = stripPatternsFromPrompt(prompt);
        const contextParts = conversationHistory.map((turn, index) => {
          return `[Turn ${index + 1}] (Provider: ${turn.providerId || 'unknown'})
User: ${turn.prompt}
Assistant: ${turn.response}`;
        }).join('\n\n');

        finalCommand = `Previous conversation history:

${contextParts}

[Current request]
User: ${cleanedPrompt}`;
      } else {
        finalCommand = stripPatternsFromPrompt(prompt);
      }
    } else {
      finalCommand = stripPatternsFromPrompt(prompt);
    }

    // Use createTask with the enriched context (file-based prompt handling happens in createTask)
    return this.createTask({ ...options, command: finalCommand, workingDir, taskId });
  }

  /**
   * Execute with greenlight mode (auto-approve all actions)
   */
  async greenlightTask(options) {
    const {
      command,
      workingDir = process.cwd(),
      modelPreference = null,
      logStream = null,
      taskId = null,
      images = []
    } = options;

    const args = [];

    // Add custom args from config FIRST
    if (this.args.length > 0) {
      args.push(...this.args);
    }

    // Add yolo flag for auto-approval (gemini's equivalent of greenlight)
    args.push('-y');

    // Add model preference if specified
    if (modelPreference) {
      args.push(...this.getModelFlags(modelPreference));
    }

    // Strip model/provider patterns from command before sending to CLI
    const cleanedCommand = stripPatternsFromPrompt(command);

    // Build prompt with image URLs if present (uses shared utility)
    const finalCommand = buildPromptWithImageUrls(cleanedCommand, images);
    if (images && images.length > 0) {
      console.log(`📷 Including ${images.length} image URL(s) in Gemini greenlight prompt`);
    }

    // Process prompt - save to file if too long to avoid shell exec issues
    const { finalPrompt } = this.processPromptForCli(finalCommand, workingDir, taskId);

    // Add the final prompt (either direct or file reference)
    args.push(finalPrompt);

    return this.spawnProcess(args, workingDir, logStream);
  }

  /**
   * Get model-specific flags
   */
  getModelFlags(modelPreference) {
    const flags = [];

    if (!modelPreference) {
      return flags;
    }

    // Gemini uses -m/--model flag for model selection
    // Pass the model preference directly
    flags.push('-m', modelPreference);

    return flags;
  }

  /**
   * Spawn the CLI process
   */
  spawnProcess(args, workingDir, logStream) {
    console.log(`🔧 Executing: ${this.binary} ${args.join(' ')}`);
    console.log(`📁 Working directory: ${workingDir}`);

    const child = spawn(this.binary, args, {
      stdio: ['pipe', 'pipe', 'pipe'],
      shell: false,
      cwd: workingDir,
      env: { ...process.env, ...this.env }
    });

    // Close stdin as Gemini doesn't need input in non-interactive mode
    child.stdin.end();

    return child;
  }

  /**
   * Validate if the handler is properly configured
   */
  validate() {
    // Check if binary exists - handle both absolute paths and PATH binaries
    if (this.binary.includes('/')) {
      // Absolute or relative path - use existsSync
      if (!existsSync(this.binary)) {
        throw new Error(`Binary not found: ${this.binary}`);
      }
    } else {
      // Binary in PATH - use 'which' command to check
      try {
        execSync(`which ${this.binary}`, { stdio: 'pipe' });
      } catch (error) {
        throw new Error(`Binary not found in PATH: ${this.binary}`);
      }
    }

    return true;
  }

  /**
   * Get handler capabilities
   */
  getCapabilities() {
    return {
      supportsCreate: true,
      supportsContinue: true,  // Via context simulation
      supportsGreenlight: true,  // Via -y/--yolo flag
      supportsModels: true,  // Via -m/--model flag
      supportsPrintMode: true,  // Via -o text flag
      supportsInteractive: true,  // Via -i flag
      supportsCcusage: false,  // Gemini has its own token tracking in JSON output, doesn't use ccusage API
      supportsImages: true,  // Gemini supports multimodal image input
      highPrivilege: false
    };
  }
}

export default GeminiCliHandler;

import { spawn, execSync } from 'child_process';
import { BaseCliHandler } from './baseCliHandler.js';
import { stripPatternsFromPrompt } from '../model-utils.js';

/**
 * Codex CLI Handler - Implementation for OpenAI Codex
 */
export class CodexCliHandler extends BaseCliHandler {
  constructor(config = {}) {
    super({
      id: config.id || 'codex',
      name: config.name || 'OpenAI Codex',
      binary: config.binary || 'codex',
      args: config.args || [],
      env: config.env || {}
    });
  }

  /**
   * Get default configuration for Codex
   * @param {string} providerId - The provider ID
   * @returns {Object} Default configuration
   */
  static getDefaults(providerId) {
    return {
      binary: 'codex',
      args: [],
      env: {}
    };
  }

  /**
   * Create a new task with Codex
   */
  async createTask(options) {
    const {
      command,
      workingDir = process.cwd(),
      modelPreference = null,
      interactive = false,
      logStream = null,
      taskId = null
    } = options;

    const args = [];

    // Use exec subcommand for non-interactive execution
    if (!interactive) {
      args.push('exec');
    }

    // Add model preference if specified
    if (modelPreference) {
      // Codex might not support sonnet/opus models
      if (modelPreference === 'sonnet' || modelPreference === 'opus') {
        console.warn(`⚠️ Model '${modelPreference}' may not be supported by Codex, using default`);
        // Don't pass the model flag, let Codex use its default
      } else {
        args.push('--model', modelPreference);
      }
    }

    // Set working directory
    if (workingDir && workingDir !== process.cwd()) {
      args.push('--cd', workingDir);
    }

    // Add custom args from config
    if (this.args.length > 0) {
      args.push(...this.args);
    }

    // Strip model/provider patterns from command before sending to CLI
    const cleanedCommand = stripPatternsFromPrompt(command);

    // Add fixed postfix for non-Claude providers to read CLAUDE.md
    const commandWithPostfix = `${cleanedCommand}\n\n(Before you start, read CLAUDE.md in the folder to understand basic rules of the process)`;

    // Process prompt - save to file if too long to avoid shell exec issues
    const { finalPrompt } = this.processPromptForCli(commandWithPostfix, workingDir, taskId);

    // Add the final prompt (either direct or file reference)
    args.push(finalPrompt);

    return this.spawnProcess(args, workingDir, logStream);
  }

  /**
   * Continue an existing conversation
   *
   * Codex resume requires TTY in daemon mode,
   * so we simulate continuation by creating a new task with previous context.
   */
  async continueTask(options) {
    const {
      prompt = 'continue',
      taskQueue = null,
      taskId = null,
      ...otherOptions
    } = options;

    const workingDir = options.workingDir || process.cwd();
    const cleanedPrompt = stripPatternsFromPrompt(prompt);
    let command = cleanedPrompt || 'Please continue with the previous task';

    // Build full conversation history context
    if (taskQueue && !options.interactive) {
      const conversationHistory = taskQueue.getConversationHistory(workingDir, 5);
      if (conversationHistory.length > 0) {
        // Build context from conversation chain
        const contextParts = conversationHistory.map((turn, index) => {
          return `[Turn ${index + 1}]
User: ${turn.prompt}
Assistant: ${turn.response}`;
        }).join('\n\n');

        command = `Previous conversation history:

${contextParts}

[Current request]
User: ${cleanedPrompt}`;
      }
    }

    // Use greenlightTask to execute as a new task with context and auto-approval
    // (file-based prompt handling happens in greenlightTask)
    return this.greenlightTask({ ...otherOptions, command, workingDir, taskId });
  }

  /**
   * Execute with auto-approve mode (greenlight)
   */
  async greenlightTask(options) {
    const {
      command,
      workingDir = process.cwd(),
      modelPreference = null,
      logStream = null,
      taskId = null
    } = options;

    const args = [];

    // Use exec for non-interactive execution
    args.push('exec');

    // Use full-auto mode for low-friction sandboxed automatic execution
    args.push('--full-auto');

    // Add model preference if specified
    if (modelPreference) {
      // Codex might not support sonnet/opus models
      if (modelPreference === 'sonnet' || modelPreference === 'opus') {
        console.warn(`⚠️ Model '${modelPreference}' may not be supported by Codex, using default`);
        // Don't pass the model flag, let Codex use its default
      } else {
        args.push('--model', modelPreference);
      }
    }

    // Set working directory
    if (workingDir && workingDir !== process.cwd()) {
      args.push('--cd', workingDir);
    }

    // Enable web search if configured
    if (this.env.CODEX_ENABLE_SEARCH === 'true') {
      args.push('--search');
    }

    // Add custom args from config
    if (this.args.length > 0) {
      args.push(...this.args);
    }

    // Strip model/provider patterns from command before sending to CLI
    const cleanedCommand = stripPatternsFromPrompt(command);

    // Add fixed postfix for non-Claude providers to read CLAUDE.md
    const commandWithPostfix = `${cleanedCommand}\n\n(Before you start, read CLAUDE.md in the folder to understand basic rules of the process)`;

    // Process prompt - save to file if too long to avoid shell exec issues
    const { finalPrompt } = this.processPromptForCli(commandWithPostfix, workingDir, taskId);

    // Add the final prompt (either direct or file reference)
    args.push(finalPrompt);

    return this.spawnProcess(args, workingDir, logStream);
  }

  /**
   * Spawn the CLI process
   */
  spawnProcess(args, workingDir, logStream) {
    console.log(`🔧 Executing: ${this.binary} ${args.join(' ')}`);
    console.log(`📁 Working directory: ${workingDir}`);

    const env = { ...process.env, ...this.env };

    const child = spawn(this.binary, args, {
      stdio: ['pipe', 'pipe', 'pipe'],
      shell: false,
      cwd: workingDir,
      env,
      // Ensure child processes are in the same process group so they get killed together
      detached: false
    });

    // Add debug handlers to track process lifecycle
    child.on('exit', (code, signal) => {
      console.log(`[CODEX] Process exited with code ${code}, signal ${signal}`);
    });

    child.on('close', (code, signal) => {
      console.log(`[CODEX] Process closed with code ${code}, signal ${signal}`);
    });

    child.on('error', (err) => {
      console.error(`[CODEX] Process error: ${err.message}`);
    });

    // Close stdin for non-interactive mode
    child.stdin.end();

    return child;
  }

  /**
   * Validate if the handler is properly configured
   */
  validate() {
    try {
      // Try to find codex in PATH
      execSync(`which ${this.binary}`, { encoding: 'utf8' });
      return true;
    } catch (error) {
      throw new Error(`Binary not found in PATH: ${this.binary}`);
    }
  }

  /**
   * Get handler capabilities
   */
  getCapabilities() {
    return {
      supportsCreate: true,
      supportsContinue: true,
      supportsGreenlight: true,
      supportsModels: true,
      supportsPrintMode: true,
      supportsInteractive: true,
      supportsCcusage: false,  // Codex doesn't support ccusage tracking
      highPrivilege: true  // Skip permission checks for non-Claude provider
    };
  }
}

export default CodexCliHandler;
#!/usr/bin/env node

import { Command } from 'commander';
import chalk from 'chalk';
import { execSync } from 'child_process';
import { createInterface } from 'readline';
import { DaemonClient } from './daemon-client.js';
import { ServiceInstaller } from './service-installer.js';
import { validateConfig, config } from './config.js';
import { IPCClient } from './ipc-client.js';
import { gatewayState } from './gateway-state.js'; // Import to ensure token is loaded
import PluginCommand from './commands/plugin.js';
import workspaceCommand from './commands/workspace.js';
import providerCommand from './commands/provider.js';
import providersCommand from './commands/providers.js';
import createGoalsCommand from './commands/goals.js';
import gatewayCommand from './commands/gateway.js';
import createHealthcheckCommand from './commands/healthcheck.js';
import createProjectsCommand from './commands/projects.js';
import hintCommand from './commands/hint.js';
import chatUICommand from './commands/chatui.js';
import { processPresets } from './preset-processor.js';
import {
  normalizePlanStep,
  normalizePlanSteps,
  stepsToPlanDescription,
  getPlanStepDisplayText
} from './utils/plan-step-utils.js';

const program = new Command();

// Helper function to check daemon version compatibility
async function checkDaemonVersion() {
  const daemonClient = new DaemonClient();
  const versionCheck = await daemonClient.checkVersionCompatibility();

  if (!versionCheck.compatible) {
    console.error(chalk.red('✗ Version Incompatibility Detected'));
    console.error(chalk.red(versionCheck.message));
    console.log(chalk.yellow('💡 To fix this issue:'));
    console.log(chalk.yellow('  1. Stop the daemon: ani-code daemon --stop'));
    console.log(chalk.yellow('  2. Update ani-code: npm update -g ani-code'));
    console.log(chalk.yellow('  3. Restart the daemon: ani-code daemon --start'));
    process.exit(1);
  }

  if (versionCheck.warning) {
    console.warn(chalk.yellow('⚠ ' + versionCheck.message));
  }

  return versionCheck;
}

// Helper function to get IPC client
async function getIPCClient() {
  const client = new IPCClient();
  await client.connect();
  return client;
}

// Escape text for Telegram MarkdownV2
function escapeMarkdownV2(text) {
  if (!text) return '';
  // In MarkdownV2, these characters must be escaped: _ * [ ] ( ) ~ ` > # + - = | { } . !
  return text
    .replace(/\\/g, '\\\\')  // Escape backslashes first
    .replace(/_/g, '\\_')
    .replace(/\*/g, '\\*')
    .replace(/\[/g, '\\[')
    .replace(/\]/g, '\\]')
    .replace(/\(/g, '\\(')
    .replace(/\)/g, '\\)')
    .replace(/~/g, '\\~')
    .replace(/`/g, '\\`')
    .replace(/>/g, '\\>')
    .replace(/#/g, '\\#')
    .replace(/\+/g, '\\+')
    .replace(/-/g, '\\-')
    .replace(/=/g, '\\=')
    .replace(/\|/g, '\\|')
    .replace(/\{/g, '\\{')
    .replace(/\}/g, '\\}')
    .replace(/\./g, '\\.')
    .replace(/!/g, '\\!');
}


program
  .name('ani-code')
  .description('Claude Code task manager with Lark notifications')
  .version('1.0.0')
  .configureHelp({
    sortSubcommands: false,
    subcommandTerm: (cmd) => cmd.name() + ' ' + cmd.usage(),
  })
  .helpOption('-h, --help', 'Show structured help by usage categories');

// Function to show structured help
function showStructuredHelp(command) {
  if (command) {
    // Show help for specific command
    const cmd = program.commands.find(c => c.name() === command);
    if (cmd) {
      cmd.help();
    } else {
      console.error(chalk.red(`Unknown command: ${command}`));
      process.exit(1);
    }
    return;
  }

  // Show structured help
  console.log(chalk.bold('\n🚀 Ani Code - Claude Task Manager\n'));
  
  console.log(chalk.blue.bold('📋 TASK MANAGEMENT (Most Common)'));
  console.log(chalk.gray('─'.repeat(50)));
  console.log(`  ${chalk.green('add')}           Add a new Claude task to the queue`);
  console.log(`                   ${chalk.cyan('-f <file>')} Read prompt from markdown file`);
  console.log(`                   ${chalk.cyan('-w <dir>')}  Set working directory`);
  console.log(`  ${chalk.green('continue')}      Continue Claude conversation (adds -c flag)`);
  console.log(`                   ${chalk.cyan('-f <file>')} Read prompt from markdown file`);
  console.log(`                   ${chalk.cyan('-w <dir>')}  Set working directory`);
  console.log(`  ${chalk.green('plan [action]')} Manage task plans`);
  console.log(`                   ${chalk.cyan('list')}      List all plans`);
  console.log(`                   ${chalk.cyan('reset')}     Clear current workspace plans`);
  console.log(`                   ${chalk.cyan('delete')}    Delete specific plan`);
  console.log(`                   ${chalk.cyan('show')}      Show plan details`);
  console.log(`  ${chalk.green('next [id]')}     Execute next plan or specific plan`);
  console.log(`                   ${chalk.cyan('-s <num>')}  Start from specific step`);
  console.log(`                   ${chalk.cyan('-a')}        Auto-execute all steps`);
  console.log(`  ${chalk.green('status')}        Show current task status (-v for process info)`);
  console.log(`  ${chalk.green('watch <id>')}    Watch real-time output of a running task`);
  console.log(`  ${chalk.green('cancel <id>')}   Cancel a running task`);
  console.log(`  ${chalk.green('retry [id]')}    Retry failed task (-c to keep workdir)`);
  console.log(`  ${chalk.green('task <id>')}     Get details of a specific task`);
  console.log(`  ${chalk.green('task-continue')} Continue failed Claude task with context`);
  console.log(`  ${chalk.green('history')}       Show recent task history (last 10 tasks)`);
  
  console.log(chalk.yellow.bold('\n⚡ QUICK WORKFLOWS'));
  console.log(chalk.gray('─'.repeat(50)));
  console.log(`  ${chalk.green('commit')}        Git commit workflow: status, add, and commit`);
  console.log(`  ${chalk.green('doc')}           Auto-generate project documentation (-y to auto-accept)`);
  console.log(`  ${chalk.green('test')}          Implement missing tests and run test suite`);
  console.log(`  ${chalk.green('run <cmd>')}     Run shell command or custom workdir command`);
  console.log(`  ${chalk.green('hint <msg>')}    Add transient context hint for next task iteration`);
  console.log(`                   ${chalk.cyan('-f <file>')} Read hint from file`);
  console.log(`                   ${chalk.cyan('--list')}    List active hints`);
  console.log(`                   ${chalk.cyan('--ack <id>')} Acknowledge/resolve hint`);
  console.log(`  ${chalk.green('message <txt>')} Send text message to related chat (Lark/Telegram)`);
  console.log(`  ${chalk.green('message-raw')}   Send raw Telegram API request from JSON file`);
  console.log(`  ${chalk.green('upload <file>')} Upload file to S3 and get downloadable URL`);
  console.log(`  ${chalk.green('upload --workspace-temp')} Upload all temp folders from workspace`);
  console.log(`  ${chalk.green('chatui [mode]')} Configure chat display mode (full/simple)`);

  console.log(chalk.magenta.bold('\n🔧 DAEMON & SERVICE'));
  console.log(chalk.gray('─'.repeat(50)));
  console.log(`  ${chalk.green('daemon -h')}     Manage the Ani Code daemon`);
  console.log(`  ${chalk.green('service -h')}    Manage systemd service`);
  console.log(`  ${chalk.green('diagnosis')}     Run system diagnosis and checks`);

  console.log(chalk.gray.bold('\n🐛 DEBUG'));
  console.log(chalk.gray('─'.repeat(50)));
  console.log(`  ${chalk.green('debug -h')}            Debug and diagnostic commands`);
  console.log(`  ${chalk.green('debug usage')}         Check Claude API usage (sessions, models, Opus)`);
  
  console.log(chalk.cyan.bold('\n⚙️  SETUP & CONFIGURATION'));
  console.log(chalk.gray('─'.repeat(50)));
  console.log(`  ${chalk.green('init')}                   Initialize Claude Code settings file`);
  console.log(`    ${chalk.cyan('--preset')}         Permission preset: basic, full, secure`);
  console.log(`    ${chalk.cyan('--global')}         Create user-level settings`);
  console.log(`  ${chalk.green('unlink')}              Unlink the global CLI command`);
  
  console.log(chalk.blue.bold('\n🏢 WORKSPACE'));
  console.log(chalk.gray('─'.repeat(50)));
  console.log(`  ${chalk.green('workspace create <name>')} Create workspace`);
  console.log(`  ${chalk.green('workspace list')}         List workspaces`);
  console.log(`  ${chalk.green('workspace token gen')}     Generate token`);
  console.log(`  ${chalk.green('workspace -h')}            More options`);
  
  console.log(chalk.blue.bold('\n🔌 CHROME PLUGIN'));
  console.log(chalk.gray('─'.repeat(50)));
  console.log(`  ${chalk.green('plugin new-token')}       Generate connection token for Chrome plugin`);
  console.log(`  ${chalk.green('plugin list')}            List all active plugin tokens`);
  console.log(`  ${chalk.green('plugin revoke <id>')}     Revoke a specific token`);
  console.log(`  ${chalk.green('build-annotate')}         Add component metadata for plugin`);
  console.log(`    ${chalk.cyan('annotate')}         Add data-ac-* attributes to components`);
  console.log(`    ${chalk.cyan('clean')}            Remove annotations for production`);
  console.log(`    ${chalk.cyan('check')}            Check annotation status`);

  console.log(chalk.magenta.bold('\n🌐 GATEWAY'));
  console.log(chalk.gray('─'.repeat(50)));
  console.log(`  ${chalk.green('gateway status')}         Check gateway registration status`);
  console.log(`  ${chalk.green('gateway test')}           Test gateway connectivity`);
  console.log(`  ${chalk.green('gateway config')}         Show gateway configuration`);
  console.log(`  ${chalk.green('gateway -h')}             More gateway commands`);

  console.log(chalk.gray.bold('\n💡 EXAMPLES'));
  console.log(chalk.gray('─'.repeat(50)));
  console.log(`  ${chalk.white('ani-code add')}                  Add a task (interactive)`);
  console.log(`  ${chalk.white('ani-code add -f prompt.md')}     Add task from markdown file`);
  console.log(`  ${chalk.white('ani-code add -f task.md -w ./src')} Task with custom workdir`);
  console.log(`  ${chalk.white('ani-code continue')}             Continue Claude conversation`);
  console.log(`  ${chalk.white('ani-code continue -f reply.md')} Continue with markdown file`);
  console.log(`  ${chalk.white('ani-code commit -a -s')}         Commit all changes + create summary`);
  console.log(`  ${chalk.white('ani-code commit -y')}            Auto-accept Claude message (YOLO mode)`);
  console.log(`  ${chalk.white('ani-code test')}                 Implement and run tests`);
  console.log(`  ${chalk.white('ani-code test -r')}              Run existing tests only`);
  console.log(`  ${chalk.white('ani-code daemon --start')}       Start the daemon`);
  console.log(`  ${chalk.white('ani-code watch 1')}              Watch task output by index`);
  console.log(`  ${chalk.white('ani-code service install --user')} Install user service`);
  console.log(`  ${chalk.white('ani-code usage')}                Check Claude API usage stats`);
  console.log(`  ${chalk.white('ani-code plugin new-token')}     Generate Chrome plugin token`);
  console.log(`  ${chalk.white('ani-code build-annotate annotate')} Add component metadata`);
  
  console.log(chalk.gray('\nFor detailed help on any command, use: ani-code help <command>'));
  console.log(chalk.gray('Version: 1.0.0\n'));
}

// Custom help command with structured output
program
  .command('help')
  .description('Show help organized by usage categories')
  .argument('[command]', 'Get help for a specific command')
  .action(showStructuredHelp);

// Cheatsheet command for Telegram integration
program
  .command('cheatsheet')
  .description('Show Telegram integration cheatsheet')
  .action(() => {
    console.log(chalk.bold('\n🚀 Ani-Code Telegram Integration Cheatsheet\n'));

    console.log(chalk.blue.bold('📋 INITIAL SETUP'));
    console.log(chalk.gray('─'.repeat(50)));
    console.log(`  ${chalk.green('1. Initialize project:')} ani-code remember "@main.md"`);
    console.log(`  ${chalk.green('2. Browser tasks:')} ani-code remember "@browser.md"`);
    console.log(`  ${chalk.green('3. Web development:')} ani-code remember "@web.md"`);
    console.log('');

    console.log(chalk.blue.bold('🤖 TELEGRAM COMMANDS'));
    console.log(chalk.gray('─'.repeat(50)));
    console.log(`  ${chalk.cyan('/add <prompt>')}       Create new Claude task`);
    console.log(`  ${chalk.cyan('/continue')}           Continue last task`);
    console.log(`  ${chalk.cyan('/commit')}             Commit current changes`);
    console.log(`  ${chalk.cyan('/plan <prompt>')}      Set tasks for later execution`);
    console.log(`  ${chalk.cyan('/yolo <prompt>')}      Execute with auto-accept`);
    console.log('');

    console.log(chalk.blue.bold('📝 MACROS (Customizable)'));
    console.log(chalk.gray('─'.repeat(50)));
    console.log(`  ${chalk.cyan('/$goal')}              Draft goals in pd/goals`);
    console.log(`  ${chalk.cyan('/$loop')}              Execute goal implementation loop`);
    console.log(`  ${chalk.cyan('/$goalcheck')}         Check goal completion status`);
    console.log('');

    console.log(chalk.yellow.bold('⚙️ MACRO EXAMPLES'));
    console.log(chalk.gray('─'.repeat(50)));

    console.log(chalk.green('\n/$goalcheck:'));
    console.log(chalk.gray('  /add check pd/goals what is the current completion status'));

    console.log(chalk.green('\n/$loop:'));
    console.log(chalk.gray('  /add read project prd, pick one or several tasks from goal'));
    console.log(chalk.gray('       and implement, after that, review your implementation'));
    console.log(chalk.gray('       if matching the goal, if so update the goal file progress,'));
    console.log(chalk.gray('       otherwise provide next step. Make sure you remember you'));
    console.log(chalk.gray('       are not only implementing the goals, but following goals'));
    console.log(chalk.gray('       and claude.md guidance. The goal can be optimized if you'));
    console.log(chalk.gray('       facing issue, but dont forget to mention your change in pd/.'));
    console.log(chalk.gray('       Every service can be auto reload, so dont run node npm'));
    console.log(chalk.gray('       command unless it is for validate compile or build.'));
    console.log(chalk.gray('       In the end summarize the current progress of goal'));
    console.log(chalk.gray('       implementation and major achievements, tell me now'));
    console.log(chalk.gray('       in which state and which goal, what is the percentage'));
    console.log(chalk.gray('       of completion, and is any manual step I need to involve.'));
    console.log(chalk.gray('       Check after the implementation if any issue preventing'));
    console.log(chalk.gray('       service running and page rendering, in the end tell me'));
    console.log(chalk.gray('       what is the current pd/goals implement progress in'));
    console.log(chalk.gray('       a short summary.'));

    console.log(chalk.green('\n/$goal:'));
    console.log(chalk.gray('  /plan Please consider the following implementation plan,'));
    console.log(chalk.gray('        review what is needed, and identify any conflicts or'));
    console.log(chalk.gray('        improvements to the pd/goals stage and goal. Update'));
    console.log(chalk.gray('        the related goal file or create a new one as necessary.'));
    console.log(chalk.gray('        Always follow claude.md guidance when preparing the'));
    console.log(chalk.gray('        goal plan.'));

    console.log(chalk.magenta.bold('\n💡 TIPS'));
    console.log(chalk.gray('─'.repeat(50)));
    console.log(`  • Use ${chalk.cyan('@@opus')} or ${chalk.cyan('@@sonnet')} to select model`);
    console.log(`  • Combine tasks: ${chalk.cyan('/yolo implement auth + tests')}`);
    console.log(`  • Check status: ${chalk.cyan('ani-code status')}`);
    console.log(`  • Watch output: ${chalk.cyan('ani-code watch <id>')}`);
    console.log('');

    console.log(chalk.magenta.bold('🔧 CREATING MACROS'));
    console.log(chalk.gray('─'.repeat(50)));
    console.log(`  ${chalk.green('List macros:')} ani-code workspace macro list`);
    console.log(`  ${chalk.green('Create macro:')} ani-code workspace macro set <name> "<command>"`);
    console.log(`  ${chalk.green('Example:')} ani-code workspace macro set test "/add run tests"`);
    console.log(`  ${chalk.green('Use in Telegram:')} /$test`);
    console.log('');
  });

// ===============================
// FREQUENT USE COMMANDS
// ===============================

program
  .command('commit')
  .description('Git commit workflow: show status, add changes, and commit')
  .argument('[message]', 'Commit message (will prompt if not provided)')
  .option('-a, --add-all', 'Add all changes (git add .)', false)
  .option('-s, --summary', 'Also create a git summary task', false)
  .option('-y, --yolo', 'Auto-accept Claude generated message without prompting', false)
  .option('-v, --verbose', 'Show detailed debug logging', false)
  .action(async (message, options) => {
    try {
      // Check if current directory is a git repository
      const { existsSync } = await import('fs');
      const { join } = await import('path');
      const { execSync } = await import('child_process');
      
      const gitDir = join(process.cwd(), '.git');
      if (!existsSync(gitDir)) {
        console.error(chalk.red('✗ Current directory is not a git repository'));
        console.log(chalk.gray('💡 Navigate to a git repository and try again'));
        process.exit(1);
      }
      
      try {
        const status = execSync('git status --porcelain', { encoding: 'utf8', cwd: process.cwd() });
        if (status.trim()) {
          const lines = status.trim().split('\n');
          const modified = lines.filter(l => l.trim().startsWith('M') || l.startsWith(' M') || l.startsWith('MM')).length;
          const added = lines.filter(l => l.startsWith('??') || l.startsWith('A')).length;
          const deleted = lines.filter(l => l.startsWith(' D') || l.startsWith('D')).length;
          if (options.verbose) {
            const parts = [];
            if (modified) parts.push(`${modified} modified`);
            if (added) parts.push(`${added} new`);
            if (deleted) parts.push(`${deleted} deleted`);
            console.log(chalk.blue(`📊 ${lines.length} files (${parts.join(', ')})`));
            console.log(chalk.gray('─'.repeat(50)));
            console.log(status);
          }
        } else {
          console.log(chalk.gray('  Working tree clean'));
          process.exit(0);
        }
      } catch (error) {
        console.error(chalk.red(`✗ Failed to get git status: ${error.message}`));
        process.exit(1);
      }
      
      // Add files - default to all files for complete diff, -a flag forces all files
      const addCommand = 'git add .';
      try {
        execSync(addCommand, { stdio: 'inherit', cwd: process.cwd() });
      } catch (error) {
        console.error(chalk.red(`✗ Failed to add files: ${error.message}`));
        process.exit(1);
      }
      
      // Get commit message
      let commitMessage = message;
      if (!commitMessage) {
        // Check if daemon is running for Claude task
        const daemonClient = new DaemonClient();
        if (!daemonClient.isDaemonRunning()) {
          console.error(chalk.red('✗ Daemon is not running - cannot generate commit message with Claude'));
          console.log(chalk.yellow('💡 Start the daemon with: ani-code daemon --start'));
          console.log(chalk.gray('💡 Or provide a commit message manually: ani-code commit "your message"'));
          process.exit(1);
        }

        console.log(chalk.blue('🤖 Generating commit message...'));
        if (options.verbose) {
          console.log(chalk.gray('[DEBUG] Starting Claude task creation...'));
        }
        
        // Create Claude task to generate commit message and wait for result
        const { basename } = await import('path');
        const projectDir = basename(process.cwd());
        const now = new Date();
        const hour = now.getHours().toString().padStart(2, '0');
        const minute = now.getMinutes().toString().padStart(2, '0');
        const taskName = `${projectDir}-commit-msg-${hour}${minute}`;
        
        // Check if running in goal loop context
        const goalContext = process.env.ANICODE_GOAL_CONTEXT
          ? JSON.parse(process.env.ANICODE_GOAL_CONTEXT)
          : null;

        let commitMsgCommand = `You are a git commit message generator.

Use the Bash tool to run these commands:
1. git diff --cached (to see staged changes)
2. git log --oneline -10 (to understand commit style)

Then analyze the changes and generate a commit message.

CRITICAL OUTPUT FORMAT:
You MUST wrap your final commit message in <commit></commit> XML tags.

Example output:
<commit>feat: add user authentication system</commit>

Requirements:
- Keep it concise (under 72 characters for the first line)
- Use lowercase unless proper nouns
- Follow the existing project's commit message style
- Focus on what changed, not how
- Do NOT include any conversational text before or after the <commit> tags`;

        // Add goal context if available
        if (goalContext) {
          commitMsgCommand += `\n\n**IMPORTANT - Goal Context:**
This commit is part of implementing Goal #${goalContext.id}: ${goalContext.title}
Include a reference to this goal in the commit message.
Example format: <commit>feat: implement user auth [goal-${goalContext.id}]</commit>`;
        }

        commitMsgCommand += `\n\n@@sonnet`;
        
        const client = await getIPCClient();
        let task;
        try {
          const taskOptions = { cwd: process.cwd() };
          
          // Check if we're running as a child process with parent's chatId
          if (process.env.ANICODE_PARENT_CHAT_ID) {
            taskOptions.chatId = process.env.ANICODE_PARENT_CHAT_ID;
            if (options.verbose) {
              console.log(chalk.gray(`[DEBUG] Inherited chatId from parent: ${taskOptions.chatId}`));
            }
          }
          
          if (options.verbose) {
            console.log(chalk.gray(`[DEBUG] Creating task '${taskName}' with options:`, JSON.stringify(taskOptions)));
          }
          task = await client.addTask(taskName, commitMsgCommand, taskOptions);
          if (options.verbose) {
            console.log(chalk.gray(`[DEBUG] Task created with ID: ${task.id}`));
          }
          
          // Wait for the task to complete and get the result
          
          let attempts = 0;
          const maxAttempts = 300; // 5 minutes with 1-second intervals
          const startTime = Date.now();
          
          while (attempts < maxAttempts) {
            await new Promise(resolve => setTimeout(resolve, 1000)); // Wait 1 second
            
            attempts++;
            
            // Log attempt details for better debugging
            if (options.verbose && (attempts === 1 || attempts % 5 === 0)) {
              console.log(chalk.gray(`[DEBUG] Attempt ${attempts}: Fetching task ${task.id} from active tasks...`));
            }
            
            let currentTask;
            try {
              currentTask = await client.getTask(task.id);
              
              // If task not found in active tasks, check history
              if (!currentTask) {
                if (options.verbose && attempts % 5 === 0) {
                  console.log(chalk.gray(`[DEBUG] Task not in active tasks, checking history...`));
                }
                currentTask = await client.getHistoryTask(task.id);
                if (currentTask && options.verbose) {
                  console.log(chalk.gray(`[DEBUG] Task found in history with status: ${currentTask.status}`));
                }
              } else if (options.verbose && attempts % 5 === 0) {
                console.log(chalk.gray(`[DEBUG] Task found in active tasks with status: ${currentTask.status}`));
              }
            } catch (fetchError) {
              if (options.verbose) {
                console.error(chalk.red(`[DEBUG] Error fetching task status: ${fetchError.message}`));
              }
              // Don't exit immediately on fetch error, try again
              if (attempts >= 3) {
                // After 3 failed attempts, give up
                console.error(chalk.red('✗ Failed to fetch task status after multiple attempts'));
                throw fetchError;
              }
              continue;
            }
            
            if (currentTask && currentTask.status === 'completed') {
              let rawOutput = (currentTask.output || '').trim();

              // Extract commit message from <commit> tags
              const commitMatch = rawOutput.match(/<commit>([\s\S]*?)<\/commit>/);
              if (commitMatch && commitMatch[1]) {
                // Extract content and remove any remaining XML tags (including nested <commit> tags)
                commitMessage = commitMatch[1]
                  .replace(/<\/?commit>/g, '') // Remove any remaining <commit> tags
                  .replace(/<\/?[\w\s='"]+>/g, '') // Remove any other XML tags
                  .trim();
              } else {
                // Fallback: remove common prefixes that Claude might add
                commitMessage = rawOutput
                  .replace(/^(Here's the commit message:|Commit message:|Message:|Based on[^:]+:)\s*/i, '')
                  .replace(/<\/?commit>/g, '') // Remove any <commit> tags
                  .replace(/<\/?[\w\s='"]+>/g, '') // Remove any other XML tags
                  .replace(/^["']|["']$/g, '') // Remove surrounding quotes
                  .split('\n')[0] // Take only first line if multiline
                  .trim();
              }

              const totalTime = Math.round((Date.now() - startTime) / 1000);
              if (options.verbose) {
                console.log(chalk.gray(`[DEBUG] Task completed successfully after ${totalTime}s`));
                console.log(chalk.gray(`[DEBUG] Raw output: ${rawOutput}`));
                console.log(chalk.gray(`[DEBUG] Cleaned message: ${commitMessage}`));
                console.log(chalk.gray(`[DEBUG] Output length: ${commitMessage.length} chars`));
              }
              break;
            } else if (currentTask && currentTask.status === 'failed') {
              console.error(chalk.red('✗ Failed to generate commit message with Claude'));
              if (options.verbose) {
                console.log(chalk.gray(`[DEBUG] Task failed with error: ${currentTask.error || 'Unknown error'}`));
              }
              console.log(chalk.gray('💡 Try again or provide a commit message manually'));
              process.exit(1);
            } else if (!currentTask) {
              console.error(chalk.red('✗ Task disappeared unexpectedly'));
              if (options.verbose) {
                console.log(chalk.gray(`[DEBUG] Task ${task.id} not found in active or history after ${attempts} attempts`));
              }
              process.exit(1);
            }
            
            // Log progress every 30 seconds
            if (attempts % 30 === 0) {
              const timeElapsed = attempts < 60 ? `${attempts}s` : `${Math.floor(attempts/60)}m ${attempts%60}s`;
              console.log(chalk.gray(`⏳ Still waiting... (${timeElapsed})`));
              if (currentTask && options.verbose) {
                console.log(chalk.gray(`[DEBUG] Current task status: ${currentTask.status}, queue position: ${currentTask.queuePosition || 'N/A'}`));
              }
            }
          }
          
          if (!commitMessage) {
            const totalTime = Math.round((Date.now() - startTime) / 1000);
            console.error(chalk.red(`✗ Timeout waiting for Claude to generate commit message after ${totalTime}s`));
            if (options.verbose) {
              console.log(chalk.gray(`[DEBUG] Max attempts (${maxAttempts}) reached`));
            }
            
            // Check final status in both active and history
            if (options.verbose) {
              console.log(chalk.gray(`[DEBUG] Performing final status check...`));
            }
            let finalTask = await client.getTask(task.id);
            if (!finalTask) {
              if (options.verbose) {
                console.log(chalk.gray(`[DEBUG] Task not in active tasks, checking history one more time...`));
              }
              finalTask = await client.getHistoryTask(task.id);
            }
            if (finalTask) {
              if (options.verbose) {
                console.log(chalk.gray(`[DEBUG] Final task status: ${finalTask.status}, output: ${finalTask.output ? 'Present' : 'Empty'}`));
              }
              if (finalTask.status === 'completed' && finalTask.output) {
                console.log(chalk.yellow('⚠️  Task completed but output retrieval was delayed'));
                let rawOutput = finalTask.output.trim();
                // Extract commit message from <commit> tags
                const commitMatch = rawOutput.match(/<commit>([\s\S]*?)<\/commit>/);
                if (commitMatch && commitMatch[1]) {
                  commitMessage = commitMatch[1].trim();
                } else {
                  // Fallback: remove common prefixes that Claude might add
                  commitMessage = rawOutput
                    .replace(/^(Here's the commit message:|Commit message:|Message:|Based on[^:]+:)\s*/i, '')
                    .replace(/^["']|["']$/g, '')
                    .split('\n')[0]
                    .trim();
                }
              }
            } else if (options.verbose) {
              console.log(chalk.gray(`[DEBUG] Task completely disappeared from both active and history`));
            }
            
            if (!commitMessage) {
              console.log(chalk.gray('💡 Try again or provide a commit message manually'));
              process.exit(1);
            }
          }
          
          console.log(chalk.green(`✓ ${commitMessage}`));

          // Skip user prompt if --yolo flag is used
          if (options.yolo) {
            // YOLO mode: auto-accept silently
          } else {
            // Show user options for the commit message
            console.log(chalk.yellow('\nChoose an action:'));
            console.log(chalk.gray('  [a] Accept and use this message'));
            console.log(chalk.gray('  [e] Edit message in vim'));
            console.log(chalk.gray('  [c] Cancel commit'));
            
            const choice = await getUserChoice(['a', 'e', 'c'], 'Your choice (a/e/c): ');
            
            if (choice === 'c') {
              console.log(chalk.yellow('✗ Commit cancelled'));
              process.exit(0);
            } else if (choice === 'e') {
              // Edit the commit message in vim
              const editedMessage = await editCommitMessageInVim(commitMessage);
              if (editedMessage === null) {
                console.log(chalk.yellow('✗ Commit cancelled (vim exited without saving)'));
                process.exit(0);
              }
              commitMessage = editedMessage;
              console.log(chalk.green('✓ Using edited commit message:'));
              console.log(chalk.cyan(`"${commitMessage}"`));
            }
          }
          
        } catch (error) {
          if (options.verbose) {
            console.error(chalk.red(`[DEBUG] Error during task operation: ${error.message}`));
            console.log(chalk.gray(`[DEBUG] Error stack: ${error.stack}`));
          }
          throw error;
        } finally {
          if (options.verbose) {
            console.log(chalk.gray(`[DEBUG] Disconnecting IPC client...`));
          }
          client.disconnect();
          if (options.verbose) {
            console.log(chalk.gray(`[DEBUG] IPC client disconnected`));
          }
        }
      }
      
      // Check current git status to decide how to handle commit
      let stagedFiles = '';
      try {
        stagedFiles = execSync('git diff --cached --name-only', { encoding: 'utf8', cwd: process.cwd() });
      } catch (error) {
        console.error(chalk.red(`✗ Failed to check staged changes: ${error.message}`));
        process.exit(1);
      }
      
      if (!stagedFiles.trim()) {
        console.log(chalk.yellow('⚠️  No staged changes found'));
        console.log(chalk.gray('💡 Tip: Files were added but may not have any actual changes'));
        process.exit(0);
      }
      
      // Commit with the generated message directly
      try {
        // Use the commit message directly instead of template file
        const commitOutput = execSync(`git commit -m "${commitMessage.replace(/"/g, '\\"')}"`, {
          encoding: 'utf-8',
          cwd: process.cwd()
        });

        if (options.verbose) {
          console.log(commitOutput);
        }

        // Get the commit hash and shortstat for compact summary
        const commitHash = execSync('git rev-parse HEAD', { encoding: 'utf-8', cwd: process.cwd() }).trim();
        const shortStat = execSync('git diff --shortstat HEAD~1 HEAD', { encoding: 'utf-8', cwd: process.cwd() }).trim();
        // Clean up shortstat: "3 files changed, 45 insertions(+), 12 deletions(-)" → "3 files changed, +45, -12"
        const cleanStat = shortStat
          .replace(/(\d+) insertions?\(\+\)/, '+$1')
          .replace(/(\d+) deletions?\(-\)/, '-$1');
        console.log(chalk.green(`✅ Committed ${commitHash.substring(0, 7)} -- ${cleanStat}`));

      } catch (error) {
        if (error.status === 1) {
          // If direct commit fails, fall back to editor approach
          console.log(chalk.yellow('⚠️  Direct commit failed, opening editor...'));
          
          try {
            // Create temporary file with the commit message
            const { writeFileSync, unlinkSync } = await import('fs');
            const { join } = await import('path');
            const { tmpdir } = await import('os');
            
            const tempFile = join(tmpdir(), `ani-code-commit-${Date.now()}.txt`);
            writeFileSync(tempFile, `${commitMessage}\n\n# Generated commit message above. Edit as needed.\n# Lines starting with # are comments and will be ignored.`);
            
            // Set EDITOR to vim if not already set
            const env = { ...process.env };
            if (!env.EDITOR) {
              env.EDITOR = 'vim';
            }
            
            // Open git commit with the generated message as template
            execSync(`git commit --template="${tempFile}"`, { 
              stdio: 'inherit', 
              cwd: process.cwd(),
              env: env
            });
            
            // Clean up temp file
            try {
              unlinkSync(tempFile);
            } catch (e) {
              // Ignore cleanup errors
            }
          } catch (editorError) {
            if (editorError.status === 1) {
              console.log(chalk.yellow('✗ Commit aborted by user'));
              process.exit(0);
            }
            console.error(chalk.red(`✗ Failed to commit: ${editorError.message}`));
            process.exit(1);
          }
        } else {
          console.error(chalk.red(`✗ Failed to commit: ${error.message}`));
          process.exit(1);
        }
      }
      
      // Create git summary task if requested
      if (options.summary) {
        console.log(chalk.blue('\n📋 Creating git summary task...'));
        
        // Check if daemon is running
        const daemonClient = new DaemonClient();
        if (!daemonClient.isDaemonRunning()) {
          console.error(chalk.red('✗ Daemon is not running - cannot create summary task'));
          console.log(chalk.yellow('💡 Start the daemon with: ani-code daemon --start'));
          process.exit(0); // Don't fail the whole command
        }
        
        const { basename } = await import('path');
        const projectDir = basename(process.cwd());
        const now = new Date();
        const hour = now.getHours().toString().padStart(2, '0');
        const minute = now.getMinutes().toString().padStart(2, '0');
        const taskName = `${projectDir}-git-summary-${hour}${minute}`;
        
        const summaryCommand = 'Summarize the git changes in this repository. Look at recent commits, current status, and any pending changes. Provide a clear overview of what has been modified recently.';
        
        const client = await getIPCClient();
        let task;
        try {
          const taskOptions = { cwd: process.cwd() };
          
          // Check if we're running as a child process with parent's chatId
          if (process.env.ANICODE_PARENT_CHAT_ID) {
            taskOptions.chatId = process.env.ANICODE_PARENT_CHAT_ID;
          }
          
          task = await client.addTask(taskName, summaryCommand, taskOptions);
        } finally {
          client.disconnect();
        }
        
        console.log(chalk.green(`✓ Git summary task created: ${task.name} (${task.id})`));
        console.log(chalk.yellow('💡 Use "ani-code watch ' + task.id + '" to see real-time output'));
      }
    } catch (error) {
      console.error(chalk.red(`Error: ${error.message}`));
      process.exit(1);
    }
  });

program
  .command('remember')
  .description('Save important information to CLAUDE.md for Claude to remember (supports @preset.md syntax, wildcards, and multiple presets)')
  .argument('[info]', 'Information to remember or @preset.md patterns (e.g. @main.md, @*.md, @api.md @web.md)')
  .option('-f, --file <file>', 'Read information from a file')
  .option('-y, --yolo', 'Auto-accept without prompting', false)
  .option('-v, --verbose', 'Show detailed debug logging', false)
  .action(async (info, options) => {
    try {
      // Validate daemon and IPC
      const daemonClient = new DaemonClient();
      if (!daemonClient.isDaemonRunning()) {
        console.error(chalk.red('✗ Daemon is not running - cannot use /remember command'));
        console.log(chalk.yellow('💡 Start the daemon with: ani-code daemon --start'));
        process.exit(1);
      }

      // Get information to remember
      let rememberInfo = info;
      let presetContent = '';

      // Check for @preset.md syntax - supports wildcards and regex patterns
      const presetMatches = rememberInfo ? rememberInfo.match(/@([\w*-]+)\.md/g) : null;
      if (presetMatches) {
        const { join, dirname } = await import('path');
        const { fileURLToPath } = await import('url');
        const { existsSync, readFileSync, readdirSync } = await import('fs');
        const __dirname = dirname(fileURLToPath(import.meta.url));
        const presetsDir = join(__dirname, 'presets');

        // Store all matching preset contents
        const matchedPresets = new Set();
        let combinedPresetContent = '';

        for (const match of presetMatches) {
          // Extract pattern from @pattern.md
          const pattern = match.replace('@', '').replace('.md', '');

          // Check if directory exists
          if (!existsSync(presetsDir)) {
            console.error(chalk.red(`✗ Presets directory not found: ${presetsDir}`));
            process.exit(1);
          }

          // Get all .md files in presets dir
          const allPresets = readdirSync(presetsDir).filter(f => f.endsWith('.md'));

          // Find matching files based on pattern
          let matchingFiles = [];
          if (pattern.includes('*')) {
            // Convert wildcard pattern to regex
            const regexPattern = pattern.replace(/\*/g, '.*');
            const regex = new RegExp(`^${regexPattern}$`);
            matchingFiles = allPresets.filter(f => regex.test(f.replace('.md', '')));
          } else {
            // Exact match
            const exactFile = `${pattern}.md`;
            if (allPresets.includes(exactFile)) {
              matchingFiles = [exactFile];
            }
          }

          // Read matching files
          for (const file of matchingFiles) {
            // Skip if already processed (for unique constraint)
            if (matchedPresets.has(file)) {
              continue;
            }
            matchedPresets.add(file);

            const presetFile = join(presetsDir, file);
            try {
              const content = readFileSync(presetFile, 'utf8');
              console.log(chalk.green(`✓ Found preset: ${file}`));

              // Add header for each preset if multiple
              if (matchedPresets.size > 1 || matchingFiles.length > 1) {
                combinedPresetContent += `\n\n# From preset: ${file}\n`;
              }
              combinedPresetContent += content;
            } catch (error) {
              console.error(chalk.red(`✗ Failed to read preset file ${file}: ${error.message}`));
              process.exit(1);
            }
          }

          // If no matches found for this pattern
          if (matchingFiles.length === 0) {
            console.error(chalk.red(`✗ No presets found matching pattern: ${pattern}`));
            console.log(chalk.yellow(`💡 Available presets in ${presetsDir}:`));
            allPresets.forEach(p => console.log(chalk.gray(`  - @${p.replace('.md', '')}.md`)));
            process.exit(1);
          }
        }

        // Remove all @preset.md patterns from the info
        let additionalInfo = rememberInfo;
        for (const match of presetMatches) {
          additionalInfo = additionalInfo.replace(match, '');
        }
        additionalInfo = additionalInfo.trim();

        // Combine preset content with additional info
        if (additionalInfo && combinedPresetContent) {
          rememberInfo = `${combinedPresetContent}\n\nAdditional context: ${additionalInfo}`;
        } else if (combinedPresetContent) {
          rememberInfo = combinedPresetContent;
        }

        // Report summary
        const fileCount = matchedPresets.size;
        if (fileCount > 1) {
          console.log(chalk.blue(`📚 Loaded ${fileCount} preset files`));
        }
      }

      // Read from file if specified
      if (options.file) {
        const { readFileSync } = await import('fs');
        try {
          rememberInfo = readFileSync(options.file, 'utf8').trim();
        } catch (error) {
          console.error(chalk.red(`✗ Failed to read file: ${error.message}`));
          process.exit(1);
        }
      }

      // Prompt if not provided
      if (!rememberInfo) {
        const rl = createInterface({
          input: process.stdin,
          output: process.stdout
        });

        rememberInfo = await new Promise(resolve => {
          rl.question(chalk.cyan('What should Claude remember? '), answer => {
            rl.close();
            resolve(answer.trim());
          });
        });

        if (!rememberInfo) {
          console.error(chalk.red('✗ No information provided'));
          process.exit(1);
        }
      }

      console.log(chalk.blue('\n📝 Updating CLAUDE.md with new information...'));

      // Create the task prompt for Claude
      const rememberPrompt = `You are a CLAUDE.md editor helper. Your task is to update the CLAUDE.md file to remember the following information:

"${rememberInfo}"

CRITICAL INSTRUCTIONS:
1. First, ALWAYS read the current CLAUDE.md file to understand its structure
2. If there are any conflicts between new and existing information, use the user's LATEST instruction
3. If you observe any serious issues or conflicts that cannot be resolved automatically, STOP editing and ask the user for suggestions
4. Add the new information in an appropriate section or create a new section if needed
5. Keep the existing critical warnings and structure intact
6. Format the information clearly and concisely
7. If the information is project-specific (like ports, endpoints, etc.), add it in a new "Project Information" section
8. If it's about commands or workflows, add it to the appropriate existing section
9. Use clear headings and bullet points where appropriate

ORGANIZATION GUIDELINES:
- For extended documentation, create files in pd/rules/ or pd/definitions/ instead of cluttering CLAUDE.md
- Place detailed specifications and reference materials in pd/rules/ for guidelines and standards
- Use pd/definitions/ for technical definitions and reference materials
- Keep CLAUDE.md focused on essential configuration and critical warnings
- Reference the organized directories when appropriate (e.g., "See pd/rules/api-conventions.md for details")

The CLAUDE.md file is used by Claude in all future conversations, so make sure the information is:
- Clear and actionable
- Well-organized within the existing structure
- Not duplicating existing information (unless explicitly updating)
- Preserving all existing critical warnings and important notes
- Using the user's latest instruction when there are conflicts
- Properly organized with extended content in pd/rules/ and pd/definitions/

@@sonnet`;

      // Create the task
      const client = await getIPCClient();
      const { basename } = await import('path');
      const projectDir = basename(process.cwd());
      const now = new Date();
      const hour = now.getHours().toString().padStart(2, '0');
      const minute = now.getMinutes().toString().padStart(2, '0');
      const taskName = `${projectDir}-remember-${hour}${minute}`;

      const taskOptions = {
        cwd: process.cwd(),
        yolo: options.yolo
      };

      if (process.env.ANICODE_PARENT_CHAT_ID) {
        taskOptions.chatId = process.env.ANICODE_PARENT_CHAT_ID;
      }

      const task = await client.addTask(taskName, rememberPrompt, taskOptions);

      if (!options.yolo) {
        console.log(chalk.green(`✓ Task created: ${task.id} - ${taskName}`));
        console.log(chalk.gray(`Claude will update CLAUDE.md to remember: "${rememberInfo.substring(0, 50)}${rememberInfo.length > 50 ? '...' : ''}"`));
        console.log(chalk.yellow('\n💡 Use "ani-code status" to monitor progress'));
      } else {
        console.log(chalk.gray('⏳ Waiting for Claude to update CLAUDE.md...'));

        // Wait for task completion in YOLO mode
        let attempts = 0;
        const maxAttempts = 300;

        while (attempts < maxAttempts) {
          await new Promise(resolve => setTimeout(resolve, 1000));
          attempts++;

          let currentTask = await client.getTask(task.id);
          if (!currentTask) {
            currentTask = await client.getHistoryTask(task.id);
          }

          if (currentTask && currentTask.status === 'completed') {
            console.log(chalk.green('✓ CLAUDE.md has been updated successfully'));
            console.log(chalk.gray(`Claude will now remember: "${rememberInfo.substring(0, 100)}${rememberInfo.length > 100 ? '...' : ''}"`));
            break;
          } else if (currentTask && currentTask.status === 'failed') {
            console.error(chalk.red('✗ Failed to update CLAUDE.md'));
            if (options.verbose && currentTask.error) {
              console.log(chalk.gray(`Error: ${currentTask.error}`));
            }
            process.exit(1);
          }

          if (attempts % 10 === 0) {
            console.log(chalk.yellow(`Still processing... (${attempts}s)`));
          }
        }

        if (attempts >= maxAttempts) {
          console.error(chalk.red('✗ Task timed out'));
          process.exit(1);
        }
      }

      process.exit(0);
    } catch (error) {
      console.error(chalk.red(`✗ Error: ${error.message}`));
      if (options.verbose) {
        console.error(error);
      }
      process.exit(1);
    }
  });

program
  .command('rulecompress')
  .description('Compress and organize CLAUDE.md by extracting details to pd/rules/ folder')
  .argument('[context]', 'Optional additional context or specific instructions')
  .option('-y, --yolo', 'Auto-accept without prompting', false)
  .option('-v, --verbose', 'Show detailed debug logging', false)
  .action(async (context, options) => {
    try {
      // Validate daemon and IPC
      const daemonClient = new DaemonClient();
      if (!daemonClient.isDaemonRunning()) {
        console.error(chalk.red('✗ Daemon is not running - cannot use rulecompress command'));
        console.log(chalk.yellow('💡 Start the daemon with: ani-code daemon --start'));
        process.exit(1);
      }

      // Build the compression prompt
      const rulecompressPrompt = `You are tasked with compressing and organizing the CLAUDE.md file by extracting detailed content to the pd/rules folder.

## Objective

Reduce the size of CLAUDE.md by:
1. Identifying verbose or detailed sections
2. Extracting them to appropriate files in pd/rules/
3. Replacing the detailed content with concise summaries and references
4. Keeping CLAUDE.md as a high-level reference guide

## Process

1. **Read Current State**
   - Read the entire CLAUDE.md file
   - Identify sections that are too detailed or verbose
   - Check existing pd/rules/ structure

2. **Extract Details**
   - For each verbose section, create or update a file in pd/rules/
   - Use descriptive filenames (e.g., port-configuration.md, service-management.md)
   - Preserve all information - nothing should be lost
   - Group related content logically

3. **Update CLAUDE.md**
   - Replace detailed sections with concise summaries (2-4 lines)
   - Add clear references to the detailed documentation
   - Format: "For detailed information, see: pd/rules/[filename].md"
   - Maintain the overall structure and flow

4. **Verify Organization**
   - Ensure CLAUDE.md remains coherent and easy to scan
   - Check that all extracted details are properly referenced
   - Confirm no information was lost in the process

## Example Transformation

### Before (verbose in CLAUDE.md):
\`\`\`markdown
## Port Configuration

### Default Ports
- **Daemon HTTP API**: \`6501\` (primary service port)
- **WebSocket Service**: \`6502\` (real-time communications)

### Port Priority (Daemon HTTP API)
The daemon port is selected with the following priority:
1. \`ANI_CODE_DAEMON_PORT\` - Primary daemon-specific variable
2. \`HTTP_CALLBACK_PORT\` - Legacy fallback
3. \`PORT\` - Generic fallback
4. Default: \`6501\`

### Environment Variables
\`\`\`bash
# Daemon HTTP API Port
ANI_CODE_DAEMON_PORT=6501         # Primary (recommended)
...
\`\`\`
\`\`\`

### After (concise in CLAUDE.md):
\`\`\`markdown
## Port Configuration

Default ports: HTTP API (6501), WebSocket (6502). Configure via \`ANI_CODE_DAEMON_PORT\` and \`ANICODE_WS_PORT\` environment variables.

For detailed port configuration, priority rules, and examples, see: pd/rules/port-configuration.md
\`\`\`

## Rules to Follow

1. **Preserve Information**: Never delete information - only relocate it
2. **Maintain References**: Always provide clear paths to detailed docs
3. **Keep Critical Warnings**: Security warnings and critical notices stay in CLAUDE.md
4. **Logical Grouping**: Group related topics in the same pd/rules file
5. **Consistent Format**: Use consistent markdown formatting across files

## Output Format

After completing the compression, provide:
1. List of files created/updated in pd/rules/
2. Summary of changes made to CLAUDE.md
3. Confirmation that all information was preserved
4. New total line count of CLAUDE.md (target: 50-70% reduction)

${context ? `\n## Additional Context from User\n\n${context}\n` : ''}

---

Begin the compression process now. Read CLAUDE.md, identify verbose sections, extract them to pd/rules/, and update CLAUDE.md with concise summaries and references.`;

      // Connect to IPC
      const client = await getIPCClient();

      if (options.verbose) {
        console.log(chalk.gray('Creating rule compression task...'));
      }

      // Create the task
      const taskId = await client.addTask(
        'CLAUDE.md Rule Compression',
        rulecompressPrompt,
        {
          type: 'add',
          priority: 'high'
        }
      );

      console.log(chalk.green('✓ Rule compression task created'));
      console.log(chalk.gray(`Task ID: ${taskId}`));

      // Poll for completion if not yolo mode
      if (!options.yolo) {
        console.log(chalk.gray('\nProcessing (this may take a minute)...'));

        const maxAttempts = 300; // 5 minutes
        let attempts = 0;

        while (attempts < maxAttempts) {
          await new Promise(resolve => setTimeout(resolve, 1000));
          attempts++;

          const currentTask = await client.getTaskStatus(taskId);

          if (currentTask && currentTask.status === 'completed') {
            console.log(chalk.green('✓ CLAUDE.md compression complete'));
            console.log(chalk.gray('Files have been organized in pd/rules/'));
            break;
          } else if (currentTask && currentTask.status === 'failed') {
            console.error(chalk.red('✗ Failed to compress CLAUDE.md'));
            if (options.verbose && currentTask.error) {
              console.log(chalk.gray(`Error: ${currentTask.error}`));
            }
            process.exit(1);
          }

          if (attempts % 10 === 0) {
            console.log(chalk.yellow(`Still processing... (${attempts}s)`));
          }
        }

        if (attempts >= maxAttempts) {
          console.error(chalk.red('✗ Task timed out'));
          process.exit(1);
        }
      }

      process.exit(0);
    } catch (error) {
      console.error(chalk.red(`✗ Error: ${error.message}`));
      if (options.verbose) {
        console.error(error);
      }
      process.exit(1);
    }
  });

program
  .command('macros')
  .description('List and show all macro commands for the current workspace')
  .option('-v, --verbose', 'Show full macro content without truncation', false)
  .action(async (options) => {
    try {
      // Import necessary modules
      const { WorkspaceManager } = await import('./workspace-manager.js');
      const chalk = (await import('chalk')).default;

      // Initialize workspace manager
      const manager = new WorkspaceManager();
      await manager.initialize();

      // Get current workspace
      const currentWorkspace = await manager.getCurrentWorkspace();
      if (!currentWorkspace) {
        console.log(chalk.yellow('No workspace found in current directory'));
        console.log(chalk.gray('Use "ani-code workspace create" or navigate to a workspace directory'));
        await manager.close();
        process.exit(0);
      }

      // Get all macros for the workspace
      const allMeta = await manager.listWorkspaceMeta(currentWorkspace.id, 'macro-');
      const macros = Object.entries(allMeta);

      if (macros.length === 0) {
        console.log(chalk.yellow('No macros defined for this workspace'));
        console.log(chalk.gray('\nCreate a macro with: ani-code workspace macro set <name> <command>'));
        console.log(chalk.gray('Example: ani-code workspace macro set progress "/add what is the current progress"'));
        await manager.close();
        process.exit(0);
      }

      // Display macros
      console.log(chalk.bold(`\n📝 Macros for workspace "${currentWorkspace.name}":\n`));

      // Format as code block
      console.log('```');
      for (const [key, value] of macros) {
        const macroName = key.replace('macro-', '');

        // Truncate content if too long and not verbose mode
        let content = value;
        if (!options.verbose && content.length > 100) {
          content = content.substring(0, 97) + '...';
        }

        console.log(`/$${macroName}`);
        console.log(`  ${content}`);
        console.log('');
      }
      console.log('```');

      console.log(chalk.gray(`\n${macros.length} macro${macros.length !== 1 ? 's' : ''} defined`));
      console.log(chalk.gray('Execute in Telegram with: /$<name>'));

      if (!options.verbose && macros.some(([k, v]) => v.length > 100)) {
        console.log(chalk.gray('Use -v flag to see full content'));
      }

      await manager.close();
      process.exit(0);
    } catch (error) {
      console.error(chalk.red(`✗ Failed to list macros: ${error.message}`));
      process.exit(1);
    }
  });

program
  .command('branch')
  .description('Create or switch git branches with smart naming')
  .argument('[reason]', 'Branch name or description (auto-generates if not provided)')
  .option('-v, --verbose', 'Show detailed debug logging', false)
  .action(async (reason, options) => {
    try {
      const { BranchManager } = await import('./services/branch-manager.js');
      const branchManager = new BranchManager();
      
      // Check if daemon is running (needed for auto-generation)
      const daemonClient = new DaemonClient();
      let ipcClient = null;
      
      if (daemonClient.isDaemonRunning()) {
        try {
          ipcClient = await getIPCClient();
        } catch (error) {
          console.error(chalk.yellow('⚠️  Daemon is running but IPC connection failed'));
        }
      }
      
      const result = await branchManager.handleBranchCommand(reason, {
        ipcClient: ipcClient,
        cwd: process.cwd(),
        verbose: options.verbose
      });
      
      // Disconnect IPC client if it was connected
      if (ipcClient) {
        ipcClient.disconnect();
      }
      
      console.log(branchManager.formatBranchResult(result));
      
      if (!result.success) {
        process.exit(1);
      }
    } catch (error) {
      console.error(chalk.red(`✗ Branch operation failed: ${error.message}`));
      process.exit(1);
    }
  });

program
  .command('add')
  .description('Add a new Claude task to the queue (supports @preset.md syntax)')
  .argument('[name]', 'Task name (auto-generated if not provided)')
  .argument('[command]', 'Claude command to execute (supports @preset.md, optional - will prompt for paragraph input if not provided)')
  .option('-t, --timeout <ms>', 'Task timeout in milliseconds', parseInt)
  .option('-f, --file <file>', 'Read prompt from markdown file')
  .option('-w, --workdir <dir>', 'Set working directory (relative to current dir)')
  .action(async (name, command, options) => {
    try {
      // Check if daemon is running
      const daemonClient = new DaemonClient();
      if (!daemonClient.isDaemonRunning()) {
        console.error(chalk.red('✗ Daemon is not running'));
        console.log(chalk.yellow('💡 Start the daemon with: ani-code daemon --start'));
        console.log(chalk.yellow('💡 Or install service with: ani-code service install --user'));
        process.exit(1);
      }

      // Check version compatibility
      await checkDaemonVersion();
      
      // Import required modules
      const path = await import('path');
      const fs = await import('fs/promises');
      
      // Handle workdir option - resolve relative to current directory
      let workingDir = process.cwd();
      if (options.workdir) {
        let adjustedPath = options.workdir;
        
        // Handle absolute-looking paths that should be relative
        if (adjustedPath.startsWith('/') && !adjustedPath.startsWith(process.cwd())) {
          // Check if it exists as absolute path first
          try {
            const stats = await fs.stat(adjustedPath);
            if (stats.isDirectory()) {
              // It's a valid absolute path, use it as is
              workingDir = adjustedPath;
            } else {
              throw new Error('Not a directory');
            }
          } catch {
            // Doesn't exist as absolute, treat as relative
            adjustedPath = adjustedPath.substring(1); // Remove leading /
            workingDir = path.resolve(process.cwd(), adjustedPath);
            console.log(chalk.yellow(`⚠️  Treating '${options.workdir}' as relative path: ${workingDir}`));
          }
        } else {
          // Normal relative path handling
          workingDir = path.resolve(process.cwd(), adjustedPath);
        }
        
        // Check if workdir exists
        try {
          const stats = await fs.stat(workingDir);
          if (!stats.isDirectory()) {
            console.error(chalk.red(`✗ Working directory is not a directory: ${workingDir}`));
            process.exit(1);
          }
        } catch (error) {
          console.error(chalk.red(`✗ Working directory does not exist: ${workingDir}`));
          process.exit(1);
        }
      }
      
      // Handle file option - read prompt from markdown file
      if (options.file) {
        const filePath = path.resolve(process.cwd(), options.file);
        try {
          const fileContent = await fs.readFile(filePath, 'utf-8');
          command = fileContent;
          // Use filename without extension as task name if not provided
          if (!name) {
            name = path.basename(filePath, path.extname(filePath));
          }
        } catch (error) {
          console.error(chalk.red(`✗ Failed to read file: ${error.message}`));
          process.exit(1);
        }
      }
      
      // Generate task name if not provided
      if (!name) {
        const projectDir = path.basename(workingDir);
        const now = new Date();
        const hour = now.getHours().toString().padStart(2, '0');
        const minute = now.getMinutes().toString().padStart(2, '0');
        name = `${projectDir}-task-${hour}${minute}`;
      }
      
      let finalCommand = command;

      // If no command provided and no file option, prompt for paragraph input
      if (!command && !options.file) {
        console.log(chalk.blue('\n📝 Enter your Claude prompt (press Enter twice to finish):'));
        console.log(chalk.gray('─'.repeat(50)));

        finalCommand = await getParagraphInput();

        if (!finalCommand.trim()) {
          console.error(chalk.red('Error: No input provided'));
          process.exit(1);
        }

        console.log(chalk.gray('─'.repeat(50)));
      }

      // Process any preset templates in the command
      if (finalCommand) {
        const originalCommand = finalCommand;
        const presetResult = await processPresets(finalCommand);
        finalCommand = presetResult.text;

        // Show expansion preview if presets were detected
        if (originalCommand.includes('@') && originalCommand.match(/@[\w*-]+\.md/)) {
          console.log(chalk.blue('\n📋 Preset detected and expanded'));

          // Extract preset names for tag generation
          const presetMatches = originalCommand.match(/@([\w*-]+)\.md/g) || [];
          const presetNames = presetMatches.map(m => m.replace('@', '').replace('.md', ''));

          // Check if expansion resulted in long content that needs wrapping
          const expansionLines = finalCommand.split('\n');
          const isLongExpansion = expansionLines.length > 15;

          if (isLongExpansion) {
            // For long expansions, show minimal preview and wrap in tags
            console.log(chalk.gray('─'.repeat(50)));

            // Show user's original request first
            const userTextMatch = originalCommand.replace(/@[\w*-]+\.md/g, '').trim();
            if (userTextMatch) {
              console.log(chalk.cyan('Your request:'));
              console.log(userTextMatch);
              console.log();
            }

            // Show which presets were loaded
            console.log(chalk.green(`✓ Loaded preset${presetNames.length > 1 ? 's' : ''}: ${presetNames.map(n => `@${n}.md`).join(', ')}`));
            console.log(chalk.gray(`📄 Expanded to ${expansionLines.length} lines`));

            // For very long content, wrap in XML-style tags
            if (presetNames.length === 1) {
              console.log(chalk.gray(`\nContent wrapped in <${presetNames[0]}>...</${presetNames[0]}> tags`));
            } else {
              console.log(chalk.gray(`\nContent wrapped in <presets>...</presets> tags`));
            }

            console.log(chalk.gray('─'.repeat(50)));
          } else {
            // For shorter expansions, show the full content
            console.log(chalk.gray('─'.repeat(50)));
            console.log(finalCommand);
            console.log(chalk.gray('─'.repeat(50)));
            console.log(chalk.green(`✓ Preset${presetNames.length > 1 ? 's' : ''} expanded and applied`));
          }
          console.log();
        }
      }

      // Validate that prompt doesn't start with '/' to avoid CLI parsing issues
      if (finalCommand && finalCommand.trim().startsWith('/')) {
        console.error(chalk.red('✗ Error: Task prompt cannot start with "/"'));
        console.log(chalk.yellow('⚠️  Prompts starting with "/" may be parsed incorrectly by different CLIs'));
        console.log(chalk.yellow('💡 Please remove the leading "/" from your prompt'));
        process.exit(1);
      }

      // Connect to daemon via IPC
      const client = await getIPCClient();
      let task;
      try {
        // Capture working directory and pass it with options
        const taskOptions = { 
          ...options, 
          cwd: workingDir 
        };
        
        // Check if we're running as a child process with parent's chatId
        if (process.env.ANICODE_PARENT_CHAT_ID) {
          taskOptions.chatId = process.env.ANICODE_PARENT_CHAT_ID;
        }
        
        task = await client.addTask(name, finalCommand, taskOptions);
      } finally {
        client.disconnect();
      }
      
      console.log(chalk.green(`✓ Task added: ${task.name} (${task.id})`));
    } catch (error) {
      console.error(chalk.red(`Error: ${error.message}`));
      process.exit(1);
    }
  });

program
  .command('continue')
  .description('Continue a Claude conversation (same as add with -c flag, supports @preset.md syntax)')
  .argument('[name]', 'Task name (auto-generated if not provided)')
  .argument('[command]', 'Claude command to execute (supports @preset.md, optional - will prompt for paragraph input if not provided)')
  .option('-t, --timeout <ms>', 'Task timeout in milliseconds', parseInt)
  .option('-f, --file <file>', 'Read prompt from markdown file')
  .option('-w, --workdir <dir>', 'Set working directory (relative to current dir)')
  .action(async (name, command, options) => {
    try {
      // Check if daemon is running
      const daemonClient = new DaemonClient();
      if (!daemonClient.isDaemonRunning()) {
        console.error(chalk.red('✗ Daemon is not running'));
        console.log(chalk.yellow('💡 Start the daemon with: ani-code daemon --start'));
        console.log(chalk.yellow('💡 Or install service with: ani-code service install --user'));
        process.exit(1);
      }

      // Check version compatibility
      await checkDaemonVersion();
      
      // Import required modules
      const path = await import('path');
      const fs = await import('fs/promises');
      
      // Handle workdir option - resolve relative to current directory
      let workingDir = process.cwd();
      if (options.workdir) {
        let adjustedPath = options.workdir;
        
        // Handle absolute-looking paths that should be relative
        if (adjustedPath.startsWith('/') && !adjustedPath.startsWith(process.cwd())) {
          // Check if it exists as absolute path first
          try {
            const stats = await fs.stat(adjustedPath);
            if (stats.isDirectory()) {
              // It's a valid absolute path, use it as is
              workingDir = adjustedPath;
            } else {
              throw new Error('Not a directory');
            }
          } catch {
            // Doesn't exist as absolute, treat as relative
            adjustedPath = adjustedPath.substring(1); // Remove leading /
            workingDir = path.resolve(process.cwd(), adjustedPath);
            console.log(chalk.yellow(`⚠️  Treating '${options.workdir}' as relative path: ${workingDir}`));
          }
        } else {
          // Normal relative path handling
          workingDir = path.resolve(process.cwd(), adjustedPath);
        }
        
        // Check if workdir exists
        try {
          const stats = await fs.stat(workingDir);
          if (!stats.isDirectory()) {
            console.error(chalk.red(`✗ Working directory is not a directory: ${workingDir}`));
            process.exit(1);
          }
        } catch (error) {
          console.error(chalk.red(`✗ Working directory does not exist: ${workingDir}`));
          process.exit(1);
        }
      }
      
      // Handle file option - read prompt from markdown file
      if (options.file) {
        const filePath = path.resolve(process.cwd(), options.file);
        try {
          const fileContent = await fs.readFile(filePath, 'utf-8');
          command = fileContent;
          // Use filename without extension as task name if not provided
          if (!name) {
            name = path.basename(filePath, path.extname(filePath));
          }
        } catch (error) {
          console.error(chalk.red(`✗ Failed to read file: ${error.message}`));
          process.exit(1);
        }
      }
      
      // Generate task name if not provided
      if (!name) {
        const projectDir = path.basename(workingDir);
        const now = new Date();
        const hour = now.getHours().toString().padStart(2, '0');
        const minute = now.getMinutes().toString().padStart(2, '0');
        name = `${projectDir}-continue-${hour}${minute}`;
      }
      
      let finalCommand = command;

      // If no command provided and no file option, prompt for paragraph input
      if (!command && !options.file) {
        console.log(chalk.blue('\n📝 Enter your Claude prompt (press Enter twice to finish):'));
        console.log(chalk.gray('─'.repeat(50)));

        finalCommand = await getParagraphInput();

        if (!finalCommand.trim()) {
          console.error(chalk.red('Error: No input provided'));
          process.exit(1);
        }

        console.log(chalk.gray('─'.repeat(50)));
      }

      // Process any preset templates in the command
      if (finalCommand) {
        const originalCommand = finalCommand;
        const presetResult = await processPresets(finalCommand);
        finalCommand = presetResult.text;

        // Show expansion preview if presets were detected
        if (originalCommand.includes('@') && originalCommand.match(/@[\w*-]+\.md/)) {
          console.log(chalk.blue('\n📋 Preset detected and expanded'));

          // Extract preset names for tag generation
          const presetMatches = originalCommand.match(/@([\w*-]+)\.md/g) || [];
          const presetNames = presetMatches.map(m => m.replace('@', '').replace('.md', ''));

          // Check if expansion resulted in long content that needs wrapping
          const expansionLines = finalCommand.split('\n');
          const isLongExpansion = expansionLines.length > 15;

          if (isLongExpansion) {
            // For long expansions, show minimal preview and wrap in tags
            console.log(chalk.gray('─'.repeat(50)));

            // Show user's original request first
            const userTextMatch = originalCommand.replace(/@[\w*-]+\.md/g, '').trim();
            if (userTextMatch) {
              console.log(chalk.cyan('Your request:'));
              console.log(userTextMatch);
              console.log();
            }

            // Show which presets were loaded
            console.log(chalk.green(`✓ Loaded preset${presetNames.length > 1 ? 's' : ''}: ${presetNames.map(n => `@${n}.md`).join(', ')}`));
            console.log(chalk.gray(`📄 Expanded to ${expansionLines.length} lines`));

            // For very long content, wrap in XML-style tags
            if (presetNames.length === 1) {
              console.log(chalk.gray(`\nContent wrapped in <${presetNames[0]}>...</${presetNames[0]}> tags`));
            } else {
              console.log(chalk.gray(`\nContent wrapped in <presets>...</presets> tags`));
            }

            console.log(chalk.gray('─'.repeat(50)));
          } else {
            // For shorter expansions, show the full content
            console.log(chalk.gray('─'.repeat(50)));
            console.log(finalCommand);
            console.log(chalk.gray('─'.repeat(50)));
            console.log(chalk.green(`✓ Preset${presetNames.length > 1 ? 's' : ''} expanded and applied`));
          }
          console.log();
        }
      }

      // Validate that prompt doesn't start with '/' to avoid CLI parsing issues
      if (finalCommand && finalCommand.trim().startsWith('/')) {
        console.error(chalk.red('✗ Error: Task prompt cannot start with "/"'));
        console.log(chalk.yellow('⚠️  Prompts starting with "/" may be parsed incorrectly by different CLIs'));
        console.log(chalk.yellow('💡 Please remove the leading "/" from your prompt'));
        process.exit(1);
      }

      // Prepend -c flag to the command for continue mode
      finalCommand = `-c ${finalCommand}`;

      // Connect to daemon via IPC
      const client = await getIPCClient();
      let task;
      try {
        // Capture working directory and pass it with options
        const taskOptions = { 
          ...options, 
          cwd: workingDir 
        };
        
        // Check if we're running as a child process with parent's chatId
        if (process.env.ANICODE_PARENT_CHAT_ID) {
          taskOptions.chatId = process.env.ANICODE_PARENT_CHAT_ID;
        }
        
        task = await client.addTask(name, finalCommand, taskOptions);
      } finally {
        client.disconnect();
      }
      
      console.log(chalk.green(`✓ Continue task added: ${task.name} (${task.id})`));
    } catch (error) {
      console.error(chalk.red(`Error: ${error.message}`));
      process.exit(1);
    }
  });

program
  .command('grant')
  .description('Review last Claude message and grant required permissions automatically')
  .argument('[instructions]', 'Additional instructions for permission review')
  .option('-w, --workdir <dir>', 'Set working directory (relative to current dir)')
  .action(async (instructions, options) => {
    try {
      // Check if daemon is running
      const daemonClient = new DaemonClient();
      if (!daemonClient.isDaemonRunning()) {
        console.error(chalk.red('✗ Daemon is not running'));
        console.log(chalk.yellow('💡 Start the daemon with: ani-code daemon --start'));
        console.log(chalk.yellow('💡 Or install service with: ani-code service install --user'));
        process.exit(1);
      }

      // Check version compatibility
      await checkDaemonVersion();

      // Import required modules
      const path = await import('path');
      const fs = await import('fs/promises');

      // Handle workdir option - resolve relative to current directory
      let workingDir = process.cwd();
      if (options.workdir) {
        let adjustedPath = options.workdir;

        // Handle absolute-looking paths that should be relative
        if (adjustedPath.startsWith('/') && !adjustedPath.startsWith(process.cwd())) {
          // Check if it exists as absolute path first
          try {
            const stats = await fs.stat(adjustedPath);
            if (stats.isDirectory()) {
              // It's a valid absolute path, use it as is
              workingDir = adjustedPath;
            } else {
              throw new Error('Not a directory');
            }
          } catch {
            // Doesn't exist as absolute, treat as relative
            adjustedPath = adjustedPath.substring(1); // Remove leading /
            workingDir = path.resolve(process.cwd(), adjustedPath);
            console.log(chalk.yellow(`⚠️  Treating '${options.workdir}' as relative path: ${workingDir}`));
          }
        } else {
          // Normal relative path handling
          workingDir = path.resolve(process.cwd(), adjustedPath);
        }

        // Check if workdir exists
        try {
          const stats = await fs.stat(workingDir);
          if (!stats.isDirectory()) {
            console.error(chalk.red(`✗ Working directory is not a directory: ${workingDir}`));
            process.exit(1);
          }
        } catch (error) {
          console.error(chalk.red(`✗ Working directory does not exist: ${workingDir}`));
          process.exit(1);
        }
      }

      // Create permission review prompt
      const grantPrompt = `You are in High Privilege Mode for permission management.

## Task
Review the last Claude message in the conversation history and identify any permission blocks or denied operations.

## Analysis Steps
1. Check the last message for:
   - Permission errors ("This tool requires approval", "permission denied")
   - Blocked Bash commands
   - Blocked file operations (Read/Write/Edit)
   - Blocked MCP function calls
   - Tool use errors related to permissions

2. Identify the permission pattern needed:
   - Bash commands: \`Bash(command:*)\`
   - File reads: \`Read(path)\` or \`Read(path/**/*)\`
   - File writes: \`Write(path)\` or \`Write(path/**/*)\`
   - File edits: \`Edit(path)\` or \`Edit(path/**/*)\`
   - MCP tools: \`mcp__server__function(*)\`

3. Update .claude/settings.local.json:
   - Add permission to permissions.allow array
   - Use wildcards appropriately for flexibility
   - Keep alphabetical order within sections
   - Ensure valid JSON syntax
   - If the file doesn't exist, create it with proper structure

4. Report back:
   - What permission was blocked
   - What pattern was added
   - Confirmation the file was updated
   - Suggest retrying the original operation

${instructions ? `\n## Additional Instructions\n${instructions}\n` : ''}

## Example Permission Patterns
- \`Bash(npm install:*)\` - npm install commands
- \`Bash(python3:*)\` - Python 3 scripts
- \`Bash(curl:*)\` - curl requests
- \`Read(/etc/**/*)\` - Read files in /etc
- \`Write(/tmp/**/*)\` - Write to tmp
- \`Edit(./**/*)\` - Edit any file in current dir

## Important Guidelines
- Be specific but not overly restrictive
- Use wildcards to avoid repeated approvals
- Never grant overly broad permissions like \`Bash(*)\`
- Preserve all existing permissions
- Validate JSON before saving
- If no permission issues found, report "No permission issues detected"

Now analyze the conversation and grant necessary permissions.`;

      // Generate task name
      const projectDir = path.basename(workingDir);
      const now = new Date();
      const hour = now.getHours().toString().padStart(2, '0');
      const minute = now.getMinutes().toString().padStart(2, '0');
      const name = `${projectDir}-grant-${hour}${minute}`;

      // Prepend -c flag for continue mode (high privilege)
      const finalCommand = `-c ${grantPrompt}`;

      console.log(chalk.blue('🔐 Launching permission review task...'));

      // Connect to daemon via IPC
      const client = await getIPCClient();
      let task;
      try {
        const taskOptions = {
          ...options,
          cwd: workingDir
        };

        // Check if we're running as a child process with parent's chatId
        if (process.env.ANICODE_PARENT_CHAT_ID) {
          taskOptions.chatId = process.env.ANICODE_PARENT_CHAT_ID;
        }

        task = await client.addTask(name, finalCommand, taskOptions);
      } finally {
        client.disconnect();
      }

      console.log(chalk.green(`✓ Permission review task created: ${task.name} (${task.id})`));
      console.log(chalk.gray('  Claude will analyze blocked operations and update permissions'));
    } catch (error) {
      console.error(chalk.red(`Error: ${error.message}`));
      process.exit(1);
    }
  });

program
  .command('plan [action] [args...]')
  .description('Manage task plans (create, list, reset, delete)')
  .option('-f, --file <file>', 'Read plan from markdown file')
  .option('-i, --id <id>', 'Custom plan ID')
  .option('-t, --title <title>', 'Plan title')
  .option('-s, --status <status>', 'Filter by status (for list/reset)')
  .option('-y, --yes', 'Skip confirmation prompts')
  .action(async (action, args, options) => {
    try {
      // Import required modules
      const { WorkspaceManager } = await import('./workspace-manager.js');
      const path = await import('path');
      const fs = await import('fs/promises');

      const manager = new WorkspaceManager();
      await manager.initialize();

      // Get current workspace
      const currentWorkspace = await manager.getCurrentWorkspace();
      if (!currentWorkspace) {
        console.error(chalk.red('✗ Not in a workspace directory'));
        console.log(chalk.yellow('💡 Create a workspace with: ani-code workspace create'));
        await manager.close();
        process.exit(1);
      }

      // Handle different plan actions
      switch (action) {
        case 'list':
        case 'ls':
          // List all plans
          const plans = await manager.listPlans(currentWorkspace.id, options.status);

          if (plans.length === 0) {
            console.log(chalk.yellow(`No plans found${options.status ? ` with status: ${options.status}` : ''}`));
          } else {
            console.log(chalk.bold(`\n📋 Plans in workspace: ${currentWorkspace.name}\n`));

            for (const plan of plans) {
              const statusEmoji = plan.status === 'completed' ? '✅' :
                                 plan.status === 'in_progress' ? '🔄' :
                                 plan.status === 'paused' ? '⏸️' : '📝';

              console.log(`${statusEmoji} ${chalk.bold(plan.plan_id)}`);
              console.log(`   Title: ${plan.title}`);
              console.log(`   Status: ${plan.status} (Step ${plan.current_step || 0}/${plan.steps.length})`);
              console.log(`   Created: ${new Date(plan.created_at).toLocaleString()}`);

              // Show commit info for completed plans
              if (plan.status === 'completed') {
                const metadata = typeof plan.metadata === 'string'
                  ? JSON.parse(plan.metadata || '{}')
                  : (plan.metadata || {});
                if (metadata.yolo_commit) {
                  console.log(`   ${chalk.gray('Commit:')} ${chalk.yellow(metadata.yolo_commit.hash)} - ${metadata.yolo_commit.message}`);
                }
              }

              if (plan.steps.length > 0) {
                console.log(`   Steps:`);
                plan.steps.slice(0, 3).forEach((step, i) => {
                  const marker = i < (plan.current_step || 0) ? '✓' : '•';
                  const stepText = getPlanStepDisplayText(step);
                  const truncated = stepText.length > 60 ? `${stepText.substring(0, 57)}...` : stepText;
                  console.log(`     ${marker} ${truncated}`);
                });
                if (plan.steps.length > 3) {
                  console.log(`     ... and ${plan.steps.length - 3} more`);
                }
              }
              console.log();
            }
          }

          await manager.close();
          return;

        case 'reset':
        case 'clear':
          // Reset/clear plans
          // First, show the plans that will be deleted
          const plansToDelete = await manager.listPlans(currentWorkspace.id, options.status || null);

          if (!plansToDelete || plansToDelete.length === 0) {
            console.log(chalk.yellow('No plans to reset'));
            await manager.close();
            return;
          }

          // Display plans that will be deleted
          console.log(chalk.cyan(`\nPlans that will be deleted (${plansToDelete.length} total):`));
          console.log(chalk.gray('─'.repeat(80)));

          for (const plan of plansToDelete) {
            const statusColor = {
              pending: 'gray',
              in_progress: 'yellow',
              completed: 'green',
              failed: 'red',
              paused: 'blue',
              cancelled: 'magenta'
            }[plan.status] || 'white';

            console.log(`  ${chalk.cyan('ID:')} ${plan.id.slice(0, 8)}  ${chalk[statusColor](`[${plan.status.toUpperCase()}]`)}`);
            console.log(`  ${chalk.gray('Name:')} ${plan.name || 'Unnamed plan'}`);

            if (plan.description) {
              console.log(`  ${chalk.gray('Description:')} ${plan.description}`);
            }

            const steps = Array.isArray(plan.steps) ? plan.steps : JSON.parse(plan.steps || '[]');
            const currentStep = plan.current_step || 0;
            const totalSteps = steps.length;

            if (totalSteps > 0) {
              console.log(`  ${chalk.gray('Progress:')} ${currentStep}/${totalSteps} steps`);

              // Show step details
              if (options.verbose) {
                console.log(`  ${chalk.gray('Steps:')}`);
                steps.forEach((step, idx) => {
                  const stepStatus = idx < currentStep ? '✓' : idx === currentStep ? '→' : ' ';
                  const stepColor = idx < currentStep ? 'green' : idx === currentStep ? 'yellow' : 'gray';
                  console.log(`    ${chalk[stepColor](stepStatus)} ${step}`);
                });
              }
            }

            console.log(`  ${chalk.gray('Created:')} ${new Date(plan.created_at).toLocaleString()}`);

            if (plan.error_message) {
              console.log(`  ${chalk.red('Error:')} ${plan.error_message}`);
            }

            console.log(chalk.gray('─'.repeat(80)));
          }

          if (!options.yes) {
            const rl = createInterface({
              input: process.stdin,
              output: process.stdout
            });

            const statusFilter = options.status ? ` with status: ${options.status}` : '';
            const answer = await new Promise((resolve) => {
              rl.question(chalk.yellow(`\nAre you sure you want to delete these ${plansToDelete.length} plan(s) in workspace "${currentWorkspace.name}"${statusFilter}? (yes/no): `), resolve);
            });
            rl.close();

            if (answer.toLowerCase() !== 'yes' && answer.toLowerCase() !== 'y') {
              console.log(chalk.gray('Operation cancelled'));
              await manager.close();
              return;
            }
          }

          const resetResult = await manager.resetPlans(currentWorkspace.id, options.status);

          if (resetResult.success) {
            console.log(chalk.green(`✓ ${resetResult.message}`));
          } else {
            console.log(chalk.red(`✗ Failed to reset plans: ${resetResult.message}`));
          }

          await manager.close();
          return;

        case 'delete':
        case 'rm':
          // Delete specific plan
          if (!args || args.length === 0) {
            console.error(chalk.red('✗ Please provide a plan ID to delete'));
            console.log(chalk.yellow('Usage: ani-code plan delete <plan-id>'));
            await manager.close();
            return;
          }

          const planId = args[0];

          if (!options.yes) {
            const rl = createInterface({
              input: process.stdin,
              output: process.stdout
            });

            const answer = await new Promise((resolve) => {
              rl.question(chalk.yellow(`Delete plan "${planId}"? (yes/no): `), resolve);
            });
            rl.close();

            if (answer.toLowerCase() !== 'yes' && answer.toLowerCase() !== 'y') {
              console.log(chalk.gray('Operation cancelled'));
              await manager.close();
              return;
            }
          }

          const deleted = await manager.deletePlan(currentWorkspace.id, planId);

          if (deleted) {
            console.log(chalk.green(`✓ Plan deleted: ${planId}`));
          } else {
            console.log(chalk.red(`✗ Failed to delete plan: ${planId} (not found or error)`));
          }

          await manager.close();
          return;

        case 'show':
        case 'get':
          // Show specific plan details
          if (!args || args.length === 0) {
            console.error(chalk.red('✗ Please provide a plan ID'));
            console.log(chalk.yellow('Usage: ani-code plan show <plan-id>'));
            await manager.close();
            return;
          }

          const showPlanId = args[0];
          const plan = await manager.getPlan(currentWorkspace.id, showPlanId);

          if (!plan) {
            console.log(chalk.red(`✗ Plan not found: ${showPlanId}`));
            await manager.close();
            return;
          }

          console.log(chalk.bold(`\n📋 Plan Details: ${plan.title}\n`));
          console.log(`ID: ${plan.plan_id}`);
          console.log(`Status: ${plan.status}`);
          console.log(`Progress: Step ${plan.current_step || 0}/${plan.steps.length}`);
          console.log(`Created: ${new Date(plan.created_at).toLocaleString()}`);
          if (plan.completed_at) {
            console.log(`Completed: ${new Date(plan.completed_at).toLocaleString()}`);
          }

          // Show commit info if available
          if (plan.status === 'completed') {
            const metadata = typeof plan.metadata === 'string'
              ? JSON.parse(plan.metadata || '{}')
              : (plan.metadata || {});
            if (metadata.yolo_commit) {
              console.log(`${chalk.gray('Commit:')} ${chalk.yellow(metadata.yolo_commit.hash)} - ${metadata.yolo_commit.message}`);
            }
          }

          console.log();
          console.log(chalk.cyan('Steps:'));

          plan.steps.forEach((step, index) => {
            const marker = index < (plan.current_step || 0) ? chalk.green('✓') :
                          index === (plan.current_step || 0) ? chalk.yellow('→') :
                          chalk.gray('○');
            const stepText = getPlanStepDisplayText(step);
            console.log(`  ${marker} ${index + 1}. ${stepText}`);
          });

          await manager.close();
          return;

        case 'edit':
          // Edit plan in $EDITOR
          if (!args || args.length === 0) {
            console.error(chalk.red('✗ Please provide a plan ID'));
            console.log(chalk.yellow('Usage: ani-code plan edit <plan-id>'));
            await manager.close();
            return;
          }

          const editPlanId = args[0];
          const editPlan = await manager.getPlan(currentWorkspace.id, editPlanId);

          if (!editPlan) {
            console.log(chalk.red(`✗ Plan not found: ${editPlanId}`));
            await manager.close();
            return;
          }

          // Create temp file with plan content
          const tempFile = path.join(process.env.TMPDIR || '/tmp', `plan-${editPlanId}.md`);
          const editLines = editPlan.steps.map(step => getPlanStepDisplayText(step)).join('\n');
          const editContent = `# Plan: ${editPlan.title}\n# Status: ${editPlan.status}\n# Steps (one per line):\n\n${editLines}`;

          await fs.writeFile(tempFile, editContent);

          // Open in editor
          const editor = process.env.EDITOR || 'vim';
          const { spawn } = await import('child_process');

          await new Promise((resolve, reject) => {
            const editorProcess = spawn(editor, [tempFile], { stdio: 'inherit' });
            editorProcess.on('exit', (code) => {
              if (code === 0) resolve();
              else reject(new Error(`Editor exited with code ${code}`));
            });
          });

          // Read edited content
          const editedContent = await fs.readFile(tempFile, 'utf-8');
          await fs.unlink(tempFile);

          // Parse edited content
          const editedLines = editedContent.split('\n');
          const editedSteps = [];
          let newTitle = editPlan.title;

          for (const line of editedLines) {
            const trimmed = line.trim();
            if (trimmed.startsWith('# Plan:')) {
              newTitle = trimmed.replace('# Plan:', '').trim();
            } else if (!trimmed.startsWith('#') && trimmed) {
              editedSteps.push(trimmed);
            }
          }

          if (editedSteps.length === 0) {
            console.log(chalk.yellow('No steps found in edited content. Plan not updated.'));
            await manager.close();
            return;
          }

          const normalizedEditedSteps = normalizePlanSteps(editedSteps);

          // Update the plan
          const updateResult = await manager.updatePlan(currentWorkspace.id, editPlanId, {
            title: newTitle,
            steps: normalizedEditedSteps,
            description: stepsToPlanDescription(normalizedEditedSteps)
          });

          if (updateResult.success) {
            console.log(chalk.green(`✓ Plan updated: ${editPlanId}`));
            console.log(chalk.gray(`  Steps: ${normalizedEditedSteps.length}`));
          } else {
            console.log(chalk.red(`✗ Failed to update plan: ${updateResult.message}`));
          }

          await manager.close();
          return;

        case 'add-step':
        case 'addstep':
          // Add a step to existing plan
          if (!args || args.length < 2) {
            console.error(chalk.red('✗ Please provide a plan ID and step'));
            console.log(chalk.yellow('Usage: ani-code plan add-step <plan-id> <step>'));
            await manager.close();
            return;
          }

          const addPlanId = args[0];
          const newStep = args.slice(1).join(' ');
          const addPlan = await manager.getPlan(currentWorkspace.id, addPlanId);

          if (!addPlan) {
            console.log(chalk.red(`✗ Plan not found: ${addPlanId}`));
            await manager.close();
            return;
          }

          // Add the new step
          const normalizedExistingSteps = normalizePlanSteps(addPlan.steps);
          const normalizedNewStep = normalizePlanStep(newStep);
          const updatedSteps = [...normalizedExistingSteps, normalizedNewStep];
          const addResult = await manager.updatePlan(currentWorkspace.id, addPlanId, {
            steps: updatedSteps,
            description: stepsToPlanDescription(updatedSteps)
          });

          if (addResult.success) {
            console.log(chalk.green(`✓ Step added to plan: ${addPlanId}`));
            console.log(chalk.gray(`  New step: ${getPlanStepDisplayText(normalizedNewStep)}`));
            console.log(chalk.gray(`  Total steps: ${updatedSteps.length}`));
          } else {
            console.log(chalk.red(`✗ Failed to add step: ${addResult.message}`));
          }

          await manager.close();
          return;

        case 'remove-step':
        case 'removestep':
        case 'rm-step':
          // Remove a step from plan
          if (!args || args.length < 2) {
            console.error(chalk.red('✗ Please provide a plan ID and step number'));
            console.log(chalk.yellow('Usage: ani-code plan remove-step <plan-id> <step-num>'));
            await manager.close();
            return;
          }

          const rmPlanId = args[0];
          const stepNum = parseInt(args[1]);
          const rmPlan = await manager.getPlan(currentWorkspace.id, rmPlanId);

          if (!rmPlan) {
            console.log(chalk.red(`✗ Plan not found: ${rmPlanId}`));
            await manager.close();
            return;
          }

          if (isNaN(stepNum) || stepNum < 1 || stepNum > rmPlan.steps.length) {
            console.log(chalk.red(`✗ Invalid step number: ${args[1]} (valid range: 1-${rmPlan.steps.length})`));
            await manager.close();
            return;
          }

          // Remove the step (convert to 0-based index)
          const normalizedRmSteps = normalizePlanSteps(rmPlan.steps);
          const removedStep = normalizedRmSteps[stepNum - 1];
          const filteredSteps = normalizedRmSteps.filter((_, index) => index !== stepNum - 1);

          const rmResult = await manager.updatePlan(currentWorkspace.id, rmPlanId, {
            steps: filteredSteps,
            description: stepsToPlanDescription(filteredSteps)
          });

          if (rmResult.success) {
            console.log(chalk.green(`✓ Step removed from plan: ${rmPlanId}`));
            console.log(chalk.gray(`  Removed: ${getPlanStepDisplayText(removedStep)}`));
            console.log(chalk.gray(`  Remaining steps: ${filteredSteps.length}`));
          } else {
            console.log(chalk.red(`✗ Failed to remove step: ${rmResult.message}`));
          }

          await manager.close();
          return;

        case 'update':
          // Update plan from file
          if (!args || args.length < 1) {
            console.error(chalk.red('✗ Please provide a plan ID'));
            console.log(chalk.yellow('Usage: ani-code plan update <plan-id> -f <file>'));
            await manager.close();
            return;
          }

          if (!options.file) {
            console.error(chalk.red('✗ Please provide a file with -f option'));
            console.log(chalk.yellow('Usage: ani-code plan update <plan-id> -f <file>'));
            await manager.close();
            return;
          }

          const updatePlanId = args[0];
          const updatePlan = await manager.getPlan(currentWorkspace.id, updatePlanId);

          if (!updatePlan) {
            console.log(chalk.red(`✗ Plan not found: ${updatePlanId}`));
            await manager.close();
            return;
          }

          // Read new content from file
          const updateFilePath = path.resolve(options.file);
          let updateContent;
          try {
            updateContent = await fs.readFile(updateFilePath, 'utf-8');
          } catch (error) {
            console.error(chalk.red(`✗ Failed to read file: ${error.message}`));
            await manager.close();
            return;
          }

          // Parse the content into steps
          const updateLines = updateContent.split('\n').filter(line => line.trim());
          const updateSteps = [];

          for (const line of updateLines) {
            const trimmed = line.trim();
            // Remove list markers
            const cleanStep = trimmed.replace(/^[-*•]\s*|\d+[.)]\s*/, '').trim();
            if (cleanStep) {
              updateSteps.push(cleanStep);
            }
          }

          if (updateSteps.length === 0) {
            console.log(chalk.red('✗ No valid steps found in file'));
            await manager.close();
            return;
          }

          const normalizedUpdateSteps = normalizePlanSteps(updateSteps);
          const defaultUpdateTitle = normalizedUpdateSteps[0]?.description || normalizedUpdateSteps[0]?.prompt || normalizedUpdateSteps[0]?.raw || updatePlan.title || 'Updated Plan';

          // Update the plan
          const fileUpdateResult = await manager.updatePlan(currentWorkspace.id, updatePlanId, {
            title: options.title || defaultUpdateTitle.substring(0, 50),
            steps: normalizedUpdateSteps,
            description: stepsToPlanDescription(normalizedUpdateSteps) || updateContent
          });

          if (fileUpdateResult.success) {
            console.log(chalk.green(`✓ Plan updated from file: ${updatePlanId}`));
            console.log(chalk.gray(`  File: ${options.file}`));
            console.log(chalk.gray(`  Steps: ${normalizedUpdateSteps.length}`));
          } else {
            console.log(chalk.red(`✗ Failed to update plan: ${fileUpdateResult.message}`));
          }

          await manager.close();
          return;

        default:
          // Default to create action if no action specified or unrecognized
          // Treat the action as part of the plan description if provided
          let planContent = '';
          const descriptionParts = action ? [action, ...(args || [])] : args;

          // Read from file if specified
          if (options.file) {
            const filePath = path.resolve(options.file);
            try {
              planContent = await fs.readFile(filePath, 'utf-8');
            } catch (error) {
              console.error(chalk.red(`✗ Failed to read file: ${error.message}`));
              await manager.close();
              process.exit(1);
            }
          } else if (descriptionParts && descriptionParts.length > 0) {
            // Use provided description
            planContent = descriptionParts.join(' ');
          } else {
            // Show help if no action and no args provided
            if (!action) {
              console.log(chalk.bold('\n📋 Plan Management Commands\n'));
              console.log(chalk.cyan('Create & Manage:'));
              console.log(`  ${chalk.green('ani-code plan <steps>')}        Create a new plan`);
              console.log(`  ${chalk.green('ani-code plan list')}           List all plans`);
              console.log(`  ${chalk.green('ani-code plan show <id>')}      Show plan details`);
              console.log(`  ${chalk.green('ani-code plan delete <id>')}    Delete specific plan`);
              console.log(`  ${chalk.green('ani-code plan reset')}          Clear current workspace plans`);
              console.log();
              console.log(chalk.cyan('Edit Plans:'));
              console.log(`  ${chalk.green('ani-code plan edit <id>')}           Edit plan in $EDITOR`);
              console.log(`  ${chalk.green('ani-code plan add-step <id> <step>')} Add step to plan`);
              console.log(`  ${chalk.green('ani-code plan remove-step <id> <num>')} Remove step by number`);
              console.log(`  ${chalk.green('ani-code plan update <id> -f <file>')} Update plan from file`);
              console.log();
              console.log(chalk.gray('Options:'));
              console.log(`  ${chalk.cyan('-f <file>')}  Read plan from markdown file`);
              console.log(`  ${chalk.cyan('-i <id>')}    Custom plan ID`);
              console.log(`  ${chalk.cyan('-t <title>')} Plan title`);
              console.log(`  ${chalk.cyan('-s <status>')} Filter by status (pending/in_progress/completed)`);
              console.log(`  ${chalk.cyan('-y')}         Skip confirmation prompts`);
              console.log();
              console.log(chalk.gray('Examples:'));
              console.log(`  ani-code plan "Fix bug" "Add tests" "Deploy"`);
              console.log(`  ani-code plan -f roadmap.md`);
              console.log(`  ani-code plan edit plan-123`);
              console.log(`  ani-code plan add-step plan-123 "Run integration tests"`);
              console.log(`  ani-code plan remove-step plan-123 2`);
              console.log(`  ani-code plan update plan-123 -f updated-plan.md`);
              await manager.close();
              return;
            }

            // Interactive mode - prompt for plan
            const rl = createInterface({
              input: process.stdin,
              output: process.stdout
            });

            console.log(chalk.cyan('Enter your plan (press Ctrl+D when done):'));
            console.log(chalk.gray('Format: Each line is a step. Start with "- " or number for lists.'));
            console.log();

            await new Promise((resolve) => {
              rl.on('line', (line) => {
                planContent += line + '\n';
              });
              rl.on('close', resolve);
            });

            if (!planContent.trim()) {
              console.error(chalk.red('✗ No plan provided'));
              await manager.close();
              process.exit(1);
            }
          }

          // Parse the plan content into steps
          const lines = planContent.split('\n').filter(line => line.trim());
          const rawSteps = [];
          let currentStep = null;

          for (const line of lines) {
            const trimmed = line.trim();
            // Check if it's a step (starts with -, *, number, or is a non-empty line)
            if (trimmed.match(/^[-*•]|\d+\.|^\d+\)/) || (trimmed && !currentStep)) {
              // Remove list markers
              const cleanStep = trimmed.replace(/^[-*•]\s*|\d+[.)]\s*/, '').trim();
              if (cleanStep) {
                rawSteps.push(cleanStep);
                currentStep = cleanStep;
              }
            } else if (trimmed && currentStep) {
              // It's a continuation of the previous step
              const merged = `${rawSteps[rawSteps.length - 1]} ${trimmed}`.trim();
              rawSteps[rawSteps.length - 1] = merged;
            }
          }

          if (rawSteps.length === 0) {
            console.error(chalk.red('✗ No valid steps found in plan'));
            await manager.close();
            process.exit(1);
          }

          const normalizedSteps = normalizePlanSteps(rawSteps);
          const defaultTitle = normalizedSteps[0]?.description || normalizedSteps[0]?.prompt || normalizedSteps[0]?.raw || 'Untitled Plan';

          // Create the plan
          const planData = {
            planId: options.id || undefined,
            title: options.title || defaultTitle.substring(0, 50),
            description: stepsToPlanDescription(normalizedSteps) || planContent,
            steps: normalizedSteps,
            createdBy: 'cli',
            metadata: {
              source: 'cli',
              timestamp: new Date().toISOString()
            }
          };

          const result = await manager.createPlan(currentWorkspace.id, planData);

          console.log(chalk.green(`✓ Plan created: ${result.planId}`));
          console.log(chalk.gray(`  Workspace: ${currentWorkspace.name}`));
          console.log(chalk.gray(`  Steps: ${normalizedSteps.length}`));
          console.log();
          console.log(chalk.cyan('Steps:'));
          normalizedSteps.forEach((step, index) => {
            console.log(`  ${index + 1}. ${getPlanStepDisplayText(step)}`);
          });
          console.log();
          console.log(chalk.yellow(`💡 Execute with: ani-code next`));
          console.log(chalk.yellow(`💡 Or specific plan: ani-code next ${result.planId}`));
          console.log(chalk.yellow(`💡 View plans: ani-code plan list`));

          await manager.close();
          break;  // End of default case
      }  // End of switch
    } catch (error) {
      console.error(chalk.red(`✗ Plan operation failed: ${error.message}`));
      process.exit(1);
    }
  });

program
  .command('next')
  .description('Execute the next plan or specific plan')
  .argument('[planId]', 'Specific plan ID to execute')
  .option('-s, --step <num>', 'Start from specific step number', parseInt)
  .option('-a, --auto', 'Auto-execute all steps without confirmation')
  .action(async (planId, options) => {
    try {
      // Check if daemon is running
      const daemonClient = new DaemonClient();
      if (!daemonClient.isDaemonRunning()) {
        console.error(chalk.red('✗ Daemon is not running'));
        console.log(chalk.yellow('💡 Start the daemon with: ani-code daemon --start'));
        process.exit(1);
      }

      // Import required modules
      const { WorkspaceManager } = await import('./workspace-manager.js');
      const path = await import('path');

      const manager = new WorkspaceManager();
      await manager.initialize();

      // Get current workspace
      const currentWorkspace = await manager.getCurrentWorkspace();
      if (!currentWorkspace) {
        console.error(chalk.red('✗ Not in a workspace directory'));
        await manager.close();
        process.exit(1);
      }

      // Get the plan
      let plan;
      if (planId) {
        plan = await manager.getPlan(currentWorkspace.id, planId);
        if (!plan) {
          console.error(chalk.red(`✗ Plan not found: ${planId}`));
          await manager.close();
          process.exit(1);
        }
      } else {
        plan = await manager.getNextPlan(currentWorkspace.id);
        if (!plan) {
          console.error(chalk.red('✗ No pending plans found'));
          console.log(chalk.yellow('💡 Create a plan with: ani-code plan'));
          await manager.close();
          process.exit(1);
        }
      }

      console.log(chalk.bold(`\n📋 Executing Plan: ${plan.title}`));
      console.log(chalk.gray(`  ID: ${plan.plan_id}`));
      console.log(chalk.gray(`  Created: ${new Date(plan.created_at).toLocaleString()}`));
      console.log(chalk.gray(`  Status: ${plan.status}`));
      console.log();

      // Determine starting step
      const startStep = options.step ? options.step - 1 : plan.current_step || 0;
      const steps = plan.steps;

      if (startStep >= steps.length) {
        console.error(chalk.red(`✗ Invalid step number. Plan has ${steps.length} steps.`));
        await manager.close();
        process.exit(1);
      }

      // Show all steps with current position
      console.log(chalk.cyan('Steps:'));
      steps.forEach((step, index) => {
        const marker = index === startStep ? '→' : ' ';
        const status = index < startStep ? chalk.green('✓') :
                      index === startStep ? chalk.yellow('•') :
                      chalk.gray('○');
        const stepText = getPlanStepDisplayText(step);
        console.log(`  ${marker} ${status} ${index + 1}. ${stepText}`);
      });
      console.log();

      // Update plan status to in_progress
      await manager.updatePlanStatus(currentWorkspace.id, plan.plan_id, 'in_progress', startStep);

      // Execute steps
      const client = await getIPCClient();

      try {
        for (let i = startStep; i < steps.length; i++) {
          const stepInfo = normalizePlanStep(steps[i]);
          const displayText = getPlanStepDisplayText(stepInfo);

          console.log(chalk.yellow(`\n▶ Step ${i + 1}/${steps.length}: ${displayText}`));

          // Ask for confirmation unless auto mode
          if (!options.auto && i > startStep) {
            const rl = createInterface({
              input: process.stdin,
              output: process.stdout
            });

            const answer = await new Promise((resolve) => {
              rl.question(chalk.cyan('Continue to next step? (yes/no/skip): '), resolve);
            });
            rl.close();

            if (answer.toLowerCase() === 'no' || answer.toLowerCase() === 'n') {
              console.log(chalk.yellow('⏸ Plan execution paused'));
              await manager.updatePlanStatus(currentWorkspace.id, plan.plan_id, 'paused', i);
              break;
            } else if (answer.toLowerCase() === 'skip' || answer.toLowerCase() === 's') {
              console.log(chalk.gray('⏭ Skipping step'));
              continue;
            }
          }

          // Create task for this step
          const taskName = `plan-${plan.plan_id}-step-${i + 1}`;
          const taskOptions = {
            cwd: currentWorkspace.path,
            source: 'plan_execution',
            planId: plan.plan_id,
            stepIndex: i
          };

          if (stepInfo.providerId) {
            taskOptions.providerId = stepInfo.providerId;
          }
          if (stepInfo.model) {
            taskOptions.model = stepInfo.model;
          }

          // Add the task (use stepText for the command)
          const task = await client.addTask(taskName, stepInfo.command, taskOptions);
          console.log(chalk.green(`✓ Task created: ${task.id}`));

          // Update current step
          await manager.updatePlanStatus(currentWorkspace.id, plan.plan_id, 'in_progress', i + 1);

          // Wait a moment between steps if auto mode
          if (options.auto && i < steps.length - 1) {
            await new Promise(resolve => setTimeout(resolve, 1000));
          }
        }

        // Mark plan as completed if all steps done
        if (startStep === 0 || plan.current_step >= steps.length - 1) {
          await manager.updatePlanStatus(currentWorkspace.id, plan.plan_id, 'completed');
          console.log(chalk.green('\n✓ Plan completed successfully!'));
        }

      } finally {
        client.disconnect();
        await manager.close();
      }

    } catch (error) {
      console.error(chalk.red(`✗ Failed to execute plan: ${error.message}`));
      process.exit(1);
    }
  });

program
  .command('yolo')
  .description('Execute ALL pending plans sequentially with auto-commit (oldest first)')
  .option('-p, --pause <ms>', 'Pause between plans in milliseconds', parseInt, 5000)
  .option('-d, --dry-run', 'Show what would be executed without running')
  .action(async (options) => {
    try {
      // Check if daemon is running
      const daemonClient = new DaemonClient();
      if (!daemonClient.isDaemonRunning()) {
        console.error(chalk.red('✗ Daemon is not running'));
        console.log(chalk.yellow('💡 Start the daemon with: ani-code daemon --start'));
        process.exit(1);
      }

      // Import required modules
      const { WorkspaceManager } = await import('./workspace-manager.js');
      const { execSync } = await import('child_process');

      const manager = new WorkspaceManager();
      await manager.initialize();

      // Get current workspace
      const currentWorkspace = await manager.getCurrentWorkspace();
      if (!currentWorkspace) {
        console.error(chalk.red('✗ Not in a workspace directory'));
        await manager.close();
        process.exit(1);
      }

      // Get all pending plans sorted by creation time (oldest first)
      const plans = await manager.listPlans(currentWorkspace.id, 'pending');

      if (plans.length === 0) {
        console.log(chalk.yellow('No pending plans found'));
        await manager.close();
        process.exit(0);
      }

      // Calculate total pending steps across all plans
      const totalPendingSteps = plans.reduce((sum, plan) => {
        const steps = typeof plan.steps === 'string' ? JSON.parse(plan.steps) : plan.steps;
        return sum + steps.length;
      }, 0);

      // Prevent YOLO mode if total pending steps exceed limit
      const MAX_YOLO_STEPS = 33;
      if (totalPendingSteps > MAX_YOLO_STEPS) {
        console.error(chalk.red(`\n✗ Cannot start YOLO mode: Total pending steps (${totalPendingSteps}) exceeds limit of ${MAX_YOLO_STEPS}`));
        console.log(chalk.yellow('\n💡 To reduce pending steps:'));
        console.log(chalk.gray('  • Complete or cancel some plans first'));
        console.log(chalk.gray('  • Break large plans into smaller chunks'));
        console.log(chalk.gray('  • Execute plans individually with: ani-code execute <plan-id>'));
        await manager.close();
        process.exit(1);
      }

      console.log(chalk.bold.cyan(`\n🚀 YOLO MODE: Found ${plans.length} pending plan(s) with ${totalPendingSteps} total steps\n`));

      // Plans are already sorted by created_at ASC (oldest first) from listPlans

      // Show execution order
      console.log(chalk.bold('Execution Order (oldest first):'));
      plans.forEach((plan, index) => {
        const age = Date.now() - new Date(plan.created_at).getTime();
        const ageMinutes = Math.floor(age / 60000);
        const ageStr = ageMinutes < 60 ? `${ageMinutes}m ago` :
                       `${Math.floor(ageMinutes / 60)}h ${ageMinutes % 60}m ago`;
        console.log(`  ${index + 1}. ${chalk.cyan(plan.plan_id)} - ${plan.title} (created ${ageStr})`);
      });
      console.log();

      // Activate yolo mode protection and create status message
      let yoloStatusMessageId = null;
      const workspaceTelegramChatId = currentWorkspace.settings?.telegramChatId;

      // Track execution data for consolidated status updates
      const executionData = {
        startTime: Date.now(),
        commits: [],
        usage: { cost: 0, tokens: 0 },
        currentStepIndex: 0,
        totalSteps: 0,
        messageVersion: 0,  // Persistent message version counter
        lastResendTime: 0,  // Track last resend time to prevent race conditions
        resendInterval: 10000,  // 10 seconds resend interval
        resend: false  // Flag to control message resending vs editing
      };

      if (workspaceTelegramChatId) {
        try {
          // Send initial yolo status message to Telegram
          const { TelegramNotifier } = await import('./telegram-notifier.js');
          const telegramNotifier = new TelegramNotifier();

          if (telegramNotifier.isEnabled()) {
            const statusMessage = await telegramNotifier.formatYoloStatusMessage(
              currentWorkspace.name,
              plans.length,
              0,
              null,
              'starting',
              executionData
            );

            const messageResult = await telegramNotifier.sendYoloStatus(
              workspaceTelegramChatId,
              statusMessage,
              { showButtons: true, workspace: currentWorkspace }
            );

            if (messageResult && messageResult.message_id) {
              yoloStatusMessageId = messageResult.message_id;
              executionData.lastResendTime = Date.now();
              console.log(chalk.gray(`Telegram status message created: ${yoloStatusMessageId} (v${executionData.messageVersion})`));
            }
          }
        } catch (error) {
          console.log(chalk.yellow(`Warning: Could not create Telegram status message: ${error.message}`));
        }
      }

      // Activate yolo mode protection for workspace
      await manager.setYoloModeActive(
        currentWorkspace.id,
        true,
        yoloStatusMessageId,
        plans.length
      );

      console.log(chalk.yellow('⚠️  Workspace protection enabled - manual tasks are blocked during YOLO mode'));

      if (options.dryRun) {
        console.log(chalk.yellow('Dry run mode - no plans will be executed'));
        await manager.close();
        process.exit(0);
      }

      const client = await getIPCClient();

      try {
        // Execute each plan sequentially
        for (let planIndex = 0; planIndex < plans.length; planIndex++) {
          // Check if YOLO mode has been stopped
          const currentStatus = await manager.getWorkspace(currentWorkspace.id);
          if (!currentStatus || !currentStatus.yolo_mode_active) {
            console.log(chalk.yellow('\n⚠️ YOLO mode has been stopped by user'));
            console.log(chalk.gray('Cleaning up and exiting...'));

            // Cancel any pending tasks
            try {
              const status = await client.getStatus();
              for (const task of status.pending) {
                if (task.metadata && task.metadata.source === 'yolo') {
                  await client.cancelTask(task.id);
                }
              }
            } catch (error) {
              // Silent fail
            }

            // Clear YOLO protection to allow manual tasks
            await manager.clearYoloProtection(currentWorkspace.id);
            console.log(chalk.green('✓ Protection mode disabled - manual tasks allowed'));

            break;
          }

          const plan = plans[planIndex];

          console.log(chalk.bold.yellow(`\n════════════════════════════════════════════════`));
          console.log(chalk.bold.yellow(`▶ Executing Plan ${planIndex + 1}/${plans.length}: ${plan.title}`));
          console.log(chalk.gray(`  ID: ${plan.plan_id}`));
          console.log(chalk.gray(`  Created: ${new Date(plan.created_at).toLocaleString()}`));
          console.log(chalk.bold.yellow(`════════════════════════════════════════════════\n`));

          // Update yolo progress in workspace
          await manager.updateYoloProgress(currentWorkspace.id, plan.plan_id, planIndex);

          // Update Telegram status message if available
          if (yoloStatusMessageId && workspaceTelegramChatId) {
            try {
              const { TelegramNotifier } = await import('./telegram-notifier.js');
              const telegramNotifier = new TelegramNotifier();

              if (telegramNotifier.isEnabled()) {
                // Always just edit the existing message during plan execution
                // Add step tracking to current plan
                const enhancedPlan = {
                  ...plan,
                  currentStep: 0,
                  totalSteps: plan.steps ? plan.steps.length : 0
                };

                const statusMessage = await telegramNotifier.formatYoloStatusMessage(
                  currentWorkspace.name,
                  plans.length,
                  planIndex,
                  enhancedPlan,
                  'executing',
                  executionData
                );

                // Just update existing message (no resending during execution)
                await telegramNotifier.updateYoloStatus(
                  workspaceTelegramChatId,
                  yoloStatusMessageId,
                  statusMessage
                );

                // Persist the message version to the database
                await manager.updateYoloMessageVersion(currentWorkspace.id, executionData.messageVersion);
              }
            } catch (error) {
              // Log but don't fail on Telegram update errors
              console.log(chalk.gray(`Failed to update Telegram status: ${error.message}`));
            }
          }

          // Update plan status to in_progress
          await manager.updatePlanStatus(currentWorkspace.id, plan.plan_id, 'in_progress', 0);

          const steps = plan.steps;

          // Execute all steps
          for (let i = 0; i < steps.length; i++) {
            // Check if YOLO mode has been stopped before each step
            const stepStatus = await manager.getWorkspace(currentWorkspace.id);
            if (!stepStatus || !stepStatus.yolo_mode_active) {
              console.log(chalk.yellow('\n⚠️ YOLO mode has been stopped by user during plan execution'));
              console.log(chalk.gray(`Stopped at step ${i + 1} of plan ${planIndex + 1}`));

              // Mark plan as interrupted in metadata
              const metadata = typeof plan.metadata === 'string'
                ? JSON.parse(plan.metadata || '{}')
                : (plan.metadata || {});
              metadata.interrupted_at_step = i + 1;
              metadata.interrupted_at = new Date().toISOString();
              metadata.yolo_stopped = true;
              await manager.updatePlanMetadata(currentWorkspace.id, plan.plan_id, metadata);

              // Update plan status to show it was interrupted
              await manager.updatePlanStatus(currentWorkspace.id, plan.plan_id, 'in_progress', i);

              // Exit the steps loop
              break;
            }

            const stepInfo = normalizePlanStep(steps[i]);
            const stepText = getPlanStepDisplayText(stepInfo);

            console.log(chalk.yellow(`\n▶ Step ${i + 1}/${steps.length}: ${stepText}`));

            // Update current step
            await manager.updatePlanStatus(currentWorkspace.id, plan.plan_id, 'in_progress', i);

            // Update Telegram status for each step
            if (yoloStatusMessageId && workspaceTelegramChatId) {
              try {
                const { TelegramNotifier } = await import('./telegram-notifier.js');
                const telegramNotifier = new TelegramNotifier();

                if (telegramNotifier.isEnabled()) {
                  // Set resend flag when new task starts
                  executionData.resend = true;

                  // Always just edit the existing message during step execution
                  const enhancedPlan = {
                    ...plan,
                    currentStep: i + 1,
                    totalSteps: steps.length,
                    currentStepText: stepText
                  };

                  const statusMessage = await telegramNotifier.formatYoloStatusMessage(
                    currentWorkspace.name,
                    plans.length,
                    planIndex,
                    enhancedPlan,
                    'executing',
                    executionData
                  );

                  // Always try to update existing message first, only send new if update fails
                  try {
                    await telegramNotifier.updateYoloStatus(
                      workspaceTelegramChatId,
                      yoloStatusMessageId,
                      statusMessage
                    );
                    executionData.resend = false;  // Reset flag after updating
                    // Persist the message version to the database
                    await manager.updateYoloMessageVersion(currentWorkspace.id, executionData.messageVersion);
                  } catch (updateError) {
                    // If update fails (message was deleted), send a new one
                    console.log(chalk.gray(`Failed to update message, sending new one: ${updateError.message}`));
                    const newMessage = await telegramNotifier.sendYoloStatus(
                      workspaceTelegramChatId,
                      statusMessage,
                      { showButtons: true, workspace: currentWorkspace, skipAutoPin: false }
                    );
                    if (newMessage && newMessage.message_id) {
                      yoloStatusMessageId = newMessage.message_id;
                      // Persist the message version after resending
                      await manager.updateYoloMessageVersion(currentWorkspace.id, executionData.messageVersion);
                      // IMPORTANT: Also persist the new message ID to avoid race conditions
                      await manager.updateYoloStatusMessageId(currentWorkspace.id, yoloStatusMessageId);
                    }
                    executionData.resend = false;  // Reset flag after resending
                  }
                }
              } catch (error) {
                // Silent fail for Telegram updates
              }
            }

            // Execute the step
            const taskName = `${plan.plan_id}-step-${i + 1}`;
            const taskOptions = {
              cwd: process.cwd(),
              skipHistory: false,
              source: 'yolo'
            };

            if (stepInfo.providerId) {
              taskOptions.providerId = stepInfo.providerId;
            }
            if (stepInfo.model) {
              taskOptions.model = stepInfo.model;
            }

            const task = await client.addTask(taskName, stepInfo.command, taskOptions);

            // Wait for task completion
            console.log(chalk.gray(`  Task ID: ${task.id}`));
            console.log(chalk.blue('  Waiting for task to complete...'));

            // Poll for task completion
            let taskComplete = false;
            while (!taskComplete) {
              await new Promise(resolve => setTimeout(resolve, 2000));
              const status = await client.getStatus();
              const runningTask = status.running.find(t => t.id === task.id);
              const pendingTask = status.pending.find(t => t.id === task.id);

              if (!runningTask && !pendingTask) {
                taskComplete = true;
              }

              // Check if we should resend status message during long-running tasks
              // Removed periodic resending during step execution - only edit the existing message
            }

            console.log(chalk.green(`  ✓ Step ${i + 1} completed`));

            // Mark resend flag after task completes
            executionData.resend = true;

            // Brief pause between steps
            await new Promise(resolve => setTimeout(resolve, 500));
          }

          // Check if YOLO was stopped during step execution
          const finalStatus = await manager.getWorkspace(currentWorkspace.id);
          if (!finalStatus || !finalStatus.yolo_mode_active) {
            console.log(chalk.yellow('\n⚠️ YOLO mode was stopped - skipping remaining plans'));

            // Clear YOLO protection to allow manual tasks
            await manager.clearYoloProtection(currentWorkspace.id);
            console.log(chalk.green('✓ Protection mode disabled - manual tasks allowed'));

            break; // Exit the main plans loop
          }

          // Mark plan as completed only if all steps were executed
          const metadata = typeof plan.metadata === 'string'
            ? JSON.parse(plan.metadata || '{}')
            : (plan.metadata || {});

          if (!metadata.yolo_stopped) {
            await manager.updatePlanStatus(currentWorkspace.id, plan.plan_id, 'completed');
            console.log(chalk.green(`\n✅ Plan completed: ${plan.title}`));

            // Auto-commit after each plan
            console.log(chalk.blue('\n📝 Creating git commit...'));
            let commitHash = null;
            let commitMessage = null;
            try {
              // Check for changes
              const gitStatus = execSync('git status --porcelain', { encoding: 'utf-8', cwd: process.cwd() });

              if (gitStatus.trim()) {
                // Add all changes
                execSync('git add .', { cwd: process.cwd() });

                // Generate commit message
                commitMessage = `feat: completed plan ${plan.plan_id} - ${plan.title}\\n\\nPlan executed in YOLO mode with ${steps.length} steps`;

                // Commit
                execSync(`git commit -m "${commitMessage}"`, { cwd: process.cwd() });
                console.log(chalk.green('✓ Changes committed'));

                // Get the commit hash and message of the latest commit
                commitHash = execSync('git rev-parse HEAD', { encoding: 'utf-8', cwd: process.cwd() }).trim();
                const fullCommitMessage = execSync('git log -1 --pretty=format:"%s"', { encoding: 'utf-8', cwd: process.cwd() }).trim();

                // Store commit info in plan's metadata
                const commitMetadata = typeof plan.metadata === 'string'
                  ? JSON.parse(plan.metadata || '{}')
                  : (plan.metadata || {});
                commitMetadata.yolo_commit = {
                  hash: commitHash.substring(0, 7),
                  full_hash: commitHash,
                  message: fullCommitMessage,
                  timestamp: new Date().toISOString()
                };

                // Update plan metadata
                await manager.updatePlanMetadata(currentWorkspace.id, plan.plan_id, commitMetadata);

                // Add commit to execution data
                executionData.commits.push({
                  hash: commitHash.substring(0, 7),
                  message: fullCommitMessage,
                  planId: plan.plan_id
                });

                // Update Telegram status with commit info
                if (yoloStatusMessageId && workspaceTelegramChatId) {
                  try {
                    const { TelegramNotifier } = await import('./telegram-notifier.js');
                    const telegramNotifier = new TelegramNotifier();

                    if (telegramNotifier.isEnabled()) {
                      // Mark resend flag after commit completes
                      executionData.resend = true;

                      // Always resend after commit to keep message at bottom
                      const statusMessage = await telegramNotifier.formatYoloStatusMessage(
                        currentWorkspace.name,
                        plans.length,
                        planIndex + 1,  // This is correct - we just completed plan at planIndex
                        null,
                        planIndex < plans.length - 1 ? 'committing' : 'completed',
                        executionData
                      );

                      // Update status message with commit information
                      try {
                        // First try to update the existing message
                        await telegramNotifier.updateYoloStatus(
                          workspaceTelegramChatId,
                          yoloStatusMessageId,
                          statusMessage
                        );
                        executionData.lastResendTime = Date.now();
                        executionData.resend = false;  // Reset flag after updating
                        console.log(chalk.gray(`Updated status after commit: ${yoloStatusMessageId} (v${executionData.messageVersion})`));
                      } catch (updateError) {
                        // If update fails, send a new message
                        console.log(chalk.gray(`Failed to update message after commit, sending new one: ${updateError.message}`));
                        const messageResult = await telegramNotifier.sendYoloStatus(
                          workspaceTelegramChatId,
                          statusMessage,
                          { showButtons: true, workspace: currentWorkspace, skipAutoPin: false }
                        );

                        if (messageResult && messageResult.message_id) {
                          yoloStatusMessageId = messageResult.message_id;
                          executionData.lastResendTime = Date.now();
                          executionData.resend = false;  // Reset flag after resending
                          console.log(chalk.gray(`Sent new status after commit: ${yoloStatusMessageId} (v${executionData.messageVersion})`));
                          // IMPORTANT: Persist the new message ID to avoid race conditions
                          await manager.updateYoloStatusMessageId(currentWorkspace.id, yoloStatusMessageId);
                        }
                      }
                    }
                  } catch (error) {
                    // Silent fail
                    console.log(chalk.gray(`Failed to update status after commit: ${error.message}`));
                  }
                }

              } else {
                console.log(chalk.gray('No changes to commit'));
              }
            } catch (gitError) {
              console.log(chalk.yellow(`⚠️  Git commit failed: ${gitError.message}`));
            }
          }

          // Pause between plans (except for the last one)
          if (planIndex < plans.length - 1 && options.pause > 0) {
            const pauseSeconds = Math.round(options.pause / 1000);
            console.log(chalk.gray(`\n⏸️  Pausing for ${pauseSeconds} seconds before next plan...`));
            await new Promise(resolve => setTimeout(resolve, options.pause));
          }
        }

        // Get updated plans to show commit information
        const completedPlans = [];
        for (const plan of plans) {
          const updatedPlan = await manager.getPlan(currentWorkspace.id, plan.plan_id);
          if (updatedPlan) {
            completedPlans.push(updatedPlan);
          }
        }

        console.log(chalk.bold.green(`\n\n🎉 YOLO COMPLETE! All ${plans.length} plan(s) executed successfully!`));

        // Show summary of commits
        console.log(chalk.bold.cyan('\n📋 Execution Summary:'));
        console.log(chalk.gray('─'.repeat(60)));

        completedPlans.forEach((plan, index) => {
          console.log(`\n${index + 1}. ${chalk.bold(plan.title)}`);
          console.log(`   ${chalk.gray('Plan ID:')} ${plan.plan_id}`);
          const metadata = plan.metadata || {};
          if (metadata.yolo_commit) {
            console.log(`   ${chalk.gray('Commit:')} ${chalk.yellow(metadata.yolo_commit.hash)} - ${metadata.yolo_commit.message}`);
            if (metadata.yolo_commit.timestamp) {
              console.log(`   ${chalk.gray('Committed:')} ${new Date(metadata.yolo_commit.timestamp).toLocaleString()}`);
            }
          } else {
            console.log(`   ${chalk.gray('Commit:')} ${chalk.gray('No changes committed')}`);
          }
        });

        console.log(chalk.gray('\n─'.repeat(60)));

        // Clear yolo mode and update final status
        await manager.clearYoloMode(currentWorkspace.id);

        if (yoloStatusMessageId && workspaceTelegramChatId) {
          try {
            const { TelegramNotifier } = await import('./telegram-notifier.js');
            const telegramNotifier = new TelegramNotifier();

            if (telegramNotifier.isEnabled()) {
              // Add final commits to execution data from completed plans
              executionData.commits = [];
              for (const plan of completedPlans) {
                const metadata = plan.metadata || {};
                if (metadata.yolo_commit) {
                  executionData.commits.push({
                    hash: metadata.yolo_commit.hash,
                    message: metadata.yolo_commit.message,
                    planId: plan.plan_id
                  });
                }
              }

              // Mark resend flag for final status
              executionData.resend = true;

              const statusMessage = await telegramNotifier.formatYoloStatusMessage(
                currentWorkspace.name,
                plans.length,
                plans.length,
                null,
                'completed',
                executionData
              );

              // For final completion, we need to delete and resend with different buttons
              // This is the only case where we intentionally create a new message
              try {
                // Unpin first if autopin is enabled
                if ((currentWorkspace.settings?.showprogress || 'autopin') === 'autopin') {
                  try {
                    await telegramNotifier.api.unpinChatMessage(workspaceTelegramChatId, yoloStatusMessageId);
                  } catch (unpinError) {
                    // Ignore unpin errors
                  }
                }
                await telegramNotifier.deleteMessage(workspaceTelegramChatId, yoloStatusMessageId);
              } catch (e) {
                // Ignore delete errors
              }

              const messageResult = await telegramNotifier.sendYoloStatus(
                workspaceTelegramChatId,
                statusMessage,
                { showCompletedButtons: true, workspace: currentWorkspace, skipAutoPin: false }
              );

              if (messageResult && messageResult.message_id) {
                executionData.resend = false;  // Reset flag after resending
                console.log(chalk.gray(`Final completion message sent with new buttons: ${messageResult.message_id} (v${executionData.messageVersion})`));
              }
            }
          } catch (error) {
            console.log(chalk.gray(`Failed to update final Telegram status: ${error.message}`));
          }
        }

        console.log(chalk.green('✓ Workspace protection disabled - manual tasks allowed again'));

      } finally {
        client.disconnect();
        await manager.close();
      }

    } catch (error) {
      console.error(chalk.red(`✗ YOLO execution failed: ${error.message}`));
      process.exit(1);
    }
  });

program
  .command('status')
  .description('Show current task status')
  .option('-v, --verbose', 'Show detailed process information')
  .action(async (options) => {
    // Check if daemon is running
    const daemonClient = new DaemonClient();
    if (!daemonClient.isDaemonRunning()) {
      console.error(chalk.red('✗ Daemon is not running'));
      console.log(chalk.yellow('💡 Start the daemon with: ani-code daemon --start'));
      console.log(chalk.yellow('💡 Or install service with: ani-code install-service --user'));
      process.exit(1);
    }

    // Connect to daemon via IPC
    const client = await getIPCClient();
    let status;
    try {
      // Get enhanced status with process info if verbose flag is set
      if (options.verbose) {
        status = await client.getStatusWithProcessInfo();
      } else {
        status = await client.getStatus();
      }
    } catch (error) {
      throw error;
    } finally {
      client.disconnect();
    }

    console.log(chalk.bold('\n📋 Task Status'));
    console.log(chalk.gray('─'.repeat(50)));
    
    if (status.running.length > 0) {
      console.log(chalk.yellow('\n🏃 Running Tasks:'));
      
      // Group by project for better visibility
      const tasksByProject = new Map();
      status.running.forEach(task => {
        const projectPath = task.cwd;
        if (!tasksByProject.has(projectPath)) {
          tasksByProject.set(projectPath, []);
        }
        tasksByProject.get(projectPath).push(task);
      });
      
      for (const [projectPath, tasks] of tasksByProject) {
        // Count Claude tasks (not shell commands) for this workspace
        const claudeTasks = tasks.filter(t => !t.command.startsWith('shell:'));
        const claudeCount = claudeTasks.length;
        
        console.log(chalk.cyan(`\n  📁 ${projectPath}:`));
        console.log(chalk.gray(`     Claude tasks: ${claudeCount}/${config.tasks.maxConcurrent}`));
        
        tasks.forEach(task => {
          const startedAt = new Date(task.startedAt);
          const elapsed = Date.now() - startedAt.getTime();
          const elapsedSeconds = Math.round(elapsed / 1000);
          
          // Show task name and elapsed time
          const taskType = task.command.startsWith('shell:') ? '[SHELL]' : '[CLAUDE]';
          console.log(`    • ${chalk.bold(task.name)} ${chalk.gray(taskType)} (${elapsedSeconds}s)`);
          
          // Show task ID
          console.log(`      ${chalk.gray('ID:')} ${task.id}`);
          
          // Show PID if available
          if (task.pid) {
            console.log(`      ${chalk.gray('PID:')} ${task.pid}`);
          }
          
          // Show process info if available (verbose mode)
          if (task.processInfo && options.verbose) {
            const pi = task.processInfo;
            console.log(`      ${chalk.gray('CPU:')} ${pi.cpu}% | ${chalk.gray('Memory:')} ${pi.memory}% | ${chalk.gray('User:')} ${pi.user}`);
          }
          
          // Show truncated command/prompt
          const commandPreview = task.command.length > 80 
            ? task.command.substring(0, 77) + '...' 
            : task.command;
          console.log(`      ${chalk.gray('Prompt:')} ${commandPreview}`);
        });
      }
    }
    
    if (status.pending.length > 0) {
      console.log(chalk.blue('\n⏳ Pending Tasks:'));
      
      // Group pending tasks by project
      const pendingByProject = new Map();
      status.pending.forEach(task => {
        const projectPath = task.cwd;
        if (!pendingByProject.has(projectPath)) {
          pendingByProject.set(projectPath, []);
        }
        pendingByProject.get(projectPath).push(task);
      });
      
      let taskIndex = 1;
      for (const [projectPath, tasks] of pendingByProject) {
        // Count Claude tasks (not shell commands) for this workspace
        const claudeTasks = tasks.filter(t => !t.command.startsWith('shell:'));
        const claudeCount = claudeTasks.length;
        
        console.log(chalk.cyan(`\n  📁 ${projectPath}:`));
        if (claudeCount > 0) {
          console.log(chalk.gray(`     Claude tasks pending: ${claudeCount}`));
        }
        
        tasks.forEach(task => {
          const taskType = task.command.startsWith('shell:') ? '[SHELL]' : '[CLAUDE]';
          console.log(`    ${taskIndex}. ${task.name} ${chalk.gray(taskType)} - ${task.id}`);
          taskIndex++;
        });
      }
    }
    
    if (status.running.length === 0 && status.pending.length === 0) {
      console.log(chalk.gray('\n  No tasks in queue'));
    }

    console.log(chalk.gray(`\nMax concurrent Claude tasks per workspace: ${config.tasks.maxConcurrent}`));

    // Add plan summary for current workspace
    try {
      const { WorkspaceManager } = await import('./workspace-manager.js');
      const manager = new WorkspaceManager();
      await manager.initialize();

      const currentWorkspace = await manager.getCurrentWorkspace();
      if (currentWorkspace) {
        const planSummary = await manager.getPlanSummary(currentWorkspace.id);

        if (planSummary && Object.keys(planSummary.counts).length > 0) {
          console.log(chalk.bold('\n📊 Plan Summary'));
          console.log(chalk.gray('─'.repeat(50)));
          console.log(chalk.cyan(`  Workspace: ${planSummary.workspaceName}`));

          const pending = planSummary.counts.pending || 0;
          const inProgress = planSummary.counts.in_progress || 0;
          const paused = planSummary.counts.paused || 0;
          const completed = planSummary.counts.completed || 0;
          const total = pending + inProgress + paused + completed;

          if (total > 0) {
            console.log(`  📝 Plans: ${chalk.green(completed)} completed, ${chalk.yellow(inProgress)} in progress, ${chalk.blue(pending)} pending${paused > 0 ? `, ${chalk.gray(paused)} paused` : ''}`);

            if (planSummary.totalSteps > 0) {
              const percentage = Math.round((planSummary.completedSteps / planSummary.totalSteps) * 100);
              console.log(`  📈 Progress: ${planSummary.completedSteps}/${planSummary.totalSteps} steps (${percentage}%)`);
            }
          } else {
            console.log(chalk.gray('  No plans in workspace'));
          }
        }
      }

      await manager.close();
    } catch (error) {
      // Silently ignore if unable to get plan summary
    }
  });

program
  .command('watch')
  .description('Watch real-time output of a running task')
  .argument('<taskId>', 'Task ID or index (1, 2, 3...) to watch')
  .action(async (taskId) => {
    // Check if daemon is running
    const daemonClient = new DaemonClient();
    if (!daemonClient.isDaemonRunning()) {
      console.error(chalk.red('✗ Daemon is not running'));
      console.log(chalk.yellow('💡 Start the daemon with: ani-code daemon --start'));
      console.log(chalk.yellow('💡 Or install service with: ani-code install-service --user'));
      process.exit(1);
    }

    // Connect to daemon via IPC
    const client = await getIPCClient();
    let task;
    
    // Try to resolve taskId as index first, then as task ID
    if (/^\d+$/.test(taskId)) {
      // If taskId is a number, try as index first
      task = await client.getTaskByIndex(parseInt(taskId));
      if (!task) {
        // Fallback to treating it as a task ID
        task = await client.getTask(taskId);
      }
    } else {
      // If not a number, treat as task ID
      task = await client.getTask(taskId);
    }
    
    if (!task || task.status !== 'running') {
      console.error(chalk.red(`Task ${taskId} is not running or not found`));
      client.disconnect();
      process.exit(1);
    }

    console.log(chalk.bold(`\n👀 Watching Task: ${task.name} (${task.id})`));
    console.log(chalk.gray('─'.repeat(50)));
    console.log(chalk.gray('Press Ctrl+C to stop watching\n'));

    const outputHandler = (outputData) => {
      if (outputData.taskId === task.id) {
        const prefix = outputData.type === 'stderr' ? chalk.red('ERR') : chalk.green('OUT');
        process.stdout.write(`${prefix} ${outputData.data}`);
      }
    };

    // Set up output handler
    client.on('message', outputHandler);

    // Start watching
    await client.watchTask(task.id, outputHandler);

    // Handle cleanup on exit
    const cleanup = () => {
      client.off('message', outputHandler);
      client.disconnect();
      console.log(chalk.gray('\n\nStopped watching task'));
      process.exit(0);
    };

    process.on('SIGINT', cleanup);
    process.on('SIGTERM', cleanup);
  });

program
  .command('history')
  .description('Show recent task history (last 10 tasks)')
  .option('-n, --number <count>', 'Number of tasks to show', parseInt, 10)
  .action(async (options) => {
    // Check if daemon is running
    const daemonClient = new DaemonClient();
    if (!daemonClient.isDaemonRunning()) {
      console.error(chalk.red('✗ Daemon is not running'));
      console.log(chalk.yellow('💡 Start the daemon with: ani-code daemon --start'));
      console.log(chalk.yellow('💡 Or install service with: ani-code service install --user'));
      process.exit(1);
    }

    // Connect to daemon via IPC
    const client = await getIPCClient();
    let history;
    try {
      history = await client.getTaskHistory(options.number);
    } finally {
      client.disconnect();
    }
    
    console.log(chalk.bold(`\n📜 Task History (Last ${Math.min(options.number, history?.length || 0)} tasks)`));
    console.log(chalk.gray('─'.repeat(70)));
    
    if (!history || history.length === 0) {
      console.log(chalk.gray('\n  No tasks in history'));
      return;
    }
    
    history.forEach(async (task, index) => {
      const duration = task.duration ? Math.round(task.duration / 1000) : 0;
      const statusDisplay = getStatusDisplay(task.status);
      const createdTime = task.createdAt ? new Date(task.createdAt).toLocaleString() : 'Unknown';
      
      console.log(`\n${index + 1}. ${chalk.bold(task.name)} ${statusDisplay}`);
      console.log(`   ${chalk.gray('ID:')} ${task.id}`);
      console.log(`   ${chalk.gray('Created:')} ${createdTime}`);
      console.log(`   ${chalk.gray('Duration:')} ${duration}s`);
      
      if (task.error) {
        console.log(`   ${chalk.gray('Error:')} ${chalk.red(task.error)}`);
      }
      
      if (task.cwd) {
        const { basename } = await import('path');
        const workdir = basename(task.cwd);
        console.log(`   ${chalk.gray('Workdir:')} ${chalk.cyan(workdir)}`);
      }
      
      // Show usage if available
      if (task.usage && (task.usage.input_tokens > 0 || task.usage.output_tokens > 0)) {
        console.log(`   ${chalk.gray('Usage:')} ${chalk.blue(task.usage.input_tokens + 'i/' + task.usage.output_tokens + 'o')}`);
      }
      
      // Show truncated command
      const command = task.command.length > 60 ? task.command.substring(0, 57) + '...' : task.command;
      console.log(`   ${chalk.gray('Command:')} ${command}`);
    });
    
    console.log(chalk.gray(`\n💡 Use "ani-code task <id>" to see full details of any task`));
  });

// ===============================
// DOCUMENTATION COMMANDS
// ===============================

program
  .command('doc')
  .description('Generate/update project documentation using Claude')
  .option('-y, --yolo', 'Auto-accept and execute documentation updates without prompting', false)
  .option('-c, --changes-only', 'Only update daily change log', false)
  .option('-a, --api-only', 'Only update API documentation', false)
  .action(async (options) => {
    try {
      // Check if daemon is running
      const daemonClient = new DaemonClient();
      if (!daemonClient.isDaemonRunning()) {
        console.error(chalk.red('✗ Daemon is not running'));
        console.log(chalk.yellow('💡 Start the daemon with: ani-code daemon --start'));
        process.exit(1);
      }

      // Check for pd folder and CLAUDE.md
      const { existsSync, mkdirSync, writeFileSync } = await import('fs');
      const { join } = await import('path');
      const { execSync } = await import('child_process');
      
      const pdDir = join(process.cwd(), 'pd');
      const claudeFile = join(process.cwd(), 'CLAUDE.md');
      
      // Create pd structure if it doesn't exist
      if (!existsSync(pdDir)) {
        console.log(chalk.yellow('📁 Creating pd/ folder structure...'));
        mkdirSync(join(pdDir, 'api'), { recursive: true });
        mkdirSync(join(pdDir, 'changes'), { recursive: true });
        mkdirSync(join(pdDir, 'architecture'), { recursive: true });
        mkdirSync(join(pdDir, 'features'), { recursive: true });
        
        // Create README
        const pdReadme = `# Project Documentation

This folder contains comprehensive documentation for the project.

## Structure

- **\`/api/\`** - API endpoint documentation
- **\`/changes/\`** - Daily change logs (format: YYYY-MM-DD.md)
- **\`/architecture/\`** - System architecture documentation
- **\`/features/\`** - Feature documentation

## Auto-generation

Documentation is auto-updated using: \`ani-code doc -y\`
`;
        writeFileSync(join(pdDir, 'README.md'), pdReadme);
        console.log(chalk.green('✓ Created pd/ folder structure'));
      }
      
      // Create or update CLAUDE.md if needed
      if (!existsSync(claudeFile)) {
        console.log(chalk.yellow('📝 Creating CLAUDE.md configuration...'));
        const claudeContent = `# Claude Configuration

## Project Context
Project documentation should be maintained in the pd/ folder.

## Permissions
- You have full read/write access to the \`pd/\` folder for documentation
- You can create and modify files in \`pd/changes/\` for daily change logs
- You can read all source files to understand the codebase
- You can execute git commands to get commit history

## Documentation Structure
- \`/pd/\` - Project documentation root
  - \`/pd/api/\` - API documentation
  - \`/pd/changes/\` - Daily change logs (format: YYYY-MM-DD.md)
  - \`/pd/architecture/\` - Architecture documentation
  - \`/pd/features/\` - Feature documentation

## Commands to Run
When updating documentation:
1. Use \`git log --oneline --since="today"\` to get today's changes
2. Create daily change files with format: \`/pd/changes/YYYY-MM-DD.md\`
3. Read source files to understand API changes
`;
        writeFileSync(claudeFile, claudeContent);
        console.log(chalk.green('✓ Created CLAUDE.md'));
      }
      
      // Get current date for change log
      const now = new Date();
      const dateStr = now.toISOString().split('T')[0]; // YYYY-MM-DD
      
      // Build the documentation prompt
      let docPrompt = `You are a project documentation generator. Your task is to update the project documentation in the pd/ folder.

IMPORTANT: You have full permissions to read and write files in the pd/ folder. Check CLAUDE.md for your permissions.

Current date: ${dateStr}

Tasks to complete:
`;

      if (options.changesOnly) {
        docPrompt += `
1. Create or update the daily change log at pd/changes/${dateStr}.md
   - Run 'git log --oneline --since="today" --until="tomorrow"' to get today's commits
   - Format as a markdown list with clear descriptions
   - Group related changes together
   - Include commit hashes for reference
`;
      } else if (options.apiOnly) {
        docPrompt += `
1. Update API documentation in pd/api/
   - Read src/http-server.js to document HTTP endpoints
   - Read src/ipc-server.js to document IPC protocol
   - Read src/index.js to document CLI commands
   - Create or update relevant .md files
`;
      } else {
        // Full documentation update
        docPrompt += `
1. Create or update the daily change log at pd/changes/${dateStr}.md
   - Run 'git log --oneline --since="today" --until="tomorrow"' to get today's commits
   - Format as a markdown list with clear descriptions
   - Group related changes together
   - Include commit hashes for reference

2. Update API documentation in pd/api/ if there are code changes
   - Read src/http-server.js for HTTP endpoints
   - Read src/ipc-server.js for IPC protocol
   - Read src/index.js for CLI commands
   - Update existing documentation or create new files as needed

3. Update feature documentation in pd/features/ if new features were added
   - Document any new commands or capabilities
   - Update existing feature docs if behavior changed

4. Update architecture documentation in pd/architecture/ if structure changed
   - Document any new components or services
   - Update data flow diagrams if applicable

Always:
- Use clear, concise markdown formatting
- Include code examples where helpful
- Keep documentation up-to-date with actual code
- Preserve existing documentation structure where possible
`;
      }

      docPrompt += `\n\nOutput a summary of what documentation was created or updated.`;

      console.log(chalk.blue('\n🤖 Generating documentation with Claude...'));
      
      // Create Claude task for documentation
      const { basename } = await import('path');
      const projectDir = basename(process.cwd());
      const hour = now.getHours().toString().padStart(2, '0');
      const minute = now.getMinutes().toString().padStart(2, '0');
      const taskName = `${projectDir}-doc-${hour}${minute}`;
      
      const client = await getIPCClient();
      let task;
      try {
        const taskOptions = { cwd: process.cwd() };
        
        // Check if we're running as a child process with parent's chatId
        if (process.env.ANICODE_PARENT_CHAT_ID) {
          taskOptions.chatId = process.env.ANICODE_PARENT_CHAT_ID;
        }
        
        task = await client.addTask(taskName, docPrompt, taskOptions);
        
        // Wait for the task to complete
        console.log(chalk.gray('⏳ Waiting for Claude to generate documentation...'));
        
        let attempts = 0;
        const maxAttempts = 300; // 5 minutes
        let result = null;
        
        while (attempts < maxAttempts) {
          await new Promise(resolve => setTimeout(resolve, 1000));
          
          let currentTask = await client.getTask(task.id);
          
          if (!currentTask) {
            currentTask = await client.getHistoryTask(task.id);
          }
          
          if (currentTask && (currentTask.status === 'completed' || currentTask.status === 'failed')) {
            // For doc command, check if output exists even if status is 'failed'
            // Claude sometimes returns exit code 1 but still generates valid output
            result = (currentTask.output || '').trim();
            
            if (result && result.length > 0) {
              // If we have output, consider it successful regardless of exit code
              break;
            } else if (currentTask.status === 'failed') {
              // Only fail if there's no output AND status is failed
              console.error(chalk.red('✗ Failed to generate documentation'));
              console.log(chalk.gray(`Error: ${currentTask.error || 'Unknown error'}`));
              process.exit(1);
            }
          }
          
          attempts++;
          
          if (attempts % 5 === 0) {
            const timeElapsed = attempts < 60 ? `${attempts}s` : `${Math.floor(attempts/60)}m ${attempts%60}s`;
            console.log(chalk.yellow(`Still waiting... (${timeElapsed})`));
          }
        }
        
        if (!result) {
          console.error(chalk.red('✗ Timeout waiting for documentation generation'));
          process.exit(1);
        }
        
        console.log(chalk.green('\n✓ Documentation generated successfully!'));
        console.log(chalk.cyan('Summary:'));
        console.log(result);
        
        if (!options.yolo) {
          console.log(chalk.yellow('\n⚠️  Please review the generated documentation in the pd/ folder'));
          console.log(chalk.gray('💡 Use --yolo flag to auto-accept in the future'));
        }
        
      } finally {
        client.disconnect();
      }
      
      console.log(chalk.green('\n✓ Documentation workflow completed successfully!'));
      
    } catch (error) {
      console.error(chalk.red(`Error: ${error.message}`));
      process.exit(1);
    }
  });

// TEST COMMANDS
// ===============================

program
  .command('test')
  .description('Implement missing tests and run test suite')
  .option('-y, --yolo', 'Auto-accept and run tests without prompting', false)
  .option('-i, --implement-only', 'Only implement missing tests', false)
  .option('-r, --run-only', 'Only run existing tests', false)
  .option('-f, --framework <framework>', 'Test framework to use (jest, mocha, vitest)', 'jest')
  .action(async (options) => {
    try {
      // Check if daemon is running
      const daemonClient = new DaemonClient();
      if (!daemonClient.isDaemonRunning()) {
        console.error(chalk.red('✗ Daemon is not running'));
        console.log(chalk.yellow('💡 Start the daemon with: ani-code daemon --start'));
        process.exit(1);
      }

      const { existsSync, readFileSync } = await import('fs');
      const { join } = await import('path');
      const { execSync } = await import('child_process');
      
      // Read package.json to understand the project
      const packageJsonPath = join(process.cwd(), 'package.json');
      let packageJson = {};
      if (existsSync(packageJsonPath)) {
        packageJson = JSON.parse(readFileSync(packageJsonPath, 'utf8'));
      }
      
      const now = new Date();
      const dateStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
      
      // Build test prompt based on options
      let testPrompt = `You are a test engineer tasked with implementing and running tests for this project.

IMPORTANT: Your goal is to ensure comprehensive test coverage for the codebase.
`;

      if (options.implementOnly) {
        testPrompt += `
1. Analyze the codebase structure:
   - Read package.json to understand dependencies and scripts
   - Identify main source files in src/ directory
   - Check for existing test files (*.test.js, *.spec.js, etc.)
   
2. Implement missing tests:
   - Create test files for modules that don't have tests
   - Use ${options.framework} as the testing framework
   - Install necessary testing dependencies if missing
   - Focus on unit tests for core functionality
   - Add integration tests for critical workflows
   - Ensure test files follow naming convention (*.test.js or *.spec.js)
   
3. Update package.json:
   - Add or update the "test" script to run ${options.framework}
   - Add test configuration if needed (jest.config.js, etc.)
   
4. Create test documentation:
   - Document test structure in pd/testing/README.md
   - Include instructions for running tests
   - List what is tested and coverage goals
`;
      } else if (options.runOnly) {
        testPrompt += `
1. Check test setup:
   - Read package.json to find test script
   - Verify test framework is installed
   - Check for test configuration files
   
2. Run the test suite:
   - Execute: npm test (or appropriate test command)
   - Capture and analyze test output
   - Note any failures or errors
   
3. Generate test report:
   - Summarize test results (passed/failed/skipped)
   - List any failing tests with error details
   - Suggest fixes for failing tests if any
`;
      } else {
        // Full test workflow - implement and run
        testPrompt += `
1. Analyze the codebase structure:
   - Read package.json to understand dependencies and scripts
   - Identify main source files in src/ directory
   - Check for existing test files (*.test.js, *.spec.js, etc.)
   
2. Implement missing tests:
   - Create test files for modules that don't have tests
   - Use ${options.framework} as the testing framework
   - Install necessary testing dependencies if missing
   - Focus on unit tests for core functionality
   - Add integration tests for critical workflows
   - Ensure test files follow naming convention (*.test.js or *.spec.js)
   
3. Update package.json:
   - Add or update the "test" script to run ${options.framework}
   - Add test configuration if needed (jest.config.js, etc.)
   
4. Run the test suite:
   - Execute: npm test
   - Capture and analyze test output
   - Fix any failing tests
   - Re-run tests until all pass
   
5. Generate test report:
   - Create or update pd/testing/test-report-${dateStr}.md
   - Include test statistics (total, passed, failed, coverage)
   - Document any issues found and fixed
   - List areas that need more test coverage
`;
      }

      testPrompt += `
      
Always:
- Follow project conventions and style
- Write clear, maintainable test code
- Use descriptive test names that explain what is being tested
- Include both positive and negative test cases
- Mock external dependencies appropriately
- Ensure tests are isolated and can run independently

Output a summary of:
- What tests were implemented or run
- Test results (if tests were run)
- Any issues encountered and how they were resolved
- Recommendations for improving test coverage`;

      console.log(chalk.blue('\n🧪 Starting test workflow with Claude...'));
      
      // Create Claude task for testing
      const { basename } = await import('path');
      const projectDir = basename(process.cwd());
      const hour = now.getHours().toString().padStart(2, '0');
      const minute = now.getMinutes().toString().padStart(2, '0');
      const taskName = `${projectDir}-test-${hour}${minute}`;
      
      const client = await getIPCClient();
      let task;
      try {
        const taskOptions = { cwd: process.cwd() };
        
        // Check if we're running as a child process with parent's chatId
        if (process.env.ANICODE_PARENT_CHAT_ID) {
          taskOptions.chatId = process.env.ANICODE_PARENT_CHAT_ID;
        }
        
        task = await client.addTask(taskName, testPrompt, taskOptions);
        
        // Wait for the task to complete
        console.log(chalk.gray('⏳ Waiting for Claude to implement and run tests...'));
        
        let attempts = 0;
        const maxAttempts = 600; // 10 minutes for test implementation
        let result = null;
        
        while (attempts < maxAttempts) {
          await new Promise(resolve => setTimeout(resolve, 1000));
          
          let currentTask = await client.getTask(task.id);
          
          if (!currentTask) {
            currentTask = await client.getHistoryTask(task.id);
          }
          
          if (currentTask && (currentTask.status === 'completed' || currentTask.status === 'failed')) {
            // For test command, check if output exists even if status is 'failed'
            // Tests might fail but we still want the report
            result = (currentTask.output || '').trim();
            
            if (result && result.length > 0) {
              // If we have output, consider it successful regardless of exit code
              break;
            } else if (currentTask.status === 'failed') {
              // Only fail if there's no output AND status is failed
              console.error(chalk.red('✗ Failed to complete test workflow'));
              console.log(chalk.gray(`Error: ${currentTask.error || 'Unknown error'}`));
              process.exit(1);
            }
          }
          
          attempts++;
          
          if (attempts % 10 === 0) {
            const timeElapsed = attempts < 60 ? `${attempts}s` : `${Math.floor(attempts/60)}m ${attempts%60}s`;
            console.log(chalk.yellow(`Still working on tests... (${timeElapsed})`));
          }
        }
        
        if (!result) {
          console.error(chalk.red('✗ Timeout waiting for test completion'));
          process.exit(1);
        }
        
        console.log(chalk.green('\n✓ Test workflow completed!'));
        console.log(chalk.cyan('Summary:'));
        console.log(result);
        
        if (!options.yolo) {
          console.log(chalk.yellow('\n⚠️  Please review the test results and any new test files'));
          console.log(chalk.gray('💡 Use --yolo flag to auto-accept in the future'));
        }
        
      } finally {
        client.disconnect();
      }
      
      console.log(chalk.green('\n✓ Test workflow completed successfully!'));
      
    } catch (error) {
      console.error(chalk.red(`Error: ${error.message}`));
      process.exit(1);
    }
  });

// GIT RELATED COMMANDS
// ===============================

program
  .command('run')
  .description('Run a shell command or custom workdir command')
  .argument('<command>', 'Shell command or custom command name')
  .argument('[name]', 'Task name (auto-generated if not provided)')
  .option('-t, --timeout <ms>', 'Task timeout in milliseconds', parseInt)
  .action(async (command, name, options) => {
    try {
      // Check if daemon is running
      const daemonClient = new DaemonClient();
      if (!daemonClient.isDaemonRunning()) {
        console.error(chalk.red('✗ Daemon is not running'));
        console.log(chalk.yellow('💡 Start the daemon with: ani-code daemon --start'));
        console.log(chalk.yellow('💡 Or install service with: ani-code service install --user'));
        process.exit(1);
      }
      
      // Check if this is a custom workdir command
      const fs = await import('fs/promises');
      const path = await import('path');
      const customPromptPath = path.join(process.cwd(), '.ani-code', `${command}-prompt.md`);
      let taskCommand = command;
      let isCustomCommand = false;
      
      try {
        await fs.access(customPromptPath);
        // Custom command exists, read the prompt
        const customPrompt = await fs.readFile(customPromptPath, 'utf-8');
        taskCommand = customPrompt;
        isCustomCommand = true;
        console.log(chalk.blue(`✓ Found custom command: ${command}`));
      } catch (err) {
        // Not a custom command, treat as shell command
        taskCommand = `shell:${command}`;
      }
      
      // Generate task name if not provided
      if (!name) {
        const projectDir = path.basename(process.cwd());
        const now = new Date();
        const hour = now.getHours().toString().padStart(2, '0');
        const minute = now.getMinutes().toString().padStart(2, '0');
        const cmdName = isCustomCommand ? command : 'run';
        name = `${projectDir}-${cmdName}-${hour}${minute}`;
      }
      
      // Connect to daemon via IPC
      const client = await getIPCClient();
      let task;
      try {
        // Capture current working directory and pass it with options
        const taskOptions = { 
          ...options, 
          cwd: process.cwd() 
        };
        task = await client.addTask(name, taskCommand, taskOptions);
      } finally {
        client.disconnect();
      }
      
      const taskType = isCustomCommand ? 'Custom command' : 'Shell';
      console.log(chalk.green(`✓ ${taskType} task added: ${task.name} (${task.id})`));
      if (!isCustomCommand) {
        console.log(chalk.gray(`Command: ${command}`));
      }
      console.log(chalk.yellow('💡 Use "ani-code watch ' + task.id + '" to see real-time output'));
    } catch (error) {
      console.error(chalk.red(`Error: ${error.message}`));
      process.exit(1);
    }
  });

program
  .command('message')
  .description('Send a text message to the related Lark/Telegram chat (use @filename to attach files)')
  .argument('<message>', 'Text message to send')
  .option('-m, --markdown', 'Send as markdown formatted message')
  .option('--mdv2', 'Send as MarkdownV2 formatted message (supports better code blocks)')
  .allowUnknownOption() // Allow unknown options to be passed as part of the message
  .addHelpText('after', `
Examples:
  $ ani-code message "Hello from ani-code!"
  $ ani-code message -m "**Important** update"
  $ ani-code message "Check this file: @report.pdf"
  $ ani-code message "Multiple files: @image.png @data.csv"
  $ ani-code message "This has -- double dashes"
  $ ani-code message -- "Message starting with --option-like-text"

Markdown Formatting (Telegram):
  -m, --markdown  : Use classic Markdown (bold: *text*, italic: _text_)
  --mdv2          : Use MarkdownV2 for better code block support

  Markdown Examples:
    $ ani-code message -m "*Bold* and _italic_ text"
    $ ani-code message -m "Command: \`npm install\`"

  MarkdownV2 Examples (better for code):
    $ ani-code message --mdv2 "Code: \`npm install\`"
    $ ani-code message --mdv2 "Multi-line code:\\n\\\`\\\`\\\`python\\nfor i in range(5):\\n    print(i)\\n\\\`\\\`\\\`"

  Combining Code and Images:
    $ ani-code message --mdv2 "Here's the error:\\n\\\`\\\`\\\`\\nError: Module not found\\n\\\`\\\`\\\`\\nScreenshot: @error.png"

File Attachments (Telegram):
  Use @filename syntax to attach files to your message.
  - Local files are automatically uploaded to S3 and sent as URLs
  - Images (.jpg, .png, .gif, .apng, etc.) are sent as photos
  - Other files are sent as documents (if S3 upload fails)
  - Supports multiple attachments in one message
  - Paths can be relative or absolute
  - Works with both plain text and markdown messages
  - URLs starting with http:// or https:// are sent directly

  Examples:
    $ ani-code message "Bug screenshot: @./screenshots/error.png"
    $ ani-code message "Check this: @/tmp/ani-browser-screenshots/screenshot.png"
    $ ani-code message "Image from web: @https://example.com/image.jpg"

Note: Use quotes around messages containing special characters or dashes.
      Use -- before the message to prevent dash interpretation as options.
      For MarkdownV2, some characters (._*[]()~\`>#+-=|{}) need escaping with \\
`)
  .action(async (messageText, options, command) => {
    try {
      // Handle case where message might contain unprocessed arguments
      // If there are unknown options captured, they might be part of the message
      const unknownArgs = command.args.slice(1); // Get any additional arguments after the first one
      if (unknownArgs.length > 0) {
        // Append any additional arguments that were mistakenly parsed as separate
        messageText = [messageText, ...unknownArgs].join(' ');
      }

      // Process escape sequences like \n, \t, etc.
      messageText = messageText
        .replace(/\\n/g, '\n')
        .replace(/\\t/g, '\t')
        .replace(/\\r/g, '\r')
        .replace(/\\\\/g, '\\');

      // Check if daemon is running
      const daemonClient = new DaemonClient();
      if (!daemonClient.isDaemonRunning()) {
        console.error(chalk.red('✗ Daemon is not running'));
        console.log(chalk.yellow('💡 Start the daemon with: ani-code daemon --start'));
        console.log(chalk.yellow('💡 Or install service with: ani-code service install --user'));
        process.exit(1);
      }

      const path = await import('path');
      const fs = await import('fs');
      const workdir = path.basename(process.cwd());

      // Load chat settings directly to get chat ID
      const { ChatSettingsManager } = await import('./chat-settings.js');
      const chatSettings = new ChatSettingsManager();
      await chatSettings.load();

      // Get the chat ID for current workdir
      const chatId = chatSettings.getChatForWorkdir(process.cwd());

      if (!chatId) {
        console.error(chalk.red(`✗ No chat ID configured for workdir: ${workdir}`));
        console.log(chalk.yellow('💡 First use /workdir command in Lark to configure this directory'));
        process.exit(1);
      }

      // Check if this is a Telegram chat ID
      if (chatId && chatId.startsWith('telegram:')) {
        // Use Telegram notifier for Telegram chats
        const { TelegramNotifier } = await import('./telegram-notifier.js');
        const telegramNotifier = new TelegramNotifier();

        // Extract the numeric chat ID from telegram:394977994 format
        const telegramChatId = chatId.replace('telegram:', '');

        // Parse message for @filename patterns and @URL patterns
        // Updated pattern to handle both local files and URLs
        const fileAttachmentPattern = /@([^\s]+\.[^\s]+)/g;
        const matches = [...messageText.matchAll(fileAttachmentPattern)];
        const attachments = [];

        if (matches.length > 0) {
          console.log(chalk.cyan(`Found ${matches.length} file attachment(s)`));

          for (const match of matches) {
            const filename = match[1];
            let filePath = filename;

            // Check if it's a URL (starts with http:// or https://)
            if (filename.startsWith('http://') || filename.startsWith('https://')) {
              // For URLs, especially S3 URLs, send them directly as photos
              console.log(chalk.cyan(`Found URL attachment: ${filename}`));
              // Extract meaningful filename from URL
              let attachmentFilename = 'image.jpg';
              try {
                const url = new URL(filename);
                const pathParts = url.pathname.split('/');
                const lastPart = pathParts[pathParts.length - 1];
                if (lastPart && lastPart !== '') {
                  attachmentFilename = lastPart;
                } else {
                  attachmentFilename = url.hostname;
                }
              } catch (e) {
                attachmentFilename = 'image.jpg';
              }
              attachments.push({
                filename: attachmentFilename,
                path: filename, // Use the URL as the path
                originalRef: match[0],
                isUrl: true
              });
              // Check if URL is a video
              const videoExtensions = ['.mp4', '.avi', '.mov', '.webm', '.mkv'];
              let isVideo = false;
              try {
                const url = new URL(filename);
                const ext = path.extname(url.pathname).toLowerCase();
                isVideo = videoExtensions.includes(ext);
              } catch (e) {
                // Not a valid URL or can't determine extension
              }
              const mediaType = isVideo ? 'video' : 'image';
              console.log(chalk.green(`✓ Will send URL as ${mediaType}: ${filename}`));
              continue;
            }

            // If not an absolute path, resolve relative to current directory
            if (!path.isAbsolute(filePath)) {
              filePath = path.resolve(process.cwd(), filePath);
            }

            // Check if file exists and validate size
            try {
              await fs.promises.access(filePath);

              // Check file size (50MB limit)
              const stats = await fs.promises.stat(filePath);
              const fileSizeInMB = stats.size / (1024 * 1024);
              const MAX_FILE_SIZE_MB = 50;

              if (fileSizeInMB > MAX_FILE_SIZE_MB) {
                console.error(chalk.red(`✗ File too large: ${filePath} (${fileSizeInMB.toFixed(2)}MB > ${MAX_FILE_SIZE_MB}MB limit)`));
                console.log(chalk.yellow(`💡 Please use a smaller file or compress it first`));
                continue; // Skip this file
              }

              console.log(chalk.green(`✓ Found file: ${filePath} (${fileSizeInMB.toFixed(2)}MB)`));

              // Upload local file to S3 first
              try {
                const { SecureUploader } = await import('./utils/secure-upload.js');
                const uploader = new SecureUploader();

                console.log(chalk.cyan(`📤 Uploading to S3: ${path.basename(filePath)}`));
                const uploadResult = await uploader.uploadFile(filePath, {
                  workdir: workdir,
                  metadata: {
                    'source': 'ani-code-message',
                    'original-path': filePath
                  }
                });

                console.log(chalk.green(`✓ Uploaded to S3: ${uploadResult.url}`));

                // Use S3 URL as the attachment path (treat it as a URL)
                attachments.push({
                  filename: path.basename(filePath),
                  path: uploadResult.url,
                  originalRef: match[0],
                  isUrl: true,  // Treat S3 upload as URL
                  isS3Upload: true  // Mark as S3 upload for reference
                });
              } catch (uploadError) {
                console.error(chalk.red(`✗ Failed to upload to S3: ${uploadError.message}`));
                // Fallback to direct file sending if S3 upload fails
                attachments.push({
                  filename: path.basename(filePath),
                  path: filePath,
                  originalRef: match[0],
                  isUrl: false
                });
                console.log(chalk.yellow(`⚠ Using direct file send as fallback`));
              }
            } catch (error) {
              console.warn(chalk.yellow(`⚠ File not found: ${filePath}`));
            }
          }
        }

        // Remove @filename references from the message text
        let cleanMessage = messageText;
        for (const attachment of attachments) {
          cleanMessage = cleanMessage.replace(attachment.originalRef, `[${attachment.filename}]`);
        }

        // Determine parse mode based on options (before sending attachments)
        let parseMode = undefined;
        if (options.mdv2) {
          parseMode = 'MarkdownV2';
        } else if (options.markdown) {
          parseMode = 'Markdown';
        }

        // If there's only one attachment and there's a message, combine them into a single message
        if (attachments.length === 1 && cleanMessage.trim()) {
          const attachment = attachments[0];
          try {
            // Use the clean message as the caption for the single attachment
            let captionText = cleanMessage.trim();

            // Normalize content to prevent Telegram errors
            captionText = captionText.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, ''); // Remove control chars

            if (attachment.isUrl) {
              // Check if URL is a video based on extension
              const videoExtensions = ['.mp4', '.avi', '.mov', '.webm', '.mkv'];
              let isVideo = false;
              try {
                const url = new URL(attachment.path);
                const ext = path.extname(url.pathname).toLowerCase();
                isVideo = videoExtensions.includes(ext);
              } catch (e) {
                // Not a valid URL or can't determine extension
              }

              if (isVideo) {
                // Send as video
                const actionText = attachment.isS3Upload ? '📤 Sending uploaded video' : '🎬 Sending URL as video';
                console.log(chalk.cyan(`${actionText} with message caption: ${attachment.path}`));
                await telegramNotifier.api.sendVideo(telegramChatId, attachment.path, {
                  caption: captionText,
                  parse_mode: parseMode
                });
                const successText = attachment.isS3Upload ? '✓ Sent uploaded video' : '✓ Sent URL as video';
                console.log(chalk.green(`${successText} with message in single Telegram message`));
              } else {
                // Send as photo (default for non-video URLs)
                const actionText = attachment.isS3Upload ? '📤 Sending uploaded image' : '📸 Sending URL as image';
                console.log(chalk.cyan(`${actionText} with message caption: ${attachment.path}`));
                await telegramNotifier.api.sendPhoto(telegramChatId, attachment.path, {
                  caption: captionText,
                  parse_mode: parseMode
                });
                const successText = attachment.isS3Upload ? '✓ Sent uploaded image' : '✓ Sent URL as image';
                console.log(chalk.green(`${successText} with message in single Telegram message`));
              }
            } else {
              // Determine if it's an image or video based on extension
              const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.apng', '.bmp', '.webp'];
              const videoExtensions = ['.mp4', '.avi', '.mov', '.webm', '.mkv'];
              const ext = path.extname(attachment.path).toLowerCase();

              if (imageExtensions.includes(ext)) {
                // Send as photo with message as caption
                console.log(chalk.cyan(`📸 Sending image with message caption: ${attachment.filename}`));
                const fileStream = fs.createReadStream(attachment.path);
                await telegramNotifier.api.sendPhoto(telegramChatId, fileStream, {
                  caption: captionText,
                  parse_mode: parseMode
                });
              } else if (videoExtensions.includes(ext)) {
                // Send as video with message as caption
                console.log(chalk.cyan(`🎬 Sending video with message caption: ${attachment.filename}`));
                const fileStream = fs.createReadStream(attachment.path);
                await telegramNotifier.api.sendVideo(telegramChatId, fileStream, {
                  caption: captionText,
                  parse_mode: parseMode
                });
              } else {
                // Send as document with message as caption
                console.log(chalk.cyan(`📄 Sending document with message caption: ${attachment.filename}`));
                const fileStream = fs.createReadStream(attachment.path);
                await telegramNotifier.api.sendDocument(telegramChatId, fileStream, {
                  caption: captionText,
                  filename: attachment.filename,
                  parse_mode: parseMode
                });
              }
              console.log(chalk.green(`✓ Sent ${attachment.filename} with message in single Telegram message`));
            }
          } catch (error) {
            console.error(chalk.red(`✗ Failed to send ${attachment.filename}: ${error.message}`));
          }
        } else {
          // Multiple attachments or no message - send separately as before
          for (const attachment of attachments) {
            try {
              if (attachment.isUrl) {
                // For URLs and S3 uploads, send directly as photo (Telegram accepts URLs for photos)
                const actionText = attachment.isS3Upload ? '📤 Sending uploaded image' : '📸 Sending URL as image';
                console.log(chalk.cyan(`${actionText}: ${attachment.path}`));
                // Extract hostname from URL for meaningful caption
                let captionText = attachment.isS3Upload ? `📤 ${attachment.filename}` : '📎 Image';
                if (!attachment.isS3Upload) {
                  try {
                    const url = new URL(attachment.path);
                    captionText = `📎 ${url.hostname}`;
                  } catch (e) {
                    captionText = `📎 ${attachment.path.substring(0, 50)}...`;
                  }
                }
                // Escape caption if using MarkdownV2
                if (parseMode === 'MarkdownV2') {
                  captionText = escapeMarkdownV2(captionText);
                }
                await telegramNotifier.api.sendPhoto(telegramChatId, attachment.path, {
                  caption: captionText,
                  parse_mode: parseMode
                });
                const successText = attachment.isS3Upload ? '✓ Sent uploaded image' : '✓ Sent URL as image';
                console.log(chalk.green(successText));
              } else {
                // Determine if it's an image or video based on extension
                const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.apng', '.bmp', '.webp'];
                const videoExtensions = ['.mp4', '.avi', '.mov', '.webm', '.mkv'];
                const ext = path.extname(attachment.path).toLowerCase();

                if (imageExtensions.includes(ext)) {
                  // Send as photo
                  console.log(chalk.cyan(`📸 Sending image: ${attachment.filename}`));
                  const fileStream = fs.createReadStream(attachment.path);
                  let captionText = `📎 ${attachment.filename}`;
                  // Escape caption if using MarkdownV2
                  if (parseMode === 'MarkdownV2') {
                    captionText = escapeMarkdownV2(captionText);
                  }
                  await telegramNotifier.api.sendPhoto(telegramChatId, fileStream, {
                    caption: captionText,
                    parse_mode: parseMode
                  });
                } else if (videoExtensions.includes(ext)) {
                  // Send as video
                  console.log(chalk.cyan(`🎬 Sending video: ${attachment.filename}`));
                  const fileStream = fs.createReadStream(attachment.path);
                  let captionText = `📎 ${attachment.filename}`;
                  // Escape caption if using MarkdownV2
                  if (parseMode === 'MarkdownV2') {
                    captionText = escapeMarkdownV2(captionText);
                  }
                  await telegramNotifier.api.sendVideo(telegramChatId, fileStream, {
                    caption: captionText,
                    parse_mode: parseMode
                  });
                } else {
                  // Send as document
                  console.log(chalk.cyan(`📄 Sending document: ${attachment.filename}`));
                  const fileStream = fs.createReadStream(attachment.path);
                  let captionText = `📎 ${attachment.filename}`;
                  // Escape caption if using MarkdownV2
                  if (parseMode === 'MarkdownV2') {
                    captionText = escapeMarkdownV2(captionText);
                  }
                  await telegramNotifier.api.sendDocument(telegramChatId, fileStream, {
                    caption: captionText,
                    filename: attachment.filename,
                    parse_mode: parseMode
                  });
                }
                console.log(chalk.green(`✓ Sent: ${attachment.filename}`));
              }
            } catch (error) {
              console.error(chalk.red(`✗ Failed to send ${attachment.filename}: ${error.message}`));
            }
          }

          // Send the main message (with @filename references replaced) only if there are no attachments or multiple attachments
          if (cleanMessage.trim() && attachments.length !== 1) {
            await telegramNotifier.sendMessage(telegramChatId, cleanMessage, {
              parse_mode: parseMode
            });
          }
        }

        const attachmentInfo = attachments.length > 0 ? ` with ${attachments.length} attachment(s)` : '';
        console.log(chalk.green(`✓ Message sent to Telegram chat for ${workdir}${attachmentInfo}`));
      } else {
        // Send message via Lark notifier
        const { LarkNotifier } = await import('./lark-notifier.js');
        const notifier = new LarkNotifier();
        
        let content, msgType;
        
        if (options.markdown) {
          // Convert markdown to Lark post format
          const { convertMarkdownToLarkPost } = await import('./markdown-to-lark.js');
          const postContent = convertMarkdownToLarkPost(messageText);
          content = JSON.stringify(postContent);
          msgType = 'post';
        } else {
          // For plain text messages
          content = JSON.stringify({
            text: messageText
          });
          msgType = 'text';
        }
        
        await notifier.sendMessageToChat(chatId, content, msgType);
        console.log(chalk.green(`✓ Message sent to Lark chat for ${workdir} (${msgType} format)`));
      }
    } catch (error) {
      console.error(chalk.red(`Error: ${error.message}`));
      process.exit(1);
    }
  });

program
  .command('message-raw')
  .description('Send raw Telegram API request from JSON file with auto-upload support')
  .argument('<jsonfile>', 'Path to JSON file containing Telegram API request')
  .addHelpText('after', `
This command sends raw Telegram API requests from a JSON file.
Supports @filename syntax for auto-uploading files as attachments.

Required fields in JSON:
  - chat_id: Telegram chat ID (numeric) - Optional if workspace is configured
  - text or caption: Message text (use caption when photo field is present)

Optional fields:
  - parse_mode: "Markdown", "MarkdownV2", or "HTML"
  - disable_web_page_preview: true/false
  - disable_notification: true/false
  - reply_to_message_id: Message ID to reply to
  - reply_markup: Inline keyboard or reply keyboard markup
  - photo: Path to photo file (will use sendPhoto API)

File Attachment Support:
  - Use @filename in text/caption to auto-upload and attach files
  - Images (.jpg, .png, .gif, .apng) are sent as photos
  - Other files are sent as documents
  - Files are uploaded after the main message

Example JSON files:

1. Simple text message (message.json):
{
  "text": "Hello World"
}
Or with explicit chat_id:
{
  "chat_id": 123456789,
  "text": "Hello World"
}

2. Message with copyable URLs (notification.json):
{
  "chat_id": 123456789,
  "text": "📸 Screenshot\\n\\nSite: \`https://example.com\`\\nFile: \`https://file.io/ABC123\`",
  "parse_mode": "MarkdownV2"
}

3. Photo with caption (screenshot.json):
{
  "chat_id": 123456789,
  "photo": "/tmp/screenshot.png",
  "caption": "📸 Screenshot captured\\n\\nURL: \`https://example.com\`",
  "parse_mode": "MarkdownV2"
}

4. Message with auto-upload attachments (report.json):
{
  "chat_id": 123456789,
  "text": "📊 Daily Report\\n\\nScreenshot: @screenshot.png\\nData: @report.csv",
  "parse_mode": "MarkdownV2"
}

5. Combined photo and attachments (full.json):
{
  "chat_id": 123456789,
  "photo": "/tmp/main-screenshot.png",
  "caption": "Error Report\\n\\nLogs: @error.log\\nConfig: @config.json",
  "parse_mode": "MarkdownV2"
}

Usage:
  $ ani-code message-raw message.json
  $ ani-code message-raw ./notifications/screenshot.json
  $ ani-code message-raw report.json

Notes:
  - URLs wrapped in backticks (\`) are copyable in Telegram
  - If chat_id is not in JSON, uses workspace's configured Telegram chat
  - If chat_id IS specified in JSON, it overrides workspace configuration
  - Requires TELEGRAM_BOT_TOKEN environment variable
  - @filename references are processed and files are uploaded automatically
  - Configure workspace with: /workdir command in Telegram
`)
  .action(async (jsonFile) => {
    try {
      const fs = await import('fs');
      const path = await import('path');

      // Resolve file path
      const resolvedPath = path.resolve(jsonFile);

      // Check if file exists
      if (!fs.existsSync(resolvedPath)) {
        console.error(chalk.red(`✗ JSON file not found: ${jsonFile}`));
        console.log(chalk.yellow('Please provide a valid path to a JSON file'));
        console.log(chalk.gray('Example: ani-code message-raw message.json'));
        process.exit(1);
      }

      // Read and parse JSON file
      let body;
      try {
        const fileContent = fs.readFileSync(resolvedPath, 'utf8');
        body = JSON.parse(fileContent);
        console.log(chalk.cyan(`📂 Reading JSON from: ${jsonFile}`));
      } catch (error) {
        console.error(chalk.red('✗ Invalid JSON format in file'));
        console.error(chalk.yellow(`Parse error: ${error.message}`));
        console.log(chalk.gray('Please ensure the file contains valid JSON'));
        process.exit(1);
      }

      // Check if daemon is running
      const { DaemonClient } = await import('./daemon-client.js');
      const daemonClient = new DaemonClient();
      if (!daemonClient.isDaemonRunning()) {
        console.error(chalk.red('✗ Daemon is not running'));
        console.log(chalk.yellow('💡 Start the daemon with: ani-code daemon --start'));
        process.exit(1);
      }

      // Get workspace-based chat ID if not specified in JSON
      if (!body.chat_id) {
        // Load chat settings to get chat ID from workspace
        const { ChatSettingsManager } = await import('./chat-settings.js');
        const chatSettings = new ChatSettingsManager();
        await chatSettings.load();

        // Get the chat ID for current workdir
        const chatId = chatSettings.getChatForWorkdir(process.cwd());

        if (!chatId) {
          const workdir = path.basename(process.cwd());
          console.error(chalk.red(`✗ No chat ID configured for workdir: ${workdir}`));
          console.log(chalk.yellow('💡 Either specify "chat_id" in JSON or configure workspace with /workdir command in Telegram'));
          process.exit(1);
        }

        // Check if this is a Telegram chat ID
        if (chatId.startsWith('telegram:')) {
          // Extract the numeric chat ID from telegram:394977994 format
          body.chat_id = chatId.replace('telegram:', '');
          console.log(chalk.cyan(`📍 Using workspace chat ID: ${body.chat_id}`));
        } else {
          console.error(chalk.red(`✗ Workspace is not configured for Telegram (found: ${chatId})`));
          console.log(chalk.yellow('💡 Use /workdir command in Telegram to configure this workspace'));
          process.exit(1);
        }
      }

      // Process @filename references in text/caption for auto-upload
      let processedText = body.text || body.caption || '';
      const attachments = [];

      if (processedText) {
        const fileAttachmentPattern = /@([^\s]+\.[^\s]+)/g;
        const matches = [...processedText.matchAll(fileAttachmentPattern)];

        if (matches.length > 0) {
          console.log(chalk.cyan(`Found ${matches.length} @filename reference(s) for auto-upload`));

          for (const match of matches) {
            const filename = match[1];
            let filePath = filename;

            // Check if it's a URL (starts with http:// or https://)
            if (filename.startsWith('http://') || filename.startsWith('https://')) {
              // For URLs, especially S3 URLs, send them directly as photos
              console.log(chalk.cyan(`Found URL attachment: ${filename}`));
              // Extract meaningful filename from URL
              let attachmentFilename = 'image.jpg';
              let displayName = 'Image from URL';
              try {
                const url = new URL(filename);
                const pathParts = url.pathname.split('/');
                const lastPart = pathParts[pathParts.length - 1];
                if (lastPart && lastPart !== '') {
                  attachmentFilename = lastPart;
                  displayName = lastPart;
                } else {
                  attachmentFilename = url.hostname;
                  displayName = url.hostname;
                }
              } catch (e) {
                attachmentFilename = 'image.jpg';
                displayName = 'Image from URL';
              }
              attachments.push({
                filename: attachmentFilename,
                path: filename, // Use the URL as the path
                originalRef: match[0],
                isUrl: true
              });
              // Check if URL is a video
              const videoExtensions = ['.mp4', '.avi', '.mov', '.webm', '.mkv'];
              let isVideo = false;
              try {
                const url = new URL(filename);
                const ext = path.extname(url.pathname).toLowerCase();
                isVideo = videoExtensions.includes(ext);
              } catch (e) {
                // Not a valid URL or can't determine extension
              }
              const mediaType = isVideo ? 'video' : 'image';
              console.log(chalk.green(`✓ Will send URL as ${mediaType}: ${filename}`));
              // Replace @URL with [hostname or filename] in the text
              // If using MarkdownV2, we need to escape the display name
              const replacementText = body.parse_mode === 'MarkdownV2'
                ? `[${escapeMarkdownV2(displayName)}]`
                : `[${displayName}]`;
              processedText = processedText.replace(match[0], replacementText);
              continue;
            }

            // If not an absolute path, resolve relative to current directory
            if (!path.isAbsolute(filePath)) {
              filePath = path.resolve(process.cwd(), filePath);
            }

            // Check if file exists and validate size
            if (fs.existsSync(filePath)) {
              // Check file size (50MB limit)
              const stats = fs.statSync(filePath);
              const fileSizeInMB = stats.size / (1024 * 1024);
              const MAX_FILE_SIZE_MB = 50;

              if (fileSizeInMB > MAX_FILE_SIZE_MB) {
                console.error(chalk.red(`✗ File too large: ${filePath} (${fileSizeInMB.toFixed(2)}MB > ${MAX_FILE_SIZE_MB}MB limit)`));
                console.log(chalk.yellow(`💡 Please use a smaller file or compress it first`));
                // Keep the reference as-is if file is too large
                continue;
              }

              attachments.push({
                filename: path.basename(filePath),
                path: filePath,
                originalRef: match[0],
                isUrl: false
              });
              console.log(chalk.green(`✓ Found file: ${filePath} (${fileSizeInMB.toFixed(2)}MB)`));
              // Replace @filename with [filename] in the text
              // If using MarkdownV2, we need to escape the filename
              const basename = path.basename(filePath);
              const replacementText = body.parse_mode === 'MarkdownV2'
                ? `[${escapeMarkdownV2(basename)}]`
                : `[${basename}]`;
              processedText = processedText.replace(match[0], replacementText);
            } else {
              console.warn(chalk.yellow(`⚠ File not found: ${filePath} (referenced as ${match[0]})`));
              // Keep the reference as-is if file not found
            }
          }
        }
      }

      // Update body with processed text
      if (body.text) body.text = processedText;
      if (body.caption) body.caption = processedText;

      // Check if it's a photo message or text message
      const isPhotoMessage = body.photo;

      if (!body.text && !body.caption && !isPhotoMessage) {
        console.error(chalk.red('✗ Missing required field: text, caption, or photo'));
        console.log(chalk.yellow('Either text, caption, or photo field is required in the JSON'));
        process.exit(1);
      }

      // Check if Telegram bot token is configured
      const botToken = process.env.TELEGRAM_BOT_TOKEN;
      if (!botToken) {
        console.error(chalk.red('✗ TELEGRAM_BOT_TOKEN not configured'));
        console.log(chalk.yellow('💡 Set TELEGRAM_BOT_TOKEN in your .env file or environment'));
        process.exit(1);
      }

      // Send the raw request using Telegram API
      const { TelegramAPI } = await import('./telegram-api.js');
      const telegramAPI = new TelegramAPI();

      console.log(chalk.cyan(`📤 Sending raw Telegram API request (${isPhotoMessage ? 'photo' : 'text'})...`));

      let result;

      if (isPhotoMessage) {
        // Handle photo message
        const photoPath = path.resolve(body.photo);

        // Check if photo file exists and validate size
        if (!fs.existsSync(photoPath)) {
          console.error(chalk.red(`✗ Photo file not found: ${body.photo}`));
          process.exit(1);
        }

        // Check file size (50MB limit)
        const photoStats = fs.statSync(photoPath);
        const photoSizeInMB = photoStats.size / (1024 * 1024);
        const MAX_PHOTO_SIZE_MB = 50;

        if (photoSizeInMB > MAX_PHOTO_SIZE_MB) {
          console.error(chalk.red(`✗ Photo file too large: ${photoPath} (${photoSizeInMB.toFixed(2)}MB > ${MAX_PHOTO_SIZE_MB}MB limit)`));
          console.log(chalk.yellow(`💡 Please use a smaller photo or compress it first`));
          process.exit(1);
        }

        console.log(chalk.gray(`  Photo: ${photoPath} (${photoSizeInMB.toFixed(2)}MB)`));
        if (body.caption) {
          const captionPreview = body.caption.substring(0, 50) + (body.caption.length > 50 ? '...' : '');
          console.log(chalk.gray(`  Caption: ${captionPreview}`));
        }

        // Create file stream for photo
        const fileStream = fs.createReadStream(photoPath);

        // Send photo with optional caption and other parameters
        result = await telegramAPI.sendPhoto(body.chat_id, fileStream, {
          caption: body.caption,
          parse_mode: body.parse_mode,
          disable_notification: body.disable_notification,
          reply_to_message_id: body.reply_to_message_id,
          reply_markup: body.reply_markup,
          // Include any other fields from the body
          ...Object.keys(body).filter(k => !['chat_id', 'photo', 'caption', 'text'].includes(k)).reduce((acc, k) => ({...acc, [k]: body[k]}), {})
        });

      } else {
        // Handle text message
        const messageText = body.text || body.caption;

        // Log sanitized preview of the request
        const preview = {
          chat_id: body.chat_id,
          text: messageText ? `${messageText.substring(0, 50)}${messageText.length > 50 ? '...' : ''}` : undefined,
          parse_mode: body.parse_mode,
          ...Object.keys(body).filter(k => !['chat_id', 'text', 'caption'].includes(k)).reduce((acc, k) => ({...acc, [k]: typeof body[k] === 'object' ? '[object]' : body[k]}), {})
        };
        console.log(chalk.gray('Request preview:'), preview);

        // Send text message
        result = await telegramAPI.sendMessage(body.chat_id, messageText, {
          parse_mode: body.parse_mode,
          disable_web_page_preview: body.disable_web_page_preview,
          disable_notification: body.disable_notification,
          reply_to_message_id: body.reply_to_message_id,
          reply_markup: body.reply_markup,
          // Include any other fields from the body
          ...Object.keys(body).filter(k => !['chat_id', 'text', 'caption'].includes(k)).reduce((acc, k) => ({...acc, [k]: body[k]}), {})
        });
      }

      if (result.ok) {
        const messageId = result.result?.message_id;
        const chatTitle = result.result?.chat?.title || result.result?.chat?.username || 'private chat';
        console.log(chalk.green(`✓ ${isPhotoMessage ? 'Photo' : 'Message'} sent successfully`));
        console.log(chalk.gray(`  Chat: ${chatTitle} (${body.chat_id})`));
        console.log(chalk.gray(`  Message ID: ${messageId}`));
        if (body.parse_mode) {
          console.log(chalk.gray(`  Parse mode: ${body.parse_mode}`));
        }

        // Send additional attachments if any (from @filename references)
        if (attachments.length > 0) {
          console.log(chalk.cyan(`\n📎 Sending ${attachments.length} attachment(s)...`));

          // Import TelegramAPI for sending documents
          const { TelegramAPI } = await import('./telegram-api.js');
          const telegramAPI = new TelegramAPI();

          for (const attachment of attachments) {
            try {
              if (attachment.isUrl) {
                // For URLs, send directly as photo (Telegram accepts URLs for photos)
                console.log(chalk.cyan(`  📸 Sending URL as image: ${attachment.path}`));
                // Extract hostname from URL for meaningful caption
                let captionText = '📎 Image';
                try {
                  const url = new URL(attachment.path);
                  captionText = `📎 ${url.hostname}`;
                } catch (e) {
                  captionText = `📎 ${attachment.path.substring(0, 50)}...`;
                }
                // Escape caption if using MarkdownV2
                if (body.parse_mode === 'MarkdownV2') {
                  captionText = escapeMarkdownV2(captionText);
                }
                await telegramAPI.sendPhoto(body.chat_id, attachment.path, {
                  caption: captionText,
                  parse_mode: body.parse_mode
                });
                console.log(chalk.green(`  ✓ Sent URL as image`));
              } else {
                // Determine if it's an image based on extension
                const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.apng', '.bmp', '.webp'];
                const ext = path.extname(attachment.path).toLowerCase();

                if (imageExtensions.includes(ext)) {
                  // Send as photo
                  console.log(chalk.cyan(`  📸 Sending image: ${attachment.filename}`));
                  const fileStream = fs.createReadStream(attachment.path);
                  let captionText = `📎 ${attachment.filename}`;
                  // Escape caption if using MarkdownV2
                  if (body.parse_mode === 'MarkdownV2') {
                    captionText = escapeMarkdownV2(captionText);
                  }
                  await telegramAPI.sendPhoto(body.chat_id, fileStream, {
                    caption: captionText,
                    parse_mode: body.parse_mode
                  });
                } else {
                  // Send as document
                  console.log(chalk.cyan(`  📄 Sending document: ${attachment.filename}`));
                  const fileStream = fs.createReadStream(attachment.path);
                  let captionText = `📎 ${attachment.filename}`;
                  // Escape caption if using MarkdownV2
                  if (body.parse_mode === 'MarkdownV2') {
                    captionText = escapeMarkdownV2(captionText);
                  }
                  await telegramAPI.sendDocument(body.chat_id, fileStream, {
                    caption: captionText,
                    filename: attachment.filename,
                    parse_mode: body.parse_mode
                  });
                }
                console.log(chalk.green(`  ✓ Sent: ${attachment.filename}`));
              }
            } catch (error) {
              console.error(chalk.red(`  ✗ Failed to send ${attachment.filename}: ${error.message}`));
            }
          }
        }
      } else {
        console.error(chalk.red(`✗ Failed to send ${isPhotoMessage ? 'photo' : 'message'}: ${result.description || 'Unknown error'}`));
        if (result.error_code) {
          console.error(chalk.yellow(`Error code: ${result.error_code}`));
        }
        process.exit(1);
      }
    } catch (error) {
      console.error(chalk.red(`✗ Error: ${error.message}`));
      if (error.response?.data) {
        console.error(chalk.yellow('API response:'), error.response.data);
      }
      process.exit(1);
    }
  });

program
  .command('upload')
  .description('Upload a file to S3 and get a downloadable URL')
  .argument('[file]', 'File path to upload')
  .option('--workspace-temp', 'Upload all temp folders from current workspace')
  .action(async (filePath, options) => {
    try {
      const fs = await import('fs/promises');
      const path = await import('path');
      const crypto = await import('crypto');
      
      // Handle workspace temp folder upload
      if (options.workspaceTemp) {
        const { secureUploader } = await import('./utils/secure-upload.js');
        
        console.log(chalk.cyan('🔍 Searching for temp folders in workspace...'));
        const workspacePath = process.cwd();
        console.log(chalk.gray(`Workspace: ${workspacePath}`));
        
        try {
          const results = await secureUploader.uploadWorkspaceTempFolders(workspacePath);
          
          if (results.length === 0) {
            console.log(chalk.yellow('No temp folders found to upload'));
            return;
          }
          
          console.log(chalk.green(`\n✓ Uploaded ${results.length} temp folder(s):\n`));
          
          results.forEach(result => {
            if (result.error) {
              console.log(chalk.red(`  ✗ ${result.directory}: ${result.error}`));
            } else {
              console.log(chalk.green(`  ✓ ${result.directory}:`));
              console.log(chalk.gray(`     Original size: ${result.originalSize}`));
              console.log(chalk.gray(`     Archive size: ${result.archiveSize}`));
              console.log(chalk.blue(`     URL: ${result.url}`));
            }
          });
          
          return;
        } catch (error) {
          console.error(chalk.red(`✗ Failed to upload workspace temp folders: ${error.message}`));
          process.exit(1);
        }
      }
      
      // Regular file upload - require file argument
      if (!filePath) {
        console.error(chalk.red('✗ File path is required when not using --workspace-temp'));
        console.log(chalk.yellow('Usage: ani-code upload <file>'));
        console.log(chalk.yellow('   or: ani-code upload --workspace-temp'));
        process.exit(1);
      }
      
      // Check if file exists
      try {
        await fs.access(filePath);
      } catch (error) {
        console.error(chalk.red(`✗ File not found: ${filePath}`));
        process.exit(1);
      }
      
      // Check S3 environment variables
      const bucketName = process.env.S3_CACHE_BUCKET;
      const s3Endpoint = process.env.S3_ENDPOINT;
      
      if (!bucketName) {
        console.error(chalk.red('✗ S3_CACHE_BUCKET environment variable not set'));
        console.log(chalk.yellow('💡 Set S3_CACHE_BUCKET=your-bucket-name in .env or environment'));
        process.exit(1);
      }
      
      if (!s3Endpoint) {
        console.error(chalk.red('✗ S3_ENDPOINT environment variable not set'));
        console.log(chalk.yellow('💡 Set S3_ENDPOINT=s3://KEY:SECRET@endpoint-url in .env or environment'));
        process.exit(1);
      }
      
      // Parse S3 endpoint
      const endpointMatch = s3Endpoint.match(/^s3:\/\/([^:]+):([^@]+)@(.+)$/);
      if (!endpointMatch) {
        console.error(chalk.red('✗ Invalid S3_ENDPOINT format'));
        console.log(chalk.yellow('💡 Format: s3://ACCESS_KEY:SECRET_KEY@endpoint-url'));
        process.exit(1);
      }
      
      const [, accessKeyId, secretAccessKey, endpoint] = endpointMatch;
      
      // Get file stats
      const fileStats = await fs.stat(filePath);
      const fileSizeInBytes = fileStats.size;
      const fileSizeInMB = (fileSizeInBytes / (1024 * 1024)).toFixed(2);
      
      // Format file size for display
      const formatFileSize = (bytes) => {
        if (bytes < 1024) return `${bytes} B`;
        if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(2)} KB`;
        if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
        return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
      };
      
      console.log(chalk.cyan(`📁 File: ${filePath}`));
      console.log(chalk.cyan(`📊 Size: ${formatFileSize(fileSizeInBytes)}`));
      
      // Read file and calculate MD5
      console.log(chalk.gray('Reading file and calculating checksum...'));
      const fileContent = await fs.readFile(filePath);
      const md5Hash = crypto.createHash('md5').update(fileContent).digest('hex');
      
      // Get file extension
      const extension = path.extname(filePath);
      const baseName = path.basename(filePath, extension);

      // Generate S3 key based on workdir with improved naming
      const workdir = path.basename(process.cwd());
      const now = new Date();
      const yearMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

      // Normalize and shorten the filename
      let normalizedName = '';
      if (baseName) {
        // Remove special characters, keep only alphanumeric and dash
        normalizedName = baseName
          .replace(/[^a-zA-Z0-9-]/g, '-') // Replace special chars with dash
          .replace(/-+/g, '-') // Replace multiple dashes with single dash
          .replace(/^-|-$/g, '') // Remove leading/trailing dashes
          .toLowerCase()
          .substring(0, 12); // Max 12 characters
        if (normalizedName) {
          normalizedName = `${normalizedName}-`;
        }
      }

      // Use only first 8 characters of hash for brevity
      const shortHash = md5Hash.substring(0, 8);

      const s3Key = `${workdir}/${yearMonth}/${normalizedName}${shortHash}${extension}`;
      
      // Initialize S3 client
      const { S3Client, PutObjectCommand } = await import('@aws-sdk/client-s3');
      
      const s3Client = new S3Client({
        endpoint: `https://${endpoint}`,
        region: 'auto',
        credentials: {
          accessKeyId,
          secretAccessKey
        },
        forcePathStyle: process.env.S3_FORCE_PATH_STYLE === 'true'
      });
      
      // Upload file with progress indication
      const uploadStartTime = Date.now();
      process.stdout.write(chalk.yellow(`⬆️  Uploading to S3...`));
      
      const command = new PutObjectCommand({
        Bucket: bucketName,
        Key: s3Key,
        Body: fileContent,
        ContentType: getContentType(extension),
        Metadata: {
          'original-name': path.basename(filePath),
          'upload-date': new Date().toISOString(),
          'workdir': workdir,
          'file-size': fileSizeInBytes.toString()
        }
      });
      
      try {
        // Create a simple animation while uploading
        const spinner = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];
        let spinnerIndex = 0;
        const spinnerInterval = setInterval(() => {
          const elapsed = ((Date.now() - uploadStartTime) / 1000).toFixed(1);
          process.stdout.write(`\r${chalk.yellow(`⬆️  Uploading to S3... ${spinner[spinnerIndex]} (${elapsed}s)`)}`);
          spinnerIndex = (spinnerIndex + 1) % spinner.length;
        }, 100);
        
        await s3Client.send(command);
        
        clearInterval(spinnerInterval);
        const uploadTime = ((Date.now() - uploadStartTime) / 1000).toFixed(2);
        const uploadSpeed = (fileSizeInBytes / (1024 * 1024) / uploadTime).toFixed(2);
        process.stdout.write(`\r${' '.repeat(50)}\r`); // Clear the line
        console.log(chalk.green(`✓ Upload completed in ${uploadTime}s (${uploadSpeed} MB/s)`));
      } catch (error) {
        console.error(chalk.red(`\n✗ Upload failed: ${error.message}`));
        process.exit(1);
      }
      
      // Generate download URL with bucket ID in the front
      const downloadUrl = `https://${bucketName}.${endpoint}/${s3Key}`;
      
      console.log(`\n📎 Download URL: ${chalk.bgBlue.white(` ${downloadUrl} `)}`);
      console.log(chalk.gray(`   S3 Key: ${s3Key}`));
      console.log(chalk.gray(`   MD5: ${md5Hash}`));
      
      // Copy to clipboard if possible
      try {
        const { execSync } = await import('child_process');
        if (process.platform === 'darwin') {
          execSync(`echo "${downloadUrl}" | pbcopy`);
          console.log(chalk.gray('✓ URL copied to clipboard'));
        } else if (process.platform === 'linux') {
          try {
            execSync(`echo "${downloadUrl}" | xclip -selection clipboard`, { stdio: 'pipe' });
            console.log(chalk.gray('✓ URL copied to clipboard'));
          } catch {
            // xclip might not be installed, silently skip
          }
        }
      } catch {
        // Clipboard copy failed, ignore
      }
    } catch (error) {
      console.error(chalk.red(`Error: ${error.message}`));
      process.exit(1);
    }
  });

// Helper function to get content type based on file extension
function getContentType(extension) {
  const contentTypes = {
    '.pdf': 'application/pdf',
    '.png': 'image/png',
    '.apng': 'image/apng',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.webp': 'image/webp',
    '.svg': 'image/svg+xml',
    '.mp4': 'video/mp4',
    '.webm': 'video/webm',
    '.mp3': 'audio/mpeg',
    '.wav': 'audio/wav',
    '.zip': 'application/zip',
    '.tar': 'application/x-tar',
    '.gz': 'application/gzip',
    '.json': 'application/json',
    '.xml': 'application/xml',
    '.txt': 'text/plain',
    '.html': 'text/html',
    '.css': 'text/css',
    '.js': 'application/javascript',
    '.ts': 'application/typescript',
    '.md': 'text/markdown',
    '.csv': 'text/csv',
    '.doc': 'application/msword',
    '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    '.xls': 'application/vnd.ms-excel',
    '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    '.ppt': 'application/vnd.ms-powerpoint',
    '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
  };
  
  return contentTypes[extension.toLowerCase()] || 'application/octet-stream';
}

program
  .command('cancel')
  .description('Cancel a running task')
  .argument('<taskId>', 'Task ID to cancel')
  .action(async (taskId) => {
    // Check if daemon is running
    const daemonClient = new DaemonClient();
    if (!daemonClient.isDaemonRunning()) {
      console.error(chalk.red('✗ Daemon is not running'));
      console.log(chalk.yellow('💡 Start the daemon with: ani-code daemon --start'));
      console.log(chalk.yellow('💡 Or install service with: ani-code install-service --user'));
      process.exit(1);
    }

    // Connect to daemon via IPC
    const client = await getIPCClient();
    let result;
    try {
      result = await client.cancelTask(taskId);
    } finally {
      client.disconnect();
    }
    
    if (result.success) {
      console.log(chalk.green(`✓ ${result.message}`));
    } else {
      console.error(chalk.red(`✗ ${result.message}`));
      process.exit(1);
    }
  });

program
  .command('retry')
  .description('Retry the last failed task or a specific task')
  .argument('[taskId]', 'Task ID to retry (defaults to last failed task)')
  .option('-c, --continue', 'Continue in the same working directory as the original task')
  .action(async (taskId, options) => {
    try {
      // Check if daemon is running
      const daemonClient = new DaemonClient();
      if (!daemonClient.isDaemonRunning()) {
        console.error(chalk.red('✗ Daemon is not running'));
        console.log(chalk.yellow('💡 Start the daemon with: ani-code daemon --start'));
        console.log(chalk.yellow('💡 Or install service with: ani-code service install --user'));
        process.exit(1);
      }

      // Connect to daemon via IPC
      const client = await getIPCClient();
      let taskToRetry = null;
      
      try {
        if (taskId) {
          // Get specific task from history
          taskToRetry = await client.getHistoryTask(taskId);
          if (!taskToRetry) {
            // Try getting from active tasks
            taskToRetry = await client.getTask(taskId);
          }
          
          if (!taskToRetry) {
            console.error(chalk.red(`✗ Task ${taskId} not found`));
            process.exit(1);
          }
        } else {
          // Get last failed task from history
          const history = await client.getTaskHistory(10);
          taskToRetry = history.find(task => task.status === 'failed');
          
          if (!taskToRetry) {
            console.error(chalk.red('✗ No failed tasks found in recent history'));
            process.exit(1);
          }
        }
        
        // Prepare new task
        const newTaskName = `${taskToRetry.name}-retry`;
        const taskOptions = {
          cwd: options.continue ? taskToRetry.cwd : process.cwd()
        };
        
        console.log(chalk.blue(`🔄 Retrying task: ${taskToRetry.name}`));
        console.log(chalk.gray(`   Original ID: ${taskToRetry.id}`));
        console.log(chalk.gray(`   Command: ${taskToRetry.command.substring(0, 60)}...`));
        console.log(chalk.gray(`   Working dir: ${taskOptions.cwd}`));
        
        // Add the retry task
        const newTask = await client.addTask(newTaskName, taskToRetry.command, taskOptions);
        console.log(chalk.green(`✓ Retry task added: ${newTask.name} (${newTask.id})`));
        
      } finally {
        client.disconnect();
      }
    } catch (error) {
      console.error(chalk.red(`Error: ${error.message}`));
      process.exit(1);
    }
  });

program
  .command('task')
  .description('Get details of a specific task')
  .argument('<taskId>', 'Task ID')
  .action(async (taskId) => {
    // Check if daemon is running
    const daemonClient = new DaemonClient();
    if (!daemonClient.isDaemonRunning()) {
      console.error(chalk.red('✗ Daemon is not running'));
      console.log(chalk.yellow('💡 Start the daemon with: ani-code daemon --start'));
      console.log(chalk.yellow('💡 Or install service with: ani-code install-service --user'));
      process.exit(1);
    }

    // Connect to daemon via IPC
    const client = await getIPCClient();
    let task;
    try {
      task = await client.getTask(taskId);
    } finally {
      client.disconnect();
    }
    
    if (!task) {
      console.error(chalk.red(`Task not found: ${taskId}`));
      process.exit(1);
    }
    
    console.log(chalk.bold(`\n📋 Task Details: ${task.name}`));
    console.log(chalk.gray('─'.repeat(50)));
    console.log(`ID: ${task.id}`);
    console.log(`Status: ${getStatusDisplay(task.status)}`);
    console.log(`Command: ${task.command}`);
    console.log(`Created: ${task.createdAt.toLocaleString()}`);
    
    if (task.startedAt) {
      console.log(`Started: ${task.startedAt.toLocaleString()}`);
    }
    
    if (task.completedAt) {
      console.log(`Completed: ${task.completedAt.toLocaleString()}`);
      const duration = task.completedAt - task.startedAt;
      console.log(`Duration: ${Math.round(duration / 1000)}s`);
    }
    
    if (task.error) {
      console.log(chalk.red(`Error: ${task.error}`));
    }
    
    if (task.output && task.output.trim()) {
      console.log(`\nOutput:`);
      console.log(chalk.gray('─'.repeat(30)));
      console.log(task.output);
    }
  });

program
  .command('task-continue')
  .description('Create a Claude continue task for a failed task')
  .argument('[taskId]', 'Task ID to continue (defaults to last failed task)')
  .option('-m, --message <msg>', 'Additional instructions for continuation', 'continue')
  .action(async (taskId, options) => {
    try {
      // Check if daemon is running
      const daemonClient = new DaemonClient();
      if (!daemonClient.isDaemonRunning()) {
        console.error(chalk.red('✗ Daemon is not running'));
        console.log(chalk.yellow('💡 Start the daemon with: ani-code daemon --start'));
        process.exit(1);
      }
      
      // Connect to daemon via IPC
      const client = await getIPCClient();
      let targetTask;
      
      try {
        if (taskId) {
          // Get specific task
          targetTask = await client.getTask(taskId);
          if (!targetTask) {
            console.error(chalk.red(`Task not found: ${taskId}`));
            process.exit(1);
          }
        } else {
          // Get last failed task
          const history = await client.getTaskHistory(50); // Get more tasks to find failed one
          targetTask = history.find(t => t.status === 'error' && t.exitCode !== 0);
          
          if (!targetTask) {
            // No failed task found, just create a continue task with -c flag
            console.log(chalk.yellow('No failed tasks found, creating a continue task with default prompt'));
            
            // Generate task name
            const path = await import('path');
            const projectDir = path.basename(process.cwd());
            const now = new Date();
            const hour = now.getHours().toString().padStart(2, '0');
            const minute = now.getMinutes().toString().padStart(2, '0');
            const taskName = `${projectDir}-continue-${hour}${minute}`;
            
            // Create continue task with -c flag and default prompt
            const continueCommand = `-c ${options.message || 'continue'}`;
            const taskOptions = { cwd: process.cwd() };
            
            // Check if we're running as a child process with parent's chatId
            if (process.env.ANICODE_PARENT_CHAT_ID) {
              taskOptions.chatId = process.env.ANICODE_PARENT_CHAT_ID;
            }
            
            const newTask = await client.addTask(taskName, continueCommand, taskOptions);
            console.log(chalk.green(`✓ Continue task created: ${newTask.name} (${newTask.id})`));
            
            client.disconnect();
            return; // Exit early since we've handled the case
          }
        }
        
        // Check if this is a Claude task
        const isClaudeTask = targetTask.name.toLowerCase().includes('claude') || 
                            targetTask.command.includes('You are a') ||
                            targetTask.command.includes('IMPORTANT:') ||
                            targetTask.command.includes('Requirements:');
        
        if (!isClaudeTask) {
          console.error(chalk.red(`Task ${targetTask.id} does not appear to be a Claude task`));
          console.log(chalk.yellow('💡 This command is for continuing failed Claude tasks only'));
          process.exit(1);
        }
        
        // Create continue task
        const { basename } = await import('path');
        const projectDir = basename(targetTask.cwd || process.cwd());
        const now = new Date();
        const hour = now.getHours().toString().padStart(2, '0');
        const minute = now.getMinutes().toString().padStart(2, '0');
        const taskName = `${projectDir}-continue-${hour}${minute}`;
        
        // Build continue command
        const continueCommand = `Continue from the previous task that failed. The user says: "${options.message}"

Previous task context:
${targetTask.command}

Previous task output:
${targetTask.output || 'No output'}

Previous task error:
${targetTask.error || 'No error message'}

Continue working on the task, addressing any errors or issues that occurred.`;
        
        // Create the new task with same working directory
        const newTask = await client.addTask(taskName, continueCommand, {
          cwd: targetTask.cwd || process.cwd(),
          source: 'task-continue'
        });
        
        console.log(chalk.green(`✓ Continue task created: ${newTask.name} (${newTask.id})`));
        console.log(chalk.gray(`Continuing from failed task: ${targetTask.id}`));
        console.log(chalk.blue(`Working directory: ${targetTask.cwd || process.cwd()}`));
      } finally {
        client.disconnect();
      }
    } catch (error) {
      console.error(chalk.red(`Error: ${error.message}`));
      process.exit(1);
    }
  });

// ===============================
// SERVICE & DAEMON COMMANDS
// ===============================

program
  .command('daemon')
  .description('Manage the Ani Code daemon')
  .option('-s, --start', 'Start the daemon')
  .option('-S, --stop', 'Stop the daemon')
  .option('-r, --restart', 'Restart the daemon')
  .option('-f, --force', 'Force operation (--restart: ignore running tasks, --cleanup: use SIGKILL)')
  .option('-l, --reload', 'Reload daemon configuration')
  .option('-t, --status', 'Show daemon status')
  .option('-c, --cleanup', 'Clean up failed subprocess tasks from journalctl')
  .configureHelp({
    sortOptions: false,
    helpWidth: 80
  })
  .action(async (options) => {
    const daemonClient = new DaemonClient();
    
    if (options.start) {
      daemonClient.startDaemon().then(success => {
        if (success) {
          console.log(chalk.green('✓ Daemon started successfully'));
        } else {
          console.error(chalk.red('✗ Failed to start daemon'));
          console.log(chalk.yellow('💡 Tip: Install systemd service with "ani-code service install --user"'));
          process.exit(1);
        }
      });
    } else if (options.stop) {
      if (daemonClient.stopDaemon()) {
        console.log(chalk.green('✓ Daemon stop signal sent'));
      } else {
        console.error(chalk.red('✗ Failed to stop daemon'));
        process.exit(1);
      }
    } else if (options.restart) {
      // Check for running tasks before restarting (unless forced)
      if (!options.force) {
        try {
          const ipcClient = await getIPCClient();
          const status = await ipcClient.getStatus();
          
          // Check if there are any running tasks
          if (status.running && status.running.length > 0) {
            console.error(chalk.red('✗ Cannot restart daemon while tasks are running!'));
            console.log(chalk.yellow(`\n${status.running.length} task(s) currently running:`));
            status.running.forEach(task => {
              console.log(chalk.gray(`  - Task ${task.id}: ${task.command.substring(0, 50)}...`));
            });
            console.log(chalk.yellow('\nPlease wait for tasks to complete or cancel them first.'));
            console.log(chalk.cyan('Use "ani-code status" to check task status'));
            console.log(chalk.cyan('Use "ani-code cancel <id>" to cancel a task'));
            console.log(chalk.cyan('Use "ani-code daemon --restart --force" to force restart'));
            process.exit(1);
          }
          
          await ipcClient.disconnect();
        } catch (error) {
          // If we can't connect to daemon, it's probably not running, safe to proceed
          console.log(chalk.gray('Daemon not responding, proceeding with restart...'));
        }
      } else {
        console.log(chalk.yellow('⚠️  Force restarting daemon (running tasks will be terminated)...'));
      }
      
      if (daemonClient.stopDaemon()) {
        setTimeout(async () => {
          const success = await daemonClient.startDaemon();
          if (success) {
            console.log(chalk.green('✓ Daemon restarted successfully'));
          } else {
            console.error(chalk.red('✗ Failed to restart daemon'));
            process.exit(1);
          }
        }, 2000);
      } else {
        console.error(chalk.red('✗ Failed to restart daemon'));
        process.exit(1);
      }
    } else if (options.reload) {
      try {
        daemonClient.reloadDaemon();
        console.log(chalk.green('✓ Daemon reload signal sent'));
      } catch (error) {
        console.error(chalk.red(`✗ Failed to reload daemon: ${error.message}`));
        process.exit(1);
      }
    } else if (options.cleanup) {
      const signalType = options.force ? 'SIGKILL' : 'SIGTERM';
      console.log(chalk.blue(`🧹 Cleaning up failed subprocess tasks (${signalType})...`));
      try {
        const cleaned = daemonClient.cleanupFailedProcesses(options.force);
        if (cleaned > 0) {
          console.log(chalk.green(`✓ Cleaned up ${cleaned} failed subprocess(es)`));
        } else {
          console.log(chalk.yellow('No failed subprocesses found to clean up'));
        }
      } catch (error) {
        console.error(chalk.red(`✗ Failed to cleanup processes: ${error.message}`));
        process.exit(1);
      }
    } else if (options.status) {
      const fullStatus = daemonClient.getFullStatus();
      
      console.log(chalk.bold('\n🔧 Daemon Status'));
      console.log(chalk.gray('─'.repeat(50)));
      
      // Daemon status
      if (fullStatus.daemon.running) {
        console.log(`Daemon: ${chalk.green('✓ Running')} (PID: ${fullStatus.daemon.pid})`);
      } else {
        console.log(`Daemon: ${chalk.red('✗ Not running')}`);
      }
      
      // Service status
      if (fullStatus.service.installed) {
        const statusColor = fullStatus.service.running ? chalk.green : chalk.yellow;
        const statusText = fullStatus.service.running ? 'Active' : 'Inactive';
        console.log(`Service: ${statusColor('✓ Installed')} (${fullStatus.service.type}) - ${statusColor(statusText)}`);
      } else {
        console.log(`Service: ${chalk.red('✗ Not installed')}`);
        console.log(chalk.yellow('💡 Tip: Install service with "ani-code service install --user"'));
      }
    } else {
      console.log(chalk.yellow('Please specify an action: --start, --stop, --restart, --reload, or --status'));
    }
  });

const serviceCommand = program
  .command('service')
  .description('Manage systemd service for Ani Code daemon')
  .configureHelp({
    sortSubcommands: false,
    helpWidth: 80
  });

serviceCommand
  .command('install')
  .description('Install systemd service for Ani Code daemon')
  .option('-u, --user', 'Install as user service (no sudo required)')
  .option('-s, --system', 'Install as system service (requires sudo)')
  .action((options) => {
    const installer = new ServiceInstaller();
    
    if (options.user) {
      const result = installer.installUserService();
      if (result.success) {
        console.log(chalk.green(`✓ ${result.message}`));
      } else {
        console.error(chalk.red(`✗ ${result.message}`));
        process.exit(1);
      }
    } else if (options.system) {
      const result = installer.installService();
      if (result.success) {
        console.log(chalk.green(`✓ ${result.message}`));
      } else {
        console.error(chalk.red(`✗ ${result.message}`));
        process.exit(1);
      }
    } else {
      console.log(chalk.yellow('Please specify service type: --user or --system'));
      console.log(chalk.gray('  --user: Install as user service (recommended)'));
      console.log(chalk.gray('  --system: Install as system service (requires sudo)'));
    }
  });

serviceCommand
  .command('uninstall')
  .description('Uninstall systemd service for Ani Code daemon')
  .option('-u, --user', 'Uninstall user service')
  .option('-s, --system', 'Uninstall system service (requires sudo)')
  .action((options) => {
    const installer = new ServiceInstaller();
    
    if (options.user) {
      const result = installer.uninstallUserService();
      if (result.success) {
        console.log(chalk.green(`✓ ${result.message}`));
      } else {
        console.error(chalk.red(`✗ ${result.message}`));
        process.exit(1);
      }
    } else if (options.system) {
      const result = installer.uninstallService();
      if (result.success) {
        console.log(chalk.green(`✓ ${result.message}`));
      } else {
        console.error(chalk.red(`✗ ${result.message}`));
        process.exit(1);
      }
    } else {
      console.log(chalk.yellow('Please specify service type: --user or --system'));
    }
  });

serviceCommand
  .command('status')
  .description('Check systemd service status')
  .action(() => {
    const installer = new ServiceInstaller();
    const status = installer.getServiceStatus();
    
    console.log(chalk.bold('\n🔧 Service Status'));
    console.log(chalk.gray('─'.repeat(50)));
    
    if (status.type === 'system') {
      console.log(`Type: ${chalk.blue('System Service')}`);
      console.log(`Status: ${status.running ? chalk.green('Active') : chalk.red('Inactive')}`);
      console.log(chalk.gray('Use: systemctl start/stop/status ani-code'));
    } else if (status.type === 'user') {
      console.log(`Type: ${chalk.blue('User Service')}`);
      console.log(`Status: ${status.running ? chalk.green('Active') : chalk.red('Inactive')}`);
      console.log(chalk.gray('Use: systemctl --user start/stop/status ani-code'));
    } else {
      console.log(`Type: ${chalk.red('Not Installed')}`);
      console.log(chalk.gray('Use: ani-code service install --user to install'));
    }
  });

// ===============================
// DEBUG & DIAGNOSTICS
// ===============================

const debugCommand = program
  .command('debug')
  .description('Debug and diagnostic commands')
  .configureHelp({
    sortSubcommands: false,
    helpWidth: 80
  });

debugCommand
  .command('test-notification')
  .description('Send a test notification to Lark')
  .action(async () => {
    try {
      validateConfig();
      const { LarkNotifier } = await import('./lark-notifier.js');
      const larkNotifier = new LarkNotifier();
      
      // Get ani-code project's chat ID for test notifications
      const { ChatSettingsManager } = await import('./chat-settings.js');
      const chatSettings = new ChatSettingsManager();
      await chatSettings.load();
      const aniCodePath = '/root/workspace/ani-code';
      const chatId = chatSettings.getChatForWorkdir(aniCodePath);
      
      await larkNotifier.sendCustomMessage(
        'Ani Code Test',
        '🧪 **Test Notification**\n\nIf you see this message, your Lark integration is working correctly!',
        'green',
        chatId
      );
      console.log(chalk.green('✓ Test notification sent successfully'));
    } catch (error) {
      console.error(chalk.red(`Failed to send test notification: ${error.message}`));
      process.exit(1);
    }
  });

debugCommand
  .command('usage-report')
  .description('Generate and send daily usage report')
  .option('-f, --force', 'Force send report even if already sent today')
  .action(async (options) => {
    try {
      validateConfig();
      
      // Check if daemon is running
      const daemonClient = new DaemonClient();
      if (!daemonClient.isDaemonRunning()) {
        console.error(chalk.red('✗ Daemon is not running'));
        console.log(chalk.yellow('💡 Start the daemon with: ani-code daemon --start'));
        console.log(chalk.yellow('💡 Or install service with: ani-code service install --user'));
        process.exit(1);
      }

      const { UsageReporter } = await import('./usage-reporter.js');
      const { LarkNotifier } = await import('./lark-notifier.js');
      
      const usageReporter = new UsageReporter();
      const larkNotifier = new LarkNotifier();

      if (options.force) {
        usageReporter.resetDailyReport();
        console.log(chalk.yellow('⚠️  Force flag used - will send report even if already sent today'));
      }

      console.log(chalk.blue('📊 Generating daily usage report...'));
      
      const report = await usageReporter.generateDailyReport();
      
      if (report) {
        // Get ani-code project's chat ID for usage reports
        const { ChatSettingsManager } = await import('./chat-settings.js');
        const chatSettings = new ChatSettingsManager();
        await chatSettings.load();
        const aniCodePath = '/root/workspace/ani-code';
        const chatId = chatSettings.getChatForWorkdir(aniCodePath);
        
        await larkNotifier.sendCustomMessage(
          report.title,
          report.content,
          report.color,
          chatId
        );
        console.log(chalk.green('✓ Daily usage report sent successfully'));
      } else {
        console.log(chalk.yellow('⚠️  No usage data found or report already sent today'));
      }
    } catch (error) {
      console.error(chalk.red(`Failed to generate usage report: ${error.message}`));
      process.exit(1);
    }
  });

debugCommand
  .command('usage')
  .description('Check Claude API usage (sessions, models, Opus remaining)')
  .action(async () => {
    try {
      console.log(chalk.blue('Fetching Claude usage information...'));

      const { getClaudeUsage, formatUsageText } = await import('./claude-usage.js');
      const usage = await getClaudeUsage();
      const output = await formatUsageText(usage);

      console.log('\n' + output);

    } catch (error) {
      console.error(chalk.red(`Failed to get usage information: ${error.message}`));
      if (error.stderr) {
        console.error(chalk.gray(error.stderr.toString()));
      }
      process.exit(1);
    }
  });

// Add 'usage' as a top-level command for convenience (alias for debug usage)
program
  .command('usage')
  .description('Check Claude API usage (shortcut for debug usage)')
  .action(async () => {
    try {
      console.log(chalk.blue('Fetching Claude usage information...'));

      const { getClaudeUsage, formatUsageText } = await import('./claude-usage.js');
      const usage = await getClaudeUsage();
      const output = await formatUsageText(usage);

      console.log('\n' + output);

    } catch (error) {
      console.error(chalk.red(`Failed to get usage information: ${error.message}`));
      if (error.stderr) {
        console.error(chalk.gray(error.stderr.toString()));
      }
      process.exit(1);
    }
  });

// ===============================
// SETUP & CONFIGURATION
// ===============================

program
  .command('init-claude-settings')
  .alias('init')
  .description('Initialize Claude Code settings file with common permissions')
  .option('-p, --preset <type>', 'Permission preset: basic, full, secure (default: basic)', 'basic')
  .option('-g, --global', 'Create user-level settings (~/.claude/settings.json)')
  .option('-f, --force', 'Overwrite existing settings file')
  .action(async (options) => {
    const { writeFileSync, existsSync, mkdirSync } = await import('fs');
    const { join, dirname } = await import('path');
    const { homedir } = await import('os');
    
    // Determine file path based on global or project settings
    let settingsFile, settingsDir;
    if (options.global) {
      settingsDir = join(homedir(), '.claude');
      settingsFile = join(settingsDir, 'settings.json');
    } else {
      settingsDir = join(process.cwd(), '.claude');
      settingsFile = join(settingsDir, 'settings.json');
    }
    
    // Check if file already exists
    if (existsSync(settingsFile) && !options.force) {
      console.error(chalk.red('✗ Settings file already exists'));
      console.log(chalk.gray(`📄 File: ${settingsFile}`));
      console.log(chalk.yellow('💡 Use --force to overwrite existing file'));
      process.exit(1);
    }
    
    let settingsContent = getClaudeSettingsTemplate(options.preset);
    
    try {
      // Create directory if it doesn't exist
      if (!existsSync(settingsDir)) {
        mkdirSync(settingsDir, { recursive: true });
      }
      
      writeFileSync(settingsFile, settingsContent, 'utf8');
      const scopeText = options.global ? 'user-level' : 'project-level';
      console.log(chalk.green(`✓ Created ${scopeText} Claude settings with ${options.preset} preset`));
      console.log(chalk.gray(`📄 File created at: ${settingsFile}`));
      console.log(chalk.blue('💡 This configures Claude Code permissions to avoid frequent permission prompts'));
      
      if (!options.global) {
        console.log(chalk.yellow('💡 Add .claude/ to .gitignore if you don\'t want to commit settings'));
      }
    } catch (error) {
      console.error(chalk.red(`✗ Failed to create settings file: ${error.message}`));
      process.exit(1);
    }
  });

program
  .command('unlink')
  .description('Unlink the global CLI command')
  .action(() => {
    try {
      execSync('npm unlink', { stdio: 'inherit' });
      console.log(chalk.green('✓ Successfully unlinked ani-code command'));
      console.log(chalk.gray('The ani-code command is no longer available globally'));
    } catch (error) {
      console.error(chalk.red(`Failed to unlink: ${error.message}`));
      console.log(chalk.yellow('You may need to run this command manually: npm unlink'));
      process.exit(1);
    }
  });

// ===============================
// CHROME PLUGIN COMMANDS
// ===============================

program
  .command('plugin')
  .description('Manage Chrome plugin connection tokens')
  .argument('[action]', 'Action to perform: new-token, list, revoke')
  .argument('[tokenId]', 'Token ID for revoke action')
  .option('--debug', 'Show debug information including raw token')
  .action(async (action, tokenId, options) => {
    try {
      const pluginCmd = new PluginCommand();
      
      const args = [];
      if (action) args.push(action);
      if (tokenId) args.push(tokenId);
      if (options.debug) args.push('--debug');
      
      await pluginCmd.execute(args);
    } catch (error) {
      console.error(chalk.red(`Plugin command failed: ${error.message}`));
      process.exit(1);
    }
  });

program
  .command('build-annotate')
  .description('Add component metadata for Chrome plugin integration')
  .argument('[action]', 'Action to perform: annotate, clean, check')
  .option('--framework <name>', 'Framework to annotate (react, vue, angular)', 'react')
  .option('--src <dir>', 'Source directory', './src')
  .option('--verbose', 'Show detailed output')
  .action(async (action, options) => {
    try {
      const BuildAnnotator = require('./commands/build-annotate.js');
      const annotator = new BuildAnnotator({
        framework: options.framework,
        srcDir: options.src,
        verbose: options.verbose
      });
      
      const args = action ? [action] : ['help'];
      await annotator.execute(args);
    } catch (error) {
      console.error(chalk.red(`Build annotation failed: ${error.message}`));
      process.exit(1);
    }
  });

function getStatusDisplay(status) {
  switch (status) {
    case 'pending': return chalk.blue('⏳ Pending');
    case 'running': return chalk.yellow('🏃 Running');
    case 'completed': return chalk.green('✅ Completed');
    case 'failed': return chalk.red('❌ Failed');
    case 'cancelled': return chalk.magenta('🚫 Cancelled');
    default: return status;
  }
}

function getUserChoice(validChoices, prompt) {
  return new Promise((resolve) => {
    const rl = createInterface({
      input: process.stdin,
      output: process.stdout,
      terminal: true
    });

    const askChoice = () => {
      rl.question(prompt, (answer) => {
        const choice = answer.toLowerCase().trim();
        if (validChoices.includes(choice)) {
          rl.close();
          resolve(choice);
        } else {
          console.log(chalk.red(`Invalid choice. Please enter one of: ${validChoices.join(', ')}`));
          askChoice();
        }
      });
    };

    askChoice();
  });
}

async function editCommitMessageInVim(initialMessage) {
  try {
    const { writeFileSync, readFileSync, unlinkSync, existsSync } = await import('fs');
    const { join } = await import('path');
    const { tmpdir } = await import('os');
    
    // Create temporary file with initial commit message
    const tempFile = join(tmpdir(), `ani-code-commit-edit-${Date.now()}.txt`);
    const fileContent = `${initialMessage}

# Edit your commit message above. Lines starting with # are comments.
# Save and exit to use the message, or exit without saving to cancel.
`;
    
    writeFileSync(tempFile, fileContent, 'utf8');
    
    // Store the original content for comparison later
    const originalContent = fileContent;
    
    // Open vim to edit the file
    console.log(chalk.blue('Opening vim to edit commit message...'));
    
    try {
      const { spawn } = await import('child_process');
      
      await new Promise((resolve, reject) => {
        const vim = spawn('vim', [tempFile], {
          stdio: 'inherit',
          cwd: process.cwd()
        });
        
        vim.on('exit', (code) => {
          if (code === 0) {
            resolve();
          } else {
            reject(new Error(`Vim exited with code ${code}`));
          }
        });
        
        vim.on('error', (error) => {
          reject(error);
        });
      });
      
      // Check if file was modified (saved)
      if (!existsSync(tempFile)) {
        return null; // File was deleted, consider it cancelled
      }
      
      // Read the content to check if it was actually modified
      const currentContent = readFileSync(tempFile, 'utf8');
      
      // Compare content instead of just modification time for more reliable detection
      if (currentContent === fileContent) {
        // Content unchanged, user exited without saving
        unlinkSync(tempFile);
        return null;
      }
      
      // Use the already read content
      const editedContent = currentContent;
      
      // Extract the commit message (remove comments and empty lines at the end)
      const lines = editedContent.split('\n');
      const messageLines = [];
      
      for (const line of lines) {
        if (line.startsWith('#')) {
          break; // Stop at first comment line
        }
        messageLines.push(line);
      }
      
      // Clean up the message
      const editedMessage = messageLines.join('\n').trim();
      
      // Clean up temp file
      unlinkSync(tempFile);
      
      if (!editedMessage) {
        return null; // Empty message, consider it cancelled
      }
      
      return editedMessage;
      
    } catch (error) {
      // Clean up temp file on error
      if (existsSync(tempFile)) {
        unlinkSync(tempFile);
      }
      
      if (error.code === 'ENOENT') {
        console.error(chalk.red('✗ Vim not found. Please install vim or set EDITOR environment variable.'));
        return null;
      }
      
      throw error;
    }
    
  } catch (error) {
    console.error(chalk.red(`✗ Failed to open editor: ${error.message}`));
    return null;
  }
}

function getSingleLineInput() {
  return new Promise((resolve) => {
    const rl = createInterface({
      input: process.stdin,
      output: process.stdout,
      terminal: true
    });

    rl.question('', (answer) => {
      rl.close();
      resolve(answer);
    });
  });
}

function getParagraphInput() {
  return new Promise((resolve) => {
    const rl = createInterface({
      input: process.stdin,
      output: process.stdout,
      terminal: true
    });

    const lines = [];
    let emptyLineCount = 0;

    rl.on('line', (line) => {
      if (line.trim() === '') {
        emptyLineCount++;
        if (emptyLineCount >= 2) {
          rl.close();
          resolve(lines.join('\n'));
        }
      } else {
        emptyLineCount = 0;
      }
      lines.push(line);
    });

    rl.on('close', () => {
      resolve(lines.join('\n'));
    });
  });
}

function getClaudeSettingsTemplate(preset) {
  const templates = {
    basic: {
      permissions: {
        allow: [
          // File operations
          "Read(**/*)",
          "Edit(**/*)",
          "Write(**/*)",
          "MultiEdit(**/*)",

          // Explicit pd/goals/ permission — workaround for Claude Code glob
          // matching bugs where Edit(**/*) may not match pd/ subdirectory files.
          // Uses /pd prefix (project-root-relative) per Claude Code gitignore spec.
          "Edit(/pd/goals/**)",
          "Write(/pd/goals/**)",
          "Read(/pd/goals/**)",

          // Node.js package management
          "Bash(npm install:*)",
          "Bash(npm uninstall:*)",
          "Bash(npm update:*)",
          "Bash(npm run:*)",
          "Bash(npm test:*)",
          "Bash(npm start:*)",
          "Bash(npm build:*)",
          "Bash(npm init:*)",
          "Bash(yarn:*)",
          "Bash(pnpm:*)",
          "Bash(npx:*)",
          
          // File system operations
          "Bash(mkdir:*)",
          "Bash(touch:*)",
          "Bash(cp:*)",
          "Bash(mv:*)",
          "Bash(ls:*)",
          
          // Development commands
          "Bash(pip install:*)",
          "Bash(python -m pytest:*)",
          "Bash(cargo build:*)",
          "Bash(cargo test:*)",
          
          // Node.js syntax checking
          "Bash(node -c:*)",
          
          // Network utilities
          "Bash(wget:*)",
          "Bash(curl:*)",
          "Bash(ani-browser:*)",
          
          // Git operations
          "Bash(git status:*)",
          "Bash(git diff:*)",
          "Bash(git add:*)",
          "Bash(git commit:*)",
          "Bash(git log:*)",
          "Bash(git branch:*)",
          "Bash(git checkout:*)",
          "Bash(git pull:*)",
          "Bash(git push:*)",
          
          // Code analysis
          "Grep(*)",
          "Glob(*)",
          "LS(*)",
          
          // Linting and formatting
          "Bash(eslint:*)",
          "Bash(prettier:*)",
          "Bash(tslint:*)",
          "Bash(pylint:*)",
          
          // Claude Code tools
          "TodoWrite(*)",
          "Task(*)",
          "ExitPlanMode(*)",
          "NotebookEdit(**/*)",
          "WebFetch",
          "WebSearch",
          "BashOutput(*)",
          "KillBash(*)"
        ],
        deny: [
          "Read(.env*)",
          "Read(*.key)",
          "Read(*.pem)",
          "Read(**/secrets/*)",
          "Bash(rm -rf /*)",
          "Bash(rm -rf ~/*)",
          "Bash(sudo:*)",
          "Bash(chmod 777:*)"
        ]
      }
    },
    
    full: {
      permissions: {
        allow: [
          // All file operations
          "Read(**/*)",
          "Read(/tmp/**/*)",
          "Edit(**/*)",
          "Edit(/tmp/**/*)",
          "Write(**/*)",
          "Write(/tmp/**/*)",
          "MultiEdit(**/*)",
          "MultiEdit(/tmp/**/*)",

          // Explicit pd/goals/ permission — workaround for Claude Code glob
          // matching bugs where Edit(**/*) may not match pd/ subdirectory files.
          // Uses /pd prefix (project-root-relative) per Claude Code gitignore spec.
          "Edit(/pd/goals/**)",
          "Write(/pd/goals/**)",
          "Read(/pd/goals/**)",

          // All development commands
          "Bash(npm:*)",
          "Bash(yarn:*)",
          "Bash(pnpm:*)",
          "Bash(npx:*)",
          "Bash(pip:*)",
          "Bash(poetry:*)",
          "Bash(cargo:*)",
          "Bash(go:*)",
          "Bash(mvn:*)",
          "Bash(gradle:*)",
          "Bash(sqlite3:*)",
          
          // File system operations - Enhanced for directory creation
          "Bash(mkdir:*)",
          "Bash(mkdir -p:*)",
          "Bash(touch:*)",
          "Bash(cp:*)",
          "Bash(mv:*)",
          "Bash(ls:*)",
          "Bash(cat:*)",
          "Bash(find:*)",
          
          // Full git workflow
          "Bash(git:*)",
          
          // Docker and containers
          "Bash(docker:*)",
          "Bash(docker-compose:*)",

          // Process managers
          "Bash(pm2:*)",

          // Testing and CI
          "Bash(pytest:*)",
          "Bash(jest:*)",
          "Bash(npm test:*)",
          "Bash(cargo test:*)",
          "Bash(go test:*)",
          "Bash(make:*)",
          "Bash(npm run:*)",
          
          // Node.js syntax checking
          "Bash(node -c:*)",
          
          // Network utilities
          "Bash(wget:*)",
          "Bash(curl:*)",
          "Bash(ani-browser:*)",
          
          // System monitoring and logs
          "Bash(journalctl:*)",
          "Bash(systemctl status:*)",
          
          // Code analysis and tools
          "Grep(*)",
          "Glob(*)",
          "LS(*)",
          
          // Claude Code tools
          "TodoWrite(*)",
          "Task(*)",
          "ExitPlanMode(*)",
          "NotebookEdit(**/*)",
          "WebFetch",
          "WebSearch",
          "BashOutput(*)",
          "KillBash(*)"
        ],
        deny: [
          "Read(.env*)",
          "Read(*.key)",
          "Read(*.pem)",
          "Read(*/secrets/*)",
          "Bash(rm -rf /*)",
          "Bash(rm -rf ~/*)",
          "Bash(sudo:*)",
          "Bash(chmod 777:*)"
        ]
      }
    },
    
    secure: {
      permissions: {
        allow: [
          // Read-only operations
          "Read(**/*.{js,ts,jsx,tsx,py,java,cpp,c,h,hpp,cs,php,rb,go,rs,kt,scala})",
          "Read(**/*.{json,yaml,yml,toml,xml,md,txt})",
          
          // Safe analysis
          "Grep(*)",
          "Glob(*)",
          "LS(*)",
          
          // Limited editing of source files only
          "Edit(**/*.{js,ts,jsx,tsx,py,java,cpp,c,h,hpp,cs,php,rb,go,rs,kt,scala})",
          
          // Read-only git operations
          "Bash(git status:*)",
          "Bash(git diff:*)",
          "Bash(git log:*)",
          
          // Safe linting (no fixes)
          "Bash(eslint --dry-run:*)",
          "Bash(eslint --check:*)",
          "Bash(pylint --check:*)",
          
          // Node.js syntax checking
          "Bash(node -c:*)"
        ],
        deny: [
          "Read(.env*)",
          "Read(*.key)",
          "Read(*.pem)",
          "Read(*/secrets/*)",
          "Write(*)",
          "Bash(npm install:*)",
          "Bash(pip install:*)",
          "Bash(git add:*)",
          "Bash(git commit:*)",
          "Bash(git push:*)",
          "Bash(*)",
          "WebFetch(*)"
        ]
      }
    }
  };

  if (!templates[preset]) {
    throw new Error(`Unknown preset: ${preset}. Available presets: basic, full, secure`);
  }

  return JSON.stringify(templates[preset], null, 2);
}

// Override default help behavior to use structured help
program.on('--help', () => {
  // This will be handled by the custom help command we added
});

// Add workspace command
program
  .command('diagnosis')
  .alias('diagnose')
  .description('Run system diagnosis and show configuration status')
  .option('-v, --verbose', 'Show detailed information')
  .option('-j, --json', 'Output in JSON format')
  .action(async (options) => {
    const diagnosis = {
      timestamp: new Date().toISOString(),
      system: {},
      daemon: {},
      version: {},
      configuration: {},
      endpoints: {},
      services: {},
      errors: []
    };

    // 1. System Information
    try {
      const os = await import('os');
      diagnosis.system = {
        platform: os.platform(),
        arch: os.arch(),
        nodeVersion: process.version,
        hostname: os.hostname(),
        user: os.userInfo().username
      };
    } catch (error) {
      diagnosis.errors.push(`System info: ${error.message}`);
    }

    // 2. Daemon Status
    const daemonClient = new DaemonClient();
    diagnosis.daemon.running = daemonClient.isDaemonRunning();
    diagnosis.daemon.pid = daemonClient.getDaemonPid();

    const serviceStatus = daemonClient.isServiceRunning();
    diagnosis.services = {
      installed: daemonClient.isServiceInstalled(),
      running: serviceStatus
    };

    // 3. Version Compatibility
    if (diagnosis.daemon.running) {
      try {
        const versionCheck = await daemonClient.checkVersionCompatibility();
        diagnosis.version = {
          cliVersion: versionCheck.cliVersion,
          daemonVersion: versionCheck.daemonVersion,
          compatible: versionCheck.compatible,
          warning: versionCheck.warning,
          message: versionCheck.message
        };
      } catch (error) {
        diagnosis.errors.push(`Version check: ${error.message}`);
      }

      // 4. Test Endpoints
      const fetch = (await import('node-fetch')).default;
      const endpoints = [
        { name: 'Health', url: 'http://127.0.0.1:6501/health' },
        { name: 'Version', url: 'http://127.0.0.1:6501/version' },
        { name: 'WebSocket', url: 'ws://127.0.0.1:6502', type: 'ws' }
      ];

      for (const endpoint of endpoints) {
        try {
          if (endpoint.type === 'ws') {
            diagnosis.endpoints[endpoint.name] = {
              url: endpoint.url,
              status: 'available',
              port: 6502
            };
          } else {
            const response = await fetch(endpoint.url, { timeout: 2000 });
            diagnosis.endpoints[endpoint.name] = {
              url: endpoint.url,
              status: response.ok ? 'ok' : `error (${response.status})`,
              responseTime: response.headers.get('x-response-time') || 'N/A'
            };

            if (endpoint.name === 'Version') {
              if (response.ok) {
                const data = await response.json();
                diagnosis.endpoints[endpoint.name].data = data.data;
              } else if (response.status === 404) {
                diagnosis.errors.push('Version endpoint not found - daemon needs restart to enable version checking');
              }
            }
          }
        } catch (error) {
          diagnosis.endpoints[endpoint.name] = {
            url: endpoint.url,
            status: 'failed',
            error: error.message
          };
        }
      }
    }

    // 5. Configuration Validation
    try {
      validateConfig();
      diagnosis.configuration = {
        valid: true,
        warnings: [],
        errors: []
      };
    } catch (error) {
      diagnosis.configuration = {
        valid: false,
        warnings: [],
        errors: [error.message]
      };
    }

    // 6. File System Checks
    try {
      const fs = await import('fs/promises');
      const path = await import('path');
      const { fileURLToPath } = await import('url');

      const __filename = fileURLToPath(import.meta.url);
      const __dirname = path.dirname(__filename);
      const baseDir = path.join(__dirname, '..');

      const importantFiles = [
        { name: 'package.json', path: path.join(baseDir, 'package.json') },
        { name: '.env', path: path.join(baseDir, '.env') },
        { name: 'CLAUDE.md', path: path.join(baseDir, 'CLAUDE.md') },
        { name: 'daemon.pid', path: path.join(baseDir, '.ani-code-daemon.pid') }
      ];

      diagnosis.files = {};
      for (const file of importantFiles) {
        try {
          const stat = await fs.stat(file.path);
          diagnosis.files[file.name] = {
            exists: true,
            size: stat.size,
            modified: stat.mtime.toISOString()
          };
        } catch {
          diagnosis.files[file.name] = { exists: false };
        }
      }
    } catch (error) {
      diagnosis.errors.push(`File checks: ${error.message}`);
    }

    // Output Results
    if (options.json) {
      console.log(JSON.stringify(diagnosis, null, 2));
    } else {
      console.log(chalk.bold('\n🔍 Ani-Code Diagnosis\n'));

      // Always show CLI version first
      const fs = await import('fs');
      const path = await import('path');
      const { fileURLToPath } = await import('url');
      const __filename = fileURLToPath(import.meta.url);
      const __dirname = path.dirname(__filename);
      const packageJson = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'package.json'), 'utf8'));
      console.log(`CLI Version: ${chalk.cyan(packageJson.version)}`);

      // Daemon & Service
      if (diagnosis.daemon.running) {
        console.log(chalk.green(`✓ Daemon running (PID: ${diagnosis.daemon.pid})`));

        // Show daemon version if available
        if (diagnosis.version.daemonVersion) {
          const versionStatus = !diagnosis.version.compatible ? chalk.red('✗') :
                               diagnosis.version.warning ? chalk.yellow('⚠') :
                               chalk.green('✓');
          console.log(`${versionStatus} Daemon Version: ${diagnosis.version.daemonVersion}`);
          if (diagnosis.version.message && (!diagnosis.version.compatible || diagnosis.version.warning)) {
            console.log(chalk.gray(`  ${diagnosis.version.message}`));
          }
        }
      } else {
        console.log(chalk.red('✗ Daemon not running'));
      }

      if (diagnosis.services.installed.installed) {
        const svcStatus = diagnosis.services.running.running ? chalk.green('active') : chalk.yellow(diagnosis.services.running.status);
        console.log(`  Service: ${diagnosis.services.installed.type} (${svcStatus})`);
      }

      // Endpoints
      console.log(chalk.bold('\nEndpoints:'));
      for (const [name, info] of Object.entries(diagnosis.endpoints)) {
        const icon = (info.status === 'ok' || info.status === 'available') ? chalk.green('✓') : chalk.red('✗');
        const port = name === 'Health' ? '6501' : name === 'Version' ? '6501' : '6502';
        console.log(`${icon} ${name.padEnd(10)} :${port} (${info.status})`);
      }

      // Configuration
      const configIcon = diagnosis.configuration.valid ? chalk.green('✓') : chalk.red('✗');
      console.log(`\n${configIcon} Configuration: ${diagnosis.configuration.valid ? 'Valid' : 'Invalid'}`);
      if (diagnosis.configuration.errors?.length > 0) {
        diagnosis.configuration.errors.forEach(e => console.log(chalk.red(`  ${e}`)));
      }

      // Show errors if any
      if (diagnosis.errors.length > 0) {
        console.log(chalk.red.bold('\nIssues:'));
        diagnosis.errors.forEach(error => {
          console.log(chalk.red(`• ${error}`));
        });
      }

      // Quick status
      const hasIssues = !diagnosis.daemon.running ||
                       !diagnosis.version.compatible ||
                       !diagnosis.configuration.valid ||
                       diagnosis.errors.length > 0;

      if (!hasIssues) {
        console.log(chalk.green.bold('\n✓ System healthy'));
      } else {
        console.log(chalk.yellow.bold('\n⚠ Issues detected'));
        if (!diagnosis.daemon.running) {
          console.log(chalk.gray('  Run: ani-code daemon --start'));
        }
        if (diagnosis.errors.some(e => e.includes('Version endpoint not found'))) {
          console.log(chalk.gray('  Restart daemon for version checking'));
        }
      }
    }
  });

program.addCommand(workspaceCommand);
program.addCommand(providerCommand);
program.addCommand(providersCommand);
program.addCommand(createGoalsCommand());
program.addCommand(gatewayCommand);
program.addCommand(createHealthcheckCommand());
program.addCommand(createProjectsCommand());
program.addCommand(hintCommand);
program.addCommand(chatUICommand);

// If no command provided, show structured help
if (process.argv.length === 2) {
  showStructuredHelp();
} else {
  program.parse();
}

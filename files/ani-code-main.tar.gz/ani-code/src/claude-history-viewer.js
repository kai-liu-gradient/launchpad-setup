import fs from 'fs/promises';
import path from 'path';
import { logger } from './logger.js';
import os from 'os';

/**
 * Claude Code History Viewer
 * Parses JSONL conversation logs and generates professional HTML output
 */

export class ClaudeHistoryViewer {
  constructor() {
    this.homeDir = os.homedir();
    this.projectsDir = path.join(this.homeDir, '.claude', 'projects');
  }

  /**
   * Find the latest JSONL file for a given project path
   * @param {string} projectPath - The project directory path (e.g., /root/workspace/ani-code)
   * @returns {Promise<string|null>} Path to the latest JSONL file
   */
  async findLatestSession(projectPath) {
    try {
      // Encode project path (slashes become hyphens, leading slash becomes hyphen)
      const encodedPath = projectPath.replace(/\//g, '-');
      const sessionDir = path.join(this.projectsDir, encodedPath);

      logger.debug(`Looking for sessions in: ${sessionDir}`);

      // Check if directory exists
      try {
        await fs.access(sessionDir);
      } catch {
        logger.warn(`Session directory not found: ${sessionDir}`);
        return null;
      }

      // Get all JSONL files, excluding agent sub-sessions (agent-*.jsonl)
      const files = await fs.readdir(sessionDir);
      const jsonlFiles = files.filter(f => f.endsWith('.jsonl') && !f.startsWith('agent-'));

      if (jsonlFiles.length === 0) {
        logger.warn(`No JSONL files found in: ${sessionDir}`);
        return null;
      }

      // Get file stats and sort by modification time
      const fileStatsRaw = await Promise.all(
        jsonlFiles.map(async (file) => {
          const filePath = path.join(sessionDir, file);
          const stats = await fs.stat(filePath);
          return { path: filePath, mtime: stats.mtime, size: stats.size };
        })
      );

      // Filter out empty files (0 bytes) and sort by modification time (newest first)
      const fileStats = fileStatsRaw.filter(f => f.size > 0);

      if (fileStats.length === 0) {
        logger.warn(`No non-empty JSONL files found in: ${sessionDir}`);
        return null;
      }

      fileStats.sort((a, b) => b.mtime - a.mtime);

      return fileStats[0].path;
    } catch (error) {
      logger.error(`Error finding latest session: ${error.message}`);
      return null;
    }
  }

  /**
   * Find a session file by task start time range
   * This helps identify the correct session when multiple tasks run in the same workspace
   * @param {string} projectPath - The project directory path
   * @param {Date} taskStartTime - When the task started
   * @param {number} toleranceMs - Tolerance in milliseconds for matching (default 30 seconds)
   * @returns {Promise<string|null>} Path to the matching session file
   */
  async findSessionByTaskStartTime(projectPath, taskStartTime, toleranceMs = 30000) {
    try {
      const encodedPath = projectPath.replace(/\//g, '-');
      const sessionDir = path.join(this.projectsDir, encodedPath);

      try {
        await fs.access(sessionDir);
      } catch {
        return null;
      }

      // Get all JSONL files, excluding agent sub-sessions (agent-*.jsonl)
      const files = await fs.readdir(sessionDir);
      const jsonlFiles = files.filter(f => f.endsWith('.jsonl') && !f.startsWith('agent-'));

      if (jsonlFiles.length === 0) {
        return null;
      }

      const taskStartMs = new Date(taskStartTime).getTime();

      // Get file stats with both birthtime and first message timestamp
      const fileStatsRaw = await Promise.all(
        jsonlFiles.map(async (file) => {
          const filePath = path.join(sessionDir, file);
          const stats = await fs.stat(filePath);

          // Skip empty files (0 bytes) - these are failed/incomplete sessions
          if (stats.size === 0) {
            return null;
          }

          // Try to get first message timestamp from the file for more accurate matching
          // Only read a small chunk (first 1KB) instead of the entire file
          let firstMessageTime = null;
          try {
            const fileHandle = await fs.open(filePath, 'r');
            try {
              const buf = Buffer.alloc(1024);
              const { bytesRead } = await fileHandle.read(buf, 0, 1024, 0);
              if (bytesRead > 0) {
                const chunk = buf.toString('utf-8', 0, bytesRead);
                const newlineIdx = chunk.indexOf('\n');
                const firstLine = newlineIdx >= 0 ? chunk.substring(0, newlineIdx) : chunk;
                if (firstLine) {
                  const entry = JSON.parse(firstLine);
                  if (entry.timestamp) {
                    firstMessageTime = new Date(entry.timestamp).getTime();
                  }
                }
              }
            } finally {
              await fileHandle.close();
            }
          } catch {
            // Fall back to birthtime if can't parse first message
          }

          // Use first message time if available, otherwise use birthtime
          const sessionStartTime = firstMessageTime || stats.birthtime.getTime();

          return {
            path: filePath,
            birthtime: stats.birthtime,
            mtime: stats.mtime,
            size: stats.size,
            sessionStartTime,
            timeDiff: Math.abs(sessionStartTime - taskStartMs)
          };
        })
      );

      // Filter out null entries (empty files)
      const fileStats = fileStatsRaw.filter(f => f !== null);

      // For concurrent tasks, we need to find the session that belongs to THIS task
      // Strategy 1: Find sessions created AFTER task start (new tasks)
      // Strategy 2: Find sessions modified AFTER task start (continue tasks - session was created earlier)

      const clockSkewTolerance = 5000; // 5 seconds for clock skew

      // Find sessions created after (or very close to) task start time (new tasks)
      const sessionsCreatedAfterTaskStart = fileStats.filter(f =>
        f.sessionStartTime >= taskStartMs - clockSkewTolerance
      );

      if (sessionsCreatedAfterTaskStart.length > 0) {
        // Among sessions created around/after task start, find the one closest to task start time
        const closestSession = sessionsCreatedAfterTaskStart.reduce((best, current) => {
          const bestDiff = Math.abs(best.sessionStartTime - taskStartMs);
          const currentDiff = Math.abs(current.sessionStartTime - taskStartMs);
          return currentDiff < bestDiff ? current : best;
        });

        logger.debug(`[SessionMatch] Found new session for task started at ${new Date(taskStartMs).toISOString()}: ${closestSession.path} (session started: ${new Date(closestSession.sessionStartTime).toISOString()}, diff: ${closestSession.sessionStartTime - taskStartMs}ms)`);
        return closestSession.path;
      }

      // Strategy 2: For continue tasks - find sessions MODIFIED after task start
      // (session was created earlier but is being actively used now)
      const sessionsModifiedAfterTaskStart = fileStats.filter(f =>
        f.mtime.getTime() >= taskStartMs - clockSkewTolerance
      );

      if (sessionsModifiedAfterTaskStart.length > 0) {
        // Among sessions modified after task start, prefer the most recently modified
        // (most likely to be the active session for this continue task)
        sessionsModifiedAfterTaskStart.sort((a, b) => b.mtime.getTime() - a.mtime.getTime());
        const activeSession = sessionsModifiedAfterTaskStart[0];

        logger.debug(`[SessionMatch] Found continued session for task started at ${new Date(taskStartMs).toISOString()}: ${activeSession.path} (modified: ${activeSession.mtime.toISOString()})`);
        return activeSession.path;
      }

      // Fallback: use the one with smallest time difference to task start
      const matchingSessions = fileStats.filter(f => f.timeDiff <= toleranceMs);
      if (matchingSessions.length > 0) {
        matchingSessions.sort((a, b) => a.timeDiff - b.timeDiff);
        logger.debug(`[SessionMatch] Fallback - found session within tolerance: ${matchingSessions[0].path} (diff: ${matchingSessions[0].timeDiff}ms)`);
        return matchingSessions[0].path;
      }

      logger.debug(`[SessionMatch] No matching session found for task started at ${new Date(taskStartMs).toISOString()}`);
      return null;
    } catch (error) {
      logger.error(`Error finding session by time range: ${error.message}`);
      return null;
    }
  }

  /**
   * Parse a JSONL file and extract conversation messages
   * @param {string} filePath - Path to the JSONL file
   * @returns {Promise<Array>} Array of parsed messages
   */
  async parseSession(filePath) {
    try {
      const content = await fs.readFile(filePath, 'utf-8');
      const lines = content.trim().split('\n').filter(line => line.trim());

      // Debug logging for file parsing
      logger.debug(`[PARSE-SESSION] File: ${filePath}`);
      logger.debug(`[PARSE-SESSION] Content length: ${content.length} bytes, Lines: ${lines.length}`);

      const messages = [];

      for (const line of lines) {
        try {
          const entry = JSON.parse(line);

          // Extract relevant message data
          if (entry.type === 'user' && entry.message) {
            // Handle both string and array content formats
            let userContent = entry.message.content;
            if (Array.isArray(userContent)) {
              // Extract text from content array
              userContent = userContent
                .filter(item => item.type === 'text')
                .map(item => item.text)
                .join('\n');
            } else if (typeof userContent !== 'string') {
              userContent = JSON.stringify(userContent);
            }

            messages.push({
              type: 'user',
              content: userContent,
              timestamp: entry.timestamp,
              uuid: entry.uuid
            });
          } else if (entry.type === 'assistant' && entry.message) {
            const msg = entry.message;

            // Extract text content and tool uses
            const textContent = [];
            const toolUses = [];
            const thinking = [];

            if (Array.isArray(msg.content)) {
              for (const item of msg.content) {
                if (item.type === 'text') {
                  textContent.push(item.text);
                } else if (item.type === 'tool_use') {
                  toolUses.push({
                    id: item.id,
                    name: item.name,
                    input: item.input
                  });
                } else if (item.type === 'thinking') {
                  thinking.push(item.thinking);
                }
              }
            }

            messages.push({
              type: 'assistant',
              textContent: textContent.join('\n'),
              toolUses,
              thinking: thinking.join('\n'),
              timestamp: entry.timestamp,
              uuid: entry.uuid,
              usage: msg.usage || null
            });
          } else if (entry.type === 'user' && entry.toolUseResult) {
            // Tool result
            messages.push({
              type: 'tool_result',
              content: entry.toolUseResult,
              timestamp: entry.timestamp,
              uuid: entry.uuid
            });
          }
        } catch (parseError) {
          logger.debug(`Failed to parse line: ${parseError.message}`);
        }
      }

      // Debug summary
      const assistantMsgs = messages.filter(m => m.type === 'assistant');
      const assistantWithText = assistantMsgs.filter(m => m.textContent && m.textContent.length > 0);
      logger.debug(`[PARSE-SESSION] Total messages: ${messages.length}, Assistant: ${assistantMsgs.length}, Assistant with text: ${assistantWithText.length}`);
      if (assistantWithText.length > 0) {
        const last = assistantWithText[assistantWithText.length - 1];
        logger.debug(`[PARSE-SESSION] Last assistant text preview: ${last.textContent.substring(0, 80).replace(/\n/g, '\\n')}...`);
      }

      return messages;
    } catch (error) {
      logger.error(`Error parsing session: ${error.message}`);
      throw error;
    }
  }

  /**
   * Generate professional HTML from conversation messages
   * @param {Array} messages - Array of parsed messages
   * @param {string} sessionPath - Path to the session file
   * @param {Object} options - Generation options
   * @param {boolean} options.includeMetadataFooter - Whether to include metadata footer in messages (default: false)
   * @returns {string} HTML content
   */
  generateHTML(messages, sessionPath, options = {}) {
    const { includeMetadataFooter = false } = options;
    const sessionFile = path.basename(sessionPath);
    const sessionDate = messages.length > 0 ? new Date(messages[0].timestamp) : new Date();

    // Extract project name from session path
    const projectName = sessionPath.includes('-root-workspace-')
      ? sessionPath.split('-root-workspace-')[1]?.split('/')[0]?.replace(/-/g, '/') || 'unknown'
      : 'unknown';

    // Get hostname
    const hostname = process.env.HOSTNAME || os.hostname();

    // Group USER messages only for navigation (more meaningful bookmarks)
    const userMessages = [];
    messages.forEach((msg, index) => {
      if (msg.type === 'user' && msg.content && msg.content.trim()) {
        const msgDate = new Date(msg.timestamp);
        const timeStr = `${msgDate.getHours().toString().padStart(2, '0')}:${msgDate.getMinutes().toString().padStart(2, '0')}`;
        // Get first 50 chars of user message for preview
        let preview = msg.content.trim().substring(0, 50);
        if (msg.content.length > 50) preview += '...';
        userMessages.push({
          index,
          timeStr,
          preview,
          fullContent: msg.content.trim(),
          anchorId: `msg-${index}`,
          timestamp: msg.timestamp
        });
      }
    });

    // Generate navigation with expandable user input
    const navLinks = userMessages.map((um, idx) => {
      return `
        <details class="nav-item">
          <summary>
            <span class="nav-link" data-timestamp="${um.timestamp}" data-target="${um.anchorId}" onclick="jumpToMessage('${um.anchorId}'); return false;">${um.timeStr}</span>
            <span class="nav-preview">${this.escapeHTML(um.preview)}</span>
          </summary>
          <pre class="nav-content">${this.escapeHTML(um.fullContent)}</pre>
        </details>`;
    }).join('');

    // Collect file operations for navigation
    const fileOperations = {};
    messages.forEach((msg, index) => {
      if (msg.toolUses && msg.toolUses.length > 0) {
        msg.toolUses.forEach(tool => {
          if ((tool.name === 'Write' || tool.name === 'Edit' || tool.name === 'Read') && tool.input.file_path) {
            const filePath = tool.input.file_path;
            if (!fileOperations[filePath]) {
              fileOperations[filePath] = [];
            }
            const msgDate = new Date(msg.timestamp);
            const timeStr = `${msgDate.getHours().toString().padStart(2, '0')}:${msgDate.getMinutes().toString().padStart(2, '0')}`;
            fileOperations[filePath].push({
              type: tool.name,
              timestamp: msg.timestamp,
              timeStr,
              anchorId: `msg-${index}`
            });
          }
        });
      }
    });

    // Build file operations navigation
    let fileNavHTML = '';
    const fileCount = Object.keys(fileOperations).length;
    if (fileCount > 0) {
      const fileNavItems = Object.entries(fileOperations)
        .sort((a, b) => a[0].localeCompare(b[0]))
        .map(([filePath, ops]) => {
          const fileName = filePath.split('/').pop();
          const opTypes = [...new Set(ops.map(op => op.type))];
          const opSummary = opTypes.map(type => {
            const count = ops.filter(op => op.type === type).length;
            const icon = type === 'Write' ? '📝' : type === 'Edit' ? '✏️' : '👁️';
            return `${icon} ${count}`;
          }).join(' ');

          const opLinks = ops.map(op => {
            const icon = op.type === 'Write' ? '📝' : op.type === 'Edit' ? '✏️' : '👁️';
            return `<span class="file-op-link" onclick="jumpToMessage('${op.anchorId}'); return false;">${icon} ${op.timeStr}</span>`;
          }).join(' ');

          return `
            <details class="file-nav-item">
              <summary>
                <span class="file-nav-name">${this.escapeHTML(fileName)}</span>
                <span class="file-nav-ops">${opSummary}</span>
              </summary>
              <div class="file-nav-details">
                <div class="file-nav-path">${this.escapeHTML(filePath)}</div>
                <div class="file-nav-links">${opLinks}</div>
              </div>
            </details>`;
        }).join('');

      fileNavHTML = `
        <details class="nav-section file-nav-section">
          <summary>📁 File Operations (${fileCount} files)</summary>
          <div class="file-nav-list">${fileNavItems}</div>
        </details>`;
    }

    // Build HTML with improved styling
    const messagesHTML = messages.map((msg, index) => {
      const timestamp = new Date(msg.timestamp).toLocaleTimeString();
      const anchorId = `msg-${index}`;

      if (msg.type === 'user') {
        // Skip empty user messages
        const contentStr = typeof msg.content === 'string' ? msg.content : JSON.stringify(msg.content);
        if (!contentStr || contentStr.trim().length === 0) {
          return '';
        }
        return `
        <div id="${anchorId}" class="message user-message">
          <div class="header">USER <span class="timestamp" data-timestamp="${msg.timestamp}">${timestamp}</span></div>
          <pre class="content">${this.escapeHTML(contentStr)}</pre>
        </div>`;
      } else if (msg.type === 'assistant') {
        let content = '';

        // Add thinking if present
        if (msg.thinking && msg.thinking.length > 0) {
          content += `
          <details class="section">
            <summary>--- Extended Thinking ---</summary>
            <pre>${this.escapeHTML(msg.thinking)}</pre>
          </details>`;
        }

        // Add text content
        if (msg.textContent && msg.textContent.length > 0) {
          content += `<pre class="text">${this.escapeHTML(msg.textContent)}</pre>`;
        }

        // Add tool uses with enhanced rendering
        if (msg.toolUses && msg.toolUses.length > 0) {
          content += msg.toolUses.map(tool => {
            // Enhanced rendering for file operations
            if (tool.name === 'Write' && tool.input.file_path) {
              return this.renderWriteTool(tool);
            } else if (tool.name === 'Edit' && tool.input.file_path) {
              return this.renderEditTool(tool);
            } else if (tool.name === 'Read' && tool.input.file_path) {
              return this.renderReadTool(tool);
            }

            // Default rendering for other tools
            const inputStr = JSON.stringify(tool.input, null, 2);
            const lineCount = inputStr.split('\n').length;

            // Auto-expand short commands (2 lines or less) or common read-only tools
            const shouldAutoExpand = lineCount <= 2 ||
              ['Grep', 'Glob', 'Read', 'Bash'].includes(tool.name);

            // Determine tool category for color coding
            let toolClass = 'tool-other';
            if (['Read', 'Grep', 'Glob'].includes(tool.name)) {
              toolClass = 'tool-read';
            } else if (['Write', 'Edit'].includes(tool.name)) {
              toolClass = 'tool-write';
            } else if (['Bash'].includes(tool.name)) {
              toolClass = 'tool-bash';
            } else if (['Task'].includes(tool.name)) {
              toolClass = 'tool-task';
            }

            if (shouldAutoExpand) {
              return `
              <details class="section ${toolClass}" open>
                <summary>--- Tool: ${this.escapeHTML(tool.name)} ---</summary>
                <pre>${this.escapeHTML(inputStr)}</pre>
              </details>`;
            } else {
              return `
              <details class="section ${toolClass}">
                <summary>--- Tool: ${this.escapeHTML(tool.name)} ---</summary>
                <pre>${this.escapeHTML(inputStr)}</pre>
              </details>`;
            }
          }).join('');
        }

        // Add rich metadata footer (only for top-level assistant messages)
        let metadataFooter = '';
        if (includeMetadataFooter && msg.usage) {
          const input = msg.usage.input_tokens || 0;
          const output = msg.usage.output_tokens || 0;
          const cacheRead = msg.usage.cache_read_input_tokens || 0;
          const cacheCreate = msg.usage.cache_creation_input_tokens || 0;

          // Calculate approximate cost (rough estimates for sonnet-4.5)
          const inputCost = (input * 3 / 1000000);  // $3 per 1M tokens
          const outputCost = (output * 15 / 1000000); // $15 per 1M tokens
          const cacheCost = (cacheRead * 0.3 / 1000000); // $0.30 per 1M tokens
          const totalCost = inputCost + outputCost + cacheCost;

          // Format cached tokens
          const cachedTotal = cacheRead + cacheCreate;
          const cachedStr = cachedTotal > 0 ? ` (${(cachedTotal / 1000).toFixed(1)}k cached)` : '';

          // Build rich footer: 💰 $0.5540 (sonnet-4.5) • In: 37 (635.4k cached) • Out: 269 • 🖥 bdt-duke01 • ⏰ 20:43 • 📁 ani-code • 🤖 claude
          const parts = [];
          if (totalCost > 0.0001) {
            parts.push(`💰 $${totalCost.toFixed(4)} (sonnet-4.5)`);
          }
          parts.push(`• In: ${input.toLocaleString()}${cachedStr}`);
          parts.push(`• Out: ${output.toLocaleString()}`);
          parts.push(`• 🖥 ${hostname}`);
          parts.push(`• ⏰ <span class="local-time" data-timestamp="${msg.timestamp}">${timestamp}</span>`);
          parts.push(`• 📁 ${projectName}`);
          parts.push(`• 🤖 claude`);

          metadataFooter = `<div class="metadata-footer">${parts.join(' ')}</div>`;
        }

        return `
        <div id="${anchorId}" class="message assistant-message">
          <div class="content">${content}</div>
          ${metadataFooter}
        </div>`;
      } else if (msg.type === 'tool_result') {
        const resultText = typeof msg.content === 'string' ? msg.content : JSON.stringify(msg.content, null, 2);

        // Skip empty results
        if (!resultText || resultText.trim().length === 0) {
          return '';
        }

        // Count lines in result
        const lineCount = resultText.split('\n').length;

        // Auto-expand if 2 lines or less, otherwise collapse
        if (lineCount <= 2) {
          return `
          <div id="${anchorId}" class="message tool-result">
            <div class="header">RESULT <span class="timestamp" data-timestamp="${msg.timestamp}">${timestamp}</span></div>
            <pre class="content">${this.escapeHTML(resultText)}</pre>
          </div>`;
        } else {
          return `
          <div id="${anchorId}" class="message tool-result">
            <div class="header">RESULT <span class="timestamp" data-timestamp="${msg.timestamp}">${timestamp}</span></div>
            <details class="section">
              <summary>View Output (${lineCount} lines)</summary>
              <pre>${this.escapeHTML(resultText)}</pre>
            </details>
          </div>`;
        }
      }

      return '';
    }).join('\n');

    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Claude Code Session - ${sessionDate.toLocaleDateString()}</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    html {
      scroll-behavior: smooth;
      scroll-padding-top: 50px;
    }

    body {
      font-family: 'Courier New', Courier, monospace;
      background: #fff;
      padding: 10px;
      margin: 10px;
      line-height: 1.4;
      font-size: 13px;
      max-width: 100%;
      overflow-x: hidden;
    }

    .container {
      max-width: 800px;
      margin: 0 auto;
    }

    .page-header {
      border-bottom: 1px solid #000;
      padding-bottom: 5px;
      margin-bottom: 10px;
    }

    .page-header h1 {
      font-size: 14px;
      font-weight: bold;
    }

    .page-header .meta {
      font-size: 11px;
      margin-top: 3px;
    }

    .message {
      margin-bottom: 8px;
      border-left: 4px solid #ddd;
      padding: 6px;
      padding-left: 8px;
      position: relative;
    }

    .user-message {
      border-left-color: #4CAF50;
    }

    .assistant-message {
      border-left-color: #2196F3;
    }

    .tool-result {
      border-left-color: #FF9800;
    }

    .message .header {
      font-weight: bold;
      margin-bottom: 4px;
      font-size: 11px;
      color: #555;
    }

    .user-message .header {
      color: #2e7d32;
    }

    .assistant-message .header {
      color: #1565C0;
    }

    .tool-result .header {
      color: #E65100;
    }

    .message div.content {
      word-wrap: break-word;
      overflow-wrap: break-word;
      color: #333;
      line-height: 1.5;
    }

    .message pre.content {
      white-space: pre-wrap;
      word-wrap: break-word;
      overflow-wrap: break-word;
      color: #333;
      line-height: 1.5;
      font-size: 12px;
      margin: 0;
      padding: 0;
    }

    .message pre.text {
      white-space: pre-wrap;
      word-wrap: break-word;
      overflow-wrap: break-word;
      color: #333;
      line-height: 1.5;
      font-size: 12px;
      margin: 0;
      padding: 0;
    }

    .timestamp {
      float: right;
      font-weight: normal;
      color: #999;
      font-size: 11px;
    }

    .message .text {
      margin-bottom: 5px;
    }

    .section {
      margin: 6px 0;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      padding: 0;
      background: white;
    }

    .section summary {
      cursor: pointer;
      font-weight: bold;
      padding: 6px 10px;
      user-select: none;
      font-size: 11px;
      border-radius: 4px 4px 0 0;
    }

    .section[open] summary {
      border-bottom: 1px solid #e0e0e0;
    }

    .section pre {
      margin: 0;
      padding: 6px 10px;
      background: #fafafa;
      overflow-x: auto;
      font-size: 11px;
      line-height: 1.4;
    }

    /* Color coding for different tool types */
    .tool-read summary {
      background: #e8f4f8;
      color: #0066cc;
    }

    .tool-write summary {
      background: #fff4e6;
      color: #cc6600;
    }

    .tool-bash summary {
      background: #f0f0f0;
      color: #333;
    }

    .tool-task summary {
      background: #f0e6ff;
      color: #6600cc;
    }

    .tool-other summary {
      background: #f5f5f5;
      color: #666;
    }

    /* Enhanced file operation styles */
    .file-operation summary {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .tool-label {
      font-weight: bold;
      margin-right: 4px;
    }

    .file-path {
      font-family: 'Courier New', monospace;
      color: #0066cc;
      word-break: break-all;
      flex: 1;
    }

    .file-meta {
      color: #999;
      font-size: 10px;
      white-space: nowrap;
    }

    .file-preview {
      padding: 10px;
      background: #fafafa;
    }

    .file-description {
      background: #f0f0f0;
      padding: 6px 10px;
      margin-bottom: 10px;
      border-left: 3px solid #0066cc;
      font-size: 11px;
      color: #555;
    }

    /* Code preview styles */
    .code-preview {
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      overflow: hidden;
    }

    .code-header {
      background: #f5f5f5;
      padding: 6px 10px;
      border-bottom: 1px solid #e0e0e0;
      display: flex;
      justify-content: space-between;
      font-size: 10px;
    }

    .code-lang {
      color: #666;
      font-weight: bold;
      text-transform: uppercase;
    }

    .code-lines {
      color: #999;
    }

    .code-content {
      margin: 0;
      padding: 10px;
      background: white;
      overflow-x: auto;
      white-space: pre;
      line-height: 1.4;
    }

    .code-content code {
      font-family: 'Courier New', monospace;
      font-size: 11px;
      line-height: 1.4;
    }

    .show-more-container {
      margin-top: 10px;
      padding: 10px;
      background: #f9f9f9;
      border-top: 1px solid #e0e0e0;
      text-align: center;
    }

    .show-more-btn {
      padding: 8px 16px;
      background: #0066cc;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 11px;
      font-weight: bold;
      transition: background 0.2s;
    }

    .show-more-btn:hover {
      background: #0052a3;
    }

    .show-more-btn:active {
      background: #003d7a;
    }

    /* Diff view styles */
    .diff-view {
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      overflow: hidden;
    }

    .diff-header {
      background: #f5f5f5;
      padding: 6px 10px;
      border-bottom: 1px solid #e0e0e0;
      font-size: 11px;
      font-weight: bold;
      color: #666;
    }

    .diff-block {
      border-bottom: 1px solid #e0e0e0;
    }

    .diff-block:last-child {
      border-bottom: none;
    }

    .diff-label {
      padding: 6px 10px;
      font-size: 10px;
      font-weight: bold;
    }

    .diff-remove .diff-label {
      background: #ffebeb;
      color: #cc0000;
    }

    .diff-add .diff-label {
      background: #e6ffe6;
      color: #00cc00;
    }

    .diff-content {
      margin: 0;
      padding: 10px;
      background: white;
      font-size: 11px;
      line-height: 1.4;
      overflow-x: auto;
    }

    .diff-remove .diff-content {
      background: #fffafa;
    }

    .diff-add .diff-content {
      background: #fafffa;
    }

    .diff-hunk {
      border-bottom: 1px solid #e0e0e0;
    }

    .diff-hunk:last-child {
      border-bottom: none;
    }

    .diff-location {
      background: #f0f0f0;
      padding: 4px 10px;
      font-size: 10px;
      color: #999;
      font-weight: bold;
    }

    .usage {
      margin-top: 5px;
      padding-top: 5px;
      border-top: 1px solid #000;
      font-size: 10px;
    }

    .metadata-footer {
      margin-top: 8px;
      padding: 5px;
      border: 1px solid #ddd;
      background: #f9f9f9;
      font-size: 10px;
      line-height: 1.6;
      overflow-x: auto;
      white-space: nowrap;
    }

    pre {
      white-space: pre-wrap;
      word-wrap: break-word;
      overflow-wrap: break-word;
    }

    .page-footer {
      border-top: 1px solid #000;
      padding-top: 5px;
      margin-top: 10px;
      font-size: 10px;
      text-align: center;
    }

    .nav-menu {
      position: sticky;
      top: 0;
      background: #fff;
      border: 2px solid #000;
      margin-bottom: 10px;
      font-size: 11px;
      z-index: 1000;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .nav-menu summary {
      padding: 8px;
      cursor: pointer;
      user-select: none;
      list-style: none;
      font-weight: bold;
      font-size: 12px;
    }

    .nav-menu summary::-webkit-details-marker {
      display: none;
    }

    .nav-menu summary::before {
      content: '▼ ';
      display: inline-block;
      transition: transform 0.2s;
      font-size: 10px;
    }

    .nav-menu:not([open]) summary::before {
      content: '▶ ';
    }

    .nav-menu:hover {
      background: #f9f9f9;
    }

    .nav-list {
      max-height: 400px;
      overflow-y: auto;
      padding: 8px;
      padding-top: 0;
    }

    .nav-item {
      margin: 4px 0;
      border: 1px solid #ddd;
      border-radius: 3px;
      background: #f9f9f9;
    }

    .nav-item summary {
      cursor: pointer;
      padding: 4px 8px;
      user-select: none;
      list-style: none;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .nav-item summary::-webkit-details-marker {
      display: none;
    }

    .nav-item summary::before {
      content: '▶';
      display: inline-block;
      width: 12px;
      transition: transform 0.2s;
      font-size: 9px;
    }

    .nav-item[open] summary::before {
      transform: rotate(90deg);
    }

    .nav-item:hover {
      background: #f0f0f0;
    }

    .nav-link {
      color: #000;
      text-decoration: none;
      padding: 2px 6px;
      border: 1px solid #000;
      background: #fff;
      font-weight: bold;
      border-radius: 2px;
      font-size: 11px;
      cursor: pointer;
      display: inline-block;
    }

    .nav-link:hover {
      background: #0066cc;
      color: #fff;
      border-color: #0066cc;
    }

    .nav-link:active {
      background: #004499;
    }

    .nav-preview {
      color: #666;
      font-size: 10px;
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .nav-content {
      margin: 0;
      padding: 8px;
      border-top: 1px solid #ddd;
      background: #fff;
      font-size: 10px;
      max-height: 200px;
      overflow-y: auto;
      white-space: pre-wrap;
      word-wrap: break-word;
    }

    /* File navigation styles */
    .file-nav-section {
      position: sticky;
      top: 0;
      background: #fff;
      border: 2px solid #000;
      margin-bottom: 10px;
      font-size: 11px;
      z-index: 999;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .file-nav-section summary {
      padding: 8px;
      cursor: pointer;
      user-select: none;
      font-weight: bold;
      font-size: 12px;
      background: #f9f9f9;
    }

    .file-nav-list {
      padding: 8px;
      max-height: 300px;
      overflow-y: auto;
    }

    .file-nav-item {
      border: 1px solid #e0e0e0;
      margin-bottom: 4px;
      border-radius: 4px;
    }

    .file-nav-item summary {
      padding: 6px 8px;
      cursor: pointer;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 11px;
    }

    .file-nav-item summary:hover {
      background: #f0f0f0;
    }

    .file-nav-name {
      font-family: 'Courier New', monospace;
      font-weight: bold;
      color: #0066cc;
      flex: 1;
    }

    .file-nav-ops {
      color: #666;
      font-size: 10px;
      white-space: nowrap;
    }

    .file-nav-details {
      padding: 8px;
      background: #fafafa;
      border-top: 1px solid #e0e0e0;
    }

    .file-nav-path {
      font-family: 'Courier New', monospace;
      font-size: 10px;
      color: #666;
      margin-bottom: 6px;
      word-break: break-all;
    }

    .file-nav-links {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    }

    .file-op-link {
      display: inline-block;
      padding: 2px 6px;
      background: #e8f4f8;
      border: 1px solid #c0dfe8;
      border-radius: 3px;
      font-size: 10px;
      cursor: pointer;
      color: #0066cc;
    }

    .file-op-link:hover {
      background: #d0e8f0;
      border-color: #a0c8d8;
    }

    @media (max-width: 600px) {
      body {
        font-size: 12px;
        padding: 8px;
        margin: 5px;
      }

      .page-header h1 {
        font-size: 13px;
      }

      .message {
        margin-bottom: 6px;
        padding: 5px;
        padding-left: 7px;
      }

      .message .header {
        font-size: 10px;
        margin-bottom: 3px;
      }

      .section {
        margin: 4px 0;
      }

      .section summary {
        padding: 5px 8px;
        font-size: 10px;
      }

      .section pre {
        font-size: 10px;
        padding: 4px 8px;
      }

      .message .text {
        margin-bottom: 4px;
      }
    }
  </style>
  <script>
    // Track if we're programmatically scrolling
    let isJumping = false;

    // Show remaining lines inline without separate scroll
    function showRemainingLines(button) {
      const targetId = button.getAttribute('data-target');
      const totalLines = parseInt(button.getAttribute('data-total'));
      const shownLines = parseInt(button.getAttribute('data-shown'));

      const codeElement = document.getElementById(targetId);
      if (!codeElement) return;

      // Get the code tag inside the pre tag
      const codeTag = codeElement.querySelector('code');
      if (!codeTag) return;

      // Find the hidden div with remaining content
      const container = button.closest('.show-more-container');
      const remainingDiv = container ? container.querySelector('[data-remaining]') : null;
      if (!remainingDiv) return;

      const remainingContent = remainingDiv.textContent;

      // Append remaining content to existing code
      codeTag.textContent = codeTag.textContent + '\\n' + remainingContent;

      // Update the header to show full line count
      const codeHeader = codeElement.parentElement.querySelector('.code-header .code-lines');
      if (codeHeader) {
        codeHeader.textContent = totalLines + ' lines';
      }

      // Remove the button container
      if (container) {
        container.remove();
      }

      // Scroll to where the new content starts (approximate)
      const lineHeight = 16; // approximate line height in pixels
      const scrollPosition = shownLines * lineHeight;
      codeElement.scrollTop = scrollPosition - 100; // offset by 100px to show context
    }

    // Jump to message with smooth scrolling
    function jumpToMessage(anchorId) {
      const element = document.getElementById(anchorId);
      if (!element) return;

      // Set jumping flag to prevent auto-collapse
      isJumping = true;

      // Close the entire navigation menu
      const navMenu = document.getElementById('nav-menu');
      if (navMenu) {
        navMenu.removeAttribute('open');
      }

      // Close all open nav items inside
      const navItems = document.querySelectorAll('.nav-item[open]');
      navItems.forEach(function(item) {
        item.removeAttribute('open');
      });

      // Get position accounting for sticky nav (collapsed height)
      const navHeight = navMenu ? navMenu.offsetHeight : 0;
      const elementPosition = element.getBoundingClientRect().top + window.pageYOffset;
      const offsetPosition = elementPosition - navHeight - 10;

      // Smooth scroll to position
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });

      // Flash highlight effect
      element.style.backgroundColor = '#ffffcc';
      setTimeout(function() {
        element.style.transition = 'background-color 1s ease';
        element.style.backgroundColor = '';
      }, 100);

      // Reset jumping flag after scroll completes
      setTimeout(function() {
        isJumping = false;
      }, 1000);
    }

    // Convert all timestamps to browser's local timezone
    document.addEventListener('DOMContentLoaded', function() {
      // Convert all timestamps with data-timestamp attribute
      const timeElements = document.querySelectorAll('[data-timestamp]');
      timeElements.forEach(function(el) {
        const timestamp = parseInt(el.getAttribute('data-timestamp'));
        if (!isNaN(timestamp)) {
          const date = new Date(timestamp);

          // For nav-link elements, format as HH:MM
          if (el.classList.contains('nav-link')) {
            const hours = date.getHours().toString().padStart(2, '0');
            const minutes = date.getMinutes().toString().padStart(2, '0');
            el.textContent = hours + ':' + minutes;
          }
          // For regular timestamp elements, format as HH:MM:SS
          else if (el.classList.contains('timestamp')) {
            const hours = date.getHours().toString().padStart(2, '0');
            const minutes = date.getMinutes().toString().padStart(2, '0');
            const seconds = date.getSeconds().toString().padStart(2, '0');
            el.textContent = hours + ':' + minutes + ':' + seconds;
          }
          // For .local-time class (in metadata footer), format as HH:MM:SS
          else if (el.classList.contains('local-time')) {
            const hours = date.getHours().toString().padStart(2, '0');
            const minutes = date.getMinutes().toString().padStart(2, '0');
            const seconds = date.getSeconds().toString().padStart(2, '0');
            el.textContent = hours + ':' + minutes + ':' + seconds;
          }
        }
      });

      // No auto-collapse on scroll - only collapse when user clicks jump button
      // This prevents the navigation from collapsing while user is browsing
    });
  </script>
</head>
<body>
  <div class="container">
    <div class="page-header">
      <h1>CLAUDE CODE SESSION HISTORY</h1>
      <div class="meta">
        Date: ${sessionDate.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })}
        | Messages: ${messages.length}
        | Session: ${sessionFile.substring(0, 12)}...
      </div>
    </div>
    ${navLinks ? `
    <details class="nav-menu" id="nav-menu">
      <summary class="nav-title">User Messages (${userMessages.length})</summary>
      <div class="nav-list">${navLinks}</div>
    </details>` : ''}
    ${fileNavHTML}
    ${messagesHTML}
    <div class="page-footer">
      🤖 Generated with Claude Code
      <br>
      ${new Date().toISOString()}
    </div>
  </div>
</body>
</html>`;
  }

  /**
   * Escape HTML special characters
   */
  escapeHTML(text) {
    if (typeof text !== 'string') return '';
    return text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // Get file extension from path
  getFileExtension(filePath) {
    const match = filePath.match(/\.([^.]+)$/);
    return match ? match[1].toLowerCase() : '';
  }

  // Get language from file extension
  getLanguageFromExtension(ext) {
    const langMap = {
      'js': 'javascript', 'jsx': 'javascript', 'ts': 'typescript', 'tsx': 'typescript',
      'py': 'python', 'rb': 'ruby', 'go': 'go', 'rs': 'rust',
      'java': 'java', 'cpp': 'cpp', 'c': 'c', 'cs': 'csharp',
      'php': 'php', 'swift': 'swift', 'kt': 'kotlin', 'scala': 'scala',
      'html': 'html', 'css': 'css', 'scss': 'scss', 'sass': 'sass',
      'json': 'json', 'xml': 'xml', 'yaml': 'yaml', 'yml': 'yaml',
      'md': 'markdown', 'sh': 'bash', 'bash': 'bash', 'sql': 'sql'
    };
    return langMap[ext] || 'plaintext';
  }

  // Format file size
  formatFileSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  }

  // Render Write tool with file preview
  renderWriteTool(tool) {
    const filePath = tool.input.file_path || 'unknown';
    const content = tool.input.content || tool.input.file_text || '';
    const description = tool.input.description || '';

    // Get file info
    const fileName = filePath.split('/').pop();
    const ext = this.getFileExtension(filePath);
    const language = this.getLanguageFromExtension(ext);
    const fileSize = this.formatFileSize(new TextEncoder().encode(content).length);

    // Split content into lines for preview
    const lines = content.split('\n');
    const lineCount = lines.length;
    const previewLines = 50; // Show first 50 lines
    const hasMore = lineCount > previewLines;

    // Build HTML
    let html = `
      <details class="section tool-write file-operation">
        <summary>
          <span class="tool-label">📝 Write</span>
          <span class="file-path">${this.escapeHTML(filePath)}</span>
          <span class="file-meta">(${fileSize}, ${lineCount} lines)</span>
        </summary>
        <div class="file-preview">`;

    if (description) {
      html += `<div class="file-description">${this.escapeHTML(description)}</div>`;
    }

    html += `
          <div class="code-preview">
            <div class="code-header">
              <span class="code-lang">${language}</span>
              ${hasMore ? `<span class="code-lines">Showing ${previewLines} of ${lineCount} lines</span>` : `<span class="code-lines">${lineCount} lines</span>`}
            </div>
            <pre class="code-content language-${language}" id="code-${tool.id || 'preview'}"><code>${this.escapeHTML(hasMore ? lines.slice(0, previewLines).join('\n') : content)}</code></pre>`;

    if (hasMore) {
      const remainingContent = lines.slice(previewLines).join('\n');
      const remainingEscaped = this.escapeHTML(remainingContent);
      html += `
            <div class="show-more-container">
              <button class="show-more-btn" onclick="showRemainingLines(this)" data-target="code-${tool.id || 'preview'}" data-total="${lineCount}" data-shown="${previewLines}">Show remaining ${lineCount - previewLines} lines...</button>
              <div style="display:none;" data-remaining="${tool.id || 'preview'}">${remainingEscaped}</div>
            </div>`;
    }

    html += `
          </div>
        </div>
      </details>`;

    return html;
  }

  // Render Edit tool with diff view
  renderEditTool(tool) {
    const filePath = tool.input.file_path || 'unknown';
    const oldStr = tool.input.old_string || tool.input.old_str || '';
    const newStr = tool.input.new_string || tool.input.new_str || '';
    const replaceAll = tool.input.replace_all || false;
    const description = tool.input.description || '';

    // Get file info
    const fileName = filePath.split('/').pop();
    const ext = this.getFileExtension(filePath);
    const language = this.getLanguageFromExtension(ext);

    let html = `
      <details class="section tool-edit file-operation">
        <summary>
          <span class="tool-label">✏️ Edit</span>
          <span class="file-path">${this.escapeHTML(filePath)}</span>
          <span class="file-meta">${replaceAll ? '(replace all)' : '(1 change)'}</span>
        </summary>
        <div class="file-preview">`;

    if (description) {
      html += `<div class="file-description">${this.escapeHTML(description)}</div>`;
    }

    // Show diff view
    html += `
          <div class="diff-view">
            <div class="diff-header">String Replacement${replaceAll ? ' (All Occurrences)' : ''}</div>`;

    if (oldStr) {
      const oldLines = oldStr.split('\n');
      html += `
            <div class="diff-block diff-remove">
              <div class="diff-label">- Remove (${oldLines.length} lines):</div>
              <pre class="diff-content language-${language}"><code>${this.escapeHTML(oldStr)}</code></pre>
            </div>`;
    }

    if (newStr) {
      const newLines = newStr.split('\n');
      html += `
            <div class="diff-block diff-add">
              <div class="diff-label">+ Add (${newLines.length} lines):</div>
              <pre class="diff-content language-${language}"><code>${this.escapeHTML(newStr)}</code></pre>
            </div>`;
    }

    html += `
          </div>
        </div>
      </details>`;

    return html;
  }

  // Render Read tool with file info
  renderReadTool(tool) {
    const filePath = tool.input.file_path || 'unknown';
    const offset = tool.input.offset || 0;
    const limit = tool.input.limit || 'all';

    // Get file info
    const fileName = filePath.split('/').pop();
    const ext = this.getFileExtension(filePath);

    let rangeInfo = '';
    if (offset > 0 || (limit !== 'all' && limit)) {
      rangeInfo = ` (lines ${offset + 1}-${limit !== 'all' && limit ? offset + limit : 'end'})`;
    }

    return `
      <details class="section tool-read file-operation" open>
        <summary>
          <span class="tool-label">👁️ Read</span>
          <span class="file-path">${this.escapeHTML(filePath)}</span>
          <span class="file-meta">${rangeInfo}</span>
        </summary>
      </details>`;
  }

  /**
   * Basic markdown formatting
   */
  formatMarkdown(text) {
    if (typeof text !== 'string') return '';

    // Escape HTML first
    let formatted = this.escapeHTML(text);

    // Format code blocks
    formatted = formatted.replace(/```(\w+)?\n([\s\S]*?)```/g, '<pre class="code-block"><code>$2</code></pre>');

    // Format inline code
    formatted = formatted.replace(/`([^`]+)`/g, '<code>$1</code>');

    // Format bold
    formatted = formatted.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');

    // Format italic
    formatted = formatted.replace(/\*([^*]+)\*/g, '<em>$1</em>');

    // Format links
    formatted = formatted.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank">$1</a>');

    return formatted;
  }

  /**
   * Get the current working project path
   */
  async getCurrentProjectPath() {
    // Default to ani-code project
    return '/root/workspace/ani-code';
  }

  /**
   * Generate HTML for the latest session
   * @param {string} projectPath - Optional project path, defaults to current
   * @returns {Promise<string>} HTML content
   */
  async generateLatestSessionHTML(projectPath = null) {
    try {
      if (!projectPath) {
        projectPath = await this.getCurrentProjectPath();
      }

      logger.info(`Generating history HTML for project: ${projectPath}`);

      const sessionFile = await this.findLatestSession(projectPath);
      if (!sessionFile) {
        throw new Error('No session file found');
      }

      logger.info(`Found session file: ${sessionFile}`);

      // Get file size for logging
      const stats = await fs.stat(sessionFile);
      logger.info(`Session file size: ${(stats.size / 1024 / 1024).toFixed(2)} MB, modified: ${stats.mtime}`);

      const messages = await this.parseSession(sessionFile);
      logger.info(`Parsed ${messages.length} messages from session`);

      // Log last few messages for verification
      if (messages.length > 0) {
        const lastMsg = messages[messages.length - 1];
        logger.info(`Last message type: ${lastMsg.type}, timestamp: ${new Date(lastMsg.timestamp).toISOString()}`);
        if (lastMsg.textContent) {
          logger.info(`Last message preview: ${lastMsg.textContent.substring(0, 100)}...`);
        }
      }

      const html = this.generateHTML(messages, sessionFile);
      logger.info(`Generated HTML (${html.length} bytes)`);

      return html;
    } catch (error) {
      logger.error(`Error generating session HTML: ${error.message}`);
      throw error;
    }
  }

  /**
   * Generate HTML from the latest session file
   * @param {string} projectPath - Project directory path
   * @param {number} startTime - Start timestamp (unused, kept for backward compatibility)
   * @param {number} endTime - End timestamp (unused, kept for backward compatibility)
   * @returns {Promise<string>} HTML content
   */
  async generateFilteredHTML(projectPath, startTime, endTime) {
    try {
      logger.info(`Generating history HTML for project: ${projectPath}`);

      const sessionFile = await this.findLatestSession(projectPath);
      if (!sessionFile) {
        throw new Error('No session file found');
      }

      logger.info(`Found latest session file: ${sessionFile}`);

      const allMessages = await this.parseSession(sessionFile);
      logger.info(`Parsed ${allMessages.length} total messages from session`);

      if (allMessages.length === 0) {
        throw new Error('No messages found in session file');
      }

      // Debug: Log timestamp info
      if (allMessages.length > 0) {
        const firstMsg = allMessages[0];
        const lastMsg = allMessages[allMessages.length - 1];
        logger.info(`First message: ${new Date(firstMsg.timestamp).toISOString()}`);
        logger.info(`Last message: ${new Date(lastMsg.timestamp).toISOString()}`);
      }

      const html = this.generateHTML(allMessages, sessionFile);
      logger.info(`Generated HTML (${html.length} bytes)`);

      return html;
    } catch (error) {
      logger.error(`Error generating filtered HTML: ${error.message}`);
      throw error;
    }
  }
}

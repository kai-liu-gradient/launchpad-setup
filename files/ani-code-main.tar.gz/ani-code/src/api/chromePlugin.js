const express = require('express');
const WebSocket = require('ws');
const tokenService = require('../services/tokenService');
const { executeCommand } = require('../services/executor');
const { getGitLog } = require('../services/git');

class ChromePluginAPI {
  constructor(app, server) {
    this.app = app;
    this.wss = new WebSocket.Server({ 
      server,
      path: '/ws/chrome-plugin'
    });
    
    this.connections = new Map();
    this.setupRoutes();
    this.setupWebSocket();
  }

  setupRoutes() {
    const router = express.Router();
    
    // Generate token for project
    router.post('/token/generate', (req, res) => {
      try {
        const { projectId, metadata } = req.body;
        
        if (!projectId) {
          return res.status(400).json({ error: 'Project ID required' });
        }
        
        // Check if token already exists for project
        let tokenData = tokenService.getTokenByProject(projectId);
        
        if (!tokenData || Date.now() > tokenData.expiresAt) {
          // Generate new token
          tokenData = tokenService.generateToken(projectId, metadata);
        }
        
        res.json({
          success: true,
          token: tokenData.token,
          url: tokenData.url,
          expiresAt: tokenData.expiresAt
        });
      } catch (error) {
        console.error('Token generation error:', error);
        res.status(500).json({ error: error.message });
      }
    });
    
    // Validate token
    router.post('/token/validate', (req, res) => {
      const { token } = req.body;
      
      if (!token) {
        return res.status(400).json({ error: 'Token required' });
      }
      
      const validation = tokenService.validateToken(token);
      res.json(validation);
    });
    
    // Revoke token
    router.post('/token/revoke', (req, res) => {
      const { token } = req.body;
      
      if (!token) {
        return res.status(400).json({ error: 'Token required' });
      }
      
      const revoked = tokenService.revokeToken(token);
      res.json({ success: revoked });
    });
    
    // List tokens
    router.get('/tokens', (req, res) => {
      const tokens = tokenService.listTokens();
      res.json({ tokens });
    });
    
    // Get project status
    router.get('/project/:projectId/status', (req, res) => {
      const { projectId } = req.params;
      const connection = this.getConnectionByProject(projectId);
      
      if (!connection) {
        return res.json({ 
          connected: false,
          projectId 
        });
      }
      
      res.json({
        connected: true,
        projectId,
        tasks: connection.tasks || [],
        activeTask: connection.activeTask || null
      });
    });
    
    this.app.use('/api/chrome-plugin', router);
  }

  setupWebSocket() {
    this.wss.on('connection', (ws, req) => {
      const url = new URL(req.url, `http://${req.headers.host}`);
      const token = url.searchParams.get('token');
      
      if (!token) {
        ws.close(1008, 'Token required');
        return;
      }
      
      const validation = tokenService.validateToken(token);
      if (!validation.valid) {
        ws.close(1008, validation.reason);
        return;
      }
      
      const connectionId = this.generateConnectionId();
      const connection = {
        id: connectionId,
        ws,
        token,
        projectId: validation.data.projectId,
        metadata: validation.data.metadata,
        tasks: [],
        activeTask: null
      };
      
      this.connections.set(connectionId, connection);
      console.log(`Chrome plugin connected: ${connection.projectId}`);
      
      // Send initial connection confirmation
      this.sendToConnection(connectionId, {
        type: 'CONNECTED',
        projectId: connection.projectId,
        connectionId
      });
      
      // Handle messages
      ws.on('message', (message) => {
        this.handleMessage(connectionId, message);
      });
      
      // Handle ping/pong for keep-alive
      ws.on('ping', () => {
        ws.pong();
      });
      
      // Handle disconnection
      ws.on('close', () => {
        console.log(`Chrome plugin disconnected: ${connection.projectId}`);
        this.connections.delete(connectionId);
      });
      
      ws.on('error', (error) => {
        console.error('WebSocket error:', error);
      });
    });
    
    // Clean up expired tokens periodically
    setInterval(() => {
      tokenService.cleanExpiredTokens();
    }, 60 * 60 * 1000); // Every hour
  }

  async handleMessage(connectionId, message) {
    const connection = this.connections.get(connectionId);
    if (!connection) return;
    
    try {
      const data = JSON.parse(message);
      
      switch (data.type) {
        case 'PING':
          this.sendToConnection(connectionId, { type: 'PONG' });
          break;
          
        case 'PROMPT':
          await this.handlePrompt(connectionId, data);
          break;
          
        case 'GET_GIT_LOG':
          await this.handleGitLog(connectionId, data);
          break;
          
        case 'GET_TASKS':
          this.sendToConnection(connectionId, {
            type: 'TASKS',
            tasks: connection.tasks
          });
          break;
          
        case 'PAGE_NAVIGATED':
          console.log(`Page navigated: ${data.url}`);
          connection.currentUrl = data.url;
          break;
          
        default:
          console.warn(`Unknown message type: ${data.type}`);
      }
    } catch (error) {
      console.error('Message handling error:', error);
      this.sendToConnection(connectionId, {
        type: 'ERROR',
        message: error.message
      });
    }
  }

  async handlePrompt(connectionId, data) {
    const connection = this.connections.get(connectionId);
    if (!connection) return;
    
    try {
      // Create a new task
      const task = {
        id: this.generateTaskId(),
        prompt: data.prompt,
        context: data.context,
        status: 'pending',
        createdAt: Date.now()
      };
      
      connection.tasks.push(task);
      connection.activeTask = task;
      
      // Notify about task creation
      this.sendToConnection(connectionId, {
        type: 'TASK_UPDATE',
        task
      });
      
      // Execute the prompt (integrate with AniCode's AI system)
      task.status = 'in_progress';
      this.sendToConnection(connectionId, {
        type: 'TASK_UPDATE',
        task
      });
      
      // Here you would integrate with AniCode's existing AI execution
      // For now, we'll simulate with a placeholder
      const result = await this.executePrompt(data.prompt, data.context);
      
      task.status = 'completed';
      task.result = result;
      task.completedAt = Date.now();
      
      this.sendToConnection(connectionId, {
        type: 'TASK_UPDATE',
        task
      });
      
      this.sendToConnection(connectionId, {
        type: 'PROMPT_RESPONSE',
        taskId: task.id,
        response: result
      });
      
    } catch (error) {
      console.error('Prompt execution error:', error);
      
      if (connection.activeTask) {
        connection.activeTask.status = 'failed';
        connection.activeTask.error = error.message;
        
        this.sendToConnection(connectionId, {
          type: 'TASK_UPDATE',
          task: connection.activeTask
        });
      }
      
      this.sendToConnection(connectionId, {
        type: 'ERROR',
        message: error.message
      });
    }
  }

  async handleGitLog(connectionId, data) {
    try {
      const logs = await getGitLog(data.limit || 10);
      
      this.sendToConnection(connectionId, {
        type: 'GIT_LOG_RESPONSE',
        logs
      });
    } catch (error) {
      console.error('Git log error:', error);
      this.sendToConnection(connectionId, {
        type: 'ERROR',
        message: error.message
      });
    }
  }

  async executePrompt(prompt, context) {
    // This should integrate with AniCode's existing AI execution system
    // For now, return a placeholder
    return {
      success: true,
      message: `Processed prompt: ${prompt}`,
      context,
      timestamp: Date.now()
    };
  }

  sendToConnection(connectionId, data) {
    const connection = this.connections.get(connectionId);
    if (connection && connection.ws.readyState === WebSocket.OPEN) {
      connection.ws.send(JSON.stringify(data));
    }
  }

  broadcastToProject(projectId, data) {
    for (const connection of this.connections.values()) {
      if (connection.projectId === projectId) {
        this.sendToConnection(connection.id, data);
      }
    }
  }

  getConnectionByProject(projectId) {
    for (const connection of this.connections.values()) {
      if (connection.projectId === projectId) {
        return connection;
      }
    }
    return null;
  }

  generateConnectionId() {
    return `conn_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  generateTaskId() {
    return `task_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}

module.exports = ChromePluginAPI;
const crypto = require('crypto');
const WebSocket = require('ws');

class ChromePluginAuth {
  constructor() {
    this.activeSessions = new Map();
  }

  // Validate token from Chrome plugin
  validateToken(tokenString) {
    try {
      const [encodedPayload, signature, secret] = tokenString.split('.');
      
      if (!encodedPayload || !signature || !secret) {
        return { valid: false, error: 'Invalid token format' };
      }
      
      // Verify signature
      const expectedSignature = crypto
        .createHmac('sha256', secret)
        .update(encodedPayload)
        .digest('hex');
      
      if (signature !== expectedSignature) {
        return { valid: false, error: 'Invalid token signature' };
      }
      
      // Decode payload
      const payload = JSON.parse(Buffer.from(encodedPayload, 'base64').toString());
      
      // Check expiry
      if (Date.now() > payload.expiresAt) {
        return { valid: false, error: 'Token expired' };
      }
      
      return { valid: true, payload };
    } catch (error) {
      return { valid: false, error: error.message };
    }
  }

  // Handle WebSocket authentication
  authenticateWebSocket(ws, req) {
    const url = new URL(req.url, `http://${req.headers.host}`);
    const token = url.searchParams.get('token');
    
    if (!token) {
      ws.close(1008, 'Token required');
      return null;
    }
    
    const validation = this.validateToken(token);
    if (!validation.valid) {
      ws.close(1008, validation.error);
      return null;
    }
    
    // Create session
    const sessionId = crypto.randomBytes(16).toString('hex');
    const session = {
      id: sessionId,
      ws,
      payload: validation.payload,
      project: validation.payload.project,
      projectPath: validation.payload.projectPath,
      connectedAt: Date.now(),
      lastActivity: Date.now()
    };
    
    this.activeSessions.set(sessionId, session);
    
    // Send connection confirmation
    ws.send(JSON.stringify({
      type: 'AUTH_SUCCESS',
      sessionId,
      project: validation.payload.project,
      projectPath: validation.payload.projectPath,
      serverUrl: validation.payload.serverUrl
    }));
    
    return session;
  }

  // Get session by ID
  getSession(sessionId) {
    return this.activeSessions.get(sessionId);
  }

  // Remove session
  removeSession(sessionId) {
    return this.activeSessions.delete(sessionId);
  }

  // Update session activity
  updateActivity(sessionId) {
    const session = this.activeSessions.get(sessionId);
    if (session) {
      session.lastActivity = Date.now();
    }
  }

  // Clean inactive sessions
  cleanInactiveSessions(maxInactiveMs = 30 * 60 * 1000) { // 30 minutes
    const now = Date.now();
    for (const [sessionId, session] of this.activeSessions) {
      if (now - session.lastActivity > maxInactiveMs) {
        if (session.ws.readyState === WebSocket.OPEN) {
          session.ws.close(1000, 'Session timeout');
        }
        this.activeSessions.delete(sessionId);
      }
    }
  }

  // Get all active sessions for a project
  getProjectSessions(projectPath) {
    const sessions = [];
    for (const session of this.activeSessions.values()) {
      if (session.projectPath === projectPath) {
        sessions.push(session);
      }
    }
    return sessions;
  }

  // Broadcast to all sessions for a project
  broadcastToProject(projectPath, message) {
    const sessions = this.getProjectSessions(projectPath);
    const messageStr = typeof message === 'string' ? message : JSON.stringify(message);
    
    for (const session of sessions) {
      if (session.ws.readyState === WebSocket.OPEN) {
        session.ws.send(messageStr);
      }
    }
  }
}

module.exports = ChromePluginAuth;
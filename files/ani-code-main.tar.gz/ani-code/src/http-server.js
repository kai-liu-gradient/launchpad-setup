import { createServer } from 'http';
import { parse } from 'url';
import path from 'path';
import { fileURLToPath } from 'url';
import fetch from 'node-fetch';
import os from 'os';
import fs from 'fs';
import { execSync } from 'child_process';
import { logger } from './logger.js';
import { config } from './config.js';
import { ChatSettingsManager } from './chat-settings.js';
import { SecureUploader } from './utils/secure-upload.js';
import { TelegramAPI } from './telegram-api.js';
import { processPresets } from './preset-processor.js';
import { ClaudeHistoryViewer } from './claude-history-viewer.js';
import {
  normalizePlanStep,
  normalizePlanSteps,
  stepsToPlanDescription,
  getPlanStepDisplayText
} from './utils/plan-step-utils.js';
import {
  findGoalFiles,
  parseGoalFile,
  extractGoalId
} from './utils/goals-utils.js';
import {
  stripPatternsFromPrompt,
  extractProviderFromPrompt
} from './model-utils.js';
import { DisplayModeManager, VALID_DISPLAY_MODES, resolveDisplayMode } from './display-mode.js';
import { ensureTmpDir } from './services/imageHandler.js';
import { categorizeGitFilesByTaskTiming } from './telegram-notifier-base.js';

export class HTTPServer {
  constructor(taskMonitor, chatSettings = null) {
    this.taskMonitor = taskMonitor;
    this.server = null;
    // Use provided chat settings or create new one
    this.chatSettings = chatSettings || new ChatSettingsManager();
    // Message deduplication cache - stores message IDs with timestamps
    this.processedMessages = new Map();
    // Cleanup interval for old messages
    this.cleanupInterval = null;
    // Maximum age for messages in milliseconds (30 seconds)
    // Store pending prompts for Telegram callback buttons (to avoid exceeding 64 byte limit)
    this.pendingPrompts = new Map();
    this.MAX_MESSAGE_AGE_MS = 30000;
    // Workspace manager instance
    this.workspaceManager = null;
    // Git status cache to prevent blocking operations
    this.gitStatusCache = new Map();
    // Telegram bot username for mention detection
    this.telegramBotUsername = null;
    this.gitStatusCacheTTL = 5000; // 5 second cache
    // Store recent images per chat for /url command
    this.recentImages = new Map();
    // Store progress tracking intervals for /progress command
    this.progressTrackers = new Map();
    
    // Initialize Telegram API client if configured
    if (config.telegram?.botToken) {
      this.telegramAPI = new TelegramAPI(config.telegram.botToken);
    }
  }

  async getAvailableWorkdirs(chatId = null) {
    // Get workdirs from both config and workspace system
    const workdirs = { ...config.lark.workdirs };

    // If running in GATEWAY mode, always use /workspace
    if (config.gateway.enabled) {
      workdirs['workspace'] = '/workspace';
      logger.debug(`GATEWAY mode: Using /workspace as default workspace`);
      return workdirs;
    }

    // If a chat ID is provided, check if it's connected to a workspace
    if (chatId) {
      try {
        // Initialize workspace manager if not already done
        if (!this.workspaceManager) {
          const { WorkspaceManager } = await import('./workspace-manager.js');
          this.workspaceManager = new WorkspaceManager();
          await this.workspaceManager.initialize();
        }

        // Get workspace for regular chats
        const workspace = await this.workspaceManager.getWorkspaceForChat(chatId);
        if (workspace) {
          // Add the workspace to available workdirs
          workdirs[workspace.workspace_name] = workspace.workspace_path;
        }

        // Fallback: Check ChatSettings if WorkspaceManager didn't have the mapping
        if (!workspace) {
          const workdirName = this.chatSettings.getWorkdir(chatId);
          if (workdirName) {
            // Try to resolve the full path
            // First check if it's already in workdirs (from config)
            if (!workdirs[workdirName]) {
              // Try to resolve from /root/workspace/{workdirName}
              const { existsSync } = await import('fs');
              const candidatePath = `/root/workspace/${workdirName}`;
              if (existsSync(candidatePath)) {
                workdirs[workdirName] = candidatePath;
                logger.debug(`Resolved workspace path from ChatSettings: ${workdirName} -> ${candidatePath}`);
              } else {
                logger.warn(`Workspace ${workdirName} from ChatSettings not found at ${candidatePath}`);
              }
            }
          }
        }
      } catch (error) {
        logger.warn(`Failed to get workspace for chat ${chatId}:`, error);
      }
    }

    return workdirs;
  }

  async getGitDiffStats(workdir) {
    try {
      const { exec } = await import('child_process');
      const { promisify } = await import('util');
      const execAsync = promisify(exec);

      // Get diff stats with both staged and unstaged changes
      const { stdout: diffStats } = await execAsync(
        'git diff --stat --stat-width=200 HEAD 2>/dev/null || true',
        { cwd: workdir, maxBuffer: 1024 * 1024 }
      );

      // Parse the summary line (e.g., "3 files changed, 45 insertions(+), 12 deletions(-)")
      const summaryMatch = diffStats.match(/(\d+) files? changed(?:, (\d+) insertions?\(\+\))?(?:, (\d+) deletions?\(-\))?/);

      if (summaryMatch) {
        return {
          filesChanged: parseInt(summaryMatch[1]) || 0,
          insertions: parseInt(summaryMatch[2]) || 0,
          deletions: parseInt(summaryMatch[3]) || 0
        };
      }

      return null;
    } catch (error) {
      logger.debug(`Failed to get git diff stats: ${error.message}`);
      return null;
    }
  }

  /**
   * Get the last assistant response (/print content) for a workspace
   * @param {string} workspacePath - The workspace directory path
   * @param {number} maxLength - Maximum length of the output (default 500)
   * @param {Object} options - Optional parameters
   * @param {string} options.sessionFile - Specific session file path to use
   * @param {Date} options.taskStartTime - Task start time to find matching session
   * @returns {Promise<{content: string, truncated: boolean, sessionFile: string}|null>} The last assistant response or null
   */
  async getPrintContentForWorkspace(workspacePath, maxLength = 500, options = {}) {
    try {
      const historyViewer = new ClaudeHistoryViewer();
      let sessionFile = options.sessionFile;

      // If no session file specified, try to find by task start time first
      if (!sessionFile && options.taskStartTime) {
        sessionFile = await historyViewer.findSessionByTaskStartTime(workspacePath, options.taskStartTime);
      }

      // Fall back to latest session if no match found
      if (!sessionFile) {
        sessionFile = await historyViewer.findLatestSession(workspacePath);
      }

      if (!sessionFile) {
        const wsName = path.basename(workspacePath);
        logger.info(`[PROGRESS-SESSION] No session found for ${wsName}`);
        return null;
      }

      const sessionId = path.basename(sessionFile, '.jsonl').substring(0, 8);
      const elapsed = options.taskStartTime ? `${Math.round((Date.now() - new Date(options.taskStartTime).getTime()) / 1000)}s ago` : 'no start time';
      logger.info(`[PROGRESS-SESSION] Session ${sessionId}… (started ${elapsed})`);

      const messages = await historyViewer.parseSession(sessionFile);

      if (!messages || messages.length === 0) {
        return null;
      }

      const taskStartMs = options.taskStartTime ? new Date(options.taskStartTime).getTime() : null;

      // Find the last assistant message with text content
      let lastAssistantMessage = null;
      let lastAssistantIndex = -1;
      for (let i = messages.length - 1; i >= 0; i--) {
        if (messages[i].type === 'assistant' && messages[i].textContent) {
          lastAssistantMessage = messages[i];
          lastAssistantIndex = i;
          break;
        }
      }

      // Skip if the message predates the current task (stale output from previous run)
      if (lastAssistantMessage && taskStartMs && lastAssistantMessage.timestamp) {
        const messageMs = new Date(lastAssistantMessage.timestamp).getTime();
        if (messageMs < taskStartMs) {
          logger.info(`[PROGRESS-SESSION] Session ${sessionId}… text msg predates task, skipping`);
          lastAssistantMessage = null;
        }
      }

      if (!lastAssistantMessage) {
        // No valid text — check for tool activity from assistant messages after task start
        for (let i = messages.length - 1; i >= 0; i--) {
          const msg = messages[i];
          if (msg.type !== 'assistant') continue;
          // Skip messages from before this task
          if (taskStartMs && msg.timestamp) {
            const msgMs = new Date(msg.timestamp).getTime();
            if (msgMs < taskStartMs) break; // All older messages will also predate task
          }

          if (msg.toolUses && msg.toolUses.length > 0) {
            const toolNames = [...new Set(msg.toolUses.map(t => t.name))];
            const toolSummary = toolNames.join(', ');
            const lastTool = msg.toolUses[msg.toolUses.length - 1];
            let detail = '';
            if (lastTool.input) {
              if ((lastTool.name === 'Read' || lastTool.name === 'Edit' || lastTool.name === 'Write') && lastTool.input.file_path) {
                detail = ` - ${path.basename(lastTool.input.file_path)}`;
              } else if (lastTool.name === 'Bash' && lastTool.input.command) {
                const cmd = lastTool.input.command.split('\n')[0];
                detail = ` - ${cmd.length > 40 ? cmd.substring(0, 37) + '...' : cmd}`;
              } else if ((lastTool.name === 'Grep' || lastTool.name === 'Glob') && lastTool.input.pattern) {
                detail = ` - ${lastTool.input.pattern}`;
              }
            }
            logger.info(`[PROGRESS-SESSION] Session ${sessionId}… no text, showing tool activity: ${toolSummary}`);
            return { content: `working... (${toolSummary}${detail})`, truncated: false, sessionFile };
          }
          break; // Only check the most recent post-task assistant message
        }
        return null;
      }

      const output = lastAssistantMessage.textContent;

      // Debug logging for progress message content
      logger.debug(`[PROGRESS-CONTENT] Found assistant message at index ${lastAssistantIndex}/${messages.length - 1}`);
      logger.debug(`[PROGRESS-CONTENT] Message timestamp: ${lastAssistantMessage.timestamp}`);
      logger.debug(`[PROGRESS-CONTENT] Text length: ${output.length}, first 100 chars: ${output.substring(0, 100).replace(/\n/g, '\\n')}`);
      const truncated = output.length > maxLength;

      let cleanOutput;
      if (truncated) {
        // Show beginning (1/3) and end (2/3) — latest content is more useful for progress
        const startLength = Math.floor(maxLength / 3) - 15;
        const endLength = Math.floor(maxLength * 2 / 3) - 15;
        const firstPart = output.substring(0, startLength);
        const lastPart = output.substring(output.length - endLength);
        const hiddenCount = output.length - startLength - endLength;
        cleanOutput = `${firstPart}\n... ${hiddenCount} chars hidden ...\n${lastPart}`;
      } else {
        cleanOutput = output;
      }

      // Clean up backticks to avoid breaking code blocks
      cleanOutput = cleanOutput
        .replace(/```/g, '   ')
        .replace(/`/g, ' ')
        .trim();

      if (!cleanOutput) {
        return null;
      }

      return {
        content: cleanOutput,
        truncated,
        sessionFile // Return the session file path for caching
      };
    } catch (error) {
      logger.warn(`[PROGRESS-SESSION] Failed to get print content: ${error.message}`);
      return null;
    }
  }

  /**
   * Get the current provider ID for task tracking
   * @returns {Promise<string>} Provider ID (defaults to 'claude' if unable to determine)
   */
  async getCurrentProviderId() {
    try {
      const { getProviderManager } = await import('./providers/providerManager.js');
      const providerManager = await getProviderManager();
      const currentHandler = providerManager.getCurrentHandler();
      if (currentHandler && currentHandler.id) {
        return currentHandler.id;
      }
    } catch (error) {
      logger.debug(`Could not get current provider: ${error.message}`);
    }
    return 'claude'; // Default to claude if unable to determine
  }

  async getGitStatusCached(workdir) {
    // Check cache first
    const cacheKey = `git-status-${workdir}`;
    const cached = this.gitStatusCache.get(cacheKey);

    if (cached && Date.now() - cached.timestamp < this.gitStatusCacheTTL) {
      logger.debug(`Using cached git status for ${workdir}`);
      return cached.data;
    }
    
    // Fetch new status
    const { exec } = await import('child_process');
    const { promisify } = await import('util');
    const execAsync = promisify(exec);
    
    try {
      // Set aggressive timeout for git operations
      const gitStatus = await Promise.race([
        execAsync('git status --porcelain', {
          cwd: workdir,
          timeout: 2000 // 2 second timeout
        }),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Git status timeout')), 2000)
        )
      ]);
      
      const result = {
        status: gitStatus.stdout || '',
        hasUnpushed: false
      };
      
      // Try to check unpushed commits but don't block if it fails
      try {
        const revList = await Promise.race([
          execAsync('git rev-list --count @{u}..HEAD', {
            cwd: workdir,
            timeout: 1000 // 1 second timeout
          }),
          new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Git revlist timeout')), 1000)
          )
        ]);
        result.hasUnpushed = parseInt(revList.stdout.trim()) > 0;
      } catch (e) {
        // Ignore unpushed check errors
      }
      
      // Cache the result
      this.gitStatusCache.set(cacheKey, {
        timestamp: Date.now(),
        data: result
      });
      
      return result;
    } catch (error) {
      logger.debug(`Git status failed for ${workdir}: ${error.message}`);
      // Return empty result on error
      return { status: '', hasUnpushed: false, error: error.message };
    }
  }

  getSimplifiedTaskDescription(command, taskName) {
    // Generate simplified descriptions for Claude tasks
    if (command.includes('git commit message') || taskName.includes('commit-msg')) {
      return '🔄 Generating commit message';
    }
    
    if (command.includes('documentation') || taskName.includes('doc-')) {
      return '📝 Updating documentation';
    }
    
    if (command.includes('git changes') || taskName.includes('git-summary')) {
      return '📊 Creating git summary';
    }
    
    if (command.includes('code review')) {
      return '🔍 Reviewing code';
    }
    
    // Extract first meaningful line from Claude prompts
    const lines = command.split('\n');
    if (lines[0].startsWith('You are a ')) {
      const role = lines[0].match(/You are a (.+?)\./)?.[1] || 'assistant';
      return `🤖 ${role}`;
    }
    
    // For -c continue commands
    if (command.startsWith('-c ')) {
      return '🔄 Continuing previous task';
    }
    
    // Default: show first line truncated
    const firstLine = lines[0];
    return firstLine.length > 60 ? firstLine.substring(0, 57) + '...' : firstLine;
  }

  getSystemInfo() {
    const cpus = os.cpus();
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    const memUsagePercent = ((usedMem / totalMem) * 100).toFixed(1);
    
    const loadAvg = os.loadavg();
    const cpuCount = cpus.length;
    
    // Calculate average CPU usage
    let totalIdle = 0;
    let totalTick = 0;
    
    cpus.forEach(cpu => {
      for (const type in cpu.times) {
        totalTick += cpu.times[type];
      }
      totalIdle += cpu.times.idle;
    });
    
    const avgIdlePercent = (100 * totalIdle / totalTick);
    const avgUsagePercent = (100 - avgIdlePercent).toFixed(1);
    
    return {
      cpu: {
        count: cpuCount,
        usage: avgUsagePercent,
        loadAvg: loadAvg.map(load => load.toFixed(2))
      },
      memory: {
        total: (totalMem / (1024 * 1024 * 1024)).toFixed(2), // GB
        used: (usedMem / (1024 * 1024 * 1024)).toFixed(2), // GB
        free: (freeMem / (1024 * 1024 * 1024)).toFixed(2), // GB
        percent: memUsagePercent
      }
    };
  }

  async generateStatusMessage(chatId = null) {
    // Unified status message generator for both /status command and show_status action
    const status = await this.taskMonitor.getStatusWithProcessInfo();

    // Get workdir for this chat (in gateway mode, defaults to 'workspace' via ChatSettings)
    const selectedWorkdirName = chatId ? this.chatSettings.getWorkdir(chatId) : null;
    const availableWorkdirs = await this.getAvailableWorkdirs(chatId);
    const selectedWorkdirPath = selectedWorkdirName ? availableWorkdirs[selectedWorkdirName] : null;
    
    // Build status message - more concise
    let statusMessage = '';

    // Show active mode (yolo / goalloop) with abort guidance
    // States are keyed by raw chatId (number from Telegram API), so strip prefix and convert
    const rawChatId = chatId ? chatId.replace('telegram:', '') : null;
    const stateKey = rawChatId ? (isNaN(rawChatId) ? rawChatId : Number(rawChatId)) : null;
    let activeMode = null;
    let modeDetails = '';

    if (stateKey && this.yoloStates && this.yoloStates.has(stateKey)) {
      const yoloState = this.yoloStates.get(stateKey);
      activeMode = 'yolo';
      const elapsed = yoloState.startTime ? Math.round((Date.now() - yoloState.startTime) / 1000) : 0;
      const mins = Math.floor(elapsed / 60);
      const secs = elapsed % 60;
      modeDetails = `**🚀 Mode: YOLO**\n`;
      if (yoloState.totalSteps > 0) {
        modeDetails += `• Progress: ${yoloState.currentStepIndex || 0}/${yoloState.totalSteps} plans\n`;
      }
      if (yoloState.lastCompletedPlan) {
        const planPreview = yoloState.lastCompletedPlan.length > 40
          ? yoloState.lastCompletedPlan.substring(0, 37) + '...'
          : yoloState.lastCompletedPlan;
        modeDetails += `• Last: ${planPreview}\n`;
      }
      modeDetails += `• Running: ${mins}m ${secs}s\n`;
      modeDetails += `• Stop: /stopyolo\n\n`;
    } else if (stateKey && this.scheduledYoloTimeouts && this.scheduledYoloTimeouts.has(stateKey)) {
      activeMode = 'yolo_scheduled';
      modeDetails = `**⏰ Mode: YOLO (Scheduled)**\n`;
      modeDetails += `• Stop: /stopyolo\n\n`;
    }

    if (stateKey && this.goalLoopStates && this.goalLoopStates.has(stateKey)) {
      const goalState = this.goalLoopStates.get(stateKey);
      if (goalState.isActive) {
        activeMode = activeMode || 'goalloop';
        const elapsed = goalState.startTime ? Math.round((Date.now() - goalState.startTime) / 1000) : 0;
        const mins = Math.floor(elapsed / 60);
        const secs = elapsed % 60;
        modeDetails += `**🔄 Mode: Goal Loop**\n`;
        if (goalState.maxIterations) {
          modeDetails += `• Iteration: ${goalState.completedIterations || 0}/${goalState.maxIterations}\n`;
        }
        if (goalState.currentGoal) {
          const goalName = (goalState.currentGoal.name || goalState.currentGoal.title || '').substring(0, 40);
          if (goalName) modeDetails += `• Goal: ${goalName}\n`;
        }
        modeDetails += `• Running: ${mins}m ${secs}s\n`;
        modeDetails += `• Stop: /stoploop\n\n`;
      } else if (goalState.isScheduled) {
        activeMode = activeMode || 'goalloop_scheduled';
        modeDetails += `**⏰ Mode: Goal Loop (Scheduled)**\n`;
        modeDetails += `• Stop: /stoploop\n\n`;
      }
    }

    if (modeDetails) {
      statusMessage += modeDetails;
    }

    // Show running tasks grouped by workdir
    if (status.running.length > 0) {
      // Group tasks by workdir
      const tasksByWorkdir = new Map();
      status.running.forEach(task => {
        const workdir = task.cwd || 'unknown';
        if (!tasksByWorkdir.has(workdir)) {
          tasksByWorkdir.set(workdir, []);
        }
        tasksByWorkdir.get(workdir).push(task);
      });
      
      statusMessage += `**🔄 Running (${status.running.length}):**\n\n`;
      
      // Show current workdir tasks first if set
      if (selectedWorkdirPath && tasksByWorkdir.has(selectedWorkdirPath)) {
        const currentTasks = tasksByWorkdir.get(selectedWorkdirPath);
        statusMessage += `📁 **${selectedWorkdirName}** (current)\n`;
        currentTasks.forEach(task => {
          const elapsed = task.startedAt ? Math.round((Date.now() - new Date(task.startedAt).getTime()) / 1000) : 0;
          const minutes = Math.floor(elapsed / 60);
          const seconds = elapsed % 60;
          
          // Extract prompt preview
          let promptPreview = '';
          if (task.command) {
            const cleanCommand = task.command.replace(/^-c\s+/, '');
            promptPreview = cleanCommand.length > 30 
              ? cleanCommand.substring(0, 27) + '...'
              : cleanCommand;
          }
          
          // Show full task ID without truncation
          statusMessage += `• \`${task.id}\` - ${task.name}\n`;
          statusMessage += `  ⏱️ ${minutes}m ${seconds}s`;
          
          if (task.pid) {
            statusMessage += ` | PID: ${task.pid}`;
          }
          
          if (task.processInfo) {
            statusMessage += ` | CPU: ${task.processInfo.cpu}%`;
          }
          
          if (promptPreview) {
            statusMessage += `\n  📝 "${promptPreview}"`;
          }
          statusMessage += `\n`;
        });
        statusMessage += `\n`;
        tasksByWorkdir.delete(selectedWorkdirPath);
      }
      
      // Show other workdir tasks
      for (const [workdir, tasks] of tasksByWorkdir) {
        const workdirName = Object.entries(availableWorkdirs || {})
          .find(([name, path]) => path === workdir)?.[0] || workdir.split('/').pop() || workdir;
        statusMessage += `📁 **${workdirName}**\n`;
        
        tasks.forEach(task => {
          const elapsed = task.startedAt ? Math.round((Date.now() - new Date(task.startedAt).getTime()) / 1000) : 0;
          const minutes = Math.floor(elapsed / 60);
          const seconds = elapsed % 60;
          
          // Show full task ID for non-current workdir tasks
          statusMessage += `• \`${task.id}\` - ${task.name} (${minutes}m ${seconds}s)\n`;
        });
        statusMessage += `\n`;
      }
    }
    
    // Show pending tasks - only count if many
    if (status.pending.length > 0) {
      if (status.pending.length > 3) {
        statusMessage += `**⏳ Pending:** ${status.pending.length} tasks\n`;
      } else {
        statusMessage += `**⏳ Pending:**\n`;
        status.pending.forEach((task, index) => {
          const taskWorkdir = task.cwd ? task.cwd : null;
          const isCurrentWorkdir = taskWorkdir === selectedWorkdirPath;
          if (isCurrentWorkdir || !selectedWorkdirPath) {
            statusMessage += `${index + 1}. ${task.name.substring(0, 30)}${task.name.length > 30 ? '...' : ''}\n`;
          }
        });
      }
      statusMessage += '\n';
    }
    
    // If no tasks at all
    if (status.running.length === 0 && status.pending.length === 0) {
      statusMessage += `✅ No active tasks\n`;
    } else if (!activeMode && status.running.length > 0) {
      // Show cancel hint for standalone tasks (mode tasks already have stop commands above)
      statusMessage += `_/cancel <id> to stop a task_\n`;
    }

    // Variables for git status
    let gitActionButtons = [];
    
    // Run git status in the selected workdir
    if (selectedWorkdirPath) {
      try {
        // Use cached git status for faster response
        const gitInfo = await this.getGitStatusCached(selectedWorkdirPath);
        const gitStatus = gitInfo.status;
        const hasUnpushedCommits = gitInfo.hasUnpushed;
        
        if (gitStatus && gitStatus.trim()) {
          // Parse git status output
          const lines = gitStatus.trim().split('\n');
          const staged = [];
          const modified = [];
          const untracked = [];
          
          lines.forEach(line => {
            const statusCode = line.substring(0, 2);
            let file = line.substring(3);
            
            // Handle renamed files (R  old -> new)
            if (statusCode[0] === 'R' && file.includes(' -> ')) {
              // For renamed files, use the new name
              file = file.split(' -> ')[1];
            }
            
            // Debug logging for git status parsing
            logger.debug(`Git status line: "${line}" -> status="${statusCode}" file="${file}"`);
            
            if (statusCode[0] === 'A' || statusCode[0] === 'M' || statusCode[0] === 'D' || statusCode[0] === 'R') {
              staged.push(file);
            } else if (statusCode[1] === 'M' || statusCode[1] === 'D') {
              modified.push(file);
            } else if (statusCode === '??') {
              untracked.push(file);
            }
          });
          
          // Format git status like in progress messages (with code blocks)
          const totalChanges = staged.length + modified.length + untracked.length;
          
          // Add git diff stats if available
          const diffStats = await this.getGitDiffStats(selectedWorkdirPath);
          let diffStatsText = '';
          if (diffStats && (diffStats.insertions > 0 || diffStats.deletions > 0)) {
            diffStatsText = `: +${diffStats.insertions}/-${diffStats.deletions}`;
          }
          
          // Format files with git status codes
          const dirtyFiles = [];
          staged.forEach(file => {
            dirtyFiles.push(`A   ${file}`);
          });
          modified.forEach(file => {
            dirtyFiles.push(`M   ${file}`);
          });
          untracked.forEach(file => {
            dirtyFiles.push(`??  ${file}`);
          });
          
          // Add git status in code block format (matching task progress format)
          statusMessage += `\n*📂 Git Status* (${totalChanges} file${totalChanges === 1 ? '' : 's'}${diffStatsText}):\n\`\`\`\n${dirtyFiles.slice(0, 10).join('\n')}${dirtyFiles.length > 10 ? `\n... and ${dirtyFiles.length - 10} more` : ''}\n\`\`\`\n`;
          
          // Prepare action buttons based on git state
          if (modified.length > 0 && staged.length === 0) {
            // Need to stage files first
            gitActionButtons.push({
              tag: 'button',
              text: {
                tag: 'plain_text',
                content: `📦 Stage All (${modified.length})`
              },
              type: 'primary',
              value: JSON.stringify({
                action: 'run_task',
                command: 'git add .'
              })
            });
          } else if (staged.length > 0 || untracked.length > 0) {
            // Ready to commit - show total count (staged + modified + untracked if we're committing)
            const totalToCommit = staged.length + modified.length + untracked.length;
            gitActionButtons.push({
              tag: 'button',
              text: {
                tag: 'plain_text',
                content: `💾 Commit (${totalToCommit})`
              },
              type: 'primary',
              value: JSON.stringify({
                action: 'run_task',
                command: 'ani-code commit -y'
              })
            });
            
            gitActionButtons.push({
              tag: 'button',
              text: {
                tag: 'plain_text',
                content: '📤 Push'
              },
              type: 'default',
              value: JSON.stringify({
                action: 'run_task',
                command: 'git push'
              })
            });
          }
          
          // Diff button removed per user request
          // if (staged.length > 0 || modified.length > 0) {
          //   gitActionButtons.push({
          //     tag: 'button',
          //     text: {
          //       tag: 'plain_text',
          //       content: '🔍 Diff'
          //     },
          //     type: 'default',
          //     value: JSON.stringify({
          //       action: 'run_task',
          //       command: 'git diff --stat'
          //     })
          //   });
          // }
          
          // Always add these useful buttons regardless of git status
          gitActionButtons.push({
            tag: 'button',
            text: {
              tag: 'plain_text',
              content: '📚 DOC'
            },
            type: 'default',
            value: JSON.stringify({
              action: 'run_task',
              command: 'ani-code doc'
            })
          });
          
        } else {
          // Check if there are unpushed commits even though working tree is clean
          if (hasUnpushedCommits) {
            statusMessage += `\n*📂 Git Status:* Clean (unpushed commits)\n`;
            
            // Add push button first for unpushed commits
            gitActionButtons.push({
              tag: 'button',
              text: {
                tag: 'plain_text',
                content: '📤 Push'
              },
              type: 'primary',
              value: JSON.stringify({
                action: 'run_task',
                command: 'git push'
              })
            });
          } else {
            statusMessage += `\n*📂 Git Status:* Clean\n`;
          }
          
          // Add useful buttons even when git is clean
          gitActionButtons.push({
            tag: 'button',
            text: {
              tag: 'plain_text',
              content: '📚 DOC'
            },
            type: 'default',
            value: JSON.stringify({
              action: 'run_task',
              command: 'ani-code doc'
            })
          });
          
          
          gitActionButtons.push({
            tag: 'button',
            text: {
              tag: 'plain_text',
              content: '📤 Pull'
            },
            type: 'default',
            value: JSON.stringify({
              action: 'run_task',
              command: 'git pull'
            })
          });
        }
      } catch (error) {
        // Not a git repository or git command failed
        if (error.message.includes('not a git repository')) {
          statusMessage += `\n**Git:** Not a repo`;
        } else {
          logger.debug(`Git status failed: ${error.message}`);
        }
      }
    }
    
    // Add workdir info at the bottom
    if (selectedWorkdirName) {
      statusMessage += `\n📁 **${selectedWorkdirName}**`;
    } else {
      statusMessage += `\n⚠️ No workdir selected - use /workdir`;
    }
    
    return { statusMessage, gitActionButtons };
  }

  async start() {
    // Load saved chat settings
    await this.chatSettings.load();
    
    // Start cleanup interval for all in-memory caches (every 30 seconds)
    this.cleanupInterval = setInterval(() => {
      const now = Date.now();
      let cleanedCount = 0;

      // Clean processedMessages (60 second TTL)
      for (const [messageId, timestamp] of this.processedMessages) {
        if (now - timestamp > 60000) {
          this.processedMessages.delete(messageId);
          cleanedCount++;
        }
      }

      // Clean recentImages (10 minute TTL)
      for (const [chatId, imageData] of this.recentImages) {
        if (now - imageData.timestamp > 600000) {
          this.recentImages.delete(chatId);
          cleanedCount++;
        }
      }

      // Clean pendingPrompts (5 minute TTL - safety net for missed timeouts)
      for (const [promptId, promptData] of this.pendingPrompts) {
        // promptId is timestamp in base36, convert back to check age
        const promptTimestamp = parseInt(promptId, 36);
        if (now - promptTimestamp > 300000) {
          this.pendingPrompts.delete(promptId);
          cleanedCount++;
        }
      }

      // Clean gitStatusCache (5 second TTL)
      for (const [key, cacheEntry] of this.gitStatusCache) {
        if (now - cacheEntry.timestamp > this.gitStatusCacheTTL) {
          this.gitStatusCache.delete(key);
          cleanedCount++;
        }
      }

      if (cleanedCount > 0) {
        logger.debug(`Cache cleanup: removed ${cleanedCount} expired entries`);
      }
    }, 30000);
    
    return new Promise((resolve, reject) => {
      this.server = createServer((req, res) => {
        this.handleRequest(req, res);
      });

      this.server.on('error', (error) => {
        logger.error('HTTP server error:', error);
        reject(error);
      });

      this.server.listen(config.http.port, config.http.host, () => {
        const actualPort = this.server.address().port;
        logger.debug(`HTTP callback server listening on ${config.http.host}:${actualPort}`);
        resolve(actualPort);
      });
    });
  }

  stop() {
    if (this.server) {
      this.server.close();
      this.server = null;
      logger.info('HTTP callback server stopped');
    }
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
    }
    
    // Clear all progress trackers
    if (this.progressTrackers.size > 0) {
      logger.info(`Cleaning up ${this.progressTrackers.size} progress trackers`);
      for (const [key, tracker] of this.progressTrackers) {
        if (tracker.interval) {
          clearInterval(tracker.interval);
        }
      }
      this.progressTrackers.clear();
    }
  }

  async handleRequest(req, res) {
    const url = parse(req.url, true);
    let { pathname } = url;

    // Check for CLI version header and log if mismatch (but don't block)
    const cliVersion = req.headers['x-cli-version'];
    if (cliVersion) {
      try {
        const packagePath = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'package.json');
        const { readFileSync } = await import('fs');
        const packageJson = JSON.parse(readFileSync(packagePath, 'utf8'));
        const daemonVersion = packageJson.version;

        if (cliVersion !== daemonVersion) {
          const cliParts = cliVersion.split('.').map(Number);
          const daemonParts = daemonVersion.split('.').map(Number);

          if (cliParts[0] !== daemonParts[0]) {
            logger.warn(`[HTTP Version] Major mismatch - CLI: ${cliVersion}, Daemon: ${daemonVersion}`);
          } else if (cliParts[1] !== daemonParts[1]) {
            logger.info(`[HTTP Version] Minor mismatch - CLI: ${cliVersion}, Daemon: ${daemonVersion}`);
          }
        }
      } catch {
        // Ignore version check errors
      }
    }

    // Log the original path for debugging (skip /health to reduce noise)
    if (pathname !== '/health') {
      logger.info(`[HTTP] Original request path: ${pathname}`);
    } else {
      logger.debug(`[HTTP] Health check received`);
    }

    // Handle proxy path prefix stripping
    // The proxy keeps the full path, so we need to strip the prefix
    const proxyPrefix = '/bmc-dev-tokyo-duke01/anicode-callback-6501';
    if (pathname.startsWith(proxyPrefix)) {
      pathname = pathname.substring(proxyPrefix.length) || '/';
      logger.info(`[HTTP] Stripped proxy prefix, new path: ${pathname}`);
    }
    
    // Set CORS headers for API and callbacks
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    
    // Set a response timeout to prevent hanging requests
    const responseTimeout = setTimeout(() => {
      if (!res.headersSent) {
        logger.warn(`Request timeout for ${pathname}`);
        this.sendError(res, 504, 'Gateway Timeout');
      }
    }, 30000); // 30 second timeout
    
    // Clean up timeout when response is sent
    const originalEnd = res.end;
    res.end = function(...args) {
      clearTimeout(responseTimeout);
      return originalEnd.apply(res, args);
    };
    
    if (req.method === 'OPTIONS') {
      res.writeHead(200);
      res.end();
      return;
    }

    try {
      // Goals API endpoints (no auth required - public access from gateway)
      if (pathname === '/api/goals' || pathname.startsWith('/api/goals/')) {
        await this.handleGoalsAPI(req, res, pathname, url.query);
      }
      // Tasks API endpoint (no auth required - public access from gateway for status)
      else if (pathname === '/api/tasks' || pathname === '/api/tasks/status') {
        await this.handleTasksStatusAPI(req, res, url.query);
      }
      // Tasks progress endpoint - returns live latestMessage + gitStatus for running tasks
      else if (pathname === '/api/tasks/progress') {
        await this.handleTasksProgressAPI(req, res);
      }
      // Cancel mode API endpoint (cancel yolo/goalloop mode)
      else if (pathname === '/api/tasks/cancel-mode') {
        await this.handleCancelModeAPI(req, res, url.query);
      }
      // Cancel individual task by ID: POST /api/tasks/:taskId/cancel
      else if (pathname.match(/^\/api\/tasks\/([^\/]+)\/cancel$/) && req.method === 'POST') {
        const taskId = pathname.match(/^\/api\/tasks\/([^\/]+)\/cancel$/)[1];
        await this.handleCancelTaskAPI(req, res, taskId);
      }
      // Stats usage v2 API endpoint - per-model token usage from task_usage_v2 table
      else if (pathname === '/api/stats/usage-v2') {
        await this.handleStatsUsageV2API(req, res, url.query);
      }
      // REST API endpoints moved to port 6502 (WebSocket service)
      // API requests should now go to port 6502 instead of 6501
      // else if (pathname.startsWith('/api/')) {
      //   await this.handleAPIRequest(req, res, pathname);
      // }
      else if (pathname === '/callback/lark' || pathname === '/lark') {
        // Handle both /callback/lark and /lark for proxy compatibility
        await this.handleLarkCallback(req, res);
      } else if (pathname === '/callback/telegram' || pathname === '/telegram') {
        // Handle both paths for telegram
        await this.handleTelegramCallback(req, res);
      } else if (pathname === '/health') {
        await this.handleHealthCheck(req, res);
      } else if (pathname === '/version') {
        await this.handleVersion(req, res);
      } else if (pathname === '/api/memory') {
        await this.handleMemoryStats(req, res);
      }
      // Chat UI display mode API endpoints (Goal 011)
      else if (pathname === '/api/chatui' || pathname === '/api/chatui/modes') {
        await this.handleChatUIAPI(req, res, pathname, url.query);
      }
      // API documentation moved to port 6502
      // else if (pathname === '/docs') {
      //   // Add direct /docs endpoint for proxy access
      //   await this.handleAPIDocumentation(req, res);
      // }
      else {
        this.sendError(res, 404, 'Not Found');
      }
    } catch (error) {
      logger.error('HTTP request error:', error);
      if (!res.headersSent) {
        this.sendError(res, 500, 'Internal Server Error');
      }
    }
  }

  /**
   * Handle Goals API endpoints
   * GET /api/goals - List all goals
   * GET /api/goals/:goalNumber - Get specific goal details
   */
  async handleGoalsAPI(req, res, pathname, query) {
    if (req.method !== 'GET') {
      this.sendError(res, 405, 'Method Not Allowed');
      return;
    }

    try {
      // Determine workspace directory - support workspace query parameter
      // Default to /workspace as per specification
      const workspaceDir = query.workspace || process.env.WORKSPACE || '/workspace';
      const goalsDir = path.join(workspaceDir, 'pd', 'goals');

      // Check if goals directory exists
      if (!fs.existsSync(goalsDir)) {
        // Return empty goals array with success=true (not 404)
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          success: true,
          goals: [],
          total: 0,
          source: 'filesystem',
          message: 'Goals directory does not exist yet',
          timestamp: new Date().toISOString()
        }));
        return;
      }

      // Parse pathname to check if requesting specific goal
      const goalNumberMatch = pathname.match(/^\/api\/goals\/(\d+)$/);

      if (goalNumberMatch) {
        // Handle GET /api/goals/:goalNumber
        await this.handleSingleGoal(req, res, parseInt(goalNumberMatch[1]), goalsDir);
      } else {
        // Handle GET /api/goals
        await this.handleGoalsList(req, res, query, goalsDir);
      }

    } catch (error) {
      logger.error('[Goals API] Error:', error);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: false,
        error: 'Failed to read goals',
        message: error.message
      }));
    }
  }

  /**
   * Handle GET /api/goals - List all goals
   */
  async handleGoalsList(req, res, query, goalsDir) {
    try {
      // Get query parameters
      const status = query.status;
      const limit = parseInt(query.limit) || 100;
      const offset = parseInt(query.offset) || 0;

      // Find and parse all goal files
      const goalFiles = findGoalFiles(goalsDir);
      const goals = [];

      for (const goalFile of goalFiles) {
        try {
          const parsed = parseGoalFile(goalFile);

          // Transform to API format
          const goal = {
            goal_number: parsed.id,
            title: parsed.title,
            status: parsed.status,
            objective: parsed.objective,
            progress: parsed.completionPercentage || 0,
            start_date: parsed.progress?.startDate || null,
            completion_date: parsed.progress?.completionDate || null,
            last_updated: new Date().toISOString(),
            tasks: parsed.tasks.map(t => ({
              title: t.description,
              completed: t.completed
            })),
            acceptance_criteria: [], // Not parsed in current implementation
            dependencies: [],
            file_path: `pd/goals/${parsed.file}`
          };

          goals.push(goal);
        } catch (err) {
          logger.warn(`[Goals API] Failed to parse goal file ${goalFile}:`, err.message);
        }
      }

      // Filter by status if requested
      let filteredGoals = goals;
      if (status) {
        const normalizedStatus = status.toLowerCase().replace(/_/g, ' ');
        filteredGoals = goals.filter(g => {
          const goalStatus = g.status.toLowerCase();
          return goalStatus === normalizedStatus ||
                 goalStatus.replace(/ /g, '_') === status.toLowerCase();
        });
      }

      // Sort by goal_number
      filteredGoals.sort((a, b) => (a.goal_number || 0) - (b.goal_number || 0));

      // Apply pagination
      const paginatedGoals = filteredGoals.slice(offset, offset + limit);

      // Send response
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: true,
        goals: paginatedGoals,
        total: filteredGoals.length,
        source: 'filesystem',
        timestamp: new Date().toISOString()
      }));

    } catch (error) {
      logger.error('[Goals API] Error listing goals:', error);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: false,
        error: 'Failed to list goals',
        message: error.message
      }));
    }
  }

  /**
   * Handle GET /api/goals/:goalNumber - Get specific goal
   */
  async handleSingleGoal(req, res, goalNumber, goalsDir) {
    try {
      // Find goal file by number
      const goalFiles = findGoalFiles(goalsDir);
      const goalFile = goalFiles.find(f => {
        const id = extractGoalId(path.basename(f));
        return id === goalNumber;
      });

      if (!goalFile) {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          success: false,
          error: 'Goal not found',
          goal_number: goalNumber
        }));
        return;
      }

      // Parse goal file
      const parsed = parseGoalFile(goalFile);
      const content = fs.readFileSync(goalFile, 'utf8');

      // Transform to API format with full content
      const goal = {
        goal_number: parsed.id,
        title: parsed.title,
        status: parsed.status,
        objective: parsed.objective,
        progress: parsed.completionPercentage || 0,
        start_date: parsed.progress?.startDate || null,
        completion_date: parsed.progress?.completionDate || null,
        last_updated: new Date().toISOString(),
        tasks: parsed.tasks.map(t => ({
          title: t.description,
          completed: t.completed
        })),
        acceptance_criteria: [],
        dependencies: [],
        file_path: `pd/goals/${parsed.file}`,
        file_content: content
      };

      // Send response
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: true,
        goal
      }));

    } catch (error) {
      logger.error('[Goals API] Error getting goal:', error);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: false,
        error: 'Failed to read goal',
        message: error.message
      }));
    }
  }

  /**
   * Extract execution mode from task source
   * Maps task source to standard mode names: yolo, goalloop, plan, or null
   * @param {Object} task - Task object with source and metadata properties
   * @returns {string|null} Mode name or null if no special mode
   */
  extractModeFromTask(task) {
    const source = task.source || task.metadata?.source;

    if (!source) return null;

    // Map source values to mode names
    if (source === 'yolo' || source === 'plan_execution') {
      return 'yolo';
    }
    if (source.includes('goal_loop') || source === 'goalloop') {
      return 'goalloop';
    }
    if (source.includes('plan') && source !== 'plan_execution') {
      return 'plan';
    }

    return null;
  }

  /**
   * Extract prompt text from task command
   * Handles -c commands, strips @@patterns, and truncates to 150 chars
   * @param {Object} task - Task object with command and name properties
   * @returns {string} Clean prompt text
   */
  extractPromptFromTask(task) {
    let promptText = task.name || '';

    // If command exists, extract the actual prompt
    if (task.command) {
      if (task.command.startsWith('-c')) {
        // Continue command - extract prompt after -c
        promptText = task.command.substring(2).trim()
          .replace('--dangerously-skip-permissions', '').trim() || promptText;
      } else if (!task.command.startsWith('shell:')) {
        // Regular command - use the command itself
        promptText = task.command;
      }
    }

    // Strip @@patterns (providers/models)
    promptText = stripPatternsFromPrompt(promptText);

    // Truncate to 150 chars if needed
    if (promptText.length > 150) {
      promptText = promptText.substring(0, 147) + '...';
    }

    return promptText || task.name || '';
  }

  /**
   * Extract provider slug from task
   * Priority: 1. providerId from task, 2. @@provider from command, 3. default 'anthropic'
   * @param {Object} task - Task object with providerId and command properties
   * @returns {string} Provider slug in lowercase
   */
  extractProviderFromTask(task) {
    // 1. Use task's providerId if available
    if (task.providerId) {
      return task.providerId.toLowerCase();
    }

    // 2. Check for @@provider in command
    if (task.command) {
      const providerFromCommand = extractProviderFromPrompt(task.command);
      if (providerFromCommand) {
        return providerFromCommand.toLowerCase();
      }
    }

    // 3. Check task name for @@provider
    if (task.name) {
      const providerFromName = extractProviderFromPrompt(task.name);
      if (providerFromName) {
        return providerFromName.toLowerCase();
      }
    }

    // 4. Default to anthropic (Claude)
    return 'anthropic';
  }

  extractUsageFromTask(task) {
    if (!task.usage) return null;
    return {
      tokens: task.usage.tokens || 0,
      inputTokens: task.usage.inputTokens || 0,
      outputTokens: task.usage.outputTokens || 0,
      cacheReadTokens: task.usage.cacheReadTokens || 0,
      cost: task.usage.cost || 0
    };
  }

  /**
   * Handle Tasks Status API - Public endpoint for gateway to get task status
   * GET /api/tasks - List current tasks with status
   * GET /api/tasks/status - Same, alias for compatibility
   *
   * Query params:
   *   status - Filter by status: running, pending, completed, failed, all (default: all)
   *   limit - Max tasks to return (default: 20)
   */
  async handleTasksStatusAPI(req, res, query) {
    if (req.method !== 'GET') {
      this.sendError(res, 405, 'Method Not Allowed');
      return;
    }

    try {
      const statusFilter = query.status || 'all';
      const limit = Math.min(parseInt(query.limit) || 20, 100);

      // Get current task status from task monitor
      const currentStatus = this.taskMonitor.getStatus();

      // Build task list
      let tasks = [];

      // Add running tasks
      if (statusFilter === 'all' || statusFilter === 'running') {
        tasks.push(...currentStatus.running.map(t => ({
          id: t.id,
          name: t.name,
          status: 'running',
          mode: this.extractModeFromTask(t),
          prompt: this.extractPromptFromTask(t),
          provider: this.extractProviderFromTask(t),
          startedAt: t.startedAt,
          elapsedSeconds: t.startedAt ? Math.floor((Date.now() - new Date(t.startedAt).getTime()) / 1000) : 0,
          workdir: t.cwd
        })));
      }

      // Add pending/queued tasks
      if (statusFilter === 'all' || statusFilter === 'pending' || statusFilter === 'queued') {
        tasks.push(...currentStatus.pending.map(t => ({
          id: t.id,
          name: t.name,
          status: 'pending',
          mode: this.extractModeFromTask(t),
          prompt: this.extractPromptFromTask(t),
          provider: this.extractProviderFromTask(t),
          queuedAt: t.addedAt,
          workdir: t.cwd
        })));
      }

      // Add completed tasks from recent history
      if (statusFilter === 'all' || statusFilter === 'completed') {
        const history = this.taskMonitor.getTaskHistory(limit);
        const completed = history.filter(t => t.status === 'completed');
        tasks.push(...completed.map(t => ({
          id: t.id,
          name: t.name,
          status: 'completed',
          mode: this.extractModeFromTask(t),
          prompt: this.extractPromptFromTask(t),
          provider: this.extractProviderFromTask(t),
          model: t.parsedModel || t.model || null,
          startedAt: t.startedAt,
          completedAt: t.completedAt,
          duration: t.duration,
          workdir: t.cwd,
          output: t.output || null,
          usage: this.extractUsageFromTask(t)
        })));
      }

      // Add failed tasks from recent history
      if (statusFilter === 'all' || statusFilter === 'failed') {
        const history = this.taskMonitor.getTaskHistory(limit);
        const failed = history.filter(t => t.status === 'failed' || t.status === 'error');
        tasks.push(...failed.map(t => ({
          id: t.id,
          name: t.name,
          status: 'failed',
          mode: this.extractModeFromTask(t),
          prompt: this.extractPromptFromTask(t),
          provider: this.extractProviderFromTask(t),
          model: t.parsedModel || t.model || null,
          startedAt: t.startedAt,
          completedAt: t.completedAt,
          error: t.error,
          workdir: t.cwd,
          output: t.output || null,
          usage: this.extractUsageFromTask(t)
        })));
      }

      // Apply limit
      tasks = tasks.slice(0, limit);

      // Calculate stats
      const stats = {
        running: currentStatus.running.length,
        pending: currentStatus.pending.length,
        completed: currentStatus.completed?.length || 0,
        failed: currentStatus.failed?.length || 0,
        total: tasks.length
      };

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: true,
        tasks,
        stats,
        timestamp: new Date().toISOString()
      }));

    } catch (error) {
      logger.error('[Tasks API] Error getting tasks:', error);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: false,
        error: 'Failed to get tasks',
        message: error.message
      }));
    }
  }

  /**
   * Handle Tasks Progress API - Returns live latestMessage + gitStatus for running tasks
   * GET /api/tasks/progress
   * Used by gateway to provide real-time task output to Launchpad UI
   */
  async handleTasksProgressAPI(req, res) {
    if (req.method !== 'GET') {
      this.sendError(res, 405, 'Method Not Allowed');
      return;
    }

    try {
      const currentStatus = this.taskMonitor.getStatus();
      const runningTasks = currentStatus.running || [];

      const progressPromises = runningTasks.map(async (task) => {
        const taskId = task.id;
        let latestMessage = null;
        let gitStatus = null;

        // Get latest output from session files / stdout buffer
        try {
          const providerId = task.providerId || 'claude';
          let isClaudeProvider = !providerId || providerId === 'claude' ||
            providerId.startsWith('custom') || providerId === 'ccr' || providerId === 'glm';

          if (!isClaudeProvider) {
            try {
              const { getProviderManager } = await import('./providers/providerManager.js');
              const providerManager = await getProviderManager();
              const handler = providerManager.getHandler(providerId);
              if (handler && typeof handler.isCustomClaude === 'function') {
                isClaudeProvider = true;
              }
            } catch (e) { /* ignore */ }
          }

          if (isClaudeProvider && task.cwd) {
            const printContent = await this.getPrintContentForWorkspace(task.cwd, 800, {
              taskStartTime: task.startedAt
            });
            if (printContent && printContent.content) {
              latestMessage = {
                content: printContent.content,
                truncated: printContent.truncated || false
              };
            }
          } else {
            const taskOutput = this.taskMonitor.getTaskOutput(taskId, 'stdout', 50);
            if (taskOutput && Array.isArray(taskOutput) && taskOutput.length > 0) {
              let rawOutput = taskOutput.join('\n');
              const { extractProviderConclusion } = await import('./providers/outputExtractor.js');
              rawOutput = extractProviderConclusion(rawOutput, providerId);
              const truncated = rawOutput.length > 800;
              const content = truncated ? rawOutput.slice(-800) : rawOutput;
              latestMessage = { content, truncated };
            }
          }
        } catch (err) {
          logger.debug(`[Tasks Progress] Failed to get output for task ${taskId}: ${err.message}`);
        }

        // Get git status
        if (task.cwd) {
          try {
            const { execSync } = await import('child_process');
            const statusOutput = execSync('git status --porcelain', {
              cwd: task.cwd, encoding: 'utf8', timeout: 5000
            }).trim();

            if (statusOutput) {
              const files = statusOutput.split('\n').map(line => {
                const trimmed = line.trim();
                const [status, ...fileParts] = trimmed.split(/\s+/);
                return { status, path: fileParts.join(' ') };
              });

              // Categorize files by task timing
              const { duringTask, beforeTask } = categorizeGitFilesByTaskTiming(statusOutput, task.cwd, task.startedAt);

              let diffStats = null;
              try {
                const diffOutput = execSync('git diff --shortstat', {
                  cwd: task.cwd, encoding: 'utf8', timeout: 5000
                }).trim();
                const diffMatch = diffOutput.match(/(\d+)\s+files?\s+changed(?:,\s*(\d+)\s+insertions?\(\+\))?(?:,\s*(\d+)\s+deletions?\(-\))?/);
                if (diffMatch) {
                  diffStats = {
                    insertions: parseInt(diffMatch[2], 10) || 0,
                    deletions: parseInt(diffMatch[3], 10) || 0
                  };
                }
              } catch (e) { /* ignore */ }

              gitStatus = {
                filesCount: files.length,
                files: files.slice(0, 10),
                changedDuringTask: duringTask.length,
                uncommittedBefore: beforeTask.length,
                diffStats
              };
            }
          } catch (err) {
            logger.debug(`[Tasks Progress] Failed to get git status for task ${taskId}: ${err.message}`);
          }
        }

        return {
          taskId,
          taskName: task.name,
          command: this.extractPromptFromTask(task),
          latestMessage,
          gitStatus,
          elapsedSeconds: task.startedAt ? Math.floor((Date.now() - new Date(task.startedAt).getTime()) / 1000) : 0,
          timestamp: task.startedAt || new Date().toISOString()
        };
      });

      const tasks = await Promise.all(progressPromises);

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: true,
        data: { tasks, count: tasks.length },
        source: 'daemon-api'
      }));
    } catch (error) {
      logger.error('[Tasks Progress API] Error:', error);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: false,
        error: 'Failed to get task progress',
        message: error.message
      }));
    }
  }

  /**
   * Handle Cancel Mode API - Cancel yolo or goalloop mode execution
   * POST /api/tasks/cancel-mode
   *
   * Body params:
   *   mode - Mode to cancel: 'yolo' or 'goalloop'
   *   workdir - Optional: workspace directory to cancel mode for
   *   workspaceId - Optional: workspace ID to cancel mode for
   */
  async handleCancelModeAPI(req, res, query) {
    if (req.method !== 'POST') {
      this.sendError(res, 405, 'Method Not Allowed');
      return;
    }

    try {
      // Parse request body
      let body = {};
      try {
        const bodyStr = await this.readRequestBody(req);
        if (bodyStr) {
          body = JSON.parse(bodyStr);
        }
      } catch (parseError) {
        // Use query params as fallback
        body = query;
      }

      const mode = body.mode || query.mode;
      const workdir = body.workdir || query.workdir;
      const workspaceId = body.workspaceId || query.workspaceId;

      if (!mode) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          success: false,
          error: 'Missing required parameter: mode',
          message: 'Specify mode to cancel: yolo or goalloop'
        }));
        return;
      }

      if (!['yolo', 'goalloop'].includes(mode.toLowerCase())) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          success: false,
          error: 'Invalid mode',
          message: 'Mode must be "yolo" or "goalloop"'
        }));
        return;
      }

      const normalizedMode = mode.toLowerCase();
      let cancelled = [];
      let modeCleared = false;

      // Get current running tasks
      const currentStatus = this.taskMonitor.getStatus();

      // Find tasks matching the mode
      const modeTasks = currentStatus.running.filter(t => {
        const taskMode = this.extractModeFromTask(t);
        return taskMode === normalizedMode;
      });

      // Also check pending tasks
      const pendingModeTasks = currentStatus.pending.filter(t => {
        const taskMode = this.extractModeFromTask(t);
        return taskMode === normalizedMode;
      });

      // Cancel all running tasks of this mode
      for (const task of modeTasks) {
        const result = this.taskMonitor.cancelTask(task.id);
        if (result.success) {
          cancelled.push({ id: task.id, name: task.name, status: 'cancelled' });
        }
      }

      // Cancel all pending tasks of this mode
      for (const task of pendingModeTasks) {
        const result = this.taskMonitor.cancelTask(task.id);
        if (result.success) {
          cancelled.push({ id: task.id, name: task.name, status: 'cancelled' });
        }
      }

      // Clear yolo mode from workspace if applicable
      if (normalizedMode === 'yolo' && this.workspaceManager) {
        try {
          let workspace = null;

          if (workspaceId) {
            workspace = await this.workspaceManager.getWorkspaceById(workspaceId);
          } else if (workdir) {
            workspace = await this.workspaceManager.getWorkspaceByPath(workdir);
          } else if (modeTasks.length > 0 && modeTasks[0].cwd) {
            // Try to get workspace from cancelled task's workdir
            workspace = await this.workspaceManager.getWorkspaceByPath(modeTasks[0].cwd);
          }

          if (workspace) {
            const yoloStatus = await this.workspaceManager.getYoloStatus(workspace.id);
            if (yoloStatus && yoloStatus.active) {
              await this.workspaceManager.clearYoloMode(workspace.id);
              modeCleared = true;
              logger.info(`[Cancel Mode API] Cleared yolo mode for workspace ${workspace.id}`);
            }
          }
        } catch (clearError) {
          logger.error('[Cancel Mode API] Failed to clear yolo mode:', clearError);
        }
      }

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: true,
        mode: normalizedMode,
        cancelled: cancelled,
        cancelledCount: cancelled.length,
        modeCleared: modeCleared,
        message: cancelled.length > 0
          ? `Cancelled ${cancelled.length} ${normalizedMode} task(s)`
          : `No active ${normalizedMode} tasks found`,
        timestamp: new Date().toISOString()
      }));

    } catch (error) {
      logger.error('[Cancel Mode API] Error:', error);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: false,
        error: 'Failed to cancel mode',
        message: error.message
      }));
    }
  }

  /**
   * Handle Cancel Task API - Cancel individual task by ID
   * POST /api/tasks/:taskId/cancel
   */
  async handleCancelTaskAPI(req, res, taskId) {
    try {
      logger.info(`[Cancel Task API] Cancelling task: ${taskId}`);

      if (!this.taskMonitor) {
        res.writeHead(503, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          success: false,
          error: 'Task monitor not available'
        }));
        return;
      }

      const result = this.taskMonitor.cancelTask(taskId);

      if (result.success) {
        logger.info(`[Cancel Task API] Task ${taskId} cancelled successfully`);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          success: true,
          taskId: taskId,
          message: 'Task cancelled successfully',
          timestamp: new Date().toISOString()
        }));
      } else {
        logger.warn(`[Cancel Task API] Failed to cancel task ${taskId}: ${result.error}`);
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          success: false,
          error: result.error || 'Task not found or already completed',
          taskId: taskId
        }));
      }
    } catch (error) {
      logger.error('[Cancel Task API] Error:', error);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: false,
        error: 'Failed to cancel task',
        message: error.message
      }));
    }
  }

  /**
   * Handle Stats Usage V2 API - Per-model token usage from task_usage_v2 table
   * GET /api/stats/usage-v2
   *
   * Query params:
   *   - since: Unix timestamp (seconds) - only return records after this time
   *   - until: Unix timestamp (seconds) - only return records before this time
   *   - days: Number of days to look back (default: 7, max: 90)
   *   - aggregated: 'true'|'false' (default: true) - return aggregated or daily breakdown
   */
  async handleStatsUsageV2API(req, res, query) {
    if (req.method !== 'GET') {
      res.writeHead(405, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: false, error: 'Method Not Allowed' }));
      return;
    }

    try {
      const { getStatsDB } = await import('./stats-db.js');
      const statsDB = getStatsDB();

      if (!statsDB) {
        res.writeHead(503, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          success: false,
          error: 'Stats database not available'
        }));
        return;
      }

      // Parse query parameters
      const days = Math.min(Math.max(parseInt(query.days) || 7, 1), 90);
      const aggregated = query.aggregated !== 'false';
      const since = query.since ? parseInt(query.since) * 1000 : null; // Convert to ms
      const until = query.until ? parseInt(query.until) * 1000 : null;

      let usageData;
      if (aggregated) {
        // Get aggregated usage by model - pass since/until for proper filtering
        usageData = statsDB.getModelUsageStats(days, since, until);
      } else {
        // Get daily breakdown - pass since/until for proper filtering
        usageData = statsDB.getDailyModelUsage(days, since, until);
      }

      // Calculate totals
      const totals = usageData.reduce((acc, item) => {
        acc.inputTokens += parseInt(item.totalInputTokens || item.inputTokens || 0);
        acc.inputCachedTokens += parseInt(item.totalInputCachedTokens || item.inputCachedTokens || 0);
        acc.outputTokens += parseInt(item.totalOutputTokens || item.outputTokens || 0);
        acc.costUsd += parseFloat(item.totalCost || item.cost || 0);
        acc.taskCount += parseInt(item.taskCount || 0);
        return acc;
      }, { inputTokens: 0, inputCachedTokens: 0, outputTokens: 0, costUsd: 0, taskCount: 0 });

      // Get task stats with duration data
      const startDate = since ? new Date(since) : new Date(Date.now() - days * 24 * 60 * 60 * 1000);
      const endDate = until ? new Date(until) : new Date();
      const taskStats = statsDB.getTaskStats(startDate, endDate);

      // Format response matching gateway expectations
      const response = {
        success: true,
        timestamp: new Date().toISOString(),
        usageByModel: usageData.map(item => ({
          modelId: item.modelId,
          providerId: item.providerId || 'claude',
          inputTokens: parseInt(item.totalInputTokens || item.inputTokens || 0),
          inputCachedTokens: parseInt(item.totalInputCachedTokens || item.inputCachedTokens || 0),
          outputTokens: parseInt(item.totalOutputTokens || item.outputTokens || 0),
          costUsd: parseFloat(item.totalCost || item.cost || 0),
          taskCount: parseInt(item.taskCount || 0),
          ...(item.day && { day: item.day })
        })),
        totals: {
          inputTokens: totals.inputTokens,
          inputCachedTokens: totals.inputCachedTokens,
          outputTokens: totals.outputTokens,
          totalTokens: totals.inputTokens + totals.outputTokens,
          costUsd: Math.round(totals.costUsd * 10000) / 10000,
          taskCount: totals.taskCount,
          // Duration stats from task_stats table
          avgDurationMs: taskStats?.avgDurationMs || null,
          minDurationMs: taskStats?.minDurationMs || null,
          maxDurationMs: taskStats?.maxDurationMs || null,
          totalDurationMs: taskStats?.totalDurationMs || null,
          completedTasks: taskStats?.completedTasks || 0,
          failedTasks: (taskStats?.cancelledTasks || 0) + (taskStats?.errorTasks || 0)
        },
        timeRange: {
          days,
          since: since ? new Date(since).toISOString() : null,
          until: until ? new Date(until).toISOString() : null
        }
      };

      res.writeHead(200, {
        'Content-Type': 'application/json',
        'Cache-Control': 'max-age=30'
      });
      res.end(JSON.stringify(response));

    } catch (error) {
      logger.error('[Stats Usage V2 API] Error:', error);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: false,
        error: 'Failed to get usage stats',
        message: error.message
      }));
    }
  }

  async handleLarkCallback(req, res) {
    // Log incoming request
    logger.debug('Lark callback received:', req.url);
    
    if (req.method !== 'POST') {
      this.sendError(res, 405, 'Method Not Allowed');
      return;
    }

    let body;
    try {
      body = await this.readRequestBody(req);
    } catch (error) {
      logger.error('Failed to read request body:', error);
      this.sendError(res, 400, 'Invalid request body');
      return;
    }
    
    try {
      const data = JSON.parse(body);
      
      // Log full JSON for debugging (truncate if too large)
      const jsonStr = JSON.stringify(data, null, 2);
      if (jsonStr.length > 5000) {
        logger.debug('Lark callback data (truncated):', jsonStr.substring(0, 5000) + '...[truncated]');
      } else {
        logger.debug('Lark callback data:', jsonStr);
      }
      
      // Log callback type properly - handle object actions
      let callbackType = 'unknown';
      if (data.type) {
        callbackType = data.type;
      } else if (data.action) {
        // Handle action that might be an object
        if (typeof data.action === 'object') {
          callbackType = `action:${data.action.value ? 'card_action' : 'object'}`;
        } else {
          callbackType = `action:${data.action}`;
        }
      } else if (data.schema === '2.0' && data.header) {
        callbackType = `v2.0:${data.header.event_type || 'unknown'}`;
      }
      
      logger.info(`Lark callback type: ${callbackType}, timestamp: ${new Date().toISOString()}`);
      
      // Handle Lark URL verification challenge - MUST respond immediately
      if (data.type === 'url_verification') {
        logger.info('Received Lark URL verification challenge');
        
        // Verify token if configured
        if (config.lark.verificationToken && 
            data.token !== config.lark.verificationToken) {
          logger.error('Invalid verification token');
          this.sendError(res, 401, 'Unauthorized');
          return;
        }
        
        // Return the challenge code immediately
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ challenge: data.challenge }));
        logger.info('Lark URL verification successful');
        return;
      }
      
      // Handle event callbacks (messages from Lark bot)
      if (data.type === 'event_callback') {
        logger.debug('Received Lark event callback');
        
        // Verify token if configured
        if (config.lark.verificationToken && 
            data.token !== config.lark.verificationToken) {
          logger.error('Invalid verification token');
          this.sendError(res, 401, 'Unauthorized');
          return;
        }
        
        // Process the event
        const result = await this.processLarkEvent(data);
        this.sendSuccess(res, result);
        return;
      }
      
      // Handle Lark v2.0 schema events
      if (data.schema === '2.0' && data.header && data.event) {
        logger.debug('Received Lark v2.0 event - Type:', data.header.event_type);
        
        // Verify token if configured
        if (config.lark.verificationToken && 
            data.header.token !== config.lark.verificationToken) {
          logger.error('Invalid verification token');
          this.sendError(res, 401, 'Unauthorized');
          return;
        }
        
        // Process the v2.0 event
        const result = await this.processLarkV2Event(data);
        this.sendSuccess(res, result);
        return;
      }
      
      // Handle custom commands (backward compatibility)
      logger.debug('Received Lark custom command');
      
      // Handle card button actions (action is an object with value and tag)
      if (data.action && typeof data.action === 'object' && data.action.value) {
        try {
          // Parse the nested JSON in action.value
          const actionValue = JSON.parse(JSON.parse(data.action.value));
          logger.debug(`Card action: ${actionValue.action}${actionValue.taskId ? `, task=${actionValue.taskId}` : ''}${actionValue.workdir ? `, workdir=${actionValue.workdir}` : ''}`);
          
          // Process the card action
          const result = await this.processCardAction(actionValue, data);
          this.sendSuccess(res, result);
        } catch (parseError) {
          logger.error('Failed to parse card action:', parseError);
          this.sendError(res, 400, 'Invalid card action data');
        }
      } 
      // Handle old-style direct actions (action is a string)
      else if (data.action && typeof data.action === 'string') {
        const result = await this.processLarkCommand(data);
        this.sendSuccess(res, result);
      } else {
        // Log unrecognized format with proper JSON output
        logger.warn('Received unrecognized Lark callback format');
        logger.warn('Full callback data:', JSON.stringify(data, null, 2));
        
        // Always return success to prevent Lark from retrying
        this.sendSuccess(res, {
          success: true,
          message: 'Event received but no action specified',
          type: callbackType
        });
      }
    } catch (error) {
      logger.error('Failed to process Lark callback:', error);
      logger.error('Error stack:', error.stack);
      // Return success to prevent Lark from retrying
      this.sendSuccess(res, {
        success: true,
        message: 'Event received with error'
      });
    }
  }

  async processLarkEvent(data) {
    const event = data.event;
    const header = data.header; // Add this line to extract header from data
    
    // Log event type for debugging
    logger.debug('Processing Lark event:', data.type || 'unknown');
    
    // Extract chat ID for logging (only log if found)
    if (event) {
      let chatId = null;
      
      // Check multiple possible locations for chat ID
      if (event.message && event.message.chat_id) {
        chatId = event.message.chat_id;
      } else if (event.chat_id) {
        chatId = event.chat_id;
      } else if (event.open_chat_id) {
        chatId = event.open_chat_id;
      }
      
      if (chatId) {
        logger.debug(`Chat ID: ${chatId}`);
      }
    }
    
    // Handle card action events
    if (event && event.type === 'card.action.trigger') {
      const action = event.action;
      logger.debug('Received card action');
      
      if (action && action.value) {
        const value = typeof action.value === 'string' ? 
          JSON.parse(action.value) : action.value;
        
        switch (value.action) {
          case 'cancel_task':
            const cancelled = this.taskMonitor.cancelTask(value.taskId);

            // cancelTask returns { success: boolean, message: string }
            // No need for additional notification - task status will be updated
            return cancelled;
            
          case 'retry_task':
            // Retry the task with the same command
            const originalTask = this.taskMonitor.getTaskById(value.taskId);
            if (originalTask) {
              const newTask = this.taskMonitor.addTask(
                `Retry: ${originalTask.name}`,
                originalTask.command,
                {
                  cwd: originalTask.cwd || process.cwd(),
                  source: 'lark_card_retry',
                  chatId: originalTask.chatId  // Preserve original chat ID
                }
              );
              
              return {
                success: true,
                taskId: newTask.id,
                message: `Retrying task as ${newTask.id}`
              };
            }
            
            return {
              success: false,
              message: `Original task ${value.taskId} not found`
            };
            
          case 'view_logs':
            // Return task logs
            const task = this.taskMonitor.getTaskById(value.taskId);
            if (task) {
              return {
                success: true,
                data: {
                  taskId: task.id,
                  name: task.name,
                  status: task.status,
                  output: task.output,
                  error: task.error
                }
              };
            }
            
            return {
              success: false,
              message: `Task ${value.taskId} not found`
            };
            
          default:
            return {
              success: false,
              message: `Unknown action: ${value.action}`
            };
        }
      }
    }
    
    // Skip the legacy handler if this is a v1.0 event that will be processed below
    if (header && header.event_type === 'im.message.receive_v1') {
      logger.info('Skipping legacy handler for v1.0 message event');
      // This will be processed by the v1.0 handler below
    }
    // Handle message events (v1.0 format)
    else if (event && (event.type === 'message' || event.message)) {
      logger.info('Processing message event (v1.0 handler)...');
      // Extract message details - Lark uses nested structure
      const messageObj = event.message || event;
      
      // Log message details
      const messageId = messageObj.message_id || event.message_id;
      const messageCreateTime = messageObj.create_time;
      const chatId = messageObj.chat_id || event.chat_id;
      
      // Parse message text
      let messageText = '';
      try {
        if (messageObj.content) {
          const content = JSON.parse(messageObj.content);
          messageText = content.text || '';
        } else if (event.text) {
          messageText = event.text;
        }
      } catch (e) {
        messageText = messageObj.content || event.text || '';
      }
      
      logger.info(`📨 V1.0 Message received:
  Message ID: ${messageId}
  Chat ID: ${chatId}
  Create Time: ${messageCreateTime} (${messageCreateTime ? new Date(parseInt(messageCreateTime)).toISOString() : 'N/A'})
  Current Time: ${Date.now()} (${new Date().toISOString()})
  Message Text: ${messageText.substring(0, 100)}${messageText.length > 100 ? '...' : ''}`);
      
      // Check for duplicate message using message_id
      if (messageId) {
        if (this.processedMessages.has(messageId)) {
          logger.info(`✋ Duplicate message detected (v1.0): ${messageId}, ignoring`);
          return {
            success: true,
            message: 'Duplicate message ignored'
          };
        }
        // Store the message ID with current timestamp
        this.processedMessages.set(messageId, Date.now());
        logger.debug(`Stored message ID (v1.0): ${messageId} for deduplication`);
      }
      
      // Check message age for v1.0 events
      if (messageObj.create_time) {
        const messageAge = Date.now() - parseInt(messageObj.create_time);
        if (messageAge > this.MAX_MESSAGE_AGE_MS) {
          logger.warn(`⏰ STALE MESSAGE REJECTED (v1.0):
  Message ID: ${messageId}
  Chat ID: ${chatId}
  Message Age: ${Math.round(messageAge/1000)} seconds (>${this.MAX_MESSAGE_AGE_MS/1000}s threshold)
  Create Time: ${new Date(parseInt(messageObj.create_time)).toISOString()}
  Current Time: ${new Date().toISOString()}
  Message Text: ${messageText.substring(0, 50)}${messageText.length > 50 ? '...' : ''}`);
          return {
            success: true,
            message: 'Stale message ignored'
          };
        } else {
          logger.debug(`✅ Message age check passed: ${Math.round(messageAge/1000)}s old (within ${this.MAX_MESSAGE_AGE_MS/1000}s threshold)`);
        }
      }
      
      // Continue processing the message
      let message = messageText;  // Already parsed above
      const sender = event.sender ? event.sender.sender_id : (event.sender_id || 'unknown');
      
      // Log sender info
      logger.debug(`Message sender: ${sender}`);
      
      // Strip Lark mention tags like <at open_id="...">@BotName</at>
      message = message.replace(/<at[^>]*>.*?<\/at>/g, '').trim();
      
      // Parse command from message
      // Expected format: /command [args]
      if (message.startsWith('/')) {
        const parts = message.slice(1).split(' ');
        const command = parts[0];
        const args = parts.slice(1).join(' ');
        
        switch (command) {
          case 'add': {
            // Handle /add command for Claude task creation
            if (!args) {
              return {
                success: false,
                message: 'Prompt is required for /add'
              };
            }

            // Get workdir for this chat
            const selectedWorkdirName = chatId ? this.chatSettings.getWorkdir(chatId) : null;
            const availableWorkdirs = config.lark.workdirs;
            const selectedWorkdirPath = selectedWorkdirName ? availableWorkdirs[selectedWorkdirName] : null;

            if (!selectedWorkdirPath) {
              return {
                success: false,
                message: 'Working directory not set. Use /workdir [name] to set'
              };
            }

            // Process any preset templates in the prompt
            const presetResult = await processPresets(args);
            const processedPrompt = presetResult.text;

            // Create the Claude task - pass prompt directly to claude
            const taskName = `claude-add-${Date.now()}`;
            // Pass the prompt directly to claude (without -c flag for new task)
            const claudeCommand = processedPrompt;

            const taskOptions = {
              cwd: selectedWorkdirPath,
              source: 'lark_add_command',
              chatId: chatId,  // Store chat ID for response routing
              providerId: await this.getCurrentProviderId()  // Track provider for footer/usage display
            };

            const task = this.taskMonitor.addTask(taskName, claudeCommand, taskOptions);
            
            logger.info(`Created Claude add task: ${task.id} in ${selectedWorkdirPath}`);
            
            return {
              success: true,
              message: `Claude task created with ID: ${task.id}`,
              taskId: task.id
            };
          }
          
          case 'grant': {
            // Handle /grant command for permission review
            const selectedWorkdirName = chatId ? this.chatSettings.getWorkdir(chatId) : null;
            const availableWorkdirs = config.lark.workdirs;
            const selectedWorkdirPath = selectedWorkdirName ? availableWorkdirs[selectedWorkdirName] : null;

            if (!selectedWorkdirPath) {
              return {
                success: false,
                message: 'Working directory not set. Use /workdir [name] to set'
              };
            }

            const grantPrompt = `You are in High Privilege Mode for permission management.

## Task
Review the last Claude message in the conversation history and identify any permission blocks or denied operations.

## Analysis Steps
1. Check the last message for:
   - Permission errors ("This tool requires approval", "permission denied")
   - Blocked Bash commands
   - Blocked file operations (Read/Write/Edit)
   - Blocked MCP function calls
   - Tool use errors related to permissions

2. Identify the permission pattern needed:
   - Bash commands: \`Bash(command:*)\`
   - File reads: \`Read(path)\` or \`Read(path/**/*)\`
   - File writes: \`Write(path)\` or \`Write(path/**/*)\`
   - File edits: \`Edit(path)\` or \`Edit(path/**/*)\`
   - MCP tools: \`mcp__server__function(*)\`

3. Update .claude/settings.local.json (PREFERRED over .claude/settings.json):
   - ALWAYS prefer modifying \`.claude/settings.local.json\` instead of \`.claude/settings.json\` to resolve permission issues
   - \`.claude/settings.local.json\` is the local override file and should be used for per-machine permission grants
   - Only modify \`.claude/settings.json\` if explicitly instructed to do so
   - Add permission to permissions.allow array
   - Use wildcards appropriately for flexibility
   - Keep alphabetical order within sections
   - Ensure valid JSON syntax
   - If the file doesn't exist, create it with proper structure

4. Report back:
   - What permission was blocked
   - What pattern was added
   - Confirmation the file was updated
   - Do NOT re-execute the originally blocked operation — only resolve the permission and describe what you did
   - The user will retry the operation themselves

${args ? `\n## Additional Instructions\n${args}\n` : ''}

## Example Permission Patterns
- \`Bash(npm install:*)\` - npm install commands
- \`Bash(python3:*)\` - Python 3 scripts
- \`Bash(curl:*)\` - curl requests
- \`Read(/etc/**/*)\` - Read files in /etc
- \`Write(/tmp/**/*)\` - Write to tmp
- \`Edit(./**/*)\` - Edit any file in current dir

## Important Guidelines
- Be specific but not overly restrictive
- Use wildcards to avoid repeated approvals
- Never grant overly broad permissions like \`Bash(*)\`
- Preserve all existing permissions
- Validate JSON before saving
- ALWAYS use \`.claude/settings.local.json\` — never modify \`.claude/settings.json\` unless explicitly asked
- Only resolve the permission issue and report what was done — do NOT execute the originally blocked operation
- If no permission issues found, report "No permission issues detected"

Now analyze the conversation and grant necessary permissions.`;

            const taskName = `claude-grant-${Date.now()}`;
            const task = this.taskMonitor.addTask(
              taskName,
              `-c --dangerously-skip-permissions ${grantPrompt}`,
              {
                cwd: selectedWorkdirPath,
                source: 'lark_grant',
                chatId
              }
            );

            return {
              success: true,
              message: `Permission review task created with ID: ${task.id}`,
              taskId: task.id
            };
          }

          case 'continue': {
            // Handle /continue command for Claude task continuation
            // Get workdir for this chat
            const selectedWorkdirName = chatId ? this.chatSettings.getWorkdir(chatId) : null;
            const availableWorkdirs = config.lark.workdirs;
            const selectedWorkdirPath = selectedWorkdirName ? availableWorkdirs[selectedWorkdirName] : null;

            if (!selectedWorkdirPath) {
              return {
                success: false,
                message: 'Working directory not set. Use /workdir [name] to set'
              };
            }

            // Process any preset templates in the prompt
            const presetResult = args ? await processPresets(args) : { text: null, presets: [] };
            const processedPrompt = presetResult.text;

            // Create the Claude continue task - pass prompt with -c flag to claude
            const taskName = `claude-continue-${Date.now()}`;
            // Pass the prompt with -c flag to continue from previous context
            // If no args provided, use 'continue' as default prompt
            const claudeCommand = processedPrompt ?
              `-c ${processedPrompt}` :
              `-c continue`;

            const taskOptions = {
              cwd: selectedWorkdirPath,
              source: 'lark_continue_command',
              chatId: chatId,  // Store chat ID for response routing
              providerId: await this.getCurrentProviderId()  // Track provider for footer/usage display
            };

            const task = this.taskMonitor.addTask(taskName, claudeCommand, taskOptions);
            
            logger.info(`Created Claude continue task: ${task.id} in ${selectedWorkdirPath}`);
            
            return {
              success: true,
              message: `Claude continue task created with ID: ${task.id}`,
              taskId: task.id
            };
          }

          case 'plan': {
            // Handle /plan command for creating task plans
            try {
              const { WorkspaceManager } = await import('./workspace-manager.js');
              const manager = new WorkspaceManager();
              await manager.initialize();

              // Get workspace for this chat
              let workspace;
              if (chatId && chatId.startsWith('telegram:')) {
                // For Telegram chats, use the specialized method
                const telegramChatId = chatId.replace('telegram:', '');
                workspace = await manager.getWorkspaceForTelegramChat(telegramChatId);
              } else {
                // For other chats (Lark), use the regular method
                workspace = await manager.getWorkspaceForChat(chatId);
              }

              if (!workspace) {
                // In gateway mode, ensure gateway workspace exists in database
                if (config.gateway.enabled) {
                  workspace = await manager.ensureGatewayWorkspace();
                  logger.debug('Gateway mode: Using gateway workspace for /plan');
                } else {
                  return {
                    success: false,
                    message: 'No workspace connected. Use /connect <token> to connect.'
                  };
                }
              }

              if (!args) {
                return {
                  success: false,
                  message: 'Please provide plan steps. Example: /plan\n- Fix login bug\n- Add tests\n- Deploy'
                };
              }

              // Check if the plan contains preset references (starts with @)
              if (args.trim().match(/^@[\w.-]+\.md/im) || args.includes('@preset') || args.match(/@[\w.-]+\.md/)) {
                await manager.close();
                return {
                  success: false,
                  message: '❌ Plan creation failed\n\nPreset expansion is not supported in /plan command.\n\n⚠️ Each line in a plan can expand to multiple tasks, which could result in unexpectedly long plans.\n\n💡 Please:\n  • Write out steps manually without presets\n  • Use presets with /remember instead'
                };
              }

              // Process any preset templates in the args (safety check, should not match after validation above)
              const presetResult = await processPresets(args);
              const processedArgs = presetResult.text;

              // If presets were found, notify the user and reject (redundant safety check)
              if (presetResult.presets && presetResult.presets.length > 0) {
                await manager.close();
                return {
                  success: false,
                  message: `❌ Plan creation failed\n\nPreset expansion is not supported in /plan command.\n\nFound preset references:\n${presetResult.presets.map(p => `  • ${p.file}`).join('\n')}`
                };
              }

              // Treat entire chat input as a single step (no multi-step breakdown)
              const stepContent = processedArgs.trim();

              if (!stepContent) {
                await manager.close();
                return {
                  success: false,
                  message: 'No valid content found in plan'
                };
              }

              // Single step from entire input
              const steps = [stepContent];

              // Create the plan
              const isFromTelegram = chatId && chatId.startsWith('telegram:');
              const planData = {
                title: stepContent.split('\n')[0].substring(0, 50),
                description: processedArgs,
                steps: steps,
                createdBy: isFromTelegram ? chatId : `lark:${chatId}`,
                metadata: {
                  source: isFromTelegram ? 'telegram' : 'lark',
                  chatId: chatId,
                  timestamp: new Date().toISOString()
                }
              };

              const result = await manager.createPlan(workspace.id, planData);
              await manager.close();

              logger.info(`Created plan ${result.planId} with ${steps.length} steps`);

              return {
                success: true,
                message: `Plan created: ${result.planId}\nSteps: ${steps.length}\n\nExecute with: /next or /next ${result.planId}`,
                planId: result.planId
              };
            } catch (error) {
              logger.error(`Failed to create plan: ${error.message}`);
              return {
                success: false,
                message: `Failed to create plan: ${error.message}`
              };
            }
          }

          case 'next': {
            // Handle /next command for executing plans
            try {
              const { WorkspaceManager } = await import('./workspace-manager.js');
              const manager = new WorkspaceManager();
              await manager.initialize();

              // Get workspace for this chat
              let workspace;
              if (chatId && chatId.startsWith('telegram:')) {
                // For Telegram chats, use the specialized method
                const telegramChatId = chatId.replace('telegram:', '');
                workspace = await manager.getWorkspaceForTelegramChat(telegramChatId);
              } else {
                // For other chats (Lark), use the regular method
                workspace = await manager.getWorkspaceForChat(chatId);
              }

              if (!workspace) {
                // In gateway mode, ensure gateway workspace exists in database
                if (config.gateway.enabled) {
                  workspace = await manager.ensureGatewayWorkspace();
                  logger.debug('Gateway mode: Using gateway workspace for /next');
                } else {
                  return {
                    success: false,
                    message: 'No workspace connected. Use /connect <token> to connect.'
                  };
                }
              }

              // Get the plan
              let plan;
              if (args) {
                plan = await manager.getPlan(workspace.id, args);
                if (!plan) {
                  await manager.close();
                  return {
                    success: false,
                    message: `Plan not found: ${args}`
                  };
                }
              } else {
                plan = await manager.getNextPlan(workspace.id);
                if (!plan) {
                  await manager.close();
                  return {
                    success: false,
                    message: 'No pending plans found. Create a plan with: /plan <steps>'
                  };
                }
              }

              const steps = plan.steps;
              const currentStep = plan.current_step || 0;

              const normalizedSteps = normalizePlanSteps(steps);
              plan.steps = normalizedSteps;

              // Find the next step to execute (first non-completed step)
              let nextStepIndex = -1;
              for (let i = 0; i < normalizedSteps.length; i++) {
                if (!normalizedSteps[i].status || normalizedSteps[i].status !== 'completed') {
                  nextStepIndex = i;
                  break;
                }
              }

              if (nextStepIndex === -1) {
                // All steps completed
                await manager.updatePlanStatus(workspace.id, plan.plan_id, 'completed');
                await manager.close();
                return {
                  success: true,
                  message: 'All plan steps have been completed!'
                };
              }

              // Check if there's a task already running for this step
              if (normalizedSteps[nextStepIndex].taskId && normalizedSteps[nextStepIndex].status === 'in_progress') {
                // Check if the task is actually still running
                const existingTask = this.taskMonitor.getTaskById(normalizedSteps[nextStepIndex].taskId);
                if (existingTask && (existingTask.status === 'pending' || existingTask.status === 'running')) {
                  await manager.close();
                  return {
                    success: false,
                    message: `Step ${nextStepIndex + 1} is already in progress with task ID: ${normalizedSteps[nextStepIndex].taskId}`
                  };
                }
                // Task is completed/failed/cancelled, update step status accordingly
                if (!existingTask || existingTask.status === 'completed' || existingTask.status === 'failed' ||
                    existingTask.status === 'cancelled' || existingTask.status === 'error') {
                  const newStatus = (!existingTask || existingTask.status === 'cancelled') ? 'pending' :
                                    (existingTask.status === 'completed' ? 'completed' : 'failed');
                  await manager.updatePlanStep(workspace.id, plan.plan_id, nextStepIndex, {
                    status: newStatus,
                    completedAt: existingTask?.completedAt || new Date().toISOString()
                  });

                  // If this step is now completed, we need to find the next non-completed step
                  if (newStatus === 'completed') {
                    // Re-check for the next step
                    for (let i = nextStepIndex + 1; i < normalizedSteps.length; i++) {
                      if (!normalizedSteps[i].status || normalizedSteps[i].status !== 'completed') {
                        nextStepIndex = i;
                        break;
                      } else if (i === normalizedSteps.length - 1) {
                        // All steps completed
                        await manager.updatePlanStatus(workspace.id, plan.plan_id, 'completed');
                        await manager.close();
                        return {
                          success: true,
                          message: 'All plan steps have been completed!'
                        };
                      }
                    }
                  }
                }
              }

              const stepInfo = normalizePlanStep(normalizedSteps[nextStepIndex]);
              const stepDescription = getPlanStepDisplayText(stepInfo);

              // Update plan status
              await manager.updatePlanStatus(workspace.id, plan.plan_id, 'in_progress', nextStepIndex);

              // Create task for this step
              const taskName = `plan-${plan.plan_id}-step-${nextStepIndex + 1}`;
              const taskOptions = {
                cwd: workspace.path,
                source: 'lark_plan',
                chatId: chatId,
                planId: plan.plan_id,
                stepIndex: nextStepIndex,
                workspaceId: workspace.id
              };

              if (stepInfo.providerId) {
                taskOptions.providerId = stepInfo.providerId;
              }
              if (stepInfo.model) {
                taskOptions.model = stepInfo.model;
              }

              const task = this.taskMonitor.addTask(
                taskName,
                stepInfo.command,
                taskOptions
              );

              // Update step with task ID and mark as in_progress
              await manager.updatePlanStep(workspace.id, plan.plan_id, nextStepIndex, {
                taskId: task.id,
                status: 'in_progress'
              });

              await manager.close();

              logger.info(`Executing plan step ${nextStepIndex + 1}/${normalizedSteps.length}: ${task.id}`);

              return {
                success: true,
                message: `Executing step ${nextStepIndex + 1}/${normalizedSteps.length}: ${stepDescription}\n\nTask ID: ${task.id}`,
                taskId: task.id
              };
            } catch (error) {
              logger.error(`Failed to execute plan: ${error.message}`);
              return {
                success: false,
                message: `Failed to execute plan: ${error.message}`
              };
            }
          }

          case 'plans': {
            // Handle listing all plans for workspace
            try {
              const { WorkspaceManager } = await import('./workspace-manager.js');
              const manager = new WorkspaceManager();
              await manager.initialize();

              // Get workspace for this chat
              let workspace;
              if (chatId && chatId.startsWith('telegram:')) {
                // For Telegram chats, use the specialized method
                const telegramChatId = chatId.replace('telegram:', '');
                workspace = await manager.getWorkspaceForTelegramChat(telegramChatId);
              } else {
                // For other chats (Lark), use the regular method
                workspace = await manager.getWorkspaceForChat(chatId);
              }

              if (!workspace) {
                // In gateway mode, ensure gateway workspace exists in database
                if (config.gateway.enabled) {
                  workspace = await manager.ensureGatewayWorkspace();
                  logger.debug('Gateway mode: Using gateway workspace for /plans');
                } else {
                  return {
                    success: false,
                    message: 'No workspace connected. Use /connect <token> to connect.'
                  };
                }
              }

              // Get all plans for the workspace
              const plans = await manager.listPlans(workspace.id);

              if (!plans || plans.length === 0) {
                await manager.close();
                return {
                  success: true,
                  message: `📋 No plans found for workspace: ${workspace.name}\n\nCreate a plan with: /plan <steps>`
                };
              }

              // Format plans list
              let message = `📋 Plans for workspace: ${workspace.name}\n\n`;

              // Group plans by status
              const pendingPlans = plans.filter(p => p.status === 'pending');
              const inProgressPlans = plans.filter(p => p.status === 'in_progress');
              const completedPlans = plans.filter(p => p.status === 'completed');
              const failedPlans = plans.filter(p => p.status === 'failed');

              if (inProgressPlans.length > 0) {
                message += `🔵 In Progress:\n`;
                inProgressPlans.forEach(plan => {
                  const steps = plan.steps || [];
                  const completedCount = steps.filter(s =>
                    (typeof s === 'object' && s.status === 'completed')
                  ).length;
                  const totalSteps = steps.length;
                  const progress = totalSteps > 0 ? Math.round((completedCount / totalSteps) * 100) : 0;
                  message += `• ${plan.plan_id} - ${plan.title} (${completedCount}/${totalSteps} steps, ${progress}%)\n`;

                  // Show current running step if any
                  const runningStep = steps.find(s =>
                    typeof s === 'object' && s.status === 'in_progress' && s.taskId
                  );
                  if (runningStep) {
                    const stepIndex = steps.indexOf(runningStep);
                    message += `  → Running step ${stepIndex + 1}: Task ${runningStep.taskId}\n`;
                  }
                });
                message += '\n';
              }

              if (pendingPlans.length > 0) {
                message += `⏸️ Pending:\n`;
                pendingPlans.forEach(plan => {
                  message += `• ${plan.plan_id} - ${plan.title} (${plan.steps.length} steps)\n`;
                });
                message += '\n';
              }

              if (completedPlans.length > 0) {
                message += `✅ Completed:\n`;
                completedPlans.slice(0, 5).forEach(plan => {  // Show only last 5 completed
                  message += `• ${plan.plan_id} - ${plan.title}\n`;
                });
                if (completedPlans.length > 5) {
                  message += `  ...and ${completedPlans.length - 5} more\n`;
                }
                message += '\n';
              }

              if (failedPlans.length > 0) {
                message += `❌ Failed:\n`;
                failedPlans.slice(0, 3).forEach(plan => {  // Show only last 3 failed
                  message += `• ${plan.plan_id} - ${plan.title}\n`;
                });
                if (failedPlans.length > 3) {
                  message += `  ...and ${failedPlans.length - 3} more\n`;
                }
                message += '\n';
              }

              message += `\nTotal: ${plans.length} plans\n`;
              message += `\nCommands:\n`;
              message += `• /next [plan-id] - Execute next step of a plan\n`;
              message += `• /cleanup - Remove all completed plans\n`;
              message += `• /purge - Force reset all plans (⚠️ dangerous)`;

              await manager.close();

              return {
                success: true,
                message: message
              };

            } catch (error) {
              logger.error(`Failed to list plans: ${error.message}`);
              return {
                success: false,
                message: `Failed to list plans: ${error.message}`
              };
            }
          }

          case 'cleanup':
          case 'clean': {
            // Handle cleanup of completed plans
            try {
              const { WorkspaceManager } = await import('./workspace-manager.js');
              const manager = new WorkspaceManager();
              await manager.initialize();

              // Get workspace for this chat
              let workspace;
              if (chatId && chatId.startsWith('telegram:')) {
                const telegramChatId = chatId.replace('telegram:', '');
                workspace = await manager.getWorkspaceForTelegramChat(telegramChatId);
              } else {
                workspace = await manager.getWorkspaceForChat(chatId);
              }

              if (!workspace) {
                // In gateway mode, ensure gateway workspace exists in database
                if (config.gateway.enabled) {
                  workspace = await manager.ensureGatewayWorkspace();
                  logger.debug('Gateway mode: Using gateway workspace for /clean');
                } else {
                  return {
                    success: false,
                    message: 'No workspace connected. Use /connect <token> to connect.'
                  };
                }
              }

              // Delete all completed plans
              const result = await manager.resetPlans(workspace.id, 'completed');
              await manager.close();

              return {
                success: true,
                message: result.message
              };

            } catch (error) {
              logger.error(`Failed to cleanup plans: ${error.message}`);
              return {
                success: false,
                message: `Failed to cleanup plans: ${error.message}`
              };
            }
          }

          case 'cleanup_failed': {
            // Handle cleanup of failed plans
            try {
              const { WorkspaceManager } = await import('./workspace-manager.js');
              const manager = new WorkspaceManager();
              await manager.initialize();

              // Get workspace for this chat
              let workspace;
              if (chatId && chatId.startsWith('telegram:')) {
                const telegramChatId = chatId.replace('telegram:', '');
                workspace = await manager.getWorkspaceForTelegramChat(telegramChatId);
              } else {
                workspace = await manager.getWorkspaceForChat(chatId);
              }

              if (!workspace) {
                // In gateway mode, ensure gateway workspace exists in database
                if (config.gateway.enabled) {
                  workspace = await manager.ensureGatewayWorkspace();
                  logger.debug('Gateway mode: Using gateway workspace for /cleanup_failed');
                } else {
                  return {
                    success: false,
                    message: 'No workspace connected. Use /connect <token> to connect.'
                  };
                }
              }

              // Delete all failed plans
              const result = await manager.resetPlans(workspace.id, 'failed');
              await manager.close();

              return {
                success: true,
                message: result.message
              };

            } catch (error) {
              logger.error(`Failed to cleanup failed plans: ${error.message}`);
              return {
                success: false,
                message: `Failed to cleanup failed plans: ${error.message}`
              };
            }
          }

          case 'cancel_progress': {
            // Handle canceling of in-progress plans
            try {
              const { WorkspaceManager } = await import('./workspace-manager.js');
              const manager = new WorkspaceManager();
              await manager.initialize();

              // Get workspace for this chat
              let workspace;
              if (chatId && chatId.startsWith('telegram:')) {
                const telegramChatId = chatId.replace('telegram:', '');
                workspace = await manager.getWorkspaceForTelegramChat(telegramChatId);
              } else {
                workspace = await manager.getWorkspaceForChat(chatId);
              }

              if (!workspace) {
                // In gateway mode, ensure gateway workspace exists in database
                if (config.gateway.enabled) {
                  workspace = await manager.ensureGatewayWorkspace();
                  logger.debug('Gateway mode: Using gateway workspace for /cancel_progress');
                } else {
                  return {
                    success: false,
                    message: 'No workspace connected. Use /connect <token> to connect.'
                  };
                }
              }

              // Get all in-progress plans
              const plans = await manager.listPlans(workspace.id);
              const inProgressPlans = plans.filter(p => p.status === 'in_progress');

              if (inProgressPlans.length === 0) {
                await manager.close();
                return {
                  success: false,
                  message: 'No plans currently in progress.'
                };
              }

              // Cancel all in-progress plans
              let canceledCount = 0;
              for (const plan of inProgressPlans) {
                await manager.updatePlanStatus(workspace.id, plan.plan_id, 'pending', plan.current_step || 0);
                canceledCount++;
              }

              await manager.close();

              return {
                success: true,
                message: `⏹️ Canceled ${canceledCount} in-progress plan${canceledCount > 1 ? 's' : ''}. Plans have been reset to pending status.`
              };

            } catch (error) {
              logger.error(`Failed to cancel in-progress plans: ${error.message}`);
              return {
                success: false,
                message: `Failed to cancel in-progress plans: ${error.message}`
              };
            }
          }

          case 'purge': {
            // Handle force reset of all plans (dangerous operation)
            try {
              const { WorkspaceManager } = await import('./workspace-manager.js');
              const manager = new WorkspaceManager();
              await manager.initialize();

              // Get workspace for this chat
              let workspace;
              if (chatId && chatId.startsWith('telegram:')) {
                const telegramChatId = chatId.replace('telegram:', '');
                workspace = await manager.getWorkspaceForTelegramChat(telegramChatId);
              } else {
                workspace = await manager.getWorkspaceForChat(chatId);
              }

              if (!workspace) {
                // In gateway mode, ensure gateway workspace exists in database
                if (config.gateway.enabled) {
                  workspace = await manager.ensureGatewayWorkspace();
                  logger.debug('Gateway mode: Using gateway workspace for /purge');
                } else {
                  return {
                    success: false,
                    message: 'No workspace connected. Use /connect <token> to connect.'
                  };
                }
              }

              // Confirm with user or add warning
              const confirmFlag = args && (args === '-y' || args === '--yes' || args === 'confirm');
              if (!confirmFlag) {
                return {
                  success: false,
                  message: `⚠️ WARNING: This will permanently delete ALL plans in workspace "${workspace.name}"!\n\nTo confirm, run: /purge confirm`
                };
              }

              // Force reset ALL plans (no status filter)
              const result = await manager.resetPlans(workspace.id);
              await manager.close();

              const successMessage = `🔥 Purged all plans in workspace "${workspace.name}"\n${result.message}`;

              return {
                success: true,
                message: successMessage
              };

            } catch (error) {
              logger.error(`Failed to purge plans: ${error.message}`);
              return {
                success: false,
                message: `Failed to purge plans: ${error.message}`
              };
            }
          }

          case 'task':
          case 'run':
            if (!args) {
              return {
                success: false,
                message: 'Please provide a command to run'
              };
            }
            
            // Check if workdir is set for this chat
            const selectedWorkdirName = this.chatSettings.getWorkdir(chatId);
            const availableWorkdirs = await this.getAvailableWorkdirs(chatId);
            
            if (!selectedWorkdirName) {
              // No workspace connected
              let warningMessage = `⚠️ No workspace connected.\n\n`;
              warningMessage += `Please use /connect [token] to connect to a workspace.`;
              
              // Send notification if Lark notifier is available
              if (this.taskMonitor.larkNotifier) {
                this.taskMonitor.larkNotifier.sendCustomMessage(
                  '⚠️ Working Directory Not Selected',
                  warningMessage,
                  'orange',
                  chatId
                ).catch(err => logger.error('Failed to send Lark notification:', err));
              }
              
              return {
                success: false,
                message: 'Working directory not selected'
              };
            }
            
            // Get the actual path from the selected name
            const taskWorkdir = availableWorkdirs[selectedWorkdirName];
            if (!taskWorkdir) {
              // Selected workdir no longer exists - don't remove it, just report error
              // This could be a temporary issue with workspace loading
              logger.warn(`Workdir "${selectedWorkdirName}" not found for chat ${chatId}, but keeping selection`);
              
              if (this.taskMonitor.larkNotifier) {
                this.taskMonitor.larkNotifier.sendCustomMessage(
                  '❌ Invalid Working Directory',
                  `Previously selected directory "${selectedWorkdirName}" is no longer available.\nPlease select a new directory with /workdir`,
                  'red',
                  chatId
                ).catch(err => logger.error('Failed to send Lark notification:', err));
              }
              
              return {
                success: false,
                message: 'Selected workdir no longer available'
              };
            }
            
            const task = this.taskMonitor.addTask(
              `Lark Task: ${args.substring(0, 50)}...`,
              args,
              {
                cwd: taskWorkdir,
                source: 'lark_message',
                chatId: chatId  // Store chat ID for response routing
              }
            );
            
            return {
              success: true,
              taskId: task.id,
              message: `Task created: ${task.name}`
            };
            
          case 'workdir':
          case 'wd':
            const workdirs = config.lark.workdirs;
            
            if (!args) {
              // Show current workdir status
              const currentDirName = this.chatSettings.getWorkdir(chatId);
              const currentDirPath = currentDirName ? workdirs[currentDirName] : null;
              
              let dirMessage = '';
              if (currentDirName && currentDirPath) {
                dirMessage = `📁 Current working directory:\n**${currentDirName}** → ${currentDirPath}`;
              } else {
                dirMessage = `📁 No workspace connected\n\nPlease use /connect [token] to connect to a workspace.`;
              }
              
              if (this.taskMonitor.larkNotifier) {
                this.taskMonitor.larkNotifier.sendCustomMessage(
                  '📁 Working Directory',
                  dirMessage,
                  'blue',
                  chatId
                ).catch(err => logger.error('Failed to send Lark notification:', err));
              }
              
              return {
                success: true,
                message: 'Workdir status sent'
              };
            }
            
            // Set workdir by name
            const workdirName = args.trim().toLowerCase();
            
            // Check if the name exists in configured workdirs
            if (!workdirs[workdirName]) {
              let errorMessage = `❌ Unknown directory: **${workdirName}**\n\n`;
              errorMessage += `Please use /connect [token] to connect to a workspace.`;
              
              if (this.taskMonitor.larkNotifier) {
                this.taskMonitor.larkNotifier.sendCustomMessage(
                  '❌ Invalid Selection',
                  errorMessage,
                  'red',
                  chatId
                ).catch(err => logger.error('Failed to send Lark notification:', err));
              }
              
              return {
                success: false,
                message: `Unknown workdir: ${workdirName}`
              };
            }
            
            // Store the selected workdir name for this chat (persistent)
            const selectedPath = workdirs[workdirName];
            await this.chatSettings.setWorkdir(chatId, workdirName, selectedPath);
            
            if (this.taskMonitor.larkNotifier) {
              this.taskMonitor.larkNotifier.sendCustomMessage(
                '✅ Working Directory Set',
                `Working directory set to:\n**${workdirName}** → ${selectedPath}\n\nAll future tasks will run from this directory.`,
                'green',
                chatId
              ).catch(err => logger.error('Failed to send Lark notification:', err));
            }
            
            return {
              success: true,
              message: `Workdir set to ${workdirName}`
            };
            
          case 'status': {
            // Use unified status message generator
            const { statusMessage, gitActionButtons } = await this.generateStatusMessage(chatId);
            
            // Send interactive message with action buttons
            if (this.taskMonitor.larkNotifier) {
              // Add refresh button
              const statusButtons = [
                {
                  tag: 'button',
                  text: {
                    tag: 'plain_text',
                    content: '🔄 Refresh'
                  },
                  type: 'default',
                  value: JSON.stringify({
                    action: 'show_status'
                  })
                }
              ];
              
              // Combine git action buttons with refresh button
              const allButtons = [...gitActionButtons, ...statusButtons];
              
              await this.taskMonitor.larkNotifier.sendInteractiveMessage(
                '📊 Status',
                statusMessage,
                'blue',
                allButtons,
                chatId  // Send response to the requesting chat
              );
            }
            
            return {
              success: true,
              data: this.taskMonitor.getStatus()
            };
          }
            
          case 'help':
            // Send help message with interactive buttons
            const currentWorkdirNameHelp = this.chatSettings.getWorkdir(chatId);
            const availableWorkdirsHelp = config.lark.workdirs;
            
            if (this.taskMonitor.larkNotifier) {
              this.taskMonitor.larkNotifier.sendHelpMessage(
                chatId,
                currentWorkdirNameHelp,
                availableWorkdirsHelp
              ).catch(err => logger.error('Failed to send Lark help message:', err));
            }
            
            return {
              success: true,
              message: 'Help sent'
            };
            
          case 'cancel':
            const taskId = args;
            if (!taskId) {
              return {
                success: false,
                message: 'Please provide a task ID to cancel'
              };
            }

            const cancelled = this.taskMonitor.cancelTask(taskId);
            // cancelTask returns { success: boolean, message: string }
            return cancelled;

          case 'cheatsheet': {
            const cheatsheet = `🚀 Ani-Code Lark Integration Cheatsheet

📋 INITIAL SETUP
${'─'.repeat(50)}
  1. Initialize project: \`ani-code remember "@main.md"\`
  2. Browser tasks: \`ani-code remember "@browser.md"\`
  3. Web development: \`ani-code remember "@web.md"\`

🤖 LARK COMMANDS
${'─'.repeat(50)}
  \`/add <prompt>\`       Create new Claude task
  \`/continue\`           Continue last task
  \`/commit\`             Commit current changes
  \`/plan <prompt>\`      Set tasks for later execution
  \`/yolo <prompt>\`      Execute with auto-accept

📝 MACROS (Customizable)
${'─'.repeat(50)}
  \`/$goal\`              Draft goals in pd/goals
  \`/$loop\`              Execute goal implementation loop
  \`/$goalcheck\`         Check goal completion status

⚙️ MACRO EXAMPLES

/$goalcheck:
  \`/add check pd/goals what is the current completion status\`

/$loop:
  \`/add read project prd, pick one or several tasks from goal
  and implement, after that, review your implementation
  if matching the goal, if so update the goal file progress,
  otherwise provide next step. Make sure you remember you
  are not only implementing the goals, but following goals
  and claude.md guidance. The goal can be optimized if you
  facing issue, but dont forget to mention your change in pd/.
  Every service can be auto reload, so dont run node npm
  command unless it is for validate compile or build.
  In the end summarize the current progress of goal
  implementation and major achievements, tell me now
  in which state and which goal, what is the percentage
  of completion, and is any manual step I need to involve.
  Check after the implementation if any issue preventing
  service running and page rendering, in the end tell me
  what is the current pd/goals implement progress in
  a short summary.\`

/$goal:
  \`/plan Please consider the following implementation plan,
  review what is needed, and identify any conflicts or
  improvements to the pd/goals stage and goal. Update
  the related goal file or create a new one as necessary.
  Always follow claude.md guidance when preparing the
  goal plan.\`

💡 TIPS
${'─'.repeat(50)}
  • Use \`@@opus\` or \`@@sonnet\` to select model
  • Combine tasks: \`/yolo implement auth + tests\`
  • Check status: \`ani-code status\`
  • Watch output: \`ani-code watch <id>\`

🔧 CREATING MACROS
${'─'.repeat(50)}
  List macros: \`ani-code workspace macro list\`
  Create macro: \`ani-code workspace macro set <name> "<command>"\`
  Example: \`ani-code workspace macro set test "/add run tests"\`
  Use in Lark: \`/$test\`

📚 DOCUMENTATION
${'─'.repeat(50)}
  • Main docs: https://docs.claude.com/claude-code
  • Report issues: https://github.com/anthropics/claude-code/issues
`;

            if (this.taskMonitor.larkNotifier) {
              await this.taskMonitor.larkNotifier.sendCustomMessage(
                '🚀 Cheatsheet',
                cheatsheet,
                'blue',
                chatId
              );
            }

            return {
              success: true,
              message: 'Cheatsheet sent'
            };
          }

          default:
            // If empty command or just a mention, show help
            if (!command || command === '') {
              // Show help message with interactive buttons
              const currentWorkdirNameHelp = this.chatSettings.getWorkdir(chatId);
              const availableWorkdirsHelp = config.lark.workdirs;
              
              if (this.taskMonitor.larkNotifier) {
                this.taskMonitor.larkNotifier.sendHelpMessage(
                  chatId,
                  currentWorkdirNameHelp,
                  availableWorkdirsHelp
                ).catch(err => logger.error('Failed to send Lark help message:', err));
              }
              
              return {
                success: true,
                message: 'Help request received'
              };
            }
            
            // For unknown commands, show action buttons
            const unrecognizedText = `${command}${args ? ' ' + args : ''}`;
            const availableWorkdirsUnknown = config.lark.workdirs;
            const currentWorkdirNameUnknown = this.chatSettings.getWorkdir(chatId);
            
            if (this.taskMonitor.larkNotifier) {
              this.taskMonitor.larkNotifier.sendUnrecognizedCommandMessage(
                chatId,
                unrecognizedText,
                currentWorkdirNameUnknown,
                availableWorkdirsUnknown
              ).catch(err => logger.error('Failed to send unrecognized command message:', err));
            }
            
            return {
              success: false,
              message: `Unknown command: ${command}`
            };
        }
      }
      
      // If message is empty, show status directly
      if (!messageText || !messageText.trim()) {
        logger.info('Received empty message, showing status directly');
        
        // Use unified status message generator
        const { statusMessage, gitActionButtons } = await this.generateStatusMessage(chatId);
        
        // Send interactive message with action buttons
        if (this.taskMonitor.larkNotifier) {
          // Add refresh button
          const statusButtons = [
            {
              tag: 'button',
              text: {
                tag: 'plain_text',
                content: '🔄 Refresh'
              },
              type: 'default',
              value: JSON.stringify({
                action: 'show_status'
              })
            }
          ];
          
          // Combine git action buttons with refresh button
          const allButtons = [...gitActionButtons, ...statusButtons];
          
          await this.taskMonitor.larkNotifier.sendInteractiveMessage(
            '📊 Status',
            statusMessage,
            'blue',
            allButtons,
            chatId  // Send response to the requesting chat
          );
        }
      } else {
        // If not a command, show action buttons for the message
        const availableWorkdirsNonCmd = config.lark.workdirs;
        const currentWorkdirNameNonCmd = this.chatSettings.getWorkdir(chatId);
        
        if (this.taskMonitor.larkNotifier) {
          await this.taskMonitor.larkNotifier.sendUnrecognizedCommandMessage(
            chatId,
            messageText,
            currentWorkdirNameNonCmd,
            availableWorkdirsNonCmd
          ).catch(err => {
            logger.error('Failed to send unrecognized command message:', err);
            // Still return success to prevent Lark from retrying
          });
        }
      }
      
      return {
        success: true,
        message: messageText && messageText.trim() ? 'Non-command message handled with action buttons' : 'Empty message handled'
      };
    }
    
    return {
      success: true,
      message: 'Event received'
    };
  }

  async processLarkV2Event(data) {
    const { header, event } = data;
    
    // Ignore message read events
    if (header.event_type === 'im.message.read_v1') {
      logger.debug('Ignoring message read event');
      return {
        success: true,
        message: 'Message read event ignored'
      };
    }
    
    // Handle message receive events
    if (header.event_type === 'im.message.receive_v1' && event.message) {
      const message = event.message;
      const sender = event.sender;
      
      // Parse message text
      let messageText = '';
      try {
        const content = JSON.parse(message.content);
        messageText = content.text || '';
      } catch (e) {
        messageText = message.content;
      }
      
      // Log message details
      const messageId = message.message_id;
      const messageCreateTime = message.create_time;
      
      logger.info(`📨 V2.0 Message received:
  Message ID: ${messageId}
  Chat ID: ${message.chat_id}
  Chat Type: ${message.chat_type || 'unknown'}
  Message Type: ${message.message_type}
  Create Time: ${messageCreateTime} (${messageCreateTime ? new Date(parseInt(messageCreateTime)).toISOString() : 'N/A'})
  Current Time: ${Date.now()} (${new Date().toISOString()})
  Message Text: ${messageText.substring(0, 100)}${messageText.length > 100 ? '...' : ''}`);
      
      // Check for duplicate message using message_id
      if (messageId) {
        if (this.processedMessages.has(messageId)) {
          logger.info(`✋ Duplicate message detected (v2.0): ${messageId}, ignoring`);
          return {
            success: true,
            message: 'Duplicate message ignored'
          };
        }
        // Store the message ID with current timestamp
        this.processedMessages.set(messageId, Date.now());
        logger.debug(`Stored message ID (v2.0): ${messageId} for deduplication`);
      }
      
      // Check message age for v2.0 events
      if (message.create_time) {
        const messageAge = Date.now() - parseInt(message.create_time);
        if (messageAge > this.MAX_MESSAGE_AGE_MS) {
          logger.warn(`⏰ STALE MESSAGE REJECTED (v2.0):
  Message ID: ${messageId}
  Chat ID: ${message.chat_id}
  Message Age: ${Math.round(messageAge/1000)} seconds (>${this.MAX_MESSAGE_AGE_MS/1000}s threshold)
  Create Time: ${new Date(parseInt(message.create_time)).toISOString()}
  Current Time: ${new Date().toISOString()}
  Message Text: ${messageText.substring(0, 50)}${messageText.length > 50 ? '...' : ''}`);
          return {
            success: true,
            message: 'Stale message ignored'
          };
        } else {
          logger.debug(`✅ Message age check passed: ${Math.round(messageAge/1000)}s old (within ${this.MAX_MESSAGE_AGE_MS/1000}s threshold)`);
        }
      }
      
      // Message text already parsed above, just log processing status
      logger.info(`Processing message: "${messageText.substring(0, 50)}${messageText.length > 50 ? '...' : ''}"`);
      
      
      // Strip Lark mention tags like <at user_id="...">@BotName</at>
      const cleanedText = messageText.replace(/<at[^>]*>.*?<\/at>/g, '').trim();
      if (cleanedText !== messageText) {
        logger.info(`Cleaned message: ${cleanedText}`);
        messageText = cleanedText;
      }
      
      // Check if bot was mentioned
      const botMentioned = message.mentions && message.mentions.some(mention => 
        mention.name === 'AniCodeBot' || mention.id.open_id === 'ou_0562e39783ec53678e37c4f6e5f39137'
      );
      
      if (botMentioned) {
        // Remove @mention from message text
        messageText = messageText.replace(/@_user_\d+\s*/g, '').trim();
        logger.info(`Bot mentioned with command: ${messageText}`);
      }
      
      // Process commands (with or without @mention)
      if (messageText.startsWith('/')) {
        // This is definitely a command
        const commandText = messageText.slice(1);
        const parts = commandText.split(' ');
        const command = parts[0].toLowerCase();
        const args = parts.slice(1).join(' ');
        
        logger.info(`Processing slash command: /${command} with args: ${args}`);
        
        switch (command) {
          case 'add': {
            // Handle /add command for Claude task creation
            if (!args) {
              if (this.taskMonitor.larkNotifier) {
                await this.taskMonitor.larkNotifier.sendCustomMessage(
                  '⚠️ Missing Prompt',
                  'Please provide a prompt for Claude.\nExample: /add fix the bug in the login function',
                  'orange',
                  message.chat_id
                );
              }
              return {
                success: false,
                message: 'Prompt is required for /add'
              };
            }
            
            // Get workdir for this chat
            const selectedWorkdirName = this.chatSettings.getWorkdir(message.chat_id);
            const availableWorkdirs = config.lark.workdirs;
            const selectedWorkdirPath = selectedWorkdirName ? availableWorkdirs[selectedWorkdirName] : null;
            
            if (!selectedWorkdirPath) {
              if (this.taskMonitor.larkNotifier) {
                await this.taskMonitor.larkNotifier.sendCustomMessage(
                  '⚠️ Working Directory Not Set',
                  `Please select a working directory first.\nUse: /workdir [name]`,
                  'orange',
                  message.chat_id
                );
              }
              return {
                success: false,
                message: 'Working directory not set'
              };
            }
            
            // Create the Claude task - pass prompt directly to claude
            const taskName = `claude-add-${Date.now()}`;
            // Pass the prompt directly to claude (without -c flag for new task)
            const claudeCommand = args;
            
            const taskOptions = {
              cwd: selectedWorkdirPath,
              source: 'lark_add_command',
              chatId: message.chat_id  // Store chat ID for response routing
            };
            
            const task = this.taskMonitor.addTask(taskName, claudeCommand, taskOptions);
            
            logger.info(`Created Claude add task: ${task.id} in ${selectedWorkdirPath}`);
            
            return {
              success: true,
              message: `Claude task created with ID: ${task.id}`,
              taskId: task.id
            };
          }
          
          case 'grant': {
            // Handle /grant command for permission review
            const selectedWorkdirName = this.chatSettings.getWorkdir(message.chat_id);
            const availableWorkdirs = config.lark.workdirs;
            const selectedWorkdirPath = selectedWorkdirName ? availableWorkdirs[selectedWorkdirName] : null;

            if (!selectedWorkdirPath) {
              if (this.taskMonitor.larkNotifier) {
                await this.taskMonitor.larkNotifier.sendCustomMessage(
                  '⚠️ Working Directory Not Set',
                  `Please select a working directory first.\nUse: /workdir [name]`,
                  'orange',
                  message.chat_id
                );
              }
              return {
                success: false,
                message: 'Working directory not set'
              };
            }

            const grantPrompt = `You are in High Privilege Mode for permission management.

## Task
Review the last Claude message in the conversation history and identify any permission blocks or denied operations.

## Analysis Steps
1. Check the last message for:
   - Permission errors ("This tool requires approval", "permission denied")
   - Blocked Bash commands
   - Blocked file operations (Read/Write/Edit)
   - Blocked MCP function calls
   - Tool use errors related to permissions

2. Identify the permission pattern needed:
   - Bash commands: \`Bash(command:*)\`
   - File reads: \`Read(path)\` or \`Read(path/**/*)\`
   - File writes: \`Write(path)\` or \`Write(path/**/*)\`
   - File edits: \`Edit(path)\` or \`Edit(path/**/*)\`
   - MCP tools: \`mcp__server__function(*)\`

3. Update .claude/settings.local.json (PREFERRED over .claude/settings.json):
   - ALWAYS prefer modifying \`.claude/settings.local.json\` instead of \`.claude/settings.json\` to resolve permission issues
   - \`.claude/settings.local.json\` is the local override file and should be used for per-machine permission grants
   - Only modify \`.claude/settings.json\` if explicitly instructed to do so
   - Add permission to permissions.allow array
   - Use wildcards appropriately for flexibility
   - Keep alphabetical order within sections
   - Ensure valid JSON syntax
   - If the file doesn't exist, create it with proper structure

4. Report back:
   - What permission was blocked
   - What pattern was added
   - Confirmation the file was updated
   - Do NOT re-execute the originally blocked operation — only resolve the permission and describe what you did
   - The user will retry the operation themselves

${args ? `\n## Additional Instructions\n${args}\n` : ''}

## Example Permission Patterns
- \`Bash(npm install:*)\` - npm install commands
- \`Bash(python3:*)\` - Python 3 scripts
- \`Bash(curl:*)\` - curl requests
- \`Read(/etc/**/*)\` - Read files in /etc
- \`Write(/tmp/**/*)\` - Write to tmp
- \`Edit(./**/*)\` - Edit any file in current dir

## Important Guidelines
- Be specific but not overly restrictive
- Use wildcards to avoid repeated approvals
- Never grant overly broad permissions like \`Bash(*)\`
- Preserve all existing permissions
- Validate JSON before saving
- ALWAYS use \`.claude/settings.local.json\` — never modify \`.claude/settings.json\` unless explicitly asked
- Only resolve the permission issue and report what was done — do NOT execute the originally blocked operation
- If no permission issues found, report "No permission issues detected"

Now analyze the conversation and grant necessary permissions.`;

            const taskName = `claude-grant-${Date.now()}`;
            const task = this.taskMonitor.addTask(
              taskName,
              `-c --dangerously-skip-permissions ${grantPrompt}`,
              {
                cwd: selectedWorkdirPath,
                source: 'lark_grant',
                chatId: message.chat_id
              }
            );

            if (this.taskMonitor.larkNotifier) {
              await this.taskMonitor.larkNotifier.sendCustomMessage(
                '🔐 Permission Review',
                `Analyzing last message for blocked operations...\nTask ID: ${task.id}`,
                'blue',
                message.chat_id
              );
            }

            return {
              success: true,
              message: `Permission review task created with ID: ${task.id}`,
              taskId: task.id
            };
          }

          case 'continue': {
            // Handle /continue command for Claude task continuation
            // Get workdir for this chat
            const selectedWorkdirName = this.chatSettings.getWorkdir(message.chat_id);
            const availableWorkdirs = config.lark.workdirs;
            const selectedWorkdirPath = selectedWorkdirName ? availableWorkdirs[selectedWorkdirName] : null;

            if (!selectedWorkdirPath) {
              if (this.taskMonitor.larkNotifier) {
                await this.taskMonitor.larkNotifier.sendCustomMessage(
                  '⚠️ Working Directory Not Set',
                  `Please select a working directory first.\nUse: /workdir [name]`,
                  'orange',
                  message.chat_id
                );
              }
              return {
                success: false,
                message: 'Working directory not set'
              };
            }
            
            // Create the Claude continue task - pass prompt with -c flag to claude
            const taskName = `claude-continue-${Date.now()}`;
            // Pass the prompt with -c flag to continue from previous context
            // If no args provided, use 'continue' as default prompt
            const claudeCommand = args ? 
              `-c ${args}` : 
              `-c continue`;
            
            const taskOptions = {
              cwd: selectedWorkdirPath,
              source: 'lark_continue_command',
              chatId: message.chat_id  // Store chat ID for response routing
            };
            
            const task = this.taskMonitor.addTask(taskName, claudeCommand, taskOptions);
            
            logger.info(`Created Claude continue task: ${task.id} in ${selectedWorkdirPath}`);
            
            return {
              success: true,
              message: `Claude continue task created with ID: ${task.id}`,
              taskId: task.id
            };
          }
          
          case 'check': {
            // Handle /check command for task completion checklist
            logger.info(`Processing /check command from Lark chat ${message.chat_id}`);
            await this.handleCheckCommand(message.chat_id, args, 'lark');
            
            return {
              success: true,
              message: 'Check command processed'
            };
          }
          
          case 'help': {
            // Send help message with interactive buttons
            const currentWorkdirName = this.chatSettings.getWorkdir(message.chat_id);
            const availableWorkdirs = config.lark.workdirs;
            
            if (this.taskMonitor.larkNotifier) {
              await this.taskMonitor.larkNotifier.sendHelpMessage(
                message.chat_id,
                currentWorkdirName,
                availableWorkdirs
              );
            }
            
            return {
              success: true,
              message: 'Help sent'
            };
          }
            
          case 'workdir':
          case 'wd':
          case 'cd': {
            const availableWorkdirs = await this.getAvailableWorkdirs(message.chat_id);
            
            if (!args) {
              // Check if already connected via workspace token
              const currentDirName = this.chatSettings.getWorkdir(message.chat_id);
              
              let dirMessage = '';
              if (currentDirName) {
                dirMessage = `📁 Current workspace: **${currentDirName}**\n\n`;
                dirMessage += `This chat is connected to a workspace.`;
              } else {
                dirMessage = `📁 No workspace connected\n\n`;
                dirMessage += `To connect this chat to a workspace:\n\n`;
                dirMessage += `1. Generate a token (from command line):\n`;
                dirMessage += `   \`ani-code workspace token gen <workspace-name>\`\n\n`;
                dirMessage += `2. Connect using the token:\n`;
                dirMessage += `   \`/connect <token>\`\n\n`;
                dirMessage += `This will securely link this chat to your workspace.`;
              }
              
              if (this.taskMonitor.larkNotifier) {
                await this.taskMonitor.larkNotifier.sendCustomMessage(
                  '🔐 Workspace Connection',
                  dirMessage,
                  'blue',
                  message.chat_id
                );
              }
              return {
                success: true,
                message: 'Workspace info sent'
              };
            }
            
            // Set workdir by name
            const workdirName = args.trim().toLowerCase();
            
            // Check if the name exists in configured workdirs
            if (!availableWorkdirs[workdirName]) {
              let errorMessage = `❌ Invalid workspace name\n\n`;
              errorMessage += `Please use \`/connect <token>\` to connect to a workspace.\n\n`;
              errorMessage += `To get a token:\n`;
              errorMessage += `1. Run: \`ani-code workspace token gen <workspace-name>\`\n`;
              errorMessage += `2. Use: \`/connect <token>\``;
              
              if (this.taskMonitor.larkNotifier) {
                await this.taskMonitor.larkNotifier.sendCustomMessage(
                  '❌ Workspace Not Found',
                  errorMessage,
                  'red',
                  message.chat_id
                );
              }
              return {
                success: false,
                message: `Unknown workdir: ${workdirName}`
              };
            }
            
            // Store the selected workdir name for this chat (persistent)
            const selectedPath = availableWorkdirs[workdirName];
            await this.chatSettings.setWorkdir(message.chat_id, workdirName, selectedPath);
            
            if (this.taskMonitor.larkNotifier) {
              await this.taskMonitor.larkNotifier.sendCustomMessage(
                '✅ Working Directory Set',
                `Working directory set to:\n**${workdirName}**\n\nAll future tasks will run from this directory.`,
                'green',
                message.chat_id
              );
            }
            
            return {
              success: true,
              message: `Workdir set to ${workdirName}`
            };
          }
            
          case 'connect':
          case 'token':
          case 'workspace-token':
          case 'ws-token': {
            // Handle workspace token linking
            if (!args) {
              if (this.taskMonitor.larkNotifier) {
                await this.taskMonitor.larkNotifier.sendCustomMessage(
                  '🔐 Connect Workspace',
                  'Please provide a workspace token to connect this chat.\n\nExample:\n`/connect <your-token>`\n\nGet a token using:\n`ani-code workspace token gen <workspace-name>`\n\nThis will automatically link this Lark chat to the workspace.',
                  'blue',
                  message.chat_id
                );
              }
              return {
                success: false,
                message: 'Token required'
              };
            }
            
            // Import and initialize workspace manager
            const { WorkspaceManager } = await import('./workspace-manager.js');
            const workspaceManager = new WorkspaceManager();
            await workspaceManager.initialize();
            
            try {
              // Validate the token
              const validation = await workspaceManager.validateToken(args.trim());
              
              if (!validation.valid) {
                if (this.taskMonitor.larkNotifier) {
                  await this.taskMonitor.larkNotifier.sendCustomMessage(
                    '❌ Invalid Token',
                    `Token validation failed: ${validation.error}\n\nPlease check your token and try again.`,
                    'red',
                    message.chat_id
                  );
                }
                await workspaceManager.close();
                return {
                  success: false,
                  message: `Invalid token: ${validation.error}`
                };
              }
              
              // Map the chat to the workspace
              await workspaceManager.mapChatToWorkspace(message.chat_id, validation.workspace_id);
              
              // Also update the chat settings for backward compatibility
              await this.chatSettings.setWorkdir(message.chat_id, validation.workspace_name, validation.workspace_path);
              
              if (this.taskMonitor.larkNotifier) {
                await this.taskMonitor.larkNotifier.sendCustomMessage(
                  '✅ Workspace Connected',
                  `Successfully connected this chat to workspace:\n\n**${validation.workspace_name}**\n📁 ${validation.workspace_path}\n🔑 Token: ${validation.type} (${validation.permissions.join(', ')})\n\nAll future tasks from this chat will run in this workspace.`,
                  'green',
                  message.chat_id
                );
              }
              
              await workspaceManager.close();
              
              return {
                success: true,
                message: `Workspace linked: ${validation.workspace_name}`
              };
            } catch (error) {
              logger.error('Failed to process workspace token:', error);
              
              if (this.taskMonitor.larkNotifier) {
                await this.taskMonitor.larkNotifier.sendCustomMessage(
                  '❌ Error',
                  `Failed to link workspace: ${error.message}`,
                  'red',
                  message.chat_id
                );
              }
              
              await workspaceManager.close();
              
              return {
                success: false,
                message: error.message
              };
            }
          }
          
          case 'task':
          case 'task!':
          case 'shell':
          case 'shell!':
          case 'run':
          case 'run!': {
            if (!args) {
              if (this.taskMonitor.larkNotifier) {
                await this.taskMonitor.larkNotifier.sendCustomMessage(
                  '⚠️ Missing Command',
                  'Please provide a command to run.\nExample: /shell echo "Hello World"',
                  'orange',
                  message.chat_id
                );
              }
              return {
                success: false,
                message: 'Please provide a command to run'
              };
            }
            
            // Check if workdir is set or if using force command
            const forceDefault = command === 'task!' || command === 'run!';
            const selectedWorkdirName = this.chatSettings.getWorkdir(message.chat_id);
            const availableWorkdirs = await this.getAvailableWorkdirs(message.chat_id);
            const isPrivateChat = message.chat_type === 'p2p';
            
            // For private chats, auto-select the first available workdir if not set
            let autoSelectedWorkdir = null;
            if (isPrivateChat && !selectedWorkdirName && !forceDefault) {
              const workdirNames = Object.keys(availableWorkdirs);
              if (workdirNames.length > 0) {
                autoSelectedWorkdir = workdirNames[0];
                const autoSelectedPath = availableWorkdirs[autoSelectedWorkdir];
                await this.chatSettings.setWorkdir(message.chat_id, autoSelectedWorkdir, autoSelectedPath);
                logger.debug(`Auto-selected workdir for private chat: ${autoSelectedWorkdir}`);
              }
            }
            
            const finalSelectedName = selectedWorkdirName || autoSelectedWorkdir;
            
            if (!finalSelectedName && !forceDefault) {
              // No workspace connected (for group chats)
              let warningMessage = `⚠️ No workspace connected.\n\n`;
              warningMessage += `Please use /connect [token] to connect to a workspace.`;
              
              if (this.taskMonitor.larkNotifier) {
                await this.taskMonitor.larkNotifier.sendCustomMessage(
                  '⚠️ Workspace Not Connected',
                  warningMessage,
                  'orange',
                  message.chat_id
                );
              }
              
              return {
                success: false,
                message: 'Workspace not connected'
              };
            }
            
            // Get the actual path from the selected name
            let finalWorkdir;
            if (finalSelectedName) {
              finalWorkdir = availableWorkdirs[finalSelectedName];
              if (!finalWorkdir) {
                // Selected workdir not found - don't remove it, just report error
                // This could be a temporary issue with workspace loading
                logger.warn(`Workdir "${finalSelectedName}" not found for chat ${message.chat_id}, but keeping selection`);
                
                if (this.taskMonitor.larkNotifier) {
                  await this.taskMonitor.larkNotifier.sendCustomMessage(
                    '⚠️ Workspace Connection Issue',
                    `Unable to access workspace "${finalSelectedName}".\n\nThis might be temporary. Try:\n1. Check if the workspace still exists: \`ani-code workspace list\`\n2. Reconnect with: \`/connect <token>\`\n3. Or select a different workspace: \`/workdir\``,
                    'orange',
                    message.chat_id
                  );
                }
                
                return {
                  success: false,
                  message: 'Selected workdir no longer available'
                };
              }
            } else {
              // Using force flag with default
              finalWorkdir = process.cwd();
            }
            
            // Add shell: prefix for shell/task/run commands to ensure they run as shell commands
            const commandToRun = `shell:${args}`;
            const task = this.taskMonitor.addTask(
              `Lark Task: ${args.substring(0, 50)}...`,
              commandToRun,
              {
                cwd: finalWorkdir,
                source: 'lark_v2_message'
              }
            );
            
            return {
              success: true,
              taskId: task.id,
              message: `Task created: ${task.name}`
            };
          }
            
          case 'clear-settings':
          case 'reset-chat': {
            // Clear all settings for this chat (useful for debugging)
            await this.chatSettings.removeWorkdir(message.chat_id);
            
            // Also clear workspace mappings if available
            try {
              const { WorkspaceManager } = await import('./workspace-manager.js');
              const workspaceManager = new WorkspaceManager();
              await workspaceManager.initialize();
              
              // Deactivate any workspace mappings for this chat
              await workspaceManager.db.run(
                `UPDATE chat_workspace_mappings SET is_active = 0 WHERE chat_id = ?`,
                [message.chat_id]
              );
              
              await workspaceManager.close();
              logger.info(`Cleared workspace mappings for chat ${message.chat_id}`);
            } catch (error) {
              logger.warn(`Failed to clear workspace mappings: ${error.message}`);
            }
            
            if (this.taskMonitor.larkNotifier) {
              await this.taskMonitor.larkNotifier.sendCustomMessage(
                '🔄 Chat Reset',
                `All settings for this chat have been cleared.\n\nYou can now:\n1. Connect to a workspace: \`/connect <token>\`\n2. Or set a workdir: \`/workdir <name>\``,
                'blue',
                message.chat_id
              );
            }
            
            return {
              success: true,
              message: 'Chat settings cleared'
            };
          }
          
          case 'stats': {
            // Show chat settings statistics
            const stats = this.chatSettings.getStats();
            const availableWorkdirs = config.lark.workdirs;
            
            let statsMessage = `📊 Chat Settings Statistics:\n\n`;
            statsMessage += `Total chats configured: ${stats.totalChats}\n\n`;
            
            if (Object.keys(stats.workdirUsage).length > 0) {
              statsMessage += `Workdir usage:\n`;
              for (const [workdir, count] of Object.entries(stats.workdirUsage)) {
                const path = availableWorkdirs[workdir] || 'unknown';
                statsMessage += `• **${workdir}**: ${count} chat(s) → ${path}\n`;
              }
            } else {
              statsMessage += `No workdirs configured yet.`;
            }
            
            if (this.taskMonitor.larkNotifier) {
              await this.taskMonitor.larkNotifier.sendCustomMessage(
                '📊 Settings Statistics',
                statsMessage,
                'blue',
                message.chat_id
              );
            }
            
            return {
              success: true,
              message: 'Stats sent'
            };
          }
          
          case 'status': {
            // Use unified status message generator
            const { statusMessage, gitActionButtons } = await this.generateStatusMessage(message.chat_id);
            
            // Send interactive message with action buttons
            if (this.taskMonitor.larkNotifier) {
              // Add refresh button
              const statusButtons = [
                {
                  tag: 'button',
                  text: {
                    tag: 'plain_text',
                    content: '🔄 Refresh'
                  },
                  type: 'default',
                  value: JSON.stringify({
                    action: 'show_status'
                  })
                }
              ];
              
              // Combine git action buttons with refresh button
              const allButtons = [...gitActionButtons, ...statusButtons];
              
              await this.taskMonitor.larkNotifier.sendInteractiveMessage(
                '📊 Status',
                statusMessage,
                'blue',
                allButtons,
                message.chat_id  // Send response to the requesting chat
              );
            }
            
            return {
              success: true,
              data: this.taskMonitor.getStatus()
            };
          }
          
          case 'rank': {
            logger.info(`Processing /rank command from Lark chat ${message.chat_id}`);
            try {
              // Initialize usage reporter if not exists
              if (!this.usageReporter) {
                logger.debug('Initializing UsageReporter for /rank command');
                const { UsageReporter } = await import('./usage-reporter.js');
                this.usageReporter = new UsageReporter();
              }

              // Generate and send daily usage report (force=true for manual command)
              const report = await this.usageReporter.generateDailyReport(true);
              if (report) {
                if (this.taskMonitor.larkNotifier) {
                  await this.taskMonitor.larkNotifier.sendCustomMessage(
                    report.title,
                    report.content,
                    'blue',
                    message.chat_id
                  );
                }
                logger.info(`Daily usage report sent to Lark chat ${message.chat_id}`);
                return {
                  success: true,
                  message: 'Usage report sent'
                };
              } else {
                if (this.taskMonitor.larkNotifier) {
                  await this.taskMonitor.larkNotifier.sendCustomMessage(
                    '❌ Error',
                    'Failed to generate usage report. Please try again later.',
                    'red',
                    message.chat_id
                  );
                }
                return {
                  success: false,
                  message: 'Failed to generate usage report'
                };
              }
            } catch (error) {
              // Log full error details
              logger.error(`Error handling /rank command for Lark chat ${message.chat_id}:`, {
                message: error.message,
                stack: error.stack,
                code: error.code,
                name: error.name
              });
              if (this.taskMonitor.larkNotifier) {
                await this.taskMonitor.larkNotifier.sendCustomMessage(
                  '❌ Error',
                  'Error generating usage report. Please try again later.',
                  'red',
                  message.chat_id
                );
              }
              return {
                success: false,
                message: 'Error generating usage report'
              };
            }
          }

          case 'usage': {
            logger.info(`Processing /usage command from Lark chat ${message.chat_id} with args: ${args}`);

            // Check if this is a reset command
            const resetArg = args.trim().toLowerCase();
            if (resetArg === 'reset all' || resetArg === 'reset opus' || resetArg === 'reset') {
              try {
                const { resetClaudeUsageCache } = await import('./claude-usage.js');

                // Determine what to reset
                let resetType = 'all'; // Default to all if just "reset"
                if (resetArg === 'reset opus') {
                  resetType = 'opus';
                }

                await resetClaudeUsageCache(resetType);

                const resetMessage = resetType === 'opus'
                  ? '✓ Opus usage cache reset successfully'
                  : '✓ All usage cache (session + opus) reset successfully';

                if (this.taskMonitor.larkNotifier) {
                  await this.taskMonitor.larkNotifier.sendCustomMessage(
                    '✅ Cache Reset',
                    resetMessage,
                    'green',
                    message.chat_id
                  );
                }
                return {
                  success: true,
                  message: 'Cache reset successfully'
                };
              } catch (error) {
                logger.error(`Error resetting usage cache for Lark chat ${message.chat_id}:`, {
                  message: error.message,
                  stack: error.stack
                });
                if (this.taskMonitor.larkNotifier) {
                  await this.taskMonitor.larkNotifier.sendCustomMessage(
                    '❌ Error',
                    `Error resetting usage cache: ${error.message}`,
                    'red',
                    message.chat_id
                  );
                }
                return {
                  success: false,
                  message: 'Error resetting cache'
                };
              }
            }

            // Normal usage query
            try {
              const { getClaudeUsage, formatUsageMarkdown } = await import('./claude-usage.js');

              // Get usage data with retry logic
              let usage = null;
              let retries = 2;
              while (retries > 0 && !usage) {
                try {
                  usage = await getClaudeUsage();
                  if (!usage || (usage.currentSession === null && usage.weekOpus === null)) {
                    throw new Error('Empty usage data returned');
                  }
                  break;
                } catch (err) {
                  retries--;
                  if (retries > 0) {
                    logger.warn(`Failed to get usage data, retrying... (${retries} attempts left)`);
                    await new Promise(resolve => setTimeout(resolve, 1000));
                  } else {
                    throw err;
                  }
                }
              }

              const usageMessage = await formatUsageMarkdown(usage);

              if (!usageMessage || usageMessage.trim().length === 0) {
                throw new Error('Empty formatted message');
              }

              if (this.taskMonitor.larkNotifier) {
                await this.taskMonitor.larkNotifier.sendCustomMessage(
                  '📊 Claude Usage',
                  usageMessage,
                  'blue',
                  message.chat_id
                );
              }

              return {
                success: true,
                message: 'Usage information sent'
              };
            } catch (error) {
              logger.error(`Error handling /usage command for Lark chat ${message.chat_id}:`, {
                message: error.message,
                stack: error.stack
              });
              if (this.taskMonitor.larkNotifier) {
                await this.taskMonitor.larkNotifier.sendCustomMessage(
                  '❌ Error',
                  'Error getting Claude usage information. Please try again later.',
                  'red',
                  message.chat_id
                );
              }
              return {
                success: false,
                message: 'Error getting usage information'
              };
            }
          }

          case 'cancel': {
            const taskId = args;
            if (!taskId) {
              if (this.taskMonitor.larkNotifier) {
                await this.taskMonitor.larkNotifier.sendCustomMessage(
                  '⚠️ Missing Task ID',
                  'Please provide a task ID to cancel.\nExample: /cancel abc123',
                  'orange',
                  message.chat_id
                );
              }
              return {
                success: false,
                message: 'Please provide a task ID to cancel'
              };
            }

            const cancelled = this.taskMonitor.cancelTask(taskId);
            // cancelTask returns { success: boolean, message: string }
            const cancelMessage = cancelled.success ?
              `✅ Task ${taskId} cancelled` :
              `❌ ${cancelled.message}`;

            if (this.taskMonitor.larkNotifier) {
              await this.taskMonitor.larkNotifier.sendCustomMessage(
                cancelled.success ? '✅ Cancelled' : '❌ Not Found',
                cancelMessage,
                cancelled.success ? 'green' : 'red',
                message.chat_id
              );
            }

            return {
              success: true,
              message: cancelMessage
            };
          }

          case 'cheatsheet': {
            const cheatsheet = `🚀 Ani-Code Lark Integration Cheatsheet

📋 INITIAL SETUP
${'─'.repeat(50)}
  1. Initialize project: \`ani-code remember "@main.md"\`
  2. Browser tasks: \`ani-code remember "@browser.md"\`
  3. Web development: \`ani-code remember "@web.md"\`

🤖 LARK COMMANDS
${'─'.repeat(50)}
  \`/add <prompt>\`       Create new Claude task
  \`/continue\`           Continue last task
  \`/commit\`             Commit current changes
  \`/plan <prompt>\`      Set tasks for later execution
  \`/yolo <prompt>\`      Execute with auto-accept

📝 MACROS (Customizable)
${'─'.repeat(50)}
  \`/$goal\`              Draft goals in pd/goals
  \`/$loop\`              Execute goal implementation loop
  \`/$goalcheck\`         Check goal completion status

⚙️ MACRO EXAMPLES

/$goalcheck:
  \`/add check pd/goals what is the current completion status\`

/$loop:
  \`/add read project prd, pick one or several tasks from goal
  and implement, after that, review your implementation
  if matching the goal, if so update the goal file progress,
  otherwise provide next step. Make sure you remember you
  are not only implementing the goals, but following goals
  and claude.md guidance. The goal can be optimized if you
  facing issue, but dont forget to mention your change in pd/.
  Every service can be auto reload, so dont run node npm
  command unless it is for validate compile or build.
  In the end summarize the current progress of goal
  implementation and major achievements, tell me now
  in which state and which goal, what is the percentage
  of completion, and is any manual step I need to involve.
  Check after the implementation if any issue preventing
  service running and page rendering, in the end tell me
  what is the current pd/goals implement progress in
  a short summary.\`

/$goal:
  \`/plan Please consider the following implementation plan,
  review what is needed, and identify any conflicts or
  improvements to the pd/goals stage and goal. Update
  the related goal file or create a new one as necessary.
  Always follow claude.md guidance when preparing the
  goal plan.\`

💡 TIPS
${'─'.repeat(50)}
  • Use \`@@opus\` or \`@@sonnet\` to select model
  • Combine tasks: \`/yolo implement auth + tests\`
  • Check status: \`ani-code status\`
  • Watch output: \`ani-code watch <id>\`

🔧 CREATING MACROS
${'─'.repeat(50)}
  List macros: \`ani-code workspace macro list\`
  Create macro: \`ani-code workspace macro set <name> "<command>"\`
  Example: \`ani-code workspace macro set test "/add run tests"\`
  Use in Lark: \`/$test\`

📚 DOCUMENTATION
${'─'.repeat(50)}
  • Main docs: https://docs.claude.com/claude-code
  • Report issues: https://github.com/anthropics/claude-code/issues
`;

            if (this.taskMonitor.larkNotifier) {
              await this.taskMonitor.larkNotifier.sendCustomMessage(
                '🚀 Cheatsheet',
                cheatsheet,
                'blue',
                message.chat_id
              );
            }

            return {
              success: true,
              message: 'Cheatsheet sent'
            };
          }

          default: {
            // Only show help if explicitly requested or if it's just a bot mention with no text
            if (!command || command === '') {
              // If bot was mentioned with no additional text, show help
              if (botMentioned) {
                const currentWorkdirNameHelp = this.chatSettings.getWorkdir(message.chat_id);
                const availableWorkdirsHelp = config.lark.workdirs;
                
                if (this.taskMonitor.larkNotifier) {
                  await this.taskMonitor.larkNotifier.sendHelpMessage(
                    message.chat_id,
                    currentWorkdirNameHelp,
                    availableWorkdirsHelp
                  );
                }
                
                return {
                  success: true,
                  message: 'Help sent'
                };
              }
              // For slash with no command, also show help
              return {
                success: true,
                message: 'Empty command'
              };
            }
            
            // For actual unknown commands, show error with suggestions and action buttons
            const availableWorkdirs = config.lark.workdirs;
            const currentWorkdirName = this.chatSettings.getWorkdir(message.chat_id);
            
            // Store the unrecognized text for potential use
            const unrecognizedText = `${command}${args ? ' ' + args : ''}`;
            
            if (this.taskMonitor.larkNotifier) {
              await this.taskMonitor.larkNotifier.sendUnrecognizedCommandMessage(
                message.chat_id,
                unrecognizedText,
                currentWorkdirName,
                availableWorkdirs
              );
            }
            
            return {
              success: false,
              message: `Unknown command: ${command}`
            };
          }
        }
      }
      
      // If message is empty, show status directly
      if (!messageText || !messageText.trim()) {
        logger.info('Received empty message, showing status directly');
        
        // Use unified status message generator
        const { statusMessage, gitActionButtons } = await this.generateStatusMessage(message.chat_id);
        
        // Send interactive message with action buttons
        if (this.taskMonitor.larkNotifier) {
          // Add refresh button
          const statusButtons = [
            {
              tag: 'button',
              text: {
                tag: 'plain_text',
                content: '🔄 Refresh'
              },
              type: 'default',
              value: JSON.stringify({
                action: 'show_status'
              })
            }
          ];
          
          // Combine git action buttons with refresh button
          const allButtons = [...gitActionButtons, ...statusButtons];
          
          await this.taskMonitor.larkNotifier.sendInteractiveMessage(
            '📊 Status',
            statusMessage,
            'blue',
            allButtons,
            message.chat_id  // Send response to the requesting chat
          );
        }
      } else {
        // If not a slash command, show the unrecognized command UI
        // This allows users to easily turn any message into a task
        logger.info(`Non-command message received: "${messageText}" (bot mentioned: ${botMentioned})`);
        
        const availableWorkdirs = config.lark.workdirs;
        const currentWorkdirName = this.chatSettings.getWorkdir(message.chat_id);
        
        if (this.taskMonitor.larkNotifier) {
          logger.info(`Sending unrecognized command UI for message: "${messageText}"`);
          try {
            await this.taskMonitor.larkNotifier.sendUnrecognizedCommandMessage(
              message.chat_id,
              messageText,
              currentWorkdirName,
              availableWorkdirs
            );
          } catch (err) {
            logger.error('Failed to send unrecognized command message:', err);
            // Still return success to prevent Lark from retrying
          }
        }
      }
      
      return {
        success: true,
        message: messageText && messageText.trim() ? 'Non-command message handled with action buttons' : 'Empty message handled'
      };
    }
    
    // Handle other v2.0 event types if needed
    return {
      success: true,
      message: `Event ${header.event_type} received`
    };
  }

  async processCardAction(actionData, originalData) {
    // Handle both old format and new shortened format
    let { action, taskId, workdir, command } = actionData;
    
    // Support shortened format from Telegram (a = action, t = shortened taskId)
    if (!action && actionData.a) {
      // Map shortened actions to full action names
      const actionMap = {
        'cancel': 'cancel_task',
        'retry': 'retry_task',
        'ct': 'create_task',
        'help': 'show_help'
      };
      action = actionMap[actionData.a] || actionData.a;
      
      // Also map shortened command codes
      if (actionData.c) {
        const commandMap = {
          'a': 'add',
          'c': 'continue',
          's': 'shell'
        };
        actionData.command = commandMap[actionData.c] || actionData.c;
      }
      
      // Map shortened prompt ID
      if (actionData.p) {
        actionData.pid = actionData.p;
      }
    }
    
    // Handle shortened task ID (need to find full task ID from partial)
    if (!taskId && actionData.t) {
      // Find task that ends with the shortened ID
      const shortId = actionData.t;
      const status = this.taskMonitor.getStatus();
      const allTasks = [...status.running, ...status.pending, ...status.completed];
      const matchingTask = allTasks.find(task => task.id.endsWith(shortId));
      if (matchingTask) {
        taskId = matchingTask.id;
      } else {
        // If no exact match, use the short ID as-is (will fail gracefully)
        taskId = shortId;
      }
    }
    
    // Extract chat ID from original data for context
    let chatId = null;
    if (originalData.open_chat_id) {
      chatId = originalData.open_chat_id;
    } else if (originalData.open_message_id) {
      // Try to get chat context from message
      chatId = originalData.open_message_id; // Use as fallback
    }
    
    switch (action) {
      case 'stop_loop': {
        // Handle stopping goal loop execution
        logger.info('Stop goal loop action triggered via button');

        if (chatId) {
          // States are keyed by raw chatId (number), so strip prefix and convert type
          const rawId = chatId.startsWith('telegram:') ? chatId.replace('telegram:', '') : chatId;
          const stateKey = isNaN(rawId) ? rawId : Number(rawId);

          if (this.goalLoopStates && this.goalLoopStates.has(stateKey)) {
            const state = this.goalLoopStates.get(stateKey);
            if (state.isActive) {
              state.isActive = false;

              // Cancel current task if running
              if (state.currentTaskId) {
                try {
                  const task = this.taskMonitor.getTask(state.currentTaskId);
                  if (task && (task.status === 'pending' || task.status === 'running')) {
                    this.taskMonitor.cancelTask(state.currentTaskId);
                  }
                } catch (error) {
                  logger.error(`Failed to cancel goal loop task: ${error.message}`);
                }
              }

              // Update status message to stopped
              await this.updateGoalLoopMessage(rawId, state, 'stopped');

              // Clean up state
              this.goalLoopStates.delete(stateKey);

              return {
                success: true,
                message: 'Goal loop stopped successfully'
              };
            }
          }
        }

        return {
          success: false,
          message: 'No active goal loop found'
        };
      }

      case 'refresh_loop': {
        // Handle refreshing goal loop status
        logger.info('Refresh goal loop action triggered via button');

        if (chatId) {
          // States are keyed by raw chatId (number), so strip prefix and convert type
          const rawId = chatId.startsWith('telegram:') ? chatId.replace('telegram:', '') : chatId;
          const stateKey = isNaN(rawId) ? rawId : Number(rawId);

          if (this.goalLoopStates && this.goalLoopStates.has(stateKey)) {
            const state = this.goalLoopStates.get(stateKey);
            if (state.isActive) {
              // Just update the message with current status
              const status = state.currentTaskId ? 'implementing' : 'starting';
              await this.updateGoalLoopMessage(rawId, state, status);

              return {
                success: true,
                message: 'Status refreshed'
              };
            }
          }
        }

        return {
          success: false,
          message: 'No active goal loop found'
        };
      }

      case 'stop_yolo': {
        // Handle stopping yolo execution - same as /stopyolo command
        logger.info('Stop YOLO action triggered via button');

        if (chatId && chatId.startsWith('telegram:')) {
          if (!this.telegramNotifier) {
            const { TelegramNotifier } = await import('./telegram-notifier.js');
            this.telegramNotifier = new TelegramNotifier();
          }
          const telegramChatId = chatId.replace('telegram:', '');
          // States are keyed by raw chatId (number), convert for Map lookup
          const yoloStateKey = isNaN(telegramChatId) ? telegramChatId : Number(telegramChatId);

          // Check for scheduled YOLO first (same as /stopyolo command)
          if (this.scheduledYoloTimeouts && this.scheduledYoloTimeouts.has(yoloStateKey)) {
            clearTimeout(this.scheduledYoloTimeouts.get(yoloStateKey));
            this.scheduledYoloTimeouts.delete(yoloStateKey);

            // Clear protection mode
            try {
              const { WorkspaceManager } = await import('./workspace-manager.js');
              const manager = new WorkspaceManager();
              await manager.initialize();

              const workspace = await manager.getWorkspaceForTelegramChat(String(telegramChatId));
              if (workspace) {
                await manager.clearYoloProtection(workspace.id);
              }
              await manager.close();
            } catch (error) {
              logger.error('Failed to clear scheduled YOLO protection:', error);
            }

            await this.telegramNotifier.sendMessage(telegramChatId,
              `⏰ *Scheduled YOLO Cancelled*\n\n` +
              `✅ Protection mode disabled\n` +
              `The scheduled execution has been cancelled.`,
              { parse_mode: 'Markdown' }
            );
            break;
          }

          // Stop ongoing YOLO execution (same logic as /stopyolo)
          if (this.yoloStates && this.yoloStates.has(yoloStateKey)) {
            const state = this.yoloStates.get(yoloStateKey);
            state.isActive = false;

            // Clear the status update interval
            if (state.statusUpdateInterval) {
              clearInterval(state.statusUpdateInterval);
              state.statusUpdateInterval = null;
              logger.info('Cleared YOLO status update interval');
            }

            // Cancel any currently running yolo tasks
            try {
              const status = this.taskMonitor.getStatus();
              const runningYoloTasks = status.running.filter(task =>
                task.metadata && task.metadata.source === 'yolo'
              );

              for (const task of runningYoloTasks) {
                logger.info(`Cancelling running YOLO task: ${task.name} (${task.id})`);
                this.taskMonitor.cancelTask(task.id);
              }
            } catch (error) {
              logger.error('Failed to cancel running yolo tasks:', error);
            }

            // Clear the protection mode
            if (this.telegramNotifier && this.telegramNotifier.clearYoloProtection) {
              this.telegramNotifier.clearYoloProtection(telegramChatId);
            }

            // Clear YOLO mode in database
            try {
              const { WorkspaceManager } = await import('./workspace-manager.js');
              const manager = new WorkspaceManager();
              await manager.initialize();

              // Get workspace for this chat
              const mapping = await manager.getWorkspaceForTelegramChat(telegramChatId);
              if (mapping && mapping.id) {
                await manager.clearYoloProtection(mapping.id);
                logger.info(`Cleared YOLO protection for workspace ${mapping.id} via button`);
              }

              await manager.close();
            } catch (error) {
              logger.error('Failed to clear YOLO mode in database:', error);
            }

            // Calculate cost if available
            let costInfo = '';
            if (this.taskMonitor.usageReporter && state.initialSnapshot) {
              const stopSnapshot = await this.taskMonitor.usageReporter.createTaskCompletionSnapshot('yolo-session', 'YOLO Session (Stopped)', { source: 'yolo' });
              if (stopSnapshot) {
                const duration = Math.round((new Date() - state.startTime) / 1000);
                const formattedDuration = duration >= 60
                  ? `${Math.floor(duration / 60)}m ${duration % 60}s`
                  : `${duration}s`;
                costInfo = `\n💰 Cost so far: $${stopSnapshot.cost.toFixed(4)}\n` +
                          `🔤 Tokens used: ${stopSnapshot.tokens.toLocaleString()}\n` +
                          `⏱️ Duration: ${formattedDuration}`;
              }
            }

            await this.telegramNotifier.sendMessage(telegramChatId,
              `⛔ *YOLO mode stopped*\n\n` +
              `✅ Protection mode disabled\n` +
              `Current progress: Plan ${state.currentPlanIndex + 1}\n` +
              `Executed: ${state.executedPlans.length} plans` +
              costInfo,
              { parse_mode: 'Markdown' }
            );
          } else {
            // Even if no in-memory state, check and clear database flag
            let workspaceCleared = false;
            try {
              const { WorkspaceManager } = await import('./workspace-manager.js');
              const manager = new WorkspaceManager();
              await manager.initialize();

              // Try multiple approaches to find and clear the workspace
              let workspaceId = null;

              // First try: Get workspace via telegram mapping
              try {
                const mapping = await manager.getWorkspaceForTelegramChat(telegramChatId);
                if (mapping && mapping.id) {
                  workspaceId = mapping.id;
                  logger.info(`Found workspace via telegram mapping: ${workspaceId}`);
                }
              } catch (mappingError) {
                logger.warn(`Failed to get telegram mapping: ${mappingError.message}`);
              }

              // Second try: Get workspace via workdir setting
              if (!workspaceId) {
                const fullChatId = `telegram:${telegramChatId}`;
                const workdirName = this.chatSettings.getWorkdir(fullChatId);
                if (workdirName) {
                  const availableWorkdirs = await this.getAvailableWorkdirs(fullChatId);
                  const workdirPath = availableWorkdirs[workdirName];
                  if (workdirPath) {
                    const workspace = await manager.getWorkspaceByPath(workdirPath);
                    if (workspace) {
                      workspaceId = workspace.id;
                      logger.info(`Found workspace via workdir path: ${workspaceId}`);
                    }
                  }
                }
              }

              // If we found a workspace, clear its protection
              if (workspaceId) {
                // First check if it has YOLO protection
                const workspace = await manager.getWorkspace(workspaceId);
                if (workspace && workspace.yolo_mode_active) {
                  // Clear the protection
                  await manager.clearYoloProtection(workspaceId);
                  workspaceCleared = true;
                  logger.info(`Cleared YOLO protection for workspace ${workspaceId} via button (no in-memory state)`);

                  await this.telegramNotifier.sendMessage(telegramChatId,
                    `⛔ *YOLO protection cleared*\n\n` +
                    `✅ Protection mode disabled\n` +
                    `You can now run manual tasks again.`,
                    { parse_mode: 'Markdown' }
                  );
                } else {
                  logger.info(`Workspace ${workspaceId} does not have YOLO protection active`);
                }
              } else {
                logger.warn('Could not find workspace for telegram chat to clear YOLO protection');
              }

              await manager.close();
            } catch (error) {
              logger.error('Failed to check/clear YOLO mode in database:', {
                error: error.message,
                stack: error.stack
              });
            }

            if (!workspaceCleared) {
              await this.telegramNotifier.sendMessage(telegramChatId,
                `ℹ️ No active YOLO execution to stop`,
                { parse_mode: 'Markdown' }
              );
            }
          }
        }

        return {
          success: true,
          message: 'YOLO execution stop requested'
        };
      }

      case 'yolo': {
        // Handle YOLO execution via button
        logger.info('YOLO action triggered via button');

        if (chatId && chatId.startsWith('telegram:')) {
          const telegramChatId = chatId.replace('telegram:', '');

          // Execute the yolo command
          try {
            await this.processTelegramCommand('/yolo', telegramChatId, originalData.open_message_id);
            return {
              success: true,
              message: 'YOLO execution started'
            };
          } catch (error) {
            logger.error('Failed to execute YOLO via button:', error);
            return {
              success: false,
              error: error.message
            };
          }
        }

        return {
          success: false,
          error: 'No valid chat context for YOLO execution'
        };
      }

      case 'exit_protection': {
        // Handle exiting protection mode while keeping yolo running
        logger.info('Exit protection action triggered');

        if (chatId && chatId.startsWith('telegram:')) {
          if (!this.telegramNotifier) {
            const { TelegramNotifier } = await import('./telegram-notifier.js');
            this.telegramNotifier = new TelegramNotifier();
          }
          const telegramChatId = chatId.replace('telegram:', '');

          // Get workspace for this chat
          const workspaceManager = this.workspaceManager || await (async () => {
            const { WorkspaceManager } = await import('./workspace-manager.js');
            const manager = new WorkspaceManager();
            await manager.initialize();
            return manager;
          })();

          // Find workspace with active yolo mode
          const workdir = this.chatSettings.getWorkdir(chatId);
          if (workdir) {
            const workspace = await workspaceManager.getWorkspaceByPath(workdir);
            if (workspace) {
              const yoloStatus = await workspaceManager.getYoloStatus(workspace.id);
              if (yoloStatus && yoloStatus.active) {
                // Clear protection mode
                await workspaceManager.clearYoloProtection(workspace.id);

                // Clear from telegram notifier
                this.telegramNotifier.clearYoloProtection(telegramChatId);

                // Update the status message
                // Try to get executionData from yoloStates if available
                const yoloState = this.yoloStates?.get(telegramChatId);
                const executionData = yoloState?.executionData || {
                  startTime: Date.now(),
                  commits: [],
                  usage: { cost: 0, tokens: 0 },
                  currentStepIndex: 0,
                  totalSteps: 0,
                  messageVersion: yoloStatus.messageVersion || 1,
                  providerId: null
                };

                const statusMessage = await this.telegramNotifier.formatYoloStatusMessage(
                  workspace.name,
                  yoloStatus.plansTotal,
                  yoloStatus.plansCompleted,
                  { plan_id: yoloStatus.currentPlan },
                  'executing',
                  executionData
                );

                // Extract version before modifying message
                const versionMatch = statusMessage.match(/\[v(\d+)\]$/);
                const version = versionMatch ? versionMatch[0] : '';

                // Modify message but preserve version tag
                let updatedMessage = statusMessage.replace('ENABLED', 'DISABLED (Manual Override)');
                if (version) {
                  updatedMessage = updatedMessage.replace(version, ''); // Remove old version
                  updatedMessage = updatedMessage + '\n\n🔓 *Protection disabled* - Manual tasks now allowed ' + version; // Add version at end
                } else {
                  updatedMessage = updatedMessage + '\n\n🔓 *Protection disabled* - Manual tasks now allowed';
                }

                // Always resend to keep at bottom
                logger.info(`[YOLO] Resending status for protection disabled`);
                await this.telegramNotifier.sendYoloStatus(
                  telegramChatId,
                  updatedMessage,
                  { showButtons: false, workspace }
                );
              }
            }
          }
        }

        return {
          success: true,
          message: 'Protection mode disabled'
        };
      }

      case 'refresh_yolo_status': {
        // Handle refreshing the YOLO status by resending it
        logger.info('Refresh YOLO status action triggered');

        if (chatId && chatId.startsWith('telegram:')) {
          if (!this.telegramNotifier) {
            const { TelegramNotifier } = await import('./telegram-notifier.js');
            this.telegramNotifier = new TelegramNotifier();
          }
          const telegramChatId = chatId.replace('telegram:', '');

          // Get workspace for this chat
          const workspaceManager = this.workspaceManager || await (async () => {
            const { WorkspaceManager } = await import('./workspace-manager.js');
            const manager = new WorkspaceManager();
            await manager.initialize();
            return manager;
          })();

          // Find workspace with active yolo mode for this Telegram chat
          // First try to get workspace connected to this Telegram chat
          let workspace = await workspaceManager.getWorkspaceForTelegramChat(telegramChatId);
          if (!workspace && config.gateway.enabled) {
            // In gateway mode, ensure gateway workspace exists in database
            workspace = await workspaceManager.ensureGatewayWorkspace();
            logger.debug('Gateway mode: Using gateway workspace for refresh_yolo');
          }

          if (workspace) {
            const yoloStatus = await workspaceManager.getYoloStatus(workspace.id);
            if (yoloStatus && yoloStatus.active) {
                // Get or create executionData
                const yoloState = this.yoloStates?.get(telegramChatId);
                const executionData = yoloState?.executionData || {
                  startTime: yoloStatus.startTime || Date.now(),
                  commits: [],
                  usage: { cost: 0, tokens: 0 },
                  currentStepIndex: 0,
                  totalSteps: 0,
                  messageVersion: (yoloStatus.messageVersion || 1) + 1,  // Increment version for resend
                  providerId: null
                };

                // If there's existing yoloState, increment the message version
                if (yoloState) {
                  executionData.messageVersion = (executionData.messageVersion || 1) + 1;
                  yoloState.executionData = executionData;
                }

                const statusMessage = await this.telegramNotifier.formatYoloStatusMessage(
                  workspace.name,
                  yoloStatus.plansTotal,
                  yoloStatus.plansCompleted,
                  { plan_id: yoloStatus.currentPlan },
                  'executing',
                  executionData
                );

                // Update the existing message
                const oldMessageId = yoloStatus.statusMessageId || (yoloState ? yoloState.yoloStatusMessageId : null);
                if (oldMessageId) {
                  try {
                    // Try to update the existing message first
                    logger.info(`[YOLO] Refreshing status by updating message ${oldMessageId}`);
                    await this.telegramNotifier.updateYoloStatus(
                      telegramChatId,
                      oldMessageId,
                      statusMessage,
                      { showButtons: true }
                    );
                    logger.info(`[YOLO] Successfully refreshed status message ${oldMessageId}`);
                  } catch (updateError) {
                    // If update fails (message was deleted), send a new one
                    logger.warn(`[YOLO] Failed to update message ${oldMessageId}: ${updateError.message}`);
                    logger.info(`[YOLO] Sending new status message since update failed`);

                    const result = await this.telegramNotifier.sendYoloStatus(
                      telegramChatId,
                      statusMessage,
                      { showButtons: true, workspace }
                    );

                    // Update the message ID if available
                    if (result && (result.message_id || result.result?.message_id)) {
                      const newMessageId = result.message_id || result.result?.message_id;
                      await workspaceManager.updateYoloStatusMessageId(workspace.id, newMessageId);

                      // Update yoloState if it exists
                      if (yoloState) {
                        yoloState.yoloStatusMessageId = newMessageId;
                      }
                    }
                  }
                } else {
                  // No existing message, send a new one
                  logger.info(`[YOLO] No existing message found, sending new status`);
                  const result = await this.telegramNotifier.sendYoloStatus(
                    telegramChatId,
                    statusMessage,
                    { showButtons: true, workspace }
                  );

                  // Update the message ID if available
                  if (result && (result.message_id || result.result?.message_id)) {
                    const newMessageId = result.message_id || result.result?.message_id;
                    await workspaceManager.updateYoloStatusMessageId(workspace.id, newMessageId);

                    // Update yoloState if it exists
                    if (yoloState) {
                      yoloState.yoloStatusMessageId = newMessageId;
                    }
                  }
                }

                return {
                  success: true,
                  message: 'YOLO status refreshed'
                };
              } else {
                // No active YOLO mode
                await this.telegramNotifier.sendMessage(telegramChatId,
                  '❌ No active YOLO execution found for this workspace.',
                  { parse_mode: 'Markdown' });
              }
            } else {
              // No workspace connected to this Telegram chat
              await this.telegramNotifier.sendMessage(telegramChatId,
                '❌ No workspace connected to this chat. Use `/connect <token>` to connect.',
                { parse_mode: 'Markdown' });
            }
        }

        return {
          success: true,
          message: 'Refresh YOLO status action handled'
        };
      }

      case 'set_workdir':
        if (!workdir) {
          return {
            success: false,
            message: 'Workdir name is required for set_workdir'
          };
        }
        
        const availableWorkdirs = config.lark.workdirs;
        if (!availableWorkdirs[workdir]) {
          return {
            success: false,
            message: `Unknown workdir: ${workdir}`
          };
        }
        
        // Set the workdir for this chat
        if (chatId) {
          const workdirPath = config.lark.workdirs[workdir];
          await this.chatSettings.setWorkdir(chatId, workdir, workdirPath);
        }
        
        // Check if this is from Telegram
        if (chatId && chatId.startsWith('telegram:')) {
          // Get or initialize Telegram notifier
          if (!this.telegramNotifier) {
            const { TelegramNotifier } = await import('./telegram-notifier.js');
            this.telegramNotifier = new TelegramNotifier();
          }
          
          const telegramChatId = chatId.replace('telegram:', '');
          await this.telegramNotifier.sendMessage(telegramChatId, 
            `✅ Working directory set to: *${workdir}*\n📁 Path: \`${availableWorkdirs[workdir]}\`\n\nAll future tasks will run from this directory.`,
            { parse_mode: 'Markdown' });
        } else if (this.taskMonitor.larkNotifier) {
          await this.taskMonitor.larkNotifier.sendCustomMessage(
            '✅ Working Directory Set',
            `Working directory set to:\n**${workdir}** → ${availableWorkdirs[workdir]}\n\nAll future tasks will run from this directory.`,
            'green',
            chatId
          );
        }
        
        return {
          success: true,
          message: `Workdir set to ${workdir}`
        };
        
      case 'run_task': {
        if (!command) {
          return {
            success: false,
            message: 'Command is required for run_task'
          };
        }
        
        // Get workdir for this chat
        const selectedWorkdirName = chatId ? this.chatSettings.getWorkdir(chatId) : null;
        const availableWorkdirsForTask = await this.getAvailableWorkdirs(chatId);
        
        if (!selectedWorkdirName) {
          // Check if this is from Telegram and use appropriate notifier
          if (chatId && chatId.startsWith('telegram:')) {
            if (!this.telegramNotifier) {
              const { TelegramNotifier } = await import('./telegram-notifier.js');
              this.telegramNotifier = new TelegramNotifier();
            }
            const telegramChatId = chatId.replace('telegram:', '');
            await this.telegramNotifier.sendMessage(telegramChatId, 
              '⚠️ Working Directory Not Selected\n\nPlease connect to a workspace first using /connect [token]');
          } else if (this.taskMonitor.larkNotifier) {
            await this.taskMonitor.larkNotifier.sendCustomMessage(
              '⚠️ Working Directory Not Selected',
              'Please select a working directory first using the /workdir command or the quick setup buttons.',
              'orange',
              chatId
            );
          }
          
          return {
            success: false,
            message: 'Working directory not selected'
          };
        }
        
        const taskWorkdir = availableWorkdirsForTask[selectedWorkdirName];
        if (!taskWorkdir) {
          return {
            success: false,
            message: 'Selected workdir no longer available'
          };
        }
        
        // For ani-code doc -y, keep the Claude template approach
        if (command === 'ani-code doc -y') {
          // Handle doc command with Claude template
          const { basename } = await import('path');
          const projectDir = basename(taskWorkdir);
          const now = new Date();
          const hour = now.getHours().toString().padStart(2, '0');
          const minute = now.getMinutes().toString().padStart(2, '0');
          
          const taskName = `${projectDir}-doc-${hour}${minute}`;
          const dateStr = new Date().toISOString().split('T')[0];
          const claudeCommand = `You are a project documentation generator. Your task is to update the project documentation in the pd/ folder.
IMPORTANT: You have full permissions to read and write files in the pd/ folder. Check CLAUDE.md for your permissions.
Current date: ${dateStr}
Tasks to complete:
1. Create or update the daily change log at pd/changes/${dateStr}.md
   - Run 'git log --oneline --since="today" --until="tomorrow"' to get today's commits
   - Format as a markdown list with clear descriptions
   - Group related changes together
   - Include commit hashes for reference
2. Update API documentation in pd/api/ if there are code changes`;
          
          const taskOptions = {
            cwd: taskWorkdir,
            source: 'lark_doc_command',
            chatId: originalData.open_chat_id || chatId  // Store chat ID for response routing
          };
          
          const task = this.taskMonitor.addTask(taskName, claudeCommand, taskOptions);
          
          logger.info(`Created Claude doc task: ${task.id} in ${taskWorkdir}`);
          
          return {
            success: true,
            message: `Claude doc task created with ID: ${task.id}`,
            taskId: task.id
          };
        }
        
        // For all other commands, run as shell command
        // Add "shell:" prefix to ensure it runs as shell command, not Claude prompt
        // Determine source based on chat ID
        const isFromTelegram = chatId && chatId.startsWith('telegram:');
        const taskSource = isFromTelegram ? 'telegram_button' : 'lark_button';
        const taskPrefix = isFromTelegram ? 'Telegram Task' : 'Lark Task';
        
        const task = this.taskMonitor.addTask(
          `${taskPrefix}: ${command.substring(0, 50)}...`,
          `shell:${command}`,
          {
            cwd: taskWorkdir,
            source: taskSource,
            chatId: originalData.open_chat_id || chatId  // Store chat ID for response routing
          }
        );
        
        return {
          success: true,
          taskId: task.id,
          message: `Task created: ${task.name}`
        };
      }
        
      case 'history': {
        // Handle Browse History button from task completion
        // Extract start and end times from action data (in seconds)
        const startTimeSec = actionData.s; // Task start time in seconds
        const endTimeSec = actionData.e;   // Task end time in seconds

        if (!startTimeSec || !endTimeSec) {
          return {
            success: false,
            message: 'Missing time parameters for history'
          };
        }

        // Convert seconds to milliseconds for filtering
        const startTime = startTimeSec * 1000;
        const endTime = endTimeSec * 1000;

        // Check if this is from Telegram
        if (chatId && chatId.startsWith('telegram:')) {
          const telegramChatId = chatId.replace('telegram:', '');

          // Get or initialize Telegram notifier
          if (!this.telegramNotifier) {
            const { TelegramNotifier } = await import('./telegram-notifier.js');
            this.telegramNotifier = new TelegramNotifier();
          }

          // Send generating message
          const generatingMsg = await this.telegramNotifier.sendMessage(telegramChatId,
            'Generating task history...'
          );

          try {
            // Import the history viewer module
            const { ClaudeHistoryViewer } = await import('./claude-history-viewer.js');
            const viewer = new ClaudeHistoryViewer();

            // Get current project path
            const workdirName = this.chatSettings.getWorkdir(chatId);
            const workdirs = await this.getAvailableWorkdirs(chatId);
            const projectPath = workdirs[workdirName] || workdirName;

            // Generate HTML from latest session (no time filtering)
            const html = await viewer.generateFilteredHTML(projectPath, startTime, endTime);

            // Get session metadata from latest session file
            const sessionFile = await viewer.findLatestSession(projectPath);
            const allMessages = sessionFile ? await viewer.parseSession(sessionFile) : [];

            // Use all messages from the latest session (no time filtering)
            const messages = allMessages;

            // Calculate tokens for all messages
            let totalTokens = 0;
            messages.forEach(msg => {
              if (msg.usage) {
                totalTokens += (msg.usage.input_tokens || 0) + (msg.usage.output_tokens || 0);
              }
            });

            // Get actual time range from messages
            let startDate, endDate;
            if (messages.length > 0) {
              startDate = new Date(messages[0].timestamp).toLocaleTimeString();
              endDate = new Date(messages[messages.length - 1].timestamp).toLocaleTimeString();
            } else {
              startDate = new Date(startTime).toLocaleTimeString();
              endDate = new Date(endTime).toLocaleTimeString();
            }

            // Save HTML to temp file
            const tmpDir = '/tmp';
            const timestamp = Date.now();
            const htmlFile = path.join(tmpDir, `claude-task-history-${timestamp}.html`);
            await fs.promises.writeFile(htmlFile, html, 'utf-8');

            logger.info(`Task history HTML saved to: ${htmlFile}`);

            // Build caption with footer
            const projectName = path.basename(projectPath);
            const workdir = projectName;
            let caption = `📜 *TASK HISTORY*\n\n` +
              `*Project:* ${projectName}\n` +
              `*Time:* ${startDate} - ${endDate}\n` +
              `*Messages:* ${messages.length}\n` +
              `*Tokens:* ${totalTokens.toLocaleString()}\n\n` +
              `Download and open in browser.`;

            // Add footer using telegram notifier's formatFooter method
            caption += await this.telegramNotifier.formatFooter(workdir);

            // Create file stream for upload
            const fileStream = fs.createReadStream(htmlFile);

            // Generate filename with project, datetime, and task time range
            const startTimeStr = new Date(startTime).toISOString().slice(0, 19).replace(/[T:]/g, '-');
            const filename = `${projectName}-task-${startTimeStr}.html`;

            // Send HTML file with Markdown formatting for caption
            await this.telegramNotifier.sendDocument(telegramChatId, fileStream, {
              caption: caption,
              filename: filename,
              parse_mode: 'Markdown'
            });

            // Clean up
            await fs.promises.unlink(htmlFile);

            // Delete generating message
            if (generatingMsg && generatingMsg.result?.message_id) {
              await this.telegramNotifier.deleteMessage(telegramChatId, generatingMsg.result.message_id);
            }

            logger.info(`Task history sent to chat ${telegramChatId}`);

            return {
              success: true,
              message: 'Task history generated'
            };
          } catch (error) {
            logger.error(`Error generating task history:`, {
              error: error.message,
              stack: error.stack
            });

            // If no messages in time range, fallback to latest history
            if (error.message.includes('No messages found in the specified time range')) {
              logger.info('No messages in time range, falling back to latest history');

              try {
                // Import the history viewer module
                const { ClaudeHistoryViewer } = await import('./claude-history-viewer.js');
                const viewer = new ClaudeHistoryViewer();

                // Get current project path
                const workdirName = this.chatSettings.getWorkdir(chatId);
                const workdirs = await this.getAvailableWorkdirs(chatId);
                const projectPath = workdirs[workdirName] || workdirName;

                // Generate HTML for the latest session
                const html = await viewer.generateLatestSessionHTML(projectPath);

                // Get session metadata for caption
                const sessionFile = await viewer.findLatestSession(projectPath);
                const messages = sessionFile ? await viewer.parseSession(sessionFile) : [];

                // Calculate total tokens
                let totalTokens = 0;
                messages.forEach(msg => {
                  if (msg.usage) {
                    totalTokens += (msg.usage.input_tokens || 0) + (msg.usage.output_tokens || 0);
                  }
                });

                // Get session date
                const sessionDate = messages.length > 0
                  ? new Date(messages[0].timestamp).toLocaleDateString('en-US', {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric'
                    })
                  : new Date().toLocaleDateString();

                // Save HTML to temp file
                const tmpDir = '/tmp';
                const timestamp = Date.now();
                const htmlFile = path.join(tmpDir, `claude-history-${timestamp}.html`);
                await fs.promises.writeFile(htmlFile, html, 'utf-8');

                logger.info(`Latest history HTML saved to: ${htmlFile}`);

                // Build caption with metadata and footer
                const projectName = path.basename(projectPath);
                const workdir = projectName;
                let caption = `📜 *SESSION HISTORY* (Latest)\n\n` +
                  `ℹ️ No messages in requested time range\n` +
                  `Showing latest session instead\n\n` +
                  `*Project:* ${projectName}\n` +
                  `*Date:* ${sessionDate}\n` +
                  `*Messages:* ${messages.length}\n` +
                  `*Tokens:* ${totalTokens.toLocaleString()}\n\n` +
                  `Download and open in browser.`;

                // Add footer using telegram notifier's formatFooter method
                caption += await this.telegramNotifier.formatFooter(workdir);

                // Create file stream for upload
                const fileStream = fs.createReadStream(htmlFile);

                // Generate filename with project name and date
                const filename = `${projectName}-${sessionDate.replace(/\s+/g, '-')}.html`;

                // Send HTML file with Markdown formatting for caption
                await this.telegramNotifier.sendDocument(telegramChatId, fileStream, {
                  caption: caption,
                  filename: filename,
                  parse_mode: 'Markdown'
                });

                // Clean up
                await fs.promises.unlink(htmlFile);

                // Delete generating message
                if (generatingMsg && generatingMsg.result?.message_id) {
                  await this.telegramNotifier.deleteMessage(telegramChatId, generatingMsg.result.message_id);
                }

                logger.info(`Latest session history sent to chat ${telegramChatId}`);

                return {
                  success: true,
                  message: 'Latest session history generated'
                };
              } catch (fallbackError) {
                logger.error(`Error generating fallback history:`, {
                  error: fallbackError.message,
                  stack: fallbackError.stack
                });

                await this.telegramNotifier.sendMessage(telegramChatId,
                  'Error generating history.\n\n' + fallbackError.message
                );

                // Delete generating message
                if (generatingMsg && generatingMsg.result?.message_id) {
                  await this.telegramNotifier.deleteMessage(telegramChatId, generatingMsg.result.message_id);
                }

                return {
                  success: false,
                  message: fallbackError.message
                };
              }
            }

            // For other errors, show error message
            await this.telegramNotifier.sendMessage(telegramChatId,
              'Error generating task history.\n\n' + error.message
            );

            // Delete generating message
            if (generatingMsg && generatingMsg.result?.message_id) {
              await this.telegramNotifier.deleteMessage(telegramChatId, generatingMsg.result.message_id);
            }

            return {
              success: false,
              message: error.message
            };
          }
        }

        return {
          success: false,
          message: 'History action only supported in Telegram'
        };
      }

      case 'show_status': {
        // Use unified status message generator - pass chatId if available
        const { statusMessage, gitActionButtons } = await this.generateStatusMessage(chatId);
        
        // Check if this is from Telegram
        if (chatId && chatId.startsWith('telegram:')) {
          // Get or initialize Telegram notifier
          if (!this.telegramNotifier) {
            const { TelegramNotifier } = await import('./telegram-notifier.js');
            this.telegramNotifier = new TelegramNotifier();
          }
          
          const telegramChatId = chatId.replace('telegram:', '');
          await this.showTelegramStatus(telegramChatId);
        } else if (this.taskMonitor.larkNotifier) {
          // Add refresh button
          const statusButtons = [
            {
              tag: 'button',
              text: {
                tag: 'plain_text',
                content: '🔄 Refresh'
              },
              type: 'default',
              value: JSON.stringify({
                action: 'show_status'
              })
            }
          ];
          
          // Combine git action buttons with refresh button
          const allButtons = [...gitActionButtons, ...statusButtons];
          
          await this.taskMonitor.larkNotifier.sendInteractiveMessage(
            '📊 Status',
            statusMessage,
            'blue',
            allButtons,
            originalData.open_chat_id || chatId  // Send response to originating chat
          );
        }
        
        return {
          success: true,
          message: 'Status sent'
        };
      }
        
      case 'run_check': {
        // Handle check command from button click
        const platform = chatId && chatId.startsWith('telegram:') ? 'telegram' : 'lark';
        const actualChatId = platform === 'telegram' ? chatId.replace('telegram:', '') : chatId;
        
        // Call the handleCheckCommand method
        await this.handleCheckCommand(actualChatId, '', platform);
        
        return {
          success: true,
          message: 'Check command initiated'
        };
      }
        
      // Removed list_workdirs action - users should use /connect with token instead
        
      case 'create_task':
        // Handle generic task creation from unrecognized command buttons
        {
          const taskCommand = actionData.command;

          // Retrieve prompt from stored ID (for Telegram callbacks) or use direct prompt
          let taskPrompt;
          let taskAttachments = null;
          if (actionData.pid) {
            // Retrieve stored prompt using ID
            const storedData = this.pendingPrompts.get(actionData.pid);
            if (!storedData) {
              return {
                success: false,
                message: 'Prompt expired or not found. Please try again.'
              };
            }
            // Handle both old string format and new object format with attachments
            if (typeof storedData === 'string') {
              taskPrompt = storedData;
            } else {
              taskPrompt = storedData.text;
              taskAttachments = storedData.attachments;
            }
            // Clean up the stored prompt
            this.pendingPrompts.delete(actionData.pid);
          } else {
            // Fallback to direct prompt (for backwards compatibility)
            taskPrompt = actionData.prompt;
          }

          if (!taskCommand || !taskPrompt) {
            return {
              success: false,
              message: 'Command and prompt are required for task creation'
            };
          }

          // Get workdir for this chat
          const selectedWorkdirName = chatId ? this.chatSettings.getWorkdir(chatId) : null;
          const availableWorkdirs = config.lark.workdirs;
          const selectedWorkdirPath = selectedWorkdirName ? availableWorkdirs[selectedWorkdirName] : null;

          if (taskCommand !== 'shell' && !selectedWorkdirPath) {
            if (this.taskMonitor.larkNotifier) {
              await this.taskMonitor.larkNotifier.sendCustomMessage(
                '⚠️ Working Directory Not Set',
                `Please select a working directory first.\nUse: /workdir [name]`,
                'orange',
                chatId
              );
            }
            return {
              success: false,
              message: 'Working directory not set'
            };
          }

          let taskName, finalCommand, taskOptions;

          switch (taskCommand) {
            case 'add':
              taskName = `claude-add-${Date.now()}`;
              finalCommand = taskPrompt;
              taskOptions = {
                cwd: selectedWorkdirPath,
                source: 'lark_unrecognized_add',
                chatId: originalData.open_chat_id || chatId
              };
              break;

            case 'continue':
              taskName = `claude-continue-${Date.now()}`;
              finalCommand = `-c ${taskPrompt}`;
              taskOptions = {
                cwd: selectedWorkdirPath,
                source: 'lark_unrecognized_continue',
                chatId: originalData.open_chat_id || chatId
              };
              break;

            case 'shell':
              taskName = `shell-${Date.now()}`;
              finalCommand = taskPrompt;
              taskOptions = {
                cwd: selectedWorkdirPath || process.cwd(),
                source: 'lark_unrecognized_shell',
                chatId: originalData.open_chat_id || chatId,
                isShellCommand: true
              };
              break;

            default:
              return {
                success: false,
                message: `Unknown task command: ${taskCommand}`
              };
          }

          // Add attachments if present (from web chat image uploads)
          if (taskAttachments && taskAttachments.length > 0) {
            taskOptions.attachments = taskAttachments;
            logger.info(`[create_task] Adding ${taskAttachments.length} attachment(s) to task`);
          }

          const task = this.taskMonitor.addTask(taskName, finalCommand, taskOptions);
          
          logger.info(`Created ${taskCommand} task from unrecognized input: ${task.id}`);
          
          // Send confirmation message for Telegram users
          if (chatId && chatId.startsWith('telegram:')) {
            if (!this.telegramNotifier) {
              const { TelegramNotifier } = await import('./telegram-notifier.js');
              this.telegramNotifier = new TelegramNotifier();
            }
            
            const telegramChatId = chatId.replace('telegram:', '');
            const taskTypeEmoji = taskCommand === 'shell' ? '⚡' : 
                                 taskCommand === 'continue' ? '↪️' : 
                                 '🤖';
            const taskTypeText = taskCommand === 'shell' ? 'Shell command' : 
                                taskCommand === 'continue' ? 'Continue task' : 
                                'Claude task';
            
            // Create inline keyboard with process button
            const keyboard = {
              inline_keyboard: [[
                {
                  text: '▶️ Watch Task Progress',
                  callback_data: `/process ${task.id}`
                }
              ]]
            };
            
            await this.telegramNotifier.sendMessage(telegramChatId,
              `${taskTypeEmoji} *${taskTypeText} created*\n\n` +
              `Task ID: \`${task.id}\`\n` +
              `Status: ${task.status === 'running' ? '🟡 Running' : '⏳ Queued'}\n` +
              `Working dir: ${selectedWorkdirName || 'current'}`,
              { 
                parse_mode: 'Markdown',
                reply_markup: keyboard
              }
            );
          }
          
          return {
            success: true,
            message: `Task created with ID: ${task.id}`,
            taskId: task.id
          };
        }
        
      case 'claude_add':
        // Handle Claude add button click - guide user to enter prompt
        {
          // Get workdir for this chat
          const selectedWorkdirName = chatId ? this.chatSettings.getWorkdir(chatId) : null;
          const availableWorkdirs = config.lark.workdirs;
          const selectedWorkdirPath = selectedWorkdirName ? availableWorkdirs[selectedWorkdirName] : null;
          
          if (!selectedWorkdirPath) {
            if (this.taskMonitor.larkNotifier) {
              await this.taskMonitor.larkNotifier.sendCustomMessage(
                '⚠️ Working Directory Not Set',
                `Please select a working directory first.\nUse: /workdir [name]`,
                'orange',
                chatId
              );
            }
            return {
              success: false,
              message: 'Working directory not set'
            };
          }
          
          // Send guidance message instead of creating task with default prompt
          if (chatId && chatId.startsWith('telegram:')) {
            // Get or initialize Telegram notifier
            if (!this.telegramNotifier) {
              const { TelegramNotifier } = await import('./telegram-notifier.js');
              this.telegramNotifier = new TelegramNotifier();
            }
            
            const telegramChatId = chatId.replace('telegram:', '');
            await this.telegramNotifier.sendMessage(telegramChatId,
              `💡 *Please enter your prompt for Claude:*\n\nType your request and send it as a message. For example:\n• "Fix the bug in the login function"\n• "Add a new feature for user profiles"\n• "Help me understand how the API works"\n\n📝 Just type your message and press send!`,
              { parse_mode: 'Markdown' });
          } else if (this.taskMonitor.larkNotifier) {
            await this.taskMonitor.larkNotifier.sendCustomMessage(
              '💡 Enter Your Prompt',
              `Please type your request for Claude and send it as a message.\n\nExamples:\n• Fix the bug in the login function\n• Add a new feature for user profiles\n• Help me understand how the API works`,
              'blue',
              chatId
            );
          }
          
          logger.info(`Sent prompt guidance for Claude add in ${selectedWorkdirPath}`);
          
          return {
            success: true,
            message: 'Prompt guidance sent'
          };
        }
        
      case 'claude_continue':
        // Handle Claude continue button click
        {
          // Get workdir for this chat
          const selectedWorkdirName = chatId ? this.chatSettings.getWorkdir(chatId) : null;
          const availableWorkdirs = await this.getAvailableWorkdirs(chatId);
          const selectedWorkdirPath = selectedWorkdirName ? availableWorkdirs[selectedWorkdirName] : null;
          
          if (!selectedWorkdirPath) {
            // Check if this is from Telegram
            if (chatId && chatId.startsWith('telegram:')) {
              // Get or initialize Telegram notifier
              if (!this.telegramNotifier) {
                const { TelegramNotifier } = await import('./telegram-notifier.js');
                this.telegramNotifier = new TelegramNotifier();
              }
              
              const telegramChatId = chatId.replace('telegram:', '');
              await this.telegramNotifier.sendMessage(telegramChatId,
                '⚠️ *Working Directory Not Set*\n\nPlease select a working directory first.\nUse: `/workdir [name]`',
                { parse_mode: 'Markdown' });
            } else if (this.taskMonitor.larkNotifier) {
              await this.taskMonitor.larkNotifier.sendCustomMessage(
                '⚠️ Working Directory Not Set',
                `Please select a working directory first.\nUse: /workdir [name]`,
                'orange',
                chatId
              );
            }
            return {
              success: false,
              message: 'Working directory not set'
            };
          }
          
          // Send guidance message instead of creating task with default prompt
          if (chatId && chatId.startsWith('telegram:')) {
            // Get or initialize Telegram notifier
            if (!this.telegramNotifier) {
              const { TelegramNotifier } = await import('./telegram-notifier.js');
              this.telegramNotifier = new TelegramNotifier();
            }
            
            const telegramChatId = chatId.replace('telegram:', '');
            await this.telegramNotifier.sendMessage(telegramChatId,
              `↪️ *Please enter your continuation prompt:*\n\nType what you want Claude to continue working on. For example:\n• "Continue fixing the remaining issues"\n• "Keep working on the feature"\n• "Continue with the next step"\n\n💬 Or simply type "continue" to proceed with the previous context.\n\n📝 Just type your message and press send!`,
              { parse_mode: 'Markdown' });
          } else if (this.taskMonitor.larkNotifier) {
            await this.taskMonitor.larkNotifier.sendCustomMessage(
              '↪️ Enter Continuation Prompt',
              `Please type what you want Claude to continue working on.\n\nExamples:\n• Continue fixing the remaining issues\n• Keep working on the feature\n• Continue with the next step\n\nOr simply type "continue" to proceed with the previous context.`,
              'blue',
              chatId
            );
          }
          
          logger.info(`Sent prompt guidance for Claude continue in ${selectedWorkdirPath}`);
          
          return {
            success: true,
            message: 'Prompt guidance sent'
          };
        }
        
      case 'show_help':
        // Handle help button click
        {
          const currentWorkdirName = chatId ? this.chatSettings.getWorkdir(chatId) : null;

          // Check if this is a Telegram chat (has telegram: prefix)
          if (chatId && chatId.startsWith('telegram:')) {
            // Get Telegram chat ID without prefix
            const telegramChatId = chatId.replace('telegram:', '');

            // Get or initialize Telegram notifier
            if (!this.telegramNotifier) {
              const { TelegramNotifier } = await import('./telegram-notifier.js');
              this.telegramNotifier = new TelegramNotifier();
            }

            await this.telegramNotifier.sendHelpMessage(
              telegramChatId,
              currentWorkdirName
            );
          } else if (this.taskMonitor.larkNotifier) {
            // For Lark chats
            await this.taskMonitor.larkNotifier.sendHelpMessage(
              originalData.open_chat_id || chatId,
              currentWorkdirName
            );
          }

          return {
            success: true,
            message: 'Help message sent'
          };
        }

      case 'execute_command':
        // Handle executing a command via callback button (e.g., /goals, /goalloop)
        {
          if (!chatId || !chatId.startsWith('telegram:')) {
            return {
              success: false,
              message: 'This action is only supported for Telegram chats'
            };
          }

          const telegramChatId = chatId.replace('telegram:', '');
          const commandToExecute = actionData.command;
          const commandArgs = actionData.args || '';

          logger.info(`[CALLBACK] Executing command ${commandToExecute} with args: ${commandArgs || 'none'}`);

          // Create a synthetic message to process the command
          const syntheticMessage = {
            chat: { id: parseInt(telegramChatId), type: 'private' },
            from: { id: originalData.user_id },
            message_id: originalData.open_message_id,
            text: commandArgs ? `${commandToExecute} ${commandArgs}` : commandToExecute,
            date: Math.floor(Date.now() / 1000)
          };

          // Process the message as if it was sent by the user
          await this.processTelegramMessage(syntheticMessage);

          return {
            success: true,
            message: `Executed ${commandToExecute}`
          };
        }

      case 'retry_img':
        // Handle retry image upload
        const fileId = actionData.f || actionData.file_id;
        const originalMessageId = actionData.m || actionData.message_id;
        const caption = actionData.cap || actionData.caption || '';
        
        if (!fileId) {
          return {
            success: false,
            message: 'File ID is required for retry_img'
          };
        }
        
        // Extract Telegram chat ID from the context
        let telegramChatId = null;
        if (chatId && chatId.startsWith('telegram:')) {
          telegramChatId = parseInt(chatId.replace('telegram:', ''));
        } else if (originalData.open_chat_id && originalData.open_chat_id.startsWith('telegram:')) {
          telegramChatId = parseInt(originalData.open_chat_id.replace('telegram:', ''));
        }
        
        if (!telegramChatId) {
          return {
            success: false,
            message: 'Telegram chat ID not found'
          };
        }
        
        // Get or initialize Telegram notifier
        if (!this.telegramNotifier) {
          const { TelegramNotifier } = await import('./telegram-notifier.js');
          this.telegramNotifier = new TelegramNotifier();
        }
        
        // Send a processing message first
        await this.telegramNotifier.sendMessage(telegramChatId, 
          '🔄 Retrying image upload...',
          { reply_to_message_id: originalMessageId }
        );
        
        // Retry the image upload process
        logger.info(`Retrying image upload for file ${fileId} in chat ${telegramChatId}`);
        
        // Create a synthetic message object to reprocess
        const retryMessage = {
          photo: [{
            file_id: fileId
          }],
          caption: caption,
          chat: {
            id: telegramChatId,
            type: 'private' // Will be overridden if needed
          },
          message_id: originalMessageId || Date.now(),
          from: {
            id: originalData.user_id || 'unknown',
            username: 'retry_action'
          }
        };
        
        // Process the image again
        await this.processTelegramMessage(retryMessage);
        
        return {
          success: true,
          message: 'Retrying image upload...'
        };
        
      case 'cancel_task':
        if (!taskId) {
          return {
            success: false,
            message: 'Task ID is required for cancel_task'
          };
        }

        const cancelled = this.taskMonitor.cancelTask(taskId);

        // cancelTask returns { success: boolean, message: string }
        // Return the result directly for proper handling
        return cancelled;

      case 'view_output':
        if (!taskId) {
          return {
            success: false,
            message: 'Task ID is required for view_output'
          };
        }

        // Get the task
        const viewTask = this.taskMonitor.getTaskById(taskId);
        if (!viewTask) {
          return {
            success: false,
            message: `Task not found: ${taskId}`
          };
        }

        // Send full output to user
        if (chatId && chatId.startsWith('telegram:')) {
          if (!this.telegramNotifier) {
            const { TelegramNotifier } = await import('./telegram-notifier.js');
            this.telegramNotifier = new TelegramNotifier();
          }
          const telegramChatId = chatId.replace('telegram:', '');

          // Get task output
          const output = viewTask.output || 'No output available';

          // Split into chunks if too long (Telegram message limit is 4096 chars)
          // We'll use code blocks which don't need escaping
          const maxLength = 4000; // Leave some room for formatting (```\n and \n```)
          const chunks = [];
          let currentChunk = '';

          const lines = output.split('\n');
          for (const line of lines) {
            if (currentChunk.length + line.length + 1 > maxLength) {
              if (currentChunk) {
                chunks.push(currentChunk);
              }
              currentChunk = line;
            } else {
              currentChunk += (currentChunk ? '\n' : '') + line;
            }
          }
          if (currentChunk) {
            chunks.push(currentChunk);
          }

          // Send header message
          const statusEmoji = viewTask.status === 'completed' ? '✅' : viewTask.status === 'error' ? '❌' : '⏳';
          await this.telegramNotifier.sendMessage(telegramChatId,
            `${statusEmoji} *Full Output for Task:* \`${viewTask.name}\`\n` +
            `*Task ID:* \`${taskId}\`\n` +
            `*Status:* ${viewTask.status}`,
            { parse_mode: 'Markdown' }
          );

          // Send output chunks
          for (let i = 0; i < chunks.length; i++) {
            const chunkHeader = chunks.length > 1 ? `*Part ${i + 1}/${chunks.length}:*\n\n` : '';
            await this.telegramNotifier.sendMessage(telegramChatId,
              chunkHeader + '```\n' + chunks[i] + '\n```',
              { parse_mode: 'Markdown' }
            );
          }

          return {
            success: true,
            message: `Sent full output for task ${taskId}`
          };
        }

        return {
          success: false,
          message: 'View output is only supported for Telegram'
        };

      case 'process_task':
        // Handle process task action (from legacy /process command buttons)
        if (!taskId) {
          return {
            success: false,
            message: 'Task ID is required for process_task'
          };
        }
        
        // Get the chat ID from the original data
        const processTaskChatId = originalData?.open_chat_id?.replace('telegram:', '');
        if (processTaskChatId) {
          // Show task progress for the specified task
          await this.showTaskProgress(processTaskChatId, taskId);
          return {
            success: true,
            message: `Showing progress for task ${taskId}`
          };
        } else {
          return {
            success: false,
            message: 'Could not determine chat ID for task progress'
          };
        }
        
      case 'continue':
        // Handle continue action from check command results
        if (!taskId) {
          // If no task ID, create a simple continue task
          const { basename } = await import('path');
          
          // Get workdir for this chat
          const selectedWorkdirName = chatId ? this.chatSettings.getWorkdir(chatId) : null;
          const availableWorkdirsForTask = await this.getAvailableWorkdirs(chatId);
          const taskWorkdir = selectedWorkdirName ? availableWorkdirsForTask[selectedWorkdirName] : process.cwd();
          
          const projectDir = basename(taskWorkdir);
          const now = new Date();
          const hour = now.getHours().toString().padStart(2, '0');
          const minute = now.getMinutes().toString().padStart(2, '0');
          const taskName = `${projectDir}-continue-fixes-${hour}${minute}`;
          
          const continueCommand = `Continue with the suggested fixes from the previous /check command. Apply the fixes that were identified in the check summary.`;
          
          const newTask = this.taskMonitor.addTask(
            taskName,
            continueCommand,
            {
              cwd: taskWorkdir,
              source: chatId && chatId.startsWith('telegram:') ? 'telegram_continue' : 'lark_continue',
              chatId: chatId
            }
          );
          
          // Send confirmation
          if (chatId && chatId.startsWith('telegram:')) {
            if (!this.telegramNotifier) {
              const { TelegramNotifier } = await import('./telegram-notifier.js');
              this.telegramNotifier = new TelegramNotifier();
            }
            const telegramChatId = chatId.replace('telegram:', '');
            
            // Create inline keyboard with process button
            const keyboard = {
              inline_keyboard: [[
                {
                  text: '▶️ Watch Task Progress',
                  callback_data: `/process ${newTask.id}`
                }
              ]]
            };
            
            await this.telegramNotifier.sendMessage(telegramChatId,
              `🔧 *Applying Suggested Fixes*\n\nTask ID: \`${newTask.id}\`\n\nI'll now apply the fixes identified in the check summary.`,
              { 
                parse_mode: 'Markdown',
                reply_markup: keyboard
              }
            );
          }
          
          return {
            success: true,
            taskId: newTask.id,
            message: `Continuing with fixes as task ${newTask.id}`
          };
        }
        
        // If task ID is provided, find the original task
        const checkTask = this.taskMonitor.getTaskById(taskId);
        if (checkTask && checkTask.command.includes('check') && checkTask.output) {
          const { basename } = await import('path');
          const projectDir = basename(checkTask.cwd || process.cwd());
          const now = new Date();
          const hour = now.getHours().toString().padStart(2, '0');
          const minute = now.getMinutes().toString().padStart(2, '0');
          const taskName = `${projectDir}-continue-fixes-${hour}${minute}`;
          
          const continueCommand = `Continue with the suggested fixes from the previous /check command. 

Previous check output:
${checkTask.output}

Apply the fixes that were identified in the check summary.`;
          
          const newTask = this.taskMonitor.addTask(
            taskName,
            continueCommand,
            {
              cwd: checkTask.cwd || process.cwd(),
              source: chatId && chatId.startsWith('telegram:') ? 'telegram_continue' : 'lark_continue',
              chatId: checkTask.chatId || chatId
            }
          );
          
          // Send confirmation
          if (chatId && chatId.startsWith('telegram:')) {
            if (!this.telegramNotifier) {
              const { TelegramNotifier } = await import('./telegram-notifier.js');
              this.telegramNotifier = new TelegramNotifier();
            }
            const telegramChatId = chatId.replace('telegram:', '');
            
            // Create inline keyboard with process button
            const keyboard = {
              inline_keyboard: [[
                {
                  text: '▶️ Watch Task Progress',
                  callback_data: `/process ${newTask.id}`
                }
              ]]
            };
            
            await this.telegramNotifier.sendMessage(telegramChatId,
              `🔧 *Applying Suggested Fixes*\n\nTask ID: \`${newTask.id}\`\n\nI'll now apply the fixes identified in the check summary.`,
              { 
                parse_mode: 'Markdown',
                reply_markup: keyboard
              }
            );
          }
          
          return {
            success: true,
            taskId: newTask.id,
            message: `Continuing with fixes as task ${newTask.id}`
          };
        }
        
        return {
          success: false,
          message: 'Could not find check task to continue from'
        };
        
      case 'retry_task':
        if (!taskId) {
          return {
            success: false,
            message: 'Task ID is required for retry_task'
          };
        }
        
        // Get the original task
        const originalTask = this.taskMonitor.getTaskById(taskId);
        if (originalTask) {
          // Check if this is a Claude task
          const isClaudeTask = originalTask.name.toLowerCase().includes('claude') || 
                              originalTask.command.includes('You are a') ||
                              originalTask.command.includes('IMPORTANT:') ||
                              originalTask.command.includes('Requirements:');
          
          let newTask;
          
          if (isClaudeTask && originalTask.status === 'error') {
            // For failed Claude tasks, create a continue task
            const { basename } = await import('path');
            const projectDir = basename(originalTask.cwd || process.cwd());
            const now = new Date();
            const hour = now.getHours().toString().padStart(2, '0');
            const minute = now.getMinutes().toString().padStart(2, '0');
            const taskName = `${projectDir}-continue-${hour}${minute}`;
            
            const continueCommand = `Continue from the previous task that failed. The user says: "continue"

Previous task context:
${originalTask.command}

Previous task output:
${originalTask.output || 'No output'}

Previous task error:
${originalTask.error || 'No error message'}

Continue working on the task, addressing any errors or issues that occurred.`;
            
            newTask = this.taskMonitor.addTask(
              taskName,
              continueCommand,
              {
                cwd: originalTask.cwd || process.cwd(),
                source: 'lark_card_continue'
              }
            );
          } else {
            // For non-Claude tasks or cancelled tasks, just retry with same command
            newTask = this.taskMonitor.addTask(
              `Retry: ${originalTask.name}`,
              originalTask.command,
              {
                cwd: originalTask.cwd || process.cwd(),
                source: 'lark_card_retry'
              }
            );
          }
          
          return {
            success: true,
            taskId: newTask.id,
            message: `Retrying task as ${newTask.id}`
          };
        }
        
        return {
          success: false,
          message: `Original task ${taskId} not found`
        };
        
      case 'view_logs':
        if (!taskId) {
          return {
            success: false,
            message: 'Task ID is required for view_logs'
          };
        }

        // Return task logs
        const task = this.taskMonitor.getTaskById(taskId);
        if (task) {
          // Send logs via Lark notification
          if (this.taskMonitor.larkNotifier) {
            const logMessage = task.output || task.error || 'No logs available';
            const truncatedLogs = logMessage.length > 2000 ?
              logMessage.substring(logMessage.length - 2000) + '...' :
              logMessage;

            await this.taskMonitor.larkNotifier.sendCustomMessage(
              `📋 Logs for Task ${taskId.substring(0, 8)}`,
              `\`\`\`\n${truncatedLogs}\n\`\`\``,
              'blue',
              chatId
            );
          }

          return {
            success: true,
            message: `Logs sent for task ${taskId}`
          };
        }

        return {
          success: false,
          message: `Task ${taskId} not found`
        };

      case 'delete_plan':
        // Handle plan deletion from Telegram buttons
        const planId = actionData.pid || actionData.planId;

        if (!planId) {
          return {
            success: false,
            message: 'Plan ID is required for deletion'
          };
        }

        try {
          // Initialize workspace manager if not already done
          if (!this.workspaceManager) {
            const { WorkspaceManager } = await import('./workspace-manager.js');
            this.workspaceManager = new WorkspaceManager();
            await this.workspaceManager.initialize();
          }

          // Extract chat ID from original data
          let telegramChatId = null;
          if (chatId && chatId.startsWith('telegram:')) {
            telegramChatId = chatId.replace('telegram:', '');
          }

          // Get workspace for this chat
          if (telegramChatId) {
            let workspace = await this.workspaceManager.getWorkspaceForTelegramChat(telegramChatId);
            if (!workspace) {
              // In gateway mode, ensure gateway workspace exists in database
              if (config.gateway.enabled) {
                workspace = await this.workspaceManager.ensureGatewayWorkspace();
                logger.debug('Gateway mode: Using gateway workspace for delete_plan');
              } else {
                return {
                  success: false,
                  message: 'No workspace connected'
                };
              }
            }

            // Delete the plan
            await this.workspaceManager.deletePlan(workspace.id, planId);

            // Send confirmation message
            if (!this.telegramNotifier) {
              const { TelegramNotifier } = await import('./telegram-notifier.js');
              this.telegramNotifier = new TelegramNotifier();
            }

            await this.telegramNotifier.sendMessage(telegramChatId,
              `✅ Plan \`${planId}\` has been deleted successfully`,
              { parse_mode: 'Markdown', workspaceName: workspace.name }
            );

            return {
              success: true,
              message: `Plan ${planId} deleted successfully`
            };
          }

          return {
            success: false,
            message: 'Unable to determine chat context for deletion'
          };
        } catch (error) {
          logger.error(`Failed to delete plan ${planId}:`, error);

          // Send error message if we have a chat ID
          if (chatId && chatId.startsWith('telegram:')) {
            const telegramChatId = chatId.replace('telegram:', '');
            if (this.telegramNotifier) {
              await this.telegramNotifier.sendMessage(telegramChatId,
                `❌ Failed to delete plan: ${error.message}`,
                { parse_mode: 'Markdown' }
              );
            }
          }

          return {
            success: false,
            message: `Failed to delete plan: ${error.message}`
          };
        }

      case 'next':
        {
          // Handle executing next plan step
          // Initialize workspace manager if not already done
          if (!this.workspaceManager) {
            const { WorkspaceManager } = await import('./workspace-manager.js');
            this.workspaceManager = new WorkspaceManager();
            await this.workspaceManager.initialize();
          }

          // Get workspace for this chat
          let workspace;
          if (chatId && chatId.startsWith('telegram:')) {
            const telegramChatId = chatId.replace('telegram:', '');
            workspace = await this.workspaceManager.getWorkspaceForTelegramChat(telegramChatId);
          } else {
            workspace = await this.workspaceManager.getWorkspaceForChat(chatId);
          }

          if (!workspace) {
            // In gateway mode, ensure gateway workspace exists in database
            if (config.gateway.enabled) {
              workspace = await this.workspaceManager.ensureGatewayWorkspace();
              logger.debug('Gateway mode: Using gateway workspace for plan /next action');
            } else {
              // Send error message via appropriate notifier
              if (chatId && chatId.startsWith('telegram:')) {
                if (!this.telegramNotifier) {
                  const { TelegramNotifier } = await import('./telegram-notifier.js');
                  this.telegramNotifier = new TelegramNotifier();
                }
                const telegramChatId = chatId.replace('telegram:', '');
                await this.telegramNotifier.sendMessage(telegramChatId,
                  '❌ No workspace connected. Use /connect <token> to connect first.',
                  { parse_mode: 'Markdown' }
                );
              }

              return {
                success: false,
                message: 'No workspace connected. Use /connect <token> to connect.'
              };
            }
          }

          try {
            // Get the next plan to execute
            const plan = await this.workspaceManager.getNextPlan(workspace.id);

            if (!plan) {
              if (chatId && chatId.startsWith('telegram:')) {
                if (!this.telegramNotifier) {
                  const { TelegramNotifier } = await import('./telegram-notifier.js');
                  this.telegramNotifier = new TelegramNotifier();
                }
                const telegramChatId = chatId.replace('telegram:', '');
                await this.telegramNotifier.sendMessage(telegramChatId,
                  '📋 No pending plans found. Create a plan with: `/plan <steps>`',
                  { parse_mode: 'Markdown' }
                );
              }
              return {
                success: false,
                message: 'No pending plans found. Create a plan with: /plan <steps>'
              };
            }

            const steps = plan.steps;
            const currentStep = plan.current_step || 0;

            const normalizedSteps = normalizePlanSteps(steps);

            // Find the next step to execute (first non-completed step)
            let nextStepIndex = -1;
            for (let i = 0; i < normalizedSteps.length; i++) {
              if (!normalizedSteps[i].status || normalizedSteps[i].status !== 'completed') {
                nextStepIndex = i;
                break;
              }
            }

            if (nextStepIndex === -1) {
              // All steps completed
              await this.workspaceManager.updatePlanStatus(workspace.id, plan.plan_id, 'completed');

              if (chatId && chatId.startsWith('telegram:')) {
                if (!this.telegramNotifier) {
                  const { TelegramNotifier } = await import('./telegram-notifier.js');
                  this.telegramNotifier = new TelegramNotifier();
                }
                const telegramChatId = chatId.replace('telegram:', '');
                await this.telegramNotifier.sendMessage(telegramChatId,
                  '✅ All plan steps have been completed!',
                  { parse_mode: 'Markdown' }
                );
              }

              return {
                success: true,
                message: 'All plan steps have been completed!'
              };
            }

            // Check if there's a task already running for this step
            if (normalizedSteps[nextStepIndex].taskId && normalizedSteps[nextStepIndex].status === 'in_progress') {
              // Check if the task is actually still running
              const existingTask = this.taskMonitor.getTaskById(normalizedSteps[nextStepIndex].taskId);
              if (existingTask && (existingTask.status === 'pending' || existingTask.status === 'running')) {
                if (chatId && chatId.startsWith('telegram:')) {
                  if (!this.telegramNotifier) {
                    const { TelegramNotifier } = await import('./telegram-notifier.js');
                    this.telegramNotifier = new TelegramNotifier();
                  }
                  const telegramChatId = chatId.replace('telegram:', '');
                  await this.telegramNotifier.sendMessage(telegramChatId,
                    `⚠️ Step ${nextStepIndex + 1} is already in progress with task ID: ${normalizedSteps[nextStepIndex].taskId}`,
                    { parse_mode: 'Markdown' }
                  );
                }

                return {
                  success: false,
                  message: `Step ${nextStepIndex + 1} is already in progress with task ID: ${normalizedSteps[nextStepIndex].taskId}`
                };
              }
              // Task is completed/failed/cancelled, update step status accordingly
              if (!existingTask || existingTask.status === 'completed' || existingTask.status === 'failed' ||
                  existingTask.status === 'cancelled' || existingTask.status === 'error') {
                const newStatus = (!existingTask || existingTask.status === 'cancelled') ? 'pending' :
                                  (existingTask.status === 'completed' ? 'completed' : 'failed');
                await this.workspaceManager.updatePlanStep(workspace.id, plan.plan_id, nextStepIndex, {
                  status: newStatus,
                  completedAt: existingTask?.completedAt || new Date().toISOString()
                });

                // If this step is now completed, we need to find the next non-completed step
                if (newStatus === 'completed') {
                  // Re-check for the next step
                  for (let i = nextStepIndex + 1; i < normalizedSteps.length; i++) {
                    if (!normalizedSteps[i].status || normalizedSteps[i].status !== 'completed') {
                      nextStepIndex = i;
                      break;
                    } else if (i === normalizedSteps.length - 1) {
                      // All steps completed
                      await this.workspaceManager.updatePlanStatus(workspace.id, plan.plan_id, 'completed');

                      if (chatId && chatId.startsWith('telegram:')) {
                        if (!this.telegramNotifier) {
                          const { TelegramNotifier } = await import('./telegram-notifier.js');
                          this.telegramNotifier = new TelegramNotifier();
                        }
                        const telegramChatId = chatId.replace('telegram:', '');
                        await this.telegramNotifier.sendMessage(telegramChatId,
                          '✅ All plan steps have been completed!',
                          { parse_mode: 'Markdown' }
                        );
                      }

                      return {
                        success: true,
                        message: 'All plan steps have been completed!'
                      };
                    }
                  }
                }
              }
            }

            // Get step description
            const stepInfo = normalizePlanStep(normalizedSteps[nextStepIndex]);
            const stepDescription = getPlanStepDisplayText(stepInfo);

            // Update plan status
            await this.workspaceManager.updatePlanStatus(workspace.id, plan.plan_id, 'in_progress', nextStepIndex);

            // Create task for this step
            const taskName = `plan-${plan.plan_id}-step-${nextStepIndex + 1}`;
            const taskOptions = {
              cwd: workspace.path,
              source: chatId && chatId.startsWith('telegram:') ? 'telegram_plan' : 'lark_plan',
              chatId: chatId,
              planId: plan.plan_id,
              stepIndex: nextStepIndex,
              workspaceId: workspace.id
            };

            if (stepInfo.providerId) {
              taskOptions.providerId = stepInfo.providerId;
            }
            if (stepInfo.model) {
              taskOptions.model = stepInfo.model;
            }

            const task = this.taskMonitor.addTask(
              taskName,
              stepInfo.command,
              taskOptions
            );

            // Update step with task ID and mark as in_progress
            await this.workspaceManager.updatePlanStep(workspace.id, plan.plan_id, nextStepIndex, {
              taskId: task.id,
              status: 'in_progress'
            });

            logger.info(`Executing plan step ${nextStepIndex + 1}/${steps.length}: ${task.id}`);

            // Send notification
            if (chatId && chatId.startsWith('telegram:')) {
              if (!this.telegramNotifier) {
                const { TelegramNotifier } = await import('./telegram-notifier.js');
                this.telegramNotifier = new TelegramNotifier();
              }
              const telegramChatId = chatId.replace('telegram:', '');
              await this.telegramNotifier.sendMessage(telegramChatId,
                `▶️ *Executing step ${nextStepIndex + 1}/${steps.length}:*\n${stepDescription}\n\n_Task ID: ${task.id}_`,
                { parse_mode: 'Markdown' }
              );
            }

            return {
              success: true,
              message: `Executing step ${nextStepIndex + 1}/${steps.length}: ${stepDescription}\n\nTask ID: ${task.id}`,
              taskId: task.id
            };

          } catch (error) {
            logger.error(`Failed to execute plan: ${error.message}`);
            return {
              success: false,
              message: `Failed to execute plan: ${error.message}`
            };
          }
        }

      case 'cleanup':
      case 'cleanup_failed':
        {
          // Handle cleanup of plans (completed or failed)
          const cleanupType = action === 'cleanup' ? 'completed' : 'failed';

          // Initialize workspace manager if not already done
          if (!this.workspaceManager) {
            const { WorkspaceManager } = await import('./workspace-manager.js');
            this.workspaceManager = new WorkspaceManager();
            await this.workspaceManager.initialize();
          }

          // Get workspace for this chat
          let workspace;
          if (chatId && chatId.startsWith('telegram:')) {
            const telegramChatId = chatId.replace('telegram:', '');
            workspace = await this.workspaceManager.getWorkspaceForTelegramChat(telegramChatId);
          } else {
            workspace = await this.workspaceManager.getWorkspaceForChat(chatId);
          }

          if (!workspace) {
            // In gateway mode, ensure gateway workspace exists in database
            if (config.gateway.enabled) {
              workspace = await this.workspaceManager.ensureGatewayWorkspace();
              logger.debug('Gateway mode: Using gateway workspace for plan cleanup action');
            } else {
              // Send error message via appropriate notifier
              if (chatId && chatId.startsWith('telegram:')) {
                if (!this.telegramNotifier) {
                  const { TelegramNotifier } = await import('./telegram-notifier.js');
                  this.telegramNotifier = new TelegramNotifier();
                }
                const telegramChatId = chatId.replace('telegram:', '');
                await this.telegramNotifier.sendMessage(telegramChatId,
                  '❌ No workspace connected. Use /connect <token> to connect first.',
                  { parse_mode: 'Markdown' }
                );
              }

              return {
                success: false,
                message: 'No workspace connected. Use /connect <token> to connect.'
              };
            }
          }

          try {
            // Delete plans based on type
            const result = await this.workspaceManager.resetPlans(workspace.id, cleanupType);

            // Send success message via appropriate notifier
            if (chatId && chatId.startsWith('telegram:')) {
              if (!this.telegramNotifier) {
                const { TelegramNotifier } = await import('./telegram-notifier.js');
                this.telegramNotifier = new TelegramNotifier();
              }
              const telegramChatId = chatId.replace('telegram:', '');

              // First send the success message
              await this.telegramNotifier.sendMessage(telegramChatId,
                `✅ ${result.message}`,
                { parse_mode: 'Markdown' }
              );

              // Now show the updated plans list
              const updatedPlans = await this.workspaceManager.listPlans(workspace.id);

              if (!updatedPlans || updatedPlans.length === 0) {
                await this.telegramNotifier.sendMessage(telegramChatId,
                  `📋 *No plans remaining for workspace: ${workspace.name}*\n\n` +
                  `Create a plan with: \`/plan <steps>\``,
                  { parse_mode: 'Markdown', workspaceName: workspace.name }
                );
              } else {
                // Format updated plans list (same format as /plans command)
                let message = `📋 *Plans for workspace: ${workspace.name}*\n\n`;

                // Group plans by status
                const pendingPlans = updatedPlans.filter(p => p.status === 'pending');
                const inProgressPlans = updatedPlans.filter(p => p.status === 'in_progress');
                const completedPlans = updatedPlans.filter(p => p.status === 'completed');
                const failedPlans = updatedPlans.filter(p => p.status === 'failed');

                if (inProgressPlans.length > 0) {
                  message += `*🔵 In Progress:*\n`;
                  inProgressPlans.forEach(plan => {
                    const currentStep = plan.current_step || 0;
                    const totalSteps = plan.steps.length;
                    const progress = totalSteps > 0 ? Math.round((currentStep / totalSteps) * 100) : 0;
                    message += `• \`${plan.plan_id}\` - ${plan.title} (${currentStep}/${totalSteps} steps, ${progress}%)\n`;
                  });
                  message += '\n';
                }

                if (pendingPlans.length > 0) {
                  message += `*⏸️ Pending:*\n`;
                  pendingPlans.forEach(plan => {
                    message += `• \`${plan.plan_id}\` - ${plan.title} (${plan.steps.length} steps)\n`;
                  });
                  message += '\n';
                }

                if (completedPlans.length > 0) {
                  message += `*✅ Completed:*\n`;
                  completedPlans.slice(0, 5).forEach(plan => {
                    message += `• \`${plan.plan_id}\` - ${plan.title}\n`;
                  });
                  if (completedPlans.length > 5) {
                    message += `  ...and ${completedPlans.length - 5} more\n`;
                  }
                  message += '\n';
                }

                if (failedPlans.length > 0) {
                  message += `*❌ Failed:*\n`;
                  failedPlans.slice(0, 3).forEach(plan => {
                    message += `• \`${plan.plan_id}\` - ${plan.title}\n`;
                  });
                  if (failedPlans.length > 3) {
                    message += `  ...and ${failedPlans.length - 3} more\n`;
                  }
                  message += '\n';
                }

                message += `\n*Total:* ${updatedPlans.length} plans\n`;
                message += `\nUse \`/next [plan-id]\` to execute a specific plan`;

                // Add action buttons
                const buttons = [];

                // Add /next button if there are pending or in-progress plans
                if (pendingPlans.length > 0 || inProgressPlans.length > 0) {
                  buttons.push({
                    text: '▶️ Next Step',
                    callback_data: JSON.stringify({ a: 'next' })
                  });
                }

                if (completedPlans.length > 0) {
                  buttons.push({
                    text: '🧹 Cleanup Completed',
                    callback_data: JSON.stringify({ a: 'cleanup' })
                  });
                }

                if (failedPlans.length > 0) {
                  buttons.push({
                    text: '❌ Cleanup Failed',
                    callback_data: JSON.stringify({ a: 'cleanup_failed' })
                  });
                }

                const options = { parse_mode: 'Markdown' };
                if (buttons.length > 0) {
                  options.reply_markup = {
                    inline_keyboard: [buttons]
                  };
                }

                await this.telegramNotifier.sendMessage(telegramChatId, message, options);
              }
            } else if (this.taskMonitor.larkNotifier) {
              await this.taskMonitor.larkNotifier.sendCustomMessage(
                '✅ Cleanup Complete',
                result.message,
                'green',
                chatId
              );
            }

            return {
              success: true,
              message: result.message
            };

          } catch (error) {
            logger.error(`Failed to cleanup ${cleanupType} plans:`, error);
            return {
              success: false,
              message: `Failed to cleanup ${cleanupType} plans: ${error.message}`
            };
          }
        }

      case 'cancel_progress':
        {
          // Handle canceling of in-progress plans
          // Initialize workspace manager if not already done
          if (!this.workspaceManager) {
            const { WorkspaceManager } = await import('./workspace-manager.js');
            this.workspaceManager = new WorkspaceManager();
            await this.workspaceManager.initialize();
          }

          // Get workspace for this chat
          let workspace;
          if (chatId && chatId.startsWith('telegram:')) {
            const telegramChatId = chatId.replace('telegram:', '');
            workspace = await this.workspaceManager.getWorkspaceForTelegramChat(telegramChatId);
          } else {
            workspace = await this.workspaceManager.getWorkspaceForChat(chatId);
          }

          if (!workspace) {
            // In gateway mode, ensure gateway workspace exists in database
            if (config.gateway.enabled) {
              workspace = await this.workspaceManager.ensureGatewayWorkspace();
              logger.debug('Gateway mode: Using gateway workspace for cancel_progress action');
            } else {
              // Send error message via appropriate notifier
              if (chatId && chatId.startsWith('telegram:')) {
                if (!this.telegramNotifier) {
                  const { TelegramNotifier } = await import('./telegram-notifier.js');
                  this.telegramNotifier = new TelegramNotifier();
                }
                const telegramChatId = chatId.replace('telegram:', '');
                await this.telegramNotifier.sendMessage(telegramChatId,
                  '❌ No workspace connected. Use /connect <token> to connect first.',
                  { parse_mode: 'Markdown' }
                );
              }

              return {
                success: false,
                message: 'No workspace connected. Use /connect <token> to connect.'
              };
            }
          }

          try {
            // Get all in-progress plans
            const plans = await this.workspaceManager.listPlans(workspace.id);
            const inProgressPlans = plans.filter(p => p.status === 'in_progress');

            if (inProgressPlans.length === 0) {
              if (chatId && chatId.startsWith('telegram:')) {
                if (!this.telegramNotifier) {
                  const { TelegramNotifier } = await import('./telegram-notifier.js');
                  this.telegramNotifier = new TelegramNotifier();
                }
                const telegramChatId = chatId.replace('telegram:', '');
                await this.telegramNotifier.sendMessage(telegramChatId,
                  '⚠️ No plans currently in progress.',
                  { parse_mode: 'Markdown' }
                );
              }
              return {
                success: false,
                message: 'No plans currently in progress.'
              };
            }

            // Cancel all in-progress plans
            let canceledCount = 0;
            for (const plan of inProgressPlans) {
              await this.workspaceManager.updatePlanStatus(workspace.id, plan.plan_id, 'pending', plan.current_step || 0);
              canceledCount++;
            }

            // Send success message
            if (chatId && chatId.startsWith('telegram:')) {
              if (!this.telegramNotifier) {
                const { TelegramNotifier } = await import('./telegram-notifier.js');
                this.telegramNotifier = new TelegramNotifier();
              }
              const telegramChatId = chatId.replace('telegram:', '');
              await this.telegramNotifier.sendMessage(telegramChatId,
                `⏹️ Canceled ${canceledCount} in-progress plan${canceledCount > 1 ? 's' : ''}. Plans have been reset to pending status.`,
                { parse_mode: 'Markdown' }
              );
            }

            return {
              success: true,
              message: `⏹️ Canceled ${canceledCount} in-progress plan${canceledCount > 1 ? 's' : ''}. Plans have been reset to pending status.`
            };

          } catch (error) {
            logger.error(`Failed to cancel in-progress plans:`, error);
            return {
              success: false,
              message: `Failed to cancel in-progress plans: ${error.message}`
            };
          }
        }

      case 'list_plans': {
        // Handle listing plans - just trigger the /plans command
        logger.info('List plans action triggered from View Plans button');

        // Simply call the /plans command handler
        if (chatId && chatId.startsWith('telegram:')) {
          const telegramChatId = chatId.replace('telegram:', '');
          // Call processTelegramCommand with /plans
          return await this.processTelegramCommand('/plans', telegramChatId, null);
        }

        return {
          success: false,
          message: 'List plans is only supported for Telegram'
        };
      }

      default:
        return {
          success: false,
          message: `Unknown card action: ${action}`
        };
    }
  }

  async processLarkCommand(data) {
    const { action, path, command, taskId } = data;

    switch (action) {
      case 'add_task':
        if (!command) {
          throw new Error('Command is required for add_task');
        }

        const taskOptions = {
          cwd: path || process.cwd(),
          source: 'lark_callback',
          providerId: await this.getCurrentProviderId()  // Track provider for stats extraction
        };

        const task = this.taskMonitor.addTask(
          `Lark Task: ${command.substring(0, 50)}...`,
          command,
          taskOptions
        );
        
        return {
          success: true,
          taskId: task.id,
          message: `Task created successfully: ${task.name}`
        };

      case 'cancel_task':
        if (!taskId) {
          throw new Error('Task ID is required for cancel_task');
        }

        const cancelled = this.taskMonitor.cancelTask(taskId);

        // cancelTask returns { success: boolean, message: string }
        return cancelled;

      case 'get_status':
        const status = this.taskMonitor.getStatus();
        return {
          success: true,
          data: status
        };

      case 'get_task':
        if (!taskId) {
          throw new Error('Task ID is required for get_task');
        }
        
        const taskInfo = this.taskMonitor.getTaskById(taskId);
        
        return {
          success: true,
          data: taskInfo
        };

      default:
        // Return a safe response for unknown actions instead of throwing
        logger.warn(`Unknown action received: ${action}`);
        return {
          success: false,
          message: `Unknown action: ${action || 'undefined'}`,
          data: { action, path, command, taskId }
        };
    }
  }

  async handleHealthCheck(req, res) {
    const status = this.taskMonitor.getStatus();
    const history = this.taskMonitor.getTaskHistory(1);

    // Calculate health status
    const queueDepth = status.pending.length;
    const activeCount = status.running.length;

    let healthStatus = 'healthy';
    let httpStatus = 200;

    // Degraded if queue is building up or multiple tasks running
    if (queueDepth >= 10 && queueDepth <= 50) {
      healthStatus = 'degraded';
    }

    // Unhealthy if queue is very large
    if (queueDepth > 50) {
      healthStatus = 'unhealthy';
      httpStatus = 503;
    }

    // Get resource usage
    const resourceUsage = this.getResourceUsage();

    // Get gateway connection status (now async)
    const gatewayStatus = await this.getGatewayStatus();

    // Calculate task statistics
    const completedTasks = history.filter(t => t.status === 'completed').length;
    const failedTasks = history.filter(t => t.status === 'failed').length;
    const totalTasks = completedTasks + failedTasks + activeCount + queueDepth;

    // Build runningTasks array with task details
    const runningTasks = status.running.map(task => {
      // Extract first 100-150 chars of prompt from task command
      let prompt = '';
      if (task.command) {
        // Remove -c flag if present and get the prompt text
        const cleanCommand = task.command.replace(/^-c\s+/, '');
        // Truncate to 100-150 chars
        prompt = cleanCommand.length > 150
          ? cleanCommand.substring(0, 147) + '...'
          : cleanCommand;
      }

      // Determine provider - use task's providerId or default to anthropic
      // Map internal provider IDs to standard slugs
      const providerSlug = this.mapProviderIdToSlug(task.providerId);

      return {
        taskId: task.id,
        startedAt: task.startedAt ? new Date(task.startedAt).toISOString() : null,
        prompt,
        provider: providerSlug
      };
    });

    const healthData = {
      status: healthStatus,
      uptime: process.uptime(),
      daemon: {
        activeTasks: activeCount,
        queuedTasks: queueDepth
      },
      runningTasks,
      tasks: {
        active: activeCount,
        queued: queueDepth,
        total: totalTasks,
        completed: completedTasks,
        failed: failedTasks
      },
      gateway: gatewayStatus,
      resources: resourceUsage,
      timestamp: new Date().toISOString()
    };

    res.writeHead(httpStatus, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(healthData, null, 2));
  }

  /**
   * Handle memory stats API endpoint - detailed memory usage for debugging
   * GET /api/memory
   */
  async handleMemoryStats(req, res) {
    const memUsage = process.memoryUsage();
    const taskQueue = this.taskMonitor?.taskQueue;

    // Collect in-memory data structure sizes
    const internalCaches = {
      processedMessages: this.processedMessages?.size || 0,
      pendingPrompts: this.pendingPrompts?.size || 0,
      gitStatusCache: this.gitStatusCache?.size || 0,
      recentImages: this.recentImages?.size || 0,
      progressTrackers: this.progressTrackers?.size || 0,
    };

    const taskQueueStats = taskQueue ? {
      runningTasks: taskQueue.runningTasks?.size || 0,
      pendingTasks: taskQueue.pendingTasks?.length || 0,
      taskHistory: taskQueue.taskHistory?.length || 0,
      childProcesses: taskQueue.childProcesses?.size || 0,
      taskOutputBuffers: taskQueue.taskOutputBuffers?.size || 0,
      staleDetectionState: taskQueue.staleDetectionState?.size || 0,
      fatalErrorTimeouts: taskQueue.fatalErrorTimeouts?.size || 0,
      logStreams: taskQueue.logStreams?.size || 0,
      streamLineBuffers: taskQueue.streamLineBuffers?.size || 0,
      lastOutputTime: taskQueue.lastOutputTime?.size || 0,
      taskSnapshots: taskQueue.usageReporter?.taskSnapshots?.size || 0,
    } : null;

    // Estimate output buffer sizes
    let totalOutputBufferBytes = 0;
    if (taskQueue?.taskOutputBuffers) {
      for (const [taskId, buffers] of taskQueue.taskOutputBuffers) {
        if (buffers.stdout) totalOutputBufferBytes += buffers.stdout.totalBytes || 0;
        if (buffers.stderr) totalOutputBufferBytes += buffers.stderr.totalBytes || 0;
      }
    }

    const memoryData = {
      process: {
        rss: memUsage.rss,
        rssMB: (memUsage.rss / 1024 / 1024).toFixed(2),
        heapTotal: memUsage.heapTotal,
        heapTotalMB: (memUsage.heapTotal / 1024 / 1024).toFixed(2),
        heapUsed: memUsage.heapUsed,
        heapUsedMB: (memUsage.heapUsed / 1024 / 1024).toFixed(2),
        external: memUsage.external,
        externalMB: (memUsage.external / 1024 / 1024).toFixed(2),
        arrayBuffers: memUsage.arrayBuffers,
        arrayBuffersMB: (memUsage.arrayBuffers / 1024 / 1024).toFixed(2),
      },
      internalCaches,
      taskQueue: taskQueueStats,
      outputBufferBytes: totalOutputBufferBytes,
      outputBufferMB: (totalOutputBufferBytes / 1024 / 1024).toFixed(2),
      uptime: process.uptime(),
      uptimeHours: (process.uptime() / 3600).toFixed(2),
      timestamp: new Date().toISOString(),
    };

    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(memoryData, null, 2));
  }

  /**
   * Map internal provider IDs to standard provider slugs
   * Provider slugs: anthropic, openai, fireworks, google, mistral, groq, together, cohere, deepseek
   */
  mapProviderIdToSlug(providerId) {
    if (!providerId) {
      return 'anthropic'; // Default provider
    }

    // Map common provider IDs to standard slugs
    const providerMap = {
      'claude': 'anthropic',
      'anthropic': 'anthropic',
      'openai': 'openai',
      'codex': 'openai',  // OpenAI Codex
      'gemini': 'google',
      'google': 'google',
      'fireworks': 'fireworks',
      'mistral': 'mistral',
      'groq': 'groq',
      'together': 'together',
      'cohere': 'cohere',
      'deepseek': 'deepseek',
      'cursor': 'anthropic',  // Cursor typically uses Claude
      'glm': 'glm'  // Keep as-is for GLM
    };

    return providerMap[providerId.toLowerCase()] || providerId.toLowerCase();
  }

  getResourceUsage() {
    const memUsage = process.memoryUsage();
    return {
      cpuUsage: process.cpuUsage().user / 1000000, // Convert to seconds
      memoryUsage: Math.round(memUsage.heapUsed / 1024 / 1024), // MB
      diskUsage: 0 // Placeholder - can be enhanced with actual disk check
    };
  }

  async getGatewayStatus() {
    // Use the new GatewayClient for accurate status
    const { gatewayClient } = await import('./gateway-client.js');

    if (!gatewayClient.isEnabled()) {
      return {
        connected: false,
        lastHeartbeat: null,
        registeredAt: null
      };
    }

    // Return simplified status for /health endpoint
    return {
      connected: gatewayClient.registeredWithGateway,
      instanceId: gatewayClient.instanceId,
      gatewayUrl: gatewayClient.gatewayUrl,
      heartbeatActive: !!gatewayClient.heartbeatInterval
    };
  }

  async handleVersion(req, res) {
    // Read package.json to get version
    try {
      const fs = await import('fs');
      const path = await import('path');
      const { fileURLToPath } = await import('url');

      const __filename = fileURLToPath(import.meta.url);
      const __dirname = path.dirname(__filename);
      const packagePath = path.join(__dirname, '..', 'package.json');
      const packageJson = JSON.parse(fs.readFileSync(packagePath, 'utf8'));

      this.sendSuccess(res, {
        version: packageJson.version,
        name: packageJson.name,
        description: packageJson.description,
        api_version: '1.0.0' // API version separate from package version
      });
    } catch (error) {
      logger.error('Failed to read version:', error);
      this.sendError(res, 500, 'Failed to read version information');
    }
  }

  async readRequestBody(req) {
    return new Promise((resolve, reject) => {
      let body = '';
      const chunks = [];
      let size = 0;
      const maxSize = 10 * 1024 * 1024; // 10MB limit
      
      // Set a timeout for reading the request body
      const timeout = setTimeout(() => {
        req.destroy();
        reject(new Error('Request body read timeout'));
      }, 10000); // 10 second timeout
      
      req.on('data', (chunk) => {
        size += chunk.length;
        if (size > maxSize) {
          clearTimeout(timeout);
          req.destroy();
          reject(new Error('Request body too large'));
          return;
        }
        chunks.push(chunk);
      });
      
      req.on('end', () => {
        clearTimeout(timeout);
        body = Buffer.concat(chunks).toString();
        resolve(body);
      });
      
      req.on('error', (error) => {
        clearTimeout(timeout);
        reject(error);
      });
    });
  }

  sendSuccess(res, data) {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(data));
  }

  sendError(res, statusCode, message) {
    res.writeHead(statusCode, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ 
      success: false, 
      error: message 
    }));
  }

  async handleAPIRequest(req, res, pathname) {
    const url = parse(req.url, true);
    
    // Documentation endpoint - no auth required (support GET and HEAD)
    if (pathname.endsWith('/api/docs') && (req.method === 'GET' || req.method === 'HEAD')) {
      await this.handleAPIDocumentation(req, res);
      return;
    }
    
    // Authenticate request via Bearer token
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      this.sendError(res, 401, 'Authorization required');
      return;
    }
    
    const token = authHeader.substring(7);
    
    // Validate token with workspace manager
    if (!this.workspaceManager) {
      const { WorkspaceManager } = await import('./workspace-manager.js');
      this.workspaceManager = new WorkspaceManager();
      await this.workspaceManager.initialize();
    }
    
    const tokenInfo = await this.workspaceManager.validateToken(token);
    if (!tokenInfo.valid) {
      this.sendError(res, 401, 'Invalid or expired token');
      return;
    }
    
    const workspace = {
      id: tokenInfo.workspace_id,
      name: tokenInfo.workspace_name,
      path: tokenInfo.workspace_path
    };
    
    // Route API endpoints
    const apiPath = pathname.substring(5); // Remove '/api/' prefix
    
    if (apiPath === 'task' && req.method === 'POST') {
      await this.handleAPITaskCreate(req, res, workspace);
    } else if (apiPath.startsWith('task/') && req.method === 'GET') {
      const taskId = apiPath.substring(5);
      await this.handleAPITaskGet(req, res, taskId, workspace);
    } else if (apiPath.startsWith('task/') && req.method === 'DELETE') {
      const taskId = apiPath.substring(5);
      await this.handleAPITaskCancel(req, res, taskId, workspace);
    } else if (apiPath === 'tasks' && req.method === 'GET') {
      await this.handleAPITasksList(req, res, url.query, workspace);
    } else if (apiPath.startsWith('task/') && apiPath.endsWith('/checklist') && req.method === 'GET') {
      const taskId = apiPath.substring(5, apiPath.length - 10);
      await this.handleAPITaskChecklist(req, res, taskId, workspace);
    } else {
      this.sendError(res, 404, 'API endpoint not found');
    }
  }

  async handleAPITaskCreate(req, res, workspace) {
    let body;
    try {
      body = await this.readRequestBody(req);
      const data = JSON.parse(body);
      
      // Validate required fields
      if (!data.name) {
        this.sendError(res, 400, 'Task name is required');
        return;
      }
      
      // Use workspace path from token validation
      const taskWorkdir = workspace.path;
      const taskCommand = data.command || `ani-code continue "${data.name}"`;
      const taskPriority = data.priority || 'normal';
      const taskMetadata = data.metadata || {};
      
      // Add task to queue
      const task = this.taskMonitor.addTask(
        data.name,
        taskCommand,
        {
          cwd: taskWorkdir,
          source: 'api',
          priority: taskPriority,
          metadata: {
            ...taskMetadata,
            workspace_id: workspace.id,
            workspace_name: workspace.name
          }
        }
      );
      
      logger.info(`[API] Task created: ${task.id} | ${workspace.name} | ${data.name}`);
      
      this.sendSuccess(res, {
        success: true,
        taskId: task.id,
        status: task.status,
        workspace: workspace.name,
        queuePosition: this.taskMonitor.getQueuePosition(task.id)
      });
    } catch (error) {
      logger.error('[API] Failed to create task:', error);
      this.sendError(res, 400, error.message);
    }
  }

  async handleAPITaskGet(req, res, taskId, workspace) {
    const task = this.taskMonitor.getTaskById(taskId);
    
    if (!task) {
      // Check history
      const historyTask = this.taskMonitor.getHistoryTaskById(taskId);
      if (historyTask) {
        this.sendSuccess(res, historyTask);
      } else {
        this.sendError(res, 404, 'Task not found');
      }
      return;
    }
    
    // Verify task belongs to this workspace
    if (task.metadata?.workspace_id && task.metadata.workspace_id !== workspace.id) {
      this.sendError(res, 403, 'Access denied to this task');
      return;
    }
    
    this.sendSuccess(res, {
      id: task.id,
      name: task.name,
      status: task.status,
      progress: task.progress || 0,
      output: task.output || '',
      error: task.error || null,
      startedAt: task.startedAt,
      completedAt: task.completedAt,
      workspace: workspace.name,
      queuePosition: task.status === 'pending' ? this.taskMonitor.getQueuePosition(task.id) : null
    });
  }

  async handleAPITaskCancel(req, res, taskId, workspace) {
    const task = this.taskMonitor.getTaskById(taskId);
    
    if (!task) {
      this.sendError(res, 404, 'Task not found');
      return;
    }
    
    // Verify task belongs to this workspace
    if (task.metadata?.workspace_id && task.metadata.workspace_id !== workspace.id) {
      this.sendError(res, 403, 'Access denied to this task');
      return;
    }
    
    const cancelled = this.taskMonitor.cancelTask(taskId);

    // cancelTask returns { success: boolean, message: string }
    if (cancelled.success) {
      logger.info(`[API] Task cancelled: ${taskId}`);
      this.sendSuccess(res, {
        success: true,
        message: 'Task cancelled successfully'
      });
    } else {
      this.sendError(res, 400, cancelled.message || 'Failed to cancel task');
    }
  }

  async handleAPITasksList(req, res, query, workspace) {
    const status = query.status || 'all';
    const limit = parseInt(query.limit) || 50;
    const offset = parseInt(query.offset) || 0;
    
    // Get all tasks
    const allTasks = [];
    
    // Add running and pending tasks
    const currentStatus = this.taskMonitor.getStatus();
    allTasks.push(...currentStatus.running, ...currentStatus.pending);
    
    // Add completed tasks from history
    const history = this.taskMonitor.getTaskHistory(100);
    allTasks.push(...history);
    
    // Filter by workspace
    let tasks = allTasks.filter(task => {
      if (task.metadata?.workspace_id) {
        return task.metadata.workspace_id === workspace.id;
      }
      // Also check by path for backward compatibility
      return task.cwd === workspace.path;
    });
    
    // Filter by status
    if (status !== 'all') {
      tasks = tasks.filter(task => task.status === status);
    }
    
    // Apply pagination
    const total = tasks.length;
    const paginatedTasks = tasks.slice(offset, offset + limit);
    
    this.sendSuccess(res, {
      tasks: paginatedTasks.map(task => ({
        id: task.id,
        name: task.name,
        status: task.status,
        startedAt: task.startedAt,
        completedAt: task.completedAt,
        queuePosition: task.status === 'pending' ? this.taskMonitor.getQueuePosition(task.id) : null
      })),
      total,
      hasMore: offset + limit < total
    });
  }

  async handleAPITaskChecklist(req, res, taskId, workspace) {
    const task = this.taskMonitor.getHistoryTaskById(taskId);
    
    if (!task) {
      this.sendError(res, 404, 'Task not found');
      return;
    }
    
    // Verify task belongs to this workspace
    if (task.metadata?.workspace_id && task.metadata.workspace_id !== workspace.id) {
      this.sendError(res, 403, 'Access denied to this task');
      return;
    }
    
    // Extract checklist results from task output if available
    const checklistResults = task.checklistResults || null;
    
    this.sendSuccess(res, {
      taskId: task.id,
      workspace: workspace.name,
      checklist: checklistResults,
      completedAt: task.completedAt
    });
  }

  async handleAPIDocumentation(req, res) {
    try {
      // Read the API documentation file
      const fs = await import('fs/promises');
      const path = await import('path');
      const { fileURLToPath } = await import('url');
      const { dirname } = await import('path');
      
      const __filename = fileURLToPath(import.meta.url);
      const __dirname = dirname(__filename);
      const docPath = path.join(__dirname, '..', 'API_DOCUMENTATION.md');
      
      let documentation = await fs.readFile(docPath, 'utf-8');
      
      // Use the configured plugin URL if available, otherwise construct from request
      const pluginUrl = process.env.ANICODE_PLUGIN_URL;
      let baseUrl, wsUrl;
      
      if (pluginUrl) {
        // Parse the plugin URL to get HTTP and WebSocket versions
        // Convert ws/wss to http/https for REST API
        baseUrl = pluginUrl.replace(/^wss:/, 'https:').replace(/^ws:/, 'http:');
        wsUrl = pluginUrl;
      } else {
        // Fallback to constructing from request headers
        const protocol = req.headers['x-forwarded-proto'] || 'http';
        const host = req.headers['x-forwarded-host'] || req.headers.host || 'localhost:6502';
        const fullUrl = req.url;
        const basePath = fullUrl.replace(/\/api\/docs.*$/, '');
        
        baseUrl = `${protocol}://${host}${basePath}`;
        const wsProtocol = protocol === 'https' ? 'wss' : 'ws';
        wsUrl = `${wsProtocol}://${host}${basePath}`;
      }
      
      // Debug logging
      logger.debug('[API] Documentation request details:', {
        pluginUrl,
        baseUrl,
        wsUrl,
        headers: req.headers
      });
      
      // Replace all localhost references with the actual host and path
      documentation = documentation.replace(/http:\/\/localhost:650[12]/g, baseUrl);
      documentation = documentation.replace(/ws:\/\/localhost:650[12]/g, wsUrl);
      
      // Set content type to markdown
      res.writeHead(200, {
        'Content-Type': 'text/markdown; charset=utf-8',
        'Cache-Control': 'public, max-age=3600' // Cache for 1 hour
      });
      // For HEAD requests, don't send body
      if (req.method === 'HEAD') {
        res.end();
      } else {
        res.end(documentation);
      }
      
      logger.debug('[API] Documentation served with base URL:', baseUrl);
    } catch (error) {
      logger.error('[API] Failed to serve documentation:', error);
      
      // Fallback to inline documentation if file not found
      const pluginUrl = process.env.ANICODE_PLUGIN_URL;
      let baseUrl;
      
      if (pluginUrl) {
        // Convert ws/wss to http/https for REST API
        baseUrl = pluginUrl.replace(/^wss:/, 'https:').replace(/^ws:/, 'http:');
      } else {
        const protocol = req.headers['x-forwarded-proto'] || 'http';
        const host = req.headers['x-forwarded-host'] || req.headers.host || 'localhost:6502';
        const fullUrl = req.url;
        const basePath = fullUrl.replace(/\/api\/docs.*$/, '');
        baseUrl = `${protocol}://${host}${basePath}`;
      }
      
      const fallbackDoc = `# AniCode REST API Documentation

## Quick Start
Visit ${baseUrl}/api/docs for full documentation.

## Authentication
All endpoints require: Authorization: Bearer YOUR_TOKEN

## Main Endpoints
- POST /api/task - Submit new task
- GET /api/task/{id} - Get task status
- GET /api/tasks - List tasks
- DELETE /api/task/{id} - Cancel task

Get a token: ani-code workspace token gen`;
      
      res.writeHead(200, {
        'Content-Type': 'text/markdown; charset=utf-8'
      });
      // For HEAD requests, don't send body
      if (req.method === 'HEAD') {
        res.end();
      } else {
        res.end(fallbackDoc);
      }
    }
  }

  async handleTelegramCallback(req, res) {
    logger.debug('Telegram callback received:', req.url);
    
    if (req.method !== 'POST') {
      this.sendError(res, 405, 'Method Not Allowed');
      return;
    }

    // Verify webhook token if configured
    if (config.telegram?.verificationToken) {
      const url = new URL(req.url, `http://${req.headers.host}`);
      const token = url.searchParams.get('token');
      
      if (token !== config.telegram.verificationToken) {
        logger.warn('Invalid Telegram webhook verification token');
        this.sendError(res, 403, 'Forbidden');
        return;
      }
    }

    let body;
    try {
      body = await this.readRequestBody(req);
    } catch (error) {
      logger.error('Failed to read request body:', error);
      this.sendError(res, 400, 'Invalid request body');
      return;
    }
    
    try {
      const data = JSON.parse(body);
      
      // Log the update for debugging
      logger.debug('Telegram update:', JSON.stringify(data, null, 2));
      
      // Handle different types of Telegram updates
      if (data.message) {
        // Regular message - pass req for gateway headers
        await this.processTelegramMessage(data.message, req);
      } else if (data.callback_query) {
        // Callback from inline keyboard button - pass req for gateway headers
        await this.processTelegramCallback(data.callback_query, req);
      } else if (data.edited_message) {
        // Edited message (we can ignore for now)
        logger.debug('Ignoring edited message from Telegram');
      } else if (data.channel_post) {
        // Channel post (ignore for now)
        logger.debug('Ignoring channel post from Telegram');
      } else if (data.my_chat_member || data.chat_member) {
        // Chat member updates (bot added/removed)
        const updateType = data.my_chat_member ? 'my_chat_member' : 'chat_member';
        const chatInfo = data.my_chat_member?.chat || data.chat_member?.chat;
        const newStatus = data.my_chat_member?.new_chat_member?.status || data.chat_member?.new_chat_member?.status;
        logger.info(`Telegram chat member update: ${updateType}`, {
          chat_id: chatInfo?.id,
          chat_type: chatInfo?.type,
          new_status: newStatus
        });
      } else {
        // Log the actual update type for debugging
        const updateType = Object.keys(data).find(key => key !== 'update_id');
        logger.debug(`Ignoring Telegram update type: ${updateType || 'unknown'}`);
      }
      
      // Always return 200 OK to prevent Telegram from retrying
      this.sendSuccess(res, { success: true });
    } catch (error) {
      logger.error('Failed to process Telegram callback:', error);
      // Still return success to prevent retries
      this.sendSuccess(res, { success: true });
    }
  }

  async processTelegramMessage(message, request = null) {
    // TOP-LEVEL TRY-CATCH TO CATCH ALL ERRORS
    try {
      // Log incoming Telegram message content before processing - but safely
      const logData = {
      message_id: message.message_id,
      chat_id: message.chat?.id,
      chat_type: message.chat?.type,
      user_id: message.from?.id,
      username: message.from?.username,
      text: message.text || null,
      caption: message.caption || null,
      has_photo: message.photo ? true : false,
      has_attachments: message.attachments ? true : false,
      attachment_count: message.attachments?.length || 0,
      has_document: message.document ? true : false,
      has_video: message.video ? true : false,
      has_audio: message.audio ? true : false,
      has_voice: message.voice ? true : false,
      has_sticker: message.sticker ? true : false,
      entities: message.entities || null,
      date: new Date(message.date * 1000).toISOString()
    };

    // Add reply information if present
    if (message.reply_to_message) {
      logData.reply_to = {
        message_id: message.reply_to_message.message_id,
        from_id: message.reply_to_message.from?.id,
        from_username: message.reply_to_message.from?.username,
        text: message.reply_to_message.text || null,
        caption: message.reply_to_message.caption || null,
        has_photo: message.reply_to_message.photo ? true : false,
        has_attachments: message.reply_to_message.attachments ? true : false,
        photo_count: message.reply_to_message.photo ? message.reply_to_message.photo.length : 0,
        has_document: message.reply_to_message.document ? true : false,
        document_mime: message.reply_to_message.document?.mime_type || null,
        date: message.reply_to_message.date ? new Date(message.reply_to_message.date * 1000).toISOString() : null
      };
    }

    logger.info('[TELEGRAM] Received message:', logData);

    // Log webhook received to database immediately
    try {
      // Initialize workspace manager if needed
      if (!this.workspaceManager) {
        const { WorkspaceManager } = await import('./workspace-manager.js');
        this.workspaceManager = new WorkspaceManager();
        await this.workspaceManager.initialize();
      }

      const chatId = message.chat?.id;
      // Try to find the workspace for this chat
      let workspaceId = null;
      const telegramChat = await this.workspaceManager.getTelegramChat(chatId);
      if (telegramChat && telegramChat.workspace_id) {
        workspaceId = telegramChat.workspace_id;
      }
      await this.workspaceManager.logTelegramWebhookReceived(
        chatId,
        message,
        { workspace_id: workspaceId }
      );
      logger.debug('[TELEGRAM] Logged webhook received event to database');
    } catch (logError) {
      logger.debug('Failed to log webhook to database:', logError.message);
    }

    // Log full webhook payload if this is a reply to a message with an image or document
    if (message.reply_to_message && (message.reply_to_message.photo || message.reply_to_message.document)) {
      logger.debug('[TELEGRAM] Full reply payload with image/document:', JSON.stringify(message.reply_to_message));
    }
    
    const chatId = message.chat.id;
    // Fix Telegram's auto-conversion of -- to — (em dash)
    const text = message.text ? message.text.replace(/—/g, '--') : message.text;
    const messageId = message.message_id;
    const userId = message.from?.id;
    const username = message.from?.username;
    const messageDate = message.date; // Unix timestamp in seconds
    
    // Check if message contains web attachments (images from web UI via S3 URLs)
    // Web attachments have a different format: { type: 'image', url: 'S3_URL', filename, mimeType, size }
    if (message.attachments && Array.isArray(message.attachments) && message.attachments.length > 0) {
      const imageAttachments = message.attachments.filter(att => att.type === 'image');

      if (imageAttachments.length > 0) {
        logger.info(`Web image attachments from chat ${chatId} (user: ${userId}/${username}): ${imageAttachments.length} image(s)`);

        // Store web attachments for this chat (similar to Telegram photos)
        // Use the first image for /url command compatibility
        const firstImage = imageAttachments[0];
        this.recentImages.set(chatId, {
          fileId: null, // Web attachments don't have Telegram file_id
          fileType: 'web_image',
          fileName: firstImage.filename || null,
          messageId: messageId,
          timestamp: Date.now(),
          username: username,
          caption: text || null,
          webUrl: firstImage.url, // S3 URL for web attachments
          mimeType: firstImage.mimeType,
          size: firstImage.size
        });

        // Clean up old images (keep only last 10 minutes)
        const tenMinutesAgo = Date.now() - 600000;
        for (const [key, value] of this.recentImages.entries()) {
          if (value.timestamp < tenMinutesAgo) {
            this.recentImages.delete(key);
          }
        }

        // Task commands (/add, /continue) with web attachments are handled by the
        // normal command processing flow below — message.attachments is passed through
        // to createTelegramTask which stores them on the task for processAttachments

        const textTrimmed = text ? text.trim() : '';

        // Check for prompt-based commands (/goaladd, /goaladdmulti, /plan, /goalreview)
        // These commands take a description/prompt and should receive image attachments with download instructions
        const promptBasedCommands = ['/goaladd', '/goaladdmulti', '/goalreview', '/plan'];
        const isPromptBasedCommand = textTrimmed.startsWith('/') &&
          promptBasedCommands.some(cmd =>
            textTrimmed === cmd ||
            textTrimmed.startsWith(cmd + ' ') ||
            textTrimmed.startsWith(cmd + '@')
          );

        if (isPromptBasedCommand) {
          logger.info(`Web attachment with prompt-based command: ${textTrimmed}`);

          // Ensure tmp directory exists with .gitignore before Claude downloads images
          try {
            // Get or initialize workspace manager
            if (!this.workspaceManager) {
              const { WorkspaceManager } = await import('./workspace-manager.js');
              this.workspaceManager = new WorkspaceManager();
              await this.workspaceManager.initialize();
            }

            // Find workspace for this chat and ensure tmp directory exists
            const telegramChat = await this.workspaceManager.getTelegramChat(chatId);
            if (telegramChat?.workspace_id) {
              const workspace = await this.workspaceManager.getWorkspaceById(telegramChat.workspace_id);
              if (workspace?.workspace_path) {
                ensureTmpDir(workspace.workspace_path);
                logger.debug(`Ensured tmp directory exists at ${workspace.workspace_path}/.ani-code/tmp/`);
              }
            } else if (config.gateway?.enabled) {
              // In gateway mode, use /workspace as default
              ensureTmpDir('/workspace');
              logger.debug(`Gateway mode: Ensured tmp directory exists at /workspace/.ani-code/tmp/`);
            }
          } catch (tmpDirError) {
            logger.warn(`Failed to ensure tmp directory: ${tmpDirError.message}`);
            // Continue anyway - Claude will create the directory if needed
          }

          // Parse the command to extract the base command and args
          const commandMatch = textTrimmed.match(/^(\/\w+)(?:@\S+)?(?:\s+(.*))?$/s);
          if (commandMatch) {
            const baseCommand = commandMatch[1];
            const originalArgs = commandMatch[2] ? commandMatch[2].trim() : '';

            // Build the image context to inject into the prompt
            // Use the first image URL for simplicity (multiple images are listed)
            const imageUrls = imageAttachments.map(img => img.url);
            let imageContext;
            if (imageUrls.length === 1) {
              imageContext = `\n\nImage: ${imageUrls[0]}\n\nNote: Download to .ani-code/tmp/ folder using wget with the original filename from the URL (not a generic name like image.jpg) and analyze`;
            } else {
              imageContext = `\n\nImages:\n${imageUrls.map((url, i) => `${i + 1}. ${url}`).join('\n')}\n\nNote: Download to .ani-code/tmp/ folder using wget with the original filename from the URL (not a generic name like image.jpg) and analyze`;
            }

            // Reconstruct the command with image context injected into args
            const argsWithImage = originalArgs ? `${originalArgs}${imageContext}` : `Review attached file or image${imageContext}`;
            const fullCommand = `${baseCommand} ${argsWithImage}`;

            logger.info(`Processing prompt-based command ${baseCommand} with web attachment(s) for chat ${chatId}`);
            logger.debug(`Full command with image: ${fullCommand.substring(0, 200)}...`);

            // Route through processTelegramCommand to use the standard command handlers
            await this.processTelegramCommand(fullCommand, chatId, message);
            return; // Return to avoid double-processing
          } else {
            logger.warn(`Failed to parse prompt-based command from text: ${textTrimmed}`);
          }
        }
      }
    }

    // Check if message contains a photo or document (images sent as original quality become documents)
    if ((message.photo && message.photo.length > 0) || message.document) {
      let fileId, fileType, fileName;
      
      if (message.photo && message.photo.length > 0) {
        // Handle regular photo
        const photo = message.photo[message.photo.length - 1]; // Get highest resolution
        fileId = photo.file_id;
        fileType = 'photo';
        fileName = null;
        logger.debug(`Photo array has ${message.photo.length} sizes, using highest resolution with file_id: ${fileId}`);
      } else if (message.document) {
        // Handle document (including images sent as original quality and other supported formats)
        const MAX_FILE_SIZE = 20 * 1024 * 1024; // 20MB
        if (message.document?.file_size > MAX_FILE_SIZE) {
          logger.info(`Ignoring oversized document: ${message.document.file_size} bytes (${message.document.file_name || 'unnamed'})`);
          return;
        }
        fileId = message.document.file_id;
        fileType = 'document';
        fileName = message.document.file_name || null;
        const mimeType = message.document.mime_type || 'unknown';
        logger.debug(`Document received: ${fileName || 'unnamed'}, mime_type: ${mimeType}, file_id: ${fileId}`);
      }

      const captionInfo = message.caption ? ` with caption: "${message.caption}"` : '';
      logger.info(`Telegram ${fileType} message from chat ${chatId} (user: ${userId}/${username})${captionInfo}`);
      
      // Store the file info for this chat (for /url command)
      this.recentImages.set(chatId, {
        fileId: fileId,
        fileType: fileType,
        fileName: fileName,
        messageId: messageId,
        timestamp: Date.now(),
        username: username,
        caption: message.caption || null
      });
      
      // Clean up old images (keep only last 10 minutes)
      const tenMinutesAgo = Date.now() - 600000;
      for (const [key, value] of this.recentImages.entries()) {
        if (value.timestamp < tenMinutesAgo) {
          this.recentImages.delete(key);
        }
      }
      
      // Check if caption contains commands (fix em dash conversion)
      const captionText = message.caption ? message.caption.replace(/—/g, '--').trim() : '';
      const isUrlCommand = captionText === '/url' || captionText.startsWith('/url ') || captionText.startsWith('/url@');
      const isAddCommand = captionText === '/add' || captionText.startsWith('/add ') || captionText.startsWith('/add@');
      const isContinueCommand = captionText === '/continue' || captionText.startsWith('/continue ') || captionText.startsWith('/continue@');
      const isTaskCommand = isAddCommand || isContinueCommand;

      // Check for other prompt-based commands that should receive image attachments
      // These commands take a description/prompt and will be routed to processTelegramCommand with the image URL injected
      const promptBasedCommands = ['/goaladd', '/goaladdmulti', '/goalreview', '/plan'];
      const isPromptBasedCommand = captionText.startsWith('/') &&
        promptBasedCommands.some(cmd =>
          captionText === cmd ||
          captionText.startsWith(cmd + ' ') ||
          captionText.startsWith(cmd + '@')
        );
      
      // In private chats or when bot is mentioned or caption contains commands, auto-process
      const isGroupChat = message.chat.type === 'group' || message.chat.type === 'supergroup';
      const botMention = this.telegramBotUsername ? `@${this.telegramBotUsername}` : null;
      const isBotMentioned = message.caption && botMention && message.caption.includes(botMention);

      if (!isGroupChat || isBotMentioned || isUrlCommand || isTaskCommand || isPromptBasedCommand) {
        // Get or initialize Telegram notifier
        if (!this.telegramNotifier) {
          const { TelegramNotifier } = await import('./telegram-notifier.js');
          this.telegramNotifier = new TelegramNotifier();
        }
        
        // Implement retry logic with exponential backoff for ECONNRESET errors
        const maxRetries = 3;
        let retryCount = 0;
        let fileData = null;
        
        while (retryCount < maxRetries && !fileData) {
          try {
            // Get file info from Telegram
            const botToken = config.telegram?.botToken;
            if (!botToken) {
              logger.error('Telegram bot token not configured');
              await this.telegramNotifier.sendMessage(chatId, 
                '❌ Bot configuration error. Please contact administrator.',
                { reply_to_message_id: messageId }
              );
              return;
            }
            
            const apiUrl = `https://api.telegram.org/bot${botToken}`;
            
            let fileResponse;
            let timeout; // Declare timeout in outer scope
            try {
              // Add timeout and better error handling for fetch
              // Use the new Telegram API helper with built-in retry logic
              if (this.telegramAPI) {
                fileResponse = await this.telegramAPI.getFile(fileId);
              } else {
                // Fallback if API client not initialized
                const controller = new AbortController();
                timeout = setTimeout(() => controller.abort(), 15000); // 15 second timeout
                
                fileResponse = await fetch(`${apiUrl}/getFile?file_id=${fileId}`, {
                  signal: controller.signal,
                  headers: {
                    'Connection': 'close',
                    'Cache-Control': 'no-cache'
                  },
                  keepalive: false
                });
                clearTimeout(timeout);
                fileResponse = await fileResponse.json();
              }
            } catch (fetchError) {
              if (timeout) clearTimeout(timeout);
              
              // Handle ECONNRESET and other network errors with retry
              if (fetchError.code === 'ECONNRESET' || 
                  fetchError.message?.includes('ECONNRESET') ||
                  fetchError.message?.includes('socket hang up') ||
                  fetchError.message?.includes('ENOTFOUND')) {
                
                retryCount++;
                if (retryCount < maxRetries) {
                  logger.warn(`Network error (attempt ${retryCount}/${maxRetries}), retrying in ${retryCount * 1000}ms:`, fetchError.message);
                  // Exponential backoff
                  await new Promise(resolve => setTimeout(resolve, retryCount * 1000));
                  continue; // Retry the request
                }
              }
              
              const errorMessage = fetchError.cause?.message || fetchError.message || 'Unknown network error';
              const errorCode = fetchError.cause?.code || fetchError.code || fetchError.name;
              const errorReason = fetchError.cause?.reason || fetchError.reason || '';
              
              // Log the full error details as a single string for better visibility
              logger.error(`Network error fetching Telegram file info after retries:
  Error: ${errorMessage}
  Code: ${errorCode}
  Type: ${fetchError.name}
  Reason: ${errorReason}
  Full Error: ${fetchError.toString()}`);
              
              // Check if it's a network/connection error
              if (fetchError.name === 'FetchError' || fetchError.name === 'AbortError' || fetchError.code === 'ECONNRESET') {
                // Don't add retry button due to payload size limitations with caption
                // User can simply resend the image
                await this.telegramNotifier.sendMessage(chatId, 
                  '⚠️ Network error getting image URL. Please resend the image.',
                  { 
                    reply_to_message_id: messageId
                  }
                );
              } else {
                await this.telegramNotifier.sendMessage(chatId, 
                  '❌ Failed to get image URL. Please try again.',
                  { reply_to_message_id: messageId }
                );
              }
              return;
            }
          
            // Check response based on whether we used the API helper or direct fetch
            const isOk = this.telegramAPI ? fileResponse.ok : fileResponse?.ok;
            
            if (!isOk) {
              // Handle rate limiting specifically (only for direct fetch)
              if (!this.telegramAPI && fileResponse.status === 429) {
                retryCount++;
                if (retryCount < maxRetries) {
                  const retryAfter = fileResponse.headers.get('Retry-After') || retryCount * 2;
                  logger.warn(`Rate limited (attempt ${retryCount}/${maxRetries}), retrying after ${retryAfter} seconds`);
                  await new Promise(resolve => setTimeout(resolve, retryAfter * 1000));
                  continue; // Retry the request
                }
              }
              
              logger.error(`Telegram API returned status ${fileResponse.status} for file ${fileId}`);
              await this.telegramNotifier.sendMessage(chatId, 
                `❌ Telegram API error (${fileResponse.status}). Please try again later.`,
                { reply_to_message_id: messageId }
              );
              return;
            }
            
            // Extract file data based on API helper or direct fetch
            fileData = this.telegramAPI ? fileResponse : await fileResponse.json();
            break; // Success, exit the retry loop
            
          } catch (error) {
            // Handle any other errors in the try block
            retryCount++;
            if (retryCount < maxRetries) {
              logger.warn(`Error processing request (attempt ${retryCount}/${maxRetries}), retrying:`, error.message);
              await new Promise(resolve => setTimeout(resolve, retryCount * 1000));
              continue;
            }
            
            logger.error('Error processing Telegram photo after retries:', error);
            await this.telegramNotifier.sendMessage(chatId, 
              '❌ Error processing image. Please try again.',
              { reply_to_message_id: messageId }
            );
            return;
          }
        }
        
        // Process the file data if we got it
        // Handle both direct Telegram API response and gateway mode response
        const hasFileData = fileData && (fileData.ok || fileData.success) && (fileData.result || fileData.file_path);
        if (hasFileData) {
          const botToken = config.telegram?.botToken;
          const filePath = fileData.result?.file_path || fileData.file_path;
          const telegramUrl = `https://api.telegram.org/file/bot${botToken}/${filePath}`;
          
          try {
            // Upload image to S3
            const uploader = new SecureUploader();
            
            // Get workdir name for this chat (to use as S3 path prefix)
            const workdirName = this.chatSettings.getWorkdir(`telegram:${chatId}`);
            const workdirPath = workdirName || 'telegram-images'; // fallback if no workdir set
            
            const s3Result = await uploader.uploadImageFromUrl(telegramUrl, {
              workdir: workdirPath,
              fileName: fileName,
              fileType: fileType,
              metadata: {
                'telegram-chat-id': chatId.toString(),
                'telegram-user': username || userId || 'unknown',
                'telegram-message-id': messageId.toString(),
                'caption': (message.caption || '').replace(/[\r\n]/g, ' ').replace(/[\x00-\x1F\x7F]/g, '').trim()
              }
            });
            
            // Create inline keyboard with copy and open buttons
            const keyboard = {
              inline_keyboard: [[
                {
                  text: '📋 Copy URL',
                  copy_text: {
                    text: s3Result.url
                  }
                },
                {
                  text: '🔗 Open Image',
                  url: s3Result.url
                }
              ]]
            };
            
            // Send the S3 URL back to the user (skip if task command will be processed or caption creates a task)
            // Use concise message if /url caption was used, especially in groups
            const willProcessAsTask = isTaskCommand || isPromptBasedCommand || (captionText && !isUrlCommand && !isPromptBasedCommand);
            if (!willProcessAsTask) {
              if (isUrlCommand && isGroupChat) {
                // Concise response for /url caption in groups
                await this.telegramNotifier.sendMessage(chatId, 
                  `🔗 \`${s3Result.url}\``,
                  { 
                    parse_mode: 'Markdown',
                    reply_to_message_id: messageId,
                    reply_markup: keyboard
                  }
                );
              } else {
                // Full response for private chats or when bot is mentioned
                await this.telegramNotifier.sendMessage(chatId, 
                  `🖼️ *Image uploaded to S3!*\n\n` +
                  `📎 URL:\n\`${s3Result.url}\`\n\n` +
                  `📊 Size: ${(s3Result.size / 1024).toFixed(2)} KB\n` +
                  `🔑 MD5: \`${s3Result.md5}\`\n\n` +
                  `_Image has been securely uploaded to S3._\n` +
                  `_In groups, use /url to get the URL of the last image._`,
                  { 
                    parse_mode: 'Markdown',
                    reply_to_message_id: messageId,
                    reply_markup: keyboard
                  }
                );
              }
            }
            
            // Update the stored image info with S3 URL
            const storedImage = this.recentImages.get(chatId);
            if (storedImage) {
              storedImage.s3Url = s3Result.url;
              storedImage.s3Key = s3Result.s3Key;
              storedImage.md5 = s3Result.md5;
              storedImage.size = s3Result.size;
            }
            
            logger.info(`Uploaded Telegram image to S3 for chat ${chatId}: ${s3Result.url}`);
            
            // Handle task commands with image URL
            if (isTaskCommand) {
              // Parse the command from caption
              let command, args;
              
              if (isAddCommand) {
                // Extract prompt after /add (handles multiline)
                const match = captionText.match(/^\/add(?:@\S+)?(?:\s+(.+))?$/s);
                command = 'add';
                args = match && match[1] ? match[1].trim() : null;
                
                // If no prompt provided with /add, ask user to provide one
                if (!args) {
                  await this.telegramNotifier.sendMessage(chatId, 
                    '❌ Please provide a description or question with the /add command.\n\n' +
                    'Example: `/add What is in this image?`\n\n' +
                    'Or simply send the image with a caption (without /add) to create a task.',
                    { 
                      parse_mode: 'Markdown',
                      reply_to_message_id: messageId 
                    }
                  );
                  return;
                }
              } else if (isContinueCommand) {
                // Extract optional prompt after /continue (handles multiline)
                const match = captionText.match(/^\/continue(?:@\S+)?(?:\s+(.+))?$/s);
                command = 'continue';
                args = match && match[1] ? match[1].trim() : '';
              }
              
              // Append image URL to the prompt with download instructions
              const imageContext = `\n\nImage: ${s3Result.url}\n\nNote: Download to .ani-code/tmp/ folder using wget with the original filename from the URL (not a generic name like image.jpg) and analyze`;
              const fullPrompt = args ? `${args}${imageContext}` : imageContext;
              
              logger.info(`Processing ${command} command with image URL for chat ${chatId}`);
              logger.debug(`Full prompt with image: ${fullPrompt}`);
              
              // Execute the task command with the image URL appended
              await this.createTelegramTask(chatId, command, fullPrompt);
            } else if (isPromptBasedCommand) {
              // Handle prompt-based commands (/goaladd, /plan, /goalreview, etc.) with image URL injection

              // Ensure tmp directory exists with .gitignore before Claude downloads images
              try {
                // Get or initialize workspace manager
                if (!this.workspaceManager) {
                  const { WorkspaceManager } = await import('./workspace-manager.js');
                  this.workspaceManager = new WorkspaceManager();
                  await this.workspaceManager.initialize();
                }

                // Find workspace for this chat and ensure tmp directory exists
                const telegramChat = await this.workspaceManager.getTelegramChat(chatId);
                if (telegramChat?.workspace_id) {
                  const workspace = await this.workspaceManager.getWorkspaceById(telegramChat.workspace_id);
                  if (workspace?.workspace_path) {
                    ensureTmpDir(workspace.workspace_path);
                    logger.debug(`Ensured tmp directory exists at ${workspace.workspace_path}/.ani-code/tmp/`);
                  }
                } else if (config.gateway?.enabled) {
                  // In gateway mode, use /workspace as default
                  ensureTmpDir('/workspace');
                  logger.debug(`Gateway mode: Ensured tmp directory exists at /workspace/.ani-code/tmp/`);
                }
              } catch (tmpDirError) {
                logger.warn(`Failed to ensure tmp directory: ${tmpDirError.message}`);
                // Continue anyway - Claude will create the directory if needed
              }

              // Parse the command to extract the base command and args
              const commandMatch = captionText.match(/^(\/\w+)(?:@\S+)?(?:\s+(.*))?$/s);
              if (commandMatch) {
                const baseCommand = commandMatch[1];
                const originalArgs = commandMatch[2] ? commandMatch[2].trim() : '';

                // Build the image context to inject into the prompt
                const imageContext = `\n\nImage: ${s3Result.url}\n\nNote: Download to .ani-code/tmp/ folder using wget with the original filename from the URL (not a generic name like image.jpg) and analyze`;

                // Reconstruct the command with image context injected into args
                const argsWithImage = originalArgs ? `${originalArgs}${imageContext}` : `Review attached file or image${imageContext}`;
                const fullCommand = `${baseCommand} ${argsWithImage}`;

                logger.info(`Processing prompt-based command ${baseCommand} with image URL for chat ${chatId}`);
                logger.debug(`Full command with image: ${fullCommand.substring(0, 200)}...`);

                // Route through processTelegramCommand to use the standard command handlers
                await this.processTelegramCommand(fullCommand, chatId, message);
              } else {
                logger.warn(`Failed to parse prompt-based command from caption: ${captionText}`);
              }
            } else if (captionText && !isUrlCommand) {
              // If there's a caption but it's not a command, create an add task with the caption as the prompt
              const imageContext = `\n\nImage: ${s3Result.url}\n\nNote: Download to .ani-code/tmp/ folder using wget with the original filename from the URL (not a generic name like image.jpg) and analyze`;
              const fullPrompt = `${captionText}${imageContext}`;

              logger.info(`Processing image with caption as task for chat ${chatId}`);
              logger.debug(`Caption-based prompt with image: ${fullPrompt}`);

              // Create an add task with the caption and image URL
              await this.createTelegramTask(chatId, 'add', fullPrompt);
            }
          } catch (error) {
            const errorMessage = error.cause?.message || error.message || 'Unknown error';
            const errorCode = error.cause?.code || error.code || error.name;
            logger.error('Failed to upload image to S3:', {
              error: errorMessage,
              code: errorCode,
              type: error.name,
              chatId,
              fileId: fileId
            });
            
            // Mask any credentials in the error message before sending to user
            const maskedErrorMessage = SecureUploader.maskCredentials(errorMessage);
            
            // Fallback: send error message with properly escaped Markdown
            const escapedError = this.telegramNotifier.escapeMarkdownContent(maskedErrorMessage);
            await this.telegramNotifier.sendMessage(chatId, 
              `⚠️ *Image received but S3 upload failed*\n\n` +
              `Error: ${escapedError}\n\n` +
              `The image was received but could not be uploaded to S3\\. Please check S3 configuration\\.`,
              { 
                parse_mode: 'Markdown',
                reply_to_message_id: messageId 
              }
            );
          }
        } else {
          logger.error('Failed to get file info from Telegram after all retries:', fileData);
          await this.telegramNotifier.sendMessage(chatId, 
            '❌ Failed to get image URL after multiple attempts. The Telegram servers may be experiencing issues.',
            { reply_to_message_id: messageId }
          );
        }
      } else {
        // In group chats without mention, just store the image silently
        const captionInfo = message.caption ? ` with caption: "${message.caption}"` : ' (no caption)';
        logger.info(`Stored image from chat ${chatId} for later retrieval with /url command${captionInfo}`);
      }
      
      return;
    }
    
    if (!text) {
      logger.debug('Ignoring non-text message from Telegram');
      return;
    }
    
    logger.info(`📨 Telegram msg`, { chatId, userId, username, textLen: text?.length || 0, hasReply: !!message.reply_to_message });
    
    // Check message age - Telegram sends date as Unix timestamp in seconds
    if (messageDate) {
      const messageAge = Date.now() - (messageDate * 1000); // Convert to milliseconds
      if (messageAge > this.MAX_MESSAGE_AGE_MS) {
        logger.warn(`⏰ STALE TELEGRAM MESSAGE REJECTED:
  Message ID: ${messageId}
  Chat ID: ${chatId}
  Message Age: ${Math.round(messageAge/1000)} seconds (>${this.MAX_MESSAGE_AGE_MS/1000}s threshold)
  Message Time: ${new Date(messageDate * 1000).toISOString()}
  Current Time: ${new Date().toISOString()}
  Message Text: ${text.substring(0, 50)}${text.length > 50 ? '...' : ''}`);
        return;
      } else {
        logger.debug(`✅ Telegram message age check passed: ${Math.round(messageAge/1000)}s old (within ${this.MAX_MESSAGE_AGE_MS/1000}s threshold)`);
      }
    }
    
    // Check for deduplication
    const dedupKey = `telegram:${chatId}:${messageId}`;
    if (this.processedMessages.has(dedupKey)) {
      logger.debug(`Duplicate Telegram message ${messageId}, ignoring`);
      return;
    }
    this.processedMessages.set(dedupKey, Date.now());
    
    // Get or initialize Telegram notifier
    if (!this.telegramNotifier) {
      const { TelegramNotifier } = await import('./telegram-notifier.js');
      this.telegramNotifier = new TelegramNotifier();
    }
    
    // Initialize workspace manager if not already done
    if (!this.workspaceManager) {
      const { WorkspaceManager } = await import('./workspace-manager.js');
      this.workspaceManager = new WorkspaceManager();
      await this.workspaceManager.initialize();
    }
    
    // Register chat information in database
    const chatInfo = {
      chat_id: String(chatId),
      chat_type: message.chat.type || 'private',
      chat_title: message.chat.title,
      username: message.from?.username,
      first_name: message.from?.first_name,
      last_name: message.from?.last_name,
      metadata: {
        user_id: userId,
        language_code: message.from?.language_code
      }
    };
    
    await this.workspaceManager.registerTelegramChat(chatInfo);
    
    // Process text to remove bot mentions in group chats
    let processedText = text;
    const isGroupChat = message.chat.type === 'group' || message.chat.type === 'supergroup';
    
    // Log concise message info, avoiding full text content
    const messageInfo = {
      chatId,
      chatType: message.chat.type,
      messageId: message.message_id,
      textLength: text?.length || 0,
      hasReply: !!message.reply_to_message,
      replyHasPhoto: message.reply_to_message?.photo ? true : false,
      replyHasDoc: message.reply_to_message?.document ? true : false
    };
    logger.info(`📥 Telegram message received:`, messageInfo);
    
    // For /connect command, handle bot mention removal differently
    if (text.startsWith('/connect ')) {
      logger.info(`🎯 Handler: command:connect (special handling for chat: ${chatId})`);
      // Extract everything after '/connect '
      let token = text.substring(9).trim();
      
      logger.debug(`Token extracted`, { length: token?.length || 0 });
      
      // Remove bot mention if present - but be careful not to remove @ from URLs
      // Only remove @botusername if it's at the end of the token
      if (this.telegramBotUsername) {
        const botMentionPattern = new RegExp(`\\s*@${this.telegramBotUsername}$`);
        if (botMentionPattern.test(token)) {
          token = token.replace(botMentionPattern, '').trim();
          logger.info(`Removed bot mention from token. Clean token length: ${token.length}`);
        }
      }
      // Also check for hardcoded bot name as fallback
      const hardcodedBotPattern = /\s*@anicodedev_bot$/;
      if (hardcodedBotPattern.test(token)) {
        token = token.replace(hardcodedBotPattern, '').trim();
        logger.info(`Removed hardcoded bot mention from token. Clean token length: ${token.length}`);
      }
      
      logger.debug(`Final token`, { length: token?.length || 0, tokenPresent: !!token });
      
      if (token) {
        await this.handleTelegramConnect(chatId, token);
        // Log that the connect command was processed
        logger.info(`✅ Message processed by command:connect`, {
          chatId,
          messageId: message.message_id,
          success: true
        });
        return;
      }
    }
    
    // Process other commands normally
    // Only process @ as bot mention if it's followed by a valid username (not a URL)
    if (isGroupChat && text.startsWith('/') && this.telegramBotUsername) {
      // Check if the command has @botusername at the end (Telegram command format)
      const botMentionPattern = new RegExp(`@${this.telegramBotUsername}(\\s|$)`);
      if (botMentionPattern.test(text)) {
        // Remove bot mention from commands in group chats
        processedText = text.replace(botMentionPattern, '').trim();
        logger.debug(`Removed bot mention from command: ${processedText}`);
      }
    }
    
    // Check authorization (pass request for gateway headers)
    logger.debug(`Checking authorization for chat ${chatId}, user ${userId}`);
    const isAuthorized = await this.checkTelegramAuthorization(chatId, userId, request);
    logger.debug(`Authorization result for chat ${chatId}: ${isAuthorized}`);
    
    if (!isAuthorized) {
      logger.warn(`❌ Message processing failed`, {
        chatId,
        messageId: message.message_id,
        handler: 'unauthorized',
        error: `Unauthorized access from user ${userId}`
      });
      await this.telegramNotifier.sendMessage(chatId, 
        `🔒 *Access Denied*\n\n` +
        `This chat is not authorized to use the bot.\n\n` +
        `To connect to a workspace, use:\n` +
        `\`/connect <token>\`\n\n` +
        `You can generate a token from your workspace using:\n` +
        `\`ani-code workspace token <workspace-name>\``,
        { parse_mode: 'Markdown' }
      );
      return;
    }
    
    // In group chats, check if bot is mentioned or if it's a reply to bot's message
    // isGroupChat already defined above
    let shouldProcess = false;
    processedText = text;
    
    if (isGroupChat) {
      // Check if bot is mentioned
      const botMention = this.telegramBotUsername ? `@${this.telegramBotUsername}` : null;
      
      if (text.startsWith('/')) {
        // Commands in groups might have @botname suffix
        // But be careful not to split on @ in URLs or other content
        if (this.telegramBotUsername && text.includes(`@${this.telegramBotUsername}`)) {
          // Command mentions our bot specifically
          shouldProcess = true;
          // Remove only the bot mention, not other @ symbols
          processedText = text.replace(new RegExp(`@${this.telegramBotUsername}(\\s|$)`), '').trim();
        } else {
          // Command without bot mention - process it anyway in case it's for us
          shouldProcess = true;
        }
      } else if (botMention && text.includes(botMention)) {
        // Bot is mentioned in the message
        shouldProcess = true;
        // Remove the mention from the text
        processedText = text.replace(botMention, '').trim();
      } else if (message.reply_to_message && message.reply_to_message.from?.is_bot) {
        // Check if this is a reply to our bot's message
        // Note: We should ideally check if it's our specific bot, but this is a good approximation
        shouldProcess = true;
      }
      
      // If bot is not mentioned and it's not a command, ignore in group chats
      if (!shouldProcess) {
        logger.debug(`🔇 Message ignored (not directed at bot)`, {
          chatId,
          messageId: message.message_id,
          handler: 'ignored_group_message'
        });
        return;
      }
    } else {
      // In private chats, process all messages
      shouldProcess = true;
    }
    
    // Process commands and track which handler processes the message
    let handlerUsed = 'unknown';
    let handlerResult = null;
    
    try {
      if (processedText.startsWith('/')) {
        const command = processedText.split(' ')[0].substring(1).toLowerCase();
        handlerUsed = `command:${command}`;
        logger.info(`🎯 Handler: ${handlerUsed} (chat: ${chatId})`);
        handlerResult = await this.processTelegramCommand(processedText, chatId, message);
      } else {
        // Non-command text
        const fullChatId = `telegram:${chatId}`;
        const displayModeManager = new DisplayModeManager(this.chatSettings);
        const chatDisplayMode = displayModeManager.getDisplayMode(fullChatId);

        if (chatDisplayMode === 'simple') {
          // In simple mode, check for special keywords that map to commands
          const trimmedLower = processedText.trim().toLowerCase();
          if (trimmedLower === 'continue') {
            // "continue" maps to /continue, not /add continue
            handlerUsed = 'simple_auto_continue';
            logger.info(`🎯 Handler: ${handlerUsed} (chat: ${chatId})`);
            handlerResult = await this.processTelegramCommand('/continue', chatId, message);
          } else {
            // Auto-treat plain text as /add task
            handlerUsed = 'simple_auto_add';
            logger.info(`🎯 Handler: ${handlerUsed} (chat: ${chatId}, text_length: ${processedText.length})`);
            handlerResult = await this.processTelegramCommand(`/add ${processedText}`, chatId, message);
          }
        } else {
          // Full mode - show help or unrecognized command UI
          handlerUsed = 'unrecognized_text';
          logger.info(`🎯 Handler: ${handlerUsed} (chat: ${chatId}, text_length: ${processedText.length})`);
          const workdirName = this.chatSettings.getWorkdir(fullChatId);

          // Extract attachments from message if present (for web chat image uploads)
          const messageAttachments = message?.attachments || null;

          // Show unrecognized command UI with action buttons (pass attachments for later task creation)
          await this.showTelegramUnrecognizedCommand(chatId, processedText, workdirName, messageAttachments);
          handlerResult = { success: true, handler: 'unrecognized_ui' };
        }
      }
      
      // Log final processing status
      logger.info(`✅ Message processed by ${handlerUsed}`, {
        chatId,
        messageId: message.message_id,
        success: handlerResult?.success !== false
      });
    } catch (error) {
      handlerUsed = `error:${error.message?.substring(0, 50)}`;
      logger.error(`❌ Message processing failed`, {
        chatId,
        messageId: message.message_id,
        handler: handlerUsed,
        error: error.message
      });
    }
    } catch (topLevelError) {
      // TOP-LEVEL CATCH: This should catch ANY error that occurs during message processing
      logger.error(`🚨 CRITICAL: Uncaught error in processTelegramMessage`, {
        error: topLevelError.message,
        stack: topLevelError.stack,
        messageId: message?.message_id,
        chatId: message?.chat?.id,
        userId: message?.from?.id,
        textLength: message?.text?.length || 0
      });
      
      // Try to notify the user if possible
      try {
        if (message?.chat?.id && this.telegramNotifier) {
          await this.telegramNotifier.sendMessage(message.chat.id,
            `❌ An unexpected error occurred while processing your message.\n\n` +
            `Please try again with a simpler message or contact support.\n\n` +
            `Error: ${topLevelError.message?.substring(0, 100) || 'Unknown error'}`,
            { parse_mode: 'Markdown' }
          );
        }
      } catch (notifyError) {
        logger.error('Failed to notify user of error:', notifyError);
      }
    }
  }

  async answerTelegramCallbackQuery(chatId, callbackId, options = {}) {
    // Helper method to answer callback queries with gateway support
    try {
      // Route through gateway if enabled
      if (config.gateway.enabled) {
        if (!this.telegramNotifier) {
          const { TelegramNotifier } = await import('./telegram-notifier.js');
          this.telegramNotifier = new TelegramNotifier();
        }
        // Use the dummy notifier's gateway method - needs chatId for gateway validation
        return await this.telegramNotifier.answerCallbackQueryViaGateway(chatId, callbackId, options);
      }

      // Direct API call when not in gateway mode
      if (this.telegramAPI) {
        return await this.telegramAPI.answerCallbackQuery(callbackId, options);
      } else {
        const response = await fetch(`https://api.telegram.org/bot${config.telegram.botToken}/answerCallbackQuery`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            callback_query_id: callbackId,
            ...options
          })
        });
        return await response.json();
      }
    } catch (error) {
      logger.error('Failed to answer callback query:', error);
      // Return success to prevent blocking execution
      return { ok: true };
    }
  }

  async processTelegramCallback(callbackQuery, request = null) {
    try {
      const chatId = callbackQuery.message.chat.id;
      const messageId = callbackQuery.message.message_id;
      const callbackId = callbackQuery.id;
      const userId = callbackQuery.from?.id;
      const messageDate = callbackQuery.message?.date; // Unix timestamp in seconds from the original message
    
    // No age check for callbacks - buttons should remain functional
    // Users should be able to click buttons at any time
    logger.debug(`Processing Telegram callback without age restriction (message date: ${messageDate ? new Date(messageDate * 1000).toISOString() : 'unknown'})`);
    
    // Parse the callback data
    let action;
    try {
      action = JSON.parse(callbackQuery.data);
    } catch (error) {
      // Check if it's a legacy string command format (like "/process taskId")
      if (typeof callbackQuery.data === 'string' && callbackQuery.data.startsWith('/')) {
        const parts = callbackQuery.data.split(' ');
        const command = parts[0];
        const args = parts.slice(1).join(' ');

        // Convert legacy format to action object
        if (command === '/process' && args) {
          action = { action: 'process_task', taskId: args };
        } else if (command === '/goals') {
          // Handle /goals command - execute as a Telegram command
          action = { action: 'execute_command', command: '/goals', args: args };
          logger.info(`[CALLBACK] Parsed /goals command callback`);
        } else if (command === '/goalloop') {
          // Handle /goalloop command - execute as a Telegram command
          action = { action: 'execute_command', command: '/goalloop', args: args };
          logger.info(`[CALLBACK] Parsed /goalloop command callback with args: ${args || 'none'}`);
        } else {
          logger.error('Failed to parse Telegram callback data:', callbackQuery.data);
          return;
        }
      } else if (typeof callbackQuery.data === 'string' && callbackQuery.data.includes(':')) {
        // Handle simple string formats like "output:taskId", "retry:taskId"
        const [prefix, value] = callbackQuery.data.split(':', 2);

        if (prefix === 'output') {
          action = { action: 'view_output', taskId: value };
          logger.info(`[CALLBACK] Parsed simple format: output -> view_output for task ${value}`);
        } else if (prefix === 'retry') {
          action = { action: 'retry_task', taskId: value };
          logger.info(`[CALLBACK] Parsed simple format: retry -> retry_task for task ${value}`);
        } else if (prefix === 'cancel') {
          action = { action: 'cancel_task', taskId: value };
          logger.info(`[CALLBACK] Parsed simple format: cancel -> cancel_task for task ${value}`);
        } else if (prefix === 'chatui') {
          action = { action: 'set_chatui', mode: value };
          logger.info(`[CALLBACK] Parsed simple format: chatui -> set_chatui mode ${value}`);
        } else if (prefix === 'process') {
          action = { action: 'process_task', taskId: value };
          logger.info(`[CALLBACK] Parsed simple format: process -> process_task for task ${value}`);
        } else {
          logger.error('Unknown simple format callback prefix:', prefix);
          return;
        }
      } else {
        logger.error('Failed to parse Telegram callback data:', callbackQuery.data);
        return;
      }
    }
    
    // Map shortened keys to full keys for Telegram (to fit within 64-byte limit)
    // a = action, c = command, p = promptId, ct = create_task, t = taskId, pid = planId, s = startTime, e = endTime
    const normalizedAction = {
      action: action.a || action.action,
      command: action.c || action.command,
      promptId: action.p || action.promptId,
      taskId: action.t || action.taskId,
      pid: action.pid || action.p,  // For plan ID and backward compatibility with pending prompts
      s: action.s,  // Start time for history filtering
      e: action.e   // End time for history filtering
    };

    // Map shortened action names
    if (normalizedAction.action === 'ct') {
      normalizedAction.action = 'create_task';
    } else if (normalizedAction.action === 'cancel') {
      normalizedAction.action = 'cancel_task';
    } else if (normalizedAction.action === 'retry_img') {
      // Keep retry_img as is
      normalizedAction.action = 'retry_img';
      // Also preserve file_id, message_id, and caption
      normalizedAction.file_id = action.f || action.file_id;
      normalizedAction.message_id = action.m || action.message_id;
      normalizedAction.caption = action.cap || action.caption;
    } else if (normalizedAction.action === 'delete_plan') {
      // Ensure pid is properly set for delete_plan
      normalizedAction.pid = action.pid || action.planId;
    }
    
    // Map shortened commands
    if (normalizedAction.command === 'a') {
      normalizedAction.command = 'add';
    } else if (normalizedAction.command === 'c') {
      normalizedAction.command = 'continue';
    } else if (normalizedAction.command === 's') {
      normalizedAction.command = 'shell';
    }
    
    // Log callback info concisely
    logger.info(`🔘 Telegram callback:`, {
      chatId,
      userId,
      action: normalizedAction.action,
      command: normalizedAction.command || 'none'
    });
    
    // Get or initialize Telegram notifier
    if (!this.telegramNotifier) {
      const { TelegramNotifier } = await import('./telegram-notifier.js');
      this.telegramNotifier = new TelegramNotifier();
    }
    
    // Initialize workspace manager if not already done
    if (!this.workspaceManager) {
      const { WorkspaceManager } = await import('./workspace-manager.js');
      this.workspaceManager = new WorkspaceManager();
      await this.workspaceManager.initialize();
    }
    
    // Check authorization for callbacks too (pass request for gateway headers)
    const isAuthorized = await this.checkTelegramAuthorization(chatId, userId, request);
    if (!isAuthorized) {
      logger.warn(`Unauthorized Telegram callback from chat ${chatId}, user ${userId}`);
      await this.answerTelegramCallbackQuery(chatId, callbackId, {
        text: '🔒 Access denied. Please connect to a workspace first.',
        show_alert: true
      });
      return;
    }

    // Answer the callback query to remove loading state
    await this.answerTelegramCallbackQuery(chatId, callbackId);

    // Handle plan continue callback — creates a /continue task to implement the drafted plan
    if (normalizedAction.action === 'plc') {
      const fullChatId = `telegram:${chatId}`;
      const originalTaskId = normalizedAction.taskId || null;
      const selectedWorkdirName = this.chatSettings.getWorkdir(fullChatId);
      const availableWorkdirs = await this.getAvailableWorkdirs(fullChatId);
      const selectedWorkdirPath = selectedWorkdirName ? availableWorkdirs[selectedWorkdirName] : null;

      if (!selectedWorkdirPath) {
        await this.telegramNotifier.sendMessage(chatId, '⚠️ No workspace connected. Use /connect first.', { parse_mode: 'Markdown' });
        return;
      }

      const taskName = `plan-implement-${Date.now()}`;
      const continuePrompt = 'implement the plan directly, do not ask for approval or review, just execute it';
      const task = this.taskMonitor.addTask(taskName, `-c ${continuePrompt}`, {
        cwd: selectedWorkdirPath,
        source: 'telegram_plan_continue',
        chatId: fullChatId,
        providerId: await this.getCurrentProviderId()
      });

      logger.info(`[PLAN-CONTINUE] Created continue task ${task.id} for plan task ${originalTaskId || 'unknown'} in ${selectedWorkdirPath}`);
      await this.telegramNotifier.sendMessage(chatId, `🚀 *Implementing plan...*\nTask: \`${task.id.replace(/_/g, '\\_')}\``, { parse_mode: 'Markdown' });
      return;
    }

    // Handle chatui mode selection callback directly
    if (normalizedAction.action === 'set_chatui') {
      const mode = action.mode;
      if (mode && VALID_DISPLAY_MODES.includes(mode)) {
        const fullChatId = `telegram:${chatId}`;
        const displayModeManager = new DisplayModeManager(this.chatSettings);
        const { previousMode, newMode } = await displayModeManager.setDisplayMode(fullChatId, mode);

        let msg;
        if (previousMode === newMode) {
          msg = `ℹ️ Display mode already set to: *${newMode}*`;
        } else {
          msg = `✅ Display mode changed: *${previousMode}* → *${newMode}*`;
        }

        await this.telegramNotifier.sendMessage(chatId, msg, { parse_mode: 'Markdown' });
      }
      return;
    }

    // Process the action and get the result
    const result = await this.processCardAction(normalizedAction, {
      open_chat_id: `telegram:${chatId}`,
      open_message_id: messageId,
      user_id: userId  // Pass user ID for context
    });
    
    // Send response to user if there's an error or important message
    if (result && !result.success && result.message) {
      // Send error message to user with escaped markdown to prevent parse errors
      const escapedMessage = this.telegramNotifier.escapeMarkdownContent(result.message);
      await this.telegramNotifier.sendMessage(chatId,
        `❌ ${escapedMessage}`,
        { parse_mode: 'Markdown' }
      );
    } else if (result && result.message && result.message.includes('expired')) {
      // Handle expired prompts specially
      const escapedMessage = this.telegramNotifier.escapeMarkdownContent(result.message);
      await this.telegramNotifier.sendMessage(chatId,
        `⏰ ${escapedMessage}\n\nPlease send your command again.`,
        { parse_mode: 'Markdown' }
      );
    }
    // Note: Success messages are handled within processCardAction or by task notifications
    } catch (error) {
      logger.error(`🚨 CRITICAL: Uncaught error in processTelegramCallback`, {
        error: error.message,
        stack: error.stack,
        callbackId: callbackQuery?.id,
        chatId: callbackQuery?.message?.chat?.id,
        userId: callbackQuery?.from?.id,
        data: callbackQuery?.data
      });
      
      // Try to notify the user
      try {
        if (callbackQuery?.message?.chat?.id && this.telegramNotifier) {
          await this.telegramNotifier.sendMessage(callbackQuery.message.chat.id,
            `❌ An error occurred while processing your action.\n\n` +
            `Please try again or contact support.\n\n` +
            `Error: ${error.message?.substring(0, 100) || 'Unknown error'}`,
            { parse_mode: 'Markdown' }
          );
        }
      } catch (notifyError) {
        logger.error('Failed to notify user of callback error:', notifyError);
      }
    }
  }

  async processRepliedImage(repliedMessage, chatId) {
    // Check if the replied message contains a photo or document
    if (!repliedMessage || (!repliedMessage.photo && !repliedMessage.document)) {
      return null;
    }
    
    let fileId, fileType, fileName;
    
    if (repliedMessage.photo && repliedMessage.photo.length > 0) {
      // Handle regular photo
      const photo = repliedMessage.photo[repliedMessage.photo.length - 1]; // Get highest resolution
      fileId = photo.file_id;
      fileType = 'photo';
      fileName = null;
    } else if (repliedMessage.document) {
      // Handle document (including images sent as original quality and other supported formats)
      const MAX_FILE_SIZE = 20 * 1024 * 1024; // 20MB
      if (repliedMessage.document?.file_size > MAX_FILE_SIZE) {
        logger.info(`Ignoring oversized document: ${repliedMessage.document.file_size} bytes (${repliedMessage.document.file_name || 'unnamed'})`);
        return null;
      }
      const mimeType = repliedMessage.document.mime_type || 'unknown';
      fileName = repliedMessage.document.file_name || null;

      fileId = repliedMessage.document.file_id;
      fileType = 'document';
    }

    logger.info(`Processing ${fileType} from replied message in chat ${chatId}`);
    
    try {
      // Fetch the file info from Telegram
      const botToken = config.telegram?.botToken;
      if (!botToken) {
        logger.error('Telegram bot token not configured for replied image');
        return null;
      }
      
      const apiUrl = `https://api.telegram.org/bot${botToken}`;
      
      // Add timeout and better error handling for fetch
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 15000); // 15 second timeout
      
      let fileResponse;
      try {
        if (this.telegramAPI) {
          fileResponse = await this.telegramAPI.getFile(fileId);
        } else {
          fileResponse = await fetch(`${apiUrl}/getFile?file_id=${fileId}`, {
            signal: controller.signal,
            headers: {
              'Connection': 'close',
              'Cache-Control': 'no-cache'
            },
            keepalive: false
          });
          clearTimeout(timeout);
          fileResponse = await fileResponse.json();
        }
      } catch (fetchError) {
        if (timeout) clearTimeout(timeout);
        logger.error('Network error fetching replied image file info:', fetchError.message);
        return null;
      }
      
      const isOk = this.telegramAPI ? fileResponse.ok : fileResponse?.ok;
      if (!isOk) {
        const status = this.telegramAPI ? 'error' : fileResponse.status;
        logger.error(`Telegram API returned status ${status} for replied image`);
        return null;
      }
      
      const fileData = this.telegramAPI ? fileResponse : await fileResponse.json();

      // Handle both direct Telegram API response and gateway mode response
      const hasFileData = fileData && (fileData.ok || fileData.success) && (fileData.result || fileData.file_path);
      if (hasFileData) {
        const filePath = fileData.result?.file_path || fileData.file_path;
        const telegramUrl = `https://api.telegram.org/file/bot${botToken}/${filePath}`;
        
        // Upload to S3
        const { SecureUploader } = await import('./utils/secure-upload.js');
        const uploader = new SecureUploader();
        
        // Get workdir name for this chat (to use as S3 path prefix)
        const workdirName = this.chatSettings.getWorkdir(`telegram:${chatId}`);
        const workdirPath = workdirName || 'telegram-images';
        
        const s3Result = await uploader.uploadImageFromUrl(telegramUrl, {
          workdir: workdirPath,
          fileName: fileName,
          fileType: fileType,
          metadata: {
            'telegram-chat-id': chatId.toString(),
            'telegram-message-id': repliedMessage.message_id.toString(),
            'caption': (repliedMessage.caption || '').replace(/[\r\n]/g, ' ').replace(/[\x00-\x1F\x7F]/g, '').trim(),
            'from-reply': 'true'
          }
        });
        
        logger.info(`Uploaded replied image to S3: ${s3Result.url}`);
        return s3Result.url;
      }
    } catch (error) {
      logger.error('Error processing replied image:', error);
    }
    
    return null;
  }

  async processTelegramCommand(text, chatId, message = null) {
    try {
      // Find the first space to split command from args, preserving newlines in args
      const firstSpaceIndex = text.indexOf(' ');
      let command = firstSpaceIndex === -1 ? text.toLowerCase() : text.substring(0, firstSpaceIndex).toLowerCase();
      let args = firstSpaceIndex === -1 ? '' : text.substring(firstSpaceIndex + 1);

      // Log command info concisely
      logger.info(`📝 Processing command`, {
        command: command.substring(0, 20),
        argsLength: args.length,
        chatId
      });

      // Store chat ID with telegram prefix for disambiguation
      const fullChatId = `telegram:${chatId}`;

      // Get or initialize Telegram notifier
      if (!this.telegramNotifier) {
        logger.info('Initializing TelegramNotifier...');
        const { TelegramNotifier } = await import('./telegram-notifier.js');
        this.telegramNotifier = new TelegramNotifier();
        logger.info('TelegramNotifier initialized');
      }

      // Check if command starts with /$ (macro expansion)
      if (command.startsWith('/$')) {
        const macroName = command.substring(2); // Remove /$

        try {
          // Get workspace for this chat - use same lookup as handleMacrosCommand
          const { WorkspaceManager } = await import('./workspace-manager.js');
          const manager = new WorkspaceManager();
          await manager.initialize();

          let workspace = null;

          // First try: resolve via chatSettings workdir + path lookup (same as /macros listing)
          const workdirName = this.chatSettings.getWorkdir(fullChatId);
          if (workdirName) {
            const availableWorkdirs = await this.getAvailableWorkdirs(fullChatId);
            const workdirPath = availableWorkdirs[workdirName];
            if (workdirPath) {
              workspace = await manager.getWorkspaceByPath(workdirPath);
            }
          }

          // Second try: resolve via telegram_chats table
          if (!workspace) {
            workspace = await manager.getWorkspaceForTelegramChat(String(chatId));
          }

          // Third try: gateway fallback
          if (!workspace && config.gateway.enabled) {
            workspace = await manager.ensureGatewayWorkspace();
            logger.debug('Gateway mode: Using gateway workspace for macro expansion');
          }
          if (workspace) {
            // Try to get macro from workspace metadata
            const metaKey = `macro-${macroName}`;
            const macroCommand = await manager.getWorkspaceMeta(workspace.id, metaKey);

            if (macroCommand) {
              logger.info(`Expanding macro /$${macroName} to: ${macroCommand}`);

              // Parse the expanded command
              // Check if there's additional content after the macro
              let expandedText;
              if (args) {
                // Check if we need a space between macro and args
                // If macro ends with alphanumeric and args starts with alphanumeric, add space
                const macroEndsWithAlphaNum = /[a-zA-Z0-9]$/.test(macroCommand);
                const argsStartsWithAlphaNum = /^[a-zA-Z0-9]/.test(args);

                if (macroEndsWithAlphaNum && argsStartsWithAlphaNum) {
                  // Add space to separate words
                  expandedText = `${macroCommand} ${args}`;
                } else {
                  // Concatenate directly (preserves user's spacing)
                  expandedText = `${macroCommand}${args}`;
                }
              } else {
                expandedText = macroCommand;
              }

              const expandedFirstSpace = expandedText.indexOf(' ');
              command = expandedFirstSpace === -1 ? expandedText.toLowerCase() : expandedText.substring(0, expandedFirstSpace).toLowerCase();
              args = expandedFirstSpace === -1 ? '' : expandedText.substring(expandedFirstSpace + 1);

              // Send feedback to user
              await this.telegramNotifier.sendMessage(chatId,
                `🔄 *Macro Expanded*\n\`$${macroName}\` → \`${macroCommand.substring(0, 50)}${macroCommand.length > 50 ? '...' : ''}\``,
                { parse_mode: 'Markdown' }
              );
            } else {
              // Macro not found
              await this.telegramNotifier.sendMessage(chatId,
                `❌ *Macro not found*: \`$${macroName}\`\n\n` +
                `Use \`/macro $${macroName} <command>\` to create it`,
                { parse_mode: 'Markdown' }
              );
              await manager.close();
              return;
            }
          } else {
            await this.telegramNotifier.sendMessage(chatId,
              `❌ *No workspace connected*\n\n` +
              `Macros require a workspace connection.\n` +
              `Connect with: \`/connect <token>\``,
              { parse_mode: 'Markdown' }
            );
            await manager.close();
            return;
          }

          await manager.close();
        } catch (error) {
          logger.error(`Failed to expand macro: ${error.message}`);
          await this.telegramNotifier.sendMessage(chatId,
            `❌ Failed to expand macro: ${error.message}`,
            { parse_mode: 'Markdown' }
          );
          return;
        }
      }

      switch (command) {
        case '/start':
        case '/help':
          logger.info(`Handling /help command for chat ${chatId}`);
          const workdirName = this.chatSettings.getWorkdir(fullChatId);
          await this.telegramNotifier.sendHelpMessage(chatId, workdirName);
          logger.info(`Help message sent to chat ${chatId}`);
          break;
          
        case '/status':
          logger.info(`Handling /status command for chat ${chatId}`);
          await this.showTelegramStatus(chatId);
          logger.info(`Status sent to chat ${chatId}`);
          break;
          
        case '/process':
          logger.info(`Handling /process command for chat ${chatId} with args: ${args}`);
          await this.showTaskProgress(chatId, args);
          break;
          
        case '/rank':
          logger.info(`Handling /rank command for chat ${chatId}`);
          try {
            // Initialize usage reporter if not exists
            if (!this.usageReporter) {
              logger.debug('Initializing UsageReporter for /rank command');
              const { UsageReporter } = await import('./usage-reporter.js');
              this.usageReporter = new UsageReporter();
            }
            
            // Generate and send daily usage report (force=true for manual command)
            const report = await this.usageReporter.generateDailyReport(true);
            if (report) {
              await this.telegramNotifier.sendCustomMessage(
                `📊 ${report.title}`,
                report.content,
                chatId
              );
              logger.info(`Daily usage report sent to chat ${chatId}`);
            } else {
              await this.telegramNotifier.sendMessage(chatId,
                '❌ Failed to generate usage report. Please try again later.');
            }
          } catch (error) {
            // Log full error details
            logger.error(`Error handling /rank command for chat ${chatId}:`, {
              message: error.message,
              stack: error.stack,
              code: error.code,
              name: error.name
            });
            await this.telegramNotifier.sendMessage(chatId, 
              '❌ Error generating usage report. Please try again later.');
          }
          break;

        case '/usage':
          logger.info(`Handling /usage command for chat ${chatId} with args: ${args}`);

          // Check if this is a reset command
          const resetArg = args.trim().toLowerCase();
          if (resetArg === 'reset all' || resetArg === 'reset opus' || resetArg === 'reset') {
            try {
              const { resetClaudeUsageCache } = await import('./claude-usage.js');

              // Determine what to reset
              let resetType = 'all'; // Default to all if just "reset"
              if (resetArg === 'reset opus') {
                resetType = 'opus';
              }

              await resetClaudeUsageCache(resetType);

              const resetMessage = resetType === 'opus'
                ? '✓ Opus usage cache reset successfully'
                : '✓ All usage cache (session + opus) reset successfully';

              await this.telegramNotifier.sendMessage(chatId, resetMessage);
              logger.info(`Usage cache reset (${resetType}) for chat ${chatId}`);
            } catch (error) {
              logger.error(`Error resetting usage cache for chat ${chatId}:`, {
                message: error.message,
                stack: error.stack
              });
              await this.telegramNotifier.sendMessage(chatId,
                `❌ Error resetting usage cache: ${error.message}`);
            }
            break;
          }

          // Send immediate feedback message for normal usage query
          let loadingMessageId = null;
          try {
            const loadingResult = await this.telegramNotifier.sendMessage(chatId,
              '⏳ Fetching usage data, this will take a moment...');
            if (loadingResult && loadingResult.result && loadingResult.result.message_id) {
              loadingMessageId = loadingResult.result.message_id;
            }
          } catch (err) {
            logger.warn(`Failed to send loading message: ${err.message}`);
          }

          try {
            const { getClaudeUsage, formatUsageMarkdown } = await import('./claude-usage.js');

            // Get usage data with retry logic
            let usage = null;
            let retries = 2;
            while (retries > 0 && !usage) {
              try {
                usage = await getClaudeUsage();
                if (!usage || (usage.currentSession === null && usage.weekOpus === null)) {
                  throw new Error('Empty usage data returned');
                }
                break;
              } catch (err) {
                retries--;
                if (retries > 0) {
                  logger.warn(`Failed to get usage data, retrying... (${retries} attempts left)`);
                  await new Promise(resolve => setTimeout(resolve, 1000));
                } else {
                  throw err;
                }
              }
            }

            // Format usage data - MUST await this async function
            const message = await formatUsageMarkdown(usage);

            if (!message || message.trim().length === 0) {
              throw new Error('Empty formatted message');
            }

            // Delete loading message before sending result
            if (loadingMessageId) {
              try {
                await this.telegramNotifier.deleteMessage(chatId, loadingMessageId);
              } catch (err) {
                logger.warn(`Failed to delete loading message: ${err.message}`);
              }
            }

            await this.telegramNotifier.sendMessage(chatId, message, {
              parse_mode: 'Markdown'
            });
            logger.info(`Usage information sent to chat ${chatId}`);
          } catch (error) {
            logger.error(`Error handling /usage command for chat ${chatId}:`, {
              message: error.message,
              stack: error.stack
            });

            // Delete loading message before sending error
            if (loadingMessageId) {
              try {
                await this.telegramNotifier.deleteMessage(chatId, loadingMessageId);
              } catch (err) {
                logger.warn(`Failed to delete loading message: ${err.message}`);
              }
            }

            await this.telegramNotifier.sendMessage(chatId,
              '❌ Error getting Claude usage information. Please try again later.\n\n' +
              `Error: ${error.message}`);
          }
          break;

        case '/history':
          logger.info(`Handling /history command for chat ${chatId}`);
          try {
            // Import the history viewer module
            const { ClaudeHistoryViewer } = await import('./claude-history-viewer.js');
            const viewer = new ClaudeHistoryViewer();

            // Send "generating" message
            const generatingMsg = await this.telegramNotifier.sendMessage(chatId,
              'Generating session history...'
            );

            // Get current project path
            const workdirName = this.chatSettings.getWorkdir(fullChatId);
            const workdirs = await this.getAvailableWorkdirs(fullChatId);
            const projectPath = workdirs[workdirName] || workdirName;

            // Generate HTML for the latest session
            const html = await viewer.generateLatestSessionHTML(projectPath);

            // Get session metadata for caption
            const sessionFile = await viewer.findLatestSession(projectPath);
            const messages = sessionFile ? await viewer.parseSession(sessionFile) : [];

            // Calculate total tokens
            let totalTokens = 0;
            messages.forEach(msg => {
              if (msg.usage) {
                totalTokens += (msg.usage.input_tokens || 0) + (msg.usage.output_tokens || 0);
              }
            });

            // Get session date
            const sessionDate = messages.length > 0
              ? new Date(messages[0].timestamp).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'short',
                  day: 'numeric'
                })
              : new Date().toLocaleDateString();

            // Save HTML to temp file
            const tmpDir = '/tmp';
            const timestamp = Date.now();
            const htmlFile = path.join(tmpDir, `claude-history-${timestamp}.html`);
            await fs.promises.writeFile(htmlFile, html, 'utf-8');

            logger.info(`History HTML saved to: ${htmlFile}`);

            // Build caption with metadata and footer
            const projectName = path.basename(projectPath);
            const workdir = projectName;
            let caption = `📜 *SESSION HISTORY*\n\n` +
              `*Date:* ${sessionDate}\n` +
              `*Project:* ${projectName}\n` +
              `*Messages:* ${messages.length}\n` +
              `*Tokens:* ${totalTokens.toLocaleString()}\n\n` +
              `Download and open in browser to view.`;

            // Add footer using telegram notifier's formatFooter method
            caption += await this.telegramNotifier.formatFooter(workdir);

            // Create file stream for upload
            const fileStream = fs.createReadStream(htmlFile);

            // Generate filename with datetime and project
            const now = new Date();
            const dateTimeStr = now.toISOString().slice(0, 19).replace(/[T:]/g, '-');
            const filename = `${projectName}-${dateTimeStr}.html`;

            // Send HTML file as document with Markdown formatting
            await this.telegramNotifier.sendDocument(chatId, fileStream, {
              caption: caption,
              filename: filename,
              parse_mode: 'Markdown'
            });

            // Clean up temp file after sending
            await fs.promises.unlink(htmlFile);

            // Delete "generating" message
            if (generatingMsg && generatingMsg.result?.message_id) {
              await this.telegramNotifier.deleteMessage(chatId, generatingMsg.result.message_id);
            }

            logger.info(`History HTML sent to chat ${chatId}`);
          } catch (error) {
            logger.error(`Error handling /history command for chat ${chatId}:`, {
              message: error.message,
              stack: error.stack
            });
            await this.telegramNotifier.sendMessage(chatId,
              'Error generating session history. Please try again later.\n\n' +
              `Error: ${error.message}`);
          }
          break;

        case '/daystat':
          logger.info(`Handling /daystat command for chat ${chatId} with args: ${args}`);
          try {
            const { getStatsDB } = await import('./stats-db.js');
            const statsDB = getStatsDB();

            // Check for --all flag
            const showAll = args && args.includes('--all');

            // Check for --from date parameter
            let fromDate = null;
            let hoursToFetch = 24;
            if (args) {
              const fromMatch = args.match(/--from[=\s]+(\d{4}-\d{2}-\d{2})/);
              if (fromMatch) {
                fromDate = new Date(fromMatch[1]);
                const now = new Date();
                const diffMs = now - fromDate;
                hoursToFetch = Math.ceil(diffMs / (1000 * 60 * 60)); // Convert to hours
                if (hoursToFetch > 24 * 30) { // Cap at 30 days
                  hoursToFetch = 24 * 30;
                }
              }
            }

            // Get current workspace if not showing all
            let currentWorkspace = null;
            if (!showAll) {
              const workdirName = this.chatSettings.getWorkdir(fullChatId);
              const workdirs = await this.getAvailableWorkdirs(fullChatId);
              currentWorkspace = workdirs[workdirName] || workdirName;
            }

            // Get hourly stats
            const hourlyStats = statsDB.getHourlyStats(hoursToFetch);

            if (!hourlyStats || hourlyStats.length === 0) {
              const timeRange = fromDate ? `since ${fromDate.toISOString().split('T')[0]}` : 'for the last 24 hours';
              await this.telegramNotifier.sendMessage(chatId,
                `[STATS] No task statistics available ${timeRange}`);
              break;
            }

            // Filter stats by workspace if not showing all
            let filteredStats = hourlyStats;
            if (currentWorkspace && !showAll) {
              filteredStats = hourlyStats.filter(stat =>
                stat.workspace === currentWorkspace ||
                stat.workspace === path.basename(currentWorkspace)
              );
            }

            if (filteredStats.length === 0) {
              const timeRange = fromDate ? `since ${fromDate.toISOString().split('T')[0]}` : 'in the last 24 hours';
              await this.telegramNotifier.sendMessage(chatId,
                `[STATS] No task statistics for workspace "${path.basename(currentWorkspace)}" ${timeRange}`);
              break;
            }

            // Group stats by hour
            const statsByHour = {};
            let totalDurationMs = 0;

            filteredStats.forEach(stat => {
              const hour = stat.hour;
              if (!statsByHour[hour]) {
                statsByHour[hour] = {
                  tasks: 0,
                  completed: 0,
                  cancelled: 0,
                  errors: 0,
                  cost: 0,
                  tokens: 0,
                  duration_ms: 0,
                  workspaces: new Set()
                };
              }
              statsByHour[hour].tasks += stat.task_count;
              statsByHour[hour].completed += stat.completed_count;
              statsByHour[hour].cancelled += stat.cancelled_count;
              statsByHour[hour].errors += stat.error_count;
              statsByHour[hour].cost += stat.total_cost || 0;
              statsByHour[hour].tokens += stat.total_tokens || 0;
              statsByHour[hour].duration_ms += stat.total_duration_ms || 0;
              if (stat.workspace) {
                statsByHour[hour].workspaces.add(stat.workspace);
              }
            });

            // Format the message (compact)
            const timeRangeLabel = fromDate
              ? `from ${fromDate.toISOString().split('T')[0]}`
              : '(24h)';
            let message = `[STATS] *${showAll ? 'All Workspaces' : path.basename(currentWorkspace || 'Unknown')}* ${timeRangeLabel}\n\n`;
            message += '```\n';

            // Use date format for longer periods
            const useDateFormat = hoursToFetch > 48;
            const headerLabel = useDateFormat ? 'Date' : 'Hr';
            message += `${headerLabel.padEnd(10)} | Tasks | Time   | Cost  | Status\n`;
            message += '-----------+-------+--------+-------+-----------\n';

            // Generate hours to show
            const now = new Date();
            const hoursToShow = [];
            for (let i = 0; i < hoursToFetch; i++) {
              const hourDate = new Date(now.getTime() - (i * 60 * 60 * 1000));
              hourDate.setMinutes(0, 0, 0);
              // Format to match database: 'YYYY-MM-DD HH:00'
              const year = hourDate.getFullYear();
              const month = String(hourDate.getMonth() + 1).padStart(2, '0');
              const day = String(hourDate.getDate()).padStart(2, '0');
              const hour = String(hourDate.getHours()).padStart(2, '0');
              hoursToShow.push(`${year}-${month}-${day} ${hour}:00`);
            }

            const hours = hoursToShow;

            let totalTasks = 0;
            let totalCompleted = 0;
            let totalCancelled = 0;
            let totalErrors = 0;
            let totalCost = 0;
            let totalTokens = 0;
            let totalMinutes = 0;

            hours.forEach(hour => {
              const stats = statsByHour[hour] || {
                tasks: 0,
                completed: 0,
                cancelled: 0,
                errors: 0,
                cost: 0,
                tokens: 0,
                duration_ms: 0
              };
              totalTasks += stats.tasks;
              totalCompleted += stats.completed;
              totalCancelled += stats.cancelled;
              totalErrors += stats.errors;
              totalCost += stats.cost;
              totalTokens += stats.tokens;

              // Calculate minutes used (duration in ms / 60000)
              const minutesUsed = Math.round(stats.duration_ms / 60000);
              totalMinutes += minutesUsed;

              // Format time label based on range
              let timeLabel;
              if (useDateFormat) {
                // Show date for longer periods (YYYY-MM-DD)
                timeLabel = hour.split(' ')[0]; // Get date part
              } else {
                // Show hour for 24-48h periods
                const hourTime = new Date(hour).getHours().toString().padStart(2, '0');
                timeLabel = hourTime;
              }

              // Format status with ASCII
              let status = '';
              if (stats.completed > 0) status += `OK:${stats.completed}`;
              if (stats.cancelled > 0) status += ` X:${stats.cancelled}`;
              if (stats.errors > 0) status += ` !:${stats.errors}`;
              status = status.trim() || '-';

              // Format row
              const tasksStr = stats.tasks.toString().padEnd(5);

              // Format time: use decimal hours if >= 60 minutes
              let timeStr = '-';
              if (minutesUsed > 0) {
                if (minutesUsed >= 60) {
                  const hours = (minutesUsed / 60).toFixed(1);
                  timeStr = `${hours}h`;
                } else {
                  timeStr = `${minutesUsed}m`;
                }
              }
              const timeFormatted = timeStr.padEnd(6);
              // Simplify cost display - remove leading zeros
              let costStr = '-';
              if (stats.cost > 0) {
                if (stats.cost < 1) {
                  costStr = stats.cost.toFixed(2).substring(1); // Remove leading 0
                } else {
                  costStr = stats.cost.toFixed(2);
                }
              }
              const costFormatted = costStr.padEnd(5);

              const timeLabelPadded = timeLabel.padEnd(10);
              message += `${timeLabelPadded} | ${tasksStr} | ${timeFormatted} | ${costFormatted} | ${status}\n`;
            });

            message += '```\n';

            // Calculate time usage percentage
            const totalPossibleHours = fromDate ? Math.ceil(hoursToFetch / 24) * 24 : 24;
            const totalPossibleMinutes = totalPossibleHours * 60;
            const timeUsagePercent = Math.round((totalMinutes / totalPossibleMinutes) * 100);

            // Add summary
            message += '\n*[SUMMARY]*\n';
            message += `[>] Tasks: ${totalTasks} (OK: ${totalCompleted}`;
            if (totalCancelled > 0) message += `, X: ${totalCancelled}`;
            if (totalErrors > 0) message += `, ERR: ${totalErrors}`;
            message += `)\n`;

            // Format total time
            const totalHours = Math.floor(totalMinutes / 60);
            const remainingMinutes = totalMinutes % 60;
            let timeStr = '';
            if (totalHours > 0) {
              timeStr = `${totalHours}h ${remainingMinutes}m`;
            } else {
              timeStr = `${remainingMinutes}m`;
            }

            const timeRangeText = fromDate ? `${Math.ceil(hoursToFetch / 24)}d` : '24h';
            message += `[>] Time Used: ${timeStr} (${timeUsagePercent}% of ${timeRangeText})\n`;
            message += `[>] Success Rate: ${totalTasks > 0 ? Math.round(totalCompleted/totalTasks*100) : 0}%\n`;
            // Simplify total cost display
            let totalCostStr;
            if (totalCost < 1) {
              totalCostStr = totalCost.toFixed(2).substring(1); // Remove leading 0
            } else {
              totalCostStr = totalCost.toFixed(2);
            }
            message += `[>] Total Cost: ${totalCostStr}\n`;
            message += `[>] Tokens: ${totalTokens.toLocaleString()}\n`;

            if (!showAll && currentWorkspace) {
              message += `\n_Use /daystat --all to see all workspaces_`;
            }
            if (fromDate) {
              message += `\n_Showing stats from ${fromDate.toISOString().split('T')[0]}_`;
            }

            await this.telegramNotifier.sendMessage(chatId, message, { parse_mode: 'Markdown' });
            logger.info(`Day stats sent to chat ${chatId}`);
          } catch (error) {
            logger.error(`Error handling /daystat command:`, error);
            await this.telegramNotifier.sendMessage(chatId,
              '[ERROR] Failed to generate day statistics. Please try again later.');
          }
          break;

        case '/weekstat':
          logger.info(`Handling /weekstat command for chat ${chatId} with args: ${args}`);
          try {
            const { getStatsDB } = await import('./stats-db.js');
            const statsDB = getStatsDB();

            // Check for --all flag
            const showAll = args && args.includes('--all');

            // Get current workspace if not showing all
            let currentWorkspace = null;
            if (!showAll) {
              const workdirName = this.chatSettings.getWorkdir(fullChatId);
              const workdirs = await this.getAvailableWorkdirs(fullChatId);
              currentWorkspace = workdirs[workdirName] || workdirName;
            }

            // Get daily stats for last 7 days
            const dailyStats = statsDB.getDailyStats(7);

            if (!dailyStats || dailyStats.length === 0) {
              await this.telegramNotifier.sendMessage(chatId,
                '[STATS] No task statistics available for the last 7 days');
              break;
            }

            // Filter stats by workspace if not showing all
            let filteredStats = dailyStats;
            if (currentWorkspace && !showAll) {
              filteredStats = dailyStats.filter(stat =>
                stat.workspace === currentWorkspace ||
                stat.workspace === path.basename(currentWorkspace)
              );
            }

            if (filteredStats.length === 0) {
              await this.telegramNotifier.sendMessage(chatId,
                `[STATS] No task statistics for workspace "${path.basename(currentWorkspace)}" in the last 7 days`);
              break;
            }

            // Group stats by day
            const statsByDay = {};
            filteredStats.forEach(stat => {
              const day = stat.day;
              if (!statsByDay[day]) {
                statsByDay[day] = {
                  tasks: 0,
                  completed: 0,
                  cancelled: 0,
                  errors: 0,
                  cost: 0,
                  tokens: 0,
                  duration_ms: 0,
                  avgDuration: [],
                  workspaces: new Set()
                };
              }
              statsByDay[day].tasks += stat.task_count;
              statsByDay[day].completed += stat.completed_count;
              statsByDay[day].cancelled += stat.cancelled_count;
              statsByDay[day].errors += stat.error_count;
              statsByDay[day].cost += stat.total_cost || 0;
              statsByDay[day].tokens += stat.total_tokens || 0;
              statsByDay[day].duration_ms += stat.total_duration_ms || 0;
              if (stat.avg_duration_ms) {
                statsByDay[day].avgDuration.push(stat.avg_duration_ms);
              }
              if (stat.workspace) {
                statsByDay[day].workspaces.add(stat.workspace);
              }
            });

            // Format the message (compact)
            let message = `[STATS] *${showAll ? 'All Workspaces' : path.basename(currentWorkspace || 'Unknown')}* (7 days)\n\n`;
            message += '```\n';
            message += 'Date  | Tasks | Time   | Cost  | Status\n';
            message += '------+-------+--------+-------+-----------\n';

            // Generate all 7 days (including empty ones)
            // Format must match the database format: 'YYYY-MM-DD'
            const now = new Date();
            const daysToShow = [];
            for (let i = 0; i < 7; i++) {
              const dayDate = new Date(now.getTime() - (i * 24 * 60 * 60 * 1000));
              dayDate.setHours(0, 0, 0, 0);
              // Format to match database: 'YYYY-MM-DD'
              const year = dayDate.getFullYear();
              const month = String(dayDate.getMonth() + 1).padStart(2, '0');
              const day = String(dayDate.getDate()).padStart(2, '0');
              daysToShow.push(`${year}-${month}-${day}`);
            }

            const days = daysToShow;

            let totalTasks = 0;
            let totalCompleted = 0;
            let totalCancelled = 0;
            let totalErrors = 0;
            let totalCost = 0;
            let totalTokens = 0;
            let totalMinutes = 0;

            days.forEach(day => {
              const stats = statsByDay[day] || {
                tasks: 0,
                completed: 0,
                cancelled: 0,
                errors: 0,
                cost: 0,
                tokens: 0,
                duration_ms: 0,
                avgDuration: []
              };
              totalTasks += stats.tasks;
              totalCompleted += stats.completed;
              totalCancelled += stats.cancelled;
              totalErrors += stats.errors;
              totalCost += stats.cost;
              totalTokens += stats.tokens;

              // Calculate minutes used (duration in ms / 60000)
              const minutesUsed = Math.round(stats.duration_ms / 60000);
              totalMinutes += minutesUsed;

              const dayDate = new Date(day);
              const month = (dayDate.getMonth() + 1).toString().padStart(2, '0');
              const date = dayDate.getDate().toString().padStart(2, '0');
              const dayStr = `${month}/${date}`;

              // Format status with ASCII
              let status = '';
              if (stats.completed > 0) status += `OK:${stats.completed}`;
              if (stats.cancelled > 0) status += ` X:${stats.cancelled}`;
              if (stats.errors > 0) status += ` !:${stats.errors}`;
              status = status.trim() || '-';

              // Format row
              const tasksStr = stats.tasks.toString().padEnd(5);

              // Format time: use decimal hours if >= 60 minutes
              let timeStr = '-';
              if (minutesUsed > 0) {
                if (minutesUsed >= 60) {
                  const hours = (minutesUsed / 60).toFixed(1);
                  timeStr = `${hours}h`;
                } else {
                  timeStr = `${minutesUsed}m`;
                }
              }
              const timeFormatted = timeStr.padEnd(6);

              // Simplify cost display - remove leading zeros
              let costStr = '-';
              if (stats.cost > 0) {
                if (stats.cost < 1) {
                  costStr = stats.cost.toFixed(2).substring(1); // Remove leading 0
                } else {
                  costStr = stats.cost.toFixed(2);
                }
              }
              const costFormatted = costStr.padEnd(5);

              message += `${dayStr} | ${tasksStr} | ${timeFormatted} | ${costFormatted} | ${status}\n`;
            });

            message += '```\n';

            // Calculate time usage percentage (of 7 days)
            const totalPossibleMinutes = 7 * 24 * 60; // 10080 minutes in 7 days
            const timeUsagePercent = Math.round((totalMinutes / totalPossibleMinutes) * 100);

            // Add summary
            message += '\n*[SUMMARY]*\n';
            message += `[>] Tasks: ${totalTasks} (OK: ${totalCompleted}`;
            if (totalCancelled > 0) message += `, X: ${totalCancelled}`;
            if (totalErrors > 0) message += `, ERR: ${totalErrors}`;
            message += `)\n`;

            // Format total time
            const totalHours = Math.floor(totalMinutes / 60);
            const remainingMinutes = totalMinutes % 60;
            let timeStr = '';
            if (totalHours > 0) {
              timeStr = `${totalHours}h ${remainingMinutes}m`;
            } else {
              timeStr = `${remainingMinutes}m`;
            }

            message += `[>] Time Used: ${timeStr} (${timeUsagePercent}% of week)\n`;
            message += `[>] Success Rate: ${totalTasks > 0 ? Math.round(totalCompleted/totalTasks*100) : 0}%\n`;
            // Simplify total cost display
            let totalCostStr;
            if (totalCost < 1) {
              totalCostStr = totalCost.toFixed(2).substring(1); // Remove leading 0
            } else {
              totalCostStr = totalCost.toFixed(2);
            }
            message += `[>] Total Cost: ${totalCostStr}\n`;
            message += `[>] Tokens: ${totalTokens.toLocaleString()}\n`;
            // Simplify avg/day cost display
            const avgCost = totalCost / 7;
            let avgCostStr;
            if (avgCost < 1) {
              avgCostStr = avgCost.toFixed(2).substring(1); // Remove leading 0
            } else {
              avgCostStr = avgCost.toFixed(2);
            }
            message += `[>] Avg/Day: ${Math.round(totalTasks / 7)} tasks, ${avgCostStr}\n`;

            if (!showAll && currentWorkspace) {
              message += `\n_Use /weekstat --all to see all workspaces_`;
            }

            await this.telegramNotifier.sendMessage(chatId, message, { parse_mode: 'Markdown' });
            logger.info(`Week stats sent to chat ${chatId}`);
          } catch (error) {
            logger.error(`Error handling /weekstat command:`, error);
            await this.telegramNotifier.sendMessage(chatId,
              '[ERROR] Failed to generate week statistics. Please try again later.');
          }
          break;

        case '/monthstat':
          logger.info(`Handling /monthstat command for chat ${chatId} with args: ${args}`);
          try {
            const { getStatsDB } = await import('./stats-db.js');
            const statsDB = getStatsDB();

            // Check for --all flag
            const showAll = args && args.includes('--all');

            // Get current workspace if not showing all
            let currentWorkspace = null;
            if (!showAll) {
              const workdirName = this.chatSettings.getWorkdir(fullChatId);
              const workdirs = await this.getAvailableWorkdirs(fullChatId);
              currentWorkspace = workdirs[workdirName] || workdirName;
            }

            // Get daily stats for last 30 days
            const dailyStats = statsDB.getDailyStats(30);

            if (!dailyStats || dailyStats.length === 0) {
              await this.telegramNotifier.sendMessage(chatId,
                '[STATS] No task statistics available for the last 30 days');
              break;
            }

            // Filter stats by workspace if not showing all
            let filteredStats = dailyStats;
            if (currentWorkspace && !showAll) {
              filteredStats = dailyStats.filter(stat =>
                stat.workspace === currentWorkspace ||
                stat.workspace === path.basename(currentWorkspace)
              );
            }

            if (filteredStats.length === 0) {
              await this.telegramNotifier.sendMessage(chatId,
                `[STATS] No task statistics for workspace "${path.basename(currentWorkspace)}" in the last 30 days`);
              break;
            }

            // Group stats by day
            const statsByDay = {};
            filteredStats.forEach(stat => {
              const day = stat.day;
              if (!statsByDay[day]) {
                statsByDay[day] = {
                  tasks: 0,
                  completed: 0,
                  cancelled: 0,
                  errors: 0,
                  cost: 0,
                  tokens: 0,
                  duration_ms: 0,
                  avgDuration: [],
                  workspaces: new Set()
                };
              }
              statsByDay[day].tasks += stat.task_count;
              statsByDay[day].completed += stat.completed_count;
              statsByDay[day].cancelled += stat.cancelled_count;
              statsByDay[day].errors += stat.error_count;
              statsByDay[day].cost += stat.total_cost || 0;
              statsByDay[day].tokens += stat.total_tokens || 0;
              statsByDay[day].duration_ms += stat.total_duration_ms || 0;
              if (stat.avg_duration_ms) {
                statsByDay[day].avgDuration.push(stat.avg_duration_ms);
              }
              if (stat.workspace) {
                statsByDay[day].workspaces.add(stat.workspace);
              }
            });

            // Format the message (compact)
            let message = `[STATS] *${showAll ? 'All Workspaces' : path.basename(currentWorkspace || 'Unknown')}* (30 days)\n\n`;
            message += '```\n';
            message += 'Date  | Tasks | Time   | Cost  | Status\n';
            message += '------+-------+--------+-------+-----------\n';

            // Generate all 30 days (including empty ones)
            // Format must match the database format: 'YYYY-MM-DD'
            const now = new Date();
            const daysToShow = [];
            for (let i = 0; i < 30; i++) {
              const dayDate = new Date(now.getTime() - (i * 24 * 60 * 60 * 1000));
              dayDate.setHours(0, 0, 0, 0);
              // Format to match database: 'YYYY-MM-DD'
              const year = dayDate.getFullYear();
              const month = String(dayDate.getMonth() + 1).padStart(2, '0');
              const day = String(dayDate.getDate()).padStart(2, '0');
              daysToShow.push(`${year}-${month}-${day}`);
            }

            const days = daysToShow;

            let totalTasks = 0;
            let totalCompleted = 0;
            let totalCancelled = 0;
            let totalErrors = 0;
            let totalCost = 0;
            let totalTokens = 0;
            let totalMinutes = 0;

            days.forEach(day => {
              const stats = statsByDay[day] || {
                tasks: 0,
                completed: 0,
                cancelled: 0,
                errors: 0,
                cost: 0,
                tokens: 0,
                duration_ms: 0,
                avgDuration: []
              };
              totalTasks += stats.tasks;
              totalCompleted += stats.completed;
              totalCancelled += stats.cancelled;
              totalErrors += stats.errors;
              totalCost += stats.cost;
              totalTokens += stats.tokens;

              // Calculate minutes used (duration in ms / 60000)
              const minutesUsed = Math.round(stats.duration_ms / 60000);
              totalMinutes += minutesUsed;

              const dayDate = new Date(day);
              const month = (dayDate.getMonth() + 1).toString().padStart(2, '0');
              const date = dayDate.getDate().toString().padStart(2, '0');
              const dayStr = `${month}/${date}`;

              // Format status with ASCII
              let status = '';
              if (stats.completed > 0) status += `OK:${stats.completed}`;
              if (stats.cancelled > 0) status += ` X:${stats.cancelled}`;
              if (stats.errors > 0) status += ` !:${stats.errors}`;
              status = status.trim() || '-';

              // Format row
              const tasksStr = stats.tasks.toString().padEnd(5);

              // Format time: use decimal hours if >= 60 minutes
              let timeStr = '-';
              if (minutesUsed > 0) {
                if (minutesUsed >= 60) {
                  const hours = (minutesUsed / 60).toFixed(1);
                  timeStr = `${hours}h`;
                } else {
                  timeStr = `${minutesUsed}m`;
                }
              }
              const timeFormatted = timeStr.padEnd(6);

              // Simplify cost display - remove leading zeros
              let costStr = '-';
              if (stats.cost > 0) {
                if (stats.cost < 1) {
                  costStr = stats.cost.toFixed(2).substring(1); // Remove leading 0
                } else {
                  costStr = stats.cost.toFixed(2);
                }
              }
              const costFormatted = costStr.padEnd(5);

              message += `${dayStr} | ${tasksStr} | ${timeFormatted} | ${costFormatted} | ${status}\n`;
            });

            message += '```\n';

            // Calculate time usage percentage (of 30 days)
            const totalPossibleMinutes = 30 * 24 * 60; // 43200 minutes in 30 days
            const timeUsagePercent = Math.round((totalMinutes / totalPossibleMinutes) * 100);

            // Add summary
            message += '\n*[SUMMARY]*\n';
            message += `[>] Tasks: ${totalTasks} (OK: ${totalCompleted}`;
            if (totalCancelled > 0) message += `, X: ${totalCancelled}`;
            if (totalErrors > 0) message += `, ERR: ${totalErrors}`;
            message += `)\n`;

            // Format total time
            const totalHours = Math.floor(totalMinutes / 60);
            const remainingMinutes = totalMinutes % 60;
            let timeStr = '';
            if (totalHours > 0) {
              timeStr = `${totalHours}h ${remainingMinutes}m`;
            } else {
              timeStr = `${remainingMinutes}m`;
            }

            message += `[>] Time Used: ${timeStr} (${timeUsagePercent}% of month)\n`;
            message += `[>] Success Rate: ${totalTasks > 0 ? Math.round(totalCompleted/totalTasks*100) : 0}%\n`;
            // Simplify total cost display
            let totalCostStr;
            if (totalCost < 1) {
              totalCostStr = totalCost.toFixed(2).substring(1); // Remove leading 0
            } else {
              totalCostStr = totalCost.toFixed(2);
            }
            message += `[>] Total Cost: ${totalCostStr}\n`;
            message += `[>] Tokens: ${totalTokens.toLocaleString()}\n`;
            // Simplify avg/day cost display
            const avgCost = totalCost / 30;
            let avgCostStr;
            if (avgCost < 1) {
              avgCostStr = avgCost.toFixed(2).substring(1); // Remove leading 0
            } else {
              avgCostStr = avgCost.toFixed(2);
            }
            message += `[>] Avg/Day: ${Math.round(totalTasks / 30)} tasks, ${avgCostStr}\n`;

            if (!showAll && currentWorkspace) {
              message += `\n_Use /monthstat --all to see all workspaces_`;
            }

            await this.telegramNotifier.sendMessage(chatId, message, { parse_mode: 'Markdown' });
            logger.info(`Month stats sent to chat ${chatId}`);
          } catch (error) {
            logger.error(`Error handling /monthstat command:`, error);
            await this.telegramNotifier.sendMessage(chatId,
              '[ERROR] Failed to generate month statistics. Please try again later.');
          }
          break;

        case '/report':
          logger.info(`Handling /report command for chat ${chatId} with args: ${args}`);
          try {
            const { getStatsDB } = await import('./stats-db.js');
            const statsDB = getStatsDB();

            // Check for --all flag
            const showAll = args && args.includes('--all');

            // Get current workspace if not showing all
            let currentWorkspace = null;
            if (!showAll) {
              const workdirName = this.chatSettings.getWorkdir(fullChatId);
              const workdirs = await this.getAvailableWorkdirs(fullChatId);
              currentWorkspace = workdirs[workdirName] || workdirName;
            }

            // Get daily stats for last 365 days
            const dailyStats = statsDB.getDailyStats(365);
            
            if (!dailyStats || dailyStats.length === 0) {
              await this.telegramNotifier.sendMessage(chatId, '[STATS] No data available for report');
              break;
            }

            // Filter stats
            let filteredStats = dailyStats;
            if (currentWorkspace && !showAll) {
              filteredStats = dailyStats.filter(stat => 
                stat.workspace === currentWorkspace || 
                stat.workspace === path.basename(currentWorkspace)
              );
            }

            // Map stats to date -> tokens
            const statsMap = new Map();
            let maxTokens = 0;
            let totalTokens = 0;
            let totalCost = 0;
            
            filteredStats.forEach(stat => {
              const date = stat.day; // YYYY-MM-DD
              const tokens = stat.total_tokens || 0;
              const cost = stat.total_cost || 0;
              
              if (statsMap.has(date)) {
                const current = statsMap.get(date);
                statsMap.set(date, {
                  tokens: current.tokens + tokens,
                  cost: current.cost + cost,
                  count: current.count + (stat.task_count || 0)
                });
              } else {
                statsMap.set(date, {
                  tokens,
                  cost,
                  count: stat.task_count || 0
                });
              }
              
              const currentTotal = statsMap.get(date).tokens;
              if (currentTotal > maxTokens) maxTokens = currentTotal;
              totalTokens += tokens;
              totalCost += cost;
            });

            // Get monthly provider stats
            const monthlyModelStats = statsDB.getMonthlyModelStats(12);

            // Helper function to determine provider from provider_id or model
            const getProviderName = (providerId, model) => {
                // First try provider_id (new data)
                if (providerId) {
                    const id = providerId.toLowerCase();
                    if (id === 'claude' || id.includes('claude')) return 'Claude';
                    if (id === 'cursor') return 'Cursor';
                    if (id === 'codex' || id === 'openai') return 'OpenAI';
                    if (id === 'gemini' || id === 'google') return 'Gemini';
                    if (id === 'glm' || id === 'zhipu') return 'GLM';
                    if (id === 'deepseek') return 'DeepSeek';
                    if (id === 'mistral') return 'Mistral';
                    if (id === 'meta' || id === 'llama') return 'Meta';
                    // If provider_id is set but not recognized, use it as-is (capitalized)
                    return providerId.charAt(0).toUpperCase() + providerId.slice(1);
                }

                // Fallback to model-based detection (for older data without provider_id)
                const modelLower = (model || '').toLowerCase();
                if (modelLower.includes('claude') || modelLower === 'opus' || modelLower === 'sonnet' || modelLower === 'haiku') return 'Claude';
                if (modelLower.includes('gpt') || modelLower.includes('o1-')) return 'OpenAI';
                if (modelLower.includes('gemini')) return 'Gemini';
                if (modelLower.includes('deepseek')) return 'DeepSeek';
                if (modelLower.includes('llama')) return 'Meta';
                if (modelLower.includes('mistral')) return 'Mistral';
                if (modelLower.includes('cursor')) return 'Cursor';
                if (modelLower.includes('glm')) return 'GLM';

                return 'Other';
            };

            // Process provider stats
            const providerStats = new Map(); // month -> { provider -> { count, tokens, cost } }
            const providers = new Set();

            monthlyModelStats.forEach(stat => {
                const month = stat.month;
                const provider = getProviderName(stat.provider_id, stat.model);

                providers.add(provider);

                if (!providerStats.has(month)) {
                    providerStats.set(month, {});
                }
                const monthStats = providerStats.get(month);
                if (!monthStats[provider]) {
                    monthStats[provider] = { count: 0, tokens: 0, cost: 0 };
                }

                monthStats[provider].count += stat.task_count || 0;
                monthStats[provider].tokens += stat.total_tokens || 0;
                monthStats[provider].cost += stat.total_cost || 0;
            });

            // Generate full 12 month list for chart
            const chartMonths = [];
            const chartPtr = new Date();
            chartPtr.setDate(1);
            chartPtr.setMonth(chartPtr.getMonth() - 11); // Go back 11 months + current = 12
            
            for(let i=0; i<12; i++) {
                const y = chartPtr.getFullYear();
                const m = chartPtr.getMonth() + 1;
                chartMonths.push(`${y}-${m.toString().padStart(2, '0')}`);
                chartPtr.setMonth(chartPtr.getMonth() + 1);
            }

            const providerColors = {
                'Claude': '#d97757',
                'OpenAI': '#10a37f',
                'Gemini': '#4285F4',
                'DeepSeek': '#4b67e3',
                'Meta': '#0668E1',
                'Mistral': '#fcd53f',
                'Cursor': '#a0a0a0',
                'GLM': '#7c3aed',
                'Other': '#6e7681'
            };

            // Generate HTML
            const now = new Date();
            const oneYearAgo = new Date();
            oneYearAgo.setFullYear(now.getFullYear() - 1);
            
            // Helper for color scale
            const getColor = (tokens) => {
              if (tokens === 0) return '#161b22';
              const ratio = tokens / maxTokens;
              if (ratio < 0.25) return '#0e4429';
              if (ratio < 0.5) return '#006d32';
              if (ratio < 0.75) return '#26a641';
              return '#39d353';
            };

            let html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Token Usage Report</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; padding: 20px; color: #c9d1d9; background-color: #0d1117; max-width: 1200px; margin: 0 auto; }
    h1 { font-size: 24px; margin-bottom: 20px; text-align: center; color: #e6edf3; }
    .summary { display: flex; flex-wrap: wrap; gap: 20px; margin-bottom: 30px; justify-content: center; }
    .stat-card { background: #161b22; padding: 15px; border-radius: 6px; border: 1px solid #30363d; min-width: 140px; text-align: center; flex: 1; }
    .stat-value { font-size: 18px; font-weight: 600; margin-top: 5px; color: #e6edf3; }
    .stat-label { font-size: 12px; color: #8b949e; }
    
    .months-wrapper { display: flex; flex-wrap: wrap; gap: 20px; justify-content: center; }
    .month-container { margin-bottom: 10px; }
    .month-title { font-size: 14px; font-weight: 600; margin-bottom: 5px; text-align: center; color: #e6edf3; }
    .days-grid { display: grid; grid-template-rows: repeat(7, 10px); grid-auto-flow: column; gap: 2px; }
    .day-cell { width: 10px; height: 10px; border-radius: 2px; }
    
    .tooltip { position: relative; }
    .tooltip .tooltiptext {
      visibility: hidden; width: 180px; background-color: rgba(110, 118, 129, 0.9); color: #fff; text-align: left;
      border-radius: 6px; padding: 8px; position: absolute; z-index: 100;
      bottom: 150%; left: 50%; margin-left: -90px; opacity: 0; transition: opacity 0.2s;
      font-size: 12px; pointer-events: none; white-space: pre-wrap; box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    .tooltip .tooltiptext::after {
      content: ""; position: absolute; top: 100%; left: 50%; margin-left: -5px;
      border-width: 5px; border-style: solid; border-color: rgba(110, 118, 129, 0.9) transparent transparent transparent;
    }
    .tooltip:hover .tooltiptext { visibility: visible; opacity: 1; }
    
    .legend { margin-top: 20px; display: flex; align-items: center; justify-content: center; gap: 5px; font-size: 12px; color: #8b949e; }
    .legend-box { width: 10px; height: 10px; border-radius: 2px; }

    .chart-container { margin-top: 40px; margin-bottom: 40px; }
    .chart-title { font-size: 18px; font-weight: 600; margin-bottom: 15px; text-align: center; color: #e6edf3; }
    .bar-chart { display: flex; height: 200px; gap: 10px; align-items: flex-end; padding-bottom: 20px; border-bottom: 1px solid #30363d; padding-left: 10px; padding-right: 10px; }
    .bar-group { flex: 1; display: flex; flex-direction: column-reverse; justify-content: flex-start; height: 100%; position: relative; min-width: 20px; }
    .bar-segment { width: 100%; position: relative; transition: opacity 0.2s; cursor: pointer; }
    .bar-segment:hover { opacity: 0.8; }
    .bar-label { position: absolute; bottom: -45px; left: 50%; transform: translateX(-50%) rotate(-45deg); font-size: 10px; color: #8b949e; white-space: nowrap; transform-origin: center top; }
    .provider-legend { display: flex; flex-wrap: wrap; gap: 15px; justify-content: center; margin-top: 20px; margin-bottom: 20px; }
    .p-item { display: flex; align-items: center; gap: 5px; font-size: 12px; color: #8b949e; }
    .p-color { width: 12px; height: 12px; border-radius: 2px; }
    .no-data { text-align: center; color: #8b949e; padding: 20px; font-style: italic; }

    @media (max-width: 600px) {
        .stat-card { min-width: 45%; }
        .day-cell { width: 8px; height: 8px; }
        .days-grid { gap: 1px; grid-template-rows: repeat(7, 8px); }
    }
  </style>
</head>
<body>
  <h1>Usage Report: ${showAll ? 'All Workspaces' : path.basename(currentWorkspace || 'Unknown')}</h1>
  
  <div class="summary">
    <div class="stat-card">
      <div class="stat-label">Total Tokens</div>
      <div class="stat-value">${totalTokens.toLocaleString()}</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Total Cost</div>
      <div class="stat-value">$${totalCost.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Max Daily Tokens</div>
      <div class="stat-value">${maxTokens.toLocaleString()}</div>
    </div>
  </div>

  <div class="months-wrapper">
`;
            
            // Loop through last 12 months (or relevant range)
            const monthsToProcess = [];
            // Start from one year ago, first day of that month
            const ptr = new Date(oneYearAgo);
            ptr.setDate(1); 
            
            while (ptr <= now) {
                monthsToProcess.push(new Date(ptr));
                ptr.setMonth(ptr.getMonth() + 1);
            }

            for (const monthDate of monthsToProcess) {
                const monthName = monthDate.toLocaleDateString('default', { month: 'short', year: 'numeric' });
                const year = monthDate.getFullYear();
                const month = monthDate.getMonth();
                
                // Determine days in this month
                const daysInMonth = new Date(year, month + 1, 0).getDate();
                const startDay = new Date(year, month, 1).getDay(); // 0=Sun
                
                html += `<div class="month-container">
                    <div class="month-title">${monthName}</div>
                    <div class="days-grid">`;
                
                // Add padding cells for start of month (Sunday-aligned)
                for (let i = 0; i < startDay; i++) {
                     html += `<div class="day-cell" style="background-color: transparent"></div>`;
                }
                
                // Add day cells
                for (let day = 1; day <= daysInMonth; day++) {
                    const d = new Date(year, month, day);
                    const isoDate = d.toISOString().split('T')[0];
                    const stats = statsMap.get(isoDate) || { tokens: 0, count: 0, cost: 0 };
                    const color = getColor(stats.tokens);
                    
                    const tooltip = `${isoDate}
Tasks: ${stats.count}
Tokens: ${stats.tokens.toLocaleString()}
Cost: $${stats.cost.toFixed(2)}`;
                    
                    html += `<div class="day-cell tooltip" style="background-color: ${color}">
                      <span class="tooltiptext">${tooltip.replace(/\n/g, '<br>')}</span>
                    </div>`;
                }
                
                html += `</div></div>`;
            }
            
            html += `</div>
    <div class="legend">
      <span>Less</span>
      <div class="legend-box" style="background-color: #161b22"></div>
      <div class="legend-box" style="background-color: #0e4429"></div>
      <div class="legend-box" style="background-color: #006d32"></div>
      <div class="legend-box" style="background-color: #26a641"></div>
      <div class="legend-box" style="background-color: #39d353"></div>
      <span>More</span>
    </div>

    <div class="chart-container">
        <div class="chart-title">Provider Usage (Last 12 Months)</div>
        ${(() => {
            let chartHtml = '';
            const sortedProviders = Array.from(providers).sort();
            
            // Calculate max value for scaling across ALL months (including empty ones if relevant, but really just checking data)
            let maxMonthlyValue = 0;
            
            // Check if we have any data at all first
            let hasAnyData = false;
            
            chartMonths.forEach(month => {
                const monthData = providerStats.get(month);
                if (monthData) {
                    let monthlyTotal = 0;
                    Object.values(monthData).forEach(d => monthlyTotal += d.count);
                    if (monthlyTotal > maxMonthlyValue) maxMonthlyValue = monthlyTotal;
                    if (monthlyTotal > 0) hasAnyData = true;
                }
            });

            if (!hasAnyData) {
                chartHtml += `<div class="no-data">No usage data available for breakdown</div>`;
            } else {
                if (maxMonthlyValue === 0) maxMonthlyValue = 1;

                chartHtml += `<div class="bar-chart">`;
                
                chartMonths.forEach(month => {
                    const monthData = providerStats.get(month) || {};
                    
                    // Format month for label
                    const [y, m] = month.split('-');
                    const dateObj = new Date(parseInt(y), parseInt(m)-1, 1);
                    const label = dateObj.toLocaleDateString('default', { month: 'short', year: '2-digit' });

                    chartHtml += `<div class="bar-group">`;
                    
                    sortedProviders.forEach(provider => {
                        const data = monthData[provider];
                        if (data && data.count > 0) {
                            const height = (data.count / maxMonthlyValue) * 100;
                            const color = providerColors[provider] || providerColors['Other'];
                            
                            // Tooltip
                            const tooltip = `${provider} • ${month}
Tasks: ${data.count}
Tokens: ${data.tokens.toLocaleString()}
Cost: $${data.cost.toFixed(2)}`;
                            
                            chartHtml += `<div class="bar-segment tooltip" style="height: ${height}%; background-color: ${color}">
                                <span class="tooltiptext">${tooltip.replace(/\n/g, '<br>')}</span>
                            </div>`;
                        }
                    });
                    
                    chartHtml += `<div class="bar-label">${label}</div>`;
                    chartHtml += `</div>`;
                });
                
                chartHtml += `</div>`;

                // Legend
                chartHtml += `<div class="provider-legend">`;
                sortedProviders.forEach(provider => {
                    const color = providerColors[provider] || providerColors['Other'];
                    chartHtml += `<div class="p-item">
                        <div class="p-color" style="background-color: ${color}"></div>
                        <span>${provider}</span>
                    </div>`;
                });
                chartHtml += `</div>`;
            }
            return chartHtml;
        })()}
    </div>

</body>
</html>`;
            
            // Write to file
            const tmpDir = path.join(process.cwd(), 'tmp');
            if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });
            const reportPath = path.join(tmpDir, `report-${Date.now()}.html`);
            fs.writeFileSync(reportPath, html);
            
            logger.info(`Generated report at ${reportPath}`);

            // Send file - need to create a read stream for Telegram API
            const fileStream = fs.createReadStream(reportPath);
            await this.telegramNotifier.sendDocument(chatId, fileStream, {
                caption: `📊 Token Usage Report (${new Date().toLocaleDateString()})`,
                filename: path.basename(reportPath)
            });
            
          } catch (error) {
             logger.error(`Error handling /report command:`, error);
             await this.telegramNotifier.sendMessage(chatId, `❌ Failed to generate report: ${error.message}`);
          }
          break;

        case '/yearstat':
          logger.info(`Handling /yearstat command for chat ${chatId} with args: ${args}`);
          try {
            const { getStatsDB } = await import('./stats-db.js');
            const statsDB = getStatsDB();

            // Check for --all flag
            const showAll = args && args.includes('--all');

            // Get current workspace if not showing all
            let currentWorkspace = null;
            if (!showAll) {
              const workdirName = this.chatSettings.getWorkdir(fullChatId);
              const workdirs = await this.getAvailableWorkdirs(fullChatId);
              currentWorkspace = workdirs[workdirName] || workdirName;
            }

            // Get daily stats for last 365 days (12 months)
            const dailyStats = statsDB.getDailyStats(365);

            if (!dailyStats || dailyStats.length === 0) {
              await this.telegramNotifier.sendMessage(chatId,
                '[STATS] No task statistics available for the last 12 months');
              break;
            }

            // Filter stats by workspace if not showing all
            let filteredStats = dailyStats;
            if (currentWorkspace && !showAll) {
              filteredStats = dailyStats.filter(stat =>
                stat.workspace === currentWorkspace ||
                stat.workspace === path.basename(currentWorkspace)
              );
            }

            if (filteredStats.length === 0) {
              await this.telegramNotifier.sendMessage(chatId,
                `[STATS] No task statistics for workspace "${path.basename(currentWorkspace)}" in the last 12 months`);
              break;
            }

            // Group stats by month
            const statsByMonth = {};
            filteredStats.forEach(stat => {
              const monthKey = stat.day.substring(0, 7); // YYYY-MM format
              if (!statsByMonth[monthKey]) {
                statsByMonth[monthKey] = {
                  tasks: 0,
                  completed: 0,
                  cost: 0,
                  tokens: 0,
                  duration: 0
                };
              }
              statsByMonth[monthKey].tasks += stat.task_count || 0;
              statsByMonth[monthKey].completed += stat.completed_count || 0;
              statsByMonth[monthKey].cost += stat.total_cost || 0;
              statsByMonth[monthKey].tokens += stat.total_tokens || 0;
              statsByMonth[monthKey].duration += stat.total_duration_ms || 0;
            });

            // Sort months (newest first)
            const sortedMonths = Object.keys(statsByMonth).sort().reverse();

            // Build message
            let message = '';
            if (showAll) {
              message = '*📊 12-Month Statistics (All Workspaces)*\n\n';
            } else {
              const workspaceName = path.basename(currentWorkspace);
              message = `*📊 12-Month Statistics*\n_Workspace: ${workspaceName}_\n\n`;
            }

            // Format each month
            sortedMonths.forEach(monthKey => {
              const stat = statsByMonth[monthKey];
              const monthDate = new Date(monthKey + '-01');
              const monthName = monthDate.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });

              // Calculate success rate
              const successRate = stat.tasks > 0
                ? Math.round((stat.completed / stat.tasks) * 100)
                : 0;

              // Format cost
              let costStr = '$0.00';
              if (stat.cost > 0) {
                if (stat.cost >= 1) {
                  costStr = `$${stat.cost.toFixed(2)}`;
                } else if (stat.cost >= 0.01) {
                  costStr = `$${stat.cost.toFixed(2)}`;
                } else {
                  costStr = `$${stat.cost.toFixed(4)}`;
                }
              }

              // Format tokens
              let tokensStr = '0';
              if (stat.tokens >= 1000000) {
                tokensStr = `${(stat.tokens / 1000000).toFixed(1)}M`;
              } else if (stat.tokens >= 1000) {
                tokensStr = `${(stat.tokens / 1000).toFixed(0)}K`;
              } else if (stat.tokens > 0) {
                tokensStr = stat.tokens.toString();
              }

              // Format duration
              let durationStr = '0m';
              if (stat.duration > 0) {
                const totalMinutes = Math.round(stat.duration / 60000);
                if (totalMinutes >= 60) {
                  const hours = Math.floor(totalMinutes / 60);
                  const mins = totalMinutes % 60;
                  durationStr = mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
                } else {
                  durationStr = `${totalMinutes}m`;
                }
              }

              message += `*${monthName}*\n`;
              message += `└ ${stat.tasks} tasks (${successRate}% ✓) • ${durationStr}\n`;
              message += `└ ${costStr} • ${tokensStr} tokens\n\n`;
            });

            // Calculate totals
            let totalTasks = 0;
            let totalCompleted = 0;
            let totalCost = 0;
            let totalTokens = 0;
            let totalDuration = 0;

            Object.values(statsByMonth).forEach(stat => {
              totalTasks += stat.tasks;
              totalCompleted += stat.completed;
              totalCost += stat.cost;
              totalTokens += stat.tokens;
              totalDuration += stat.duration;
            });

            const overallSuccessRate = totalTasks > 0
              ? Math.round((totalCompleted / totalTasks) * 100)
              : 0;

            // Format total cost
            let totalCostStr = '$0.00';
            if (totalCost > 0) {
              if (totalCost >= 1) {
                totalCostStr = `$${totalCost.toFixed(2)}`;
              } else if (totalCost >= 0.01) {
                totalCostStr = `$${totalCost.toFixed(2)}`;
              } else {
                totalCostStr = `$${totalCost.toFixed(4)}`;
              }
            }

            // Format total duration
            let totalDurationStr = '0m';
            if (totalDuration > 0) {
              const totalMinutes = Math.round(totalDuration / 60000);
              if (totalMinutes >= 60) {
                const hours = Math.floor(totalMinutes / 60);
                const mins = totalMinutes % 60;
                totalDurationStr = mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
              } else {
                totalDurationStr = `${totalMinutes}m`;
              }
            }

            message += `*Summary (12 months)*\n`;
            message += `[>] Total Tasks: ${totalTasks} (${overallSuccessRate}% success)\n`;
            message += `[>] Total Duration: ${totalDurationStr}\n`;
            message += `[>] Total Cost: ${totalCostStr}\n`;
            message += `[>] Tokens: ${totalTokens.toLocaleString()}\n`;

            // Calculate monthly average
            const monthsWithData = sortedMonths.length;
            let avgCost = 0;
            let avgCostStr = '$0.00';
            if (monthsWithData > 0) {
              avgCost = totalCost / monthsWithData;
              if (avgCost >= 1) {
                avgCostStr = `$${avgCost.toFixed(2)}`;
              } else if (avgCost >= 0.01) {
                avgCostStr = `$${avgCost.toFixed(2)}`;
              } else {
                avgCostStr = `$${avgCost.toFixed(4)}`;
              }
            }
            message += `[>] Avg/Month: ${Math.round(totalTasks / 12)} tasks, ${avgCostStr}\n`;

            if (!showAll && currentWorkspace) {
              message += `\n_Use /yearstat --all to see all workspaces_`;
            }

            await this.telegramNotifier.sendMessage(chatId, message, { parse_mode: 'Markdown' });
            logger.info(`Year stats sent to chat ${chatId}`);
          } catch (error) {
            logger.error(`Error handling /yearstat command:`, error);
            await this.telegramNotifier.sendMessage(chatId,
              '[ERROR] Failed to generate year statistics. Please try again later.');
          }
          break;

        case '/workdir':
        if (args) {
          await this.setTelegramWorkdir(chatId, args);
        } else {
          await this.telegramNotifier.sendMessage(chatId, 
            '❌ Please use /connect [token] to connect to a workspace');
        }
        break;
        
      case '/add':
        try {
          if (!args) {
            await this.telegramNotifier.sendMessage(chatId, '❌ Please provide a prompt after /add');
            return;
          }

          // Check if this is a reply to a message
          let finalPrompt = args;
          if (message && message.reply_to_message) {
            logger.debug(`Reply detected`, {
              msgId: message.reply_to_message.message_id,
              hasPhoto: !!message.reply_to_message.photo,
              hasDoc: !!message.reply_to_message.document,
              hasText: !!message.reply_to_message.text
            });

            // Check for replied message text content
            if (message.reply_to_message.text) {
              const repliedText = message.reply_to_message.text;
              finalPrompt = `${args}\n\n[Context: Replying to message]\n${repliedText}`;
              logger.debug(`Added replied text to prompt`, { textLen: repliedText.length });
            }

            // Also check for image in the replied message
            const imageUrl = await this.processRepliedImage(message.reply_to_message, chatId);
            if (imageUrl) {
              finalPrompt = `${finalPrompt}\n\nImage: ${imageUrl}\n\nNote: Download to .ani-code/tmp/ folder using wget with the original filename from the URL (not a generic name like image.jpg) and analyze`;
              logger.info(`Added replied image URL to prompt: ${imageUrl}`);
            }
          }

          // Process any preset templates in the prompt
          const presetResult = await processPresets(finalPrompt);
          finalPrompt = presetResult.text;

          // If presets were found, notify the user
          if (presetResult.presets && presetResult.presets.length > 0) {
            const presetMessages = presetResult.presets.map(p =>
              `  • \`${p.file}\` - ${p.description}`
            ).join('\n');
            await this.telegramNotifier.sendMessage(chatId,
              `**Preset found:**\n${presetMessages}`,
              { parse_mode: 'Markdown' }
            );
          }

          logger.info(`Calling createTelegramTask for /add with chatId: ${chatId}, prompt length: ${finalPrompt?.length || 0}, attachments: ${message?.attachments?.length || 0}`);
          await this.createTelegramTask(chatId, 'add', finalPrompt, { attachments: message?.attachments });
        } catch (error) {
          logger.error(`Error processing /add command for chat ${chatId}:`, error);
          await this.telegramNotifier.sendMessage(chatId, 
            `❌ Failed to process /add command\n\n` +
            `Error: ${error.message || 'Unknown error'}\n\n` +
            `Please try again with a shorter message or contact support.`,
            { parse_mode: 'Markdown' }
          );
        }
        break;
        
      case '/continue':
        // Check if this is a reply to a message
        let continueFinalPrompt = args;
        if (message && message.reply_to_message) {
          logger.debug(`[/continue] Reply detected`, {
            msgId: message.reply_to_message.message_id,
            hasPhoto: !!message.reply_to_message.photo,
            hasDoc: !!message.reply_to_message.document,
            hasText: !!message.reply_to_message.text
          });

          // Check for replied message text content
          if (message.reply_to_message.text) {
            const repliedText = message.reply_to_message.text;
            const basePrompt = args || '';
            continueFinalPrompt = basePrompt ?
              `${basePrompt}\n\n[Context: Replying to message]\n${repliedText}` :
              `[Context: Replying to message]\n${repliedText}`;
            logger.debug(`Added replied text to continue prompt`, { textLen: repliedText.length });
          }

          // Also check for image in the replied message
          const imageUrl = await this.processRepliedImage(message.reply_to_message, chatId);
          if (imageUrl) {
            continueFinalPrompt = continueFinalPrompt ?
              `${continueFinalPrompt}\n\nImage: ${imageUrl}\n\nNote: Download to .ani-code/tmp/ folder using wget with the original filename from the URL (not a generic name like image.jpg) and analyze` :
              `Image: ${imageUrl}\n\nNote: Download to .ani-code/tmp/ folder using wget with the original filename from the URL (not a generic name like image.jpg) and analyze`;
            logger.info(`Added replied image URL to continue prompt: ${imageUrl}`);
          }
        }

        // Process any preset templates in the prompt
        if (continueFinalPrompt) {
          const presetResult = await processPresets(continueFinalPrompt);
          continueFinalPrompt = presetResult.text;

          // If presets were found, notify the user
          if (presetResult.presets && presetResult.presets.length > 0) {
            const presetMessages = presetResult.presets.map(p =>
              `  • \`${p.file}\` - ${p.description}`
            ).join('\n');
            await this.telegramNotifier.sendMessage(chatId,
              `**Preset found:**\n${presetMessages}`,
              { parse_mode: 'Markdown' }
            );
          }
        }

        await this.createTelegramTask(chatId, 'continue', continueFinalPrompt, { attachments: message?.attachments });
        break;

      case '/rulecompress':
        logger.info(`Handling /rulecompress command for chat ${chatId}`);
        await this.handleRulecompressCommand(chatId, args, message);
        break;

      case '/grant':
        // Handle /grant command for permission review
        const grantPrompt = `You are in High Privilege Mode for permission management.

## Task
Review the last Claude message in the conversation history and identify any permission blocks or denied operations.

## Analysis Steps
1. Check the last message for:
   - Permission errors ("This tool requires approval", "permission denied")
   - Blocked Bash commands
   - Blocked file operations (Read/Write/Edit)
   - Blocked MCP function calls
   - Tool use errors related to permissions

2. Identify the permission pattern needed:
   - Bash commands: \`Bash(command:*)\`
   - File reads: \`Read(path)\` or \`Read(path/**/*)\`
   - File writes: \`Write(path)\` or \`Write(path/**/*)\`
   - File edits: \`Edit(path)\` or \`Edit(path/**/*)\`
   - MCP tools: \`mcp__server__function(*)\`

3. Update .claude/settings.local.json (PREFERRED over .claude/settings.json):
   - ALWAYS prefer modifying \`.claude/settings.local.json\` instead of \`.claude/settings.json\` to resolve permission issues
   - \`.claude/settings.local.json\` is the local override file and should be used for per-machine permission grants
   - Only modify \`.claude/settings.json\` if explicitly instructed to do so
   - Add permission to permissions.allow array
   - Use wildcards appropriately for flexibility
   - Keep alphabetical order within sections
   - Ensure valid JSON syntax
   - If the file doesn't exist, create it with proper structure

4. Report back:
   - What permission was blocked
   - What pattern was added
   - Confirmation the file was updated
   - Do NOT re-execute the originally blocked operation — only resolve the permission and describe what you did
   - The user will retry the operation themselves

${args ? `\n## Additional Instructions\n${args}\n` : ''}

## Example Permission Patterns
- \`Bash(npm install:*)\` - npm install commands
- \`Bash(python3:*)\` - Python 3 scripts
- \`Bash(curl:*)\` - curl requests
- \`Read(/etc/**/*)\` - Read files in /etc
- \`Write(/tmp/**/*)\` - Write to tmp
- \`Edit(./**/*)\` - Edit any file in current dir

## Important Guidelines
- Be specific but not overly restrictive
- Use wildcards to avoid repeated approvals
- Never grant overly broad permissions like \`Bash(*)\`
- Preserve all existing permissions
- Validate JSON before saving
- ALWAYS use \`.claude/settings.local.json\` — never modify \`.claude/settings.json\` unless explicitly asked
- Only resolve the permission issue and report what was done — do NOT execute the originally blocked operation
- If no permission issues found, report "No permission issues detected"

Now analyze the conversation and grant necessary permissions.`;

        await this.telegramNotifier.sendMessage(chatId,
          `🔐 *Permission Review Task*\n\n` +
          `Analyzing last message for blocked operations and granting permissions...`,
          { parse_mode: 'Markdown' }
        );
        await this.createTelegramTask(chatId, 'continue', `--dangerously-skip-permissions ${grantPrompt}`);
        break;

      case '/macro':
        // Handle macro creation
        try {
          if (!args) {
            await this.telegramNotifier.sendMessage(chatId,
              `📝 *Macro System*\n\n` +
              `Create reusable command shortcuts!\n\n` +
              `*Usage:*\n` +
              `\`/macro $name <command>\`\n\n` +
              `*Examples:*\n` +
              `• \`/macro $progress /add what is the current progress of pd/goal\`\n` +
              `• \`/macro $test /add run the test suite and fix failures\`\n` +
              `• \`/macro $status /add show me the git status and recent commits\`\n\n` +
              `*Multi-line macros:*\n` +
              `\`\`\`\n/macro $deploy\n/add deploy to staging\ncheck logs\nrun tests\n\`\`\`\n\n` +
              `*Execute macro:*\n` +
              `Just type \`/$name\` (e.g., \`/$progress\`)`,
              { parse_mode: 'Markdown' }
            );
            return;
          }

          // Parse macro name and command
          const macroMatch = args.match(/^\$(\w+)\s+([\s\S]+)$/);
          if (!macroMatch) {
            await this.telegramNotifier.sendMessage(chatId,
              `❌ Invalid macro format.\n\n` +
              `Use: \`/macro $name <command>\`\n` +
              `Example: \`/macro $test /add run tests\``,
              { parse_mode: 'Markdown' }
            );
            return;
          }

          const macroName = macroMatch[1];
          const macroCommand = macroMatch[2].trim();

          // Get workspace for this chat - use same lookup as handleMacrosCommand
          const { WorkspaceManager } = await import('./workspace-manager.js');
          const manager = new WorkspaceManager();
          await manager.initialize();

          let workspace = null;

          // First try: resolve via chatSettings workdir + path lookup (consistent with /macros listing)
          const macroWorkdirName = this.chatSettings.getWorkdir(fullChatId);
          if (macroWorkdirName) {
            const macroAvailableWorkdirs = await this.getAvailableWorkdirs(fullChatId);
            const macroWorkdirPath = macroAvailableWorkdirs[macroWorkdirName];
            if (macroWorkdirPath) {
              workspace = await manager.getWorkspaceByPath(macroWorkdirPath);
            }
          }

          // Second try: resolve via telegram_chats table
          if (!workspace) {
            workspace = await manager.getWorkspaceForTelegramChat(String(chatId));
          }

          // Third try: gateway fallback
          if (!workspace) {
            if (config.gateway.enabled) {
              workspace = await manager.ensureGatewayWorkspace();
              logger.debug('Gateway mode: Using gateway workspace for Telegram macro');
            } else {
              await this.telegramNotifier.sendMessage(chatId,
                `❌ *No workspace connected*\n\n` +
                `Connect to a workspace first:\n` +
                `1. Generate token: \`ani-code workspace token gen\`\n` +
                `2. Connect: \`/connect <token>\``,
                { parse_mode: 'Markdown' }
              );
              await manager.close();
              return;
            }
          }

          // Store macro in workspace metadata
          const metaKey = `macro-${macroName}`;
          await manager.setWorkspaceMeta(workspace.id, metaKey, macroCommand);

          await this.telegramNotifier.sendMessage(chatId,
            `✅ *Macro Created*\n\n` +
            `Macro: \`$${macroName}\`\n` +
            `Command: \`${macroCommand.substring(0, 100)}${macroCommand.length > 100 ? '...' : ''}\`\n\n` +
            `Execute with: \`/$${macroName}\``,
            { parse_mode: 'Markdown' }
          );

          await manager.close();
        } catch (error) {
          logger.error(`Failed to create macro: ${error.message}`);
          await this.telegramNotifier.sendMessage(chatId,
            `❌ Failed to create macro: ${error.message}`,
            { parse_mode: 'Markdown' }
          );
        }
        break;

      case '/plan':
        // Handle plan creation
        try {
          const { WorkspaceManager } = await import('./workspace-manager.js');
          const manager = new WorkspaceManager();
          await manager.initialize();

          // Get workspace for this chat
          let workspace = await manager.getWorkspaceForTelegramChat(String(chatId));
          if (!workspace) {
            // In gateway mode, ensure gateway workspace exists in database
            if (config.gateway.enabled) {
              workspace = await manager.ensureGatewayWorkspace();
              logger.debug('Gateway mode: Using gateway workspace for Telegram /plan');
            } else {
              await this.telegramNotifier.sendMessage(chatId,
                `❌ *No workspace connected*\n\n` +
                `Connect to a workspace first:\n` +
                `1. Generate token: \`ani-code workspace token gen\`\n` +
                `2. Connect: \`/connect <token>\``,
                { parse_mode: 'Markdown' }
              );
              await manager.close();
              return;
            }
          }

          if (!args) {
            await this.telegramNotifier.sendMessage(chatId,
              `📋 *Create a Plan*\n\n` +
              `Usage: \`/plan <steps>\`\n\n` +
              `Example:\n` +
              `\`\`\`\n/plan\n- Fix login bug\n- Add tests\n- Deploy to staging\n\`\`\`\n\n` +
              `Each line becomes a step in your plan.`,
              { parse_mode: 'Markdown' }
            );
            await manager.close();
            return;
          }

          // Check if the plan contains preset references (starts with @)
          if (args.trim().match(/^@[\w.-]+\.md/im) || args.includes('@preset') || args.match(/@[\w.-]+\.md/)) {
            await this.telegramNotifier.sendMessage(chatId,
              `❌ *Plan creation failed*\n\n` +
              `Preset expansion is not supported in \`/plan\` command.\n\n` +
              `⚠️ Each line in a plan can expand to multiple tasks, which could result in unexpectedly long plans.\n\n` +
              `💡 Please:\n` +
              `  • Write out steps manually without presets\n` +
              `  • Use presets with \`/remember\` instead`,
              { parse_mode: 'Markdown' }
            );
            await manager.close();
            return;
          }

          // Process any preset templates in the args (safety check, should not match after validation above)
          const presetResult = await processPresets(args);
          const processedArgs = presetResult.text;

          // If presets were found, notify the user and reject (redundant safety check)
          if (presetResult.presets && presetResult.presets.length > 0) {
            await this.telegramNotifier.sendMessage(chatId,
              `❌ *Plan creation failed*\n\n` +
              `Preset expansion is not supported in \`/plan\` command.\n\n` +
              `Found preset references:\n${presetResult.presets.map(p => `  • \`${p.file}\``).join('\n')}`,
              { parse_mode: 'Markdown' }
            );
            await manager.close();
            return;
          }

          // Treat entire chat input as a single step (no multi-step breakdown)
          const stepContent = processedArgs.trim();

          if (!stepContent) {
            await this.telegramNotifier.sendMessage(chatId,
              `❌ No valid content found in plan`,
              { parse_mode: 'Markdown' }
            );
            await manager.close();
            return;
          }

          // Single step from entire input
          const normalizedSteps = normalizePlanSteps([stepContent]);
          const defaultTitle = stepContent.split('\n')[0].substring(0, 50);

          // Create the plan
          const planData = {
            title: defaultTitle.substring(0, 50),
            description: stepsToPlanDescription(normalizedSteps) || args,
            steps: normalizedSteps,
            createdBy: `telegram:${chatId}`,
            metadata: {
              source: 'telegram',
              chatId: chatId,
              timestamp: new Date().toISOString()
            }
          };

          const result = await manager.createPlan(workspace.id, planData);

          let message = `✅ *Plan Created*\n\n`;
          message += `📋 ID: \`${result.planId}\`\n`;
          message += `📁 Workspace: ${workspace.name}\n`;
          message += `📝 Steps: ${normalizedSteps.length}`;

          // Add common footer with turncat content
          message += '\n━━━━━━━━━━━━━━━';
          message += await this.telegramNotifier.formatFooter(workspace.name);

          // Add inline keyboard with delete button
          const keyboard = {
            inline_keyboard: [
              [
                {
                  text: '🗑 Delete Plan',
                  callback_data: JSON.stringify({
                    a: 'delete_plan',
                    pid: result.planId
                  })
                }
              ]
            ]
          };

          await this.telegramNotifier.sendMessage(chatId, message, {
            parse_mode: 'Markdown',
            reply_markup: keyboard
          });
          await manager.close();

        } catch (error) {
          logger.error(`Failed to create plan: ${error.message}`);
          await this.telegramNotifier.sendMessage(chatId,
            `❌ Failed to create plan: ${error.message}`,
            { parse_mode: 'Markdown' }
          );
        }
        break;

      case '/plans':
        // Handle listing all plans for workspace
        try {
          const { WorkspaceManager } = await import('./workspace-manager.js');
          const manager = new WorkspaceManager();
          await manager.initialize();

          // Get workspace for this chat
          let workspace = await manager.getWorkspaceForTelegramChat(String(chatId));
          if (!workspace) {
            // In gateway mode, ensure gateway workspace exists in database
            if (config.gateway.enabled) {
              workspace = await manager.ensureGatewayWorkspace();
              logger.debug('Gateway mode: Using gateway workspace for Telegram /plans');
            } else {
              await this.telegramNotifier.sendMessage(chatId,
                `❌ *No workspace connected*\n\n` +
                `Connect to a workspace first:\n` +
                `1. Generate token: \`ani-code workspace token gen\`\n` +
                `2. Connect: \`/connect <token>\``,
                { parse_mode: 'Markdown' }
              );
              await manager.close();
              return;
            }
          }

          // Get all plans for the workspace
          const plans = await manager.listPlans(workspace.id);

          if (!plans || plans.length === 0) {
            await this.telegramNotifier.sendMessage(chatId,
              `📋 *No plans found for workspace: ${workspace.name}*\n\n` +
              `Create a plan with: \`/plan <steps>\``,
              { parse_mode: 'Markdown' }
            );
            await manager.close();
            return;
          }

          // Format plans list
          let message = `📋 *Plans for workspace: ${workspace.name}*\n\n`;

          // Group plans by status
          const pendingPlans = plans.filter(p => p.status === 'pending');
          const inProgressPlans = plans.filter(p => p.status === 'in_progress');
          const completedPlans = plans.filter(p => p.status === 'completed');
          const failedPlans = plans.filter(p => p.status === 'failed');

          if (inProgressPlans.length > 0) {
            message += `*🔵 In Progress:*\n`;
            inProgressPlans.forEach(plan => {
              const currentStep = plan.current_step || 0;
              const totalSteps = plan.steps.length;
              const progress = totalSteps > 0 ? Math.round((currentStep / totalSteps) * 100) : 0;
              message += `• \`${plan.plan_id}\` - ${plan.title} (${currentStep}/${totalSteps} steps, ${progress}%)\n`;
            });
            message += '\n';
          }

          if (pendingPlans.length > 0) {
            message += `*⏸️ Pending:*\n`;
            pendingPlans.forEach(plan => {
              message += `• \`${plan.plan_id}\` - ${plan.title} (${plan.steps.length} steps)\n`;
            });
            message += '\n';
          }

          if (completedPlans.length > 0) {
            message += `*✅ Completed:*\n`;
            completedPlans.slice(0, 5).forEach(plan => {  // Show only last 5 completed
              const metadata = typeof plan.metadata === 'string'
                ? JSON.parse(plan.metadata || '{}')
                : (plan.metadata || {});

              // Truncate title if too long
              const shortTitle = plan.title.length > 50
                ? plan.title.substring(0, 47) + '...'
                : plan.title;

              let planLine = `• \`${plan.plan_id}\` - ${shortTitle}`;

              // Add commit info if available
              if (metadata.yolo_commit) {
                // Truncate commit message if needed for Telegram
                const shortMsg = metadata.yolo_commit.message.length > 40
                  ? metadata.yolo_commit.message.substring(0, 37) + '...'
                  : metadata.yolo_commit.message;
                planLine += `\n  └ 📝 \`${metadata.yolo_commit.hash}\` ${shortMsg}`;
              }

              message += planLine + '\n';
            });
            if (completedPlans.length > 5) {
              message += `  _...and ${completedPlans.length - 5} more_\n`;
            }
            message += '\n';
          }

          if (failedPlans.length > 0) {
            message += `*❌ Failed:*\n`;
            failedPlans.slice(0, 3).forEach(plan => {  // Show only last 3 failed
              message += `• \`${plan.plan_id}\` - ${plan.title}\n`;
            });
            if (failedPlans.length > 3) {
              message += `  _...and ${failedPlans.length - 3} more_\n`;
            }
            message += '\n';
          }

          message += `\n*Total:* ${plans.length} plans`;

          // Add help about purge command
          message += `\n\n💡 *Tip:* Use \`/purge confirm\` to clean ALL plans (pending, in-progress, and completed)`;

          // Add action buttons
          const options = { parse_mode: 'Markdown' };
          const buttons = [];

          // Add /next button if there are pending or in-progress plans
          if (pendingPlans.length > 0 || inProgressPlans.length > 0) {
            buttons.push({
              text: '▶️ Next Step',
              callback_data: JSON.stringify({ a: 'next' })
            });
          }

          // Add yolo button if there are pending plans
          if (pendingPlans.length > 0) {
            buttons.push({
              text: '🚀 YOLO Execute All',
              callback_data: JSON.stringify({ a: 'yolo' })
            });
          }

          // Add cancel button if there are in-progress plans
          if (inProgressPlans.length > 0) {
            buttons.push({
              text: '⏹️ Cancel In-Progress',
              callback_data: JSON.stringify({ a: 'cancel_progress' })
            });
          }

          if (completedPlans.length > 0) {
            buttons.push({
              text: '🧹 Cleanup Completed',
              callback_data: JSON.stringify({ a: 'cleanup' })
            });
          }

          if (failedPlans.length > 0) {
            buttons.push({
              text: '❌ Cleanup Failed',
              callback_data: JSON.stringify({ a: 'cleanup_failed' })
            });
          }

          if (buttons.length > 0) {
            options.reply_markup = {
              inline_keyboard: [buttons]
            };
          }

          await this.telegramNotifier.sendMessage(chatId, message, options);
          await manager.close();

        } catch (error) {
          logger.error(`Failed to list plans: ${error.message}`);
          await this.telegramNotifier.sendMessage(chatId,
            `❌ Failed to list plans: ${error.message}`,
            { parse_mode: 'Markdown' }
          );
        }
        break;

      case '/next':
        // Handle plan execution
        try {
          const { WorkspaceManager } = await import('./workspace-manager.js');
          const manager = new WorkspaceManager();
          await manager.initialize();

          // Get workspace for this chat
          let workspace = await manager.getWorkspaceForTelegramChat(String(chatId));
          if (!workspace) {
            // In gateway mode, ensure gateway workspace exists in database
            if (config.gateway.enabled) {
              workspace = await manager.ensureGatewayWorkspace();
              logger.debug('Gateway mode: Using gateway workspace for Telegram /next');
            } else {
              await this.telegramNotifier.sendMessage(chatId,
                `❌ *No workspace connected*\n\n` +
                `Connect to a workspace first:\n` +
                `1. Generate token: \`ani-code workspace token gen\`\n` +
                `2. Connect: \`/connect <token>\``,
                { parse_mode: 'Markdown' }
              );
              await manager.close();
              return;
            }
          }

          // Get the plan
          let plan;
          if (args) {
            plan = await manager.getPlan(workspace.id, args);
            if (!plan) {
              await this.telegramNotifier.sendMessage(chatId,
                `❌ Plan not found: ${args}`,
                { parse_mode: 'Markdown' }
              );
              await manager.close();
              return;
            }
          } else {
            plan = await manager.getNextPlan(workspace.id);
            if (!plan) {
              await this.telegramNotifier.sendMessage(chatId,
                `❌ *No pending plans found*\n\n` +
                `Create a plan with: \`/plan <steps>\``,
                { parse_mode: 'Markdown' }
              );
              await manager.close();
              return;
            }
          }

          // Show plan and execute first step
          let message = `📋 *Executing Plan: ${plan.title}*\n\n`;
          message += `ID: \`${plan.plan_id}\`\n`;
          message += `Status: ${plan.status}\n\n`;
          message += `*Steps:*\n`;

          const steps = normalizePlanSteps(plan.steps || []);
          plan.steps = steps;
          const currentStep = plan.current_step || 0;

          steps.forEach((step, index) => {
            const status = index < currentStep ? '✅' :
                          index === currentStep ? '▶️' :
                          '⏸️';
            message += `${status} ${index + 1}. ${getPlanStepDisplayText(step)}\n`;
          });

          await this.telegramNotifier.sendMessage(chatId, message, { parse_mode: 'Markdown' });

          if (currentStep < steps.length) {
            // Execute the current step
            const stepInfo = normalizePlanStep(steps[currentStep]);
            const stepDisplay = getPlanStepDisplayText(stepInfo);

            // Update plan status
            await manager.updatePlanStatus(workspace.id, plan.plan_id, 'in_progress', currentStep);

            // Create task for this step
            const taskName = `plan-${plan.plan_id}-step-${currentStep + 1}`;
            const taskOptions = {
              cwd: workspace.path,
              source: 'telegram_plan',
              chatId: `telegram:${chatId}`,
              planId: plan.plan_id,
              stepIndex: currentStep
            };

            if (stepInfo.providerId) {
              taskOptions.providerId = stepInfo.providerId;
            }
            if (stepInfo.model) {
              taskOptions.model = stepInfo.model;
            }

            const task = this.taskMonitor.addTask(
              taskName,
              stepInfo.command,
              taskOptions
            );

            await this.telegramNotifier.sendMessage(chatId,
              `🚀 *Executing step ${currentStep + 1}/${steps.length}*\n\n${stepDisplay}\n\nTask ID: \`${task.id}\``,
              { parse_mode: 'Markdown' }
            );

            // Update to next step
            await manager.updatePlanStatus(workspace.id, plan.plan_id, 'in_progress', currentStep + 1);

            // If all steps completed, mark as done
            if (currentStep + 1 >= steps.length) {
              await manager.updatePlanStatus(workspace.id, plan.plan_id, 'completed');
            }
          } else {
            await this.telegramNotifier.sendMessage(chatId,
              `✅ Plan already completed!`,
              { parse_mode: 'Markdown' }
            );
          }

          await manager.close();

        } catch (error) {
          logger.error(`Failed to execute plan: ${error.message}`);
          await this.telegramNotifier.sendMessage(chatId,
            `❌ Failed to execute plan: ${error.message}`,
            { parse_mode: 'Markdown' }
          );
        }
        break;

      case '/yolo':
        // YOLO mode: Execute all pending plans with commits in between
        // Parse delay parameter (e.g., /yolo 4h)
        let delayMs = 0;
        if (args) {
          const delayMatch = args.match(/^(\d+)([hm])$/);
          if (delayMatch) {
            const value = parseInt(delayMatch[1]);
            const unit = delayMatch[2];
            delayMs = unit === 'h' ? value * 60 * 60 * 1000 : value * 60 * 1000;

            // Store the scheduled time for status display
            const scheduledTime = new Date(Date.now() + delayMs);
            const timeString = scheduledTime.toLocaleTimeString('en-GB', {
              hour12: false,
              hour: '2-digit',
              minute: '2-digit'
            });

            await this.telegramNotifier.sendMessage(chatId,
              `⏰ *YOLO Scheduled*\n\n` +
              `Will start automatically at: ${timeString}\n` +
              `Delay: ${args}\n\n` +
              `✅ Protection mode is now active\n` +
              `Use /stopyolo to cancel`,
              { parse_mode: 'Markdown' }
            );

            // Set protection mode immediately
            try {
              const { WorkspaceManager } = await import('./workspace-manager.js');
              const manager = new WorkspaceManager();
              await manager.initialize();

              const workspace = await manager.getWorkspaceForTelegramChat(String(chatId));
              if (workspace) {
                await manager.setYoloModeActive(workspace.id, true, null, 0, scheduledTime.toISOString());
              }
              await manager.close();
            } catch (error) {
              logger.error('Failed to set scheduled YOLO protection:', error);
            }
          } else {
            await this.telegramNotifier.sendMessage(chatId,
              `❌ Invalid delay format\n\n` +
              `Use: /yolo [delay]\n` +
              `Examples:\n` +
              `• /yolo 30m - Start after 30 minutes\n` +
              `• /yolo 4h - Start after 4 hours`,
              { parse_mode: 'Markdown' }
            );
            return;
          }
        }

        // Run in background - don't await to avoid blocking the response
        if (delayMs > 0) {
          // Store timeout for cancellation
          if (!this.scheduledYoloTimeouts) {
            this.scheduledYoloTimeouts = new Map();
          }

          // Clear any existing timeout for this chat
          if (this.scheduledYoloTimeouts.has(chatId)) {
            clearTimeout(this.scheduledYoloTimeouts.get(chatId));
          }

          // Schedule the YOLO execution
          const timeoutId = setTimeout(() => {
            this.scheduledYoloTimeouts.delete(chatId);
            this.handleYoloCommand(chatId, true).catch(error => {
              logger.error(`Scheduled YOLO command failed:`, error);
              this.telegramNotifier.sendMessage(chatId,
                `❌ Scheduled YOLO mode failed: ${error.message}`,
                { parse_mode: 'Markdown' }
              );
            });
          }, delayMs);

          this.scheduledYoloTimeouts.set(chatId, timeoutId);
        } else {
          // Execute immediately
          this.handleYoloCommand(chatId).catch(error => {
            logger.error(`YOLO command failed:`, error);
            this.telegramNotifier.sendMessage(chatId,
              `❌ YOLO mode failed: ${error.message}`,
              { parse_mode: 'Markdown' }
            );
          });
        }
        break;

      case '/stoploop':
        logger.info(`Handling /stoploop command for chat ${chatId}`);
        if (this.goalLoopStates && this.goalLoopStates.has(chatId)) {
          const state = this.goalLoopStates.get(chatId);
          if (state.isActive) {
            state.isActive = false;

            // Cancel current task if running
            if (state.currentTaskId) {
              try {
                const task = this.taskMonitor.getTask(state.currentTaskId);
                if (task && (task.status === 'pending' || task.status === 'running')) {
                  this.taskMonitor.cancelTask(state.currentTaskId);
                }
              } catch (error) {
                logger.error(`Failed to cancel goal loop task: ${error.message}`);
              }
            }

            // Update status message to stopped
            await this.updateGoalLoopMessage(chatId, state, 'stopped');

            // Clean up state
            this.goalLoopStates.delete(chatId);

            await this.telegramNotifier.sendMessage(chatId,
              `✅ Goal loop stopped successfully.`,
              { parse_mode: 'Markdown' }
            );
          } else {
            await this.telegramNotifier.sendMessage(chatId,
              `ℹ️ No active goal loop to stop.`,
              { parse_mode: 'Markdown' }
            );
          }
        } else {
          await this.telegramNotifier.sendMessage(chatId,
            `ℹ️ No goal loop is currently running.`,
            { parse_mode: 'Markdown' }
          );
        }
        break;

      case '/stopyolo':
        // Check for scheduled YOLO first
        if (this.scheduledYoloTimeouts && this.scheduledYoloTimeouts.has(chatId)) {
          clearTimeout(this.scheduledYoloTimeouts.get(chatId));
          this.scheduledYoloTimeouts.delete(chatId);

          // Clear protection mode
          try {
            const { WorkspaceManager } = await import('./workspace-manager.js');
            const manager = new WorkspaceManager();
            await manager.initialize();

            const workspace = await manager.getWorkspaceForTelegramChat(String(chatId));
            if (workspace) {
              await manager.clearYoloProtection(workspace.id);
            }
            await manager.close();
          } catch (error) {
            logger.error('Failed to clear scheduled YOLO protection:', error);
          }

          await this.telegramNotifier.sendMessage(chatId,
            `⏰ *Scheduled YOLO Cancelled*\n\n` +
            `✅ Protection mode disabled\n` +
            `The scheduled execution has been cancelled.`,
            { parse_mode: 'Markdown' }
          );
          break;
        }

        // Stop ongoing YOLO execution
        if (this.yoloStates && this.yoloStates.has(chatId)) {
          const state = this.yoloStates.get(chatId);
          state.isActive = false;

          // Clear the status update interval
          if (state.statusUpdateInterval) {
            clearInterval(state.statusUpdateInterval);
            state.statusUpdateInterval = null;
            logger.info('Cleared YOLO status update interval');
          }

          // Cancel any currently running yolo tasks
          try {
            const status = this.taskMonitor.getStatus();
            const runningYoloTasks = status.running.filter(task =>
              task.metadata && task.metadata.source === 'yolo'
            );

            for (const task of runningYoloTasks) {
              logger.info(`Cancelling running YOLO task: ${task.name} (${task.id})`);
              this.taskMonitor.cancelTask(task.id);
            }
          } catch (error) {
            logger.error('Failed to cancel running yolo tasks:', error);
          }

          // Clear the protection mode
          if (this.telegramNotifier && this.telegramNotifier.clearYoloProtection) {
            this.telegramNotifier.clearYoloProtection(chatId);
          }

          // Clear YOLO mode in database
          try {
            const { WorkspaceManager } = await import('./workspace-manager.js');
            const manager = new WorkspaceManager();
            await manager.initialize();

            // Get workspace for this chat
            const mapping = await manager.getWorkspaceForTelegramChat(chatId);
            if (mapping && mapping.id) {
              await manager.clearYoloProtection(mapping.id);
              logger.info(`Cleared YOLO protection for workspace ${mapping.id}`);
            }

            await manager.close();
          } catch (error) {
            logger.error('Failed to clear YOLO mode in database:', error);
          }

          // Calculate cost if available
          let costInfo = '';
          if (this.taskMonitor.usageReporter && state.initialSnapshot) {
            const stopSnapshot = await this.taskMonitor.usageReporter.createTaskCompletionSnapshot('yolo-session', 'YOLO Session (Stopped)', { source: 'yolo' });
            if (stopSnapshot) {
              const duration = Math.round((new Date() - state.startTime) / 1000);
              const formattedDuration = duration >= 60
                ? `${Math.floor(duration / 60)}m ${duration % 60}s`
                : `${duration}s`;
              costInfo = `\n💰 Cost so far: $${stopSnapshot.cost.toFixed(4)}\n` +
                        `🔤 Tokens used: ${stopSnapshot.tokens.toLocaleString()}\n` +
                        `⏱️ Duration: ${formattedDuration}`;
            }
          }

          await this.telegramNotifier.sendMessage(chatId,
            `⛔ *YOLO mode stopped*\n\n` +
            `✅ Protection mode disabled\n` +
            `Current progress: Plan ${state.currentPlanIndex + 1}\n` +
            `Executed: ${state.executedPlans.length} plans` +
            costInfo,
            { parse_mode: 'Markdown' }
          );
        } else {
          // Even if no in-memory state, check and clear database flag
          let workspaceCleared = false;
          try {
            const { WorkspaceManager } = await import('./workspace-manager.js');
            const manager = new WorkspaceManager();
            await manager.initialize();

            // Try multiple approaches to find and clear the workspace
            let workspaceId = null;

            // First try: Get workspace via telegram mapping
            try {
              const mapping = await manager.getWorkspaceForTelegramChat(chatId);
              if (mapping && mapping.id) {
                workspaceId = mapping.id;
                logger.info(`[/stopyolo] Found workspace via telegram mapping: ${workspaceId}`);
              }
            } catch (mappingError) {
              logger.warn(`[/stopyolo] Failed to get telegram mapping: ${mappingError.message}`);
            }

            // Second try: Get workspace via workdir setting
            if (!workspaceId) {
              const fullChatId = `telegram:${chatId}`;
              const workdirName = this.chatSettings.getWorkdir(fullChatId);
              if (workdirName) {
                const availableWorkdirs = await this.getAvailableWorkdirs(fullChatId);
                const workdirPath = availableWorkdirs[workdirName];
                if (workdirPath) {
                  const workspace = await manager.getWorkspaceByPath(workdirPath);
                  if (workspace) {
                    workspaceId = workspace.id;
                    logger.info(`[/stopyolo] Found workspace via workdir path: ${workspaceId}`);
                  }
                }
              }
            }

            // If we found a workspace, clear its protection
            if (workspaceId) {
              // First check if it has YOLO protection
              const workspace = await manager.getWorkspace(workspaceId);
              if (workspace && workspace.yolo_mode_active) {
                // Clear the protection
                await manager.clearYoloProtection(workspaceId);
                workspaceCleared = true;
                logger.info(`[/stopyolo] Cleared orphaned YOLO protection for workspace ${workspaceId}`);

                await this.telegramNotifier.sendMessage(chatId,
                  `⛔ *YOLO protection cleared*\n\n` +
                  `✅ Protection mode disabled\n` +
                  `You can now run manual tasks again.`,
                  { parse_mode: 'Markdown' }
                );
              } else {
                logger.info(`[/stopyolo] Workspace ${workspaceId} does not have YOLO protection active`);
              }
            } else {
              logger.warn('[/stopyolo] Could not find workspace for telegram chat to clear YOLO protection');
            }

            await manager.close();
          } catch (error) {
            logger.error('[/stopyolo] Failed to check YOLO mode in database:', {
              error: error.message,
              stack: error.stack
            });
          }

          if (!workspaceCleared) {
            await this.telegramNotifier.sendMessage(chatId,
              `ℹ️ No active YOLO execution to stop`,
              { parse_mode: 'Markdown' }
            );
          }
        }
        break;

      case '/purge':
        // Handle force reset of all plans (dangerous operation)
        try {
          const { WorkspaceManager } = await import('./workspace-manager.js');
          const manager = new WorkspaceManager();
          await manager.initialize();

          // Get workspace for this chat
          let workspace = await manager.getWorkspaceForTelegramChat(String(chatId));
          if (!workspace) {
            // In gateway mode, ensure gateway workspace exists in database
            if (config.gateway.enabled) {
              workspace = await manager.ensureGatewayWorkspace();
              logger.debug('Gateway mode: Using gateway workspace for Telegram /purge');
            } else {
              await this.telegramNotifier.sendMessage(chatId,
                `❌ *No workspace connected*\n\n` +
                `Connect to a workspace first:\n` +
                `1. Generate token: \`ani-code workspace token gen\`\n` +
                `2. Connect: \`/connect <token>\``,
                { parse_mode: 'Markdown' }
              );
              await manager.close();
              return;
            }
          }

          // Check for confirmation flag
          const confirmFlag = args && (args === 'confirm' || args === '-y' || args === '--yes');
          if (!confirmFlag) {
            await this.telegramNotifier.sendMessage(chatId,
              `⚠️ *WARNING: Dangerous Operation!*\n\n` +
              `This will permanently delete ALL plans in workspace "${workspace.name}":\n` +
              `• ⏸️ Pending plans\n` +
              `• 🔵 In-progress plans\n` +
              `• ✅ Completed plans\n` +
              `• ❌ Failed plans\n\n` +
              `To confirm, run: \`/purge confirm\``,
              { parse_mode: 'Markdown' }
            );
            await manager.close();
            return;
          }

          // Force reset ALL plans (no status filter)
          const result = await manager.resetPlans(workspace.id);

          await this.telegramNotifier.sendMessage(chatId,
            `🗑️ *All plans purged successfully*\n\n` +
            `Workspace: ${workspace.name}\n` +
            `Plans removed: ${result.deleted}\n\n` +
            `The workspace is now clean and ready for new plans.`,
            { parse_mode: 'Markdown' }
          );

          await manager.close();

        } catch (error) {
          logger.error(`Failed to purge plans for Telegram chat ${chatId}:`, error);
          await this.telegramNotifier.sendMessage(chatId,
            `❌ Failed to purge plans: ${error.message}`,
            { parse_mode: 'Markdown' }
          );
        }
        break;

      case '/connect':
        if (!args) {
          await this.telegramNotifier.sendMessage(chatId,
            `❌ Please provide a token after /connect\n\n` +
            `Usage: \`/connect <token>\`\n\n` +
            `Generate a token from your workspace:\n` +
            `\`ani-code workspace token <workspace-name>\``,
            { parse_mode: 'Markdown' }
          );
          return;
        }
        await this.handleTelegramConnect(chatId, args);
        break;
        
      case '/disconnect':
        await this.handleTelegramDisconnect(chatId);
        break;
        
      case '/shell':
        if (!args) {
          await this.telegramNotifier.sendMessage(chatId, '❌ Please provide a command after /shell');
          return;
        }
        await this.createTelegramTask(chatId, 'shell', args);
        break;
        
      case '/cancel':
        if (args) {
          await this.cancelTelegramTask(chatId, args);
        } else {
          await this.telegramNotifier.sendMessage(chatId, '❌ Please provide task ID after /cancel');
        }
        break;
        
      case '/progress':
        if (args) {
          await this.handleProgressCommand(chatId, args);
        } else {
          await this.telegramNotifier.sendMessage(chatId, '❌ Please provide task ID after /progress\n\nExample: /progress abc123');
        }
        break;

      case '/here':
        logger.info(`Handling /here command for chat ${chatId}`);
        await this.handleHereCommand(chatId, args);
        break;

      case '/url':
        logger.info(`Handling /url command for chat ${chatId}`);
        await this.handleTelegramUrlCommand(chatId);
        break;

      case '/img':
        logger.info(`Handling /img command for chat ${chatId}`);
        await this.handleTelegramImgCommand(chatId);
        break;

      case '/check':
        logger.info(`Handling /check command for chat ${chatId}`);
        await this.handleCheckCommand(chatId, args, 'telegram');
        break;

      case '/remember':
        logger.info(`Handling /remember command for chat ${chatId}`);
        await this.handleRememberCommand(chatId, args, message);
        break;

      case '/print':
        logger.info(`Handling /print command for chat ${chatId}`);
        await this.handlePrintCommand(chatId);
        break;

      case '/macros':
        logger.info(`Handling /macros command for chat ${chatId}`);
        await this.handleMacrosCommand(chatId, args);
        break;

      case '/cheatsheet':
        logger.info(`Handling /cheatsheet command for chat ${chatId}`);
        await this.handleCheatsheetCommand(chatId);
        break;

      // Goal management commands
      case '/goal':
      case '/goals':
        logger.info(`Handling /goals command for chat ${chatId}`);
        await this.handleGoalsCommand(chatId, args, 'telegram');
        break;

      case '/goaladd':
        logger.info(`Handling /goaladd command for chat ${chatId}`);
        await this.handleGoalAddCommand(chatId, args, 'telegram');
        break;

      case '/goaladdmulti':
        logger.info(`Handling /goaladdmulti command for chat ${chatId}`);
        await this.handleGoalAddCommand(chatId, args, 'telegram', { multi: true });
        break;

      case '/goalcheck':
        logger.info(`Handling /goalcheck command for chat ${chatId}`);
        await this.handleGoalCheckCommand(chatId, 'telegram');
        break;

      case '/goalloop':
        logger.info(`Handling /goalloop command for chat ${chatId}`);
        await this.handleGoalLoopCommand(chatId, args, 'telegram');
        break;

      case '/goalsync':
        logger.info(`Handling /goalsync command for chat ${chatId}`);
        await this.handleGoalSyncCommand(chatId, args, 'telegram');
        break;

      case '/goalreview':
        logger.info(`Handling /goalreview command for chat ${chatId}`);
        await this.handleGoalReviewCommand(chatId, args, 'telegram');
        break;

      case '/healthcheck':
        logger.info(`Handling /healthcheck command for chat ${chatId}`);
        await this.handleHealthcheckCommand(chatId, args, 'telegram');
        break;

      case '/chatui':
        logger.info(`Handling /chatui command for chat ${chatId}`);
        await this.handleChatUICommand(chatId, args);
        break;

        default:
          await this.telegramNotifier.sendMessage(chatId,
            `❓ Unknown command: ${command}\n\nType /help for available commands`);
          return { success: false, handler: 'unknown_command', command };
      }
    
      // Return success result for known commands
      return { success: true, handler: 'telegram_command', command: command.replace('/', '') };
    } catch (error) {
      logger.error(`🚨 CRITICAL: Uncaught error in processTelegramCommand`, {
        error: error.message,
        stack: error.stack,
        command: text?.substring(0, 50),
        originalMessageText: message?.text || message?.caption || 'N/A',
        chatId,
        messageId: message?.message_id,
        messageType: message?.text ? 'text' : (message?.caption ? 'caption' : 'unknown')
      });
      
      // Try to notify the user
      try {
        if (this.telegramNotifier) {
          await this.telegramNotifier.sendMessage(chatId,
            `❌ Failed to process command.\n\n` +
            `Error: ${error.message?.substring(0, 100) || 'Unknown error'}\n\n` +
            `Please try again or contact support.`,
            { parse_mode: 'Markdown' }
          );
        }
      } catch (notifyError) {
        logger.error('Failed to notify user of command error:', notifyError);
      }
      
      return { success: false, handler: 'error', error: error.message };
    }
  }

  async showTelegramStatus(chatId) {
    const fullChatId = `telegram:${chatId}`;
    const { statusMessage, gitActionButtons } = await this.generateStatusMessage(fullChatId);

    // Sanitize the status message for Telegram
    let sanitizedMessage = this.telegramNotifier.sanitizeMessageForTelegram(statusMessage);

    // Telegram has a 4096 character limit for messages
    const TELEGRAM_MESSAGE_LIMIT = 4000; // Leave some buffer for markdown parsing
    if (sanitizedMessage.length > TELEGRAM_MESSAGE_LIMIT) {
      // Truncate the message and add a note
      sanitizedMessage = sanitizedMessage.substring(0, TELEGRAM_MESSAGE_LIMIT - 50) + '\n\n...[Message truncated due to length]';
      logger.warn(`Status message truncated from ${statusMessage.length} to ${sanitizedMessage.length} characters for Telegram`);
    }

    // Convert Lark-style buttons to Telegram inline keyboard
    const keyboard = { inline_keyboard: [] };
    if (gitActionButtons && gitActionButtons.length > 0) {
      const row = [];
      gitActionButtons.forEach(button => {
        row.push({
          text: button.text.content,
          callback_data: button.value
        });
        if (row.length === 3) {
          keyboard.inline_keyboard.push([...row]);
          row.length = 0;
        }
      });
      if (row.length > 0) {
        keyboard.inline_keyboard.push(row);
      }
    }

    const options = { parse_mode: 'Markdown' };
    if (keyboard.inline_keyboard.length > 0) {
      options.reply_markup = keyboard;
    }

    await this.telegramNotifier.sendMessage(chatId, sanitizedMessage, options);
  }

  async showTaskProgress(chatId, taskId) {
    try {
      // Ensure chatId is a string (Telegram sends numeric IDs)
      chatId = String(chatId);

      // Ensure telegramNotifier is initialized
      if (!this.telegramNotifier) {
        const { TelegramNotifier } = await import('./telegram-notifier.js');
        this.telegramNotifier = new TelegramNotifier();
      }

      // Resolve display mode for this chat
      const fullChatId = chatId.includes(':') ? chatId : `telegram:${chatId}`;
      const displayModeManager = new DisplayModeManager(this.chatSettings);
      const displayMode = displayModeManager.getDisplayMode(fullChatId);

      if (!taskId) {
        await this.telegramNotifier.sendMessage(chatId,
          '❌ Please provide a task ID\n\nUsage: `/process <task-id>`',
          { parse_mode: 'Markdown' });
        return;
      }

      // Get task details
      const task = this.taskMonitor.getTaskById(taskId.trim());
      if (!task) {
        await this.telegramNotifier.sendMessage(chatId,
          `❌ Task not found: \`${taskId}\``,
          { parse_mode: 'Markdown' });
        return;
      }

      // Check if workspace is in YOLO mode using utility
      const { isWorkspaceInYoloMode } = await import('./utils/workspace-utils.js');
      if (task.cwd && await isWorkspaceInYoloMode(task.cwd)) {
        await this.telegramNotifier.sendMessage(chatId,
          `⚠️ Progress tracking is disabled during YOLO execution.\n\nYOLO status is being shown in the main status message.`,
          { parse_mode: 'Markdown' });
        return;
      }

      // Generate enhanced progress message with git status
      let progressMessage = await this.generateEnhancedTaskProgressMessage(taskId, displayMode);
      progressMessage = this.telegramNotifier.sanitizeMessageForTelegram(progressMessage);

      // Check if task is already completed
      if (task.status === 'completed' || task.status === 'failed' || task.status === 'cancelled' || task.status === 'error') {
        // Just send a static message for completed tasks
        await this.telegramNotifier.sendMessage(chatId, progressMessage, {
          parse_mode: 'Markdown',
          reply_markup: this.getTaskProgressKeyboard(task)
        });
        return;
      }

      // Send initial progress message (using telegramNotifier for proper sanitization)
      const sentMessage = await this.telegramNotifier.api.sendMessage(chatId, progressMessage, {
        parse_mode: 'Markdown',
        reply_markup: this.getTaskProgressKeyboard(task)
      });

      // Handle both direct Telegram API response and gateway mode response
      const isSuccess = sentMessage.ok || sentMessage.success;
      if (!isSuccess) {
        logger.error('Failed to send initial progress message:', sentMessage);
        return;
      }

      // Extract message_id - gateway mode may return it in platform_response, direct API returns it in result
      const messageId = sentMessage.platform_response?.result?.message_id || sentMessage.result?.message_id || sentMessage.message_id;

      logger.info(`[Progress] Started tracking task ${taskId}, msg:${messageId}`);

      // Critical check: if messageId is missing, log error and abort tracking
      if (!messageId) {
        logger.error(`❌ CRITICAL: Failed to extract messageId from gateway response - cannot track progress`, {
          taskId,
          chatId,
          sentMessageKeys: Object.keys(sentMessage),
          fullResponse: JSON.stringify(sentMessage).substring(0, 500)
        });
        // Cannot track progress without messageId - abort
        await this.telegramNotifier.sendMessage(chatId,
          `⚠️ Warning: Progress tracking could not be started for task ${taskId} due to missing message ID from gateway response.`,
          { parse_mode: 'Markdown' });
        return;
      }

      // Set up progress tracking with auto-updates every 10 seconds
      const trackerKey = `${chatId}:${taskId}`;
      
      // Clear any existing tracker for this task
      if (this.progressTrackers.has(trackerKey)) {
        const existingTracker = this.progressTrackers.get(trackerKey);
        clearInterval(existingTracker.interval);
        this.progressTrackers.delete(trackerKey);
      }
      
      // Check if autopin is enabled for this workspace (autopin is the default)
      let shouldAutoPin = true;
      try {
        const { WorkspaceManager, getShowProgressMode } = await import('./workspace-manager.js');
        const manager = new WorkspaceManager();
        await manager.initialize();
        const workspace = await manager.getWorkspaceByPath(task.cwd);
        shouldAutoPin = getShowProgressMode(workspace) === 'autopin';
        await manager.close();
      } catch (error) {
        logger.debug(`Failed to check autopin setting: ${error.message}`);
      }

      // Pin the message if autopin is enabled
      if (shouldAutoPin) {
        try {
          await this.telegramNotifier.pinChatMessage(chatId, messageId, { disable_notification: true });
        } catch (error) {
          logger.warn(`[AUTO-PIN] Failed to pin message: ${error.message}`);
        }
      }

      // Create new progress tracker
      const tracker = {
        chatId,
        taskId,
        messageId,
        displayMode,
        startTime: Date.now(),
        updateCount: 0,
        lastRecallTime: Date.now(), // Track when message was last recalled
        interval: null,
        isPinned: shouldAutoPin // Track if message is pinned
      };
      
      // Set up interval to update every 10 seconds
      const updateInterval = 10000; // 10 seconds
      const recallInterval = 5 * 60 * 1000; // 5 minutes for recall
      const maxDuration = 30 * 60 * 1000; // 30 minutes max tracking
      
      tracker.interval = setInterval(async () => {
        try {
          tracker.updateCount++;
          
          // Check if max duration exceeded
          if (Date.now() - tracker.startTime > maxDuration) {
            logger.info(`Progress tracking for task ${taskId} exceeded max duration, stopping`);
            clearInterval(tracker.interval);
            this.progressTrackers.delete(trackerKey);

            // Get workspace name for logging
            const { basename } = await import('path');
            const workspaceName = task.cwd ? basename(task.cwd) : 'system';

            // Send final timeout message (using telegramNotifier for proper sanitization)
            let timeoutMessage = await this.generateEnhancedTaskProgressMessage(taskId, tracker.displayMode);
            timeoutMessage = this.telegramNotifier.sanitizeMessageForTelegram(timeoutMessage);
            await this.telegramNotifier.editMessage(
              chatId,
              tracker.messageId,
              timeoutMessage,
              {
                parse_mode: 'Markdown',
                reply_markup: this.getTaskProgressKeyboard(task),
                workspaceName: workspaceName
              }
            );
            return;
          }
          
          // Get updated task status
          const currentTask = this.taskMonitor.getTaskById(taskId);
          if (!currentTask) {
            // Task no longer exists
            clearInterval(tracker.interval);
            this.progressTrackers.delete(trackerKey);
            return;
          }
          
          // Check if task completed
          if (currentTask.status === 'completed' || currentTask.status === 'failed' || 
              currentTask.status === 'cancelled' || currentTask.status === 'error') {
            logger.info(`Task ${taskId} ${currentTask.status}, stopping progress tracking interval`);
            // Don't clear the tracker here - let the task-monitor handle it when sending the completion notification
            // This way the task-monitor can get the messageId and update it with full completion details including cost
            clearInterval(tracker.interval);
            // Keep the tracker in the map so task-monitor can find it
            tracker.interval = null; // Mark interval as cleared
            return;
          }
          
          // Check if we should recall the message (delete and resend) to keep it at newest position
          const timeSinceLastRecall = Date.now() - tracker.lastRecallTime;
          if (timeSinceLastRecall >= recallInterval) {
            logger.info(`Recalling progress message for task ${taskId} to keep it at newest position (after ${Math.floor(timeSinceLastRecall / 60000)} minutes)`);

            try {
              // Get workspace name for logging
              const { basename } = await import('path');
              const workspaceName = currentTask.cwd ? basename(currentTask.cwd) : 'system';

              // Unpin the old message if it was pinned
              if (tracker.isPinned) {
                try {
                  await this.telegramNotifier.unpinChatMessage(chatId, tracker.messageId);
                  logger.info(`[AUTO-PIN] Unpinned old message ${tracker.messageId} before recall`);
                } catch (unpinError) {
                  logger.warn(`[AUTO-PIN] Failed to unpin old message: ${unpinError.message}`);
                }
              }

              // Delete the old message
              await this.telegramNotifier.deleteMessage(chatId, tracker.messageId);

              // Send a new message (using telegramNotifier for proper sanitization)
              let updatedMessage = await this.generateEnhancedTaskProgressMessage(taskId, tracker.displayMode);
              updatedMessage = this.telegramNotifier.sanitizeMessageForTelegram(updatedMessage);
              const newMessage = await this.telegramNotifier.api.sendMessage(chatId, updatedMessage, {
                parse_mode: 'Markdown',
                reply_markup: this.getTaskProgressKeyboard(currentTask),
                workspaceName: workspaceName
              });

              // Handle both direct Telegram API response and gateway mode response
              const isRecallSuccess = newMessage.ok || newMessage.success;
              if (isRecallSuccess) {
                // Update the tracker with new message ID
                tracker.messageId = newMessage.platform_response?.result?.message_id || newMessage.result?.message_id || newMessage.message_id;
                tracker.lastRecallTime = Date.now();

                // Enhanced logging to debug messageId extraction on recall
                logger.info(`Successfully recalled progress message for task ${taskId}`, {
                  messageId: tracker.messageId,
                  extractedFrom: newMessage.platform_response?.result?.message_id ? 'platform_response.result' :
                                 newMessage.result?.message_id ? 'result' :
                                 newMessage.message_id ? 'root' : 'MISSING',
                  responsePreview: JSON.stringify(newMessage).substring(0, 200)
                });

                // Critical check: if messageId is missing after recall, log error
                if (!tracker.messageId) {
                  logger.error(`❌ CRITICAL: Failed to extract messageId from recall response`, {
                    taskId,
                    chatId,
                    fullResponse: JSON.stringify(newMessage).substring(0, 500)
                  });
                }

                // Pin the new message if autopin is enabled
                if (tracker.isPinned) {
                  try {
                    await this.telegramNotifier.pinChatMessage(chatId, tracker.messageId, { disable_notification: true });
                    logger.info(`[AUTO-PIN] Pinned new recalled message ${tracker.messageId}`);
                  } catch (pinError) {
                    logger.warn(`[AUTO-PIN] Failed to pin new message: ${pinError.message}`);
                  }
                }
              } else {
                logger.error(`Failed to send recalled progress message for task ${taskId}:`, newMessage);
              }
            } catch (recallError) {
              logger.error(`Error recalling progress message for task ${taskId}:`, recallError);
              // Continue with regular update if recall fails
            }
          } else {
            // Get workspace name for logging
            const { basename } = await import('path');
            const workspaceName = currentTask.cwd ? basename(currentTask.cwd) : 'system';

            // CRITICAL: Check if tracker has valid messageId before attempting edit
            if (!tracker.messageId) {
              logger.error(`❌ CRITICAL: Cannot edit message - tracker.messageId is undefined`, {
                taskId,
                chatId,
                trackerKey,
                updateCount: tracker.updateCount,
                reason: 'messageId was not properly extracted during initial message send'
              });
              // Skip this update and continue - next update might work if recall succeeds
              return;
            }

            // Regular update (edit existing message, using telegramNotifier for proper sanitization)
            let updatedMessage = await this.generateEnhancedTaskProgressMessage(taskId, tracker.displayMode);
            updatedMessage = this.telegramNotifier.sanitizeMessageForTelegram(updatedMessage);
            const editResult = await this.telegramNotifier.editMessage(
              chatId,
              tracker.messageId,
              updatedMessage,
              {
                parse_mode: 'Markdown',
                reply_markup: this.getTaskProgressKeyboard(currentTask),
                workspaceName: workspaceName
              }
            );

            // Handle both direct Telegram API response and gateway mode response
            const isEditSuccess = editResult.ok || editResult.success;
            const isNotModified = !isEditSuccess && editResult.error_code === 400 &&
                editResult.description && editResult.description.includes('message is not modified');

            if (isNotModified) {
              // Message content hasn't changed, this is OK
              logger.debug(`Progress message for task ${taskId} unchanged at update ${tracker.updateCount}`);
            } else if (isEditSuccess) {
              logger.debug(`Updated progress for task ${taskId} (update ${tracker.updateCount})`);
            } else {
              logger.warn(`Failed to update progress message: ${editResult.description || 'Unknown error'}`);
            }
          }
          
        } catch (error) {
          logger.error(`Error updating progress for task ${taskId}:`, error);
          // Don't stop the tracker on error, try again next interval
        }
      }, updateInterval);
      
      this.progressTrackers.set(trackerKey, tracker);
      
    } catch (error) {
      logger.error(`Error in showTaskProgress for chat ${chatId}:`, error);
      // Only try to send error message if telegramNotifier is initialized
      if (this.telegramNotifier) {
        await this.telegramNotifier.sendMessage(chatId,
          `❌ Error getting task progress: ${error.message}`,
          { parse_mode: 'Markdown' });
      }
    }
  }

  /**
   * Start progress tracking on an existing message (e.g., the started placeholder).
   * Unlike showTaskProgress, this does NOT send a new initial message — it reuses
   * the given messageId and sets up the periodic edit interval.
   * @param {string} chatId - Telegram chat ID (numeric)
   * @param {string} taskId - Task ID to track
   * @param {number} messageId - Existing Telegram message ID to edit
   * @param {string} displayMode - 'simple' or 'full'
   */
  async startProgressTrackingOnMessage(chatId, taskId, messageId, displayMode = 'simple') {
    try {
      if (!this.telegramNotifier) {
        const { TelegramNotifier } = await import('./telegram-notifier.js');
        this.telegramNotifier = new TelegramNotifier();
      }

      const task = this.taskMonitor.getTaskById(taskId);
      if (!task) {
        logger.warn(`[PROGRESS-PLACEHOLDER] Cannot start tracking — task ${taskId} not found`);
        return;
      }

      // Skip if task already completed
      if (task.status === 'completed' || task.status === 'failed' ||
          task.status === 'cancelled' || task.status === 'error') {
        logger.info(`[PROGRESS-PLACEHOLDER] Task ${taskId} already ${task.status}, skipping progress tracking`);
        return;
      }

      const trackerKey = `${chatId}:${taskId}`;

      // Don't double-track
      if (this.progressTrackers.has(trackerKey)) {
        logger.debug(`[PROGRESS-PLACEHOLDER] Progress already tracked for ${trackerKey}`);
        return;
      }

      logger.info(`[PROGRESS-PLACEHOLDER] Starting progress tracking on existing message ${messageId} for task ${taskId} (displayMode=${displayMode})`);

      const { basename } = await import('path');

      // Check if autopin is enabled for this workspace (autopin is the default)
      let shouldAutoPin = true;
      if (task.cwd) {
        try {
          const { WorkspaceManager, getShowProgressMode } = await import('./workspace-manager.js');
          const manager = new WorkspaceManager();
          await manager.initialize();
          const workspace = await manager.getWorkspaceByPath(task.cwd);
          const mode = getShowProgressMode(workspace);
          shouldAutoPin = (mode === 'auto' || mode === 'autopin');
          await manager.close();
        } catch (error) {
          logger.debug(`[PROGRESS-PLACEHOLDER] Failed to check autopin setting: ${error.message}`);
        }
      }

      // Pin the message if autopin is enabled
      if (shouldAutoPin) {
        try {
          await this.telegramNotifier.pinChatMessage(chatId, messageId, { disable_notification: true });
          logger.info(`[AUTO-PIN] Pinned placeholder progress message ${messageId} for task ${taskId}`);
        } catch (pinError) {
          logger.warn(`[AUTO-PIN] Failed to pin placeholder message: ${pinError.message}`);
        }
      }

      const tracker = {
        chatId,
        taskId,
        messageId,
        displayMode,
        startTime: Date.now(),
        updateCount: 0,
        lastRecallTime: Date.now(),
        interval: null,
        isPinned: shouldAutoPin,
        fromPlaceholder: true // Mark that this tracker was created from a started placeholder
      };

      const updateInterval = 10000; // 10s for both modes
      const maxDuration = 30 * 60 * 1000; // 30 minutes max

      // Perform an immediate first update so user sees progress right away
      try {
        const workspaceName = task.cwd ? (await import('path')).basename(task.cwd) : 'system';
        let initialMessage = await this.generateEnhancedTaskProgressMessage(taskId, displayMode);
        initialMessage = this.telegramNotifier.sanitizeMessageForTelegram(initialMessage);
        const firstEdit = await this.telegramNotifier.editMessage(chatId, messageId, initialMessage, {
          parse_mode: 'Markdown',
          reply_markup: this.getTaskProgressKeyboard(task),
          workspaceName
        });
        if (firstEdit.ok || firstEdit.success) {
          logger.info(`[PROGRESS-PLACEHOLDER] Immediate first update sent for task ${taskId}`);
        }
      } catch (firstEditErr) {
        logger.debug(`[PROGRESS-PLACEHOLDER] First immediate update skipped: ${firstEditErr.message}`);
      }

      tracker.interval = setInterval(async () => {
        try {
          tracker.updateCount++;

          if (Date.now() - tracker.startTime > maxDuration) {
            logger.info(`[PROGRESS-PLACEHOLDER] Max duration exceeded for task ${taskId}, stopping`);
            clearInterval(tracker.interval);
            this.progressTrackers.delete(trackerKey);
            return;
          }

          const currentTask = this.taskMonitor.getTaskById(taskId);
          if (!currentTask) {
            clearInterval(tracker.interval);
            this.progressTrackers.delete(trackerKey);
            return;
          }

          if (currentTask.status === 'completed' || currentTask.status === 'failed' ||
              currentTask.status === 'cancelled' || currentTask.status === 'error') {
            logger.info(`[PROGRESS-PLACEHOLDER] Task ${taskId} ${currentTask.status}, stopping progress interval`);
            clearInterval(tracker.interval);
            tracker.interval = null;
            // Keep tracker in map so handleTaskCompleted can find the messageId
            return;
          }

          // Re-read display mode on every tick so /chatui changes take effect immediately
          if (this.chatSettings && currentTask.chatId) {
            const { DisplayModeManager } = await import('./display-mode.js');
            const dm = new DisplayModeManager(this.chatSettings);
            tracker.displayMode = dm.getDisplayMode(currentTask.chatId);
          }

          // Edit the message with updated progress
          const workspaceName = currentTask.cwd ? basename(currentTask.cwd) : 'system';
          let updatedMessage = await this.generateEnhancedTaskProgressMessage(taskId, tracker.displayMode);
          updatedMessage = this.telegramNotifier.sanitizeMessageForTelegram(updatedMessage);

          const editResult = await this.telegramNotifier.editMessage(
            chatId,
            tracker.messageId,
            updatedMessage,
            {
              parse_mode: 'Markdown',
              reply_markup: this.getTaskProgressKeyboard(currentTask),
              workspaceName
            }
          );

          const isEditSuccess = editResult.ok || editResult.success;
          const isNotModified = !isEditSuccess && editResult.error_code === 400 &&
              editResult.description && editResult.description.includes('message is not modified');

          if (isNotModified) {
            logger.debug(`[PROGRESS-PLACEHOLDER] Message unchanged for task ${taskId} at update ${tracker.updateCount}`);
          } else if (isEditSuccess) {
            logger.debug(`[PROGRESS-PLACEHOLDER] Updated progress for task ${taskId} (update ${tracker.updateCount})`);
          } else {
            logger.warn(`[PROGRESS-PLACEHOLDER] Failed to update message: ${editResult.description || 'Unknown error'}`);
          }
        } catch (error) {
          logger.error(`[PROGRESS-PLACEHOLDER] Error updating progress for task ${taskId}: ${error.message}`);
        }
      }, updateInterval);

      this.progressTrackers.set(trackerKey, tracker);
      logger.info(`[PROGRESS-PLACEHOLDER] Progress tracker started for task ${taskId} (interval=${updateInterval}ms)`);
    } catch (error) {
      logger.error(`[PROGRESS-PLACEHOLDER] Failed to start tracking on message ${messageId}: ${error.message}`);
    }
  }

  async generateEnhancedTaskProgressMessage(taskId, displayMode = 'full') {
    try {
      const task = this.taskMonitor.getTaskById(taskId);
      if (!task) {
        return `❌ Task not found`;
      }

      // Ensure telegramNotifier is initialized early
      if (!this.telegramNotifier) {
        const { TelegramNotifier } = await import('./telegram-notifier.js');
        this.telegramNotifier = new TelegramNotifier();
      }

      // Get task status emoji
      let statusEmoji = '';
      let statusText = task.status;
      switch (task.status) {
        case 'pending':
        case 'queued':
          statusEmoji = '⏳';
          statusText = 'Queued';
          break;
        case 'running':
          statusEmoji = '🟡';
          statusText = 'Running';
          break;
        case 'completed':
          statusEmoji = '✅';
          statusText = 'Completed';
          break;
        case 'failed':
        case 'error':
          statusEmoji = '❌';
          statusText = 'Failed';
          break;
        case 'cancelled':
          statusEmoji = '🚫';
          statusText = 'Cancelled';
          break;
        default:
          statusEmoji = '❓';
      }

      // Calculate running time first
      let runningTime = '';
      if (task.startedAt) {
        const startTime = new Date(task.startedAt);
        const endTime = task.completedAt ? new Date(task.completedAt) : new Date();
        const durationMs = endTime - startTime;
        const seconds = Math.floor(durationMs / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);

        if (hours > 0) {
          runningTime = `${hours}h ${minutes % 60}m ${seconds % 60}s`;
        } else if (minutes > 0) {
          runningTime = `${minutes}m ${seconds % 60}s`;
        } else {
          runningTime = `${seconds}s`;
        }
      }

      const isSimple = displayMode === 'simple';

      // Build header based on display mode
      let message;
      if (isSimple) {
        // Simple mode: no header — status line goes at the end (like completion format)
        message = '';
      } else {
        // Full mode: status header + task info
        message = `${statusEmoji} *${runningTime ? runningTime + ' - ' : ''}${statusText}*\n\n`;
        message += `*ID:* \`${task.id}\`\n`;
        const escapedName = this.telegramNotifier.escapeMarkdownContent(task.name);
        message += `*Name:* ${escapedName}\n`;

        if (task.command) {
          const firstLine = task.command.split('\n')[0] || task.command;
          const truncatedPrompt = firstLine.length > 120 ? firstLine.substring(0, 117) + '...' : firstLine;
          const escapedPrompt = this.telegramNotifier.escapeMarkdownContent(truncatedPrompt);
          message += `*Prompt:* ${escapedPrompt}\n`;
        }
      }

      // Get git status for the task's working directory
      // Simple mode: skip git during progress — shown only in completion message
      if (task.cwd && !isSimple) {
        try {
          const { execSync } = await import('child_process');

          // Get current branch
          const branch = execSync('git branch --show-current', {
            cwd: task.cwd,
            encoding: 'utf8',
            timeout: 5000
          }).trim();
          // Only show branch if it's not main or master
          if (branch && branch !== 'main' && branch !== 'master') {
            message += `*🌿 Branch:* \`${branch}\`\n`;
          }

          // Get dirty files
          const statusOutput = execSync('git status --porcelain', {
            cwd: task.cwd,
            encoding: 'utf8',
            timeout: 5000
          }).trim();

          if (statusOutput) {
            const { duringTask, beforeTask } = categorizeGitFilesByTaskTiming(statusOutput, task.cwd, task.startedAt);

            // Get git diff stats with colored text
            let diffStatsText = '';
            const diffStats = await this.getGitDiffStats(task.cwd);
            if (diffStats && (diffStats.insertions > 0 || diffStats.deletions > 0)) {
              diffStatsText = `: +${diffStats.insertions}/-${diffStats.deletions}`;
            }

            if (duringTask.length > 0) {
              message += `\n*📂 Changed* (${duringTask.length} file${duringTask.length === 1 ? '' : 's'}${diffStatsText}):\n\`\`\`\n${duringTask.slice(0, 10).join('\n')}${duringTask.length > 10 ? `\n... and ${duringTask.length - 10} more` : ''}\n\`\`\``;
            }
            if (beforeTask.length > 0) {
              message += `\n*📁 Uncommitted before task* (${beforeTask.length} file${beforeTask.length === 1 ? '' : 's'}):\n\`\`\`\n${beforeTask.slice(0, 5).join('\n')}${beforeTask.length > 5 ? `\n... and ${beforeTask.length - 5} more` : ''}\n\`\`\``;
            }
            if (duringTask.length === 0 && beforeTask.length === 0) {
              message += `*📂 Git Status:* Clean\n`;
            }
          } else {
            message += `*📂 Git Status:* Clean\n`;
          }
        } catch (error) {
          // Not a git repo or error getting status
          logger.debug(`Could not get git status for task ${taskId}: ${error.message}`);
        }
      }

      // Add queue position if pending
      if (task.status === 'pending' || task.status === 'queued') {
        const position = this.taskMonitor.getQueuePosition(task.id);
        if (position > 0) {
          message += `*🎯 Queue Position:* #${position}\n`;
        }
      }

      // Add /print content (last assistant response) for running tasks
      if (task.status === 'running' && task.cwd) {
        try {
          // Check provider type - Claude and customClaude use session files,
          // other providers (gemini, codex) use live stdout buffer
          const providerId = task.providerId || 'claude';

          // Determine if this is a Claude-compatible provider that writes JSONL session files
          // This includes: claude, ccr, glm, and any customClaude handler providers
          let isClaudeProvider = !providerId || providerId === 'claude' ||
            providerId.startsWith('custom') || providerId === 'ccr' || providerId === 'glm';

          // Also check the provider handler - customClaude handlers use ClaudeCliHandler
          // which means they write session files like Claude
          if (!isClaudeProvider) {
            try {
              const { getProviderManager } = await import('./providers/providerManager.js');
              const providerManager = await getProviderManager();
              const handler = providerManager.getHandler(providerId);
              if (handler) {
                // Check if the handler is ClaudeCliHandler (customClaude providers)
                // ClaudeCliHandler has isCustomClaude method
                if (typeof handler.isCustomClaude === 'function') {
                  // This is a ClaudeCliHandler-based provider (claude or customClaude)
                  isClaudeProvider = true;
                  logger.debug(`[PROGRESS-OUTPUT] Provider ${providerId} uses ClaudeCliHandler, treating as Claude-compatible`);
                }
              }
            } catch (e) {
              logger.debug(`[PROGRESS-OUTPUT] Could not check handler type for ${providerId}: ${e.message}`);
            }
          }

          let outputContent = null;
          let outputTruncated = false;

          if (isClaudeProvider) {
            // Use Claude session files for Claude-compatible providers
            // Always find the latest session file (don't use cached) to ensure fresh content like /print
            const printContent = await this.getPrintContentForWorkspace(task.cwd, 800, {
              taskStartTime: task.startedAt
            });
            if (printContent && printContent.content) {
              outputContent = printContent.content;
              outputTruncated = printContent.truncated;
            }
          } else {
            // For non-Claude providers (gemini, codex), use live stdout buffer
            const taskOutput = this.taskMonitor.getTaskOutput(task.id, 'stdout', 50);
            logger.debug(`[PROGRESS-OUTPUT] Task ${task.id} (${providerId}): getTaskOutput returned ${taskOutput ? (Array.isArray(taskOutput) ? taskOutput.length + ' lines' : typeof taskOutput) : 'null'}`);

            if (taskOutput && Array.isArray(taskOutput) && taskOutput.length > 0) {
              // Get last 50 lines and join
              let rawOutput = taskOutput.join('\n');
              logger.debug(`[PROGRESS-OUTPUT] Task ${task.id}: raw output length=${rawOutput.length}`);

              // Apply provider-specific output extraction to clean up verbose output
              const { extractProviderConclusion } = await import('./providers/outputExtractor.js');
              rawOutput = extractProviderConclusion(rawOutput, providerId);
              logger.debug(`[PROGRESS-OUTPUT] Task ${task.id}: after extraction length=${rawOutput.length}`);

              // Truncate with beginning (1/3) and end (2/3) — latest content more useful
              outputTruncated = rawOutput.length > 800;
              let truncatedOutput;
              if (outputTruncated) {
                const startLength = Math.floor(800 / 3) - 15;
                const endLength = Math.floor(800 * 2 / 3) - 15;
                const firstPart = rawOutput.substring(0, startLength);
                const lastPart = rawOutput.substring(rawOutput.length - endLength);
                const hiddenCount = rawOutput.length - startLength - endLength;
                truncatedOutput = `${firstPart}\n... ${hiddenCount} chars hidden ...\n${lastPart}`;
              } else {
                truncatedOutput = rawOutput;
              }
              // Sanitize for safe inclusion in Telegram code block
              outputContent = this.telegramNotifier.sanitizeForCodeBlock(truncatedOutput).trim();
              logger.debug(`[PROGRESS-OUTPUT] Task ${task.id}: final content length=${outputContent?.length || 0}`);
            }
          }

          if (outputContent) {
            // Check for stale output and append notice if needed
            const staleInfo = this.taskMonitor.getTaskStaleInfo(task.id);
            let staleNotice = '';
            if (staleInfo && staleInfo.isStale) {
              staleNotice = `\n[⚠️ Output stale - same message for ${staleInfo.staleDurationSeconds}s]`;
            }
            if (isSimple) {
              message += `\n\`\`\`\n${outputContent}${outputTruncated ? '...' : ''}${staleNotice}\n\`\`\`\n`;
            } else {
              message += `\n*📝 Output:*\n\`\`\`\n${outputContent}${outputTruncated ? '...' : ''}${staleNotice}\n\`\`\`\n`;
            }
          } else {
            message += isSimple ? `\n_waiting for output..._\n` : `\n*📝 Output:* Waiting for response...\n`;
          }
        } catch (error) {
          logger.warn(`Could not get print content for task ${taskId}: ${error.message}`);
          message += isSimple ? `\n_waiting for output..._\n` : `\n*📝 Output:* Unable to retrieve\n`;
        }
      } else if (task.output) {
        // For non-running tasks, use the stored output
        const lines = task.output.split('\n');
        const lastLines = lines.slice(-10).join('\n');
        const cleanOutput = this.telegramNotifier.sanitizeForCodeBlock(lastLines.substring(0, 500));
        if (isSimple) {
          message += `\n\`\`\`\n${cleanOutput}${lastLines.length > 500 ? '...' : ''}\n\`\`\`\n`;
        } else {
          message += `\n*📝 Last Output:*\n\`\`\`\n${cleanOutput}${lastLines.length > 500 ? '...' : ''}\n\`\`\`\n`;
        }
      }

      // Add error if failed
      if (task.error) {
        const cleanError = this.telegramNotifier.sanitizeForCodeBlock(task.error.substring(0, 300));
        if (isSimple) {
          message += `\n💬 \`\`\`\n${cleanError}${task.error.length > 300 ? '...' : ''}\n\`\`\`\n`;
        } else {
          message += `\n*❌ Error:*\n\`\`\`\n${cleanError}${task.error.length > 300 ? '...' : ''}\n\`\`\`\n`;
        }
      }

      if (isSimple) {
        // Simple mode: status + duration + cost + provider + task ID
        // Format: [emoji] 25s • $0.1234 • claude • #123123
        // For running/queued tasks: status line on FIRST line so user sees state immediately
        // For completed/failed/cancelled tasks: status line on last line (like completion format)
        message = message.trimEnd();
        const providerId = task.providerId || 'claude';
        const shortTaskId = task.id.slice(-6);
        let statusLine = `${statusEmoji} ${runningTime || '0s'}`;
        // Simplified cost — just $amount, no In/Out/cache breakdown
        const usage = task.liveUsage || task.usage;
        if (usage && usage.cost > 0) {
          statusLine += ` • $${usage.cost.toFixed(4)}`;
        }
        statusLine += ` • ${providerId} • #${shortTaskId}`;

        if (task.status === 'running' || task.status === 'pending' || task.status === 'queued') {
          // Running/queued: status line at the top
          message = `${statusLine}\n${message}`;
        } else {
          // Completed/failed/cancelled: status line at the bottom (like completion message format)
          const separator = message.endsWith('```') ? '' : '\n\n';
          message += `${separator}${statusLine}`;
        }
      } else {
        // Full mode: detailed token line + footer
        const tokenLine = await this.getTaskTokenLine(task);
        if (tokenLine) {
          message += `\n${tokenLine}\n`;
        }
        const { basename } = await import('path');
        const workdir = task.cwd ? basename(task.cwd) : 'system';
        message += await this.telegramNotifier.formatFooter(workdir, { taskProviderId: task.providerId });
      }

      return message;

    } catch (error) {
      logger.error('Error generating enhanced progress message:', error);
      return `❌ Error generating progress message`;
    }
  }

  /**
   * Get token usage line for a task (running or completed).
   * For running tasks, fetches live usage with 30-second caching.
   * For completed tasks, uses the stored usage data.
   * @param {Object} task - The task object
   * @returns {Promise<string>} The formatted token line or empty string
   */
  async getTaskTokenLine(task) {
    try {
      let usage = null;

      if (task.status === 'running') {
        // For running tasks, get live usage with adaptive caching
        // - Default TTL: 10 seconds for responsive updates
        // - Extended TTL: 30 seconds if last fetch took > 5 seconds (slow ccusage)
        const now = Date.now();
        const cacheAge = task.liveUsageUpdatedAt ? (now - task.liveUsageUpdatedAt) : Infinity;
        const CACHE_TTL_DEFAULT = 10000; // 10 seconds
        const CACHE_TTL_EXTENDED = 30000; // 30 seconds if ccusage is slow
        const SLOW_THRESHOLD = 5000; // 5 seconds

        // Use extended TTL if last fetch was slow
        const cacheTTL = (task.liveUsageFetchDuration && task.liveUsageFetchDuration > SLOW_THRESHOLD)
          ? CACHE_TTL_EXTENDED
          : CACHE_TTL_DEFAULT;

        if (task.liveUsage && cacheAge < cacheTTL) {
          // Use cached live usage
          usage = task.liveUsage;
          logger.debug(`[TOKEN_LINE] Using cached live usage for task ${task.id} (age: ${Math.floor(cacheAge / 1000)}s, ttl: ${cacheTTL / 1000}s)`);
        } else {
          // Fetch fresh live usage
          // Note: Use taskQueue.usageReporter which has the before snapshots stored
          try {
            const fetchStart = Date.now();
            const liveUsage = await this.taskMonitor.taskQueue.usageReporter.getLiveUsage(task.id);
            const fetchDuration = Date.now() - fetchStart;

            if (liveUsage) {
              // Update cache on task object
              task.liveUsage = liveUsage;
              task.liveUsageUpdatedAt = Date.now();
              task.liveUsageFetchDuration = fetchDuration;
              usage = liveUsage;
              logger.debug(`[TOKEN_LINE] Fetched live usage for task ${task.id} in ${fetchDuration}ms: $${liveUsage.cost?.toFixed(4)}`);
            }
          } catch (error) {
            logger.debug(`[TOKEN_LINE] Failed to fetch live usage for task ${task.id}: ${error.message}`);
            // Fallback to cached if available
            if (task.liveUsage) {
              usage = task.liveUsage;
            }
          }
        }
      } else {
        // For completed/failed tasks, prefer final usage, fallback to cached liveUsage
        // Using cached liveUsage gives quicker response; message will be updated with final usage later
        usage = task.usage || task.liveUsage;
      }

      if (!usage) {
        return '';
      }

      // Build the token line using the same format as buildCostTokenLine
      let costLine = await this.telegramNotifier.buildCostTokenLine(usage, null, task.id);

      // For running tasks or completed tasks showing cached data, use progress emoji
      const isProgressData = task.status === 'running' || (!task.usage && task.liveUsage);
      if (isProgressData && costLine) {
        // Replace 💰 with 📊 (progress cost) and 🧮 with ⏱️ (progress tokens)
        costLine = costLine.replace(/^💰/, '📊').replace(/^🧮/, '⏱️');
      }

      return costLine;
    } catch (error) {
      logger.debug(`[TOKEN_LINE] Error getting token line for task ${task.id}: ${error.message}`);
      return '';
    }
  }

  getTaskProgressKeyboard(task) {
    const keyboard = { inline_keyboard: [] };
    
    if (task.status === 'running' || task.status === 'queued' || task.status === 'pending') {
      keyboard.inline_keyboard.push([
        {
          text: '🔄 Manual Refresh',
          callback_data: `/process ${task.id}`
        },
        {
          text: '🚫 Cancel Task',
          callback_data: JSON.stringify({
            a: 'cancel',
            t: task.id.split('-').slice(-2).join('-')
          })
        }
      ]);
    } else if (task.status === 'completed') {
      // Show commit button for completed tasks (just like in the completion message)
      keyboard.inline_keyboard.push([
        {
          text: '💾 Commit',
          callback_data: JSON.stringify({
            a: 'run_task',
            c: 'ani-code commit -y'
          })
        }
      ]);
    }
    
    return keyboard.inline_keyboard.length > 0 ? keyboard : undefined;
  }

  async setTelegramWorkdir(chatId, workdirName) {
    const fullChatId = `telegram:${chatId}`;
    const availableWorkdirs = await this.getAvailableWorkdirs(fullChatId);
    
    if (!availableWorkdirs[workdirName]) {
      await this.telegramNotifier.sendMessage(chatId, 
        `❌ Workdir '${workdirName}' not found\n\nPlease use /connect [token] to connect to a workspace.`);
      return;
    }
    
    this.chatSettings.setWorkdir(fullChatId, workdirName);
    await this.chatSettings.save();
    
    await this.telegramNotifier.sendMessage(chatId, 
      `✅ Working directory set to: *${workdirName}*\n📁 Path: \`${availableWorkdirs[workdirName]}\``,
      { parse_mode: 'Markdown' });
  }


  async createTelegramTask(chatId, command, prompt, options = {}) {
    try {
      // Log without the actual prompt content to avoid issues with special characters
      logger.info(`createTelegramTask called`, {
        chatId,
        command,
        promptLength: prompt?.length || 0,
        promptLines: prompt?.split('\n').length || 0,
        hasAttachments: !!(options.attachments && options.attachments.length > 0),
        attachmentCount: options.attachments?.length || 0
      });

      const fullChatId = `telegram:${chatId}`;
      let workdirName = this.chatSettings.getWorkdir(fullChatId);
      logger.info(`Creating Telegram task for chat ${chatId}, workdirName: ${workdirName}`);

      const availableWorkdirs = await this.getAvailableWorkdirs(fullChatId);
      logger.info(`Available workdirs for ${fullChatId}:`, Object.keys(availableWorkdirs));

      // Auto-select workdir if not configured but only one is available
      if (!workdirName) {
        const workdirKeys = Object.keys(availableWorkdirs);
        if (workdirKeys.length === 1) {
          workdirName = workdirKeys[0];
          const workdirPath = availableWorkdirs[workdirName];

          // Save the auto-selected workdir for future use
          this.chatSettings.setWorkdir(fullChatId, workdirName);
          await this.chatSettings.save();
          logger.info(`[Gateway] Auto-selected workdir '${workdirName}' for chat ${chatId} (only one available)`);

          // If in gateway mode, register the Telegram chat with the workspace manager
          if (config.gateway.enabled && workdirPath) {
            try {
              if (!this.workspaceManager) {
                const { WorkspaceManager } = await import('./workspace-manager.js');
                this.workspaceManager = new WorkspaceManager();
                await this.workspaceManager.initialize();
              }

              // Get or create workspace for this path
              let workspace = await this.workspaceManager.getWorkspaceByPath(workdirPath);
              if (!workspace) {
                // Create workspace if it doesn't exist
                workspace = await this.workspaceManager.createWorkspace(workdirName, workdirPath);
                logger.info(`[Gateway] Created workspace '${workdirName}' at ${workdirPath}`);
              }

              // Register the Telegram chat with this workspace
              await this.workspaceManager.registerTelegramChat(chatId, workspace.id);
              logger.info(`[Gateway] Registered Telegram chat ${chatId} with workspace ${workspace.id} (${workdirName})`);
            } catch (error) {
              logger.warn(`[Gateway] Failed to register Telegram chat with workspace: ${error.message}`);
              // Continue anyway - the task can still run with the workdir path
            }
          }
        } else if (workdirKeys.length === 0) {
          logger.warn(`[Gateway] No workdirs available for chat ${chatId}`, {
            fullChatId,
            gatewayEnabled: config.gateway.enabled
          });
          await this.telegramNotifier.sendMessage(chatId,
            '❌ No workspaces available\n\nPlease connect a workspace using /connect [token] first');
          logger.info(`[Gateway] Error message sent to chat ${chatId} about no available workdirs`);
          return;
        } else {
          logger.warn(`[Gateway] Multiple workdirs available for chat ${chatId}, user must select`, {
            fullChatId,
            availableWorkdirs: workdirKeys,
            gatewayEnabled: config.gateway.enabled
          });
          await this.telegramNotifier.sendMessage(chatId,
            `❌ No working directory selected\n\nAvailable workspaces: ${workdirKeys.join(', ')}\n\nUse /workdir [name] to select one`);
          logger.info(`[Gateway] Error message sent to chat ${chatId} about missing workdir selection`);
          return;
        }
      }

      const workdirPath = availableWorkdirs[workdirName];
      logger.info(`Resolved workdir path for ${workdirName}: ${workdirPath}`);

      // Validate that the workspace is still available
      if (!workdirPath) {
        logger.warn(`[Gateway] Workdir '${workdirName}' not found for chat ${chatId}, sending error message`, {
          fullChatId,
          workdirName,
          gatewayEnabled: config.gateway.enabled
        });
        await this.telegramNotifier.sendMessage(chatId,
          `❌ Workspace "${workdirName}" is no longer available\n\n` +
          `Please reconnect using /connect [token] or select a different workspace with /workdir [name]`,
          { parse_mode: 'Markdown' });
        logger.info(`[Gateway] Error message sent to chat ${chatId} about unavailable workdir '${workdirName}'`);

        // Clear the invalid workdir setting
        await this.chatSettings.removeWorkdir(fullChatId);
        return;
      }

      // Check if workspace is in yolo mode and block manual task creation
      try {
        const { WorkspaceManager } = await import('./workspace-manager.js');
        const manager = new WorkspaceManager();
        await manager.initialize();

        // Get workspace for this path
        const workspace = await manager.getWorkspaceByPath(workdirPath);
        if (workspace) {
          const yoloStatus = await manager.getYoloStatus(workspace.id);
          if (yoloStatus && yoloStatus.active) {
            await manager.close();

            // Send protection message with stop button
            const keyboard = {
              inline_keyboard: [[
                {
                  text: '⛔ Stop YOLO',
                  callback_data: JSON.stringify({
                    action: 'stop_yolo'
                  })
                }
              ]]
            };

            await this.telegramNotifier.sendMessage(chatId,
              `🚫 *YOLO Mode Protection Active*\n\n` +
              `Manual tasks are blocked during YOLO execution.\n` +
              `Progress: ${yoloStatus.plansCompleted}/${yoloStatus.plansTotal} plans completed\n\n` +
              `Use /stopyolo to stop execution and disable protection.`,
              {
                parse_mode: 'Markdown',
                reply_markup: keyboard
              }
            );

            logger.info(`Task creation blocked by YOLO protection for workspace ${workspace.id}`);
            return;
          }
        }

        await manager.close();
      } catch (error) {
        logger.warn(`Failed to check yolo status: ${error.message}`);
        // Continue with task creation if check fails
      }

      // Extract provider preference from prompt (@@codex, @@deepseek, @@gemini, etc.)
      let providerId = null;
      try {
        const { extractProviderFromPrompt } = await import('./model-utils.js');
        const { getProviderManager } = await import('./providers/providerManager.js');

        // Get list of valid providers
        const providerManager = await getProviderManager();
        const validProviders = Array.from(providerManager.handlers.keys());

        providerId = extractProviderFromPrompt(prompt, validProviders);
        if (providerId) {
          logger.info(`🎯 Detected provider from prompt: ${providerId}`);
        }
      } catch (error) {
        logger.debug(`Failed to extract provider from prompt: ${error.message}`);
      }

      let taskName, taskCommand;

      if (command === 'shell') {
        taskName = `shell: ${prompt.substring(0, 50)}`;
        taskCommand = `shell:${prompt}`;
      } else if (command === 'continue') {
        // Use provider-specific name for continue tasks
        const providerPrefix = providerId || 'claude';
        taskName = `${providerPrefix}-continue`;
        taskCommand = `-c ${prompt || ''}`.trim();
      } else {
        // Use provider-specific name for regular tasks
        const providerPrefix = providerId || 'claude';
        taskName = `${providerPrefix}-task`;
        taskCommand = prompt;
      }

      const taskOptions = {
        cwd: workdirPath,
        source: 'telegram',
        chatId: fullChatId
      };

      // Add attachments if provided (for web chat image uploads)
      if (options.attachments && Array.isArray(options.attachments) && options.attachments.length > 0) {
        taskOptions.attachments = options.attachments;
        logger.info(`[TASK] Adding ${options.attachments.length} attachment(s) to task for chat ${chatId}`);
      }

      // Add provider to task options if detected, or fall back to current provider
      if (providerId) {
        taskOptions.providerId = providerId;
        logger.info(`[PROVIDER] Setting providerId on task options from prompt: ${providerId}`);
      } else {
        // Fall back to current provider for proper tracking in completion messages
        taskOptions.providerId = await this.getCurrentProviderId();
        logger.info(`[PROVIDER] No providerId detected in prompt, using current provider: ${taskOptions.providerId}`);
      }

      const task = this.taskMonitor.addTask(taskName, taskCommand, taskOptions);

      logger.info(`Created Telegram task ${task.id} for chat ${chatId}${providerId ? ` with provider: ${providerId}` : ''}`);
      logger.info(`[PROVIDER] Task ${task.id} final providerId value: ${task.providerId || 'NOT SET'}`);

      // Don't send "task created" notification here - the task will immediately
      // start and send a "task started" notification (or "task queued" if at limit)
      // This avoids redundant notifications when there are no pending/running tasks
    } catch (error) {
      logger.error(`Error in createTelegramTask for chat ${chatId}:`, error);
      await this.telegramNotifier.sendMessage(chatId,
        `❌ Failed to create task\n\n` +
        `Error: ${error.message || 'Unknown error'}\n\n` +
        `Please try again or contact support.`,
        { parse_mode: 'Markdown' }
      );
      throw error; // Re-throw to be caught by the calling function
    }
  }

  async cancelTelegramTask(chatId, taskId) {
    const cancelled = this.taskMonitor.cancelTask(taskId);

    // cancelTask returns { success: boolean, message: string }
    if (cancelled.success) {
      await this.telegramNotifier.sendMessage(chatId,
        `✅ Task \`${taskId}\` cancelled successfully`,
        { parse_mode: 'Markdown' });
    } else {
      await this.telegramNotifier.sendMessage(chatId,
        `❌ ${cancelled.message || 'Task not found or already completed'}`,
        { parse_mode: 'Markdown' });
    }
  }

  async handleProgressCommand(chatId, taskId) {
    // Simply delegate to showTaskProgress which uses the enhanced format
    logger.info(`Handling /progress command for task ${taskId} in chat ${chatId}`);
    await this.showTaskProgress(chatId, taskId);
  }

  /**
   * Handle /here command - Switch response channel for a running task to current chat
   * This allows users to redirect task notifications from web/gateway to Telegram
   * @param {string} chatId - Current Telegram chat ID
   * @param {string} args - Task ID (optional, defaults to most recent running task)
   */
  async handleChatUIAPI(req, res, pathname, query) {
    try {
      const displayModeManager = new DisplayModeManager(this.chatSettings);

      // GET /api/chatui/modes - List available modes
      if (pathname === '/api/chatui/modes' && req.method === 'GET') {
        this.sendSuccess(res, {
          success: true,
          modes: DisplayModeManager.getAvailableModes(),
          timestamp: new Date().toISOString()
        });
        return;
      }

      // GET /api/chatui?chatId=xxx - Get current mode for a chat
      if (req.method === 'GET') {
        const chatId = query.chatId;
        if (!chatId) {
          this.sendError(res, 400, 'Missing required parameter: chatId');
          return;
        }

        const mode = displayModeManager.getDisplayMode(chatId);
        this.sendSuccess(res, {
          success: true,
          chatId,
          mode,
          availableModes: ['full', 'simple', 'default'],
          timestamp: new Date().toISOString()
        });
        return;
      }

      // PATCH /api/chatui - Set mode for a chat
      if (req.method === 'PATCH') {
        const bodyStr = await this.readRequestBody(req);
        const body = bodyStr ? JSON.parse(bodyStr) : {};
        const { chatId, mode } = body;

        if (!chatId || !mode) {
          this.sendError(res, 400, 'Missing required fields: chatId, mode');
          return;
        }

        if (!VALID_DISPLAY_MODES.includes(mode)) {
          this.sendError(res, 400, `Invalid mode: ${mode}. Valid: ${VALID_DISPLAY_MODES.join(', ')}`);
          return;
        }

        const { previousMode, newMode } = await displayModeManager.setDisplayMode(chatId, mode);
        this.sendSuccess(res, {
          success: true,
          chatId,
          mode: newMode,
          previousMode,
          timestamp: new Date().toISOString()
        });
        return;
      }

      this.sendError(res, 405, 'Method Not Allowed');
    } catch (error) {
      logger.error(`[CHATUI-API] Error: ${error.message}`);
      this.sendError(res, 500, error.message);
    }
  }

  async handleChatUICommand(chatId, args) {
    const fullChatId = `telegram:${chatId}`;

    try {
      const displayModeManager = new DisplayModeManager(this.chatSettings);
      const currentMode = displayModeManager.getDisplayMode(fullChatId);

      if (!args || !args.trim()) {
        // Show current mode with inline keyboard
        const modes = DisplayModeManager.getAvailableModes().filter(m => m.id !== 'default');
        const modeList = modes.map(m => {
          const marker = m.id === currentMode ? '● ' : '○ ';
          return `${marker}*${m.id}* \\- ${this.telegramNotifier.escapeMarkdownContent ? m.description : m.description}`;
        }).join('\n');

        const keyboard = {
          inline_keyboard: [
            [
              { text: currentMode === 'full' ? '● Full' : '○ Full', callback_data: 'chatui:full' },
              { text: currentMode === 'simple' ? '● Simple' : '○ Simple', callback_data: 'chatui:simple' }
            ]
          ]
        };

        await this.telegramNotifier.sendMessage(chatId,
          `📱 *Chat Display Mode*\n\n` +
          `Current: *${currentMode}*\n\n` +
          `● *full* \\- All output: headers, git status, cost/tokens, footer\n` +
          `○ *simple* \\- Streamlined: task output \\+ brief completion line\n\n` +
          `Tap a button or send /chatui <mode> to switch\\.`,
          { parse_mode: 'MarkdownV2', reply_markup: keyboard }
        );
        return;
      }

      const mode = args.trim().toLowerCase();

      if (!VALID_DISPLAY_MODES.includes(mode)) {
        await this.telegramNotifier.sendMessage(chatId,
          `❌ Invalid display mode: ${mode}\n\nValid modes: ${VALID_DISPLAY_MODES.join(', ')}\n\nExample: /chatui simple`
        );
        return;
      }

      const { previousMode, newMode } = await displayModeManager.setDisplayMode(fullChatId, mode);

      let message;
      if (mode === 'default') {
        message = `✅ Display mode reset to default: *${newMode}*`;
      } else if (previousMode === newMode) {
        message = `ℹ️ Display mode already set to: *${newMode}*`;
      } else {
        message = `✅ Display mode changed: *${previousMode}* → *${newMode}*`;
      }

      await this.telegramNotifier.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    } catch (error) {
      logger.error(`[CHATUI] Error handling /chatui command: ${error.message}`);
      await this.telegramNotifier.sendMessage(chatId,
        `❌ Failed to update display mode: ${error.message}`
      );
    }
  }

  async handleHereCommand(chatId, args) {
    const taskQueue = this.taskMonitor.taskQueue;
    const telegramChatId = `telegram:${chatId}`;

    try {
      let taskId = args?.trim();
      let task = null;

      if (taskId) {
        // Find specific task by ID
        task = taskQueue.getTask(taskId);
        if (!task) {
          // Try partial match
          const allTasks = taskQueue.getAllTasks();
          const running = allTasks.running || [];
          const pending = allTasks.pending || [];
          const allActive = [...running, ...pending];

          task = allActive.find(t => t.id.endsWith(taskId) || t.id.includes(taskId));
        }

        if (!task) {
          await this.telegramNotifier.sendMessage(chatId,
            `❌ Task not found: ${taskId}\n\n` +
            `Use /status to see running tasks, or /here without arguments to redirect the most recent task.`
          );
          return;
        }
      } else {
        // Find most recent running task (prefer tasks from gateway/web source)
        const allTasks = taskQueue.getAllTasks();
        const running = allTasks.running || [];

        if (running.length === 0) {
          await this.telegramNotifier.sendMessage(chatId,
            `ℹ️ No running tasks to redirect.\n\n` +
            `Use /here <task_id> to redirect a specific pending task.`
          );
          return;
        }

        // Prefer gateway-sourced tasks, then most recent
        task = running.find(t => t.metadata?.source === 'gateway') ||
               running.find(t => t.source === 'gateway' || t.source === 'web') ||
               running[running.length - 1]; // Fall back to most recent
      }

      // Check if already pointing to this chat
      if (task.chatId === telegramChatId) {
        // Even if chatId matches, we need to ensure gateway source flag is cleared
        // This can happen when a gateway task has a telegram chatId but notifications
        // are still being routed through gateway callback
        const wasGatewaySource = task.metadata?.source === 'gateway';

        if (wasGatewaySource) {
          // Clear gateway source flag so notifications go directly to Telegram
          logger.info(`[HERE] Task ${task.id} chatId matches but has gateway source - clearing gateway routing`);

          // Update task to clear gateway source
          const updatedTask = taskQueue.updateTaskChannel(task.id, telegramChatId, 'telegram');

          if (updatedTask) {
            // Notify gateway about the channel redirect
            this.taskMonitor.notifyGatewayChannelRedirect(updatedTask, telegramChatId, 'gateway')
              .catch(error => {
                logger.error(`[HERE] Failed to notify gateway of channel redirect: ${error.message}`);
              });

            // Check if this is a goal-related task and show goal status
            const goalInfo = await this.checkAndShowGoalStatus(chatId, task, updatedTask);

            await this.telegramNotifier.sendMessage(chatId,
              `✅ Task \`${task.id}\` notifications redirected from gateway to this chat.${goalInfo ? `\n\n${goalInfo}` : ''}`
            );
          } else {
            await this.telegramNotifier.sendMessage(chatId,
              `⚠️ Task \`${task.id}\` is already here but failed to update routing.`
            );
          }
          return;
        }

        // Check if this is a goal-related task and show goal status even if already here
        const goalInfo = await this.checkAndShowGoalStatus(chatId, task, task);

        await this.telegramNotifier.sendMessage(chatId,
          `✅ Task \`${task.id}\` is already sending notifications here.${goalInfo ? `\n\n${goalInfo}` : ''}`
        );
        return;
      }

      // Update the task channel
      const oldChatId = task.chatId || 'none';
      const oldSource = task.metadata?.source || task.source || 'unknown';
      const wasGatewayTask = oldSource === 'gateway' || task.metadata?.source === 'gateway';

      // Log detailed state for debugging
      logger.info(`[HERE] Task state before redirect: id=${task.id}, chatId=${oldChatId}, source=${task.source}, metadata.source=${task.metadata?.source}, wasGateway=${wasGatewayTask}`);

      const updatedTask = taskQueue.updateTaskChannel(task.id, telegramChatId, 'telegram');

      if (!updatedTask) {
        await this.telegramNotifier.sendMessage(chatId,
          `❌ Failed to update task ${task.id}. Task may have completed.`
        );
        return;
      }

      // Log state after redirect
      logger.info(`[HERE] Task state after redirect: id=${task.id}, chatId=${updatedTask.chatId}, source=${updatedTask.source}, metadata.source=${updatedTask.metadata?.source}`);

      // Migrate progress tracker from old chat to new chat
      if (oldChatId && oldChatId !== 'none') {
        const oldTelegramChatId = oldChatId.replace('telegram:', '');
        const oldTrackerKey = `${oldTelegramChatId}:${task.id}`;

        if (this.progressTrackers.has(oldTrackerKey)) {
          const oldTracker = this.progressTrackers.get(oldTrackerKey);
          // Clear old tracker interval
          if (oldTracker.interval) {
            clearInterval(oldTracker.interval);
          }
          this.progressTrackers.delete(oldTrackerKey);
          logger.info(`[HERE] Cleared old progress tracker: ${oldTrackerKey}`);
        }
      }

      // Notify gateway about the channel redirect so it can send messages to the new channel
      if (wasGatewayTask) {
        this.taskMonitor.notifyGatewayChannelRedirect(updatedTask, oldChatId, oldSource)
          .catch(error => {
            logger.error(`[HERE] Failed to notify gateway of channel redirect: ${error.message}`);
          });
      }

      // Update goal loop state if this task is part of a goal loop
      // Goal loop states are keyed by the original chatId, so we need to find and update
      if (oldChatId && oldChatId !== 'none') {
        const oldTelegramChatId = oldChatId.replace('telegram:', '');
        if (this.goalLoopStates && this.goalLoopStates.has(oldTelegramChatId)) {
          const goalState = this.goalLoopStates.get(oldTelegramChatId);
          // Check if this task belongs to the goal loop
          if (goalState.currentTaskId === task.id || goalState.isActive) {
            goalState.chatId = chatId; // Update to new chatId

            // Create a new status message in the new chat for future edits
            if (goalState.statusMessageId) {
              try {
                const statusMessage = await this.formatGoalLoopStatus(goalState, 'implementing');
                const newStatusMsg = await this.telegramNotifier.sendMessage(chatId, statusMessage, {
                  parse_mode: 'Markdown',
                  reply_markup: {
                    inline_keyboard: [[
                      { text: '⏹ Stop', callback_data: JSON.stringify({ action: 'stop_loop' }) },
                      { text: '🔄 Refresh', callback_data: JSON.stringify({ action: 'refresh_loop' }) }
                    ]]
                  }
                });
                if (newStatusMsg?.result?.message_id) {
                  goalState.statusMessageId = newStatusMsg.result.message_id;
                  logger.info(`[HERE] Created new goal loop status message ${goalState.statusMessageId} in chat ${chatId}`);
                }
              } catch (error) {
                logger.error(`[HERE] Failed to create goal loop status message: ${error.message}`);
              }
            }

            logger.info(`[HERE] Updated goal loop state chatId from ${oldTelegramChatId} to ${chatId}`);
          }
        }
      }

      // Detect task type for display
      const taskMode = this.extractModeFromTask(task);
      let taskTypeEmoji = '📋';
      let taskTypeLabel = 'Task';
      if (taskMode === 'yolo') {
        taskTypeEmoji = '🚀';
        taskTypeLabel = 'Yolo';
      } else if (taskMode === 'goalloop') {
        taskTypeEmoji = '🎯';
        taskTypeLabel = 'Goal Loop';
      } else if (taskMode === 'plan') {
        taskTypeEmoji = '📝';
        taskTypeLabel = 'Plan';
      }

      // Format task info for display
      const taskName = task.name || task.command?.substring(0, 50) || 'Unknown';
      const status = task.status || 'running';

      // Show more accurate source info - display gateway if was gateway task
      const displayOldSource = wasGatewayTask ? 'gateway' : oldSource;

      // Send redirect confirmation and start progress tracking
      const redirectMsg = await this.telegramNotifier.sendMessage(chatId,
        `✅ *Redirected ${taskTypeLabel} here*\n\n` +
        `${taskTypeEmoji} ${taskTypeLabel}: \`${task.id}\`\n` +
        `📝 ${taskName.substring(0, 100)}${taskName.length > 100 ? '...' : ''}\n` +
        `📊 Status: ${status}\n` +
        `🔄 From: ${displayOldSource} → telegram\n\n` +
        `_${taskTypeLabel} notifications will now appear in this chat._`
      );

      // Start progress tracking for this task in the new chat
      if (task.status === 'running') {
        try {
          // Resolve display mode for this chat
          const hereChatId = String(chatId).includes(':') ? String(chatId) : `telegram:${chatId}`;
          const hereDisplayModeManager = new DisplayModeManager(this.chatSettings);
          const hereDisplayMode = hereDisplayModeManager.getDisplayMode(hereChatId);

          // Generate initial progress message
          let progressMessage = await this.generateEnhancedTaskProgressMessage(task.id, hereDisplayMode);
          progressMessage = this.telegramNotifier.sanitizeMessageForTelegram(progressMessage);

          // Send progress message
          const progressMsgResult = await this.telegramNotifier.api.sendMessage(chatId, progressMessage, {
            parse_mode: 'Markdown',
            reply_markup: this.getTaskProgressKeyboard(task)
          });

          if (progressMsgResult?.result?.message_id) {
            const newTrackerKey = `${chatId}:${task.id}`;

            // Create progress tracker with update interval
            const tracker = {
              chatId,
              taskId: task.id,
              messageId: progressMsgResult.result.message_id,
              displayMode: hereDisplayMode,
              startTime: Date.now(),
              updateCount: 0,
              lastRecallTime: Date.now(),
              interval: null,
              isPinned: false
            };

            // Set up interval to update every 10 seconds
            const updateInterval = 10000;
            const maxDuration = 30 * 60 * 1000; // 30 minutes max

            tracker.interval = setInterval(async () => {
              try {
                tracker.updateCount++;

                // Check if max duration exceeded
                if (Date.now() - tracker.startTime > maxDuration) {
                  logger.info(`[HERE] Progress tracking for task ${task.id} exceeded max duration, stopping`);
                  clearInterval(tracker.interval);
                  this.progressTrackers.delete(newTrackerKey);
                  return;
                }

                // Check if task is still running
                const currentTask = taskQueue.getTask(task.id);
                if (!currentTask || currentTask.status !== 'running') {
                  logger.info(`[HERE] Task ${task.id} no longer running, stopping progress tracking`);
                  clearInterval(tracker.interval);
                  this.progressTrackers.delete(newTrackerKey);
                  return;
                }

                // Update progress message
                let newProgressMessage = await this.generateEnhancedTaskProgressMessage(task.id, tracker.displayMode);
                newProgressMessage = this.telegramNotifier.sanitizeMessageForTelegram(newProgressMessage);

                await this.telegramNotifier.editMessage(
                  chatId,
                  tracker.messageId,
                  newProgressMessage,
                  {
                    parse_mode: 'Markdown',
                    reply_markup: this.getTaskProgressKeyboard(currentTask)
                  }
                );
              } catch (error) {
                if (error.message?.includes('message is not modified')) {
                  // Ignore - content hasn't changed
                } else {
                  logger.error(`[HERE] Failed to update progress: ${error.message}`);
                }
              }
            }, updateInterval);

            this.progressTrackers.set(newTrackerKey, tracker);
            logger.info(`[HERE] Started progress tracking for task ${task.id} in chat ${chatId}`);
          }
        } catch (error) {
          logger.error(`[HERE] Failed to start progress tracking: ${error.message}`);
          // Non-fatal - redirect still worked
        }
      }

      logger.info(`[HERE] Redirected ${taskTypeLabel} ${task.id} from ${displayOldSource}:${oldChatId} to telegram:${chatId}`);

    } catch (error) {
      logger.error(`[HERE] Error handling /here command: ${error.message}`);
      await this.telegramNotifier.sendMessage(chatId,
        `❌ Error: ${error.message}`
      );
    }
  }

  /**
   * Check if a task is part of a goal loop and return goal status info
   * @param {string} chatId - Telegram chat ID
   * @param {object} task - The task being redirected
   * @param {object} updatedTask - The updated task after redirect
   * @returns {string|null} Goal info string or null if not a goal task
   */
  async checkAndShowGoalStatus(chatId, task, updatedTask) {
    try {
      // Check if this task is part of a goal loop by looking at goal loop states
      // Goal loops can be keyed by various chat IDs
      if (!this.goalLoopStates) return null;

      // Check task metadata for goal-related info
      const goalId = task.metadata?.goalId || updatedTask.metadata?.goalId;
      const isGoalTask = task.metadata?.isGoalTask || updatedTask.metadata?.isGoalTask ||
                        task.mode === 'goal' || task.name?.toLowerCase().includes('goal');

      if (!goalId && !isGoalTask) {
        // Try to find if any goal loop has this task as current
        for (const [loopChatId, goalState] of this.goalLoopStates.entries()) {
          if (goalState.currentTaskId === task.id && goalState.isActive) {
            // Found a goal loop for this task
            const goal = goalState.currentGoal;
            const goalName = goal?.title || goal?.file || 'Unknown';

            // Update the goal loop state chatId to this chat
            goalState.chatId = chatId;
            this.goalLoopStates.set(chatId, goalState);

            // If the old chatId was different, clean up
            if (loopChatId !== chatId) {
              this.goalLoopStates.delete(loopChatId);
              logger.info(`[HERE] Migrated goal loop state from ${loopChatId} to ${chatId}`);
            }

            // Create a new status message in this chat
            if (goalState.statusMessageId) {
              try {
                const statusMessage = await this.formatGoalLoopStatus(goalState, 'implementing');
                const newStatusMsg = await this.telegramNotifier.sendMessage(chatId, statusMessage, {
                  parse_mode: 'Markdown',
                  reply_markup: {
                    inline_keyboard: [[
                      { text: '⏹ Stop', callback_data: JSON.stringify({ action: 'stop_loop' }) },
                      { text: '🔄 Refresh', callback_data: JSON.stringify({ action: 'refresh_loop' }) }
                    ]]
                  }
                });
                if (newStatusMsg?.result?.message_id) {
                  goalState.statusMessageId = newStatusMsg.result.message_id;
                  logger.info(`[HERE] Created new goal loop status message ${goalState.statusMessageId} in chat ${chatId}`);
                }
              } catch (error) {
                logger.error(`[HERE] Failed to create goal loop status message: ${error.message}`);
              }
            }

            return `🎯 *Goal Loop Active*\n` +
                   `*Goal:* ${goal?.id}. ${goalName}\n` +
                   `*Iteration:* ${goalState.currentIteration}/${goalState.maxIterations}`;
          }
        }
        return null;
      }

      // If we have a goalId, return info about it
      return goalId ? `🎯 *Working on Goal:* ${goalId}` : null;
    } catch (error) {
      logger.error(`[HERE] Error checking goal status: ${error.message}`);
      return null;
    }
  }

  async checkTelegramAuthorization(chatId, userId, request = null) {
    try {
      // Gateway trust bypass - MUST BE FIRST
      // Log detailed gateway bypass diagnostics
      if (config.gateway.enabled) {
        logger.debug(`🔍 Gateway mode enabled, checking trust headers for chat ${chatId}`);

        if (!request) {
          logger.warn(`⚠️  Gateway trust bypass SKIPPED: request object is null/undefined`, {
            chatId,
            userId,
            gatewayEnabled: config.gateway.enabled,
            gatewayUrl: config.gateway.url,
            hint: 'Request object not passed to checkTelegramAuthorization()'
          });
        } else if (!request.headers) {
          logger.warn(`⚠️  Gateway trust bypass SKIPPED: request.headers is missing`, {
            chatId,
            userId,
            requestKeys: Object.keys(request || {})
          });
        } else {
          const gatewayToken = request.headers['x-gateway-token'];
          const gatewayUrl = request.headers['x-gateway-url'];

          // Helper function to safely mask token values for logging
          const maskToken = (token) => {
            if (!token) return 'missing';
            if (token.length <= 8) return '***masked***';
            return `${token.substring(0, 4)}...${token.substring(token.length - 4)}`;
          };

          logger.debug(`🔍 Gateway headers check:`, {
            chatId,
            hasGatewayToken: !!gatewayToken,
            hasGatewayUrl: !!gatewayUrl,
            expectedUrl: config.gateway.url,
            receivedUrl: gatewayUrl,
            tokenMatch: gatewayToken === config.gateway.token,
            urlMatch: gatewayUrl === config.gateway.url
          });

          // Verify both token and URL match expected values
          if (gatewayToken === config.gateway.token &&
              gatewayUrl === config.gateway.url) {
            logger.info(`✓ Gateway trust auth bypass for chat ${chatId}`, {
              instanceId: config.gateway.instanceId,
              gatewayUrl,
              userId
            });
            return true; // TRUST THE GATEWAY
          }

          // Log invalid gateway auth attempts with detailed reasons
          const reasons = [];
          if (!gatewayToken) reasons.push('missing x-gateway-token header');
          else if (gatewayToken !== config.gateway.token) reasons.push('x-gateway-token mismatch');
          if (!gatewayUrl) reasons.push('missing x-gateway-url header');
          else if (gatewayUrl !== config.gateway.url) reasons.push(`x-gateway-url mismatch (got: ${gatewayUrl}, expected: ${config.gateway.url})`);

          // Detailed token comparison
          const tokenComparison = {
            expectedToken: maskToken(config.gateway.token),
            receivedToken: maskToken(gatewayToken),
            expectedLength: config.gateway.token?.length || 0,
            receivedLength: gatewayToken?.length || 0,
            exactMatch: gatewayToken === config.gateway.token,
            typeMatch: typeof gatewayToken === typeof config.gateway.token,
            // Add token type hints for debugging
            expectedSource: config.gateway.token ?
              (process.env.GATEWAY_TOKEN ? 'GATEWAY_TOKEN (gateway-generated)' : 'GATEWAY_API_KEY (pre-shared)') :
              'not configured',
            hint: !config.gateway.token ?
              'No gateway token configured. Register with gateway to receive a token.' :
              (config.gateway.token && !process.env.GATEWAY_TOKEN ?
                'Using GATEWAY_API_KEY instead of gateway-generated token. This will fail validation.' : null)
          };

          // Detailed URL comparison
          const urlComparison = {
            expectedUrl: config.gateway.url,
            receivedUrl: gatewayUrl || 'missing',
            expectedLength: config.gateway.url?.length || 0,
            receivedLength: gatewayUrl?.length || 0,
            exactMatch: gatewayUrl === config.gateway.url,
            // Character-by-character comparison to find where they differ
            firstDifferenceAt: gatewayUrl && config.gateway.url
              ? Array.from(gatewayUrl).findIndex((char, i) => char !== config.gateway.url[i])
              : -1
          };

          // Request body preview (first 200 chars)
          let bodyPreview = 'no-body';
          try {
            if (request.body) {
              const bodyStr = typeof request.body === 'string'
                ? request.body
                : JSON.stringify(request.body);
              bodyPreview = bodyStr.length > 200
                ? bodyStr.substring(0, 200) + '...'
                : bodyStr;
            }
          } catch (e) {
            bodyPreview = 'error-reading-body';
          }

          logger.warn(`✗ Gateway trust bypass FAILED for chat ${chatId}`, {
            reasons: reasons.join(', '),
            tokenComparison,
            urlComparison,
            requestDetails: {
              method: request.method,
              url: request.url,
              bodyPreview,
              contentType: request.headers['content-type'],
              userAgent: request.headers['user-agent'],
              allHeaders: Object.keys(request.headers || {})
            },
            userId,
            chatId
          });
        }
      } else {
        logger.debug(`Gateway mode disabled (GATEWAY_URL not set), using normal auth for chat ${chatId}`);
      }

      // First check if there are any allowed chats configured in env
      if (config.telegram.allowedChats && config.telegram.allowedChats.length > 0) {
        // Check if chat ID or user ID is in the allowed list
        const chatIdStr = String(chatId);
        const userIdStr = String(userId);

        if (config.telegram.allowedChats.includes(chatIdStr) ||
            config.telegram.allowedChats.includes(userIdStr)) {
          logger.debug(`Chat/User ${chatIdStr}/${userIdStr} is in allowed list from env`);
          return true;
        }
      }
      
      // Check database for authorized chats
      logger.debug(`Checking database authorization for chat ${chatId}`);
      const authInfo = await this.workspaceManager.isTelegramChatAuthorized(String(chatId));
      logger.debug(`Auth info for chat ${chatId}:`, authInfo);
      
      if (authInfo && authInfo.authorized) {
        logger.debug(`Chat ${chatId} is authorized for workspace ${authInfo.workspace_name}`);
        
        // Set the workspace path for this chat
        const fullChatId = `telegram:${chatId}`;
        if (authInfo.workspace_path) {
          // Use workspace manager to find correct workspace-based workdir
          logger.debug(`Getting workspace for ID ${authInfo.workspace_id}`);
          const workspace = await this.workspaceManager.getWorkspace(authInfo.workspace_id);
          if (workspace) {
            logger.debug(`Setting workdir for ${fullChatId} to ${workspace.name} at ${workspace.path}`);
            await this.chatSettings.setWorkdir(fullChatId, workspace.name, workspace.path);
            logger.debug(`Workdir set successfully for ${fullChatId}`);
          }
        }
        
        return true;
      }
    } catch (error) {
      logger.error(`Error in checkTelegramAuthorization for chat ${chatId}:`, error);
      throw error; // Re-throw to handle it in the calling function
    }
    
    // Check if user is in allowed users table
    if (userId) {
      const isAllowed = await this.workspaceManager.isAllowedTelegramUser(String(userId));
      if (isAllowed) {
        logger.debug(`User ${userId} is in allowed users table`);
        return true;
      }
    }
    
    // If no restrictions are configured at all, deny by default
    return false;
  }

  async handleTelegramUrlCommand(chatId) {
    // Get or initialize Telegram notifier
    if (!this.telegramNotifier) {
      const { TelegramNotifier } = await import('./telegram-notifier.js');
      this.telegramNotifier = new TelegramNotifier();
    }
    
    // Check if we have a recent image for this chat
    const imageInfo = this.recentImages.get(chatId);
    
    if (!imageInfo) {
      await this.telegramNotifier.sendMessage(chatId, 
        '❌ No recent image found in this chat.\n\n' +
        'Please send an image first, then use /url to get its public URL.',
        { parse_mode: 'Markdown' }
      );
      return;
    }
    
    // Check if image is too old (older than 10 minutes)
    const ageInMinutes = Math.floor((Date.now() - imageInfo.timestamp) / 60000);
    if (ageInMinutes > 10) {
      await this.telegramNotifier.sendMessage(chatId, 
        `❌ The last image is too old (${ageInMinutes} minutes ago).\n\n` +
        'Please send a new image and try again.',
        { parse_mode: 'Markdown' }
      );
      this.recentImages.delete(chatId); // Clean up old image
      return;
    }
    
    try {
      // Check if we already have an S3 URL stored
      if (imageInfo.s3Url) {
        // Send the S3 URL back to the user with a copy button
        let message = `🖼️ *Last image URL (S3)*\n\n`;
        message += `📎 URL:\n\`${imageInfo.s3Url}\`\n\n`;
        if (imageInfo.size) {
          message += `📊 Size: ${(imageInfo.size / 1024).toFixed(2)} KB\n`;
        }
        if (imageInfo.md5) {
          message += `🔑 MD5: \`${imageInfo.md5}\`\n`;
        }
        if (imageInfo.username) {
          message += `_Sent by: @${imageInfo.username}_\n`;
        }
        if (ageInMinutes > 0) {
          message += `_${ageInMinutes} minute(s) ago_\n`;
        } else {
          message += `_Just now_\n`;
        }
        message += `\n_Image is securely hosted on S3._`;
        
        // Create inline keyboard with copy and open buttons
        const keyboard = {
          inline_keyboard: [[
            {
              text: '📋 Copy URL',
              copy_text: {
                text: imageInfo.s3Url
              }
            },
            {
              text: '🔗 Open Image',
              url: imageInfo.s3Url
            }
          ]]
        };
        
        await this.telegramNotifier.sendMessage(chatId, message, { 
          parse_mode: 'Markdown',
          reply_to_message_id: imageInfo.messageId,
          reply_markup: keyboard
        });
        
        logger.info(`Sent S3 URL via /url command to chat ${chatId}: ${imageInfo.s3Url}`);
      } else {
        // Fallback: Upload to S3 now if not already done
        const botToken = config.telegram?.botToken;
        const apiUrl = `https://api.telegram.org/bot${botToken}`;
        
        // Add timeout and better error handling
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 15000); // 15 second timeout
        
        let fileResponse;
        try {
          if (this.telegramAPI) {
            fileResponse = await this.telegramAPI.getFile(imageInfo.fileId);
          } else {
            fileResponse = await fetch(`${apiUrl}/getFile?file_id=${imageInfo.fileId}`, {
              signal: controller.signal,
              headers: {
                'Connection': 'close',
                'Cache-Control': 'no-cache'
              },
              keepalive: false
            });
            clearTimeout(timeout);
            fileResponse = await fileResponse.json();
          }
        } catch (fetchError) {
          if (timeout) clearTimeout(timeout);
          const errorMessage = fetchError.cause?.message || fetchError.message || 'Unknown network error';
          const errorReason = fetchError.cause?.reason || fetchError.reason || '';
          logger.error(`Network error fetching file info for /url command:
  Error: ${errorMessage}
  Reason: ${errorReason}
  Type: ${fetchError.name}
  Full Error: ${fetchError.toString()}`);
          throw fetchError; // Re-throw to be caught by outer try-catch
        }
        if (!this.telegramAPI) clearTimeout(timeout);
        
        const fileData = this.telegramAPI ? fileResponse : await fileResponse.json();
        
        if (fileData && fileData.ok && fileData.result) {
          const filePath = fileData.result.file_path;
          const telegramUrl = `https://api.telegram.org/file/bot${botToken}/${filePath}`;
          
          // Upload to S3
          const uploader = new SecureUploader();
          
          // Get workdir name for this chat (to use as S3 path prefix)
          const workdirName = this.chatSettings.getWorkdir(`telegram:${chatId}`);
          const workdirPath = workdirName || 'telegram-images'; // fallback if no workdir set
          
          const s3Result = await uploader.uploadImageFromUrl(telegramUrl, {
            workdir: workdirPath,
            fileName: imageInfo.fileName,
            fileType: imageInfo.fileType,
            metadata: {
              'telegram-chat-id': chatId.toString(),
              'telegram-user': imageInfo.username || 'unknown',
              'telegram-message-id': imageInfo.messageId?.toString() || '',
              'caption': (imageInfo.caption || '').replace(/[\r\n]/g, ' ').replace(/[\x00-\x1F\x7F]/g, '').trim()
            }
          });
          
          // Update the stored image info with S3 URL
          imageInfo.s3Url = s3Result.url;
          imageInfo.s3Key = s3Result.s3Key;
          imageInfo.md5 = s3Result.md5;
          imageInfo.size = s3Result.size;
          
          // Send the S3 URL back to the user
          let message = `🖼️ *Last image uploaded to S3*\n\n`;
          message += `📎 URL:\n\`${s3Result.url}\`\n\n`;
          message += `📊 Size: ${(s3Result.size / 1024).toFixed(2)} KB\n`;
          message += `🔑 MD5: \`${s3Result.md5}\`\n`;
          if (imageInfo.username) {
            message += `_Sent by: @${imageInfo.username}_\n`;
          }
          if (ageInMinutes > 0) {
            message += `_${ageInMinutes} minute(s) ago_\n`;
          } else {
            message += `_Just now_\n`;
          }
          message += `\n_Image has been uploaded to S3._`;
          
          // Create inline keyboard with copy and open buttons
          const keyboard = {
            inline_keyboard: [[
              {
                text: '📋 Copy URL',
                copy_text: {
                  text: s3Result.url
                }
              },
              {
                text: '🔗 Open Image',
                url: s3Result.url
              }
            ]]
          };
          
          await this.telegramNotifier.sendMessage(chatId, message, { 
            parse_mode: 'Markdown',
            reply_to_message_id: imageInfo.messageId,
            reply_markup: keyboard
          });
          
          logger.info(`Uploaded and sent S3 URL via /url command to chat ${chatId}: ${s3Result.url}`);
        } else {
          logger.error('Failed to get file info from Telegram:', fileData);
          await this.telegramNotifier.sendMessage(chatId, 
            '❌ Failed to get image URL. The image may have expired.',
            { parse_mode: 'Markdown' }
          );
        }
      }
    } catch (error) {
      logger.error(`Error processing /url command:
  Error: ${error.message || 'Unknown error'}
  Type: ${error.name || 'Error'}
  Stack: ${error.stack?.split('\n')[0] || 'No stack trace'}`);
      await this.telegramNotifier.sendMessage(chatId, 
        '❌ Error retrieving image URL. Please try again.',
        { parse_mode: 'Markdown' }
      );
    }
  }

  async handleTelegramImgCommand(chatId) {
    try {
      // Get or initialize Telegram notifier
      if (!this.telegramNotifier) {
        const { TelegramNotifier } = await import('./telegram-notifier.js');
        this.telegramNotifier = new TelegramNotifier();
      }

      // Get workspace for this chat
      const { WorkspaceManager } = await import('./workspace-manager.js');
      const manager = new WorkspaceManager();
      await manager.initialize();

      let workspace = await manager.getWorkspaceForTelegramChat(String(chatId));
      if (!workspace) {
        // In gateway mode, ensure gateway workspace exists in database
        if (config.gateway.enabled) {
          workspace = await manager.ensureGatewayWorkspace();
          logger.debug('Gateway mode: Using gateway workspace for Telegram /img');
        } else {
          await this.telegramNotifier.sendMessage(chatId,
            `❌ *No workspace connected*\n\n` +
            `Connect to a workspace first:\n` +
            `1. Generate token: \`ani-code workspace token gen\`\n` +
            `2. Connect: \`/connect <token>\``,
            { parse_mode: 'Markdown' }
          );
          await manager.close();
          return;
        }
      }

      // Get the last completed task for this workspace
      const taskHistory = this.taskMonitor.taskQueue.getTaskHistory(1); // Get last 1 task
      const lastTask = taskHistory.find(t =>
        t.cwd === workspace.path &&
        t.status === 'completed' &&
        t.output
      );

      if (!lastTask) {
        await this.telegramNotifier.sendMessage(chatId,
          '❌ No completed task with output found for this workspace.\n\n' +
          'Run a task first, then use /img to extract image URLs from the output.',
          { parse_mode: 'Markdown' }
        );
        await manager.close();
        return;
      }
      const output = lastTask.output;

      // Parse image URLs from the output - look for https URLs that might be images
      const imageUrlPattern = /https?:\/\/[^\s\[\]()<>]+\.(jpg|jpeg|png|gif|webp|svg|bmp)(\?[^\s\[\]()<>]*)?/gi;
      const imageUrls = [...new Set(output.match(imageUrlPattern) || [])]; // Remove duplicates

      // Also look for URLs that might be from image services (without extensions)
      const serviceUrlPattern = /https?:\/\/(.*\.)?(imgur\.com|cloudinary\.com|s3[.-].*amazonaws\.com|cdn\.[^\s]+|.*\.r2\.dev|.*\.cloudfront\.net)\/[^\s\[\]()<>]+/gi;
      const serviceUrls = [...new Set(output.match(serviceUrlPattern) || [])];

      // Combine and deduplicate all URLs (limit to first 4)
      const allUrls = [...new Set([...imageUrls, ...serviceUrls])].slice(0, 4);

      if (allUrls.length === 0) {
        await this.telegramNotifier.sendMessage(chatId,
          `ℹ️ No image URLs found in the last task output.\n\n` +
          `Task: ${lastTask.name}\n` +
          `Completed: ${new Date(lastTask.completedAt).toLocaleString()}`,
          { parse_mode: 'Markdown' }
        );
        await manager.close();
        return;
      }

      // Initialize S3 uploader
      const { SecureUploader } = await import('./utils/secure-upload.js');
      const uploader = new SecureUploader();
      await uploader.initialize();

      // Send initial message that we'll keep editing
      const statusMessage = await this.telegramNotifier.sendMessage(chatId,
        `🖼️ Found ${allUrls.length} image URL(s) in last task output.\n` +
        `Processing...`,
        { parse_mode: 'Markdown' }
      );
      const messageId = statusMessage?.platform_response?.result?.message_id || statusMessage?.result?.message_id || statusMessage?.message_id;

      // Get S3 endpoint hostname for comparison
      const s3Endpoint = uploader.endpoint; // This is the S3 hostname from config

      // Process each URL
      const processedImages = [];
      const skippedImages = [];

      for (let i = 0; i < allUrls.length; i++) {
        const url = allUrls[i];

        // Update status message
        if (messageId) {
          await this.telegramNotifier.editMessage(chatId, messageId,
            `🖼️ Processing ${i + 1}/${allUrls.length} images...\n\n` +
            `Current: ${url.length > 50 ? url.substring(0, 50) + '...' : url}`,
            { parse_mode: 'Markdown' }
          );
        }

        try {
          // Check if URL is already from our S3 bucket
          const urlObj = new URL(url);
          if (s3Endpoint && urlObj.hostname === s3Endpoint) {
            logger.info(`Skipping S3 re-upload for URL already on S3: ${url}`);
            skippedImages.push({
              originalUrl: url,
              s3Url: url,
              skipped: true
            });

            // Send the existing S3 image directly
            await this.telegramNotifier.sendPhoto(chatId, url, {
              caption: `Image ${i + 1}/${allUrls.length} (Already on S3)\n` +
                      `URL: ${url.length > 100 ? url.substring(0, 100) + '...' : url}`,
              parse_mode: 'Markdown'
            });
          } else {
            // Upload to S3 for permanent storage
            const s3Result = await uploader.uploadImageFromUrl(url, {
              workdir: workspace.name || 'task-images',
              fileName: `task-image-${i + 1}`,
              metadata: {
                'source': 'task-output',
                'task-id': lastTask.id,
                'task-name': lastTask.name,
                'workspace': workspace.name,
                'original-url': url.substring(0, 500) // Limit metadata length
              }
            });

            processedImages.push({
              originalUrl: url,
              s3Url: s3Result.url,
              size: s3Result.size
            });

            // Send the image to Telegram with caption
            await this.telegramNotifier.sendPhoto(chatId, s3Result.url, {
              caption: `Image ${i + 1}/${allUrls.length}\n` +
                      `Size: ${(s3Result.size / 1024).toFixed(2)} KB\n` +
                      `Original: ${url.length > 100 ? url.substring(0, 100) + '...' : url}`,
              parse_mode: 'Markdown'
            });
          }

        } catch (error) {
          logger.error(`Failed to process image URL ${url}:`, error);

          // Update status with error but continue processing
          if (messageId) {
            await this.telegramNotifier.editMessage(chatId, messageId,
              `⚠️ Failed to process image ${i + 1}: ${error.message}\n` +
              `Continuing with remaining images...`,
              { parse_mode: 'Markdown' }
            );
          }
        }
      }

      // Final status message
      if (messageId) {
        let finalMessage = `✅ *Image Processing Complete*\n\n`;

        if (processedImages.length > 0) {
          finalMessage += `📤 Uploaded: ${processedImages.length} image(s)\n`;
        }
        if (skippedImages.length > 0) {
          finalMessage += `⏭️ Already on S3: ${skippedImages.length} image(s)\n`;
        }

        finalMessage += `\nFrom task: ${lastTask.name}\n`;
        finalMessage += `Completed: ${new Date(lastTask.completedAt).toLocaleString()}\n\n`;

        // List all URLs
        let urlIndex = 1;
        if (processedImages.length > 0) {
          finalMessage += `*Newly Uploaded:*\n`;
          for (const img of processedImages) {
            finalMessage += `${urlIndex}. [S3 URL](${img.s3Url})\n`;
            urlIndex++;
          }
        }

        if (skippedImages.length > 0) {
          if (processedImages.length > 0) finalMessage += `\n`;
          finalMessage += `*Already on S3:*\n`;
          for (const img of skippedImages) {
            finalMessage += `${urlIndex}. [S3 URL](${img.s3Url})\n`;
            urlIndex++;
          }
        }

        await this.telegramNotifier.editMessage(chatId, messageId, finalMessage, {
          parse_mode: 'Markdown',
          disable_web_page_preview: true
        });
      }

      await manager.close();

    } catch (error) {
      logger.error(`Error processing /img command:`, error);
      await this.telegramNotifier.sendMessage(chatId,
        `❌ Error processing /img command.\n\n` +
        `Error: ${error.message || 'Unknown error'}`,
        { parse_mode: 'Markdown' }
      );
    }
  }

  async handleYoloCommand(chatId, isScheduled = false) {
    let yoloState = null;
    let workspace = null;  // Declare at method scope for catch block access

    // Helper function to update YOLO status message (edit existing message)
    // Defined at method scope so it's accessible from both try and catch blocks
    const resendYoloStatus = async (message, options = {}) => {
      // If we have an existing message ID, update it instead of creating a new one
      if (yoloState && yoloState.yoloStatusMessageId) {
        try {
          // Use updateYoloStatus to edit the existing message
          logger.debug(`[YOLO] Updating existing message ${yoloState.yoloStatusMessageId}`);
          await this.telegramNotifier.updateYoloStatus(
            chatId,
            yoloState.yoloStatusMessageId,
            message,
            options
          );
          logger.debug(`[YOLO] Successfully updated message ${yoloState.yoloStatusMessageId}`);
        } catch (updateError) {
          // If update fails (message was deleted), send a new one
          logger.warn(`[YOLO] Failed to update message ${yoloState.yoloStatusMessageId}: ${updateError.message}`);
          logger.info(`[YOLO] Creating new message since update failed`);

          // Send new message only if update fails
          const result = await this.telegramNotifier.sendYoloStatus(chatId, message, {
            ...options,
            workspace,
            skipAutoPin: !options.showCompletedButtons  // Only pin completion messages
          });

          // Update message ID
          if (result && result.result && result.result.message_id) {
            const newMessageId = result.result.message_id;
            if (yoloState) {
              yoloState.yoloStatusMessageId = newMessageId;
            }

            // IMPORTANT: Persist the new message ID to database to avoid race conditions
            // when other processes (like auto-progress tasks) try to use the old ID
            try {
              await this.workspaceManager.updateYoloStatusMessageId(workspace.id, newMessageId);
              logger.debug(`[YOLO] New message ID ${newMessageId} persisted to database`);
            } catch (updateError) {
              logger.error(`[YOLO] Failed to persist new message ID: ${updateError.message}`);
            }
          }

          return result;
        }
      } else {
        // No existing message, send a new one
        logger.info(`[YOLO] No existing message ID, sending new status message`);
        const result = await this.telegramNotifier.sendYoloStatus(chatId, message, {
          ...options,
          workspace,
          skipAutoPin: !options.showCompletedButtons  // Only pin completion messages
        });

        // Update message ID
        if (result && result.result && result.result.message_id) {
          const newMessageId = result.result.message_id;
          if (yoloState) {
            yoloState.yoloStatusMessageId = newMessageId;
          }
        }

        return result;
      }
    };

    try {
      const { WorkspaceManager } = await import('./workspace-manager.js');
      const manager = new WorkspaceManager();
      await manager.initialize();

      // If this is a scheduled start, send notification
      if (isScheduled) {
        await this.telegramNotifier.sendMessage(chatId,
          `🚀 *Scheduled YOLO Starting Now!*\n\n` +
          `Executing all pending plans automatically...`,
          { parse_mode: 'Markdown' }
        );
      }

      // Get workspace for this chat
      workspace = await manager.getWorkspaceForTelegramChat(String(chatId));
      if (!workspace) {
        // In gateway mode, ensure gateway workspace exists in database
        if (config.gateway.enabled) {
          workspace = await manager.ensureGatewayWorkspace();
          logger.debug('Gateway mode: Using gateway workspace for Telegram /yolo');
        } else {
          await this.telegramNotifier.sendMessage(chatId,
            `❌ *No workspace connected*\n\n` +
            `Connect to a workspace first:\n` +
            `1. Generate token: \`ani-code workspace token gen\`\n` +
            `2. Connect: \`/connect <token>\``,
            { parse_mode: 'Markdown' }
          );
          await manager.close();
          return;
        }
      }

      // Check if YOLO mode is already active for this workspace
      if (workspace.yolo_mode_active) {
        await this.telegramNotifier.sendMessage(chatId,
          `❌ *YOLO mode already running*\n\n` +
          `Project: ${workspace.name}\n` +
          `A YOLO session is currently active for this workspace.\n\n` +
          `Use /stopyolo to stop the current session first.`,
          { parse_mode: 'Markdown' }
        );
        await manager.close();
        return;
      }

      // Get all pending plans
      const plans = await manager.listPlans(workspace.id);
      const pendingPlans = plans.filter(p => p.status === 'pending' || p.status === 'in_progress');

      if (pendingPlans.length === 0) {
        await this.telegramNotifier.sendMessage(chatId,
          `❌ *No pending plans found*\n\n` +
          `Create plans with: \`/plan <steps>\``,
          { parse_mode: 'Markdown' }
        );
        await manager.close();
        return;
      }

      // Take initial usage snapshot for cost tracking
      const usageReporter = this.taskMonitor.usageReporter;
      let initialSnapshot = null;
      const startTime = new Date();

      if (usageReporter) {
        initialSnapshot = await usageReporter.createTaskSnapshot('yolo-session', 'YOLO Session', { source: 'yolo' });
      }

      // Track execution data for consolidated status updates
      const executionData = {
        startTime: Date.now(),
        commits: [],
        usage: { cost: 0, tokens: 0 },
        currentStepIndex: 0,
        totalSteps: pendingPlans.reduce((sum, p) => sum + (p.steps?.length || 0), 0),
        messageVersion: 0,  // Track message version for troubleshooting
        lastCompletedPlan: null,  // Track last completed plan
        nextPlan: null,  // Track next plan to be executed
        resend: false,  // Flag to control message resending vs editing
        providerId: null  // Track current CLI provider being used
      };

      // Create initial yolo status message
      let yoloStatusMessageId = null;

      const initialStatusMessage = await this.telegramNotifier.formatYoloStatusMessage(
        workspace.name,
        pendingPlans.length,
        0,
        null,
        'starting',
        executionData
      );

      const messageResult = await this.telegramNotifier.sendYoloStatus(
        chatId,
        initialStatusMessage,
        { showButtons: true, workspace }
      );

      // Extract message ID from the result structure
      if (messageResult) {
        // Handle both direct message_id and nested result.message_id
        if (messageResult.message_id) {
          yoloStatusMessageId = messageResult.message_id;
        } else if (messageResult.result && messageResult.result.message_id) {
          yoloStatusMessageId = messageResult.result.message_id;
        }

        if (yoloStatusMessageId) {
          logger.info(`YOLO status message created with ID: ${yoloStatusMessageId}`);
        } else {
          logger.error(`Failed to extract message ID from sendYoloStatus result:`, messageResult);
        }
      } else {
        logger.error(`sendYoloStatus returned null or undefined`);
      }

      // Activate yolo mode protection for workspace
      await manager.setYoloModeActive(
        workspace.id,
        true,
        yoloStatusMessageId,
        pendingPlans.length
      );

      // Track state for yolo execution
      yoloState = {
        isActive: true,
        currentPlanIndex: 0,
        executedPlans: [],
        failedPlans: [],
        initialPlansTotal: pendingPlans.length,  // Store initial total
        startTime: startTime,
        initialSnapshot: initialSnapshot,
        executionData: executionData,
        yoloStatusMessageId: yoloStatusMessageId,
        workspaceId: workspace.id,
        workspaceName: workspace.name,
        statusUpdateInterval: null,
        lastStatusUpdate: Date.now(),
        messageResendTTL: 300  // TTL in seconds - initial 5 minutes (300s)
      };

      // Store yolo state for this chat
      if (!this.yoloStates) {
        this.yoloStates = new Map();
      }
      this.yoloStates.set(chatId, yoloState);

      // Set up 15-second interval to update status message with running time
      yoloState.statusUpdateInterval = setInterval(async () => {
        if (!yoloState.isActive || !yoloState.yoloStatusMessageId) {
          clearInterval(yoloState.statusUpdateInterval);
          return;
        }

        // Only update if it's been at least 15 seconds since last update
        const timeSinceLastUpdate = Date.now() - yoloState.lastStatusUpdate;
        if (timeSinceLastUpdate < 14000) return; // Skip if less than 14 seconds

        try {
          // Decrement TTL by 15 seconds on each interval
          yoloState.messageResendTTL -= 15;

          // Get current plan being executed
          const currentPlan = yoloState.currentPlan || null;
          const status = currentPlan ? 'executing' : 'starting';

          // Use dynamic total when new plans are added
          const totalPlans = Math.max(
            yoloState.initialPlansTotal,
            yoloState.executedPlans.length + yoloState.failedPlans.length + (currentPlan ? 1 : 0)
          );
          const statusMessage = await this.telegramNotifier.formatYoloStatusMessage(
            yoloState.workspaceName,
            totalPlans,
            yoloState.executedPlans.length,
            currentPlan,
            status,
            yoloState.executionData
          );

          // Check if TTL expired OR explicit resend flag is set
          // IMPORTANT: When autopin is enabled, skip TTL-based resends
          // Pinned messages stay visible at top, so no need to delete/resend
          // Only honor explicit resend requests (for new plans or other triggers)
          const showProgressMode = workspace.settings?.showprogress || 'autopin';
          const isAutoPinMode = showProgressMode === 'autopin';
          const shouldResend = (yoloState.messageResendTTL <= 0 && !isAutoPinMode) || yoloState.executionData.resend;

          if (shouldResend) {
            logger.debug(`[YOLO TTL] Resending status message (TTL=${yoloState.messageResendTTL}s, resend=${yoloState.executionData.resend}, autopin=${isAutoPinMode})`);
            await resendYoloStatus(statusMessage, { showButtons: true });
            yoloState.executionData.resend = false;  // Reset flag after resending
            yoloState.messageResendTTL = 300;  // Reset TTL to 5 minutes after resend
            logger.debug(`[YOLO TTL] TTL reset to 300s after resend`);
          } else {
            if (isAutoPinMode && yoloState.messageResendTTL <= 0) {
              logger.debug(`[YOLO TTL] Skipping resend in autopin mode - editing pinned message instead (TTL=${yoloState.messageResendTTL}s)`);
              yoloState.messageResendTTL = 300;  // Reset TTL to prevent continuous logging
            } else {
              logger.debug(`[YOLO TTL] Updating existing message (TTL=${yoloState.messageResendTTL}s remaining)`);
            }
            await this.telegramNotifier.updateYoloStatus(
              chatId,
              yoloState.yoloStatusMessageId,
              statusMessage,
              { showButtons: true }
            );
          }

          yoloState.lastStatusUpdate = Date.now();
          logger.debug(`[YOLO] Status updated with running time`);
        } catch (error) {
          logger.error(`[YOLO] Failed to update status: ${error.message}`);
        }
      }, 15000); // Run every 15 seconds

      // Execute plans sequentially - check for new plans after each completion
      let planIndex = 0;
      let lastKnownPlanCount = pendingPlans.length;

      logger.info(`Starting YOLO execution with ${pendingPlans.length} initial plans`);

      while (yoloState.isActive) {
        // Re-check for pending plans (including newly added ones)
        const currentPlans = await manager.listPlans(workspace.id);
        logger.debug(`Total plans in workspace: ${currentPlans.length}`);

        const currentPendingPlans = currentPlans.filter(p =>
          (p.status === 'pending' || p.status === 'in_progress') &&
          !yoloState.executedPlans.includes(p.plan_id) &&
          !yoloState.failedPlans.includes(p.plan_id)
        );

        logger.info(`YOLO: Found ${currentPendingPlans.length} pending plans to execute`);
        logger.debug(`Executed: ${yoloState.executedPlans.length}, Failed: ${yoloState.failedPlans.length}`);

        if (currentPendingPlans.length === 0) {
          logger.info(`No more pending plans to execute in YOLO mode`);
          // No more pending plans
          break;
        }

        // Check if new plans were added
        const totalKnownPlans = yoloState.executedPlans.length + yoloState.failedPlans.length + currentPendingPlans.length;
        if (totalKnownPlans > lastKnownPlanCount) {
          const newPlansCount = totalKnownPlans - lastKnownPlanCount;

          // Get current cost if available
          let costInfo = '';
          if (usageReporter && yoloState.initialSnapshot) {
            const currentSnapshot = await usageReporter.createTaskCompletionSnapshot('yolo-session', 'YOLO Session', { source: 'yolo' });
            if (currentSnapshot && currentSnapshot.cost > 0) {
              costInfo = `💰 Current Total: $${currentSnapshot.cost.toFixed(4)}\n`;
            }
          }

          // Update total plans if new ones were added
          const newTotal = currentPendingPlans.length + yoloState.executedPlans.length + yoloState.failedPlans.length;
          if (newTotal > yoloState.initialPlansTotal) {
            yoloState.initialPlansTotal = newTotal;
          }

          // Update status message to show new plans detected
          if (yoloState.yoloStatusMessageId) {
            const statusMessage = await this.telegramNotifier.formatYoloStatusMessage(
              yoloState.workspaceName,
              yoloState.initialPlansTotal,
              yoloState.executedPlans.length,
              null,
              'new_plans_detected',
              yoloState.executionData
            );

            // In autopin mode, just edit the pinned message - no need to resend
            // In normal mode, resend to keep at bottom when new plans are detected
            const isAutoPinMode = (workspace.settings?.showprogress || 'autopin') === 'autopin';
            if (isAutoPinMode) {
              logger.info(`[YOLO] Updating pinned status after detecting new plans`);
              await this.telegramNotifier.updateYoloStatus(
                chatId,
                yoloState.yoloStatusMessageId,
                statusMessage,
                { showButtons: true }
              );
            } else {
              // Reduce TTL to trigger resend sooner when new plans detected
              yoloState.messageResendTTL = Math.min(yoloState.messageResendTTL, 10);
              logger.debug(`[YOLO TTL] New plans detected - TTL set to ${yoloState.messageResendTTL}s`);
              logger.info(`[YOLO] Resending status after detecting new plans`);
              await resendYoloStatus(statusMessage, { showButtons: true });
              yoloState.executionData.resend = false;  // Reset flag after resending
            }
          }
          lastKnownPlanCount = totalKnownPlans;
        }

        const plan = currentPendingPlans[0]; // Get the next pending plan
        yoloState.currentPlanIndex = planIndex;
        yoloState.currentPlan = plan; // Store for interval updates

        // Update next plan in execution data
        if (currentPendingPlans.length > 1) {
          yoloState.executionData.nextPlan = currentPendingPlans[1];
        } else {
          yoloState.executionData.nextPlan = null;
        }

        logger.info(`YOLO executing plan ${plan.plan_id}: ${plan.title || 'Untitled'}, steps: ${plan.steps ? plan.steps.length : 0}`);

        // Announce current plan with current cost
        const totalProcessed = yoloState.executedPlans.length + yoloState.failedPlans.length + 1;

        // Get current cost if available
        let costLine = '';
        if (usageReporter && yoloState.initialSnapshot) {
          const currentSnapshot = await usageReporter.createTaskCompletionSnapshot('yolo-session', 'YOLO Session', { source: 'yolo' });
          if (currentSnapshot && currentSnapshot.cost > 0) {
            costLine = `💰 Current Total: $${currentSnapshot.cost.toFixed(4)}\n`;
          }
        }

        // Update status message instead of sending new message for plan
        if (yoloState.yoloStatusMessageId) {
          const enhancedPlan = {
            ...plan,
            currentStep: 0,
            totalSteps: plan.steps ? plan.steps.length : 0
          };

          const statusMessage = await this.telegramNotifier.formatYoloStatusMessage(
            yoloState.workspaceName,
            yoloState.initialPlansTotal,
            yoloState.executedPlans.length,
            enhancedPlan,
            'executing',
            yoloState.executionData
          );

          // Always resend to keep at bottom
          // Reduce TTL to trigger resend sooner during plan check
          yoloState.messageResendTTL = Math.min(yoloState.messageResendTTL, 10);
          logger.debug(`[YOLO TTL] Plan check - TTL set to ${yoloState.messageResendTTL}s`);
          logger.info(`[YOLO] Resending status for plan check with existing task`);
          await resendYoloStatus(statusMessage, { showButtons: true });
          yoloState.executionData.resend = false;  // Reset flag after resending
        }

        // Execute all steps of this plan
        const steps = normalizePlanSteps(plan.steps || []);
        plan.steps = steps;
        const startStep = plan.current_step || 0;

        if (steps.length === 0) {
          logger.warn(`Plan ${plan.plan_id} has no steps, marking as completed`);
          await manager.updatePlanStatus(workspace.id, plan.plan_id, 'completed');

          // Update last completed plan for no-step plans too
          yoloState.executionData.lastCompletedPlan = plan;

          yoloState.executedPlans.push(plan.plan_id);
          planIndex++;
          continue;
        }

        for (let stepIndex = startStep; stepIndex < steps.length; stepIndex++) {
          if (!yoloState.isActive) break;

          const stepInfo = normalizePlanStep(steps[stepIndex]);
          const stepDisplay = getPlanStepDisplayText(stepInfo);

          // Update plan status
          await manager.updatePlanStatus(workspace.id, plan.plan_id, 'in_progress', stepIndex);

          // Create task for this step
          const taskName = `yolo-plan-${plan.plan_id}-step-${stepIndex + 1}`;
          const taskOptions = {
            cwd: workspace.path,
            source: 'yolo',
            chatId: `telegram:${chatId}`,
            planId: plan.plan_id,
            stepIndex: stepIndex
          };

          if (stepInfo.providerId) {
            taskOptions.providerId = stepInfo.providerId;
          }
          if (stepInfo.model) {
            taskOptions.model = stepInfo.model;
          }

          const task = this.taskMonitor.addTask(
            taskName,
            stepInfo.command,
            taskOptions
          );

          // Update status message with current step instead of sending individual messages
          if (yoloState.yoloStatusMessageId) {
            yoloState.executionData.currentStepIndex++;
            // Reduce TTL to trigger resend sooner when new task starts
            yoloState.messageResendTTL = Math.min(yoloState.messageResendTTL, 10);
            logger.debug(`[YOLO TTL] New task started - TTL set to ${yoloState.messageResendTTL}s`);
              const enhancedPlan = {
                ...plan,
                currentStep: stepIndex + 1,
                totalSteps: steps.length,
                currentStepText: stepDisplay
              };
            yoloState.currentPlan = enhancedPlan; // Update for interval

            const statusMessage = await this.telegramNotifier.formatYoloStatusMessage(
              yoloState.workspaceName,
              yoloState.initialPlansTotal,
              yoloState.executedPlans.length,
              enhancedPlan,
              'executing',
              yoloState.executionData
            );

            // Always resend to keep at bottom when starting a new step
            logger.info(`[YOLO] Resending status for step ${stepIndex + 1}/${steps.length} of plan ${plan.plan_id}`);
            await resendYoloStatus(statusMessage, { showButtons: true });
            yoloState.executionData.resend = false;  // Reset flag after resending
            yoloState.lastStatusUpdate = Date.now(); // Track manual update time
          } else {
            logger.warn(`No YOLO status message ID available for update during step execution`);
          }

          // Wait for task to complete
          await this.waitForTaskCompletion(task.id, chatId);

          // Update provider from completed task
          const completedTask = this.taskMonitor.getTaskById(task.id);
          if (completedTask && completedTask.providerId) {
            yoloState.executionData.providerId = completedTask.providerId;
          }

          // After task completes, resend YOLO status to keep it at the bottom
          if (yoloState.yoloStatusMessageId) {
            // Reduce TTL to trigger resend sooner when task completes
            yoloState.messageResendTTL = Math.min(yoloState.messageResendTTL, 10);
            logger.debug(`[YOLO TTL] Task completed - TTL set to ${yoloState.messageResendTTL}s`);
            logger.debug(`Recalling YOLO message with startTime: ${yoloState.executionData?.startTime}, elapsed: ${Date.now() - (yoloState.executionData?.startTime || Date.now())}ms`);
            const currentStatusMessage = await this.telegramNotifier.formatYoloStatusMessage(
              yoloState.workspaceName,
              yoloState.initialPlansTotal,
              yoloState.executedPlans.length,
              yoloState.currentPlan || plan,
              'executing',
              yoloState.executionData
            );

            await resendYoloStatus(currentStatusMessage, { showButtons: true });
            yoloState.executionData.resend = false;  // Reset flag after resending
          }

          // Check if task failed
          if (completedTask && completedTask.status === 'failed') {
            yoloState.failedPlans.push(plan.plan_id);

            // Update status message to show failure
            if (yoloState.yoloStatusMessageId) {
              const statusMessage = await this.telegramNotifier.formatYoloStatusMessage(
                yoloState.workspaceName,
                yoloState.initialPlansTotal,
                yoloState.executedPlans.length,
                plan,
                'failed',
                yoloState.executionData
              );

              // Always resend to keep at bottom when updating cost
              // Reduce TTL to trigger resend sooner when cost updates
              yoloState.messageResendTTL = Math.min(yoloState.messageResendTTL, 10);
              logger.debug(`[YOLO TTL] Cost updated - TTL set to ${yoloState.messageResendTTL}s`);
              logger.debug(`[YOLO] Resending status with updated cost information`);
              await resendYoloStatus(statusMessage, { showButtons: true });
              yoloState.executionData.resend = false;  // Reset flag after resending
            }
            break;
          }
        }

        // Mark plan as completed if all steps done
        if (!yoloState.failedPlans.includes(plan.plan_id)) {
          await manager.updatePlanStatus(workspace.id, plan.plan_id, 'completed');

          // Update last completed plan in execution data before adding to executed
          yoloState.executionData.lastCompletedPlan = plan;

          yoloState.executedPlans.push(plan.plan_id);

          // Update execution data with latest cost
          if (usageReporter && yoloState.initialSnapshot) {
            const currentSnapshot = await usageReporter.createTaskCompletionSnapshot('yolo-session', 'YOLO Session', { source: 'yolo' });
            if (currentSnapshot) {
              yoloState.executionData.usage.cost = currentSnapshot.cost;
              yoloState.executionData.usage.tokens = currentSnapshot.tokens || 0;
            }
          }

          // Resend status message to show plan completed and keep at bottom
          if (yoloState.yoloStatusMessageId) {
            const statusMessage = await this.telegramNotifier.formatYoloStatusMessage(
              yoloState.workspaceName,
              yoloState.initialPlansTotal,
              yoloState.executedPlans.length,
              plan,
              'completed',
              yoloState.executionData
            );

            logger.debug(`Resending YOLO status after plan ${plan.plan_id} completion`);
            // Always resend to keep at bottom after plan completes
            // Reduce TTL to trigger resend sooner after plan completion
            yoloState.messageResendTTL = Math.min(yoloState.messageResendTTL, 10);
            logger.debug(`[YOLO TTL] Plan completed - TTL set to ${yoloState.messageResendTTL}s`);
            await resendYoloStatus(statusMessage, { showButtons: true });
            yoloState.executionData.resend = false;  // Reset flag after resending
          } else {
            logger.warn(`No YOLO status message ID available for update after plan completion`);
          }

          // Check if there are any changes to commit
          let hasChanges = true;

          try {
            // Check git status for uncommitted changes
            const gitStatus = execSync('git status --porcelain', { cwd: workspace.path, encoding: 'utf8' });
            hasChanges = gitStatus.trim().length > 0;
          } catch (err) {
            // If git status fails, assume there are changes to be safe
            logger.warn('Failed to check git status, assuming changes exist:', err);
          }

          if (hasChanges) {
            // Resend status message to show committing and keep at bottom
            if (yoloState.yoloStatusMessageId) {
              const statusMessage = await this.telegramNotifier.formatYoloStatusMessage(
                yoloState.workspaceName,
                yoloState.initialPlansTotal,
                yoloState.executedPlans.length,
                { ...plan, currentStepText: 'Processing commit...' },
                'committing',
                yoloState.executionData
              );

              // Always resend to keep at bottom before commit starts
              // Reduce TTL to trigger resend sooner before commit starts
              yoloState.messageResendTTL = Math.min(yoloState.messageResendTTL, 10);
              logger.debug(`[YOLO TTL] Starting commit - TTL set to ${yoloState.messageResendTTL}s`);
              logger.debug(`Resending YOLO status before commit for plan ${plan.plan_id}`);
              await resendYoloStatus(statusMessage, { showButtons: true });
              yoloState.executionData.resend = false;  // Reset flag after resending
            }

            // Create commit task - use shell: prefix to run as shell command
            const commitTask = this.taskMonitor.addTask(
              `yolo-commit-${plan.plan_id}`,
              'shell:ani-code commit -y',
              {
                cwd: workspace.path,
                source: 'yolo',
                chatId: `telegram:${chatId}`
              }
            );

            // Wait for commit to complete
            await this.waitForTaskCompletion(commitTask.id, chatId);

            const completedCommit = this.taskMonitor.getTaskById(commitTask.id);
            if (completedCommit && completedCommit.status === 'completed') {
              // Extract commit hash and message using git
              let commitHash = null;
              let commitMessage = `[YOLO] Plan ${plan.plan_id} completed`;

              try {
                const { execSync } = await import('child_process');
                const fullHash = execSync('git rev-parse HEAD', { cwd: workspace.path, encoding: 'utf8' }).trim();
                commitHash = fullHash.substring(0, 7);
                const message = execSync(`git log -1 --format=%s ${fullHash}`, { cwd: workspace.path, encoding: 'utf8' }).trim();
                if (message) commitMessage = message;
              } catch (err) {
                logger.warn(`[YOLO] Failed to get commit info: ${err.message}`);
                // Fallback: try to extract from commit output
                if (completedCommit.output) {
                  const messageMatch = completedCommit.output.match(/📝 Commit: [a-f0-9]+ - "(.+?)"/);
                  if (messageMatch) {
                    commitMessage = messageMatch[1];
                  }
                }
              }

              // Add commit to execution data
              if (yoloState.executionData) {
                yoloState.executionData.commits.push({
                  planId: plan.plan_id,
                  hash: commitHash || 'unknown',
                  message: commitMessage
                });
              }

              // Send yolo status update after commit completes
              if (yoloState.yoloStatusMessageId) {
                // Reduce TTL to trigger resend sooner when commit completes
                yoloState.messageResendTTL = Math.min(yoloState.messageResendTTL, 10);
                logger.debug(`[YOLO TTL] Commit completed - TTL set to ${yoloState.messageResendTTL}s`);
                const statusMessage = await this.telegramNotifier.formatYoloStatusMessage(
                  yoloState.workspaceName,
                  yoloState.initialPlansTotal,
                  yoloState.executedPlans.length,
                  plan,
                  'completed',
                  yoloState.executionData
                );

                // Always resend status after commit to keep message at bottom
                logger.info(`[YOLO] Resending status after commit for plan ${plan.plan_id}`);
                await resendYoloStatus(statusMessage, { showButtons: true });
                yoloState.executionData.resend = false;  // Reset flag after resending
              }
            }
          } else {
            // No changes to commit
          }
        }

        // Increment plan index for next iteration
        planIndex++;
      }

      // Calculate total cost and time
      const endTime = new Date();
      const duration = Math.round((endTime - yoloState.startTime) / 1000); // in seconds
      const formattedDuration = duration >= 60
        ? `${Math.floor(duration / 60)}m ${duration % 60}s`
        : `${duration}s`;

      let costInfo = '';
      let finalSnapshot = null;
      if (usageReporter && yoloState.initialSnapshot) {
        finalSnapshot = await usageReporter.createTaskCompletionSnapshot('yolo-session', 'YOLO Session', { source: 'yolo' });
        if (finalSnapshot) {
          costInfo = `\n💰 Total Cost: $${finalSnapshot.cost.toFixed(4)}\n` +
                     `🔤 Total Tokens: ${finalSnapshot.tokens.toLocaleString()}\n`;

          // Log model breakdown if available
          if (finalSnapshot.modelBreakdown && finalSnapshot.modelBreakdown.length > 0) {
            logger.info(`YOLO Session Model Usage:`, finalSnapshot.modelBreakdown);
          }
        }
      }

      // Update final execution data
      if (yoloState.executionData) {
        yoloState.executionData.usage.cost = finalSnapshot?.cost || 0;
        yoloState.executionData.usage.tokens = finalSnapshot?.tokens || 0;
      }

      // Clear yolo mode protection and interval
      if (yoloState.statusUpdateInterval) {
        clearInterval(yoloState.statusUpdateInterval);
        yoloState.statusUpdateInterval = null;
      }
      await manager.setYoloModeActive(workspace.id, false);

      // Send final status update - ALWAYS resend for completion
      if (yoloState.yoloStatusMessageId) {
        const finalStatusMessage = await this.telegramNotifier.formatYoloStatusMessage(
          yoloState.workspaceName,
          yoloState.initialPlansTotal,
          yoloState.executedPlans.length,
          null,
          'completed',
          yoloState.executionData
        );

        // UNPIN and RESEND completion message to keep it at the bottom
        // Step 1: Unpin the old message if it was pinned
        const oldMessageId = yoloState.yoloStatusMessageId;
        try {
          await this.telegramNotifier.api.unpinChatMessage(chatId, oldMessageId);
          logger.info(`[YOLO COMPLETE] Unpinned old status message ${oldMessageId}`);
        } catch (unpinError) {
          logger.debug(`[YOLO COMPLETE] No message to unpin (already unpinned or deleted): ${unpinError.message}`);
        }

        // Step 2: Clear the old message ID to force sending a new message
        const savedMessageId = yoloState.yoloStatusMessageId;
        yoloState.yoloStatusMessageId = null;  // Temporarily clear to force new message

        // Step 3: Send new completion message at the bottom
        logger.info(`[YOLO COMPLETE] Sending new completion message after unpinning ${savedMessageId}`);
        const result = await this.telegramNotifier.sendYoloStatus(chatId, finalStatusMessage, {
          showCompletedButtons: true,
          workspace,
          skipAutoPin: true  // Don't auto-pin the completion message
        });

        // Step 4: Update with new message ID if successful
        if (result && result.result && result.result.message_id) {
          const newMessageId = result.result.message_id;
          yoloState.yoloStatusMessageId = newMessageId;
          try {
            await this.workspaceManager.updateYoloStatusMessageId(workspace.id, newMessageId);
            logger.info(`[YOLO COMPLETE] New completion message ${newMessageId} sent and saved`);
          } catch (updateError) {
            logger.error(`[YOLO COMPLETE] Failed to persist new message ID: ${updateError.message}`);
          }
        }
      }

      // Clean up state
      this.yoloStates.delete(chatId);
      await manager.close();

    } catch (error) {
      logger.error(`YOLO command failed: ${error.message}`);

      // Clear protection and interval on error
      try {
        if (yoloState) {
          if (yoloState.statusUpdateInterval) {
            clearInterval(yoloState.statusUpdateInterval);
            yoloState.statusUpdateInterval = null;
          }
          if (yoloState.workspaceId) {
            // Create new manager instance for cleanup since we're in catch block
            const cleanupManager = new WorkspaceManager();
            await cleanupManager.initialize();
            await cleanupManager.setYoloModeActive(yoloState.workspaceId, false);
            await cleanupManager.close();
          }
        }
      } catch (cleanupError) {
        logger.error(`Failed to clear yolo protection: ${cleanupError.message}`);
      }

      // Send error status message - ALWAYS resend for final states
      if (yoloState && yoloState.yoloStatusMessageId) {
        const errorMessage = await this.telegramNotifier.formatYoloStatusMessage(
          yoloState.workspaceName,
          yoloState.initialPlansTotal,
          yoloState.executedPlans.length,
          null,
          'error',
          yoloState.executionData
        );

        // Always resend error message to keep it at the bottom
        // Force resend on error
        if (yoloState.executionData) {
          yoloState.executionData.resend = true;  // Keep immediate resend for errors
          logger.debug(`[YOLO TTL] Error occurred - forcing immediate resend`);
        }
        await resendYoloStatus(
          `${errorMessage}\n\n❌ Error: ${error.message}`,
          { showCompletedButtons: true }
        );
      } else {
        await this.telegramNotifier.sendMessage(chatId,
          `❌ YOLO mode failed: ${error.message}`,
          { parse_mode: 'Markdown' }
        );
      }

      // Clean up state on error
      if (this.yoloStates) {
        this.yoloStates.delete(chatId);
      }
    }
  }

  async waitForTaskCompletion(taskId, chatId, timeoutMs = 600000) {
    return new Promise((resolve) => {
      const startTime = Date.now();
      let updateCounter = 0; // Track updates to avoid too frequent message edits

      const checkInterval = setInterval(async () => {
        const task = this.taskMonitor.getTaskById(taskId);

        if (!task || task.status === 'completed' || task.status === 'failed' ||
            task.status === 'cancelled' || task.status === 'error') {
          clearInterval(checkInterval);
          resolve(task);
          return;
        }

        // Check for timeout
        if (Date.now() - startTime > timeoutMs) {
          clearInterval(checkInterval);
          logger.warn(`Task ${taskId} timed out after ${timeoutMs}ms`);
          resolve(null);
          return;
        }

        // Check if yolo was stopped
        if (this.yoloStates && this.yoloStates.has(chatId)) {
          const state = this.yoloStates.get(chatId);
          if (!state.isActive) {
            clearInterval(checkInterval);
            resolve(null);
            return;
          }
        }

        // Check if goalloop was stopped
        if (this.goalLoopStates && this.goalLoopStates.has(chatId)) {
          const state = this.goalLoopStates.get(chatId);
          if (!state.isActive) {
            clearInterval(checkInterval);
            logger.info(`[GOALLOOP] Task ${taskId} cancelled - loop stopped by user`);
            resolve(null);
            return;
          }

          // Update goal loop status message every 5 seconds (every 5th iteration)
          updateCounter++;
          if (updateCounter % 5 === 0) {
            try {
              await this.updateGoalLoopMessage(chatId, state, 'implementing');
            } catch (error) {
              logger.debug(`[GOALLOOP] Failed to update status message: ${error.message}`);
            }
          }
        }
      }, 1000); // Check every second
    });
  }

  async handleTelegramConnect(chatId, token) {
    try {
      const result = await this.workspaceManager.connectTelegramChatWithToken(String(chatId), token);
      
      if (result.success) {
        await this.telegramNotifier.sendMessage(chatId,
          `✅ *Successfully connected!*\n\n` +
          `Workspace: *${result.workspace_name}*\n` +
          `Path: \`${result.workspace_path}\`\n\n` +
          `You can now use all bot commands in this chat.\n` +
          `Type /help to see available commands.`,
          { parse_mode: 'Markdown' }
        );
        
        // Set the workspace for this chat
        const fullChatId = `telegram:${chatId}`;
        await this.chatSettings.setWorkdir(fullChatId, result.workspace_name, result.workspace_path);
        await this.chatSettings.save(); // Ensure settings are persisted
        
        logger.info(`Telegram chat ${chatId} connected to workspace ${result.workspace_name} with path ${result.workspace_path}`);
      }
    } catch (error) {
      logger.error(`Failed to connect Telegram chat ${chatId} with token:`, error);
      await this.telegramNotifier.sendMessage(chatId,
        `❌ *Connection failed*\n\n${error.message}\n\n` +
        `Please check your token and try again.`,
        { parse_mode: 'Markdown' }
      );
    }
  }

  async handleTelegramDisconnect(chatId) {
    const success = await this.workspaceManager.revokeTelegramChatAuth(String(chatId));
    
    if (success) {
      // Clear the workspace setting for this chat
      const fullChatId = `telegram:${chatId}`;
      await this.chatSettings.removeWorkdir(fullChatId);
      
      await this.telegramNotifier.sendMessage(chatId,
        `✅ *Disconnected from workspace*\n\n` +
        `This chat is no longer connected to any workspace.\n` +
        `Use \`/connect <token>\` to connect to a new workspace.`,
        { parse_mode: 'Markdown' }
      );
      
      logger.info(`Telegram chat ${chatId} disconnected from workspace`);
    } else {
      await this.telegramNotifier.sendMessage(chatId,
        `ℹ️ *Not connected*\n\n` +
        `This chat is not currently connected to any workspace.\n` +
        `Use \`/connect <token>\` to connect to a workspace.`,
        { parse_mode: 'Markdown' }
      );
    }
  }

  async handleCheckCommand(chatId, args, platform = 'lark') {
    try {
      // Get workspace for this chat - use same approach as /add command
      const fullChatId = platform === 'telegram' ? `telegram:${chatId}` : chatId;
      
      // First, get the selected workdir from chat settings (this is what /add uses)
      const selectedWorkdirName = this.chatSettings.getWorkdir(fullChatId);
      logger.info(`Check command for chat ${fullChatId}, selected workdir: ${selectedWorkdirName}`);
      
      // Get all available workdirs (combines config + workspace-connected dirs)
      const availableWorkdirs = await this.getAvailableWorkdirs(fullChatId);
      logger.info(`Available workdirs for ${fullChatId}:`, Object.keys(availableWorkdirs));
      
      if (!selectedWorkdirName) {
        throw new Error('No working directory selected. Use /workdir [name] to select a workspace.');
      }
      
      const workspacePath = availableWorkdirs[selectedWorkdirName];
      
      if (!workspacePath) {
        throw new Error(`Workspace "${selectedWorkdirName}" is no longer available. Use /connect [token] to reconnect.`);
      }
      
      const workspaceName = selectedWorkdirName;
      
      // Now try to get custom checklist from workspace settings if available
      let customChecklist = null;
      try {
        const { WorkspaceManager } = await import('./workspace-manager.js');
        const manager = new WorkspaceManager();
        await manager.initialize();
        
        const workspace = await manager.getWorkspaceForChat(fullChatId);
        if (workspace && workspace.settings && workspace.settings.checklist) {
          customChecklist = workspace.settings.checklist;
        }
        
        await manager.close();
      } catch (error) {
        logger.debug(`Could not get custom checklist: ${error.message}`);
        // It's OK if we can't get custom checklist, we'll use default
      }
      
      logger.info(`Running check command for chat ${fullChatId} in workspace: ${workspaceName} at ${workspacePath}`);
      
      // Prepare checklist prompt
      let checklistPrompt;
      
      // Use custom checklist if provided, otherwise use default
      if (customChecklist) {
        checklistPrompt = `Run these checks for workspace "${workspaceName}":

${customChecklist}

Format output as:
✅ Passed: [brief list]
⚠️ Warnings: [brief list]
❌ Failed: [brief list]

If fixes needed, suggest them briefly.`;
      } else {
        // Default comprehensive checks
        checklistPrompt = `Run comprehensive checks for workspace "${workspaceName}" at path: ${workspacePath}

Please check the following:

1. Build status (if applicable - check package.json scripts or Makefile)
2. Test results (if tests exist - run test command if available)
3. Lint/format errors (if configured - check for lint/format scripts)
4. Git status (check for uncommitted changes)
5. Service health (if applicable):
   - Check if any .service files exist in the project
   - If project has a systemd service (check README or .service files), run: journalctl -u <service-name> -n 50 --no-pager
   - For ani-code itself: journalctl -u ani-code -n 20 --no-pager | grep -i error
6. Runtime errors (check recent logs for any ERROR or WARN messages)
7. Dependencies (verify all dependencies are installed)

Format output as:
✅ Passed: [brief list of what's working]
⚠️ Warnings: [brief list of issues that need attention]
❌ Failed: [brief list of critical issues]

If fixes needed, suggest them briefly with specific commands or actions.`;
      }
      
      // Add any additional arguments from user
      if (args) {
        checklistPrompt += `\n\nAdditional requirements from user: ${args}`;
      }
      
      // Create a task to run the checklist with -c flag for continue mode
      const taskName = `claude-check-${Date.now()}`;
      const taskCommand = `-c ${checklistPrompt}`;
      const taskOptions = {
        cwd: workspacePath,  // Use the properly detected workspace path
        source: `${platform}_check_command`,
        chatId: fullChatId
      };
      
      const task = this.taskMonitor.addTask(taskName, taskCommand, taskOptions);
      
      logger.info(`Created checklist task: ${task.id} for ${platform} chat ${chatId} in workspace: ${workspacePath}`);
      
      // Send confirmation message
      if (platform === 'telegram') {
        // Create inline keyboard with process button
        const keyboard = {
          inline_keyboard: [[
            {
              text: '▶️ Watch Task Progress',
              callback_data: `/process ${task.id}`
            }
          ]]
        };
        
        await this.telegramNotifier.sendMessage(chatId,
          `✅ *Running completion checklist...*\n\n` +
          `*Workspace:* ${workspaceName}\n` +
          `*Path:* \`${workspacePath}\`\n` +
          `*Task ID:* \`${task.id}\`\n\n` +
          `I'll check build status, tests, code quality, service logs, and more.`,
          { 
            parse_mode: 'Markdown',
            reply_markup: keyboard
          }
        );
      } else if (this.taskMonitor.larkNotifier) {
        await this.taskMonitor.larkNotifier.sendCustomMessage(
          '✅ Running Completion Checklist',
          `Starting comprehensive checks for workspace: ${workspaceName}\n` +
          `Path: ${workspacePath}\n\n` +
          `Task ID: ${task.id}\n\n` +
          `I'll check:\n• Build & compilation\n• Test suite\n• Code quality\n• Service logs\n• Git status\n• Dependencies`,
          'blue',
          chatId
        );
      }
      
    } catch (error) {
      logger.error(`Failed to handle check command: ${error.message}`);
      
      // Send error message
      if (platform === 'telegram') {
        await this.telegramNotifier.sendMessage(chatId,
          `❌ Failed to start checklist: ${error.message}`,
          { parse_mode: 'Markdown' }
        );
      } else if (this.taskMonitor.larkNotifier) {
        await this.taskMonitor.larkNotifier.sendCustomMessage(
          '❌ Checklist Error',
          `Failed to start checklist: ${error.message}`,
          'red',
          chatId
        );
      }
    }
  }

  async handleGoalsCommand(chatId, args, platform = 'telegram') {
    try {
      const fullChatId = platform === 'telegram' ? `telegram:${chatId}` : chatId;
      const selectedWorkdirName = this.chatSettings.getWorkdir(fullChatId);

      if (!selectedWorkdirName) {
        throw new Error('No working directory selected. Use /workdir [name] to select a workspace.');
      }

      const availableWorkdirs = await this.getAvailableWorkdirs(fullChatId);
      const workspacePath = availableWorkdirs[selectedWorkdirName];

      if (!workspacePath) {
        throw new Error(`Selected workspace "${selectedWorkdirName}" not found or not available.`);
      }

      // Import goals utilities
      const { findGoalFiles, parseGoalFile, generateProgressBar } = await import('./utils/goals-utils.js');
      const { createGoalsProcessor } = await import('./utils/goals-processor.js');

      const goalsDir = path.join(workspacePath, 'pd', 'goals');
      const processor = createGoalsProcessor(goalsDir);

      // Check for specific subcommand
      const subcommand = args ? args.split(' ')[0] : 'list';
      const subargs = args ? args.substring(subcommand.length).trim() : '';

      switch (subcommand) {
        case 'list':
        case 'ls':
          // Load cache or sync if needed
          let { data: cacheData, exists } = await processor.loadCache();
          if (!exists || !cacheData) {
            await this.telegramNotifier.sendMessage(chatId,
              '🔄 Syncing goals cache...',
              { parse_mode: 'Markdown' }
            );
            await processor.processGoals('sync');
            const result = await processor.loadCache();
            cacheData = result.data;
          }

          if (!cacheData || !cacheData.goals || cacheData.goals.length === 0) {
            await this.telegramNotifier.sendMessage(chatId,
              '📋 No goals found in workspace',
              { parse_mode: 'Markdown' }
            );
            return;
          }

          // Helper function to extract title from filename
          const extractTitleFromFile = (filename) => {
            if (!filename) return 'Untitled Goal';
            // Remove .md extension and goal number prefix (e.g., "001-foundation.md" -> "foundation")
            return filename
              .replace(/\.md$/, '')
              .replace(/^\d+-/, '')
              .split('-')
              .map(word => word.charAt(0).toUpperCase() + word.slice(1))
              .join(' ');
          };

          // Sort goals by ID first
          const sortedGoals = [...cacheData.goals].sort((a, b) => {
            const idA = parseInt(a.id) || 0;
            const idB = parseInt(b.id) || 0;
            return idA - idB;
          });

          // Split: last 5 goals always shown in full, earlier ones can be grouped
          const last5Index = Math.max(0, sortedGoals.length - 5);
          const earlyGoals = sortedGoals.slice(0, last5Index);
          const last5Goals = sortedGoals.slice(last5Index);

          // Group only early goals (compact completed ranges)
          const groups = [];
          let currentGroup = null;

          for (const goal of earlyGoals) {
            const goalId = goal.id || 'N/A';
            const goalTitle = goal.title || extractTitleFromFile(goal.file) || 'Untitled';
            const status = goal.progress?.status || goal.status || 'Not Started';
            const completion = goal.progress?.taskCompletion;
            const pctValue = completion?.percentage !== undefined ? completion.percentage : goal.completionPct;
            const taskCount = completion?.total || goal.taskCount || 0;
            const tasksDone = completion?.completed || goal.tasksComplete || 0;

            // Group consecutive completed goals (must be sequential IDs)
            if (status === 'Completed') {
              const currentId = parseInt(goalId) || 0;
              const expectedNextId = currentGroup ? parseInt(currentGroup.end) + 1 : currentId;

              if (!currentGroup || currentGroup.type !== 'completed' || currentId !== expectedNextId) {
                // Start new group
                currentGroup = { type: 'completed', start: goalId, end: goalId, count: 1, titles: [goalTitle] };
                groups.push(currentGroup);
              } else {
                // Extend current group
                currentGroup.end = goalId;
                currentGroup.count++;
                currentGroup.titles.push(goalTitle);
              }
            } else {
              currentGroup = null;
              groups.push({
                type: 'individual',
                id: goalId,
                title: goalTitle,
                status: status,
                pct: pctValue,
                taskCount: taskCount,
                tasksDone: tasksDone
              });
            }
          }

          // Last 5 goals are always individual (shown in full)
          for (const goal of last5Goals) {
            const goalId = goal.id || 'N/A';
            const goalTitle = goal.title || extractTitleFromFile(goal.file) || 'Untitled';
            const status = goal.progress?.status || goal.status || 'Not Started';
            const completion = goal.progress?.taskCompletion;
            const pctValue = completion?.percentage !== undefined ? completion.percentage : goal.completionPct;
            const taskCount = completion?.total || goal.taskCount || 0;
            const tasksDone = completion?.completed || goal.tasksComplete || 0;

            groups.push({
              type: 'individual',
              id: goalId,
              title: goalTitle,
              status: status,
              pct: pctValue,
              taskCount: taskCount,
              tasksDone: tasksDone
            });
          }

          // Format output with mixed styles
          let message = '*📋 Project Goals*\n\n';
          let hasActiveGoals = false;

          // Count completed goals in early groups (for the collapsed section)
          const earlyCompletedCount = groups.filter(g => g.type === 'completed').reduce((sum, g) => sum + g.count, 0);

          // Show collapsed completed summary (only early goals)
          if (earlyCompletedCount > 0) {
            message += '```\n';

            // Show each completed range on separate line
            for (const group of groups) {
              if (group.type === 'completed') {
                if (group.count === 1) {
                  // Single goal - show title
                  const title = group.titles[0].length > 30 ? group.titles[0].substring(0, 27) + '...' : group.titles[0];
                  message += `✓ ${String(group.start).padStart(3, ' ')} ${title}\n`;
                } else if (group.count <= 3) {
                  // Small range - show all titles
                  message += `✓ ${String(group.start).padStart(3, ' ')}-${String(group.end).padEnd(3, ' ')} (${group.count})\n`;
                  group.titles.forEach(title => {
                    const shortTitle = title.length > 30 ? title.substring(0, 27) + '...' : title;
                    message += `    • ${shortTitle}\n`;
                  });
                } else {
                  // Large range - collapsed summary
                  message += `✓ ${String(group.start).padStart(3, ' ')}-${String(group.end).padEnd(3, ' ')} (${group.count} completed)\n`;
                }
              }
            }

            message += '```\n';
          }

          // Then show individual goals (last 5 + any non-completed earlier ones)
          for (const group of groups) {
            if (group.type === 'individual') {
              // Skip cancelled and abandoned goals as they are not important
              if (group.status === 'Cancelled' || group.status === 'Abandoned') {
                continue;
              }

              hasActiveGoals = true;
              const icon = group.status === 'Completed' ? '✅' :
                          group.status === 'In Progress' ? '🚀' :
                          group.status === 'Not Started' ? '⏳' : '⚠️';

              // One-line format: Icon ID. Title (Progress%)
              let line = `${icon} *${group.id}.* ${group.title}`;

              // Show progress only for non-completed goals
              if (group.status !== 'Completed') {
                if (group.pct !== undefined) {
                  line += ` (${group.pct}%)`;
                } else if (group.taskCount > 0) {
                  line += ` (${group.tasksDone}/${group.taskCount})`;
                }
              }

              message += `\n${line}`;
            }
          }

          // Add summary statistics
          const stats = cacheData.summary || {};
          const statusCounts = stats.statusCounts || {};
          const total = stats.totalGoals || cacheData.goals.length;
          const completed = statusCounts['Completed'] || stats.completed || 0;
          const inProgress = statusCounts['In Progress'] || stats.inProgress || 0;
          const notStarted = statusCounts['Not Started'] || stats.notStarted || 0;

          message += `\n📊 *Summary:* ${completed} completed • ${total} total`;
          if (inProgress > 0) message += ` • ${inProgress} active`;
          if (notStarted > 0) message += ` • ${notStarted} pending`;

          // Add goalloop quick link if there are pending tasks
          if (inProgress > 0 || notStarted > 0) {
            message += `\n\n🤖 Run /goalloop to auto-complete pending tasks`;
          }

          await this.telegramNotifier.sendMessage(chatId, message, { parse_mode: 'Markdown' });
          break;

        case 'show':
        case 'view':
          const goalId = subargs;
          if (!goalId) {
            throw new Error('Please specify a goal ID. Usage: /goals show <id>');
          }

          const goalFiles = findGoalFiles(goalsDir);
          const goalFile = goalFiles.find(f => {
            const match = path.basename(f).match(/^(\d+)/);
            return match && match[1] === goalId.padStart(3, '0');
          });

          if (!goalFile) {
            throw new Error(`Goal ${goalId} not found`);
          }

          const goalData = await parseGoalFile(goalFile);
          const goalTitle = goalData.title || 'Untitled Goal';
          const goalObjective = goalData.objective || 'Not specified';

          let detailMessage = `*📋 Goal ${goalId}: ${goalTitle}*\n\n`;
          detailMessage += `*Objective:*\n${goalObjective}\n\n`;

          if (goalData.tasks && goalData.tasks.length > 0) {
            detailMessage += '*Tasks:*\n';
            for (const task of goalData.tasks) {
              const icon = task.completed ? '✅' : '⬜';
              const taskText = task.text || 'Untitled task';
              detailMessage += `${icon} ${taskText}\n`;
            }
            detailMessage += '\n';
          }

          if (goalData.progress) {
            detailMessage += '*Progress:*\n';
            const progressStatus = goalData.progress.status || 'Not Started';
            detailMessage += `Status: ${progressStatus}\n`;
            if (goalData.progress.startDate && goalData.progress.startDate !== '-') {
              detailMessage += `Started: ${goalData.progress.startDate}\n`;
            }
            if (goalData.progress.notes && goalData.progress.notes !== '-') {
              detailMessage += `Notes: ${goalData.progress.notes}\n`;
            }
          }

          await this.telegramNotifier.sendMessage(chatId, detailMessage, { parse_mode: 'Markdown' });
          break;

        default:
          await this.telegramNotifier.sendMessage(chatId,
            '*📋 Goal Commands:*\n\n' +
            '`/goals` - List all goals\n' +
            '`/goals show <id>` - Show goal details\n' +
            '`/goaladd <desc>` - Add new goal\n' +
            '`/goalcheck` - Check completion status\n' +
            '`/goalsync` - Sync goals cache\n' +
            '`/goalsync --fast` - Fast sync (skip fixes)\n' +
            '`/goalsync --full` - Full resync (all goals)\n' +
            '`/goalloop` - Run automation loop\n',
            { parse_mode: 'Markdown' }
          );
      }

    } catch (error) {
      logger.error(`Failed to handle goals command: ${error.message}`);
      await this.telegramNotifier.sendMessage(chatId,
        `❌ Failed: ${error.message}`,
        { parse_mode: 'Markdown' }
      );
    }
  }

  async handleGoalAddCommand(chatId, args, platform = 'telegram', options = {}) {
    const { multi = false } = options;
    try {
      if (!args) {
        const commandName = multi ? '/goaladdmulti' : '/goaladd';
        const description = multi
          ? 'Create multiple goals from a broad description'
          : 'Create new goal';
        await this.telegramNotifier.sendMessage(chatId,
          `*📝 ${multi ? 'Multi-Goal Add' : 'Goal Add'} Usage:*\n\n` +
          `\`${commandName} <description>\` - ${description}\n` +
          `Example: \`${commandName} Implement user authentication\`\n\n` +
          `The goal${multi ? '(s)' : ''} will be created with Claude\'s help based on your project requirements.`,
          { parse_mode: 'Markdown' }
        );
        return;
      }

      const fullChatId = platform === 'telegram' ? `telegram:${chatId}` : chatId;
      const selectedWorkdirName = this.chatSettings.getWorkdir(fullChatId);

      if (!selectedWorkdirName) {
        throw new Error('No working directory selected. Use /workdir [name] to select a workspace.');
      }

      const availableWorkdirs = await this.getAvailableWorkdirs(fullChatId);
      const workspacePath = availableWorkdirs[selectedWorkdirName];
      const goalsDir = path.join(workspacePath, 'pd', 'goals');

      // Import goals utilities
      const { findGoalFiles, extractGoalId } = await import('./utils/goals-utils.js');
      const { buildAddGoalPrompt } = await import('./prompts/goals-prompts.js');

      // Prepare goal add context
      const { existsSync, readFileSync, mkdirSync } = await import('fs');
      const { basename, join } = await import('path');

      // Create goals directory if needed
      if (!existsSync(goalsDir)) {
        mkdirSync(goalsDir, { recursive: true });
      }

      // Get existing goal files for context
      const goalFiles = findGoalFiles(goalsDir);
      const existingIds = goalFiles.map(f => extractGoalId(basename(f))).filter(id => id !== null);
      const goalId = existingIds.length > 0 ? Math.max(...existingIds) + 1 : 1;
      const paddedId = String(goalId).padStart(3, '0');
      const targetFile = join(goalsDir, `${paddedId}-new-goal.md`);

      // Get PRD content if exists
      const prdPath = join(workspacePath, 'pd', 'prd.md');
      const prdContent = existsSync(prdPath) ? readFileSync(prdPath, 'utf8') : '';

      // Get existing goal titles for conflict checking
      const existingGoalTitles = goalFiles.map(f => basename(f));

      // Build the improved prompt with analysis and conflict checking
      const prompt = buildAddGoalPrompt(args, {
        prdContent,
        goalId,
        targetFile,
        existingGoalTitles,
        merge: false,
        multi
      });

      // Create a task with the full analysis prompt
      const taskName = `goal-add-${Date.now()}`;
      const taskOptions = {
        cwd: workspacePath,
        source: `${platform}_goal_add`,
        chatId: fullChatId,
        providerId: await this.getCurrentProviderId()  // Track provider for footer/usage display
      };

      const task = this.taskMonitor.addTask(taskName, prompt, taskOptions);

      await this.telegramNotifier.sendMessage(chatId,
        `*📝 Creating Goal${multi ? '(s)' : ''}*\n\n` +
        `Description: \`${args}\`\n` +
        `Workspace: ${selectedWorkdirName}\n` +
        `${multi ? 'Starting' : ''} Goal ID: ${goalId}${multi ? '+' : ''}\n` +
        `Task ID: \`${task.id}\`\n\n` +
        `Claude is analyzing your project, checking for conflicts, and creating the goal${multi ? '(s)' : ''}...`,
        {
          parse_mode: 'Markdown',
          reply_markup: {
            inline_keyboard: [[
              { text: '▶️ Watch Progress', callback_data: `/process ${task.id}` }
            ]]
          }
        }
      );

    } catch (error) {
      logger.error(`Failed to handle goal_add command: ${error.message}`);
      await this.telegramNotifier.sendMessage(chatId,
        `❌ Failed: ${error.message}`,
        { parse_mode: 'Markdown' }
      );
    }
  }

  async handleGoalCheckCommand(chatId, platform = 'telegram') {
    try {
      const fullChatId = platform === 'telegram' ? `telegram:${chatId}` : chatId;
      const selectedWorkdirName = this.chatSettings.getWorkdir(fullChatId);

      if (!selectedWorkdirName) {
        throw new Error('No working directory selected. Use /workdir [name] to select a workspace.');
      }

      const availableWorkdirs = await this.getAvailableWorkdirs(fullChatId);
      const workspacePath = availableWorkdirs[selectedWorkdirName];

      // Import goals utilities
      const { generateProgressBar } = await import('./utils/goals-utils.js');
      const { createGoalsProcessor } = await import('./utils/goals-processor.js');

      const goalsDir = path.join(workspacePath, 'pd', 'goals');
      const processor = createGoalsProcessor(goalsDir);

      // Load cache or sync if needed
      let { data: cacheData, exists } = await processor.loadCache();
      if (!exists || !cacheData) {
        await this.telegramNotifier.sendMessage(chatId,
          '🔄 Syncing goals cache...',
          { parse_mode: 'Markdown' }
        );
        await processor.processGoals('sync');
        const result = await processor.loadCache();
        cacheData = result.data;
      }

      if (!cacheData || !cacheData.goals || cacheData.goals.length === 0) {
        await this.telegramNotifier.sendMessage(chatId,
          '📋 No goals found in workspace',
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // Calculate statistics
      const stats = {
        total: cacheData.goals.length,
        notStarted: 0,
        inProgress: 0,
        completed: 0,
        totalTasks: 0,
        completedTasks: 0
      };

      for (const goal of cacheData.goals) {
        const status = goal.progress?.status || 'Not Started';

        if (status === 'Not Started') stats.notStarted++;
        else if (status === 'In Progress') stats.inProgress++;
        else if (status === 'Completed') stats.completed++;

        // Only count tasks from active goals (Not Started, In Progress)
        // Completed/Abandoned goals are done, don't count their tasks
        if (goal.progress?.taskCompletion) {
          if (status === 'Not Started' || status === 'In Progress') {
            stats.totalTasks += goal.progress.taskCompletion.total;
            stats.completedTasks += goal.progress.taskCompletion.completed;
          }
          // Skip tasks from Completed/Abandoned/Cancelled goals entirely
        }
      }

      // Calculate both goal-based and task-based progress
      const goalProgress = stats.total > 0
        ? Math.round((stats.completed / stats.total) * 100)
        : 0;
      const taskProgress = stats.totalTasks > 0
        ? Math.round((stats.completedTasks / stats.totalTasks) * 100)
        : 0;

      // Format message
      let message = '*📊 Goal Completion Status*\n\n';

      // Goal progress bar
      const barLength = 20;
      const goalFilled = Math.round((goalProgress / 100) * barLength);
      const goalEmpty = barLength - goalFilled;
      message += `*Goal Progress:* ${goalProgress}%\n`;
      message += `[${'█'.repeat(goalFilled)}${'░'.repeat(goalEmpty)}]\n`;
      message += `Goals: ${stats.completed}/${stats.total} completed\n\n`;

      // Task progress bar (if tasks exist)
      if (stats.totalTasks > 0) {
        const taskFilled = Math.round((taskProgress / 100) * barLength);
        const taskEmpty = barLength - taskFilled;
        message += `*Task Progress:* ${taskProgress}%\n`;
        message += `[${'█'.repeat(taskFilled)}${'░'.repeat(taskEmpty)}]\n`;
        message += `Tasks: ${stats.completedTasks}/${stats.totalTasks} completed\n\n`;
      }

      message += '*Goal Status:*\n';
      message += `⏳ Not Started: ${stats.notStarted} goals\n`;
      message += `🚀 In Progress: ${stats.inProgress} goals\n`;
      message += `✅ Completed: ${stats.completed} goals\n\n`;

      // Show in-progress goals and next 3 pending goals that can be loop started
      const inProgressGoals = cacheData.goals
        .filter(g => g.progress?.status === 'In Progress')
        .sort((a, b) => {
          // Sort in-progress by completion percentage (highest first)
          return (b.progress?.taskCompletion?.percentage || 0) - (a.progress?.taskCompletion?.percentage || 0);
        });

      const pendingGoals = cacheData.goals
        .filter(g => g.progress?.status === 'Not Started')
        .sort((a, b) => a.id - b.id)  // Sort by ID
        .slice(0, 3);  // Only show max 3 pending goals

      const hasUnfinishedGoals = inProgressGoals.length > 0 || pendingGoals.length > 0;

      if (hasUnfinishedGoals) {
        message += '*📋 Next Goals:*\n';

        // Helper to extract title from filename
        const extractTitle = (goal) => {
          if (goal.title) return goal.title;
          if (!goal.file) return 'Untitled';
          return goal.file
            .replace(/\.md$/, '')
            .replace(/^\d+-/, '')
            .split('-')
            .map(word => word.charAt(0).toUpperCase() + word.slice(1))
            .join(' ');
        };

        // Show in-progress goals first
        inProgressGoals.forEach(goal => {
          const completion = goal.progress?.taskCompletion;
          const pctValue = completion?.percentage !== undefined ? completion.percentage : goal.completionPct;
          const pct = pctValue !== undefined ? ` (${pctValue}%)` : '';
          const goalId = goal.id || 'N/A';
          const goalTitle = extractTitle(goal);
          message += `🚀 *${String(goalId).padStart(3, '0')}* ${goalTitle}${pct}\n`;
        });

        // Show max 3 pending goals that can be loop started
        pendingGoals.forEach(goal => {
          const goalId = goal.id || 'N/A';
          const goalTitle = extractTitle(goal);
          message += `⏳ *${String(goalId).padStart(3, '0')}* ${goalTitle}\n`;
        });

        message += '\n';
      }

      // Suggest next actions
      if (stats.inProgress > 0) {
        message += '*💡 Suggested Actions:*\n';
        message += '• Use `/goalloop` to automate implementation\n';
        message += '• Use `/goals show <id>` for goal details\n';
      }

      await this.telegramNotifier.sendMessage(chatId, message, { parse_mode: 'Markdown' });

    } catch (error) {
      logger.error(`Failed to handle goal_check command: ${error.message}`);
      await this.telegramNotifier.sendMessage(chatId,
        `❌ Failed: ${error.message}`,
        { parse_mode: 'Markdown' }
      );
    }
  }

  async handleGoalSyncCommand(chatId, args, platform = 'telegram') {
    try {
      const fullChatId = platform === 'telegram' ? `telegram:${chatId}` : chatId;
      const selectedWorkdirName = this.chatSettings.getWorkdir(fullChatId);

      if (!selectedWorkdirName) {
        throw new Error('No working directory selected. Use /workdir [name] to select a workspace.');
      }

      const availableWorkdirs = await this.getAvailableWorkdirs(fullChatId);
      const workspacePath = availableWorkdirs[selectedWorkdirName];

      if (!workspacePath) {
        throw new Error(`Selected workspace "${selectedWorkdirName}" not found or not available.`);
      }

      // Parse flags from args
      const flags = (args || '').toLowerCase().trim();
      const fullResync = flags.includes('--full');
      const fastMode = flags.includes('--fast');

      // Import goals utilities
      const { createGoalsProcessor } = await import('./utils/goals-processor.js');

      const goalsDir = path.join(workspacePath, 'pd', 'goals');
      const processor = createGoalsProcessor(goalsDir, {
        fullResync,
        fastMode,
        skipFix: fastMode, // Fast mode skips fixes
        autoConfirm: false
      });

      // Send initial status
      let syncTypeMsg = 'normal sync';
      if (fullResync) syncTypeMsg = 'full resync (all goals)';
      else if (fastMode) syncTypeMsg = 'fast sync (skip fixes, reuse completed)';

      await this.telegramNotifier.sendMessage(chatId,
        `🔄 *Starting Goals Sync*\n\n` +
        `Mode: ${syncTypeMsg}\n` +
        `Workspace: ${selectedWorkdirName}\n\n` +
        `Please wait...`,
        { parse_mode: 'Markdown' }
      );

      // Handle full resync confirmation
      if (fullResync) {
        const { data: existingCache } = await processor.loadCache();
        if (existingCache && existingCache.goals && existingCache.goals.length > 0) {
          await this.telegramNotifier.sendMessage(chatId,
            `⚠️ *Full Resync Warning*\n\n` +
            `Existing cache contains ${existingCache.goals.length} goal(s).\n` +
            `This will re-analyze all goals and override the cache.\n\n` +
            `Proceeding automatically...`,
            { parse_mode: 'Markdown' }
          );
          processor.options.autoConfirm = true;
        }
      }

      // Process goals
      const startTime = Date.now();
      const result = await processor.processGoals('sync');
      const duration = Math.round((Date.now() - startTime) / 1000);

      if (result.success) {
        // Load updated cache
        const { data: cacheData } = await processor.loadCache();

        let message = `✅ *Goals Sync Completed*\n\n`;
        message += `Duration: ${duration}s\n`;

        if (cacheData && cacheData.summary) {
          const stats = cacheData.summary;
          const total = stats.totalGoals || 0;
          const statusCounts = stats.statusCounts || {};
          const completed = statusCounts['Completed'] || 0;
          const inProgress = statusCounts['In Progress'] || 0;
          const notStarted = statusCounts['Not Started'] || 0;

          message += `\n*Summary:*\n`;
          message += `Total Goals: ${total}\n`;
          message += `✅ Completed: ${completed}\n`;
          message += `🚀 In Progress: ${inProgress}\n`;
          message += `⏳ Not Started: ${notStarted}\n`;
        }

        message += `\nUse \`/goals\` to view all goals.`;

        await this.telegramNotifier.sendMessage(chatId, message, { parse_mode: 'Markdown' });
      } else if (result.needsConfirmation) {
        await this.telegramNotifier.sendMessage(chatId,
          `❌ Sync requires confirmation but auto-confirm is not supported in Telegram.\n\n` +
          `Please use the CLI: \`ani-code goals sync ${fullResync ? '--full' : ''}\``,
          { parse_mode: 'Markdown' }
        );
      } else {
        await this.telegramNotifier.sendMessage(chatId,
          `❌ *Sync Failed*\n\n${result.message || 'Unknown error'}`,
          { parse_mode: 'Markdown' }
        );
      }

    } catch (error) {
      logger.error(`Failed to handle goalsync command: ${error.message}`);
      await this.telegramNotifier.sendMessage(chatId,
        `❌ Failed: ${error.message}`,
        { parse_mode: 'Markdown' }
      );
    }
  }

  async handleGoalReviewCommand(chatId, args, platform = 'telegram') {
    try {
      const fullChatId = platform === 'telegram' ? `telegram:${chatId}` : chatId;
      const selectedWorkdirName = this.chatSettings.getWorkdir(fullChatId);

      if (!selectedWorkdirName) {
        throw new Error('No working directory selected. Use /workdir [name] to select a workspace.');
      }

      const availableWorkdirs = await this.getAvailableWorkdirs(fullChatId);
      const workspacePath = availableWorkdirs[selectedWorkdirName];

      if (!workspacePath) {
        throw new Error(`Working directory "${selectedWorkdirName}" not found.`);
      }

      // Parse arguments: /goalreview <goal-id> [concern...]
      if (!args || args.trim().length === 0) {
        await this.telegramNotifier.sendMessage(chatId,
          `📋 *Goal Review Command*\n\n` +
          `Usage: \`/goalreview <goal-id> [concern]\`\n\n` +
          `Examples:\n` +
          `• \`/goalreview 123\` - Review goal 123\n` +
          `• \`/goalreview 42 check if auth is complete\`\n` +
          `• \`/goalreview 5 add feature XYZ\`\n\n` +
          `This command reviews a goal to verify its completion status and can update the goal based on your concern.`,
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // Parse goal ID and concern
      const argParts = args.trim().split(/\s+/);
      const goalIdentifier = argParts[0];
      const userConcern = argParts.slice(1).join(' ');

      // Import utilities
      const { createGoalsProcessor } = await import('./utils/goals-processor.js');
      const { buildGoalReviewPrompt } = await import('./prompts/goals-prompts.js');
      const { getIterationHistoryPath } = await import('./utils/goals-utils.js');
      const fs = await import('fs');

      const goalsDir = path.join(workspacePath, 'pd', 'goals');
      const processor = createGoalsProcessor(goalsDir);

      // Load cache
      let { data: cacheData } = await processor.loadCache();
      if (!cacheData || !cacheData.goals) {
        await this.telegramNotifier.sendMessage(chatId,
          `❌ No goals cache found. Run \`/goalsync\` first.`,
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // Find goal by ID or filename
      let goal = null;
      const numId = parseInt(goalIdentifier);

      if (!isNaN(numId)) {
        goal = cacheData.goals.find(g => g.id === numId);
      }

      if (!goal) {
        goal = cacheData.goals.find(g =>
          g.file === goalIdentifier ||
          g.file.includes(goalIdentifier) ||
          (g.title && g.title.toLowerCase().includes(goalIdentifier.toLowerCase()))
        );
      }

      if (!goal) {
        await this.telegramNotifier.sendMessage(chatId,
          `❌ Goal "${goalIdentifier}" not found.\n\n` +
          `Use \`/goals\` to see available goals.`,
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // Get goal file path and content
      const goalFilePath = goal.path || path.join(goalsDir, goal.file);
      if (!fs.existsSync(goalFilePath)) {
        await this.telegramNotifier.sendMessage(chatId,
          `❌ Goal file not found: ${goal.file}`,
          { parse_mode: 'Markdown' }
        );
        return;
      }

      const goalContent = fs.readFileSync(goalFilePath, 'utf8');

      // Get PRD content if exists
      const prdPath = path.join(workspacePath, 'pd', 'prd.md');
      const prdContent = fs.existsSync(prdPath) ? fs.readFileSync(prdPath, 'utf8') : '';

      // Get iteration history if exists
      const iterationHistoryPath = getIterationHistoryPath(workspacePath, goal.id);
      let iterationHistory = '';
      if (fs.existsSync(iterationHistoryPath)) {
        try {
          const historyData = JSON.parse(fs.readFileSync(iterationHistoryPath, 'utf8'));
          if (historyData.iterations && historyData.iterations.length > 0) {
            const recentIterations = historyData.iterations.slice(-5);
            iterationHistory = recentIterations.map(iter => {
              return `- ${iter.timestamp}: ${iter.status} - ${iter.output?.substring(0, 200) || 'No output'}...`;
            }).join('\n');
          }
        } catch (e) {
          // Ignore history parsing errors
        }
      }

      // Send starting message
      await this.telegramNotifier.sendMessage(chatId,
        `🔍 *Reviewing Goal #${goal.id}*\n\n` +
        `File: \`${goal.file}\`\n` +
        `Current Status: ${goal.status || goal.progress?.status || 'Unknown'}\n` +
        `Progress: ${goal.completionPercentage || 0}%\n` +
        (userConcern ? `\nConcern: ${userConcern}\n` : '') +
        `\n⏳ Claude is analyzing...`,
        { parse_mode: 'Markdown' }
      );

      // Build review prompt
      const prompt = buildGoalReviewPrompt(goal, goalContent, userConcern, {
        prdContent,
        iterationHistory
      });

      // Add task to queue
      const taskName = `goal-review: ${goal.file.replace('.md', '')}`;
      const task = this.taskMonitor.addTask(taskName, prompt, {
        cwd: workspacePath,
        chatId: fullChatId,
        platform,
        providerId: await this.getCurrentProviderId()  // Track provider for footer/usage display
      });

      // Wait for completion (with timeout)
      const timeout = 300000; // 5 minutes
      const startTime = Date.now();
      let complete = false;

      while (!complete && Date.now() - startTime < timeout) {
        const taskInfo = this.taskMonitor.getTaskById(task.id);

        if (taskInfo && (taskInfo.status === 'completed' || taskInfo.status === 'failed')) {
          complete = true;

          if (taskInfo.status === 'completed') {
            // Sync goals to update cache
            await processor.processGoals('sync', { fast: true });

            // Get updated goal info
            const { data: updatedCache } = await processor.loadCache();
            const updatedGoal = updatedCache?.goals?.find(g => g.id === goal.id);

            let resultMessage = `✅ *Goal Review Completed*\n\n`;
            resultMessage += `Goal: #${goal.id} - ${goal.file}\n\n`;

            if (updatedGoal) {
              resultMessage += `*Updated Status:*\n`;
              resultMessage += `Status: ${updatedGoal.status || updatedGoal.progress?.status}\n`;
              resultMessage += `Progress: ${updatedGoal.completionPercentage || 0}%\n`;
              resultMessage += `Tasks: ${updatedGoal.tasksComplete || 0}/${updatedGoal.taskCount || 0}\n\n`;
            }

            if (taskInfo.output) {
              // Truncate output if too long
              let summary = taskInfo.output;
              if (summary.length > 2000) {
                summary = summary.substring(0, 2000) + '\n\n...[truncated]';
              }
              resultMessage += `*Review Summary:*\n${summary}`;
            }

            await this.telegramNotifier.sendMessage(chatId, resultMessage, { parse_mode: 'Markdown' });
          } else {
            await this.telegramNotifier.sendMessage(chatId,
              `❌ *Review Failed*\n\n${taskInfo.error || 'Unknown error'}`,
              { parse_mode: 'Markdown' }
            );
          }
        }

        if (!complete) {
          await new Promise(resolve => setTimeout(resolve, 3000));
        }
      }

      if (!complete) {
        await this.telegramNotifier.sendMessage(chatId,
          `⏰ *Review Timed Out*\n\n` +
          `The review is taking longer than expected. Check status with \`/status\`.`,
          { parse_mode: 'Markdown' }
        );
      }

    } catch (error) {
      logger.error(`Failed to handle goalreview command: ${error.message}`);
      await this.telegramNotifier.sendMessage(chatId,
        `❌ Failed: ${error.message}`,
        { parse_mode: 'Markdown' }
      );
    }
  }

  /**
   * Handle /healthcheck command - run project healthcheck and report results
   * @param {string} chatId - Chat ID
   * @param {string} args - Optional arguments (--analyze for AI analysis)
   * @param {string} platform - Platform (telegram)
   */
  async handleHealthcheckCommand(chatId, args, platform = 'telegram') {
    try {
      const fullChatId = platform === 'telegram' ? `telegram:${chatId}` : chatId;
      const selectedWorkdirName = this.chatSettings.getWorkdir(fullChatId);

      if (!selectedWorkdirName) {
        await this.telegramNotifier.sendMessage(chatId,
          `No working directory selected. Use \`/workdir [name]\` to select a workspace.`,
          { parse_mode: 'Markdown' }
        );
        return;
      }

      const availableWorkdirs = await this.getAvailableWorkdirs(fullChatId);
      const workspacePath = availableWorkdirs[selectedWorkdirName];

      if (!workspacePath) {
        await this.telegramNotifier.sendMessage(chatId,
          `Workspace "${selectedWorkdirName}" not found.`,
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // Parse arguments - AI analysis is ON by default, use only-json to skip
      const argsList = (args || '').toLowerCase().trim().split(/\s+/);
      const onlyJson = argsList.includes('only-json') || argsList.includes('--only-json');
      const enableFix = argsList.includes('fix') || argsList.includes('--fix');
      const enableAnalyze = !onlyJson;

      // Send starting message
      await this.telegramNotifier.sendMessage(chatId,
        `Running healthcheck on \`${selectedWorkdirName}\`...`,
        { parse_mode: 'Markdown' }
      );

      // Import healthcheck utilities
      const {
        detectTechstacks,
        runNpmAudit,
        runNpmOutdated,
        getNodeConfig,
        calculateHealthScore,
        generateRecommendations,
        TECHSTACK_DETECTORS,
        SCHEMA_VERSION
      } = await import('./commands/healthcheck.js');
      const fs = await import('fs');
      const pathModule = await import('path');

      // Detect techstacks
      const detectedStacks = detectTechstacks(workspacePath);

      if (detectedStacks.length === 0) {
        await this.telegramNotifier.sendMessage(chatId,
          `No supported techstacks detected. Supported: Node.js, Python, Go, Rust, Java`,
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // Initialize report
      const report = {
        version: SCHEMA_VERSION,
        timestamp: new Date().toISOString(),
        projectPath: workspacePath,
        detectedStacks,
        summary: {
          healthScore: 100,
          status: 'pass',
          totalIssues: 0,
          critical: 0,
          high: 0,
          medium: 0,
          low: 0
        },
        stacks: {},
        recommendations: []
      };

      // Run checks for each detected stack
      for (const stackKey of detectedStacks) {
        if (stackKey === 'node') {
          const auditData = runNpmAudit(workspacePath);
          const outdatedData = runNpmOutdated(workspacePath);
          const configData = getNodeConfig(workspacePath);

          const outdatedList = Object.entries(outdatedData).map(([name, info]) => ({
            name,
            current: info.current,
            wanted: info.wanted,
            latest: info.latest
          }));

          report.stacks.node = {
            audit: auditData,
            dependencies: { outdated: outdatedList },
            config: configData
          };

          const scoreData = calculateHealthScore(auditData);
          report.summary = { ...report.summary, ...scoreData };

          const recs = generateRecommendations(report.stacks.node, configData);
          report.recommendations.push(...recs);
        }
      }

      // Save report to file
      const healthcheckDir = pathModule.join(workspacePath, '.ani-code', 'healthcheck');
      if (!fs.existsSync(healthcheckDir)) {
        fs.mkdirSync(healthcheckDir, { recursive: true });
      }

      const now = new Date();
      const randomCode = Math.random().toString(36).substring(2, 6);
      const timestamp = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}-${randomCode}`;
      const reportPath = pathModule.join(healthcheckDir, `healthcheck-${timestamp}.json`);
      fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));

      // Build response message in code block format
      let codeBlock = `HEALTHCHECK REPORT\n`;
      codeBlock += `${'─'.repeat(40)}\n`;
      codeBlock += `Health Score: ${report.summary.healthScore}/100\n`;
      codeBlock += `Status:       ${report.summary.status.toUpperCase()}\n`;
      codeBlock += `Stacks:       ${detectedStacks.map(s => TECHSTACK_DETECTORS[s].name).join(', ')}\n`;

      // Vulnerability counts
      if (report.summary.totalIssues > 0) {
        codeBlock += `\nVULNERABILITIES\n`;
        codeBlock += `${'─'.repeat(40)}\n`;
        if (report.summary.critical > 0) codeBlock += `Critical: ${report.summary.critical}\n`;
        if (report.summary.high > 0) codeBlock += `High:     ${report.summary.high}\n`;
        if (report.summary.medium > 0) codeBlock += `Medium:   ${report.summary.medium}\n`;
        if (report.summary.low > 0) codeBlock += `Low:      ${report.summary.low}\n`;
      }

      // Node.js config status
      if (report.stacks.node) {
        const cfg = report.stacks.node.config;
        codeBlock += `\nNODE.JS CONFIG\n`;
        codeBlock += `${'─'.repeat(40)}\n`;
        codeBlock += `Lock file:    ${cfg.hasLockFile ? cfg.lockFileType : 'Missing'}\n`;
        codeBlock += `Node version: ${cfg.enginesDefined ? cfg.enginesNode : 'Not specified'}\n`;

        const outdatedCount = report.stacks.node.dependencies?.outdated?.length || 0;
        if (outdatedCount > 0) {
          codeBlock += `Outdated:     ${outdatedCount} packages\n`;
        }
      }

      // Recommendations (top 5)
      if (report.recommendations.length > 0) {
        codeBlock += `\nRECOMMENDATIONS\n`;
        codeBlock += `${'─'.repeat(40)}\n`;
        const topRecs = report.recommendations.slice(0, 5);
        for (const rec of topRecs) {
          codeBlock += `[${rec.priority.toUpperCase()}] ${rec.action}\n`;
        }
        if (report.recommendations.length > 5) {
          codeBlock += `... and ${report.recommendations.length - 5} more\n`;
        }
      }

      codeBlock += `\nReport: ${reportPath.replace(workspacePath + '/', '')}`;

      await this.telegramNotifier.sendMessage(chatId, `\`\`\`\n${codeBlock}\n\`\`\``, { parse_mode: 'Markdown' });

      // If analyze flag is set, run Claude analysis
      if (enableAnalyze && report.stacks.node) {
        await this.telegramNotifier.sendMessage(chatId,
          `Running AI analysis...`,
          { parse_mode: 'Markdown' }
        );

        // Generate analysis output file path
        const analysisFilePath = pathModule.join(healthcheckDir, `analysis-${timestamp}.md`);

        // Build prompt using techstack-aware prompt builder
        const { buildAnalysisPrompt } = await import('./prompts/healthcheck-prompts.js');

        // Find primary techstack for analysis
        const primaryStack = detectedStacks[0];
        const stackData = report.stacks[primaryStack] || {};
        const vulnerabilities = stackData.audit?.vulnerabilities || {};
        const highCriticalVulns = Object.entries(vulnerabilities)
          .filter(([_, v]) => v.severity === 'critical' || v.severity === 'high')
          .map(([name, v]) => ({ name, severity: v.severity }));

        const analysisData = {
          summary: report.summary,
          vulnerabilities: highCriticalVulns,
          allVulnerabilities: Object.keys(vulnerabilities).length,
          outdated: stackData.dependencies?.outdated?.slice(0, 10) || [],
          config: stackData.config
        };

        const analysisPrompt = buildAnalysisPrompt(primaryStack, analysisData, analysisFilePath);

        const taskName = `healthcheck-analysis`;
        const task = this.taskMonitor.addTask(taskName, analysisPrompt, {
          cwd: workspacePath,
          chatId: fullChatId,
          platform,
          providerId: await this.getCurrentProviderId()
        });

        // Wait for completion
        const timeout = 180000; // 3 minutes for web search
        const startTime = Date.now();
        let complete = false;

        while (!complete && Date.now() - startTime < timeout) {
          const taskInfo = this.taskMonitor.getTaskById(task.id);

          if (taskInfo && (taskInfo.status === 'completed' || taskInfo.status === 'failed')) {
            complete = true;

            if (taskInfo.status === 'completed') {
              // Check if analysis file was created
              let summaryMsg = '';
              if (fs.existsSync(analysisFilePath)) {
                const analysisContent = fs.readFileSync(analysisFilePath, 'utf8');
                // Extract summary section or first 500 chars
                const summaryMatch = analysisContent.match(/##?\s*Summary[\s\S]*?(?=##|$)/i);
                if (summaryMatch) {
                  summaryMsg = summaryMatch[0].trim().substring(0, 800);
                } else {
                  summaryMsg = analysisContent.substring(0, 500);
                }
                summaryMsg += `\n\nFull report: ${analysisFilePath.replace(workspacePath + '/', '')}`;
              } else if (taskInfo.output) {
                // Fallback to task output
                summaryMsg = taskInfo.output.substring(0, 500);
              }

              if (summaryMsg) {
                await this.telegramNotifier.sendMessage(chatId,
                  `\`\`\`\nAI ANALYSIS\n${'─'.repeat(40)}\n${summaryMsg}\n\`\`\``,
                  { parse_mode: 'Markdown' }
                );
              }
            } else if (taskInfo.status === 'failed') {
              await this.telegramNotifier.sendMessage(chatId,
                `AI analysis failed: ${taskInfo.error || 'Unknown error'}`,
                { parse_mode: 'Markdown' }
              );
            }
          }

          if (!complete) {
            await new Promise(resolve => setTimeout(resolve, 3000));
          }
        }

        if (!complete) {
          await this.telegramNotifier.sendMessage(chatId,
            `AI analysis timed out. Check \`/status\` for task progress.`,
            { parse_mode: 'Markdown' }
          );
        }
      }

      // If fix flag is set, run Claude to fix issues
      if (enableFix && report.summary.totalIssues > 0) {
        await this.telegramNotifier.sendMessage(chatId,
          `Running auto-fix for ${detectedStacks.map(s => TECHSTACK_DETECTORS[s].name).join(', ')}...`,
          { parse_mode: 'Markdown' }
        );

        // Build techstack-aware fix prompt
        const { buildFixPrompt } = await import('./prompts/healthcheck-prompts.js');
        const primaryStack = detectedStacks[0];
        const fixPrompt = buildFixPrompt(primaryStack, report);

        const fixTaskName = `healthcheck-fix`;
        const fixTask = this.taskMonitor.addTask(fixTaskName, fixPrompt, {
          cwd: workspacePath,
          chatId: fullChatId,
          platform,
          providerId: await this.getCurrentProviderId()
        });

        // Wait for fix completion
        const fixTimeout = 300000; // 5 minutes
        const fixStartTime = Date.now();
        let fixComplete = false;

        while (!fixComplete && Date.now() - fixStartTime < fixTimeout) {
          const fixTaskInfo = this.taskMonitor.getTaskById(fixTask.id);

          if (fixTaskInfo && (fixTaskInfo.status === 'completed' || fixTaskInfo.status === 'failed')) {
            fixComplete = true;

            if (fixTaskInfo.status === 'completed') {
              let fixOutput = fixTaskInfo.output || 'Fix completed';
              if (fixOutput.length > 2000) {
                fixOutput = fixOutput.substring(0, 2000) + '\n\n[truncated]';
              }
              await this.telegramNotifier.sendMessage(chatId,
                `\`\`\`\nFIX RESULTS\n${'─'.repeat(40)}\n${fixOutput}\n\`\`\``,
                { parse_mode: 'Markdown' }
              );
            } else {
              await this.telegramNotifier.sendMessage(chatId,
                `Fix failed: ${fixTaskInfo.error || 'Unknown error'}`,
                { parse_mode: 'Markdown' }
              );
            }
          }

          if (!fixComplete) {
            await new Promise(resolve => setTimeout(resolve, 3000));
          }
        }

        if (!fixComplete) {
          await this.telegramNotifier.sendMessage(chatId,
            `Fix timed out. Check \`/status\` for task progress.`,
            { parse_mode: 'Markdown' }
          );
        }
      } else if (enableFix && report.summary.totalIssues === 0) {
        await this.telegramNotifier.sendMessage(chatId,
          `No issues to fix.`,
          { parse_mode: 'Markdown' }
        );
      }

    } catch (error) {
      logger.error(`Failed to handle healthcheck command: ${error.message}`, { stack: error.stack });
      await this.telegramNotifier.sendMessage(chatId,
        `Healthcheck failed: ${error.message}`,
        { parse_mode: 'Markdown' }
      );
    }
  }

  async handleGoalLoopCommand(chatId, args, platform = 'telegram') {
    try {
      const fullChatId = platform === 'telegram' ? `telegram:${chatId}` : chatId;
      const selectedWorkdirName = this.chatSettings.getWorkdir(fullChatId);

      if (!selectedWorkdirName) {
        throw new Error('No working directory selected. Use /workdir [name] to select a workspace.');
      }

      const availableWorkdirs = await this.getAvailableWorkdirs(fullChatId);
      const workspacePath = availableWorkdirs[selectedWorkdirName];

      if (!workspacePath) {
        throw new Error(`Working directory "${selectedWorkdirName}" not found. Available workspaces: ${Object.keys(availableWorkdirs).join(', ')}`);
      }

      // Check if goalloop is already active for this chat
      if (!this.goalLoopStates) {
        this.goalLoopStates = new Map();
      }
      // Map to track pending goal loop completion message updates
      if (!this.pendingGoalLoopUsageUpdates) {
        this.pendingGoalLoopUsageUpdates = new Map();
      }

      // Check for existing active loop
      if (this.goalLoopStates.has(chatId)) {
        const state = this.goalLoopStates.get(chatId);
        if (state.isActive) {
          await this.telegramNotifier.sendMessage(chatId,
            `❌ *Goal loop already running*\n\n` +
            `Workspace: ${selectedWorkdirName}\n` +
            `Iteration: ${state.currentIteration}/${state.maxIterations}\n\n` +
            `Use /stoploop to stop the current loop first.`,
            { parse_mode: 'Markdown' }
          );
          return;
        }
      }

      // Parse arguments for iterations and specific goal
      let iterations = 5; // default
      let specificGoalId = null;
      let skipValidation = false;
      let providerId = null;
      let delayMs = 0;

      if (args) {
        // Check for delay parameter (e.g., delay 4h, delay 30m)
        const delayMatch = args.match(/delay\s+(\d+)([hm])/i);
        if (delayMatch) {
          const value = parseInt(delayMatch[1]);
          const unit = delayMatch[2].toLowerCase();
          delayMs = unit === 'h' ? value * 60 * 60 * 1000 : value * 60 * 1000;
        }

        // Check for number of iterations
        const iterMatch = args.match(/limit\s+(\d+)/i);
        if (iterMatch) {
          iterations = parseInt(iterMatch[1]);
        } else if (/^\d+$/.test(args.trim())) {
          // If just a number, could be goal ID or iterations
          const num = parseInt(args.trim());
          if (num <= 10) {
            iterations = num;
          } else {
            specificGoalId = num;
          }
        }

        // Check for specific goal
        const goalMatch = args.match(/goal\s+(\d+)|"([^"]+)"/i);
        if (goalMatch) {
          specificGoalId = goalMatch[1] || goalMatch[2];
        }

        // Check for provider
        const providerMatch = args.match(/provider\s+([a-z0-9\-]+)/i);
        if (providerMatch) {
          providerId = providerMatch[1].toLowerCase();
        }

        // Check for skip validation
        if (args.includes('skip')) {
          skipValidation = true;
        }
      }

      // Handle delay if specified
      if (delayMs > 0) {
        const delayMinutes = Math.round(delayMs / 60000);
        const scheduledTime = new Date(Date.now() + delayMs);
        const timeStr = scheduledTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

        await this.telegramNotifier.sendMessage(chatId,
          `⏰ *Goal loop scheduled*\n\n` +
          `Workspace: \`${selectedWorkdirName}\`\n` +
          `Iterations: ${iterations}\n` +
          `Starting in: ${delayMinutes} minutes\n` +
          `Scheduled time: ${timeStr}\n\n` +
          `Use /stoploop to cancel.`,
          { parse_mode: 'Markdown' }
        );

        // Store scheduled state
        const scheduledState = {
          isActive: true,
          isScheduled: true,
          scheduledTime: scheduledTime.getTime(),
          startTime: Date.now(),
          currentIteration: 0,
          maxIterations: iterations,
          workspacePath,
          workspaceName: selectedWorkdirName,
          specificGoalId,
          providerId
        };
        this.goalLoopStates.set(chatId, scheduledState);

        // Schedule the execution
        setTimeout(async () => {
          const currentState = this.goalLoopStates.get(chatId);
          if (!currentState || !currentState.isActive) {
            return; // Loop was cancelled
          }

          // Update state to running
          currentState.isScheduled = false;
          currentState.startTime = Date.now();
          this.goalLoopStates.set(chatId, currentState);

          await this.telegramNotifier.sendMessage(chatId,
            `🚀 *Scheduled goal loop starting now*\n\nWorkspace: \`${selectedWorkdirName}\``,
            { parse_mode: 'Markdown' }
          );

          try {
            await this.executeGoalLoopWithIterations(
              chatId,
              workspacePath,
              selectedWorkdirName,
              iterations,
              specificGoalId,
              skipValidation,
              platform,
              providerId
            );
          } catch (error) {
            this.goalLoopStates.delete(chatId);
            await this.telegramNotifier.sendMessage(chatId,
              `❌ Scheduled goal loop failed: ${error.message}`,
              { parse_mode: 'Markdown' }
            );
          }
        }, delayMs);

        return;
      }

      // Mark as active BEFORE starting execution to prevent double calls
      const newState = {
        isActive: true,
        startTime: Date.now(),
        currentIteration: 0,
        maxIterations: iterations,
        workspacePath,
        workspaceName: selectedWorkdirName,
        specificGoalId,
        providerId,
        chatId // Store chatId in state so it can be updated by /here redirect
      };
      this.goalLoopStates.set(chatId, newState);

      try {
        // Start the loop execution
        await this.executeGoalLoopWithIterations(
          chatId,
          workspacePath,
          selectedWorkdirName,
          iterations,
          specificGoalId,
          skipValidation,
          platform,
          providerId
        );
      } catch (error) {
        // Clean up state on error
        this.goalLoopStates.delete(chatId);
        throw error;
      }

    } catch (error) {
      logger.error(`Failed to handle goal_loop command: ${error.message}`);
      await this.telegramNotifier.sendMessage(chatId,
        `❌ Failed: ${error.message}`,
        { parse_mode: 'Markdown' }
      );
    }
  }

  async executeGoalLoopWithIterations(chatId, workspacePath, workspaceName, maxIterations, specificGoalId, skipValidation, platform, providerId = null) {
    // Import necessary modules
    const { join, basename } = await import('path');
    const { existsSync, readFileSync } = await import('fs');
    const { createGoalsProcessor } = await import('./utils/goals-processor.js');
    const { buildGoalExecutionPrompt } = await import('./prompts/goals-prompts.js');
    const { extractProviderFromPrompt, stripPatternsFromPrompt } = await import('./model-utils.js');

    const fullChatId = platform === 'telegram' ? `telegram:${chatId}` : chatId;

    // Get existing state (already created in handleGoalLoopCommand)
    const goalLoopState = this.goalLoopStates.get(chatId);
    if (!goalLoopState) {
      throw new Error('Goal loop state not found - internal error');
    }

    // Update state with additional fields
    Object.assign(goalLoopState, {
      completedIterations: 0,
      failedIterations: 0,
      statusMessageId: null,
      currentGoal: null,
      currentTaskId: null,
      commits: [], // Each item: { hash, goalName, message }
      // Token tracking
      tokenSnapshot: null,
      totalInputTokens: 0,
      totalOutputTokens: 0,
      totalCacheReadTokens: 0,
      totalCost: 0,
      // Track task IDs for pending usage updates
      pendingUsageTaskIds: new Set()
    });

    // Load PRD if available
    const prdPath = join(workspacePath, 'pd', 'prd.md');
    let prdContent = '';
    if (existsSync(prdPath)) {
      prdContent = readFileSync(prdPath, 'utf8');
      logger.info('Loaded PRD for goal loop');
    }

    // Initialize processor
    const goalsDir = join(workspacePath, 'pd', 'goals');
    const processor = createGoalsProcessor(goalsDir);

    // Capture initial token usage snapshot
    try {
      const { execSync } = await import('child_process');
      const today = new Date().toISOString().split('T')[0].replace(/-/g, '');
      const snapshotCmd = `npx ccusage -i --offline --since ${today} -j`;
      const snapshotOutput = execSync(snapshotCmd, { encoding: 'utf8', timeout: 10000 });
      const snapshotData = JSON.parse(snapshotOutput);

      if (snapshotData?.totals) {
        // Collect unique models from all projects
        const allModels = new Set();
        if (snapshotData.projects) {
          Object.values(snapshotData.projects).forEach(projectDays => {
            projectDays.forEach(day => {
              if (day.modelsUsed) {
                day.modelsUsed.forEach(model => allModels.add(model));
              }
            });
          });
        }

        goalLoopState.tokenSnapshot = {
          inputTokens: snapshotData.totals.inputTokens || 0,
          outputTokens: snapshotData.totals.outputTokens || 0,
          cacheReadTokens: snapshotData.totals.cacheReadTokens || 0,
          cacheCreationTokens: snapshotData.totals.cacheCreationTokens || 0,
          cost: snapshotData.totals.totalCost || 0,
          modelsUsed: Array.from(allModels)
        };
        logger.info(`[GOALLOOP] Captured initial token snapshot: ${goalLoopState.tokenSnapshot.inputTokens + goalLoopState.tokenSnapshot.outputTokens} tokens, $${goalLoopState.tokenSnapshot.cost.toFixed(4)}`);
      }
    } catch (error) {
      logger.warn(`[GOALLOOP] Failed to capture initial token snapshot: ${error.message}`);
      // Continue without snapshot - non-critical
    }

    // Format initial status message with buttons
    const statusMessage = await this.formatGoalLoopStatus(goalLoopState, 'starting');

    // Send initial status message with control buttons
    const keyboard = {
      inline_keyboard: [[
        { text: '⏸ Pause', callback_data: JSON.stringify({ action: 'pause_loop' }) },
        { text: '⏹ Stop', callback_data: JSON.stringify({ action: 'stop_loop' }) },
        { text: '🔄 Refresh', callback_data: JSON.stringify({ action: 'refresh_loop' }) }
      ]]
    };

    const sentMessage = await this.telegramNotifier.sendMessage(chatId, statusMessage, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    });

    goalLoopState.statusMessageId = sentMessage?.result?.message_id;

    // Check for auto-pin setting (like YOLO)
    try {
      if (!this.workspaceManager) {
        const { WorkspaceManager } = await import('./workspace-manager.js');
        this.workspaceManager = new WorkspaceManager();
        await this.workspaceManager.initialize();
      }
      const workspace = await this.workspaceManager.getWorkspaceByPath(workspacePath);
      if ((workspace?.settings?.showprogress || 'autopin') === 'autopin' && goalLoopState.statusMessageId) {
        await this.telegramAPI.pinChatMessage(chatId, goalLoopState.statusMessageId, { disable_notification: true });
        logger.info(`[GOALLOOP] Auto-pinned status message ${goalLoopState.statusMessageId}`);
      }
    } catch (error) {
      logger.debug(`[GOALLOOP] Failed to auto-pin: ${error.message}`);
    }

    // Track goals blocked by ANICODE_BREAK to avoid re-selecting them
    const blockedGoalIds = new Set();

    // Main loop
    logger.info(`[GOALLOOP] Starting main loop for chat ${chatId}, max iterations: ${goalLoopState.maxIterations}`);
    while (goalLoopState.currentIteration < goalLoopState.maxIterations && goalLoopState.isActive) {
      goalLoopState.currentIteration++;
      logger.info(`[GOALLOOP] Starting iteration ${goalLoopState.currentIteration}/${goalLoopState.maxIterations}, isActive: ${goalLoopState.isActive}`);

      try {
        // Load/reload goals cache
        let { data: cacheData, exists } = await processor.loadCache();
        if (!exists || !cacheData) {
          await processor.processGoals('sync');
          const result = await processor.loadCache();
          cacheData = result.data;
        }

        if (!cacheData || !cacheData.goals || cacheData.goals.length === 0) {
          throw new Error('No goals found in workspace');
        }

        // Find target goal for this iteration
        let targetGoal = null;

        if (specificGoalId) {
          const goalId = parseInt(specificGoalId);
          targetGoal = isNaN(goalId)
            ? cacheData.goals.find(g => g.title && g.title.toLowerCase().includes(specificGoalId.toLowerCase()))
            : cacheData.goals.find(g => g.id === goalId);
        }

        // If no specific goal or not found, auto-select (excluding blocked goals)
        if (!targetGoal) {
          const inProgress = cacheData.goals
            .filter(g => (g.progress?.status === 'In Progress' || g.status === 'In Progress') && !blockedGoalIds.has(g.id))
            .sort((a, b) => (b.progress?.taskCompletion?.percentage || 0) - (a.progress?.taskCompletion?.percentage || 0));

          if (inProgress.length > 0) {
            targetGoal = inProgress[0];
          } else {
            targetGoal = cacheData.goals.find(g =>
              (g.progress?.status === 'Not Started' || g.status === 'Not Started') && !blockedGoalIds.has(g.id)
            );
          }
        }

        if (!targetGoal) {
          // No pending goals found - auto-sync in case user forgot to sync
          logger.info(`[GOALLOOP] No pending goals - running goalsync --fast to check for updates`);
          await processor.processGoals('sync', { fast: true });

          // Reload cache and try to find goals again
          const { data: refreshedCache } = await processor.loadCache();
          if (refreshedCache && refreshedCache.goals) {
            // Re-search for target goal after sync
            if (specificGoalId) {
              const goalId = parseInt(specificGoalId);
              targetGoal = isNaN(goalId)
                ? refreshedCache.goals.find(g => g.title && g.title.toLowerCase().includes(specificGoalId.toLowerCase()))
                : refreshedCache.goals.find(g => g.id === goalId);
            }

            if (!targetGoal) {
              const inProgress = refreshedCache.goals
                .filter(g => (g.progress?.status === 'In Progress' || g.status === 'In Progress') && !blockedGoalIds.has(g.id))
                .sort((a, b) => (b.progress?.taskCompletion?.percentage || 0) - (a.progress?.taskCompletion?.percentage || 0));

              if (inProgress.length > 0) {
                targetGoal = inProgress[0];
              } else {
                targetGoal = refreshedCache.goals.find(g =>
                  (g.progress?.status === 'Not Started' || g.status === 'Not Started') && !blockedGoalIds.has(g.id)
                );
              }
            }

            if (targetGoal) {
              logger.info(`[GOALLOOP] Found ${targetGoal.file || targetGoal.id} after goalsync`);
              // Update cacheData reference for rest of iteration
              cacheData = refreshedCache;
            }
          }

          // Still no goals after sync - all truly completed
          if (!targetGoal) {
            goalLoopState.isActive = false;
            await this.updateGoalLoopMessage(chatId, goalLoopState, 'all_complete');
            break;
          }
        }

        const goalFileName = targetGoal.file || (targetGoal.path ? basename(targetGoal.path) : 'unknown');
        goalLoopState.currentGoal = targetGoal;

        // Update status message
        await this.updateGoalLoopMessage(chatId, goalLoopState, 'implementing');

        // Get iteration history context for this goal
        const { getIterationHistoryPath, getLastIterationInfo, formatIterationHistoryForPrompt } = await import('./utils/goals-utils.js');
        const iterationHistoryPath = getIterationHistoryPath(workspacePath, targetGoal.id);
        const lastIterationInfo = getLastIterationInfo(workspacePath, targetGoal.id);
        const isFreshStart = !lastIterationInfo;

        // Check if previous iteration ended with ANICODE_BREAK - skip once then allow retry
        if (lastIterationInfo && lastIterationInfo.failureReason &&
            lastIterationInfo.failureReason.includes('ANICODE_BREAK') &&
            !lastIterationInfo.failureReason.includes('ANICODE_BREAK_HANDLED')) {
          logger.warn(`[GOALLOOP] Goal ${targetGoal.id} has ANICODE_BREAK in history - skipping for this run`);
          logger.warn(`[GOALLOOP] Break reason: ${lastIterationInfo.failureReason}`);
          blockedGoalIds.add(targetGoal.id);

          // Clear the break marker so next goalloop invocation can retry this goal
          const { clearAnicodeBreak } = await import('./utils/goals-utils.js');
          clearAnicodeBreak(workspacePath, targetGoal.id);
          logger.info(`[GOALLOOP] Cleared ANICODE_BREAK marker for goal ${targetGoal.id} - will be retryable next run`);

          // Try to find another goal to work on
          if (!specificGoalId) {
            // Remove this goal from consideration and continue to next iteration
            goalLoopState.failedIterations++;
            continue;
          } else {
            // User specified this goal - can't skip, stop the loop
            await this.telegramNotifier.sendMessage(chatId,
              `🛑 *Goal #${targetGoal.id} had ANICODE\\_BREAK last run*\n\n` +
              `Reason: ${lastIterationInfo.failureReason.replace('ANICODE_BREAK: ', '')}\n\n` +
              `Skipped for this run. It will be retried on the next goalloop.`,
              { parse_mode: 'Markdown' }
            );
            goalLoopState.isActive = false;
            break;
          }
        }

        // Format iteration history for prompt context
        let iterationHistoryContent = '';
        if (!isFreshStart) {
          iterationHistoryContent = formatIterationHistoryForPrompt(workspacePath, targetGoal.id, 3);
          logger.info(`[GOALLOOP] Including iteration history for goal ${targetGoal.id} (${lastIterationInfo.totalIterations} previous iterations)`);
        }

        // Build prompt - NO autoCommit in the prompt
        let prompt = buildGoalExecutionPrompt(targetGoal, prdContent, {
          autonomous: true,
          autoCommit: false,  // We handle commit separately after sync
          detailedSummary: true,
          iterationHistoryPath,
          iterationHistoryContent,
          isFreshStart,
          lastIteration: lastIterationInfo
        });

        // Extract provider from prompt inline syntax (@@provider)
        const inlineProvider = extractProviderFromPrompt(prompt);
        const effectiveProvider = providerId || inlineProvider;

        // Strip provider patterns from prompt
        if (inlineProvider) {
          prompt = stripPatternsFromPrompt(prompt);
        }

        // Create implementation task
        const taskName = `goal-loop-${goalLoopState.currentIteration}: ${goalFileName.replace('.md', '')}`;
        const taskTimeout = 21600000; // 6 hours per iteration
        const taskOptions = {
          cwd: workspacePath,
          source: `${platform}_goal_loop`,
          chatId: fullChatId,
          timeout: taskTimeout
        };

        // Add provider to task options - use specified provider or fall back to current
        if (effectiveProvider) {
          taskOptions.providerId = effectiveProvider;
          logger.info(`[GOALLOOP] Using specified provider: ${effectiveProvider}`);
        } else {
          taskOptions.providerId = await this.getCurrentProviderId();
          logger.info(`[GOALLOOP] Using current provider: ${taskOptions.providerId}`);
        }

        logger.info(`[GOALLOOP] Creating task for iteration ${goalLoopState.currentIteration}, goal: ${goalFileName}`);
        const taskStartTime = Date.now();
        const task = this.taskMonitor.addTask(taskName, prompt, taskOptions);
        goalLoopState.currentTaskId = task.id;
        logger.info(`[GOALLOOP] Task created with ID: ${task.id}, waiting for completion...`);

        // Wait for task completion using the proper async method
        const completedTask = await this.waitForTaskCompletion(task.id, chatId, taskTimeout);

        // Check if loop was stopped during task execution
        if (!goalLoopState.isActive) {
          logger.info(`[GOALLOOP] Loop stopped by user during iteration ${goalLoopState.currentIteration}`);
          break;
        }

        // Handle timeout
        if (!completedTask) {
          logger.error(`[GOALLOOP] Task ${task.id} timed out after 6 hours`);
          goalLoopState.failedIterations++;
          await this.updateGoalLoopMessage(chatId, goalLoopState, 'complete');
          break; // Stop loop on timeout
        }

        logger.info(`[GOALLOOP] Task ${task.id} completed with status: ${completedTask.status}`);

        if (completedTask.status === 'completed') {
          goalLoopState.completedIterations++;

          // Wait for usage data to be calculated (runs async after task completion)
          // The taskUsageReady event is emitted after calculateUsageAsync completes
          let usageTask = completedTask;
          if (!completedTask.usage || !completedTask.usage.inputTokens) {
            logger.debug(`[GOALLOOP] Waiting for usage data for task ${task.id}...`);
            // Poll for usage data (max 15 seconds wait)
            // Note: usage-reporter.js polls ccusage for up to 10 seconds, so we need more time
            const usageWaitStart = Date.now();
            const maxUsageWait = 15000;
            while (Date.now() - usageWaitStart < maxUsageWait) {
              await new Promise(resolve => setTimeout(resolve, 200));
              const refreshedTask = this.taskMonitor.getTaskById(task.id);
              if (refreshedTask?.usage?.inputTokens > 0 || refreshedTask?.usage?.cost > 0) {
                usageTask = refreshedTask;
                logger.debug(`[GOALLOOP] Got usage data after ${Date.now() - usageWaitStart}ms`);
                break;
              }
            }
            if (!usageTask.usage?.inputTokens) {
              logger.warn(`[GOALLOOP] Usage data not available after ${maxUsageWait}ms for task ${task.id}`);
            }
          }

          // Calculate iteration duration and tokens
          const iterationDuration = Date.now() - taskStartTime;
          const inputTokens = usageTask.usage?.inputTokens || 0;
          const outputTokens = usageTask.usage?.outputTokens || 0;
          const cacheReadTokens = usageTask.usage?.cacheReadTokens || 0;
          const iterationCost = usageTask.usage?.cost || 0;
          const tokensUsed = inputTokens + outputTokens;

          // Accumulate token usage from completed task
          if (usageTask.usage && (inputTokens > 0 || outputTokens > 0 || iterationCost > 0)) {
            goalLoopState.totalInputTokens += inputTokens;
            goalLoopState.totalOutputTokens += outputTokens;
            goalLoopState.totalCacheReadTokens += cacheReadTokens;
            goalLoopState.totalCost += iterationCost;
            logger.info(`[GOALLOOP] Task tokens: In=${inputTokens}, Out=${outputTokens}, Cache=${cacheReadTokens}, Cost=$${iterationCost.toFixed(4)}, Total so far: ${goalLoopState.totalInputTokens + goalLoopState.totalOutputTokens}`);
          } else {
            // Track this task ID for delayed usage update
            goalLoopState.pendingUsageTaskIds.add(task.id);
            logger.warn(`[GOALLOOP] No usage data available for task ${task.id}, added to pending list`);
          }

          // Check for __ANICODE_BREAK pattern in output BEFORE saving as success
          const taskOutput = usageTask.output || completedTask.output || '';
          const anicodeBreakMatch = taskOutput.match(/__ANICODE_BREAK\(([^)]*)\)/);
          if (anicodeBreakMatch) {
            const breakReason = anicodeBreakMatch[1] ? anicodeBreakMatch[1].trim() : 'Unknown reason';
            logger.error(`[GOALLOOP] __ANICODE_BREAK detected in task output! Reason: ${breakReason}`);

            // Save as FAILED iteration (not completed) with break reason
            try {
              const { addIterationToHistory } = await import('./utils/goals-utils.js');
              addIterationToHistory(workspacePath, targetGoal, {
                taskId: task.id,
                duration: iterationDuration,
                tokensUsed,
                inputTokens,
                outputTokens,
                cost: iterationCost,
                output: taskOutput,
                status: 'failed',
                failureReason: `ANICODE_BREAK: ${breakReason}`,
                conclusion: `Goal loop stopped due to repeat failure: ${breakReason}`,
                goalLoopIteration: goalLoopState.currentIteration
              });
              logger.info(`[GOALLOOP] Saved ANICODE_BREAK iteration history for goal ${targetGoal.id}`);
            } catch (err) {
              logger.warn(`[GOALLOOP] Failed to save break iteration history: ${err.message}`);
            }

            // Notify user about the break
            await this.telegramNotifier.sendMessage(chatId,
              `🛑 *ANICODE\\_BREAK detected!*\n\n` +
              `Goal: #${targetGoal.id} - ${goalFileName}\n` +
              `Reason: ${breakReason}\n\n` +
              `Stopping goal loop. This goal needs manual intervention.`,
              { parse_mode: 'Markdown' }
            );

            // Revert: this is actually a failure, not a success
            goalLoopState.completedIterations--;
            goalLoopState.failedIterations++;
            goalLoopState.isActive = false;
            break;
          }

          // Save iteration to history (normal success path)
          try {
            const { addIterationToHistory } = await import('./utils/goals-utils.js');
            const iterationEntry = addIterationToHistory(workspacePath, targetGoal, {
              taskId: task.id,
              duration: iterationDuration,
              tokensUsed,
              inputTokens,
              outputTokens,
              cost: iterationCost,
              output: taskOutput,
              status: 'completed',
              goalLoopIteration: goalLoopState.currentIteration
            });
            logger.info(`[GOALLOOP] Saved iteration history for goal ${targetGoal.id}, iteration ${iterationEntry.iterationNumber}`);
          } catch (err) {
            logger.warn(`[GOALLOOP] Failed to save iteration history: ${err.message}`);
          }

              // Now run sync --fast
              await this.updateGoalLoopMessage(chatId, goalLoopState, 'syncing');

              // Run goals sync
              await processor.processGoals('sync', { fast: true });

              // Create commit task - use shell: prefix to run ani-code commit command
              await this.updateGoalLoopMessage(chatId, goalLoopState, 'committing');

              // Pass goal context via environment variable for commit message generation
              const goalContext = {
                id: targetGoal.id,
                title: targetGoal.title || targetGoal.file,
                file: goalFileName
              };

              // Use ani-code commit command with goal context
              const commitTask = this.taskMonitor.addTask(
                `goal-commit-${goalLoopState.currentIteration}`,
                'shell:ani-code commit -y',
                {
                  cwd: goalLoopState.workspacePath,
                  source: `${platform}_goal_loop`,
                  chatId: fullChatId,
                  timeout: 60000,
                  env: {
                    ...process.env,
                    ANICODE_GOAL_CONTEXT: JSON.stringify(goalContext)
                  }
                }
              );

              // Wait for commit using proper async method
              logger.info(`[GOALLOOP] Waiting for commit task ${commitTask.id}...`);
              const commitCompleted = await this.waitForTaskCompletion(commitTask.id, chatId, 60000); // 60 seconds

              if (commitCompleted && commitCompleted.status === 'completed') {
                // Extract commit hash and message using git
                let commitHash = null;
                let commitMessage = null;
                try {
                  const { execSync } = await import('child_process');
                  const fullHash = execSync('git rev-parse HEAD', { cwd: workspacePath, encoding: 'utf8' }).trim();
                  commitHash = fullHash.substring(0, 7);
                  const message = execSync(`git log -1 --format=%s ${fullHash}`, {
                    cwd: workspacePath,
                    encoding: 'utf8'
                  }).trim();
                  commitMessage = message;
                  logger.debug(`[GOALLOOP] Got commit info for ${commitHash}: ${commitMessage}`);
                } catch (err) {
                  logger.warn(`[GOALLOOP] Failed to get commit info: ${err.message}`);
                  // Fallback: try to extract from commit output if available
                  if (commitCompleted.output) {
                    const msgMatch = commitCompleted.output.match(/📝 Commit: [a-f0-9]+ - "([^"]+)"/);
                    if (msgMatch) {
                      commitMessage = msgMatch[1];
                      logger.debug(`[GOALLOOP] Got commit message from output: ${commitMessage}`);
                    }
                  }
                }

                if (commitHash) {
                  const goalName = goalLoopState.currentGoal?.title ||
                                   goalLoopState.currentGoal?.file ||
                                   'Unknown';

                  goalLoopState.commits.push({
                    hash: commitHash,
                    goalName,
                    message: commitMessage || 'No message available'
                  });
                  logger.info(`[GOALLOOP] Iteration ${goalLoopState.currentIteration} committed: ${commitHash} - ${commitMessage || 'No message'}`);
                }
              } else if (commitCompleted) {
                logger.warn(`[GOALLOOP] Commit failed for iteration ${goalLoopState.currentIteration}`);
              } else {
                logger.warn(`[GOALLOOP] Commit timed out for iteration ${goalLoopState.currentIteration}`);
              }

            } else if (completedTask.status === 'failed' || completedTask.status === 'error') {
              goalLoopState.failedIterations++;
              logger.error(`[GOALLOOP] Task failed for iteration ${goalLoopState.currentIteration}: ${completedTask.status}`);

              // Save failed iteration to history
              try {
                const { addIterationToHistory } = await import('./utils/goals-utils.js');
                const iterationDuration = Date.now() - taskStartTime;
                const inputTokens = completedTask.usage?.inputTokens || 0;
                const outputTokens = completedTask.usage?.outputTokens || 0;
                const tokensUsed = inputTokens + outputTokens;

                addIterationToHistory(workspacePath, targetGoal, {
                  taskId: task.id,
                  duration: iterationDuration,
                  tokensUsed,
                  inputTokens,
                  outputTokens,
                  output: completedTask.output || completedTask.error || '',
                  status: completedTask.status,
                  error: completedTask.error || null,
                  goalLoopIteration: goalLoopState.currentIteration
                });
                logger.info(`[GOALLOOP] Saved failed iteration history for goal ${targetGoal.id}`);
              } catch (err) {
                logger.warn(`[GOALLOOP] Failed to save iteration history: ${err.message}`);
              }

              // Stop loop on task failure
              await this.updateGoalLoopMessage(chatId, goalLoopState, 'complete');
              logger.error(`[GOALLOOP] Stopping loop due to task failure`);
              break;
            } else {
              // Task was cancelled or had other status
              goalLoopState.failedIterations++;
              logger.warn(`[GOALLOOP] Task ended with unexpected status: ${completedTask.status}`);

              // Save cancelled/other iteration to history
              try {
                const { addIterationToHistory } = await import('./utils/goals-utils.js');
                const iterationDuration = Date.now() - taskStartTime;
                const inputTokens = completedTask.usage?.inputTokens || 0;
                const outputTokens = completedTask.usage?.outputTokens || 0;
                const tokensUsed = inputTokens + outputTokens;

                addIterationToHistory(workspacePath, targetGoal, {
                  taskId: task.id,
                  duration: iterationDuration,
                  tokensUsed,
                  inputTokens,
                  outputTokens,
                  output: completedTask.output || '',
                  status: completedTask.status,
                  goalLoopIteration: goalLoopState.currentIteration
                });
                logger.info(`[GOALLOOP] Saved iteration history for goal ${targetGoal.id} with status ${completedTask.status}`);
              } catch (err) {
                logger.warn(`[GOALLOOP] Failed to save iteration history: ${err.message}`);
              }
            }

      } catch (error) {
        logger.error(`[GOALLOOP] Iteration ${goalLoopState.currentIteration} error: ${error.message}`);
        goalLoopState.failedIterations++;
      }
    }

    // Final summary
    logger.info(`[GOALLOOP] Loop finished for chat ${chatId}. Total: ${goalLoopState.currentIteration}, Completed: ${goalLoopState.completedIterations}, Failed: ${goalLoopState.failedIterations}`);
    goalLoopState.isActive = false;
    await this.updateGoalLoopMessage(chatId, goalLoopState, 'complete');

    // Get token usage data using the shared helper (same source as status message)
    const tokenUsageData = await this.getGoalLoopUsageData(goalLoopState);
    if (tokenUsageData) {
      logger.info(`[GOALLOOP] Final usage: ${tokenUsageData.totalTokens} tokens, $${tokenUsageData.cost.toFixed(4)}`);
    }

    // Send a separate completion message with summary
    const elapsed = Date.now() - goalLoopState.startTime;
    const minutes = Math.floor(elapsed / 60000);
    const seconds = Math.floor((elapsed % 60000) / 1000);
    const timeStr = minutes > 0 ? `${minutes}m ${seconds}s` : `${seconds}s`;

    let completionMessage = `✅ *Goal Loop Finished*\n\n`;
    completionMessage += `📊 *Summary:*\n`;
    completionMessage += `• Workspace: ${goalLoopState.workspaceName}\n`;
    completionMessage += `• Total Time: ${timeStr}\n`;
    completionMessage += `• Iterations: ${goalLoopState.currentIteration}/${goalLoopState.maxIterations}\n`;
    completionMessage += `• Successful: ${goalLoopState.completedIterations}\n`;
    completionMessage += `• Failed: ${goalLoopState.failedIterations}\n`;

    // Add token usage and cost information
    if (tokenUsageData && tokenUsageData.totalTokens > 0) {
      const formatTokens = (tokens) => {
        if (tokens >= 1000000) return `${(tokens / 1000000).toFixed(1)}m`;
        if (tokens >= 1000) return `${(tokens / 1000).toFixed(1)}k`;
        return tokens.toLocaleString();
      };

      // Format similar to task completion message: 💰 $0.4677 (sonnet-4.5, haiku-4.5) • In: 1.6k (550.1k cached) • Out: 3.4k
      const tokenParts = [];

      // Add cost with model info if available
      if (tokenUsageData.cost !== null && tokenUsageData.cost > 0) {
        let costLine = `💰 $${tokenUsageData.cost.toFixed(4)}`;

        // Add model names if available
        if (tokenUsageData.modelsUsed && tokenUsageData.modelsUsed.length > 0) {
          const { normalizeModelNameLowercase } = await import('./utils/model-normalizer.js');
          const modelNames = tokenUsageData.modelsUsed.map(m => normalizeModelNameLowercase(m)).join(', ');
          costLine += ` (${modelNames})`;
        }

        tokenParts.push(costLine);
      }

      // Add input tokens (with cache info if available)
      if (tokenUsageData.inputTokens > 0) {
        let inputPart = `In: ${formatTokens(tokenUsageData.inputTokens)}`;
        if (tokenUsageData.cacheReadTokens && tokenUsageData.cacheReadTokens > 0) {
          inputPart += ` (${formatTokens(tokenUsageData.cacheReadTokens)} cached)`;
        }
        tokenParts.push(inputPart);
      }

      // Add output tokens
      if (tokenUsageData.outputTokens > 0) {
        tokenParts.push(`Out: ${formatTokens(tokenUsageData.outputTokens)}`);
      }

      if (tokenParts.length > 0) {
        completionMessage += `\n${tokenParts.join(' • ')}\n`;
      }
    }

    if (goalLoopState.commits.length > 0) {
      // Group commits by goal name to avoid repeating goal titles
      const commitsByGoal = {};
      for (const commit of goalLoopState.commits) {
        const goalName = commit.goalName || 'Unknown Goal';
        if (!commitsByGoal[goalName]) {
          commitsByGoal[goalName] = [];
        }
        commitsByGoal[goalName].push(commit);
      }

      completionMessage += `\n💾 *Commits:*\n`;
      const goalNames = Object.keys(commitsByGoal);
      for (const goalName of goalNames) {
        const goalCommits = commitsByGoal[goalName];
        // Only show goal name as a header if there are multiple goals
        if (goalNames.length > 1) {
          completionMessage += `*${goalName}:*\n`;
        }
        for (const commit of goalCommits) {
          const shortHash = commit.hash.substring(0, 7);
          const commitMsg = commit.message || 'No message';
          completionMessage += `• \`${shortHash}\` ${commitMsg}\n`;
        }
      }
    }

    if (goalLoopState.completedIterations > 0) {
      completionMessage += `\n✨ Successfully completed ${goalLoopState.completedIterations} iteration(s)!\n`;
    }

    completionMessage += `\nUse /goals to view updated progress.`;

    // Send completion message with action buttons
    const completionKeyboard = {
      inline_keyboard: [[
        { text: '📊 View Goals', callback_data: '/goals' }
      ]]
    };

    const completionSentMessage = await this.telegramNotifier.sendMessage(chatId, completionMessage, {
      parse_mode: 'Markdown',
      reply_markup: completionKeyboard
    });

    // If there are pending usage tasks, set up delayed update
    if (goalLoopState.pendingUsageTaskIds && goalLoopState.pendingUsageTaskIds.size > 0) {
      const messageId = completionSentMessage?.result?.message_id;
      if (messageId) {
        // Store info needed to update the message later
        const updateKey = `goalloop_${chatId}_${Date.now()}`;
        this.pendingGoalLoopUsageUpdates.set(updateKey, {
          chatId,
          messageId,
          pendingTaskIds: new Set(goalLoopState.pendingUsageTaskIds),
          // Store state needed to rebuild message
          workspaceName: goalLoopState.workspaceName,
          startTime: goalLoopState.startTime,
          currentIteration: goalLoopState.currentIteration,
          maxIterations: goalLoopState.maxIterations,
          completedIterations: goalLoopState.completedIterations,
          failedIterations: goalLoopState.failedIterations,
          commits: [...goalLoopState.commits],
          specificGoalId: goalLoopState.specificGoalId,
          // Current totals (from tasks that did report in time)
          totalInputTokens: goalLoopState.totalInputTokens,
          totalOutputTokens: goalLoopState.totalOutputTokens,
          totalCacheReadTokens: goalLoopState.totalCacheReadTokens,
          totalCost: goalLoopState.totalCost,
          // Snapshot data for models
          tokenSnapshot: goalLoopState.tokenSnapshot,
          tokenUsageData // Keep current tokenUsageData
        });

        logger.info(`[GOALLOOP] Set up delayed usage update for ${goalLoopState.pendingUsageTaskIds.size} pending task(s), key: ${updateKey}`);

        // Set up listener for pending usage updates
        this.setupGoalLoopUsageListener(updateKey);
      }
    }

    // Unpin the status message if it was auto-pinned
    if (goalLoopState.statusMessageId) {
      try {
        await this.telegramAPI.unpinChatMessage(chatId, goalLoopState.statusMessageId);
        logger.info(`[GOALLOOP] Unpinned status message ${goalLoopState.statusMessageId}`);
      } catch (unpinError) {
        logger.debug(`[GOALLOOP] Failed to unpin status message: ${unpinError.message}`);
      }
    }

    // Clean up state
    this.goalLoopStates.delete(chatId);
    logger.info(`[GOALLOOP] Cleaned up state for chat ${chatId}`);
  }

  /**
   * Set up listener for delayed goal loop usage updates
   * When tasks report usage after the completion message was sent, update the message
   */
  setupGoalLoopUsageListener(updateKey) {
    const updateInfo = this.pendingGoalLoopUsageUpdates.get(updateKey);
    if (!updateInfo) return;

    // Maximum wait time for pending usage (30 seconds)
    const maxWaitTime = 30000;

    const onUsageReady = async (task) => {
      const info = this.pendingGoalLoopUsageUpdates.get(updateKey);
      if (!info) {
        this.taskMonitor.removeListener('taskUsageReady', onUsageReady);
        return;
      }

      // Check if this task is one we're waiting for
      if (info.pendingTaskIds.has(task.id)) {
        // Accumulate usage from this task
        const inputTokens = task.usage?.inputTokens || 0;
        const outputTokens = task.usage?.outputTokens || 0;
        const cacheReadTokens = task.usage?.cacheReadTokens || 0;
        const cost = task.usage?.cost || 0;

        info.totalInputTokens += inputTokens;
        info.totalOutputTokens += outputTokens;
        info.totalCacheReadTokens += cacheReadTokens;
        info.totalCost += cost;

        // Remove from pending
        info.pendingTaskIds.delete(task.id);
        logger.info(`[GOALLOOP_USAGE] Got delayed usage for task ${task.id}: $${cost.toFixed(4)}, ${info.pendingTaskIds.size} pending remaining`);

        // Update the message
        await this.updateGoalLoopCompletionMessage(updateKey);

        // If no more pending tasks, clean up
        if (info.pendingTaskIds.size === 0) {
          logger.info(`[GOALLOOP_USAGE] All pending usage received for ${updateKey}`);
          this.taskMonitor.removeListener('taskUsageReady', onUsageReady);
          this.pendingGoalLoopUsageUpdates.delete(updateKey);
        }
      }
    };

    // Set up timeout to clean up after maxWaitTime
    setTimeout(() => {
      const info = this.pendingGoalLoopUsageUpdates.get(updateKey);
      if (info && info.pendingTaskIds.size > 0) {
        logger.warn(`[GOALLOOP_USAGE] Timeout waiting for ${info.pendingTaskIds.size} task(s) usage in ${updateKey}`);
      }
      this.taskMonitor.removeListener('taskUsageReady', onUsageReady);
      this.pendingGoalLoopUsageUpdates.delete(updateKey);
    }, maxWaitTime);

    // Start listening
    this.taskMonitor.on('taskUsageReady', onUsageReady);
    logger.debug(`[GOALLOOP_USAGE] Listening for usage events for ${updateKey}`);
  }

  /**
   * Update the goal loop completion message with new usage data
   */
  async updateGoalLoopCompletionMessage(updateKey) {
    const info = this.pendingGoalLoopUsageUpdates.get(updateKey);
    if (!info) return;

    try {
      const formatTokens = (tokens) => {
        if (tokens >= 1000000) return `${(tokens / 1000000).toFixed(1)}m`;
        if (tokens >= 1000) return `${(tokens / 1000).toFixed(1)}k`;
        return tokens.toLocaleString();
      };

      // Build the updated message
      const elapsed = Date.now() - info.startTime;
      const minutes = Math.floor(elapsed / 60000);
      const seconds = Math.floor((elapsed % 60000) / 1000);
      const timeStr = minutes > 0 ? `${minutes}m ${seconds}s` : `${seconds}s`;

      let completionMessage = `✅ *Goal Loop Finished*\n\n`;
      completionMessage += `📊 *Summary:*\n`;
      completionMessage += `• Workspace: ${info.workspaceName}\n`;
      completionMessage += `• Total Time: ${timeStr}\n`;
      completionMessage += `• Iterations: ${info.currentIteration}/${info.maxIterations}\n`;
      completionMessage += `• Successful: ${info.completedIterations}\n`;
      completionMessage += `• Failed: ${info.failedIterations}\n`;

      // Add token usage and cost information with updated values
      const totalTokens = info.totalInputTokens + info.totalOutputTokens;
      if (totalTokens > 0 || info.totalCost > 0) {
        const tokenParts = [];

        // Add cost with model info
        if (info.totalCost > 0) {
          let costLine = `💰 $${info.totalCost.toFixed(4)}`;

          // Get models from original tokenUsageData if available
          if (info.tokenUsageData?.modelsUsed && info.tokenUsageData.modelsUsed.length > 0) {
            const { normalizeModelNameLowercase } = await import('./utils/model-normalizer.js');
            const modelNames = info.tokenUsageData.modelsUsed.map(m => normalizeModelNameLowercase(m)).join(', ');
            costLine += ` (${modelNames})`;
          }
          tokenParts.push(costLine);
        }

        // Add input tokens (with cache info)
        if (info.totalInputTokens > 0) {
          let inputPart = `In: ${formatTokens(info.totalInputTokens)}`;
          if (info.totalCacheReadTokens > 0) {
            inputPart += ` (${formatTokens(info.totalCacheReadTokens)} cached)`;
          }
          tokenParts.push(inputPart);
        }

        // Add output tokens
        if (info.totalOutputTokens > 0) {
          tokenParts.push(`Out: ${formatTokens(info.totalOutputTokens)}`);
        }

        if (tokenParts.length > 0) {
          completionMessage += `\n${tokenParts.join(' • ')}\n`;
        }
      }

      if (info.commits && info.commits.length > 0) {
        // Group commits by goal name to avoid repeating goal titles
        const commitsByGoal = {};
        for (const commit of info.commits) {
          const goalName = commit.goalName || 'Unknown Goal';
          if (!commitsByGoal[goalName]) {
            commitsByGoal[goalName] = [];
          }
          commitsByGoal[goalName].push(commit);
        }

        completionMessage += `\n💾 *Commits:*\n`;
        const goalNames = Object.keys(commitsByGoal);
        for (const goalName of goalNames) {
          const goalCommits = commitsByGoal[goalName];
          // Only show goal name as a header if there are multiple goals
          if (goalNames.length > 1) {
            completionMessage += `*${goalName}:*\n`;
          }
          for (const commit of goalCommits) {
            const shortHash = commit.hash.substring(0, 7);
            const commitMsg = commit.message || 'No message';
            completionMessage += `• \`${shortHash}\` ${commitMsg}\n`;
          }
        }
      }

      if (info.completedIterations > 0) {
        completionMessage += `\n✨ Successfully completed ${info.completedIterations} iteration(s)!\n`;
      }

      completionMessage += `\nUse /goals to view updated progress.`;

      // Edit the message
      const keyboard = {
        inline_keyboard: [[
          { text: '📊 View Goals', callback_data: '/goals' }
        ]]
      };

      await this.telegramNotifier.editMessage(info.chatId, info.messageId, completionMessage, {
        parse_mode: 'Markdown',
        reply_markup: keyboard
      });

      logger.info(`[GOALLOOP_USAGE] Updated completion message for ${updateKey} with new cost: $${info.totalCost.toFixed(4)}`);
    } catch (error) {
      logger.warn(`[GOALLOOP_USAGE] Failed to update completion message: ${error.message}`);
    }
  }

  // Helper method to calculate goal loop token usage from ccusage snapshot
  async getGoalLoopUsageData(state) {
    // Primary source: ccusage snapshot difference (most reliable for total cost)
    if (state.tokenSnapshot) {
      try {
        const { execSync } = await import('child_process');
        const today = new Date().toISOString().split('T')[0].replace(/-/g, '');
        const snapshotCmd = `npx ccusage -i --offline --since ${today} -j`;
        const snapshotOutput = execSync(snapshotCmd, { encoding: 'utf8', timeout: 10000 });
        const currentSnapshot = JSON.parse(snapshotOutput);

        if (currentSnapshot?.totals) {
          const inputTokensDiff = (currentSnapshot.totals.inputTokens || 0) - state.tokenSnapshot.inputTokens;
          const outputTokensDiff = (currentSnapshot.totals.outputTokens || 0) - state.tokenSnapshot.outputTokens;
          const cacheReadTokensDiff = (currentSnapshot.totals.cacheReadTokens || 0) - (state.tokenSnapshot.cacheReadTokens || 0);
          const cacheCreationTokensDiff = (currentSnapshot.totals.cacheCreationTokens || 0) - (state.tokenSnapshot.cacheCreationTokens || 0);
          const totalTokensDiff = inputTokensDiff + outputTokensDiff + cacheReadTokensDiff + cacheCreationTokensDiff;

          // Calculate cost delta
          const inputCost = (inputTokensDiff * 3 / 1000000);
          const outputCost = (outputTokensDiff * 15 / 1000000);
          const cacheReadCost = (cacheReadTokensDiff * 0.3 / 1000000);
          const cacheCreationCost = (cacheCreationTokensDiff * 3.75 / 1000000);
          const totalCostDiff = inputCost + outputCost + cacheReadCost + cacheCreationCost;

          // Collect unique models from snapshot
          const models = new Set();
          if (currentSnapshot.projects) {
            Object.values(currentSnapshot.projects).forEach(projectDays => {
              projectDays.forEach(day => {
                if (day.modelsUsed) {
                  day.modelsUsed.forEach(model => models.add(model));
                }
              });
            });
          }

          return {
            inputTokens: inputTokensDiff,
            outputTokens: outputTokensDiff,
            cacheReadTokens: cacheReadTokensDiff,
            cacheCreationTokens: cacheCreationTokensDiff,
            totalTokens: totalTokensDiff,
            cost: totalCostDiff,
            modelsUsed: Array.from(models)
          };
        }
      } catch (error) {
        logger.debug(`Failed to get goal loop usage from snapshot: ${error.message}`);
      }
    }

    // Fallback: use accumulated tokens from per-task tracking
    if (state.totalInputTokens > 0 || state.totalOutputTokens > 0 || state.totalCost > 0) {
      return {
        inputTokens: state.totalInputTokens || 0,
        outputTokens: state.totalOutputTokens || 0,
        cacheReadTokens: state.totalCacheReadTokens || 0,
        totalTokens: (state.totalInputTokens || 0) + (state.totalOutputTokens || 0) + (state.totalCacheReadTokens || 0),
        cost: state.totalCost || 0,
        modelsUsed: []
      };
    }

    return null;
  }

  // Helper method to format goal loop status message
  async formatGoalLoopStatus(state, status) {
    const elapsed = Date.now() - state.startTime;
    const minutes = Math.floor(elapsed / 60000);
    const seconds = Math.floor((elapsed % 60000) / 1000);
    const timeStr = minutes > 0 ? `${minutes}m ${seconds}s` : `${seconds}s`;

    let message = '';

    if (status === 'starting') {
      message = `*🔄 Goal Automation Loop Starting*\n\n` +
        `*Workspace:* ${state.workspaceName}\n` +
        `*Max Iterations:* ${state.maxIterations}\n` +
        `*Target Goal:* ${state.specificGoalId || 'Auto-select'}\n\n` +
        `_Initializing..._`;
    } else if (status === 'implementing') {
      const goal = state.currentGoal;
      const goalName = goal?.title || goal?.file || 'Unknown';
      const cachedGoalStatus = goal?.progress?.status || goal?.status || 'Unknown';

      // Build progress line based on available data
      let progressLine = '';
      const taskCompleted = goal?.progress?.taskCompletion?.completed || goal?.tasksComplete || 0;
      const taskTotal = goal?.progress?.taskCompletion?.total || goal?.taskCount || 0;
      const completionPct = goal?.completionPercentage || goal?.progress?.completionPercentage || 0;

      if (taskTotal > 0) {
        progressLine = `*Progress:* ${taskCompleted}/${taskTotal} tasks (${completionPct}%)\n`;
      } else if (completionPct > 0) {
        progressLine = `*Progress:* ${completionPct}%\n`;
      }
      // Don't show progress line if no data - avoid duplication with status

      // Show cached goal status (what it was before this iteration started)
      // The "Claude is implementing..." at the bottom already indicates active work
      const displayStatus = cachedGoalStatus === 'Not Started' || cachedGoalStatus === 'Unknown'
        ? 'New goal'
        : cachedGoalStatus;

      message = `*🔄 Goal Loop - Iteration ${state.currentIteration}/${state.maxIterations}*\n\n` +
        `⏱️ ${timeStr}\n` +
        `*Current Goal:* ${goal?.id}. ${goalName}\n` +
        `*Prior Status:* ${displayStatus}\n` +
        progressLine +
        `*Task ID:* ${state.currentTaskId || 'none'}\n\n`;

      // Show cumulative loop-wide token usage using shared helper
      const formatTokens = (tokens) => {
        if (tokens >= 1000000) return `${(tokens / 1000000).toFixed(1)}m`;
        if (tokens >= 1000) return `${(tokens / 1000).toFixed(1)}k`;
        return tokens.toString();
      };

      const usageData = await this.getGoalLoopUsageData(state);
      if (usageData && (usageData.totalTokens > 0 || state.completedIterations > 0)) {
        message += `📊 *Loop Usage:* ${formatTokens(usageData.totalTokens)} tokens | $${usageData.cost.toFixed(4)}`;
        if (state.completedIterations > 0) {
          message += ` (${state.completedIterations} iter done)`;
        }
        message += `\n`;
      }

      // Get real-time git status
      if (state.workspacePath) {
        try {
          const { execSync } = await import('child_process');
          const statusOutput = execSync('git status --porcelain', {
            cwd: state.workspacePath,
            encoding: 'utf8',
            timeout: 3000
          }).trim();

          if (statusOutput) {
            const lines = statusOutput.split('\n');
            const fileCount = lines.length;

            // Count additions and modifications
            let modified = 0;
            let added = 0;
            let deleted = 0;

            lines.forEach(line => {
              const status = line.substring(0, 2);
              if (status.includes('M')) modified++;
              if (status.includes('A') || status.includes('?')) added++;
              if (status.includes('D')) deleted++;
            });

            message += `📂 *Git Changes:* ${fileCount} file${fileCount !== 1 ? 's' : ''} `;
            const changes = [];
            if (modified > 0) changes.push(`${modified}M`);
            if (added > 0) changes.push(`${added}A`);
            if (deleted > 0) changes.push(`${deleted}D`);
            message += `(${changes.join(', ')})\n`;

            // Show up to 5 files
            const filesToShow = lines.slice(0, 5).map(line => {
              const status = line.substring(0, 2);
              const file = line.substring(3);
              return `  ${status} ${file}`;
            });
            message += '```\n' + filesToShow.join('\n');
            if (lines.length > 5) {
              message += `\n... and ${lines.length - 5} more`;
            }
            message += '\n```\n';
          } else {
            message += `📂 *Git Status:* Clean\n`;
          }
        } catch (error) {
          // Not a git repo or error - skip git status
          logger.debug(`Failed to get git status for goal loop: ${error.message}`);
        }
      }

      message += `\n⏳ _Claude is implementing..._`;
    } else if (status === 'syncing') {
      const formatTokens = (tokens) => {
        if (tokens >= 1000000) return `${(tokens / 1000000).toFixed(1)}m`;
        if (tokens >= 1000) return `${(tokens / 1000).toFixed(1)}k`;
        return tokens.toString();
      };
      const usageData = await this.getGoalLoopUsageData(state);

      message = `*🔄 Goal Loop - Iteration ${state.currentIteration}/${state.maxIterations}*\n\n` +
        `⏱️ ${timeStr}\n` +
        `✅ Implementation complete\n` +
        `📊 _Syncing goals cache..._\n`;

      if (usageData && (usageData.totalTokens > 0 || usageData.cost > 0)) {
        message += `💰 *Cost:* $${usageData.cost.toFixed(4)} | ${formatTokens(usageData.totalTokens)} tokens\n`;
      }
      message += `_Debug: Completed=${state.completedIterations}, Failed=${state.failedIterations}_`;
    } else if (status === 'committing') {
      const formatTokens = (tokens) => {
        if (tokens >= 1000000) return `${(tokens / 1000000).toFixed(1)}m`;
        if (tokens >= 1000) return `${(tokens / 1000).toFixed(1)}k`;
        return tokens.toString();
      };
      const usageData = await this.getGoalLoopUsageData(state);

      message = `*🔄 Goal Loop - Iteration ${state.currentIteration}/${state.maxIterations}*\n\n` +
        `⏱️ ${timeStr}\n` +
        `✅ Implementation complete\n` +
        `✅ Cache synced\n` +
        `💾 _Committing changes..._\n`;

      if (usageData && (usageData.totalTokens > 0 || usageData.cost > 0)) {
        message += `💰 *Cost:* $${usageData.cost.toFixed(4)} | ${formatTokens(usageData.totalTokens)} tokens\n`;
      }
      message += `_Debug: Commits=${state.commits.length}_`;
    } else if (status === 'complete' || status === 'all_complete') {
      const allComplete = status === 'all_complete';
      message = `*✅ Goal Loop Complete*\n\n` +
        `⏱️ Total Time: ${timeStr}\n` +
        `*Total Iterations:* ${state.currentIteration}\n` +
        `*Successful:* ${state.completedIterations}\n` +
        `*Failed:* ${state.failedIterations}\n` +
        `*Workspace:* ${state.workspaceName}\n`;

      // Add token/cost statistics using shared helper
      const usageData = await this.getGoalLoopUsageData(state);
      if (usageData && usageData.totalTokens > 0) {
        message += `\n📊 *Usage Stats:*\n`;
        message += `  🎯 Tokens: ${usageData.totalTokens.toLocaleString()}\n`;
        if (usageData.cost > 0) {
          message += `  💰 Cost: $${usageData.cost.toFixed(4)}\n`;
        }
      }

      if (state.commits.length > 0) {
        // Group commits by goal name to avoid repeating goal titles
        const commitsByGoal = {};
        for (const commit of state.commits) {
          const goalName = commit.goalName || 'Unknown Goal';
          if (!commitsByGoal[goalName]) {
            commitsByGoal[goalName] = [];
          }
          commitsByGoal[goalName].push(commit);
        }

        message += `\n💾 *Commits:*\n`;
        const goalNames = Object.keys(commitsByGoal);
        for (const goalName of goalNames) {
          const goalCommits = commitsByGoal[goalName];
          // Only show goal name as a header if there are multiple goals
          if (goalNames.length > 1) {
            message += `*${goalName}:*\n`;
          }
          for (const commit of goalCommits) {
            const shortHash = commit.hash.substring(0, 7);
            const commitMsg = commit.message || 'No message';
            message += `  • \`${shortHash}\` ${commitMsg}\n`;
          }
        }
      }

      if (allComplete) {
        message += `\n🎉 All goals have been completed!`;
      } else {
        message += `\nRun /goals to see updated progress.`;
      }
    } else if (status === 'stopped') {
      message = `*⏹ Goal Loop Stopped*\n\n` +
        `⏱️ Run Time: ${timeStr}\n` +
        `*Completed Iterations:* ${state.completedIterations}/${state.currentIteration}\n` +
        `*Failed:* ${state.failedIterations}\n` +
        `*Workspace:* ${state.workspaceName}\n`;

      // Add token/cost statistics using shared helper
      const usageData = await this.getGoalLoopUsageData(state);
      if (usageData && usageData.totalTokens > 0) {
        message += `\n📊 *Usage Stats:*\n`;
        message += `  🎯 Tokens: ${usageData.totalTokens.toLocaleString()}\n`;
        if (usageData.cost > 0) {
          message += `  💰 Cost: $${usageData.cost.toFixed(4)}\n`;
        }
      }

      message += `\nLoop stopped by user.`;
    }

    return message;
  }

  // Helper method to update goal loop message
  async updateGoalLoopMessage(chatId, state, status) {
    const message = await this.formatGoalLoopStatus(state, status);

    // Use state.chatId if available (allows /here redirect to update target chat)
    const targetChatId = state.chatId || chatId;

    let keyboard = {};
    if (status === 'complete' || status === 'all_complete' || status === 'stopped') {
      keyboard = {
        inline_keyboard: [[
          { text: '📊 Goals', callback_data: '/goals' }
        ]]
      };
    } else {
      keyboard = {
        inline_keyboard: [[
          { text: '⏹ Stop', callback_data: JSON.stringify({ action: 'stop_loop' }) },
          { text: '🔄 Refresh', callback_data: JSON.stringify({ action: 'refresh_loop' }) }
        ]]
      };
    }

    if (state.statusMessageId) {
      try {
        await this.telegramNotifier.editMessage(
          targetChatId,
          state.statusMessageId,
          message,
          { parse_mode: 'Markdown', reply_markup: keyboard }
        );
      } catch (error) {
        logger.error(`Failed to update goal loop message: ${error.message}`);
        // Note: /here command creates a new message when redirecting,
        // so state.statusMessageId should already point to the new chat's message
      }
    }
  }

  async handleRememberCommand(chatId, args, message) {
    try {
      // Check if daemon is running
      const daemonClient = new (await import('./daemon-client.js')).DaemonClient();
      if (!daemonClient.isDaemonRunning()) {
        await this.telegramNotifier.sendMessage(chatId,
          '❌ The daemon is not running. Cannot use /remember command.\n\n' +
          'Please start the daemon first with:\n```\nani-code daemon --start\n```',
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // Check if this is a reply to a message
      let rememberInfo = args;

      // If this is a reply, include the replied message content
      if (message && message.reply_to_message) {
        const repliedText = message.reply_to_message.text || message.reply_to_message.caption || '';
        if (repliedText) {
          // If args exist, combine them with the replied text
          if (rememberInfo) {
            rememberInfo = `${repliedText}\n\nAdditional context: ${rememberInfo}`;
          } else {
            rememberInfo = repliedText;
          }
          logger.debug(`[/remember] Using reply text: ${repliedText.substring(0, 100)}...`);
        }
      }

      // Check for @preset.md syntax - supports wildcards and regex patterns
      const presetMatches = rememberInfo ? rememberInfo.match(/@([\w*]+)\.md/g) : null;
      if (presetMatches) {
        const { join, dirname } = await import('path');
        const { fileURLToPath } = await import('url');
        const { existsSync, readFileSync, readdirSync } = await import('fs');
        const __dirname = dirname(fileURLToPath(import.meta.url));
        const presetsDir = join(__dirname, 'presets');

        // Store all matching preset contents
        const matchedPresets = new Set();
        let combinedPresetContent = '';

        for (const match of presetMatches) {
          // Extract pattern from @pattern.md
          const pattern = match.replace('@', '').replace('.md', '');

          // Check if directory exists
          if (!existsSync(presetsDir)) {
            await this.telegramNotifier.sendMessage(chatId,
              `❌ Presets directory not found: ${presetsDir}`,
              { parse_mode: 'Markdown' }
            );
            return;
          }

          // Get all .md files in presets dir
          const allPresets = readdirSync(presetsDir).filter(f => f.endsWith('.md'));

          // Find matching files based on pattern
          let matchingFiles = [];
          if (pattern.includes('*')) {
            // Convert wildcard pattern to regex
            const regexPattern = pattern.replace(/\*/g, '.*');
            const regex = new RegExp(`^${regexPattern}$`);
            matchingFiles = allPresets.filter(f => regex.test(f.replace('.md', '')));
          } else {
            // Exact match
            const exactFile = `${pattern}.md`;
            if (allPresets.includes(exactFile)) {
              matchingFiles = [exactFile];
            }
          }

          // If no matches found for this pattern
          if (matchingFiles.length === 0) {
            let availablePresets = '';
            if (allPresets.length > 0) {
              availablePresets = '\n\nAvailable presets:\n' +
                allPresets.map(p => `• @${p.replace('.md', '')}.md`).join('\n');
            }
            await this.telegramNotifier.sendMessage(chatId,
              `❌ No presets found matching pattern: ${pattern}${availablePresets}`,
              { parse_mode: 'Markdown' }
            );
            return;
          }

          // Read matching files
          for (const file of matchingFiles) {
            // Skip if already processed (for unique constraint)
            if (matchedPresets.has(file)) {
              continue;
            }
            matchedPresets.add(file);

            const presetFile = join(presetsDir, file);
            try {
              const content = readFileSync(presetFile, 'utf8');

              // Add header for each preset if multiple
              if (matchedPresets.size > 1 || matchingFiles.length > 1) {
                combinedPresetContent += `\n\n# From preset: ${file}\n`;
              }
              combinedPresetContent += content;
            } catch (error) {
              await this.telegramNotifier.sendMessage(chatId,
                `❌ Failed to read preset file ${file}: ${error.message}`,
                { parse_mode: 'Markdown' }
              );
              return;
            }
          }
        }

        // Remove all @preset.md patterns from the info
        let additionalInfo = rememberInfo;
        for (const match of presetMatches) {
          additionalInfo = additionalInfo.replace(match, '');
        }
        additionalInfo = additionalInfo.trim();

        // Combine preset content with additional info
        if (additionalInfo && combinedPresetContent) {
          rememberInfo = `${combinedPresetContent}\n\nAdditional context: ${additionalInfo}`;
        } else if (combinedPresetContent) {
          rememberInfo = combinedPresetContent;
        }

        // Send confirmation with summary
        const fileCount = matchedPresets.size;
        const fileList = Array.from(matchedPresets).map(f => `• ${f}`).join('\n');
        await this.telegramNotifier.sendMessage(chatId,
          `✅ Loaded ${fileCount} preset${fileCount > 1 ? 's' : ''}:\n${fileList}`,
          { parse_mode: 'Markdown' }
        );
      }

      if (!rememberInfo) {
        await this.telegramNotifier.sendMessage(chatId,
          '❓ What should Claude remember?\n\n' +
          'Usage:\n' +
          '• `/remember <information>` - Save information\n' +
          '• `/remember @preset.md` - Use a specific preset\n' +
          '• `/remember @*.md` - Use all presets\n' +
          '• `/remember @web*.md` - Use presets matching pattern\n' +
          '• `/remember @api.md @web.md` - Use multiple presets\n' +
          '• Reply to a message with `/remember` to save it',
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // Send initial status
      const statusMessage = await this.telegramNotifier.sendMessage(chatId,
        '📝 Updating CLAUDE.md with new information...',
        { parse_mode: 'Markdown' }
      );

      // Extract message ID (handle both gateway and direct mode responses)
      const messageId = statusMessage?.platform_response?.result?.message_id || statusMessage?.result?.message_id || statusMessage?.message_id;

      // Get workspace for this chat (in gateway mode, defaults to 'workspace' via ChatSettings)
      const fullChatId = `telegram:${chatId}`;
      const workdirName = this.chatSettings.getWorkdir(fullChatId);

      if (!workdirName) {
        await this.telegramNotifier.editMessage(chatId, messageId,
          '❌ No workspace connected to this chat. Please use /connect <token> to connect to a workspace first.',
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // Get available workdirs to find the path
      const availableWorkdirs = await this.getAvailableWorkdirs(fullChatId);
      const workdirPath = availableWorkdirs[workdirName];

      if (!workdirPath) {
        await this.telegramNotifier.editMessage(chatId, messageId,
          '❌ Workspace path not found. Please reconnect to your workspace.',
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // Initialize workspace manager if needed
      if (!this.workspaceManager) {
        const { WorkspaceManager } = await import('./workspace-manager.js');
        this.workspaceManager = new WorkspaceManager();
        await this.workspaceManager.initialize();
      }

      // Get the workspace by path
      let workspace = await this.workspaceManager.getWorkspaceByPath(workdirPath);

      // In gateway mode, if workspace doesn't exist in DB, create a minimal workspace object
      if (!workspace && config.gateway.enabled) {
        logger.info(`[Gateway] Workspace not in DB, using path directly for /remember: ${workdirPath}`);
        workspace = {
          id: null,
          name: workdirName,
          path: workdirPath
        };
      } else if (!workspace) {
        await this.telegramNotifier.editMessage(chatId, messageId,
          '❌ Workspace not found in database. Please reconnect to your workspace.',
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // Create the task to update CLAUDE.md
      const rememberPrompt = `You are a CLAUDE.md editor helper. Your task is to update the CLAUDE.md file to remember the following information:

"${rememberInfo}"

CRITICAL INSTRUCTIONS:
1. First, ALWAYS read the current CLAUDE.md file to understand its structure
2. If there are any conflicts between new and existing information, use the user's LATEST instruction
3. If you observe any serious issues or conflicts that cannot be resolved automatically, STOP editing and ask the user for suggestions
4. Add the new information in an appropriate section or create a new section if needed
5. Keep the existing critical warnings and structure intact
6. Preserve any existing important instructions or configurations
7. Only update or add the new information without removing unrelated existing content
8. Use clear, concise language
9. Format the content properly with markdown
10. After updating, provide a brief summary of what was added or changed

ORGANIZATION GUIDELINES:
- For extended documentation, create files in pd/rules/ or pd/definitions/ instead of cluttering CLAUDE.md
- Place detailed specifications and reference materials in pd/rules/ for guidelines and standards
- Use pd/definitions/ for technical definitions and reference materials
- Keep CLAUDE.md focused on essential configuration and critical warnings
- Reference the organized directories when appropriate (e.g., "See pd/rules/api-conventions.md for details")
- Move long reference materials to appropriate pd/ subdirectories to maintain CLAUDE.md clarity`;

      // Create task using task monitor
      const taskName = `remember-${Date.now()}`;
      const taskOptions = {
        cwd: workdirPath,
        source: 'telegram_remember',
        chatId: fullChatId,
        workspace_id: workspace.id || null,
        providerId: await this.getCurrentProviderId()  // Track provider for footer/usage display
      };

      const task = this.taskMonitor.addTask(taskName, rememberPrompt, taskOptions);

      logger.info(`Created remember task: ${task.id} for workspace ${workspace.name} from Telegram chat ${chatId}`);

      // Update status message
      await this.telegramNotifier.editMessage(chatId, messageId,
        `✅ Task created to update CLAUDE.md!\n\n` +
        `📍 Workspace: ${workdirName}\n` +
        `🆔 Task ID: ${task.id}\n\n` +
        'Claude will process this request and remember the information for future tasks.',
        { parse_mode: 'Markdown' }
      );

    } catch (error) {
      logger.error(`Error in handleRememberCommand: ${error.message}`, error);
      await this.telegramNotifier.sendMessage(chatId,
        `❌ Failed to save information: ${error.message}`,
        { parse_mode: 'Markdown' }
      );
    }
  }

  async handleRulecompressCommand(chatId, args, message) {
    try {
      // Check if daemon is running
      const daemonClient = new (await import('./daemon-client.js')).DaemonClient();
      if (!daemonClient.isDaemonRunning()) {
        await this.telegramNotifier.sendMessage(chatId,
          '❌ The daemon is not running. Cannot use /rulecompress command.\n\n' +
          'Please start the daemon first with:\n```\nani-code daemon --start\n```',
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // Get workspace for this chat
      const fullChatId = `telegram:${chatId}`;
      const workdirName = this.chatSettings.getWorkdir(fullChatId);

      if (!workdirName) {
        await this.telegramNotifier.sendMessage(chatId,
          '❌ No workspace connected to this chat. Please use /connect <token> to connect to a workspace first.',
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // Get available workdirs to find the path
      const availableWorkdirs = await this.getAvailableWorkdirs(fullChatId);
      const workdirPath = availableWorkdirs[workdirName];

      if (!workdirPath) {
        await this.telegramNotifier.sendMessage(chatId,
          '❌ Workspace path not found. Please reconnect to your workspace.',
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // Initialize workspace manager if needed
      if (!this.workspaceManager) {
        const { WorkspaceManager } = await import('./workspace-manager.js');
        this.workspaceManager = new WorkspaceManager();
        await this.workspaceManager.initialize();
      }

      // Get the workspace by path
      const workspace = await this.workspaceManager.getWorkspaceByPath(workdirPath);
      if (!workspace) {
        await this.telegramNotifier.sendMessage(chatId,
          '❌ Workspace not found in database. Please reconnect to your workspace.',
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // Check if this is a reply to a message
      let additionalContext = args;

      // If this is a reply, include the replied message content
      if (message && message.reply_to_message) {
        const repliedText = message.reply_to_message.text || message.reply_to_message.caption || '';
        if (repliedText) {
          // If args exist, combine them with the replied text
          if (additionalContext) {
            additionalContext = `${repliedText}\n\nAdditional context: ${additionalContext}`;
          } else {
            additionalContext = repliedText;
          }
          logger.debug(`[/rulecompress] Using reply text: ${repliedText.substring(0, 100)}...`);
        }
      }

      // Send status message
      const statusMessage = await this.telegramNotifier.sendMessage(chatId,
        '🔧 Starting CLAUDE.md compression and organization...',
        { parse_mode: 'Markdown' }
      );

      // Create the task to compress CLAUDE.md
      const rulecompressPrompt = `You are tasked with compressing and organizing the CLAUDE.md file by extracting detailed content to the pd/rules folder.

## Objective

Reduce the size of CLAUDE.md by:
1. Identifying verbose or detailed sections
2. Extracting them to appropriate files in pd/rules/
3. Replacing the detailed content with concise summaries and references
4. Keeping CLAUDE.md as a high-level reference guide

## Process

1. **Read Current State**
   - Read the entire CLAUDE.md file
   - Identify sections that are too detailed or verbose
   - Check existing pd/rules/ structure

2. **Extract Details**
   - For each verbose section, create or update a file in pd/rules/
   - Use descriptive filenames (e.g., port-configuration.md, service-management.md)
   - Preserve all information - nothing should be lost
   - Group related content logically

3. **Update CLAUDE.md**
   - Replace detailed sections with concise summaries (2-4 lines)
   - Add clear references to the detailed documentation
   - Format: "For detailed information, see: pd/rules/[filename].md"
   - Maintain the overall structure and flow

4. **Verify Organization**
   - Ensure CLAUDE.md remains coherent and easy to scan
   - Check that all extracted details are properly referenced
   - Confirm no information was lost in the process

## Example Transformation

### Before (verbose in CLAUDE.md):
\`\`\`markdown
## Port Configuration

### Default Ports
- **Daemon HTTP API**: \`6501\` (primary service port)
- **WebSocket Service**: \`6502\` (real-time communications)

### Port Priority (Daemon HTTP API)
The daemon port is selected with the following priority:
1. \`ANI_CODE_DAEMON_PORT\` - Primary daemon-specific variable
2. \`HTTP_CALLBACK_PORT\` - Legacy fallback
3. \`PORT\` - Generic fallback
4. Default: \`6501\`

### Environment Variables
\`\`\`bash
# Daemon HTTP API Port
ANI_CODE_DAEMON_PORT=6501         # Primary (recommended)
...
\`\`\`
\`\`\`

### After (concise in CLAUDE.md):
\`\`\`markdown
## Port Configuration

Default ports: HTTP API (6501), WebSocket (6502). Configure via \`ANI_CODE_DAEMON_PORT\` and \`ANICODE_WS_PORT\` environment variables.

For detailed port configuration, priority rules, and examples, see: pd/rules/port-configuration.md
\`\`\`

## Rules to Follow

1. **Preserve Information**: Never delete information - only relocate it
2. **Maintain References**: Always provide clear paths to detailed docs
3. **Keep Critical Warnings**: Security warnings and critical notices stay in CLAUDE.md
4. **Logical Grouping**: Group related topics in the same pd/rules file
5. **Consistent Format**: Use consistent markdown formatting across files

## Output Format

After completing the compression, provide:
1. List of files created/updated in pd/rules/
2. Summary of changes made to CLAUDE.md
3. Confirmation that all information was preserved
4. New total line count of CLAUDE.md (target: 50-70% reduction)

${additionalContext ? `\n## Additional Context from User\n\n${additionalContext}\n` : ''}

---

Begin the compression process now. Read CLAUDE.md, identify verbose sections, extract them to pd/rules/, and update CLAUDE.md with concise summaries and references.`;

      // Create the task
      logger.info(`Creating rulecompress task for chat ${chatId} in workspace ${workspace.name}`);
      await this.createTelegramTask(chatId, 'add', rulecompressPrompt);

      // Update status message
      await this.telegramNotifier.editMessage(chatId, statusMessage.result.message_id,
        '✅ *Rule compression task created*\n\n' +
        'Claude will now:\n' +
        '• Analyze CLAUDE.md for verbose sections\n' +
        '• Extract details to pd/rules/ folder\n' +
        '• Update CLAUDE.md with concise summaries\n' +
        '• Preserve all information',
        { parse_mode: 'Markdown' }
      );

    } catch (error) {
      logger.error(`Error in handleRulecompressCommand: ${error.message}`, error);
      await this.telegramNotifier.sendMessage(chatId,
        `❌ Failed to start rule compression: ${error.message}`,
        { parse_mode: 'Markdown' }
      );
    }
  }

  async handlePrintCommand(chatId) {
    try {
      // Get workspace for this chat
      const fullChatId = `telegram:${chatId}`;
      const workdirName = this.chatSettings.getWorkdir(fullChatId);

      if (!workdirName) {
        await this.telegramNotifier.sendMessage(chatId,
          '❌ No workspace connected to this chat.\n\n' +
          'Please use `/connect <token>` to connect to a workspace first.',
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // Get available workdirs to find the path
      const availableWorkdirs = await this.getAvailableWorkdirs(fullChatId);
      const workdirPath = availableWorkdirs[workdirName];

      if (!workdirPath) {
        await this.telegramNotifier.sendMessage(chatId,
          '❌ Workspace path not found. Please reconnect to your workspace.',
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // Use ClaudeHistoryViewer to read from filesystem
      const historyViewer = new ClaudeHistoryViewer();
      const sessionFile = await historyViewer.findLatestSession(workdirPath);

      if (!sessionFile) {
        await this.telegramNotifier.sendMessage(chatId,
          '❌ No session history found for this workspace.',
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // Parse the session to get messages
      const messages = await historyViewer.parseSession(sessionFile);

      if (!messages || messages.length === 0) {
        await this.telegramNotifier.sendMessage(chatId,
          '❌ No messages found in session history.',
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // Find the last assistant message with text content
      let lastAssistantMessage = null;
      for (let i = messages.length - 1; i >= 0; i--) {
        if (messages[i].type === 'assistant' && messages[i].textContent) {
          lastAssistantMessage = messages[i];
          break;
        }
      }

      if (!lastAssistantMessage) {
        await this.telegramNotifier.sendMessage(chatId,
          '❌ No assistant response found in recent history.',
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // Get the output text
      const output = lastAssistantMessage.textContent;

      const cleanOutput = this.telegramNotifier.sanitizeForCodeBlock(output);

      // Format the message
      const timestamp = new Date(lastAssistantMessage.timestamp).toLocaleString();
      let message = `*📄 Last Assistant Response*\n\n`;
      message += `🕐 Time: ${timestamp}\n\n`;
      message += `*Output:*\n`;
      message += `\`\`\`\n${cleanOutput}\n\`\`\``;

      // Send the message (Telegram has 4096 char limit, split if needed)
      const MAX_LENGTH = 4000;
      if (message.length <= MAX_LENGTH) {
        await this.telegramNotifier.sendMessage(chatId, message, { parse_mode: 'Markdown' });
      } else {
        // Split into multiple messages
        const header = `*📄 Last Assistant Response*\n\n` +
          `🕐 Time: ${timestamp}\n\n`;

        await this.telegramNotifier.sendMessage(chatId, header + '*Output (Part 1):*', { parse_mode: 'Markdown' });

        // Split output into chunks
        const outputWithWrapper = `\`\`\`\n${cleanOutput}\n\`\`\``;
        let remaining = outputWithWrapper;
        let partNum = 1;

        while (remaining.length > 0) {
          const chunk = remaining.substring(0, MAX_LENGTH);
          remaining = remaining.substring(MAX_LENGTH);

          await this.telegramNotifier.sendMessage(chatId,
            partNum > 1 ? `*Part ${partNum}:*\n${chunk}` : chunk,
            { parse_mode: 'Markdown' }
          );
          partNum++;
        }
      }

      logger.info(`Sent last assistant response from ${sessionFile} to chat ${chatId}`);

    } catch (error) {
      logger.error(`Error in handlePrintCommand: ${error.message}`, error);
      await this.telegramNotifier.sendMessage(chatId,
        `❌ Failed to retrieve task output: ${error.message}`,
        { parse_mode: 'Markdown' }
      );
    }
  }

  async handleMacrosCommand(chatId, args) {
    try {
      // Get workspace for this chat
      const fullChatId = `telegram:${chatId}`;
      const workdirName = this.chatSettings.getWorkdir(fullChatId);

      if (!workdirName) {
        await this.telegramNotifier.sendMessage(chatId,
          '❌ No workspace connected to this chat.\n\n' +
          'Please use `/connect <token>` to connect to a workspace first.',
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // Get available workdirs to find the path
      const availableWorkdirs = await this.getAvailableWorkdirs(fullChatId);
      const workdirPath = availableWorkdirs[workdirName];

      if (!workdirPath) {
        await this.telegramNotifier.sendMessage(chatId,
          '❌ Workspace path not found. Please reconnect to your workspace.',
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // Initialize workspace manager if needed
      if (!this.workspaceManager) {
        const { WorkspaceManager } = await import('./workspace-manager.js');
        this.workspaceManager = new WorkspaceManager();
        await this.workspaceManager.initialize();
      }

      // Get the workspace by path
      const workspace = await this.workspaceManager.getWorkspaceByPath(workdirPath);
      if (!workspace) {
        await this.telegramNotifier.sendMessage(chatId,
          '❌ Workspace not found in database. Please reconnect to your workspace.',
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // Get all macros for the workspace
      const allMeta = await this.workspaceManager.listWorkspaceMeta(workspace.id, 'macro-');
      const macros = Object.entries(allMeta);

      if (macros.length === 0) {
        await this.telegramNotifier.sendMessage(chatId,
          '📝 No macros defined for this workspace\n\n' +
          'Create a macro with:\n' +
          '`ani-code workspace macro set <name> <command>`\n\n' +
          'Example:\n' +
          '`ani-code workspace macro set progress "/add what is the current progress"`\n\n' +
          'Then execute in Telegram with: `/$progress`',
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // Build macros message with clickable commands
      let macrosMessage = `📝 *Macros for workspace "${workspace.name}":*\n\n`;

      const verbose = args && (args === '-v' || args === '--verbose');

      for (const [key, value] of macros) {
        const macroName = key.replace('macro-', '');

        // Truncate content if too long and not verbose mode
        let content = value;
        if (!verbose && content.length > 100) {
          content = content.substring(0, 97) + '...';
        }

        // Make the macro command clickable, with content in code block
        macrosMessage += `\`/$${macroName}\`\n`;
        macrosMessage += '```\n';
        macrosMessage += `${content}\n`;
        macrosMessage += '```\n\n';
      }

      if (!verbose && macros.some(([k, v]) => v.length > 100)) {
        macrosMessage += '_Use `/macros -v` for full content_';
      }

      await this.telegramNotifier.sendMessage(chatId, macrosMessage, { parse_mode: 'Markdown' });

      logger.info(`Displayed ${macros.length} macros for workspace ${workspace.name} to Telegram chat ${chatId}`);

    } catch (error) {
      logger.error(`Error in handleMacrosCommand: ${error.message}`, error);
      await this.telegramNotifier.sendMessage(chatId,
        `❌ Failed to list macros: ${error.message}`,
        { parse_mode: 'Markdown' }
      );
    }
  }

  async handleCheatsheetCommand(chatId) {
    try {
      const cheatsheet = `🚀 *Ani-Code Telegram Integration Cheatsheet*

📋 *INITIAL SETUP*
  1. Initialize project: \`ani-code remember "@main.md"\`
  2. Browser tasks: \`ani-code remember "@browser.md"\`
  3. Web development: \`ani-code remember "@web.md"\`

🤖 *TELEGRAM COMMANDS*
  \`/add <prompt>\`       Create new Claude task
  \`/continue\`           Continue last task
  \`/commit\`             Commit current changes
  \`/plan <prompt>\`      Set tasks for later execution
  \`/yolo <prompt>\`      Execute with auto-accept

📝 *MACROS (Customizable)*
  \`/$goal\`              Draft goals in pd/goals
  \`/$loop\`              Execute goal implementation loop
  \`/$goalcheck\`         Check goal completion status

⚙️ *MACRO EXAMPLES*

*/$goalcheck:*
  \`/add check pd/goals what is the current completion status\`

*/$loop:*
  \`/plan read project prd, pick one or several tasks from goal
  and implement, after that, review your implementation
  if matching the goal, if so update the goal file progress,
  otherwise provide next step. Make sure you remember you
  are not only implementing the goals, but following goals
  and claude.md guidance. The goal can be optimized if you
  facing issue, but dont forget to mention your change in pd/.
  Every service can be auto reload, so dont run node npm
  command unless it is for validate compile or build.
  In the end summarize the current progress of goal
  implementation and major achievements, tell me now
  in which state and which goal, what is the percentage
  of completion, and is any manual step I need to involve.
  Check after the implementation if any issue preventing
  service running and page rendering, in the end tell me
  what is the current pd/goals implement progress in
  a short summary.\`

*/$goal:*
  \`/plan Please consider the following implementation plan,
  review what is needed, and identify any conflicts or
  improvements to the pd/goals stage and goal. Update
  the related goal file or create a new one as necessary.
  Always follow claude.md guidance when preparing the
  goal plan.\`

💡 *TIPS*
  • Use \`@@opus\` or \`@@sonnet\` to select model
  • Combine tasks: \`/yolo implement auth + tests\`
  • Check status: \`ani-code status\`
  • Watch output: \`ani-code watch <id>\`

🔧 *CREATING MACROS*
  *List macros:* \`ani-code workspace macro list\`
  *Create macro:* \`ani-code workspace macro set <name> "<command>"\`
  *Example:* \`ani-code workspace macro set test "/add run tests"\`
  *Use in Telegram:* \`/$test\`
`;

      await this.telegramNotifier.sendMessage(chatId, cheatsheet, { parse_mode: 'Markdown' });
      logger.info(`Displayed cheatsheet to Telegram chat ${chatId}`);

    } catch (error) {
      logger.error(`Error in handleCheatsheetCommand: ${error.message}`, error);
      await this.telegramNotifier.sendMessage(chatId,
        `❌ Failed to display cheatsheet: ${error.message}`
      );
    }
  }

  async showTelegramUnrecognizedCommand(chatId, text, workdirName, attachments = null) {
    const trimmedText = text.trim();

    if (!trimmedText) {
      // Empty message - show status
      await this.showTelegramStatus(chatId);
      return;
    }

    // Generate a unique ID for this prompt to avoid exceeding Telegram's 64-byte callback_data limit
    // Use shorter ID format (timestamp in base36)
    const promptId = Date.now().toString(36);

    // Store the prompt temporarily with optional attachments (clean up after 5 minutes)
    // Store as object to support both text and attachments
    const pendingData = {
      text: trimmedText,
      attachments: attachments && attachments.length > 0 ? attachments : null
    };
    this.pendingPrompts.set(promptId, pendingData);
    setTimeout(() => {
      this.pendingPrompts.delete(promptId);
    }, 5 * 60 * 1000);
    
    let message = `📝 *I received:*\n\`${trimmedText}\`\n\n`;
    message += `💡 *Would you like me to:*\n`;
    message += `• Add this as a new Claude task?\n`;
    message += `• Continue an existing Claude session?\n`;
    message += `• Run this as a shell command?\n\n`;
    message += `*Or you can use these commands:*\n`;
    message += `/add <prompt> - Create a new Claude task\n`;
    message += `/continue <prompt> - Continue Claude session\n`;
    message += `/help - Show all available commands`;
    
    const keyboard = { inline_keyboard: [] };
    
    if (workdirName) {
      // Add task action buttons with prompt ID instead of full text
      // Use shortened keys to stay under 64-byte limit
      keyboard.inline_keyboard.push([
        {
          text: '🤖 Add Task',
          callback_data: JSON.stringify({
            a: 'ct',  // action: create_task
            c: 'a',   // command: add
            p: promptId
          })
        },
        {
          text: '↪️ Continue',
          callback_data: JSON.stringify({
            a: 'ct',  // action: create_task
            c: 'c',   // command: continue
            p: promptId
          })
        }
      ]);
      
      keyboard.inline_keyboard.push([
        {
          text: '⚡ Shell',
          callback_data: JSON.stringify({
            a: 'ct',  // action: create_task
            c: 's',   // command: shell
            p: promptId
          })
        },
        {
          text: '❓ Show Help',
          callback_data: JSON.stringify({
            a: 'help'  // action: show_help
          })
        }
      ]);
    } else {
      message += `\n\n⚠️ *No workspace connected*\nPlease use /connect [token] to connect to a workspace.`;
      
      // Add help button
      keyboard.inline_keyboard.push([{
        text: '❓ Show Help',
        callback_data: JSON.stringify({
          a: 'help'  // action: show_help
        })
      }]);
    }
    
    // Debug: Check callback_data size
    for (const row of keyboard.inline_keyboard) {
      for (const button of row) {
        if (button.callback_data && button.callback_data.length > 64) {
          logger.error(`Callback data too long (${button.callback_data.length} bytes): ${button.callback_data}`);
        }
      }
    }
    
    await this.telegramNotifier.sendMessage(chatId, message, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    });
  }
}

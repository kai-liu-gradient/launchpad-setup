import { basename } from 'path';
import { config } from './config.js';
import { logger } from './logger.js';
import { SecureUploader } from './utils/secure-upload.js';
import { TelegramAPI } from './telegram-api.js';
import { normalizeModelNameLowercase } from './utils/model-normalizer.js';
import { DummyTelegramNotifier } from './dummy-telegram-notifier.js';
import { TelegramNotifierBase, categorizeGitFilesByTaskTiming } from './telegram-notifier-base.js';
import { gatewayPost } from './utils/gateway-request.js';

// Singleton instance
let instance = null;

export class TelegramNotifier extends TelegramNotifierBase {
  constructor() {
    // Implement singleton pattern
    if (instance) {
      return instance;
    }

    // Check if we're in DUMMY mode for gateway-only operation
    const isDummyMode = process.env.ANI_CODE_DUMMY_MODE === 'true' ||
                        process.env.TELEGRAM_BOT_TOKEN === 'DUMMY';

    if (isDummyMode) {
      // Return dummy notifier for gateway-only operation
      logger.info('[TELEGRAM] Using dummy mode for gateway-only operation');
      instance = new DummyTelegramNotifier();
      return instance;
    }

    super(); // Call parent constructor
    this.botToken = config.telegram?.botToken;
    this.defaultChatId = config.telegram?.chatId;
    // Use ani-code workspace chat ID as fallback if no default configured
    if (!this.defaultChatId) {
      this.defaultChatId = '394977994'; // ani-code workspace chat ID (viilachen)
    }

    // Initialize Telegram API client if bot token is available
    if (this.botToken) {
      this.api = new TelegramAPI(this.botToken);
    }

    this.messageCache = new Map(); // For storing message IDs for editing
    this.messageCacheMaxSize = 1000; // Limit to prevent unbounded growth
    this.yoloProtectedChats = new Set(); // Track chats in yolo mode

    // Store singleton instance
    instance = this;
  }

  isEnabled() {
    return !!this.botToken;
  }

  /**
   * Set a value in messageCache with size limit enforcement
   * @param {string} key - Cache key
   * @param {any} value - Value to store
   */
  setMessageCache(key, value) {
    // If cache is at max size, remove oldest entries
    if (this.messageCache.size >= this.messageCacheMaxSize) {
      // Remove oldest 10% of entries
      const toRemove = Math.ceil(this.messageCacheMaxSize * 0.1);
      const keys = Array.from(this.messageCache.keys()).slice(0, toRemove);
      for (const oldKey of keys) {
        this.messageCache.delete(oldKey);
      }
      logger.debug(`[MEMORY] Trimmed ${toRemove} old message cache entries`);
    }
    this.messageCache.set(key, value);
  }

  shortenHostname(hostname) {
    // If hostname has more than 2 parts separated by -, shorten it
    // Example: abc-def-g123 becomes ad-g123
    const parts = hostname.split('-');
    if (parts.length > 2) {
      // Take first letter of each part except the last
      const shortened = parts.slice(0, -1).map(p => p[0]).join('') + '-' + parts[parts.length - 1];
      return shortened;
    }
    return hostname;
  }

  // Override parent's formatFooter with more advanced logic
  async formatFooter(workdir, options = {}) {
    // Validate workdir parameter
    if (!workdir || workdir === 'undefined' || workdir === 'null' || workdir === 'NaN') {
      logger.warn(`[FOOTER] Invalid workdir: ${workdir}. Using fallback.`);
      workdir = 'workspace';
    }

    const time = new Date().toLocaleTimeString('en-GB', {
      hour12: false,
      timeZone: config.timezone,
      hour: '2-digit',
      minute: '2-digit'
    });
    const hostname = this.shortenHostname(config.lark.hostname); // Use shortened hostname

    // Get provider - use provided taskProviderId if available, otherwise get current
    let provider = '';
    if (!options.hideProvider) {
      if (options.taskProviderId) {
        // Use the provider ID from the task
        provider = options.taskProviderId;
        logger.debug(`[FOOTER] Using task provider: ${provider}`);
      } else {
        // Fall back to current provider
        provider = 'claude'; // default
        logger.debug(`[FOOTER] No taskProviderId provided, falling back to current provider`);
        try {
          const { getProviderManager } = await import('./providers/providerManager.js');
          const providerManager = await getProviderManager();
          const currentHandler = providerManager.getCurrentHandler();
          if (currentHandler) {
            provider = currentHandler.id;
            logger.debug(`[FOOTER] Current provider from manager: ${provider}`);
          } else {
            logger.debug(`[FOOTER] No current handler, using default: ${provider}`);
          }
        } catch (error) {
          logger.debug(`[FOOTER] Could not get provider: ${error.message}`);
        }
      }
    } else {
      logger.debug(`[FOOTER] Provider display hidden by options.hideProvider`);
    }

    // Build footer - only include provider if not hidden
    const parts = [`🖥 ${hostname}`, `⏰ ${time}`, `📁 ${workdir}`];
    if (provider) {
      parts.push(`🤖 ${provider}`);
    }

    return `\n${parts.join(' • ')}`;
  }

  isTemplateStylePrompt(command) {
    // Same logic as Lark for detecting template-style prompts
    const indicators = [
      /^You are a .+\./,
      /IMPORTANT:/,
      /Requirements:/,
      /Your response should/,
      /-.*\n.*-.*\n.*-/,
    ];
    
    const lines = command.split('\n');
    const hasMultipleInstructions = lines.length > 10 && 
      (command.includes('Requirements:') || command.includes('IMPORTANT:'));
    
    return indicators.some(pattern => pattern.test(command)) || hasMultipleInstructions;
  }

  getSimplifiedPromptDescription(command, taskName) {
    // Reuse same logic from Lark
    if (command.includes('git commit message') || taskName.includes('commit-msg')) {
      return '🔄 Generating commit message based on staged changes';
    }
    
    if (command.includes('git changes') || command.includes('git summary') || taskName.includes('git-summary')) {
      return '📊 Creating git repository summary';
    }
    
    if (command.includes('code review') || command.includes('analyze')) {
      return '🔍 Analyzing code and providing review';
    }
    
    if (command.includes('documentation') || command.includes('README')) {
      return '📝 Generating documentation';
    }
    
    if (this.isTemplateStylePrompt(command)) {
      const firstLine = command.split('\n')[0];
      if (firstLine.startsWith('You are a ')) {
        const role = firstLine.match(/You are a (.+?)\./)?.[1] || 'specialized assistant';
        return `🤖 Acting as ${role}`;
      }
    }
    
    const firstLine = command.split('\n')[0];
    return firstLine.length > 80 ? firstLine.substring(0, 77) + '...' : firstLine;
  }

  escapeMarkdown(text) {
    // Escape special characters for Telegram Markdown v1
    // In Markdown v1, we need to escape: * _ [ ] ( ) ~ ` > # + - = | { } . !
    // But we want to preserve actual markdown formatting, so we'll be selective
    // Escape brackets and backticks that could break parsing
    return text
      .replace(/\\/g, '\\\\')  // Escape backslashes first
      .replace(/\[/g, '\\[')    // Escape opening brackets
      .replace(/\]/g, '\\]')    // Escape closing brackets
      .replace(/`/g, '\\`');    // Escape backticks
  }
  
  // Override parent's escapeMarkdownContent with more aggressive escaping
  escapeMarkdownContent(text) {
    // More aggressive escaping for content that shouldn't have any formatting
    // This is for user-provided content like commands and prompts
    if (!text) return '';

    // Convert text to string if it's not already (handle objects/arrays)
    const str = typeof text === 'string' ? text : String(text);

    return str
      .replace(/\\/g, '\\\\')  // Escape backslashes first
      .replace(/\*/g, '\\*')    // Escape asterisks
      .replace(/_/g, '\\_')     // Escape underscores
      .replace(/\[/g, '\\[')    // Escape opening brackets
      .replace(/\]/g, '\\]')    // Escape closing brackets
      .replace(/`/g, '\\`')     // Escape backticks
      .replace(/\(/g, '\\(')    // Escape opening parentheses
      .replace(/\)/g, '\\)');   // Escape closing parentheses
  }

  formatMarkdown(text) {
    // Convert basic markdown to Telegram's MarkdownV2 format
    // Bold: **text** -> *text*
    text = text.replace(/\*\*(.+?)\*\*/g, '*$1*');
    
    // Code blocks: ```code``` -> `code`
    text = text.replace(/```([^`]+)```/g, '`$1`');
    
    // Inline code: `code` stays the same
    
    return text;
  }

  sanitizeMessageForTelegram(message) {
    // Additional sanitization for complex messages that may contain JSON or code
    // This is used specifically for task completion messages that may have problematic content

    if (!message) return '';

    // Convert to string if not already
    let text = typeof message === 'string' ? message : String(message);

    // First, ensure no nested code blocks by replacing triple backticks in code blocks
    text = text.replace(/```[\s\S]*?```/g, (match) => {
      // Remove any triple backticks inside code blocks
      const content = match.slice(3, -3); // Remove opening and closing ```
      const cleanedContent = content.replace(/```/g, '   ');
      return '```' + cleanedContent + '```';
    });

    // Remove any remaining unescaped backticks outside of code blocks
    // But preserve inline code (paired backticks like `code`)
    let inCodeBlock = false;
    const lines = text.split('\n');
    const sanitizedLines = lines.map(line => {
      if (line.startsWith('```')) {
        inCodeBlock = !inCodeBlock;
        return line;
      }

      if (!inCodeBlock) {
        // Remove control characters that might break Telegram
        let sanitizedLine = line.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, '');

        // Don't escape backticks - they're used for inline code formatting
        // Telegram's Markdown parser handles inline code with single backticks
        // Only escape truly problematic unpaired backticks
        const backtickCount = (sanitizedLine.match(/(?<!\\)`/g) || []).length;
        if (backtickCount % 2 !== 0) {
          // Odd number of backticks - there's an unpaired one, escape them all
          sanitizedLine = sanitizedLine.replace(/(?<!\\)`/g, '\\`');
        }
        // If even number, leave them as-is for inline code formatting

        return sanitizedLine;
      }

      return line;
    });

    // Join and ensure message length is within Telegram limits
    let result = sanitizedLines.join('\n');

    // Final safety check: ensure we don't have unmatched code blocks
    const codeBlockCount = (result.match(/```/g) || []).length;
    if (codeBlockCount % 2 !== 0) {
      // Unmatched code block - add closing
      result += '\n```';
      logger.warn('[TELEGRAM] Fixed unmatched code block in message');
    }

    return result;
  }

  async sendTaskUpdate(task, status, chatId = null, displayMode = 'full') {
    const targetChatId = chatId || task.chatId || this.defaultChatId;
    if (!targetChatId) {
      logger.warn('No chat ID available for Telegram notification');
      return;
    }

    // Always skip task started/progress updates during YOLO (even for YOLO tasks)
    const { shouldBlockTaskNotification } = await import('./utils/workspace-utils.js');
    if (await shouldBlockTaskNotification(task)) {
      logger.info(`[TELEGRAM] sendTaskUpdate blocked for task ${task.id} — workspace YOLO protection active (status=${status}, displayMode=${displayMode})`);
      return; // Skip during YOLO mode — returns undefined, caller will see no message_id
    }

    // Legacy chat-based protection check (kept for compatibility)
    const plainChatId = targetChatId.startsWith('telegram:')
      ? targetChatId.substring('telegram:'.length)
      : targetChatId;

    if (this.isYoloProtected(plainChatId)) {
      logger.info(`[TELEGRAM] sendTaskUpdate blocked for task ${task.id} — legacy YOLO chat protection active (chatId=${plainChatId})`);
      return; // Skip — returns undefined
    }

    // Use simple format if display mode is 'simple'
    const message = displayMode === 'simple'
      ? this.formatSimpleTaskUpdateMessage(task, status)
      : await this.formatTaskUpdateMessage(task, status);

    const keyboard = displayMode === 'simple' ? null : this.getTaskUpdateKeyboard(task, status);

    return this.sendMessage(targetChatId, message, {
      reply_markup: keyboard,
      parse_mode: 'Markdown'
    });
  }

  async sendTaskSummary(task, result, taskUsage = null, usageReporter = null, chatId = null, messageId = null, pendingCount = 0, displayMode = 'full') {
    const targetChatId = chatId || task.chatId || this.defaultChatId;
    if (!targetChatId) {
      logger.warn('No chat ID available for Telegram notification');
      return;
    }

    // IMPORTANT: Task completion messages should ALWAYS be sent
    // The YOLO protection should only block task START/PROGRESS notifications
    // to avoid cluttering the chat during YOLO execution.
    // Task completion messages are important for users to know when tasks finish.

    try {
      // Use simple format if display mode is 'simple'
      let message = displayMode === 'simple'
        ? await this.formatSimpleTaskSummaryMessage(task, result, taskUsage, usageReporter, pendingCount)
        : await this.formatTaskSummaryMessage(task, result, taskUsage, usageReporter, pendingCount);

      // Sanitize the message to prevent Telegram API errors
      message = this.sanitizeMessageForTelegram(message);

      // Log message content for debugging if it's a completion
      if (result === 'success' || result === 'error') {
        logger.debug(`[TELEGRAM] Task ${result} message length: ${message.length} chars`);
        if (message.length > 4000) {
          logger.warn(`[TELEGRAM] Task message exceeds 4000 chars (${message.length}), will be truncated`);
        }
      }

      // Get keyboard for task summary
      const keyboard = await this.getTaskSummaryKeyboard(task, result);

      // If messageId is provided, handle based on display mode
      if (messageId) {
        if (displayMode === 'simple') {
          // Simple mode: delete old progress message and send a NEW completion message
          // This ensures the user gets a fresh notification at the bottom of the chat
          try {
            await this.deleteMessage(targetChatId, messageId);
            logger.info(`[TELEGRAM] Deleted progress message ${messageId} for simple mode completion of task ${task.id}`);
          } catch (error) {
            logger.warn(`[TELEGRAM] Failed to delete progress message ${messageId}: ${error.message}`);
          }
          // Fall through to send new message below
        } else {
          // Full mode: edit the existing message in place
          try {
            const editResult = await this.editMessage(
              targetChatId,
              messageId,
              message,  // Already sanitized above
              {
                parse_mode: 'Markdown',
                reply_markup: keyboard
              }
            );

            if (editResult.ok || editResult.success) {
              logger.info(`[TELEGRAM] Updated existing message ${messageId} with task summary for task ${task.id}`);
              return editResult;
            } else {
              logger.warn(`[TELEGRAM] Failed to update message ${messageId}: ${editResult.description}, sending new message instead`);
            }
          } catch (error) {
            logger.warn(`[TELEGRAM] Error updating message ${messageId}: ${error.message}, sending new message instead`);
          }
        }
      }

      // Send as new message if no messageId or update failed
      return this.sendMessage(targetChatId, message, {
        reply_markup: keyboard,
        parse_mode: 'Markdown'
      });
    } catch (error) {
      // Log the full error with context
      logger.error(`[TELEGRAM] Failed to send task completion message for task ${task.id}:`, {
        error: error.message,
        stack: error.stack,
        taskId: task.id,
        taskName: task.name,
        result: result,
        chatId: targetChatId,
        messageId: messageId
      });

      // Try to send a fallback plain text message
      try {
        const fallbackMessage = `Task ${result}: ${task.name || task.id}\n\n` +
          `[Error sending formatted message: ${error.message}]\n\n` +
          `Check logs for details.`;

        logger.info(`[TELEGRAM] Attempting to send fallback message for task ${task.id}`);

        return await this.sendMessage(targetChatId, fallbackMessage, {
          parse_mode: undefined // Send as plain text
        });
      } catch (fallbackError) {
        logger.error(`[TELEGRAM] Even fallback message failed for task ${task.id}:`, {
          error: fallbackError.message,
          taskId: task.id,
          chatId: targetChatId
        });
      }

      throw error;
    }
  }

  async formatTaskUpdateMessage(task, status) {
    let emoji, title;
    const escapedName = this.escapeMarkdownContent(task.name || 'Unknown Task');
    if (status === 'started') {
      emoji = '🚀';
      title = `Task Started - ${escapedName}`;
    } else if (status === 'queued') {
      emoji = '⏳';
      title = `Task Queued - ${escapedName}`;
    } else {
      emoji = '📝';
      title = `Task ${status} - ${escapedName}`;
    }

    const workdir = task.cwd ? basename(task.cwd) : 'unknown';

    const attachmentIndicator = this.taskHasAttachments(task) ? ' 📃' : '';
    let message = `${emoji} *${title}*${attachmentIndicator}\n\n`;
    // Escape underscores in task ID to prevent Telegram markdown interpretation
    const escapedTaskId = task.id.replace(/_/g, '\\_');
    message += `*Task ID:* \`${escapedTaskId}\`\n`;

    if (task.pid && status === 'started') {
      message += `*PID:* ${task.pid}\n`;
    }

    // Add prompt section with truncation for long prompts
    const firstLine = task.command.split('\n')[0] || task.command;
    const truncatedPrompt = firstLine.length > 120 ? firstLine.substring(0, 117) + '...' : firstLine;
    message += `*Prompt:* ${truncatedPrompt}`;

    logger.debug(`[FOOTER] Task update - task ${task.id} providerId: ${task.providerId || 'NOT SET'}, source: ${task.source || 'unknown'}`);
    message += await this.formatFooter(workdir, { taskProviderId: task.providerId });

    return message;
  }

  async formatTaskSummaryMessage(task, result, taskUsage = null, usageReporter = null, pendingCount = 0) {
    const duration = task.completedAt - task.startedAt;
    const durationMs = duration;
    const seconds = Math.floor(durationMs / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    
    let durationFormatted;
    if (hours > 0) {
      durationFormatted = `${hours}h ${minutes % 60}m ${seconds % 60}s`;
    } else if (minutes > 0) {
      durationFormatted = `${minutes}m ${seconds % 60}s`;
    } else {
      durationFormatted = `${seconds}s`;
    }
    
    const isShellCommand = task.command && task.command.startsWith('shell:');
    const cleanCommand = isShellCommand ? task.command.substring(6).trim() : task.command;
    
    const workdir = task.cwd ? basename(task.cwd) : 'unknown';
    
    let emoji, title;
    const escapedName = this.escapeMarkdownContent(task.name || 'Unknown Task');
    if (result === 'success') {
      emoji = '✅';
      title = `Task Completed - ${escapedName}`;
      // Add pending count to title if there are pending tasks
      if (pendingCount > 0) {
        title += ` (${pendingCount} pending)`;
      }
    } else if (result === 'cancelled') {
      emoji = '⏹';
      title = `Task Cancelled - ${escapedName}`;
      // Add pending count to title if there are pending tasks
      if (pendingCount > 0) {
        title += ` (${pendingCount} pending)`;
      }
    } else {
      emoji = '❌';
      title = `Task Failed - ${escapedName}`;
      // Add pending count to title if there are pending tasks
      if (pendingCount > 0) {
        title += ` (${pendingCount} pending)`;
      }
    }
    
    let message = `${emoji} *${title}* (${durationFormatted})\n\n`;
    // Escape underscores in task ID to prevent Telegram markdown interpretation
    const escapedTaskId = task.id.replace(/_/g, '\\_');
    message += `*Task ID:* \`${escapedTaskId}\`\n`;
    
    // Add truncated prompt (same logic as task progress message)
    if (task.command) {
      const firstLine = task.command.split('\n')[0] || task.command;
      const truncatedPrompt = firstLine.length > 120 ? firstLine.substring(0, 117) + '...' : firstLine;
      message += `*Prompt:* ${truncatedPrompt}\n`;
    }
    
    if (task.exitCode !== null && task.exitCode !== 0) {
      message += `*Exit Code:* ${task.exitCode}\n`;
    }
    
    // Add output if available
    if (task.output && task.output.trim()) {
      const allLines = task.output.trim().split('\n');
      const totalLines = allLines.length;

      // If output is 3 lines or less, show inline without "Output:" label
      if (totalLines <= 3) {
        message += '\n' + this.escapeMarkdownContent(task.output.trim()) + '\n';
      } else {
        // For longer output, use sanitized code block
        // Increased threshold from 20 to 50 lines to show more complete output
        if (totalLines <= 50) {
          // Show full output for up to 50 lines
          message += '\n' + this.wrapInCodeBlock(task.output.trim());
        } else {
          // For very long output, show first 12 lines and last 30 lines (total 42 visible)
          const firstLines = allLines.slice(0, 12).join('\n').trim();
          const lastLines = allLines.slice(-30).join('\n').trim();
          const hiddenCount = totalLines - 42;

          // Only truncate if hiding a significant amount (more than 30 lines)
          if (hiddenCount < 30) {
            message += '\n' + this.wrapInCodeBlock(task.output.trim());
          } else {
            const truncatedOutput = `${firstLines}\n\n... ${hiddenCount} lines hidden ...\n\n${lastLines}`;
            message += '\n' + this.wrapInCodeBlock(truncatedOutput);
          }
        }
      }
    }

    // Add error if present
    if ((result === 'error' || result === 'cancelled') && task.error) {
      const escapedError = this.escapeMarkdownContent(task.error);
      message += `\n💬 ${escapedError}\n`;
    }
    
    // Add git status for the task's working directory
    if (task.cwd) {
      try {
        const { execSync } = await import('child_process');
        
        // Get current branch
        const branch = execSync('git branch --show-current', { 
          cwd: task.cwd, 
          encoding: 'utf8',
          timeout: 5000
        }).trim();
        // Only show branch if it's not main or master
        if (branch && branch !== 'main' && branch !== 'master') {
          message += `\n*🌿 Branch:* \`${branch}\``;
        }
        
        // Get dirty files
        const statusOutput = execSync('git status --porcelain', { 
          cwd: task.cwd, 
          encoding: 'utf8',
          timeout: 5000
        }).trim();
        
        if (statusOutput) {
          const { duringTask, beforeTask } = categorizeGitFilesByTaskTiming(statusOutput, task.cwd, task.startedAt);

          // Get git diff stats
          let diffStatsText = '';
          try {
            const diffStatsOutput = execSync('git diff --shortstat', {
              cwd: task.cwd,
              encoding: 'utf8',
              timeout: 5000
            }).trim();

            if (diffStatsOutput) {
              const insertions = diffStatsOutput.match(/(\d+) insertion/)?.[1] || 0;
              const deletions = diffStatsOutput.match(/(\d+) deletion/)?.[1] || 0;
              if (parseInt(insertions) > 0 || parseInt(deletions) > 0) {
                diffStatsText = `: +${insertions}/-${deletions}`;
              }
            }
          } catch (error) {
            // Ignore diff stats errors
          }

          if (duringTask.length > 0) {
            message += `\n*📂 Changed* (${duringTask.length} file${duringTask.length === 1 ? '' : 's'}${diffStatsText}):\n\`\`\`\n${duringTask.slice(0, 10).join('\n')}${duringTask.length > 10 ? `\n... and ${duringTask.length - 10} more` : ''}\n\`\`\``;
          }
          if (beforeTask.length > 0) {
            message += `\n*📁 Uncommitted before task* (${beforeTask.length} file${beforeTask.length === 1 ? '' : 's'}):\n\`\`\`\n${beforeTask.slice(0, 5).join('\n')}${beforeTask.length > 5 ? `\n... and ${beforeTask.length - 5} more` : ''}\n\`\`\``;
          }
          if (duringTask.length === 0 && beforeTask.length === 0) {
            message += `\n*📂 Git Status:* Clean`;
          }
        } else {
          message += `\n*📂 Git Status:* Clean`;
        }
      } catch (error) {
        // Not a git repo or error getting status - silently skip
      }
    }
    
    // Add cost/token info if available
    const costTokenLine = await this.buildCostTokenLine(taskUsage, usageReporter, task.id);
    if (costTokenLine) {
      message += `\n${costTokenLine}\n`;
    }

    // Pass task provider ID to footer so it shows the correct provider
    logger.debug(`[FOOTER] Task ${task.id} providerId: ${task.providerId || 'NOT SET'}, source: ${task.source || 'unknown'}`);
    message += await this.formatFooter(workdir, { taskProviderId: task.providerId });

    return message;
  }

  async buildCostTokenLine(taskUsage, usageReporter, taskId = null, { simple = false } = {}) {
    if (!taskUsage || (taskUsage.cost <= 0 && taskUsage.tokens <= 0)) {
      return '';
    }
    
    const formatTokens = (tokens) => {
      if (tokens >= 1000000) {
        return `${(tokens / 1000000).toFixed(1)}m`;
      } else if (tokens >= 1000) {
        return `${(tokens / 1000).toFixed(1)}k`;
      }
      return tokens.toLocaleString();
    };

    // Helper function to format model names for display
    const formatModelName = (modelName) => {
      return normalizeModelNameLowercase(modelName);
    };
    
    const inputTotal = (taskUsage.inputTokens || 0);
    const cachedInput = (taskUsage.cacheReadTokens || 0);
    const outputTotal = (taskUsage.outputTokens || 0);
    
    const tokenParts = [];
    
    if (taskUsage.tokens > 0 && inputTotal === 0 && outputTotal === 0) {
      tokenParts.push(`Total: ${formatTokens(taskUsage.tokens)}`);
    } else {
      if (inputTotal > 0) {
        tokenParts.push(`In: ${formatTokens(inputTotal)}${cachedInput > 0 ? ` (${formatTokens(cachedInput)} cached)` : ''}`);
      }
      if (outputTotal > 0) {
        tokenParts.push(`Out: ${formatTokens(outputTotal)}`);
      }
    }

    // Build model information
    let modelInfo = '';
    if (taskUsage.modelBreakdowns && taskUsage.modelBreakdowns.length > 0) {
      // Sort models by cost (highest first) to show the primary model first
      const sortedModels = taskUsage.modelBreakdowns.sort((a, b) => b.cost - a.cost);
      const modelNames = sortedModels.map(model => formatModelName(model.modelName));
      modelInfo = ` (${modelNames.join(', ')})`;
    } else if (taskUsage.modelsUsed && taskUsage.modelsUsed.length > 0) {
      // Fallback to modelsUsed if modelBreakdowns not available
      const modelNames = taskUsage.modelsUsed.map(model => formatModelName(model));
      modelInfo = ` (${modelNames.join(', ')})`;
    }
    
    const tokensText = tokenParts.length > 0 ? tokenParts.join(' • ') : '';

    if (taskUsage.cost > 0) {
      let costTokenLine = `💰 $${taskUsage.cost.toFixed(4)}${modelInfo}`;
      if (tokensText && !simple) {
        costTokenLine += ` • ${tokensText}`;
      }
      return costTokenLine;
    }

    if (tokensText && !simple) {
      return `🧮 ${tokensText}${modelInfo}`;
    }

    return modelInfo.trim() ? `🤖${modelInfo}` : '';
  }

  getTaskUpdateKeyboard(task, status) {
    const keyboard = { inline_keyboard: [] };
    
    if (status === 'started' || status === 'queued') {
      const buttonText = status === 'queued' ? '🚫 Cancel Queued Task' : '⏹ Cancel Task';
      // Shorten task ID to fit within Telegram's 64-byte callback_data limit
      const shortTaskId = task.id.split('-').slice(-2).join('-'); // Takes last 2 parts
      
      const buttons = [
        {
          text: buttonText,
          callback_data: JSON.stringify({
            a: 'cancel',
            t: shortTaskId
          })
        }
      ];
      
      // Add watch progress button for started tasks
      if (status === 'started') {
        buttons.push({
          text: '👀 Watch',
          callback_data: `/process ${task.id}`  // Use full task ID with /process format
        });
      }
      
      keyboard.inline_keyboard.push(buttons);
    }
    
    return keyboard;
  }

  async getTaskSummaryKeyboard(task, result) {
    const keyboard = { inline_keyboard: [] };

    if (result === 'success') {
      const buttons = [];

      // Add History button for this specific task process
      if (task.id && task.startedAt) {
        const endTime = task.completedAt || Date.now();
        // Convert milliseconds to seconds to reduce callback_data size (64-byte limit)
        const startSec = Math.floor(task.startedAt / 1000);
        const endSec = Math.floor(endTime / 1000);
        const callbackData = JSON.stringify({
          a: 'history',
          s: startSec,
          e: endSec
        });
        logger.debug(`[BUTTON] History button callback_data: ${callbackData} (${callbackData.length} bytes)`);

        // Telegram has 64-byte limit on callback_data
        if (callbackData.length > 64) {
          logger.warn(`[BUTTON] History button callback_data exceeds 64 bytes (${callbackData.length}), skipping button`);
        } else {
          buttons.push({
            text: '📜 History',
            callback_data: callbackData
          });
        }
      }

      // Add commit button for successful tasks, but only if git is dirty and task name doesn't contain "commit"
      if (!task.name?.toLowerCase().includes('commit') && task.cwd) {
        try {
          const { execSync } = await import('child_process');
          const statusOutput = execSync('git status --porcelain', {
            cwd: task.cwd,
            encoding: 'utf8',
            timeout: 5000
          }).trim();

          if (statusOutput) {
            const callbackData = JSON.stringify({
              a: 'run_task',
              c: 'ani-code commit -y'
            });
            logger.info(`[BUTTON] Adding commit button for task ${task.id} (dirty: ${statusOutput.split('\n').length} files, cwd: ${task.cwd})`);

            if (callbackData.length > 64) {
              logger.warn(`[BUTTON] Commit button callback_data exceeds 64 bytes (${callbackData.length}), skipping button`);
            } else {
              buttons.push({
                text: '💾 Commit',
                callback_data: callbackData
              });
            }
          } else {
            logger.info(`[BUTTON] Git is clean, skipping commit button for task ${task.id}`);
          }
        } catch (error) {
          logger.info(`[BUTTON] Failed to check git status for commit button (cwd: ${task.cwd}): ${error.message}`);
        }
      } else {
        logger.info(`[BUTTON] Skipping commit button - name contains commit: ${task.name?.toLowerCase().includes('commit')}, cwd: ${!!task.cwd}`);
      }

      // Try to get workspace settings for homepage button
      try {
        if (task.cwd) {
          const { WorkspaceManager } = await import('./workspace-manager.js');
          const manager = new WorkspaceManager();
          await manager.initialize();
          const workspace = await manager.getWorkspaceByPath(task.cwd);

          if (workspace && workspace.settings && workspace.settings.homepage) {
            // Validate that homepage is a valid URL
            try {
              const homepageUrl = new URL(workspace.settings.homepage);
              // Only add button if it's a valid http/https URL
              if (homepageUrl.protocol === 'http:' || homepageUrl.protocol === 'https:') {
                buttons.push({
                  text: '🌐 Open',
                  url: workspace.settings.homepage
                });
                logger.debug(`[BUTTON] Added homepage button with URL: ${workspace.settings.homepage}`);
              } else {
                logger.debug(`Homepage URL has invalid protocol: ${homepageUrl.protocol}`);
              }
            } catch (urlError) {
              logger.debug(`Invalid homepage URL: ${workspace.settings.homepage}`);
            }
          }

          await manager.close();
        }
      } catch (error) {
        logger.debug(`Failed to get workspace settings for homepage button: ${error.message}`);
      }

      // Log total buttons and validate
      logger.info(`[BUTTON] Task ${task.id} keyboard has ${buttons.length} buttons: ${buttons.map(b => b.text).join(', ')}`);
      buttons.forEach((btn, idx) => {
        if (btn.callback_data) {
          logger.debug(`[BUTTON] Button ${idx}: ${btn.text} - callback_data length: ${btn.callback_data.length}`);
        }
      });

      keyboard.inline_keyboard.push(buttons);
    }

    return keyboard;
  }

  async sendViaGateway(platform, chatId, text, options = {}) {
    const payload = {
      platform,
      chatId,
      message: {
        text,
        ...options
      },
      instanceId: config.gateway.instanceId,
      timestamp: new Date().toISOString()
    };

    logger.debug(`[Gateway] Sending message to ${chatId} (${text?.length || 0} chars)`);

    try {
      const response = await gatewayPost(
        `${config.gateway.url}/api/callback/message`,
        payload,
        {
          instanceId: config.gateway.instanceId,
          token: config.gateway.token
        },
        {
          timeout: 10000
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        logger.error(`[Gateway] Callback failed with HTTP ${response.status}`, {
          status: response.status,
          statusText: response.statusText,
          errorText: errorText.substring(0, 500),
          chatId,
          platform
        });
        throw new Error(`Gateway callback failed: ${response.status} - ${errorText}`);
      }

      const result = await response.json();
      logger.info(`[Gateway] ✓ Sent to ${chatId}`);

      // Normalize gateway response to match direct Telegram API format
      // Gateway: { success, platform_response: { ok, result: { message_id } }, message_id }
      // Telegram: { ok, result: { message_id } }
      if (result.platform_response) {
        return result.platform_response;
      }
      return {
        ok: !!result.success,
        result: result.message_id ? { message_id: result.message_id } : undefined
      };
    } catch (error) {
      logger.error(`[Gateway] ✗ Gateway callback error:`, {
        error: error.message,
        errorCode: error.code,
        platform,
        chatId,
        gatewayUrl: config.gateway.url,
        stack: error.stack?.substring(0, 500)
      });

      // Fallback to direct send on gateway failure
      if (platform === 'telegram') {
        logger.warn(`[Gateway] ⚠️  Falling back to direct telegram send for chat ${chatId}`);
        
        if (this.api) {
          return this.api.sendMessage(chatId, text, options);
        } else {
          logger.warn(`[Gateway] ⚠️  Cannot fallback to direct telegram send: No bot token configured`);
          // Return a dummy success response to prevent crashing the caller, but indicate failure
          return { 
            ok: false, 
            description: 'Gateway failed and no direct fallback available (bot token missing)',
            error_code: 503
          };
        }
      }

      throw error;
    }
  }

  async editViaGateway(platform, chatId, messageId, text, options = {}) {
    const payload = {
      platform,
      chatId,
      message: {
        type: 'edit',
        content: text,
        options: {
          messageId,
          ...options
        }
      },
      instanceId: config.gateway.instanceId,
      timestamp: new Date().toISOString()
    };

    logger.debug(`[Gateway] Editing message ${messageId} in ${chatId}`);

    try {
      const response = await gatewayPost(
        `${config.gateway.url}/api/callback/message`,
        payload,
        {
          instanceId: config.gateway.instanceId,
          token: config.gateway.token
        },
        {
          timeout: 10000
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        logger.error(`[Gateway] Edit callback failed with HTTP ${response.status}`, {
          status: response.status,
          statusText: response.statusText,
          errorText: errorText.substring(0, 500),
          chatId,
          messageId,
          platform
        });
        throw new Error(`Gateway edit callback failed: ${response.status} - ${errorText}`);
      }

      const result = await response.json();

      logger.info(`[Gateway] ✓ Edited ${messageId} in ${chatId}`);

      // Normalize gateway response to Telegram API format: { ok, result: { message_id } }
      if (result.platform_response) {
        return result.platform_response;
      }
      return {
        ok: !!result.success,
        result: result.message_id ? { message_id: result.message_id } : undefined
      };
    } catch (error) {
      logger.error(`[Gateway] ✗ Gateway edit callback error:`, {
        error: error.message,
        errorCode: error.code,
        platform,
        chatId,
        messageId,
        gatewayUrl: config.gateway.url,
        stack: error.stack?.substring(0, 500)
      });

      // Fallback to direct edit on gateway failure if bot token available
      if (platform === 'telegram' && this.api) {
        logger.warn(`[Gateway] ⚠️  Falling back to direct telegram edit for chat ${chatId}`);
        return this.api.editMessageText(chatId, messageId, undefined, text, options);
      }

      // Return dummy success response to prevent crashing the caller
      logger.warn(`[Gateway] ⚠️  Returning dummy response despite gateway edit error`);
      return {
        ok: true,
        result: {
          message_id: messageId,
          chat: { id: chatId },
          date: Date.now() / 1000,
          text: text
        }
      };
    }
  }

  async sendMessage(chatId, text, options = {}) {
    // Route through gateway if in gateway mode
    if (config.gateway.enabled) {
      return this.sendViaGateway('telegram', chatId, text, options);
    }

    if (!this.isEnabled()) {
      logger.warn('Telegram bot token not configured');
      return;
    }

    // Telegram has a 4096 character limit for messages
    const TELEGRAM_MESSAGE_LIMIT = 4000; // Leave some buffer for markdown parsing
    let messageText = text;
    if (text.length > TELEGRAM_MESSAGE_LIMIT) {
      // Truncate the message and add a note
      messageText = text.substring(0, TELEGRAM_MESSAGE_LIMIT - 50) + '\n\n...[Message truncated due to length]';
      logger.warn(`Message truncated from ${text.length} to ${messageText.length} characters for Telegram chat ${chatId}`);
    }

    // Try to get workspace name for this chat if not provided
    let workspaceName = options.workspaceName;
    if (!workspaceName) {
      try {
        const { WorkspaceManager } = await import('./workspace-manager.js');
        const manager = new WorkspaceManager();
        await manager.initialize();
        const workspace = await manager.getWorkspaceForTelegramChat(chatId);
        if (workspace) {
          workspaceName = workspace.name;
        }
        await manager.close();
      } catch (error) {
        logger.debug(`Could not get workspace name for chat ${chatId}: ${error.message}`);
      }
    }

    try {
      // Use the new API helper with retry logic and comprehensive logging
      const result = await this.api.sendMessage(chatId, messageText, { ...options, workspaceName });

      // Store message ID for potential editing later
      if (result.result?.message_id) {
        this.setMessageCache(`${chatId}:latest`, result.result.message_id);
      }

      return result;
    } catch (error) {
      // Check if error is due to markdown parsing
      if (error.response?.data?.description?.includes('Can\'t parse entities') ||
          error.response?.data?.description?.includes('Bad Request: can\'t parse entities')) {
        logger.error('Telegram markdown parsing error - attempting plain text:', {
          chatId,
          error: error.response?.data?.description,
          messagePreview: messageText.substring(0, 200)
        });

        // Log the problematic message content for debugging
        if (messageText.length <= 1000) {
          logger.debug('[TELEGRAM] Full message that failed:', messageText);
        } else {
          logger.debug('[TELEGRAM] Message excerpt that failed:', messageText.substring(0, 500));
        }

        // Try sending as plain text
        try {
          const plainOptions = { ...options, parse_mode: undefined };
          const plainResult = await this.api.sendMessage(chatId, messageText, {
            ...plainOptions,
            workspaceName
          });

          logger.info('[TELEGRAM] Successfully sent as plain text after markdown error');

          if (plainResult.result?.message_id) {
            this.setMessageCache(`${chatId}:latest`, plainResult.result.message_id);
          }

          return plainResult;
        } catch (plainError) {
          logger.error('Failed to send even as plain text:', {
            chatId,
            error: plainError.message
          });
          throw plainError;
        }
      }

      logger.error('Failed to send Telegram message:', {
        chatId,
        error: error.message,
        errorCode: error.response?.data?.error_code,
        description: error.response?.data?.description
      });
      throw error;
    }
  }

  async editMessage(chatId, messageId, text, options = {}) {
    // Validate messageId is provided
    if (!messageId) {
      logger.error('editMessage called without messageId', {
        chatId,
        textPreview: text?.substring(0, 100),
        stack: new Error().stack
      });
      return { success: false, error: 'messageId is required for edit operations' };
    }

    // Route through gateway if in gateway mode
    if (config.gateway.enabled) {
      return this.editViaGateway('telegram', chatId, messageId, text, options);
    }

    if (!this.isEnabled()) {
      logger.warn('Telegram bot token not configured');
      return;
    }

    // Try to get workspace name for this chat if not provided
    let workspaceName = options.workspaceName;
    if (!workspaceName) {
      try {
        const { WorkspaceManager } = await import('./workspace-manager.js');
        const manager = new WorkspaceManager();
        await manager.initialize();
        const workspace = await manager.getWorkspaceForTelegramChat(chatId);
        if (workspace) {
          workspaceName = workspace.name;
        }
        await manager.close();
      } catch (error) {
        logger.debug(`Could not get workspace name for chat ${chatId}: ${error.message}`);
      }
    }

    try {
      // Sanitize the message to prevent Telegram API errors
      const sanitizedText = this.sanitizeMessageForTelegram(text);

      // Use the new API helper with retry logic and comprehensive logging
      const result = await this.api.editMessageText(chatId, messageId, sanitizedText, { ...options, workspaceName });
      return result;
    } catch (error) {
      // Check if error is due to markdown parsing
      if (error.response?.data?.description?.includes('Can\'t parse entities') ||
          error.response?.data?.description?.includes('Bad Request: can\'t parse entities')) {
        logger.error('Telegram markdown parsing error in edit - attempting plain text:', {
          chatId,
          messageId,
          error: error.response?.data?.description,
          messagePreview: text.substring(0, 200)
        });

        // Log the problematic message content for debugging
        if (text.length <= 1000) {
          logger.debug('[TELEGRAM] Full edit message that failed:', text);
        } else {
          logger.debug('[TELEGRAM] Edit message excerpt that failed:', text.substring(0, 500));
        }

        // Try editing as plain text
        try {
          const plainOptions = { ...options, parse_mode: undefined };
          const plainResult = await this.api.editMessageText(chatId, messageId, text, {
            ...plainOptions,
            workspaceName
          });

          logger.info('[TELEGRAM] Successfully edited as plain text after markdown error');
          return plainResult;
        } catch (plainError) {
          logger.error('Failed to edit even as plain text:', {
            chatId,
            messageId,
            error: plainError.message
          });
          throw plainError;
        }
      }

      logger.error('Failed to edit Telegram message:', {
        chatId,
        messageId,
        error: error.message,
        errorCode: error.response?.data?.error_code,
        description: error.response?.data?.description
      });
      throw error;
    }
  }

  async sendPhoto(chatId, photoUrl, options = {}) {
    // Route through gateway if in gateway mode (only URL-based photos supported via gateway)
    if (config.gateway.enabled && typeof photoUrl === 'string') {
      return this.sendViaGateway('telegram', chatId, photoUrl, {
        type: 'photo',
        content: photoUrl,
        options
      });
    }

    if (!this.isEnabled()) {
      logger.warn('Telegram bot token not configured');
      return;
    }

    try {
      const result = await this.api.sendPhoto(chatId, photoUrl, options);
      return result;
    } catch (error) {
      logger.error('Failed to send photo to Telegram:', {
        chatId,
        photoUrl: typeof photoUrl === 'string' ? photoUrl : '(stream)',
        error: error.message
      });
      throw error;
    }
  }

  async sendVideo(chatId, videoUrl, options = {}) {
    // Route through gateway if in gateway mode (only URL-based videos supported via gateway)
    if (config.gateway.enabled && typeof videoUrl === 'string') {
      return this.sendViaGateway('telegram', chatId, videoUrl, {
        type: 'video',
        content: videoUrl,
        options
      });
    }

    if (!this.isEnabled()) {
      logger.warn('Telegram bot token not configured');
      return;
    }

    try {
      const result = await this.api.sendVideo(chatId, videoUrl, options);
      return result;
    } catch (error) {
      logger.error('Failed to send video to Telegram:', {
        chatId,
        videoUrl: typeof videoUrl === 'string' ? videoUrl : '(stream)',
        error: error.message
      });
      throw error;
    }
  }

  async sendDocument(chatId, documentPath, options = {}) {
    // Route through gateway if in gateway mode (only URL-based documents supported via gateway)
    if (config.gateway.enabled && typeof documentPath === 'string') {
      return this.sendViaGateway('telegram', chatId, documentPath, {
        type: 'document',
        content: documentPath,
        options
      });
    }

    if (!this.isEnabled()) {
      logger.warn('Telegram bot token not configured');
      return;
    }

    try {
      const result = await this.api.sendDocument(chatId, documentPath, options);
      return result;
    } catch (error) {
      logger.error('Failed to send document to Telegram:', {
        chatId,
        documentPath: typeof documentPath === 'string' ? documentPath : '(stream)',
        error: error.message
      });
      throw error;
    }
  }

  /**
   * Send a message to a workspace with file attachments support
   * Parses message for @filename patterns and sends referenced files as attachments
   * @param {string} workspaceId - The workspace ID or name
   * @param {string} message - The message text that may contain @filename references
   * @param {Object} options - Additional options for sending the message
   */
  async sendMessageToWorkspace(workspaceId, message, options = {}) {
    try {
      const { WorkspaceManager } = await import('./workspace-manager.js');
      const manager = new WorkspaceManager();
      await manager.initialize();

      // Get the workspace and its associated Telegram chat
      const workspace = await manager.getWorkspace(workspaceId);
      if (!workspace) {
        logger.error(`Workspace not found: ${workspaceId}`);
        return;
      }

      // Get the Telegram chat ID for this workspace
      const chatMapping = await manager.getWorkspaceChatMapping(workspace.id);
      if (!chatMapping || !chatMapping.telegram_chat_id) {
        logger.warn(`No Telegram chat associated with workspace: ${workspace.name}`);
        await manager.close();
        return;
      }

      const chatId = chatMapping.telegram_chat_id;

      // Parse message for @filename patterns and @URL patterns
      // Updated pattern to handle both local files and URLs
      const fileAttachmentPattern = /@([^\s]+\.[^\s]+)/g;
      const matches = [...message.matchAll(fileAttachmentPattern)];
      const attachments = [];

      if (matches.length > 0) {
        const fs = await import('fs');
        const path = await import('path');

        for (const match of matches) {
          const filename = match[1];
          let filePath = filename;

          // Check if it's a URL (starts with http:// or https://)
          if (filename.startsWith('http://') || filename.startsWith('https://')) {
            // For URLs, especially S3 URLs, send them directly as photos
            attachments.push({
              filename: 'image.jpg', // Generic filename for URL images
              path: filename, // Use the URL as the path
              originalRef: match[0],
              isUrl: true
            });
            logger.info(`Found URL attachment: ${filename}`);
            continue;
          }

          // If not an absolute path, resolve relative to workspace path
          if (!path.isAbsolute(filePath)) {
            filePath = path.resolve(workspace.path, filePath);
          }

          // Check if file exists
          try {
            await fs.promises.access(filePath);
            attachments.push({
              filename: path.basename(filePath),
              path: filePath,
              originalRef: match[0],
              isUrl: false
            });
            logger.info(`Found attachment: ${filePath}`);
          } catch (error) {
            logger.warn(`File not found for attachment reference ${match[0]}: ${filePath}`);
          }
        }
      }

      // Remove @filename references from the message text
      let cleanMessage = message;
      for (const attachment of attachments) {
        cleanMessage = cleanMessage.replace(attachment.originalRef, `[${attachment.filename}]`);
      }

      // In gateway mode, upload local files to S3 to get URLs (gateway can only send URLs)
      if (config.gateway.enabled) {
        for (const attachment of attachments) {
          if (!attachment.isUrl) {
            try {
              const uploader = new SecureUploader();
              logger.info(`[Gateway] Uploading local file to S3: ${attachment.filename}`);
              const uploadResult = await uploader.uploadFile(attachment.path, {
                workdir: workspace.name || 'attachments'
              });
              if (uploadResult && uploadResult.url) {
                attachment.path = uploadResult.url;
                attachment.isUrl = true;
                logger.info(`[Gateway] Uploaded to S3: ${uploadResult.url}`);
              } else {
                logger.warn(`[Gateway] S3 upload returned no URL for ${attachment.filename}, skipping`);
              }
            } catch (uploadError) {
              logger.error(`[Gateway] Failed to upload ${attachment.filename} to S3:`, uploadError.message);
            }
          }
        }
      }

      // Helper to determine file type
      const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.apng', '.bmp', '.webp'];
      const pathModule = await import('path');

      // Helper to send a single attachment
      const sendAttachment = async (attachment, caption) => {
        if (attachment.isUrl) {
          // URL-based: use gateway-aware methods
          const ext = pathModule.extname(new URL(attachment.path).pathname || attachment.filename).toLowerCase();
          if (imageExtensions.includes(ext) || attachment.filename === 'image.jpg') {
            await this.sendPhoto(chatId, attachment.path, { caption, ...options });
          } else {
            await this.sendDocument(chatId, attachment.path, { caption, filename: attachment.filename, ...options });
          }
        } else {
          // Local file stream: direct API (non-gateway mode)
          const ext = pathModule.extname(attachment.path).toLowerCase();
          const fs = await import('fs');
          const fileStream = fs.createReadStream(attachment.path);
          if (imageExtensions.includes(ext)) {
            await this.api.sendPhoto(chatId, fileStream, { caption, ...options });
          } else {
            await this.api.sendDocument(chatId, fileStream, { caption, filename: attachment.filename, ...options });
          }
        }
      };

      // If there's only one attachment and there's a message, combine them into a single message
      if (attachments.length === 1 && cleanMessage.trim()) {
        const attachment = attachments[0];
        try {
          let captionText = cleanMessage.trim();
          captionText = captionText.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, '');
          await sendAttachment(attachment, captionText);
          logger.info(`Successfully sent ${attachment.filename} with message in single Telegram message`);
        } catch (error) {
          logger.error(`Failed to send attachment ${attachment.filename}:`, error);
        }
      } else {
        // Multiple attachments or no message - send separately
        for (const attachment of attachments) {
          try {
            let captionText = '📎 Image';
            if (attachment.isUrl) {
              try {
                const url = new URL(attachment.path);
                captionText = `📎 ${url.hostname}`;
              } catch (e) {
                captionText = `📎 ${attachment.path.substring(0, 50)}...`;
              }
            } else {
              captionText = `📎 ${attachment.filename}`;
            }
            await sendAttachment(attachment, captionText);
          } catch (error) {
            logger.error(`Failed to send attachment ${attachment.filename}:`, error);
          }
        }

        // Send the main message (with @filename references replaced)
        if (cleanMessage.trim() && attachments.length !== 1) {
          await this.sendMessage(chatId, cleanMessage, options);
        }
      }

      await manager.close();

      return {
        success: true,
        workspace: workspace.name,
        chatId,
        attachmentCount: attachments.length
      };

    } catch (error) {
      logger.error(`Failed to send message to workspace ${workspaceId}:`, error);
      throw error;
    }
  }

  async sendCustomMessage(title, content, chatId = null) {
    const targetChatId = chatId || this.defaultChatId;
    if (!targetChatId) {
      logger.warn('No chat ID available for Telegram notification');
      return;
    }

    let message = `*${title}*\n\n${content}`;

    if (!content.includes('🖥') && !content.includes('⏰')) {
      message += await this.formatFooter('system');
    }

    return this.sendMessage(targetChatId, message, { parse_mode: 'Markdown' });
  }

  async sendInteractiveMessage(title, content, actions = [], chatId = null) {
    const targetChatId = chatId || this.defaultChatId;
    if (!targetChatId) {
      logger.warn('No chat ID available for Telegram notification');
      return;
    }

    let message = `*${title}*\n\n${content}`;

    if (!content.includes('🖥') && !content.includes('⏰')) {
      message += await this.formatFooter('system');
    }

    const keyboard = { inline_keyboard: [] };
    
    // Convert Lark-style actions to Telegram inline keyboard
    if (actions && actions.length > 0) {
      const row = [];
      actions.forEach(action => {
        if (action.tag === 'button') {
          row.push({
            text: action.text.content,
            callback_data: action.value
          });
          
          // Max 3 buttons per row
          if (row.length === 3) {
            keyboard.inline_keyboard.push([...row]);
            row.length = 0;
          }
        }
      });
      
      if (row.length > 0) {
        keyboard.inline_keyboard.push(row);
      }
    }
    
    const options = { parse_mode: 'Markdown' };
    if (keyboard.inline_keyboard.length > 0) {
      options.reply_markup = keyboard;
    }
    
    return this.sendMessage(targetChatId, message, options);
  }

  async sendHelpMessage(chatId, currentWorkdirName) {
    let helpContent = `🤖 *AniCode Bot Commands*\n\n`;
    helpContent += `*Task Commands:*\n`;
    helpContent += `• /add [prompt] - Create a new Claude task\n`;
    helpContent += `• /continue [prompt] - Continue previous Claude task\n`;
    helpContent += `• /remember [info] - Save info to CLAUDE.md\n`;
    helpContent += `• /rulecompress [context] - Compress and organize CLAUDE.md\n`;
    helpContent += `• /check - Run completion checklist\n`;
    helpContent += `• /print - Show complete output of last task\n`;
    helpContent += `• /status - Show running tasks\n`;
    helpContent += `• /rank - Show daily usage report\n`;
    helpContent += `• /usage - Check Claude API usage (sessions, Opus)\n`;
    helpContent += `• /usage reset all - Reset all usage cache (session + opus)\n`;
    helpContent += `• /usage reset opus - Reset opus usage cache only\n`;
    helpContent += `• /history - Get HTML view of latest Claude session\n`;
    helpContent += `• /daystat - Show 24-hour task statistics\n`;
    helpContent += `• /weekstat - Show 7-day task statistics\n`;
    helpContent += `• /monthstat - Show 30-day task statistics\n`;
    helpContent += `• /yearstat - Show 12-month task statistics\n`;
    helpContent += `• /report - Generate token usage heatmap report\n`;
    helpContent += `• /url - Get public URL of last image\n`;
    helpContent += `• /img - Extract and send images from last task output\n`;
    helpContent += `• /branch [name/desc] - Create or switch git branches\n`;
    helpContent += `• /macros - List all macro commands\n`;
    helpContent += `\n*Goal Commands:*\n`;
    helpContent += `• /goals - List all project goals\n`;
    helpContent += `• /goals show <id> - View goal details\n`;
    helpContent += `• /goaladd <desc> - Create new goal\n`;
    helpContent += `• /goaladdmulti <desc> - Create multiple goals\n`;
    helpContent += `• /goalcheck - Check completion status\n`;
    helpContent += `• /goalsync [--fast|--full] - Sync goals cache\n`;
    helpContent += `• /goalloop [opts] - Run automation loop\n`;
    helpContent += `\n*Project Health:*\n`;
    helpContent += `• /healthcheck - Run audit with AI analysis\n`;
    helpContent += `• /healthcheck fix - Auto-fix vulnerabilities\n`;
    helpContent += `• /healthcheck only-json - Skip AI, raw report only\n`;
    helpContent += `\n*Plan Commands:*\n`;
    helpContent += `• /plan [steps] - Create a new plan with steps\n`;
    helpContent += `• /plans - List all plans for the workspace\n`;
    helpContent += `• /next [plan-id] - Execute the next plan or specific plan\n`;
    helpContent += `• /yolo - Execute ALL pending plans with commits\n`;
    helpContent += `• /stopyolo - Stop ongoing YOLO execution\n`;
    helpContent += `• /cleanup - Remove all completed plans\n`;
    helpContent += `• /purge confirm - Force reset all plans (⚠️ dangerous)\n`;

    if (!currentWorkdirName) {
      helpContent += `\n*Workspace Settings:*\n`;
      helpContent += `• /connect [token] - Connect this chat to a workspace\n`;
      helpContent += `\n❌ *No workspace connected* - use /connect [token] to connect`;
    } else {
      helpContent += `\n📁 *Working in:* ${currentWorkdirName}`;
    }

    helpContent += await this.formatFooter('help');

    // Build inline keyboard for quick actions
    const keyboard = { inline_keyboard: [] };
    
    // Add common action buttons
    keyboard.inline_keyboard.push([
      {
        text: '📊 Status',
        callback_data: JSON.stringify({ action: 'show_status' })
      }
    ]);
    
    // If workdir is set, add Claude task buttons
    if (currentWorkdirName) {
      keyboard.inline_keyboard.push([
        {
          text: '🔄 Continue',
          callback_data: JSON.stringify({ action: 'claude_continue' })
        },
        {
          text: '💾 Commit',
          callback_data: JSON.stringify({
            action: 'run_task',
            command: 'ani-code commit -y'
          })
        }
      ]);
    }
    
    return this.sendMessage(chatId, helpContent, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    });
  }

  // Yolo mode status message formatting
  async formatYoloStatusMessage(workspaceName, totalPlans, completedPlans, currentPlan = null, status = 'executing', executionData = {}) {
    // Validate workspace name
    if (!workspaceName || workspaceName === 'undefined' || workspaceName === 'null') {
      logger.error(`[YOLO] Invalid workspace name: ${workspaceName}. Using fallback name.`);
      workspaceName = 'workspace';
    }

    // Validate totalPlans and completedPlans
    totalPlans = parseInt(totalPlans) || 0;
    completedPlans = parseInt(completedPlans) || 0;

    if (totalPlans < 0 || completedPlans < 0 || completedPlans > totalPlans) {
      logger.error(`[YOLO] Invalid plan counts - total: ${totalPlans}, completed: ${completedPlans}. Resetting to safe values.`);
      totalPlans = Math.max(totalPlans, 1);
      completedPlans = Math.max(0, Math.min(completedPlans, totalPlans));
    }

    // Increment message version for troubleshooting - only if not already set
    if (typeof executionData.messageVersion === 'undefined') {
      executionData.messageVersion = 1;
      logger.warn(`⚠️ [YOLO FORMAT] Message version was undefined, initializing to v1 - This might be the source of v1 messages!`);
    }
    // Increment version on each format (caller manages persistence)
    executionData.messageVersion++;

    // Get caller information for debugging
    const stack = new Error().stack;
    const callerMatch = stack.match(/at\s+(\S+)\s+\(([^)]+)\)/g);
    const caller = callerMatch && callerMatch[2] ? callerMatch[2].replace(/^.*\//, '') : 'unknown';

    logger.debug(`[YOLO] Format v${executionData.messageVersion} - ${status} (${completedPlans}/${totalPlans}) from ${caller}`);
    // Calculate running time for header
    let timeStr = '0s';
    if (executionData.startTime) {
      // Handle both timestamp numbers and ISO date strings
      let startTime;
      if (typeof executionData.startTime === 'string') {
        // If it's a string (likely ISO date from database), parse it
        startTime = new Date(executionData.startTime).getTime();
      } else {
        // If it's already a number, use it directly
        startTime = Number(executionData.startTime);
      }
      const currentTime = Date.now();

      // Validate that startTime is a valid number and not in the future
      if (!isNaN(startTime) && startTime > 0 && startTime <= currentTime) {
        const duration = currentTime - startTime;
        const hours = Math.floor(duration / 3600000);
        const minutes = Math.floor((duration % 3600000) / 60000);
        const seconds = Math.floor((duration % 60000) / 1000);

        if (hours > 0) {
          timeStr = `${hours}h ${minutes}m`;
        } else if (minutes > 0) {
          timeStr = `${minutes}m ${seconds}s`;
        } else {
          timeStr = `${seconds}s`;
        }
      } else {
        // Log detailed error when time calculation fails
        logger.error(`[YOLO] Invalid startTime for time calculation: ${executionData.startTime} (type: ${typeof executionData.startTime}, isNaN: ${isNaN(startTime)}, value: ${startTime})`);
        if (executionData.startTime > currentTime) {
          logger.error(`[YOLO] startTime is in the future: ${executionData.startTime} > ${currentTime}`);
        }
        // Reset to valid default
        timeStr = '0s';
        // Optionally fix the startTime to prevent recurring issues
        if (!executionData.startTime || isNaN(startTime)) {
          executionData.startTime = currentTime;
          logger.warn(`[YOLO] Reset invalid startTime to current time: ${currentTime}`);
        }
      }
    } else {
      // If no startTime at all, log this and set it
      if (status === 'executing' || status === 'committing') {
        logger.warn(`[YOLO] No startTime provided for status '${status}'. Setting to current time.`);
        executionData.startTime = Date.now();
        timeStr = '0s';
      }
    }

    // Add lock icon if protection is enabled
    const protectionEnabled = status !== 'completed' && status !== 'stopped';
    const lockIcon = protectionEnabled ? ' 🔒' : '';

    // Header - show time based on status and elapsed time
    let message = '';
    if (status === 'completed') {
      message = `🚀 *YOLO* │ ✅ ${completedPlans}/${totalPlans} plans completed\n\n`;
    } else if (status === 'stopped') {
      message = `🚀 *YOLO* │ ⛔ ${completedPlans}/${totalPlans} plans completed\n\n`;
    } else if (status === 'committing') {
      // When committing, we just finished a plan so show completion count
      message = `🟡 ${timeStr} 🚀 *YOLO* │ ${completedPlans} of ${totalPlans} completed${lockIcon}\n\n`;
    } else if (status === 'starting') {
      // Only hide time for the initial 'starting' status
      const currentPlanNum = completedPlans + 1;
      message = `🚀 *YOLO* │ Plan ${currentPlanNum}/${totalPlans}${lockIcon}\n\n`;
    } else {
      // For 'executing' and other statuses, always show time (even if 0s)
      const currentPlanNum = completedPlans + 1;
      message = `🟡 ${timeStr} 🚀 *YOLO* │ Plan ${currentPlanNum}/${totalPlans}${lockIcon}\n\n`;
    }

    // Status section with plan display (max 3: previous, current, next)
    if (currentPlan && status === 'executing') {
      // Show plans context (previous, current, next) - max 3 plans
      const planIndex = completedPlans + 1;
      const plansToShow = [];

      // Add previous plan if exists
      if (executionData.lastCompletedPlan && planIndex > 1) {
        plansToShow.push({
          type: 'completed',
          index: planIndex - 1,
          title: executionData.lastCompletedPlan.title || `Plan ${planIndex - 1}`
        });
      }

      // Add current plan
      plansToShow.push({
        type: 'current',
        index: planIndex,
        plan: currentPlan
      });

      // Add next plan if exists
      if (executionData.nextPlan && planIndex < totalPlans) {
        plansToShow.push({
          type: 'next',
          index: planIndex + 1,
          title: executionData.nextPlan.title || `Plan ${planIndex + 1}`
        });
      }

      // Display plans
      message += `📋 *Plans:*\n`;
      plansToShow.forEach(item => {
        if (item.type === 'completed') {
          message += `✓ Plan ${item.index}/${totalPlans}: ${this.escapeMarkdownContent(item.title)}\n`;
        } else if (item.type === 'current') {
          const plan = item.plan;
          const planTitle = plan.title || `Plan ${plan.plan_id || item.index}`;
          const totalSteps = plan.totalSteps || plan.steps?.length || 0;

          if (totalSteps === 1) {
            // For single-step plans, show only the plan with the step text inline
            const stepObj = plan.steps?.[0];
            let stepText = plan.currentStepText ||
                          (stepObj && typeof stepObj === 'object' ? (stepObj.description || stepObj.raw || stepObj.prompt) : stepObj) ||
                          planTitle;
            // Ensure stepText is a string
            stepText = String(stepText || planTitle);
            // Remove redundant "Processing plan:" prefix
            if (stepText.startsWith('Processing plan:')) {
              stepText = stepText.replace(/^Processing plan:[^:]*:\s*/, '').trim();
            }
            // Truncate to 100 chars for clean display
            if (stepText.length > 100) {
              stepText = stepText.substring(0, 97) + '...';
            }
            message += `▶ Plan ${item.index}/${totalPlans}: ${this.escapeMarkdownContent(stepText)}\n`;
          } else {
            // For multi-step plans, show plan and current step
            message += `▶ Plan ${item.index}/${totalPlans}: ${this.escapeMarkdownContent(planTitle)}\n`;
            if (plan.currentStep && plan.totalSteps) {
              // Get step text but truncate to reasonable length for status display
              const stepObj = plan.steps?.[plan.currentStep - 1];
              let stepText = plan.currentStepText ||
                            (stepObj && typeof stepObj === 'object' ? (stepObj.description || stepObj.raw || stepObj.prompt) : stepObj) ||
                            'Processing...';
              // Ensure stepText is a string
              stepText = String(stepText || 'Processing...');
              // Remove redundant "Processing plan:" prefix if it's step 1
              if (plan.currentStep === 1 && stepText.startsWith('Processing plan:')) {
                stepText = stepText.replace(/^Processing plan:[^:]*:\s*/, '').trim();
              }
              // Truncate to 100 chars for clean display
              if (stepText.length > 100) {
                stepText = stepText.substring(0, 97) + '...';
              }
              message += `  └ Step ${plan.currentStep}/${plan.totalSteps}: ${this.escapeMarkdownContent(stepText)}\n`;
            }
          }
        } else if (item.type === 'next') {
          message += `○ Plan ${item.index}/${totalPlans}: ${this.escapeMarkdownContent(item.title)}\n`;
        }
      });
    } else if (status === 'committing') {
      message += `💾 *Processing Commit:*\n`;
      message += `• Plan ${completedPlans}/${totalPlans} completed\n`;
      message += `• Creating git commit...\n`;
    } else if (status === 'starting') {
      message += `⏳ *Starting execution...*\n`;
    } else if (status === 'completed') {
      // Check if this is really all plans completed or just one plan
      if (completedPlans >= totalPlans) {
        // All plans are done
        message += `✅ *All plans completed!*\n`;
        message += `Total executed: ${totalPlans} plans\n`;
      } else {
        // Just one plan completed, more to go
        message += `✅ *Plan completed!*\n`;
        message += `Progress: ${completedPlans}/${totalPlans} plans done\n`;
        const remainingPlans = totalPlans - completedPlans;
        message += `Remaining: ${remainingPlans} plan${remainingPlans !== 1 ? 's' : ''}\n`;
      }
      // Add total time to body
      if (timeStr !== '0s') {
        message += `⏱️ Time elapsed: ${timeStr}\n`;
      }
    } else if (status === 'stopped') {
      message += `⛔ *Execution stopped by user*\n`;
      message += `Completed: ${completedPlans} of ${totalPlans} plans\n`;
      // Add total time when stopped
      if (timeStr !== '0s') {
        message += `⏱️ Run time: ${timeStr}\n`;
      }
    }

    // Add commit history if available
    if (executionData.commits && executionData.commits.length > 0) {
      message += `\n💾 *Commits:*\n`;
      executionData.commits.forEach((commit, index) => {
        // Show full commit message in code block (no truncation)
        message += `${index + 1}. \`${commit.hash}\`\n`;
        message += `\`\`\`\n${commit.message}\n\`\`\`\n`;
      });
    }


    // Add cost/usage info if available
    if (executionData.usage) {
      const costLine = await this.buildCostTokenLine(executionData.usage, null);
      if (costLine) {
        message += `${costLine}\n`;
      }
    }

    // Add standard footer with provider from execution data
    const footerOptions = {};
    if (executionData.providerId) {
      footerOptions.taskProviderId = executionData.providerId;
    }
    message += await this.formatFooter(workspaceName, footerOptions);

    // Add version number as small text at the end (Telegram doesn't support HTML comments)
    message += ` [v${executionData.messageVersion}]`;

    return message;
  }

  async sendYoloStatus(chatId, message, options = {}) {
    // Check for NaN in message content
    if (message.includes('NaN')) {
      logger.error(`[YOLO SEND] NaN detected in message content! Message preview: ${message.substring(0, 200)}`);
      logger.error(`[YOLO SEND] Full message for debugging:`, message);
      // Don't send messages with NaN values
      logger.warn(`[YOLO SEND] Skipping message send due to NaN content. This prevents confusing status messages.`);
      return null;
    }

    // Extract version from message for logging
    const versionMatch = message.match(/\[v(\d+)\]/);
    const messageVersion = versionMatch ? versionMatch[1] : 'MISSING';

    // If version is missing, log why
    if (!versionMatch) {
      logger.warn(`⚠️ [YOLO SEND] Version missing in message! This might be from:
        1. Direct message send without formatYoloStatusMessage
        2. Message text modified after formatting
        3. Error/fallback message without proper formatting`);
      logger.debug(`[YOLO SEND] Message preview: ${message.substring(0, 100)}...`);
    }

    // Get caller stack trace for debugging
    const stack = new Error().stack;
    const callerMatch = stack.match(/at\s+(\S+)\s+\(([^)]+)\)/g);
    const caller = callerMatch && callerMatch[2] ? callerMatch[2].replace(/^.*\//, '') : 'unknown';

    // Extract key message details for logging
    const planMatch = message.match(/Plan (\d+)\/(\d+)/);
    const planInfo = planMatch ? `Plan ${planMatch[1]}/${planMatch[2]}` : 'No plan info';

    logger.info(`📤 [YOLO SEND] v${messageVersion} | ${planInfo} | chat:${chatId} | caller:${caller} | skipAutoPin:${options.skipAutoPin || false}`);

    const keyboard = { inline_keyboard: [] };

    if (options.showButtons) {
      keyboard.inline_keyboard.push([
        {
          text: '🔓 Exit Protection',
          callback_data: JSON.stringify({ action: 'exit_protection' })
        },
        {
          text: '🔄 Refresh Status',
          callback_data: JSON.stringify({ action: 'refresh_yolo_status' })
        }
      ]);
    } else if (options.showCompletedButtons) {
      keyboard.inline_keyboard.push([
        {
          text: '📋 View Plans',
          callback_data: JSON.stringify({ action: 'list_plans' })
        },
        {
          text: '📊 Status',
          callback_data: JSON.stringify({ action: 'show_status' })
        }
      ]);
    }

    // Mark this chat as yolo-protected
    this.yoloProtectedChats.add(chatId);
    logger.debug(`[YOLO] Protected chat ${chatId} - total: ${this.yoloProtectedChats.size}`)

    const result = await this.sendMessage(chatId, message, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    });

    // Check if autopin is enabled for this workspace and pin the message
    // IMPORTANT: skipAutoPin option prevents pin accumulation during resends
    const workspaceShowProgress = options.workspace?.settings?.showprogress || 'autopin';
    if (result && result.result && result.result.message_id && options.workspace && !options.skipAutoPin) {
      try {
        if (workspaceShowProgress === 'autopin') {
          await this.api.pinChatMessage(chatId, result.result.message_id, { disable_notification: true });
          logger.info(`[AUTO-PIN] Pinned YOLO status message ${result.result.message_id} for workspace ${options.workspace.name}`);
        }
      } catch (error) {
        logger.warn(`[AUTO-PIN] Failed to pin YOLO status message: ${error.message}`);
      }
    } else if (options.skipAutoPin && options.workspace && workspaceShowProgress === 'autopin') {
      logger.debug(`[AUTO-PIN] Skipped pinning for resend message ${result?.result?.message_id} - preventing pin accumulation`);
    }

    return result;
  }

  async updateYoloStatus(chatId, messageId, message, options = {}) {
    // Extract version from message for logging
    const versionMatch = message.match(/\[v(\d+)\]/);
    const messageVersion = versionMatch ? versionMatch[1] : 'MISSING';

    // If version is missing, log why
    if (!versionMatch) {
      logger.warn(`⚠️ [YOLO UPDATE] Version missing in message for msg:${messageId}! This might be from:
        1. Protection disabled message (manual override)
        2. Error message without proper formatting
        3. Custom status message`);
      logger.debug(`[YOLO UPDATE] Message preview: ${message.substring(0, 100)}...`);
    }

    // Extract task info from message
    const planMatch = message.match(/Plan (\d+\/\d+)/);
    const planInfo = planMatch ? planMatch[1] : 'n/a';

    // Extract workspace from message footer
    const workspaceMatch = message.match(/📍\s+([^\n]+)/);
    const workspace = workspaceMatch ? workspaceMatch[1].trim() : 'unknown';

    // Extract time from message header
    const timeMatch = message.match(/^(\d+[hms]\s+\d*[ms]*\s*)/);
    const runTime = timeMatch ? timeMatch[1].trim() : '0s';

    // Extract current task/step from message
    let currentTask = 'idle';
    const stepMatch = message.match(/└ Step \d+\/\d+: ([^\n]+)/);
    const taskMatch = message.match(/▶ Plan \d+\/\d+: ([^\n]+)/);
    if (stepMatch) {
      currentTask = stepMatch[1].substring(0, 50); // Truncate long tasks
    } else if (taskMatch) {
      currentTask = taskMatch[1].substring(0, 50);
    }

    // Log with version warning if missing
    logger.info(`📬 [YOLO UPDATE] msg:${messageId} v${messageVersion} | ${planInfo} | ws:${workspace} | time:${runTime} | task:${currentTask}`);

    const keyboard = { inline_keyboard: [] };

    if (!messageId) {
      logger.error(`❌ [YOLO UPDATE] No message ID provided - falling back to sendYoloStatus`);
      return this.sendYoloStatus(chatId, message, options);
    }

    if (!options.showCompletedButtons) {
      keyboard.inline_keyboard.push([
        {
          text: '🔓 Exit Protection',
          callback_data: JSON.stringify({ action: 'exit_protection' })
        },
        {
          text: '🔄 Refresh Status',
          callback_data: JSON.stringify({ action: 'refresh_yolo_status' })
        }
      ]);
    } else {
      // Yolo completed, remove from protected chats
      this.yoloProtectedChats.delete(chatId);

      keyboard.inline_keyboard.push([
        {
          text: '📋 View Plans',
          callback_data: JSON.stringify({ action: 'list_plans' })
        },
        {
          text: '📊 Status',
          callback_data: JSON.stringify({ action: 'show_status' })
        }
      ]);
    }

    try {
      const result = await this.editMessage(
        chatId,
        messageId,
        message,
        {
          parse_mode: 'Markdown',
          reply_markup: keyboard
        }
      );

      logger.info(`✅ [YOLO UPDATE] msg:${messageId} v${messageVersion} updated successfully`);
      return result;
    } catch (error) {
      logger.error(`❌ [YOLO UPDATE] Failed to update message ${messageId}: ${error.message}`);

      // Check if error is because message was not modified (same content)
      if (error.response?.data?.description?.includes('message is not modified')) {
        logger.info(`ℹ️ [YOLO UPDATE] Message content unchanged, skipping update`);
        return { ok: true, result: null };
      }

      // Check if message was not found (deleted or doesn't exist)
      if (error.response?.data?.description?.includes('message to edit not found')) {
        logger.warn(`⚠️ [YOLO UPDATE] Message ${messageId} not found - likely deleted. Sending new message.`);
        // For YOLO updates, we should send a new message when the old one is gone
        return this.sendYoloStatus(chatId, message, options);
      }

      // Only fallback for other errors (network issues, etc)
      logger.warn(`⚠️ [YOLO UPDATE] Update failed, falling back to sendYoloStatus with v${messageVersion}`);
      return this.sendYoloStatus(chatId, message, options);
    }
  }

  isYoloProtected(chatId) {
    return this.yoloProtectedChats.has(chatId);
  }

  clearYoloProtection(chatId) {
    this.yoloProtectedChats.delete(chatId);
  }

  async deleteMessage(chatId, messageId) {
    // Route through gateway if in gateway mode
    if (config.gateway.enabled) {
      return this.sendViaGateway('telegram', chatId, null, {
        type: 'delete',
        options: {
          messageId
        }
      });
    }

    if (!this.isEnabled()) {
      logger.warn('Telegram bot token not configured');
      return null;
    }

    try {
      const result = await this.api.deleteMessage(chatId, messageId);
      logger.debug(`Deleted message ${messageId} in chat ${chatId}`);
      return result;
    } catch (error) {
      logger.debug(`Failed to delete message ${messageId}: ${error.message}`);
      return null;
    }
  }

  async pinChatMessage(chatId, messageId, options = {}) {
    // Route through gateway if in gateway mode
    if (config.gateway.enabled) {
      return this.sendViaGateway('telegram', chatId, null, {
        type: 'pin',
        options: {
          messageId,
          ...options
        }
      });
    }

    if (!this.isEnabled()) {
      logger.warn('Telegram bot token not configured');
      return null;
    }

    try {
      const result = await this.api.pinChatMessage(chatId, messageId, options);
      logger.debug(`Pinned message ${messageId} in chat ${chatId}`);
      return result;
    } catch (error) {
      logger.warn(`Failed to pin message ${messageId}: ${error.message}`);
      return null;
    }
  }

  async unpinChatMessage(chatId, messageId = null, options = {}) {
    // Route through gateway if in gateway mode
    if (config.gateway.enabled) {
      return this.sendViaGateway('telegram', chatId, null, {
        type: 'unpin',
        options: {
          messageId,
          ...options
        }
      });
    }

    if (!this.isEnabled()) {
      logger.warn('Telegram bot token not configured');
      return null;
    }

    try {
      const result = await this.api.unpinChatMessage(chatId, messageId, options);
      logger.debug(`Unpinned message ${messageId || 'latest'} in chat ${chatId}`);
      return result;
    } catch (error) {
      logger.warn(`Failed to unpin message ${messageId}: ${error.message}`);
      return null;
    }
  }

  // Error notification with loop prevention
  async sendErrorNotification(error, context = {}) {
    // Skip if no default chat ID configured
    if (!this.defaultChatId) {
      logger.warn('No default chat ID configured for error notifications');
      return;
    }

    // Loop prevention - check if this is a recursive error
    const errorKey = `${error.message || error}:${context.source || 'unknown'}`;
    const now = Date.now();
    
    // Initialize error tracking if needed
    if (!this.errorHistory) {
      this.errorHistory = new Map();
    }
    
    // Check if we've sent this error recently (within 5 minutes)
    const lastSent = this.errorHistory.get(errorKey);
    if (lastSent && (now - lastSent) < 5 * 60 * 1000) {
      logger.debug(`Skipping duplicate error notification: ${errorKey}`);
      return;
    }
    
    // Update last sent time
    this.errorHistory.set(errorKey, now);
    
    // Clean up old entries (older than 10 minutes)
    for (const [key, timestamp] of this.errorHistory.entries()) {
      if (now - timestamp > 10 * 60 * 1000) {
        this.errorHistory.delete(key);
      }
    }
    
    try {
      // Format error message
      let message = `⚠️ *Error Detected*\n\n`;
      
      if (context.source) {
        message += `*Source:* ${this.escapeMarkdownContent(context.source)}\n`;
      }
      
      if (context.taskId) {
        // Escape underscores in task ID to prevent Telegram markdown interpretation
        const escapedTaskId = context.taskId.replace(/_/g, '\\_');
        message += `*Task ID:* \`${escapedTaskId}\`\n`;
      }
      
      if (context.operation) {
        message += `*Operation:* ${this.escapeMarkdownContent(context.operation)}\n`;
      }
      
      message += `\n*Error:*\n`;
      const errorMessage = error.stack || error.message || String(error);
      const lines = errorMessage.split('\n').slice(0, 10);
      message += '```\n' + lines.join('\n') + '\n```';
      
      if (context.suggestion) {
        message += `\n💡 *Suggestion:* ${this.escapeMarkdownContent(context.suggestion)}`;
      }

      message += await this.formatFooter('error-check');

      // Send to default channel
      await this.sendMessage(this.defaultChatId, message, {
        parse_mode: 'Markdown'
      });
      
      logger.info(`Error notification sent to default channel: ${errorKey}`);
    } catch (sendError) {
      // Don't throw to prevent cascading errors
      logger.error('Failed to send error notification:', sendError);
    }
  }
}

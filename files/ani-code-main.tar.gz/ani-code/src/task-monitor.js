import { TaskQueue } from './task-queue.js';
import { LarkNotifier } from './lark-notifier.js';
import { TelegramNotifier } from './telegram-notifier.js';
import { UsageReporter } from './usage-reporter.js';
import { config } from './config.js';
import { logger } from './logger.js';
import { EventEmitter } from 'events';
import { formatErrorMessage } from './utils/error-formatter.js';
import fetch from 'node-fetch';
import crypto from 'crypto';
import { DisplayModeManager } from './display-mode.js';

/**
 * Generate HMAC-SHA256 signature for callback requests (Goal 269 - Security Hardening)
 * @param {string} projectId - The project identifier
 * @param {Object} body - The request body to sign
 * @param {string} secretKey - The HMAC signing key
 * @returns {{ timestamp: string, signature: string }} The timestamp and signature
 */
function generateCallbackSignature(projectId, body, secretKey) {
  const timestamp = Math.floor(Date.now() / 1000).toString();
  const payload = `${timestamp}.${projectId}.${JSON.stringify(body)}`;
  const signature = crypto
    .createHmac('sha256', secretKey)
    .update(payload)
    .digest('hex');

  return { timestamp, signature };
}

export class TaskMonitor extends EventEmitter {
  constructor(chatSettings = null, workspaceManager = null) {
    super();
    this.workspaceManager = workspaceManager;
    this.taskQueue = new TaskQueue(config.tasks.maxConcurrent, workspaceManager);
    this.larkNotifier = new LarkNotifier();
    this.telegramNotifier = null;  // Initialize lazily
    this.usageReporter = new UsageReporter();
    this.chatSettings = chatSettings;  // Optional chat settings manager
    this.lastStatusUpdateTime = new Map();  // Track last update time per chat
    this.statusUpdateInterval = null;
    this.taskCompletionMessageIds = new Map(); // Track message IDs for usage updates
    this.taskStartedMessageIds = new Map(); // Track "started" placeholder Promises that resolve to { chatId, messageId } or null
    // Gateway callback tracking
    this.gatewayCallbackEnabled = !!(config.gateway?.callbackUrl && config.gateway?.apiKey);
    this.failedCallbacks = [];
    this.maxFailedCallbacks = 100; // Limit to prevent memory growth
    this.snapshotCleanupInterval = null;
    this.setupEventHandlers();
    // Skip daily stats report in gateway mode - gateway handles its own reporting
    if (!config.gateway?.enabled) {
      this.setupDailyReportInterval();
    } else {
      logger.info('[Gateway] Daily usage report disabled - gateway mode active');
    }
    this.setupPeriodicStatusUpdates();
    this.setupSnapshotCleanup();

    // Initialize Telegram notifier if configured OR in gateway mode
    // In gateway mode, we need the notifier even without a real token
    if (config.telegram?.botToken || config.gateway?.enabled) {
      this.telegramNotifier = new TelegramNotifier();
    }

    // Log gateway callback status
    if (this.gatewayCallbackEnabled) {
      logger.info(`[Gateway] Callback enabled to ${config.gateway.callbackUrl}`);
      // Warn if running in legacy mode without callback signing (Goal 269)
      if (!config.gateway.signingKey) {
        logger.warn('[SECURITY] Running in legacy mode - callback requests not signed');
        logger.warn('[SECURITY] Set PROJECT_GATEWAY_KEY to enable signed callbacks');
      } else {
        logger.info('[SECURITY] Callback signing enabled with PROJECT_GATEWAY_KEY');
      }
    }
  }

  /**
   * Get the display mode for a chat ID
   * @param {string} chatId - Chat ID (e.g., 'telegram:123456')
   * @returns {string} Display mode ('full' or 'simple')
   */
  getDisplayModeForChat(chatId) {
    if (!this.chatSettings) return 'full';
    const manager = new DisplayModeManager(this.chatSettings);
    return manager.getDisplayMode(chatId);
  }

  setupEventHandlers() {
    this.taskQueue.on('taskStarted', async (task) => {
      logger.info(`[CHATID-TRACK] Task started: ${task.name} (${task.id}) - chatId: ${task.chatId || 'none'}`);

      // Usage snapshot is already created in task-queue.js before emitting this event
      // No need to create it again here

      // Send gateway callback for task started
      if (this.gatewayCallbackEnabled && task.metadata?.source === 'gateway') {
        this.notifyGateway(task, 'started', 0).catch(error => {
          logger.error(`[Gateway] Failed to send started callback: ${error.message}`);
        });
      }

      logger.info(`[CHATID-TRACK] Sending 'started' notification for task ${task.id} to chatId: ${task.chatId || 'default'}`);
      
      const displayMode = this.getDisplayModeForChat(task.chatId);

      // In simple mode, skip auto-progress setup (no periodic updates needed)
      // but still send a progress placeholder that will be edited on completion
      if (displayMode === 'simple') {
        logger.info(`[CHATID-TRACK] Simple mode active for task ${task.id} — will send placeholder, skip auto-progress and periodic status updates`);
      }

      // Check for showprogress auto-trigger setting (skip in simple mode)
      let autoProgressEnabled = false;
      if (displayMode !== 'simple' && task.chatId && task.cwd && task.chatId.startsWith('telegram:')) {
        try {
          const { WorkspaceManager } = await import('./workspace-manager.js');
          const manager = new WorkspaceManager();
          await manager.initialize();

          const workspace = await manager.getWorkspaceByPath(task.cwd);
          const showProgressMode = workspace?.settings?.showprogress || 'autopin';
          if (showProgressMode === 'auto' || showProgressMode === 'autopin') {
            autoProgressEnabled = true;
            const mode = showProgressMode === 'autopin' ? 'with pinning' : '';
            logger.info(`[AUTO-PROGRESS] Auto-progress enabled ${mode} for task ${task.id} in workspace ${workspace.name}`);

            // Trigger progress AFTER the normal notification
            // This creates a separate progress message that auto-updates
            setTimeout(() => {
              this.autoTriggerProgress(task);
            }, 5000); // 5 second delay - ensures it appears after the "task started" message (3s delay)
          }

          await manager.close();
        } catch (error) {
          logger.debug(`Failed to check showprogress setting: ${error.message}`);
        }
      }

      // Send notification based on chat ID prefix (ALWAYS send this, both simple and full modes)
      // We store a Promise that resolves to { chatId, messageId } so completion/cancellation
      // can await it — eliminates the race condition with fast-completing tasks.
      if (task.chatId && task.chatId.startsWith('telegram:')) {
        const telegramChatId = task.chatId.replace('telegram:', '');
        logger.info(`[CHATID-TRACK] Telegram notifier check:`, {
          hasNotifier: !!this.telegramNotifier,
          notifierType: this.telegramNotifier?.constructor?.name,
          taskId: task.id,
          chatId: telegramChatId,
          displayMode
        });
        if (this.telegramNotifier) {
          // Store a Promise that resolves to the message info after the delayed send completes.
          // handleTaskCompleted/handleTaskCancelled will await this to get the message ID.
          const taskId = task.id;
          const taskDisplayMode = displayMode;
          const placeholderPromise = new Promise((resolve) => {
            setTimeout(async () => {
              try {
                logger.info(`[CHATID-TRACK] Sending started placeholder for task ${taskId} (displayMode=${taskDisplayMode})`);
                const result = await this.telegramNotifier.sendTaskUpdate(task, 'started', telegramChatId, taskDisplayMode);
                if (result?.result?.message_id) {
                  const msgInfo = { chatId: telegramChatId, messageId: result.result.message_id };
                  logger.info(`[PROGRESS-PLACEHOLDER] Stored started message ${msgInfo.messageId} for task ${taskId}`);

                  // Start progress tracking on the placeholder message
                  // This periodically edits the placeholder with recent output + elapsed time
                  const httpServer = global.httpServer;
                  if (httpServer && typeof httpServer.startProgressTrackingOnMessage === 'function') {
                    // 2s delay — enough for task process to spawn, short enough for quick feedback
                    setTimeout(() => {
                      httpServer.startProgressTrackingOnMessage(telegramChatId, taskId, msgInfo.messageId, taskDisplayMode)
                        .catch(err => logger.warn(`[PROGRESS-PLACEHOLDER] Failed to start tracking: ${err.message}`));
                    }, 2000);
                  }

                  resolve(msgInfo);
                } else {
                  // sendTaskUpdate returned without a message_id — likely blocked by YOLO protection
                  logger.warn(`[PROGRESS-PLACEHOLDER] No message_id returned for task ${taskId} — sendTaskUpdate returned: ${result === undefined ? 'undefined (YOLO/protection blocked)' : JSON.stringify(result).substring(0, 100)}`);
                  resolve(null);
                }
              } catch (error) {
                const errorMsg = formatErrorMessage(error, {
                  operation: 'Send Telegram task start notification',
                  location: 'task-monitor.js:taskStarted'
                });
                logger.error(errorMsg);
                resolve(null); // Resolve null so awaiting code doesn't hang
              }
            }, 1000);
          });
          this.taskStartedMessageIds.set(task.id, { promise: placeholderPromise, createdAt: Date.now() });
        } else {
          logger.warn(`[CHATID-TRACK] No telegram notifier available for task ${task.id}`);
        }
      } else {
        // Default to Lark for backward compatibility
        // Add 1-second delay for all notifications to ensure proper ordering
        setTimeout(() => {
          this.larkNotifier.sendTaskUpdate(task, 'started', null, displayMode).catch(error => {
            const errorMsg = formatErrorMessage(error, {
              operation: 'Send Lark task start notification',
              location: 'task-monitor.js:86'
            });
            logger.error(errorMsg);
          });
        }, 1000);
      }
    });
    
    this.taskQueue.on('taskUpdated', (task) => {
      // Just log when PID becomes available, don't send duplicate notification
      if (task.pid) {
        logger.debug(`Task PID available: ${task.name} (PID: ${task.pid})`);
        // Note: We already sent the "started" notification in the taskStarted event
        // The PID is now included in the task object for any future references
      }
    });

    this.taskQueue.on('taskCompleted', (task) => {
      this.handleTaskCompleted(task).catch((error) => {
        const errorMsg = formatErrorMessage(error, {
          operation: `Handle taskCompleted for task ${task?.id || 'unknown'}`,
          location: 'task-monitor.js:109'
        });
        logger.error(`[TASK-MONITOR] ${errorMsg}`);
      });
    });

    this.taskQueue.on('taskCancelled', (task) => {
      this.handleTaskCancelled(task).catch((error) => {
        const errorMsg = formatErrorMessage(error, {
          operation: `Handle taskCancelled for task ${task?.id || 'unknown'}`,
          location: 'task-monitor.js:205'
        });
        logger.error(`[TASK-MONITOR] ${errorMsg}`);
      });
    });

    this.taskQueue.on('taskAdded', (task) => {
      logger.info(`Task queued: ${task.name}`);
      
      // Don't send queue notifications for shell tasks
      if (task.command.startsWith('shell:')) {
        return;
      }
      
      // Only send queued notification if task won't start immediately
      // This happens when we're at the concurrent limit for the project
      const status = this.taskQueue.getAllTasks();
      const runningClaudeTasks = this.taskQueue.getRunningClaudeTasksForProject(task.cwd);
      const maxConcurrent = this.taskQueue.maxConcurrent;
      const isShellCommand = task.command.startsWith('shell:');
      
      // Send queue message only if:
      // 1. It's a Claude task AND we're at the concurrent limit for Claude tasks, AND
      // 2. There are other tasks pending (this task won't start immediately)
      if (!isShellCommand && runningClaudeTasks >= maxConcurrent && status.pending.length > 1) {
        const displayMode = this.getDisplayModeForChat(task.chatId);

        // In simple mode, skip queued notification - users only want the final result
        if (displayMode === 'simple') {
          logger.info(`[CHATID-TRACK] Skipping 'queued' notification for task ${task.id} (simple mode)`);
        } else {
          this.larkNotifier.sendTaskUpdate(task, 'queued', null, displayMode).catch(error => {
            const errorMsg = formatErrorMessage(error, {
              operation: 'Send Lark task queued notification',
              location: 'task-monitor.js:273'
            });
            logger.error(errorMsg);
          });

          // Also send to Telegram if enabled
          if (this.telegramNotifier && this.telegramNotifier.isEnabled()) {
            this.telegramNotifier.sendTaskUpdate(task, 'queued', task.chatId, displayMode).catch(error => {
              const errorMsg = formatErrorMessage(error, {
                operation: 'Send Telegram task queued notification',
                location: 'task-monitor.js:285'
              });
              logger.error(errorMsg);
            });
          }
        }
      }
      // Note: We don't send "task created" notifications at all anymore - 
      // the task started notification will be sent immediately after if no queue
    });

    this.taskQueue.on('taskOutput', (outputData) => {
      // Emit task output for real-time monitoring
      this.emit('taskOutput', outputData);
    });

    // Handle usage data ready event (fired after async usage calculation completes)
    this.taskQueue.on('taskUsageReady', (task) => {
      logger.info(`[USAGE-READY] Usage data ready for task ${task.id}: $${task.usage?.cost?.toFixed(4) || 0}`);

      // Update Telegram message with usage data if we have a stored message ID
      this.updateTelegramMessageWithUsage(task).catch(error => {
        logger.warn(`[USAGE-READY] Failed to update Telegram message with usage: ${error.message}`);
      });

      // Emit event so external listeners can update UI with usage data
      this.emit('taskUsageReady', task);
    });
  }

  /**
   * Update existing Telegram message with usage data after async calculation
   */
  async updateTelegramMessageWithUsage(task) {
    const messageInfo = this.taskCompletionMessageIds.get(task.id);
    if (!messageInfo) {
      logger.debug(`[USAGE-READY] No stored message ID for task ${task.id}, skipping update`);
      return;
    }

    const { chatId, messageId } = messageInfo;

    // Clean up the stored message ID
    this.taskCompletionMessageIds.delete(task.id);

    // Only update if we have usage data with cost OR tokens
    // This ensures customClaude providers (which use ccusage like Claude) get their usage shown
    if (!task.usage || (task.usage.cost === 0 && (!task.usage.tokens || task.usage.tokens === 0))) {
      logger.debug(`[USAGE-READY] No usage cost or tokens for task ${task.id}, skipping update`);
      return;
    }

    if (!this.telegramNotifier) {
      logger.debug(`[USAGE-READY] No telegram notifier, skipping update`);
      return;
    }

    try {
      const result = task.status === 'completed' ? 'success' : 'error';
      const pendingCount = this.taskQueue.getPendingTasksCountForWorkspace(task.cwd);

      // Update the message with the now-available usage data
      const displayMode = this.getDisplayModeForChat(task.chatId);
      await this.telegramNotifier.sendTaskSummary(
        task,
        result,
        task.usage,
        this.usageReporter,
        chatId,
        messageId,
        pendingCount,
        displayMode
      );

      logger.info(`[USAGE-READY] Updated Telegram message ${messageId} with usage: $${task.usage.cost?.toFixed(4) || 0}`);
    } catch (error) {
      logger.warn(`[USAGE-READY] Failed to update message ${messageId}: ${error.message}`);
    }
  }

  addTask(name, command, options = {}) {
    const taskOptions = {
      timeout: config.tasks.timeoutMs,
      ...options
    };

    // Enhanced logging for chatId tracking
    logger.info(`[CHATID-TRACK] Adding task '${name}' with initial options:`, {
      chatId: options.chatId || 'none',
      cwd: options.cwd || 'none',
      source: options.source || 'unknown'
    });

    // If no chatId provided but we have a working directory, try to find associated chat
    if (!taskOptions.chatId && taskOptions.cwd && this.chatSettings) {
      const associatedChatId = this.chatSettings.getChatForWorkdir(taskOptions.cwd);
      if (associatedChatId) {
        taskOptions.chatId = associatedChatId;
        logger.info(`[CHATID-TRACK] Found associated chat ID ${associatedChatId} for workdir ${taskOptions.cwd}`);
      } else {
        logger.info(`[CHATID-TRACK] No chat ID found for workdir ${taskOptions.cwd}`);
      }
    } else if (taskOptions.chatId) {
      logger.info(`[CHATID-TRACK] Using provided chat ID ${taskOptions.chatId}`);
    }

    // Check if workspace is in yolo mode protection
    if (taskOptions.cwd && this.workspaceManager) {
      // This is async but we'll handle it in the background
      this.checkYoloProtection(taskOptions.cwd, taskOptions.chatId, taskOptions.source).then(isProtected => {
        if (isProtected) {
          logger.warn(`[YOLO-PROTECTION] Task '${name}' attempted in protected workspace during yolo mode`);
        }
      }).catch(err => {
        logger.debug(`Failed to check yolo protection: ${err.message}`);
      });
    }

    const task = this.taskQueue.addTask(name, command, taskOptions);
    logger.info(`[CHATID-TRACK] Created task ${task.id} with final chatId: ${task.chatId || 'none'}`);

    // Log task creation to database
    if (this.workspaceManager) {
      (async () => {
        try {
          // Try to find workspace from cwd or chatId
          let workspaceId = null;
          if (task.cwd) {
            const workspace = await this.workspaceManager.getWorkspaceByPath(task.cwd);
            if (workspace) {
              workspaceId = workspace.id;
            }
          } else if (task.chatId && task.chatId.startsWith('telegram:')) {
            const chatId = task.chatId.replace('telegram:', '');
            const telegramChat = await this.workspaceManager.getTelegramChat(chatId);
            if (telegramChat && telegramChat.workspace_id) {
              workspaceId = telegramChat.workspace_id;
            }
          }

          await this.workspaceManager.logTaskCreated(task, workspaceId);
        } catch (logError) {
          logger.debug('Failed to log task creation to database:', logError.message);
        }
      })().catch(criticalError => {
        // Catch any errors that escape the try-catch to prevent unhandled rejections
        logger.error('Critical error in task creation logging IIFE:', {
          message: criticalError.message,
          stack: criticalError.stack,
          taskId: task.id,
          taskName: task.name
        });
      });
    }

    return task;
  }

  async checkYoloProtection(workdir, chatId, source) {
    // Allow yolo-initiated tasks
    if (source === 'plan_execution' || source === 'yolo') {
      return false;
    }

    try {
      const workspace = await this.workspaceManager.getWorkspaceByPath(workdir);
      if (!workspace) return false;

      const yoloStatus = await this.workspaceManager.getYoloStatus(workspace.id);
      if (!yoloStatus || !yoloStatus.active) return false;

      // Workspace is in yolo mode - send warning to status message
      if (yoloStatus.statusMessageId && chatId && chatId.startsWith('telegram:')) {
        const telegramChatId = chatId.replace('telegram:', '');

        if (this.telegramNotifier) {
          // Update the yolo status message to show protection is active
          // Use persisted message version to maintain continuity
          const statusMessage = await this.telegramNotifier.formatYoloStatusMessage(
            workspace.name,
            yoloStatus.plansTotal,
            yoloStatus.plansCompleted,
            { plan_id: yoloStatus.currentPlan },
            'executing',
            {
              messageVersion: yoloStatus.messageVersion || 0,  // Use persisted version, will be incremented in formatYoloStatusMessage
              startTime: yoloStatus.startTime ? new Date(yoloStatus.startTime).getTime() : Date.now(),
              commits: [],
              usage: { cost: 0, tokens: 0 }
            }
          );

          // Update the persisted message version
          const newVersion = (yoloStatus.messageVersion || 0) + 1;
          await this.workspaceManager.updateYoloMessageVersion(workspace.id, newVersion);

          // CRITICAL: Re-fetch the latest status message ID to avoid race conditions
          // The YOLO execution might have resent the message (delete+send new) between
          // when we read yoloStatus above and now, so we must get the fresh ID
          const freshYoloStatus = await this.workspaceManager.getYoloStatus(workspace.id);
          const currentMessageId = freshYoloStatus?.statusMessageId || yoloStatus.statusMessageId;

          // Just update with the normal status message, no need for extra warning
          // since the status message already shows protection mode is enabled
          const updateResult = await this.telegramNotifier.updateYoloStatus(
            telegramChatId,
            currentMessageId,
            statusMessage
          );

          // If a new message was sent (because the old one didn't exist), update the message ID
          if (updateResult && updateResult.message_id && updateResult.message_id !== currentMessageId) {
            await this.workspaceManager.updateYoloStatusMessageId(workspace.id, updateResult.message_id);
            logger.info(`[YOLO] Updated status message ID from ${currentMessageId} to ${updateResult.message_id} after message not found`);
          }
        }
      }

      return true;
    } catch (error) {
      logger.error(`Error checking yolo protection: ${error.message}`);
      return false;
    }
  }

  cancelTask(taskId) {
    return this.taskQueue.cancelTask(taskId);
  }

  getStatus() {
    return this.taskQueue.getAllTasks();
  }
  
  async getStatusWithProcessInfo() {
    return this.taskQueue.getAllTasksWithProcessInfo();
  }

  getTaskById(taskId) {
    return this.taskQueue.getTaskStatus(taskId);
  }

  getTaskByIndex(index) {
    const status = this.taskQueue.getAllTasks();
    const allTasks = [...status.running, ...status.pending];
    const taskIndex = parseInt(index) - 1; // Convert to 0-based index
    
    if (taskIndex >= 0 && taskIndex < allTasks.length) {
      return allTasks[taskIndex];
    }
    
    return null;
  }

  getQueuePosition(taskId) {
    const status = this.taskQueue.getAllTasks();
    const pendingIndex = status.pending.findIndex(task => task.id === taskId);
    
    if (pendingIndex !== -1) {
      return pendingIndex + 1; // 1-based position
    }
    
    return null; // Not in queue or already running
  }

  isTaskRunning(taskId) {
    return this.taskQueue.isTaskRunning(taskId);
  }

  onTaskOutput(callback) {
    this.taskQueue.on('taskOutput', callback);
  }

  offTaskOutput(callback) {
    this.taskQueue.off('taskOutput', callback);
  }

  getTaskOutput(taskId, type = 'all', lines = null) {
    return this.taskQueue.getTaskOutput(taskId, type, lines);
  }

  getTaskOutputMetrics(taskId) {
    return this.taskQueue.getTaskOutputMetrics(taskId);
  }

  getTaskStaleInfo(taskId) {
    return this.taskQueue.getStaleInfo(taskId);
  }

  setupPeriodicStatusUpdates() {
    // Check if periodic status updates are enabled
    const isEnabled = process.env.LARK_STATUS_UPDATE_ENABLED === 'true';
    const intervalMs = parseInt(process.env.LARK_STATUS_UPDATE_INTERVAL_MS) || 300000; // Default 5 minutes
    
    if (!isEnabled) {
      logger.info('Periodic status updates are disabled');
      return;
    }
    
    logger.info(`Periodic status updates enabled (every ${intervalMs / 1000}s)`);
    
    // Set up the interval
    this.statusUpdateInterval = setInterval(async () => {
      try {
        const status = await this.getStatus();
        
        // Only send updates if there are running tasks
        if (status.running.length === 0) {
          return;
        }
        
        // Get unique chat IDs from running tasks
        const chatIds = new Set();
        status.running.forEach(task => {
          if (task.chatId) {
            chatIds.add(task.chatId);
          }
        });
        
        // Send status update to each relevant chat
        for (const chatId of chatIds) {
          const now = Date.now();
          const lastUpdate = this.lastStatusUpdateTime.get(chatId) || 0;
          
          // Check if enough time has passed since last update for this chat
          if (now - lastUpdate >= intervalMs) {
            // Get tasks for this specific chat
            const chatTasks = status.running.filter(t => t.chatId === chatId);

            // Check if all tasks in this chat are being watched via /progress or have a started placeholder
            // If they are, skip routine status update
            const httpServer = global.httpServer; // Get the HTTP server instance if available
            const allTasksTracked = chatTasks.every(task => {
              // Check progress trackers
              if (httpServer && httpServer.progressTrackers) {
                let trackerChatId = chatId;
                if (chatId.startsWith('telegram:')) {
                  trackerChatId = chatId.replace('telegram:', '');
                }
                const trackerKey = `${trackerChatId}:${task.id}`;
                if (httpServer.progressTrackers.has(trackerKey)) {
                  logger.debug(`Task ${task.id} is being tracked via /progress (key: ${trackerKey})`);
                  return true;
                }
              }
              // Check started placeholder (task will be edited on completion)
              if (this.taskStartedMessageIds.has(task.id)) {
                logger.info(`[CHATUI] Task ${task.id} has started placeholder — skipping periodic status update`);
                return true;
              }
              return false;
            });

            if (allTasksTracked && chatTasks.length > 0) {
              logger.info(`Skipping routine status update for chat ${chatId} - all ${chatTasks.length} tasks are tracked via /progress or started placeholder`);
              continue;
            }

            // In simple mode, skip periodic status updates entirely
            const chatDisplayMode = this.getDisplayModeForChat(chatId);
            if (chatDisplayMode === 'simple') {
              logger.info(`[CHATUI] Skipping periodic status update for chat ${chatId} — display mode is 'simple'`);
              continue;
            }

            // Check if yolo is running and under protection mode
            // If it is, skip routine status update for workspace
            // Check using workspace-utils which checks database for protection status
            const { isWorkspaceInYoloMode } = await import('./utils/workspace-utils.js');
            let isProtected = false;

            // Check each task's workspace for protection
            for (const task of chatTasks) {
              if (task.cwd && await isWorkspaceInYoloMode(task.cwd)) {
                isProtected = true;
                break;
              }
            }

            if (isProtected) {
              logger.info(`Skipping routine status update for chat ${chatId} - yolo protection mode is active`);
              continue;
            }
            
            // Group tasks by workdir
            const tasksByWorkdir = new Map();
            chatTasks.forEach(task => {
              const workdir = task.cwd || 'unknown';
              if (!tasksByWorkdir.has(workdir)) {
                tasksByWorkdir.set(workdir, []);
              }
              tasksByWorkdir.get(workdir).push(task);
            });
            
            // Build a detailed status message grouped by workdir
            let message = `📊 **Running Tasks (${chatTasks.length})**\n\n`;
            
            for (const [workdir, tasks] of tasksByWorkdir) {
              // Show workdir name
              const workdirName = Object.entries(config.lark.workdirs || {})
                .find(([name, path]) => path === workdir)?.[0] || workdir;
              message += `📁 **${workdirName}**\n`;
              
              tasks.forEach(task => {
                const elapsed = task.startedAt ? Math.round((Date.now() - new Date(task.startedAt).getTime()) / 1000) : 0;
                const minutes = Math.floor(elapsed / 60);
                const seconds = elapsed % 60;
                
                // Extract prompt preview (first 30 chars)
                let promptPreview = '';
                if (task.command) {
                  const cleanCommand = task.command.replace(/^-c\s+/, ''); // Remove -c flag
                  promptPreview = cleanCommand.length > 30 
                    ? cleanCommand.substring(0, 27) + '...'
                    : cleanCommand;
                }
                
                message += `• \`${task.id}\` - ${task.name}\n`;
                message += `  ⏱️ ${minutes}m ${seconds}s`;
                if (promptPreview) {
                  message += ` | 📝 "${promptPreview}"`;
                }
                message += `\n`;
              });
              message += `\n`;
            }
            
            // Send to appropriate notifier based on chat ID prefix
            if (chatId.startsWith('telegram:')) {
              const telegramChatId = chatId.replace('telegram:', '');
              if (this.telegramNotifier) {
                await this.telegramNotifier.sendCustomMessage(
                  '🔄 Status Update',
                  message,
                  telegramChatId
                );
                logger.debug(`Sent periodic status update to Telegram chat ${telegramChatId}`);
              }
            } else {
              await this.larkNotifier.sendCustomMessage(
                '🔄 Status Update',
                message,
                'blue',
                chatId
              );
              logger.debug(`Sent periodic status update to Lark chat ${chatId}`);
            }
            
            this.lastStatusUpdateTime.set(chatId, now);
          }
        }
      } catch (error) {
        const errorMsg = formatErrorMessage(error, {
          operation: 'Send periodic status update',
          location: 'task-monitor.js:505'
        });
        logger.error(errorMsg);
      }
    }, intervalMs);
  }
  
  setupDailyReportInterval() {
    // Calculate time until next 15:00 UTC
    const now = new Date();
    const next15UTC = new Date();
    next15UTC.setUTCHours(15, 0, 0, 0);
    
    // If we've already passed 15:00 UTC today, set for tomorrow
    if (now.getTime() > next15UTC.getTime()) {
      next15UTC.setUTCDate(next15UTC.getUTCDate() + 1);
    }
    
    const timeUntilNext = next15UTC.getTime() - now.getTime();
    
    logger.info(`Daily usage report scheduled for ${next15UTC.toISOString()} (in ${Math.round(timeUntilNext / 1000 / 60)} minutes)`);
    
    // Set initial timeout
    setTimeout(() => {
      this.sendScheduledDailyReport();
      // Set up recurring interval every 24 hours
      setInterval(() => {
        this.sendScheduledDailyReport();
      }, 24 * 60 * 60 * 1000);
    }, timeUntilNext);
  }

  async sendScheduledDailyReport() {
    try {
      logger.info('Running scheduled daily usage report check...');

      // Generate the usage report
      const report = await this.usageReporter.generateDailyReport();

      if (report && report.totals) {
        // Send even if cost is $0
        // Get ani-code project's chat ID for daily reports
        const aniCodePath = '/root/workspace/ani-code';
        const chatId = this.chatSettings ? this.chatSettings.getChatForWorkdir(aniCodePath) : null;
        
        // Send to appropriate notifier based on chat ID prefix
        if (chatId && chatId.startsWith('telegram:')) {
          const telegramChatId = chatId.replace('telegram:', '');
          if (this.telegramNotifier) {
            await this.telegramNotifier.sendCustomMessage(
              report.title,
              report.content,
              telegramChatId
            );
            logger.info('Scheduled daily usage report sent successfully to Telegram');
          }
        } else {
          await this.larkNotifier.sendCustomMessage(
            report.title,
            report.content,
            report.color,
            chatId
          );
          logger.info('Scheduled daily usage report sent successfully to Lark');
        }
      } else {
        logger.debug('No usage data for today, skipping daily report');
      }
    } catch (error) {
      const errorMsg = formatErrorMessage(error, {
        operation: 'Send scheduled daily usage report',
        location: 'task-monitor.js:582'
      });
      logger.error(errorMsg);
    }
  }

  async sendDailyUsageReport() {
    try {
      // Check if we should send a report today
      if (!this.usageReporter.shouldSendReport()) {
        logger.debug('Daily usage report already sent today, skipping');
        return;
      }

      // Generate the usage report
      const report = await this.usageReporter.generateDailyReport();
      
      if (report) {
        // Send the report via Lark
        // Get ani-code project's chat ID for daily reports
        const aniCodePath = '/root/workspace/ani-code';
        const chatId = this.chatSettings ? this.chatSettings.getChatForWorkdir(aniCodePath) : null;
        
        // Send to appropriate notifier based on chat ID prefix
        if (chatId && chatId.startsWith('telegram:')) {
          const telegramChatId = chatId.replace('telegram:', '');
          if (this.telegramNotifier) {
            await this.telegramNotifier.sendCustomMessage(
              report.title,
              report.content,
              telegramChatId
            );
            logger.info('Daily usage report sent successfully to Telegram');
          }
        } else {
          await this.larkNotifier.sendCustomMessage(
            report.title,
            report.content,
            report.color,
            chatId
          );
          logger.info('Daily usage report sent successfully to Lark');
        }
      }
    } catch (error) {
      const errorMsg = formatErrorMessage(error, {
        operation: 'Send daily usage report',
        location: 'task-monitor.js:641'
      });
      logger.error(errorMsg);
    }
  }

  getTaskHistory(limit = null) {
    return this.taskQueue.getTaskHistory(limit);
  }

  getHistoryTaskById(taskId) {
    return this.taskQueue.getHistoryById(taskId);
  }

  /**
   * Detect if a completed task only drafted a plan instead of implementing.
   * Checks the session JSONL for ExitPlanMode tool usage and output text patterns.
   * @param {Object} task - The completed task
   * @returns {Promise<boolean>} true if the task entered plan mode
   */
  async detectPlanMode(task) {
    try {
      // Strategy 1: Check session JSONL for plan mode tool usage WITHOUT subsequent implementation
      // A task is only "plan-only" if it entered plan mode and never wrote/edited files afterward
      if (task.cwd) {
        const { ClaudeHistoryViewer } = await import('./claude-history-viewer.js');
        const viewer = new ClaudeHistoryViewer();
        let sessionFile = task.sessionFile;
        if (!sessionFile && task.startedAt) {
          sessionFile = await viewer.findSessionByTaskStartTime(task.cwd, new Date(task.startedAt).toISOString());
        }
        if (!sessionFile) {
          sessionFile = await viewer.findLatestSession(task.cwd);
        }
        if (sessionFile) {
          const { readFile } = await import('fs/promises');
          const content = await readFile(sessionFile, 'utf-8');
          const hasPlanMode = content.includes('"name":"EnterPlanMode"') || content.includes('"name":"ExitPlanMode"');
          if (hasPlanMode) {
            // Check if implementation tools were used AFTER plan mode — if so, task completed implementation
            const implementationTools = ['"name":"Edit"', '"name":"Write"', '"name":"NotebookEdit"'];
            const lastPlanIdx = Math.max(
              content.lastIndexOf('"name":"EnterPlanMode"'),
              content.lastIndexOf('"name":"ExitPlanMode"')
            );
            const afterPlan = content.slice(lastPlanIdx);
            const hasImplementation = implementationTools.some(tool => afterPlan.includes(tool));
            if (!hasImplementation) {
              logger.info(`[PLAN-DETECT] Task ${task.id} session has plan mode without subsequent implementation`);
              return true;
            }
            logger.debug(`[PLAN-DETECT] Task ${task.id} entered plan mode but implemented afterward — not plan-only`);
          }
        }
      }

      // Strategy 2: Fallback — check task.output for plan-mode-only indicators
      if (task.output) {
        const output = task.output;

        // Check if the FIRST line of output contains "The Plan" — typical plan-mode opener
        const firstLine = output.split('\n').find(l => l.trim()) || '';
        if (/\bthe plan\b/i.test(firstLine)) {
          logger.info(`[PLAN-DETECT] Task ${task.id} output first line contains "The Plan"`);
          return true;
        }

        // Also check for strong plan-waiting phrases anywhere in output
        const planOnlyIndicators = [
          /shall i proceed with (?:this|the) (?:plan|implementation)\??/i,
          /ready for (?:your )?(?:approval|review)/i,
          /approve the plan/i,
          /waiting for (?:plan )?approval/i,
          /plan (?:is )?ready for (?:your )?review/i
        ];
        const hasOutputIndicator = planOnlyIndicators.some(regex => regex.test(output));
        if (hasOutputIndicator) {
          logger.info(`[PLAN-DETECT] Task ${task.id} output matches plan-only pattern`);
          return true;
        }
      }

      return false;
    } catch (error) {
      logger.warn(`[PLAN-DETECT] Error detecting plan mode for task ${task.id}: ${error.message}`);
      return false;
    }
  }

  async handleTaskCompleted(task) {
    const duration = task.completedAt - task.startedAt;
    const durationMs = Math.round(duration);

    // Use the task.usage that was already calculated in task-queue.js
    const taskUsage = task.usage || null;

    // Check if task is being tracked via progress and get the message ID if it is
    const httpServer = global.httpServer;
    let progressMessageId = null;
    let progressFromTracker = false; // true = from /progress tracker, false = from started placeholder

    if (httpServer && httpServer.progressTrackers && task.chatId) {
      let trackerChatId = task.chatId;
      if (task.chatId.startsWith('telegram:')) {
        trackerChatId = task.chatId.replace('telegram:', '');
      }
      const trackerKey = `${trackerChatId}:${task.id}`;
      const tracker = httpServer.progressTrackers.get(trackerKey);

      if (tracker) {
        progressMessageId = tracker.messageId;
        // Only flag as "from tracker" if it's a real /progress tracker, not our placeholder
        progressFromTracker = !tracker.fromPlaceholder;
        logger.info(`[PROGRESS-TRACK] Task ${task.id} tracked via ${tracker.fromPlaceholder ? 'started placeholder' : '/progress'}, will update message ${progressMessageId}`);

        // Unpin the message if it was pinned
        if (tracker.isPinned) {
          try {
            const chatIdNumeric = trackerChatId;
            await this.telegramNotifier.unpinChatMessage(chatIdNumeric, tracker.messageId);
            logger.info(`[AUTO-PIN] Unpinned progress message ${tracker.messageId} after task completion`);
          } catch (unpinError) {
            logger.warn(`[AUTO-PIN] Failed to unpin message: ${unpinError.message}`);
          }
        }

        // Clear the tracker interval since task is complete
        if (tracker.interval) {
          clearInterval(tracker.interval);
        }
        httpServer.progressTrackers.delete(trackerKey);
      }
    }

    // Fallback: await the "task started" placeholder promise to get the message ID
    // This only fires if progress tracking wasn't set up (e.g., fast-completing task before 5s delay)
    if (!progressMessageId && this.taskStartedMessageIds.has(task.id)) {
      const entry = this.taskStartedMessageIds.get(task.id);
      this.taskStartedMessageIds.delete(task.id);
      if (entry?.promise) {
        try {
          const startedMsg = await entry.promise;
          if (startedMsg?.messageId) {
            progressMessageId = startedMsg.messageId;
            logger.info(`[PROGRESS-PLACEHOLDER] Using started placeholder message ${progressMessageId} for task ${task.id}`);
          } else {
            logger.warn(`[PROGRESS-PLACEHOLDER] No placeholder message available for task ${task.id} (YOLO blocked or send failed)`);
          }
        } catch (error) {
          logger.warn(`[PROGRESS-PLACEHOLDER] Error awaiting placeholder promise for task ${task.id}: ${error.message}`);
        }
      }
    }

    // Get pending tasks count for the same workspace
    const pendingCount = this.taskQueue.getPendingTasksCountForWorkspace(task.cwd);

    // Resolve display mode for this chat
    const displayMode = this.getDisplayModeForChat(task.chatId);

    // Update plan step status if this task is part of a plan
    if (task.planId && task.stepIndex !== undefined && task.workspaceId) {
      try {
        const { WorkspaceManager } = await import('./workspace-manager.js');
        const manager = new WorkspaceManager();
        await manager.initialize();

        // Update the plan step status based on task completion
        const stepStatus = task.status === 'completed' ? 'completed' : 'failed';
        await manager.updatePlanStep(task.workspaceId, task.planId, task.stepIndex, {
          status: stepStatus,
          completedAt: new Date().toISOString()
        });

        // If this step completed successfully, update plan's current_step to the next step
        if (task.status === 'completed') {
          const plan = await manager.getPlan(task.workspaceId, task.planId);
          if (plan && plan.steps) {
            const nextStepIndex = task.stepIndex + 1;
            if (nextStepIndex < plan.steps.length) {
              // Move to the next step
              await manager.updatePlanStatus(task.workspaceId, task.planId, 'in_progress', nextStepIndex);
              logger.info(`Plan ${task.planId} moved to step ${nextStepIndex + 1}/${plan.steps.length}`);
            } else {
              // All steps completed
              await manager.updatePlanStatus(task.workspaceId, task.planId, 'completed');
              logger.info(`Plan ${task.planId} completed - all steps finished`);
            }
          }
        } else {
          // If step failed, keep the current_step at this position so retry can work
          logger.info(`Plan ${task.planId} step ${task.stepIndex + 1} failed - plan remains at current step`);
        }

        await manager.close();
      } catch (error) {
        logger.error(`Failed to update plan step status: ${error.message}`);
      }
    }

    if (task.status === 'completed') {
      logger.success(`[CHATID-TRACK] Task completed: ${task.name} (${durationMs}ms) - chatId: ${task.chatId || 'none'}`);
      logger.info(`[CHATID-TRACK] Sending 'success' notification for task ${task.id} to chatId: ${task.chatId || 'default'}`);

      // Send gateway callback for task completed
      if (this.gatewayCallbackEnabled && task.metadata?.source === 'gateway') {
        // Delete progress messages (both tracker and placeholder) for gateway tasks
        // Gateway tasks should have progress messages cleaned up since completion is sent fresh
        if (progressMessageId && task.chatId && task.chatId.startsWith('telegram:')) {
          const telegramChatId = task.chatId.replace('telegram:', '');
          if (this.telegramNotifier) {
            logger.info(`[Gateway] Deleting progress message ${progressMessageId} (fromTracker=${progressFromTracker}) before sending completion message`);
            this.telegramNotifier.deleteMessage(telegramChatId, progressMessageId).catch(error => {
              logger.error(`[Gateway] Failed to delete progress message: ${error.message}`);
            });
            // Clear progressMessageId so sendTaskSummary doesn't try to edit a deleted message
            progressMessageId = null;
          }
        }

        this.notifyGateway(task, 'completed', 100, task.output).catch(error => {
          logger.error(`[Gateway] Failed to send completed callback: ${error.message}`);
        });
      }

      // Send notification based on chat ID prefix
      if (task.chatId && task.chatId.startsWith('telegram:')) {
        const telegramChatId = task.chatId.replace('telegram:', '');
        if (this.telegramNotifier) {
          // Pass the messageId to update existing message if available
          // Store message ID for later usage update (usage is calculated async)
          this.telegramNotifier.sendTaskSummary(task, 'success', taskUsage, this.usageReporter, telegramChatId, progressMessageId, pendingCount, displayMode)
            .then(result => {
              // Store message ID for usage update if usage not yet available
              if (result?.result?.message_id && !taskUsage) {
                this.taskCompletionMessageIds.set(task.id, {
                  chatId: telegramChatId,
                  messageId: result.result.message_id
                });
                logger.debug(`[COMPLETION] Stored message ID ${result.result.message_id} for task ${task.id} usage update`);
              }

              // Check if task drafted a plan instead of implementing — send follow-up after summary
              return this.detectPlanMode(task).then(isPlanMode => {
                if (isPlanMode) {
                  logger.info(`[PLAN-DETECT] Task ${task.id} detected as plan-only, sending follow-up message`);
                  const escapedTaskId = task.id.replace(/_/g, '\\_');
                  const planMessage = `🗒 Task \`${escapedTaskId}\` drafted a plan instead of implementing it.\nTap below to continue and execute the plan.`;
                  const continueButton = {
                    inline_keyboard: [[{
                      text: '🚀 Continue & Implement',
                      callback_data: JSON.stringify({ a: 'plc', t: task.id })
                    }]]
                  };
                  return this.telegramNotifier.sendMessage(telegramChatId, planMessage, {
                    parse_mode: 'Markdown',
                    reply_markup: continueButton
                  }).catch(err => {
                    logger.warn(`[PLAN-DETECT] Failed to send plan follow-up: ${err.message}`);
                  });
                }
              }).catch(err => {
                logger.warn(`[PLAN-DETECT] Plan detection failed: ${err.message}`);
              });
            })
            .catch(error => {
              const errorMsg = formatErrorMessage(error, {
                operation: 'Send Telegram task completion notification',
                location: 'task-monitor.js:145'
              });
              logger.error(errorMsg);
            });
        }
      } else {
        this.larkNotifier.sendTaskSummary(task, 'success', taskUsage, this.usageReporter, null, pendingCount, displayMode).catch(error => {
          const errorMsg = formatErrorMessage(error, {
            operation: 'Send Lark task completion notification',
            location: 'task-monitor.js:159'
          });
          logger.error(errorMsg);
        });
      }
    } else {
      logger.error(`[CHATID-TRACK] Task failed: ${task.name} - ${task.error} - chatId: ${task.chatId || 'none'}`);
      logger.info(`[CHATID-TRACK] Sending 'error' notification for task ${task.id} to chatId: ${task.chatId || 'default'}`);

      // Send gateway callback for task failed
      if (this.gatewayCallbackEnabled && task.metadata?.source === 'gateway') {
        // Delete progress messages (both tracker and placeholder) for gateway tasks
        // Gateway tasks should have progress messages cleaned up since failure is sent fresh
        if (progressMessageId && task.chatId && task.chatId.startsWith('telegram:')) {
          const telegramChatId = task.chatId.replace('telegram:', '');
          if (this.telegramNotifier) {
            logger.info(`[Gateway] Deleting progress message ${progressMessageId} (fromTracker=${progressFromTracker}) before sending failure message`);
            this.telegramNotifier.deleteMessage(telegramChatId, progressMessageId).catch(error => {
              logger.error(`[Gateway] Failed to delete progress message: ${error.message}`);
            });
            progressMessageId = null;
          }
        }

        this.notifyGateway(task, 'failed', task.progress || 0, null, task.error).catch(error => {
          logger.error(`[Gateway] Failed to send failed callback: ${error.message}`);
        });
      }

      // Send notification based on chat ID prefix
      if (task.chatId && task.chatId.startsWith('telegram:')) {
        const telegramChatId = task.chatId.replace('telegram:', '');
        if (this.telegramNotifier) {
          // Pass the messageId to update existing message if available
          // Store message ID for later usage update (usage is calculated async)
          this.telegramNotifier.sendTaskSummary(task, 'error', taskUsage, this.usageReporter, telegramChatId, progressMessageId, pendingCount, displayMode)
            .then(result => {
              // Store message ID for usage update if usage not yet available
              if (result?.result?.message_id && !taskUsage) {
                this.taskCompletionMessageIds.set(task.id, {
                  chatId: telegramChatId,
                  messageId: result.result.message_id
                });
                logger.debug(`[COMPLETION] Stored message ID ${result.result.message_id} for task ${task.id} usage update`);
              }
            })
            .catch(error => {
              const errorMsg = formatErrorMessage(error, {
                operation: 'Send Telegram task failure notification',
                location: 'task-monitor.js:174'
              });
              logger.error(errorMsg);
            });
        }
      } else {
        this.larkNotifier.sendTaskSummary(task, 'error', taskUsage, this.usageReporter, null, pendingCount, displayMode).catch(error => {
          const errorMsg = formatErrorMessage(error, {
            operation: 'Send Lark task failure notification',
            location: 'task-monitor.js:185'
          });
          logger.error(errorMsg);
        });
      }
    }

    // Always clean up started placeholder entry (may already be deleted by fallback above)
    this.taskStartedMessageIds.delete(task.id);
  }

  async handleTaskCancelled(task) {
    const duration = task.completedAt - task.startedAt;
    const durationMs = Math.round(duration);

    // Use the task.usage that was already calculated in task-queue.js
    const taskUsage = task.usage || null;

    logger.warn(`Task cancelled: ${task.name} (${durationMs}ms)`);

    // Check if task is being tracked via progress and get the message ID if it is
    const httpServer = global.httpServer;
    let progressMessageId = null;

    if (httpServer && httpServer.progressTrackers && task.chatId) {
      let trackerChatId = task.chatId;
      if (task.chatId.startsWith('telegram:')) {
        trackerChatId = task.chatId.replace('telegram:', '');
      }
      const trackerKey = `${trackerChatId}:${task.id}`;
      const tracker = httpServer.progressTrackers.get(trackerKey);

      if (tracker) {
        progressMessageId = tracker.messageId;
        logger.info(`[PROGRESS-TRACK] Task ${task.id} tracked via ${tracker.fromPlaceholder ? 'started placeholder' : '/progress'}, will update message ${progressMessageId}`);

        // Unpin the message if it was pinned
        if (tracker.isPinned) {
          try {
            const chatIdNumeric = trackerChatId;
            await this.telegramNotifier.unpinChatMessage(chatIdNumeric, tracker.messageId);
            logger.info(`[AUTO-PIN] Unpinned progress message ${tracker.messageId} after task cancellation`);
          } catch (unpinError) {
            logger.warn(`[AUTO-PIN] Failed to unpin message: ${unpinError.message}`);
          }
        }

        // Clear the tracker interval since task is cancelled
        if (tracker.interval) {
          clearInterval(tracker.interval);
        }
        httpServer.progressTrackers.delete(trackerKey);
      }
    }

    // Fallback: await the "task started" placeholder promise to get the message ID
    if (!progressMessageId && this.taskStartedMessageIds.has(task.id)) {
      const entry = this.taskStartedMessageIds.get(task.id);
      this.taskStartedMessageIds.delete(task.id);
      if (entry?.promise) {
        try {
          const startedMsg = await entry.promise;
          if (startedMsg?.messageId) {
            progressMessageId = startedMsg.messageId;
            logger.info(`[PROGRESS-PLACEHOLDER] Using started placeholder message ${progressMessageId} for cancelled task ${task.id}`);
          } else {
            logger.warn(`[PROGRESS-PLACEHOLDER] No placeholder message available for cancelled task ${task.id} (YOLO blocked or send failed)`);
          }
        } catch (error) {
          logger.warn(`[PROGRESS-PLACEHOLDER] Error awaiting placeholder promise for cancelled task ${task.id}: ${error.message}`);
        }
      }
    }

    // Get pending tasks count for the same workspace
    const pendingCount = this.taskQueue.getPendingTasksCountForWorkspace(task.cwd);
    const cancelDisplayMode = this.getDisplayModeForChat(task.chatId);

    // Delete progress messages for gateway-sourced cancelled tasks
    if (this.gatewayCallbackEnabled && task.metadata?.source === 'gateway') {
      if (progressMessageId && task.chatId && task.chatId.startsWith('telegram:')) {
        const telegramChatId = task.chatId.replace('telegram:', '');
        if (this.telegramNotifier) {
          logger.info(`[Gateway] Deleting progress message ${progressMessageId} before sending cancellation message`);
          this.telegramNotifier.deleteMessage(telegramChatId, progressMessageId).catch(error => {
            logger.error(`[Gateway] Failed to delete progress message: ${error.message}`);
          });
          progressMessageId = null;
        }
      }
    }

    // Send notification based on chat ID prefix
    if (task.chatId && task.chatId.startsWith('telegram:')) {
      const telegramChatId = task.chatId.replace('telegram:', '');
      if (this.telegramNotifier) {
        // Pass the messageId to update existing message if available
        this.telegramNotifier.sendTaskSummary(task, 'cancelled', taskUsage, this.usageReporter, telegramChatId, progressMessageId, pendingCount, cancelDisplayMode).catch(error => {
          const errorMsg = formatErrorMessage(error, {
            operation: 'Send Telegram task cancellation notification',
            location: 'task-monitor.js:238'
          });
          logger.error(errorMsg);
        });
      }
    } else {
      this.larkNotifier.sendTaskSummary(task, 'cancelled', taskUsage, this.usageReporter, null, pendingCount, cancelDisplayMode).catch(error => {
        const errorMsg = formatErrorMessage(error, {
          operation: 'Send Lark task cancellation notification',
          location: 'task-monitor.js:246'
        });
        logger.error(errorMsg);
      });
    }

    // Always clean up started placeholder entry
    this.taskStartedMessageIds.delete(task.id);
  }
  
  async autoTriggerProgress(task) {
    try {
      // Only auto-trigger for Telegram chats currently
      if (!task.chatId || !task.chatId.startsWith('telegram:')) {
        return; // Silently skip non-Telegram
      }

      // Check if workspace is in YOLO mode using utility
      const { shouldBlockTaskNotification } = await import('./utils/workspace-utils.js');
      if (await shouldBlockTaskNotification(task)) {
        return; // Silently skip during YOLO mode
      }

      const telegramChatId = task.chatId.replace('telegram:', '');
      const httpServer = global.httpServer;

      if (!httpServer || !httpServer.handleProgressCommand) {
        logger.warn('[AUTO-PROGRESS] HTTP server not available for auto-progress');
        return;
      }

      // Check if progress is already being tracked for this task
      const trackerKey = `${telegramChatId}:${task.id}`;
      if (httpServer.progressTrackers && httpServer.progressTrackers.has(trackerKey)) {
        logger.debug(`[AUTO-PROGRESS] Progress already being tracked for task ${task.id}`);
        return;
      }

      logger.info(`[AUTO-PROGRESS] Starting auto-progress tracking for task ${task.id} in chat ${telegramChatId}`);

      // Call the progress command handler directly
      await httpServer.handleProgressCommand(telegramChatId, task.id);

      logger.info(`[AUTO-PROGRESS] Successfully started progress tracking for task ${task.id}`);
    } catch (error) {
      const errorMsg = formatErrorMessage(error, {
        operation: `Auto-trigger progress for task ${task.id}`,
        location: 'task-monitor.js:685'
      });
      logger.error(`[AUTO-PROGRESS] ${errorMsg}`);
    }
  }
  
  cleanup() {
    // Clear the periodic status update interval
    if (this.statusUpdateInterval) {
      clearInterval(this.statusUpdateInterval);
      this.statusUpdateInterval = null;
      logger.info('Stopped periodic status updates');
    }

    // Clear the snapshot cleanup interval
    if (this.snapshotCleanupInterval) {
      clearInterval(this.snapshotCleanupInterval);
      this.snapshotCleanupInterval = null;
      logger.info('Stopped snapshot cleanup interval');
    }
  }

  setupSnapshotCleanup() {
    // Clean up old task snapshots every hour to prevent memory leaks
    const cleanupIntervalMs = 60 * 60 * 1000; // 1 hour
    const snapshotMaxAgeHours = 24; // Keep snapshots for 24 hours

    logger.info(`[MEMORY] Snapshot cleanup scheduled every ${cleanupIntervalMs / 1000 / 60} minutes (max age: ${snapshotMaxAgeHours}h)`);

    this.snapshotCleanupInterval = setInterval(() => {
      try {
        const beforeSize = this.taskQueue.usageReporter.taskSnapshots.size;
        this.taskQueue.cleanupOldSnapshots(snapshotMaxAgeHours);
        const afterSize = this.taskQueue.usageReporter.taskSnapshots.size;

        if (beforeSize !== afterSize) {
          logger.info(`[MEMORY] Cleaned up ${beforeSize - afterSize} old task snapshots (${afterSize} remaining)`);
        }
      } catch (error) {
        logger.error(`[MEMORY] Failed to cleanup task snapshots: ${error.message}`);
      }

      // Clean up stale started placeholder entries (older than 1 hour)
      try {
        const staleThreshold = Date.now() - (60 * 60 * 1000);
        let staleCount = 0;
        for (const [taskId, entry] of this.taskStartedMessageIds) {
          if (entry.createdAt && entry.createdAt < staleThreshold) {
            this.taskStartedMessageIds.delete(taskId);
            staleCount++;
          }
        }
        if (staleCount > 0) {
          logger.info(`[MEMORY] Cleaned up ${staleCount} stale started placeholder entries`);
        }
      } catch (error) {
        logger.error(`[MEMORY] Failed to cleanup stale placeholders: ${error.message}`);
      }
    }, cleanupIntervalMs);

    // Also run cleanup immediately on startup to clean any stale data
    setTimeout(() => {
      try {
        const beforeSize = this.taskQueue.usageReporter.taskSnapshots.size;
        this.taskQueue.cleanupOldSnapshots(snapshotMaxAgeHours);
        const afterSize = this.taskQueue.usageReporter.taskSnapshots.size;
        logger.info(`[MEMORY] Initial snapshot cleanup: ${beforeSize - afterSize} removed (${afterSize} remaining)`);
      } catch (error) {
        logger.error(`[MEMORY] Initial snapshot cleanup failed: ${error.message}`);
      }
    }, 5000); // Run 5 seconds after startup
  }

  async notifyGateway(task, status, progress = 0, output = null, error = null) {
    if (!this.gatewayCallbackEnabled) {
      return;
    }

    const callbackUrl = `${config.gateway.callbackUrl}/api/callback/task-status`;

    // Extract metadata from task
    const duration = task.completedAt && task.startedAt ?
      task.completedAt - task.startedAt : 0;
    const model = task.parsedModel || task.model || 'claude-sonnet-4';

    // Build usage object with full details for gateway
    const usage = task.usage ? {
      tokens: task.usage.tokens || 0,
      inputTokens: task.usage.inputTokens || 0,
      outputTokens: task.usage.outputTokens || 0,
      cacheReadTokens: task.usage.cacheReadTokens || 0,
      cost: task.usage.cost || 0,
      modelsUsed: task.usage.modelsUsed || [],
      usageV2: task.usage.usageV2 || []
    } : null;

    // Resolve display mode for structured data
    const chatDisplayMode = this.getDisplayModeForChat(task.chatId);

    // Format duration for structured data
    const durationSeconds = Math.round(duration / 1000);
    const durationMinutes = Math.floor(durationSeconds / 60);
    const durationHours = Math.floor(durationMinutes / 60);
    let durationFormatted;
    if (durationHours > 0) {
      durationFormatted = `${durationHours}h ${durationMinutes % 60}m`;
    } else if (durationMinutes > 0) {
      durationFormatted = `${durationMinutes}m ${durationSeconds % 60}s`;
    } else {
      durationFormatted = `${durationSeconds}s`;
    }

    const payload = {
      taskId: task.id,
      workspaceId: task.metadata?.workspace_id || config.gateway?.workspaceId || 'default',
      projectId: task.metadata?.project_id || config.gateway?.projectId || 'default',
      status,
      progress,
      output: output || null,
      error: error || null,
      timestamp: new Date().toISOString(),
      metadata: {
        duration,
        tokensUsed: usage?.tokens || 0,
        model,
        hasImages: task.metadata?.hasImages || false,
        imageCount: task.metadata?.imageCount || 0,
        displayMode: chatDisplayMode
      },
      // Structured data for gateway consumers (Goal 011)
      structured: {
        taskId: task.id,
        taskName: task.name || '',
        contentOnly: output ? output.replace(/\x1b\[[0-9;]*m/g, '') : null,
        duration: durationFormatted,
        exitCode: task.exitCode ?? null
      },
      // Include full usage data for cost tracking
      usage
    };

    // Retry logic with exponential backoff
    const maxRetries = config.gateway?.retryAttempts || 3;
    const baseDelay = config.gateway?.retryBaseDelay || 1000;

    // Build headers with optional HMAC signature (Goal 269 - Security Hardening)
    const projectId = payload.projectId;
    const headers = {
      'Content-Type': 'application/json',
      'X-API-Key': config.gateway.apiKey,
      'X-Project-Id': projectId
    };

    // Add HMAC signature and capability header if signing key is configured
    if (config.gateway.signingKey) {
      const { timestamp, signature } = generateCallbackSignature(
        projectId,
        payload,
        config.gateway.signingKey
      );
      headers['X-Callback-Timestamp'] = timestamp;
      headers['X-Callback-Signature'] = signature;
      headers['X-Supports-Callback-Signing'] = 'true';  // Capability header for gateway validation
    }

    for (let attempt = 0; attempt < maxRetries; attempt++) {
      try {
        logger.debug(`[Gateway] Sending callback (attempt ${attempt + 1}/${maxRetries}):`, {
          taskId: task.id,
          status,
          url: callbackUrl,
          signed: !!config.gateway.signingKey
        });

        const response = await fetch(callbackUrl, {
          method: 'POST',
          headers,
          body: JSON.stringify(payload),
          timeout: 10000 // 10 second timeout
        });

        if (response.ok) {
          logger.info(`[Gateway] Callback sent successfully: ${task.id} | ${status}`);
          return;
        } else {
          const responseText = await response.text();
          logger.warn(`[Gateway] Callback failed (${response.status}): ${responseText}`);

          if (attempt < maxRetries - 1) {
            const delay = baseDelay * Math.pow(2, attempt);
            logger.info(`[Gateway] Retrying in ${delay}ms...`);
            await new Promise(resolve => setTimeout(resolve, delay));
          }
        }
      } catch (error) {
        logger.error(`[Gateway] Callback error (attempt ${attempt + 1}): ${error.message}`);

        if (attempt < maxRetries - 1) {
          const delay = baseDelay * Math.pow(2, attempt);
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }
    }

    // All retries failed - log to failed callbacks
    logger.error(`[Gateway] All callback attempts failed for task ${task.id}`);
    this.logFailedCallback(payload);
  }

  /**
   * Notify gateway when a task's channel has been redirected
   * This allows the gateway to send messages to the new channel (e.g., Telegram)
   * @param {Object} task - The task that was redirected
   * @param {string} previousChatId - The previous chat ID
   * @param {string} previousSource - The previous source (e.g., 'gateway')
   */
  async notifyGatewayChannelRedirect(task, previousChatId, previousSource) {
    if (!this.gatewayCallbackEnabled) {
      return;
    }

    const callbackUrl = `${config.gateway.callbackUrl}/api/callback/task-status`;

    const payload = {
      taskId: task.id,
      workspaceId: task.metadata?.workspace_id || config.gateway?.workspaceId || 'default',
      projectId: task.metadata?.project_id || config.gateway?.projectId || 'default',
      status: 'channel_redirected',
      progress: task.progress || 0,
      output: null,
      error: null,
      timestamp: new Date().toISOString(),
      metadata: {
        model: task.model || 'claude-sonnet-4',
        hasImages: task.metadata?.hasImages || false,
        imageCount: task.metadata?.imageCount || 0
      },
      channelRedirect: {
        previousChatId,
        previousSource,
        newChatId: task.chatId,
        newSource: task.source || 'telegram'
      }
    };

    // Build headers with optional HMAC signature (Goal 269 - Security Hardening)
    const projectId = payload.projectId;
    const headers = {
      'Content-Type': 'application/json',
      'X-API-Key': config.gateway.apiKey,
      'X-Project-Id': projectId
    };

    // Add HMAC signature and capability header if signing key is configured
    if (config.gateway.signingKey) {
      const { timestamp, signature } = generateCallbackSignature(
        projectId,
        payload,
        config.gateway.signingKey
      );
      headers['X-Callback-Timestamp'] = timestamp;
      headers['X-Callback-Signature'] = signature;
      headers['X-Supports-Callback-Signing'] = 'true';  // Capability header for gateway validation
    }

    // Single attempt for channel redirect (not critical enough for retries)
    try {
      logger.debug(`[Gateway] Sending channel_redirected callback:`, {
        taskId: task.id,
        previousChatId,
        newChatId: task.chatId,
        signed: !!config.gateway.signingKey
      });

      const response = await fetch(callbackUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify(payload),
        timeout: 10000
      });

      if (response.ok) {
        logger.info(`[Gateway] Channel redirect callback sent: ${task.id} -> ${task.chatId}`);
      } else {
        const responseText = await response.text();
        logger.warn(`[Gateway] Channel redirect callback failed (${response.status}): ${responseText}`);
      }
    } catch (error) {
      logger.error(`[Gateway] Channel redirect callback error: ${error.message}`);
    }
  }

  logFailedCallback(payload) {
    const failedCallback = {
      timestamp: new Date().toISOString(),
      payload
    };

    this.failedCallbacks.push(failedCallback);

    // Trim array if it exceeds max size to prevent memory growth
    if (this.failedCallbacks.length > this.maxFailedCallbacks) {
      const removed = this.failedCallbacks.length - this.maxFailedCallbacks;
      this.failedCallbacks = this.failedCallbacks.slice(-this.maxFailedCallbacks);
      logger.debug(`[MEMORY] Trimmed ${removed} old failed callbacks (keeping ${this.maxFailedCallbacks})`);
    }

    // Also log to file if configured
    try {
      const fs = require('fs');
      const path = require('path');
      const logDir = '/var/log/ani-code';
      const logFile = path.join(logDir, 'failed-callbacks.jsonl');

      // Create directory if it doesn't exist
      if (!fs.existsSync(logDir)) {
        fs.mkdirSync(logDir, { recursive: true });
      }

      fs.appendFileSync(logFile, JSON.stringify(failedCallback) + '\n');
      logger.info(`[Gateway] Failed callback logged to ${logFile}`);
    } catch (error) {
      logger.error(`[Gateway] Failed to write callback log: ${error.message}`);
    }
  }
}

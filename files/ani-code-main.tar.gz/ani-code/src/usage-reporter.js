import { execSync, exec } from 'child_process';
import { promisify } from 'util';
import { logger } from './logger.js';
import { normalizeModelName } from './utils/model-normalizer.js';

const execAsync = promisify(exec);

export class UsageReporter {
  constructor() {
    this.lastReportDate = null;
    this.previousDayData = null;
    this.taskSnapshots = new Map(); // Store before/after snapshots for tasks
  }

  async generateDailyReport(force = false) {
    try {
      const today = new Date();
      const dateStr = today.toISOString().split('T')[0].replace(/-/g, '');
      
      // Check if we already sent a report today (skip check if forced)
      if (!force && this.lastReportDate === dateStr) {
        logger.debug('Daily usage report already sent today');
        return null;
      }

      logger.info('Generating daily usage report...');
      
      // Run ccusage command asynchronously with timing
      const command = `npx ccusage -i --offline --since ${dateStr} -j`;
      const startTime = Date.now();
      logger.debug(`[CCUSAGE] Starting daily report generation...`);
      
      const { stdout, stderr } = await execAsync(command, { encoding: 'utf8', timeout: 60000 }); // 60 second timeout for daily report
      
      const duration = Date.now() - startTime;
      logger.info(`[CCUSAGE] Daily report generated in ${duration}ms`);

      const output = stdout;

      let usageData;
      try {
        usageData = JSON.parse(output);
      } catch (parseError) {
        logger.error(`❌ [DAILY_REPORT] BROKEN DATA: Failed to parse JSON for daily report (${dateStr})`);
        logger.error(`[DAILY_REPORT] Parse error: ${parseError.message}`);
        logger.error(`[DAILY_REPORT] Raw stdout (first 500 chars): ${output.substring(0, 500)}`);
        return null;
      }

      // Validate report data structure
      if (!usageData || typeof usageData !== 'object') {
        logger.error(`❌ [DAILY_REPORT] BROKEN DATA: Invalid usageData structure for date ${dateStr}`);
        logger.error(`[DAILY_REPORT] Raw data: ${JSON.stringify(usageData)}`);
        return null;
      }

      if (!usageData.totals || typeof usageData.totals !== 'object') {
        logger.error(`❌ [DAILY_REPORT] BROKEN DATA: Missing or invalid totals for date ${dateStr}`);
        logger.error(`[DAILY_REPORT] usageData structure: ${JSON.stringify(Object.keys(usageData))}`);
        return null;
      }
      
      // Check if this is a subsequent request for the same day
      const previousData = this.lastReportDate === dateStr ? this.previousDayData : null;
      
      // Update tracking data
      this.lastReportDate = dateStr;
      this.previousDayData = JSON.parse(JSON.stringify(usageData)); // Deep copy

      return await this.formatUsageReport(usageData, dateStr, previousData);
    } catch (error) {
      logger.error('Failed to generate usage report:', error);
      
      // Log more details about the error
      if (error.stderr) {
        logger.error(`[CCUSAGE] stderr output: ${error.stderr}`);
      }
      if (error.stdout) {
        // Only log first 500 chars of stdout to avoid huge logs
        const truncatedOutput = error.stdout.substring(0, 500);
        logger.error(`[CCUSAGE] stdout output (first 500 chars): ${truncatedOutput}`);
      }
      if (error.code !== undefined) {
        logger.error(`[CCUSAGE] Exit code: ${error.code}`);
      }
      if (error.signal) {
        logger.error(`[CCUSAGE] Terminated by signal: ${error.signal}`);
      }
      
      return null;
    }
  }

  async formatUsageReport(usageData, dateStr, previousData = null) {
    const totals = usageData.totals;

    // Format date for display
    const displayDate = `${dateStr.slice(0, 4)}-${dateStr.slice(4, 6)}-${dateStr.slice(6, 8)}`;

    // Format cost without unnecessary decimals
    const formatCost = (cost) => {
      const rounded = Math.round(cost * 100) / 100;
      return rounded.toFixed(2).replace(/\.00$/, '');
    };

    // Format tokens with K/M suffix
    const formatTokens = (tokens) => {
      if (tokens >= 1000000) {
        return `${(tokens / 1000000).toFixed(1)}M`;
      } else if (tokens >= 1000) {
        return `${(tokens / 1000).toFixed(1)}K`;
      }
      return tokens.toLocaleString();
    };

    // Get today's stats from stats DB (more accurate than ccusage)
    let dailyCost = totals.totalCost;
    let dailyInputTokens = totals.inputTokens || 0;
    let dailyOutputTokens = totals.outputTokens || 0;

    try {
      const { getStatsDB } = await import('./stats-db.js');
      const statsDB = getStatsDB();

      const todayStart = new Date();
      todayStart.setHours(0, 0, 0, 0);
      const todayStats = await statsDB.getTaskStats(todayStart, new Date());

      if (todayStats && todayStats.totalCost !== null) {
        dailyCost = todayStats.totalCost || 0;
        dailyInputTokens = todayStats.totalInputTokens || 0;
        dailyOutputTokens = todayStats.totalOutputTokens || 0;
      }
    } catch (error) {
      // Fallback to ccusage data if stats DB fails
      logger.warn('Using ccusage data for daily totals (stats DB unavailable):', error.message);
    }

    // Start with plain text total for clean look
    const costStr = formatCost(dailyCost);
    const sections = [`💰 *Daily: $${costStr}* • ${formatTokens(dailyInputTokens)} in / ${formatTokens(dailyOutputTokens)} out`];

    // Get Claude API usage information
    let claudeUsage = null;
    try {
      const { getClaudeUsage } = await import('./claude-usage.js');
      claudeUsage = await getClaudeUsage();

      if (claudeUsage && (claudeUsage.currentSession !== null || claudeUsage.weekOpus !== null)) {
        const claudeLines = [];

        // Add plan name if available
        if (claudeUsage.currentPlan) {
          claudeLines.push(claudeUsage.currentPlan, '');
        }

        if (claudeUsage.currentSession !== null) {
          const icon = claudeUsage.currentSession > 80 ? '!! ' : claudeUsage.currentSession > 60 ? '!  ' : '';
          claudeLines.push(`${icon}Session:     ${claudeUsage.currentSession}%`);
        }

        if (claudeUsage.weekAllModels !== null) {
          const icon = claudeUsage.weekAllModels > 80 ? '!! ' : claudeUsage.weekAllModels > 60 ? '!  ' : '';
          claudeLines.push(`${icon}Week (All):  ${claudeUsage.weekAllModels}%`);
        }

        if (claudeUsage.weekOpus !== null) {
          const icon = claudeUsage.weekOpus > 80 ? '!! ' : claudeUsage.weekOpus > 60 ? '!  ' : '';
          claudeLines.push(`${icon}Week (Opus): ${claudeUsage.weekOpus}%`);

          // Add reset time and depletion estimate on second line
          if (claudeUsage.weekOpusResetInfo) {
            const resetInfo = claudeUsage.weekOpusResetInfo;
            const days = resetInfo.daysUntilReset;
            const hours = resetInfo.hoursUntilReset % 24;
            const timeStr = days > 0 ? `${days}d ${hours}h` : `${hours}h`;

            let resetLine = '  ';

            if (claudeUsage.weekOpusResetTime) {
              resetLine += `Reset: ${claudeUsage.weekOpusResetTime} (${timeStr})`;
            }

            // Calculate depletion estimate if usage will exceed 100%
            if (resetInfo.projectedUsage && resetInfo.projectedUsage > 100) {
              const usageRate = claudeUsage.weekOpus / resetInfo.percentTimeElapsed * 100;
              const daysUntilDepleted = Math.floor((100 - claudeUsage.weekOpus) / (usageRate / 24));
              const hoursUntilDepleted = Math.floor(((100 - claudeUsage.weekOpus) / (usageRate / 24) % 1) * 24);
              resetLine += ` • Est. depletion: ${daysUntilDepleted}d ${hoursUntilDepleted}h`;
            }

            claudeLines.push(resetLine);
          }
        }

        sections.push(['```', ...claudeLines, '```'].join('\n'));
      }
    } catch (error) {
      logger.warn('Failed to fetch Claude usage for daily report:', error.message);
    }

    // Add usage response section - task/cost stats for current window
    try {
      const { getStatsDB } = await import('./stats-db.js');
      const statsDB = getStatsDB();

      // Calculate time window based on reset time
      let windowStart = new Date();
      if (claudeUsage && claudeUsage.weekOpusResetInfo && claudeUsage.weekOpusResetInfo.nextResetDate) {
        const nextReset = new Date(claudeUsage.weekOpusResetInfo.nextResetDate);
        // Go back 7 days from next reset to get window start
        windowStart = new Date(nextReset.getTime() - 7 * 24 * 60 * 60 * 1000);
      } else {
        // Fallback: last 7 days
        windowStart.setDate(windowStart.getDate() - 7);
      }

      // Get stats for the window
      const windowStats = await statsDB.getTaskStats(windowStart, new Date());
      const todayStart = new Date();
      todayStart.setHours(0, 0, 0, 0);
      const todayStats = await statsDB.getTaskStats(todayStart, new Date());

      if (windowStats && todayStats) {
        const windowCost = windowStats.totalCost || 0;
        const todayCost = todayStats.totalCost || 0;
        const windowTasks = windowStats.totalTasks || 0;
        const todayTasks = todayStats.totalTasks || 0;

        const windowTaskText = windowTasks === 1 ? 'task' : 'tasks';
        const todayTaskText = todayTasks === 1 ? 'task' : 'tasks';

        const usageResponseSection = [
          '```',
          'USAGE RESPONSE',
          `Window (7d): ${windowTasks.toString().padStart(4)} ${windowTaskText.padEnd(5)} $${windowCost.toFixed(2).padStart(7)}`,
          `Today:       ${todayTasks.toString().padStart(4)} ${todayTaskText.padEnd(5)} $${todayCost.toFixed(2).padStart(7)}`,
          '```'
        ].join('\n');

        sections.push(usageResponseSection);
      }
    } catch (error) {
      logger.warn('Failed to fetch task stats for daily report:', error.message);
    }

    const topProjects = [];

    // Add top projects ranking using stats DB (more accurate than ccusage)
    try {
      const { getStatsDB } = await import('./stats-db.js');
      const statsDB = getStatsDB();

      // Get project stats from today
      const todayStart = new Date();
      todayStart.setHours(0, 0, 0, 0);

      // Query to get per-project costs for today
      const projectStatsQuery = statsDB.db.prepare(`
        SELECT
          workspace,
          COUNT(*) as task_count,
          SUM(cost_usd) as total_cost,
          SUM(total_tokens) as total_tokens
        FROM task_stats
        WHERE created_at >= ? AND status = 'completed'
        GROUP BY workspace
        ORDER BY total_cost DESC
        LIMIT 5
      `);

      const projectStats = projectStatsQuery.all(todayStart.getTime());

      if (projectStats && projectStats.length > 0) {
        projectStats.forEach((project, index) => {
          let cleanName = project.workspace.replace(/^\/root\/workspace\//, '');
          if (cleanName.length > 20) {
            cleanName = cleanName.substring(0, 17) + '...';
          }

          const cost = formatCost(project.total_cost || 0);
          const tokens = formatTokens(project.total_tokens || 0);
          const rank = (index + 1).toString().padStart(1);
          const taskCount = project.task_count || 0;
          const taskText = taskCount === 1 ? 'task' : 'tasks';

          topProjects.push({
            rank,
            name: cleanName,
            cost,
            tokens,
            taskCount: `${taskCount} ${taskText}`
          });
        });
      }
    } catch (error) {
      logger.warn('Failed to fetch project stats for daily report:', error.message);

      // Fallback to ccusage project data if stats DB fails
      const projects = usageData.projects;
      if (projects && Object.keys(projects).length > 0) {
        const projectList = Object.entries(projects)
          .filter(([, data]) => data.length > 0)
          .map(([name, data]) => {
            // Calculate actual cost by summing model breakdowns
            // (ccusage sometimes reports totalCost as 0 even when models have costs)
            let actualCost = data[0].totalCost || 0;

            // If totalCost is 0 but we have modelBreakdowns, sum those up
            if (actualCost === 0 && data[0].modelBreakdowns && data[0].modelBreakdowns.length > 0) {
              actualCost = data[0].modelBreakdowns.reduce((sum, model) => sum + (model.cost || 0), 0);
            }

            // ccusage bug: costs are sometimes missing at project level even when present at daily level
            // Calculate estimated cost from tokens if cost is still 0
            let estimatedCost = actualCost;
            if (estimatedCost === 0 && data[0].totalTokens > 0) {
              // Estimate based on total daily cost proportional to tokens used
              const totalTokens = totals.totalTokens || 1;
              const projectTokens = data[0].totalTokens || 0;
              const tokenRatio = projectTokens / totalTokens;
              estimatedCost = (totals.totalCost || 0) * tokenRatio;
            }

            return [name, data, estimatedCost];
          })
          .sort((a, b) => b[2] - a[2])  // Sort by estimated cost
          .slice(0, 5);

        if (projectList.length > 0) {
          projectList.forEach(([name, data, estimatedCost], index) => {
            let cleanName = name.replace(/^-/, '');
            cleanName = cleanName.replace(/^root-workspace-/, '');
            if (cleanName.length > 20) {
              cleanName = cleanName.substring(0, 17) + '...';
            }

            const cost = formatCost(estimatedCost);
            const tokens = formatTokens(data[0].totalTokens || 0);
            const rank = (index + 1).toString().padStart(1);
            const taskCount = data[0].taskCount || data.length;
            const taskText = taskCount === 1 ? 'task' : 'tasks';

            topProjects.push({
              rank,
              name: cleanName,
              cost,
              tokens,
              taskCount: `${taskCount} ${taskText}`
            });
          });
        }
      }
    }

    if (topProjects.length > 0) {
      const projectLines = ['```', 'TOP PROJECTS'];
      topProjects.forEach(project => {
        projectLines.push(`${project.rank}. ${project.name.padEnd(20)} $${project.cost.toString().padStart(7)} ${project.tokens.toString().padStart(8)} (${project.taskCount})`);
      });
      projectLines.push('```');
      sections.push(projectLines.join('\n'));
    }

    return {
      title: `Usage Report • ${displayDate}`,
      content: sections.join('\n'),
      color: 'blue',
      date: displayDate,
      totals: totals
    };
  }

  forecastUsageDepletion(weekOpusUsed) {
    // Calculate how much time is left in the week
    const now = new Date();
    const dayOfWeek = now.getUTCDay(); // 0 = Sunday, 6 = Saturday
    const hoursIntoWeek = dayOfWeek * 24 + now.getUTCHours();
    const totalHoursInWeek = 7 * 24;
    const hoursRemaining = totalHoursInWeek - hoursIntoWeek;
    const percentTimeElapsed = (hoursIntoWeek / totalHoursInWeek) * 100;

    // If we've used more % than time elapsed, we're running hot
    const usageRate = weekOpusUsed / percentTimeElapsed;
    const projectedUsage = usageRate * 100;

    const result = {
      warning: false,
      message: '',
      projectedUsage: Math.round(projectedUsage),
      hoursRemaining: Math.round(hoursRemaining)
    };

    // Warn if projected to exceed 100%
    if (projectedUsage > 100) {
      const depletionHours = (100 / usageRate) * (totalHoursInWeek / 100) - hoursIntoWeek;
      result.warning = true;
      result.message = `At current rate, Opus will run out in ~${Math.round(depletionHours)}h\n` +
                       `Projected: ${Math.round(projectedUsage)}% by week end`;
    } else if (projectedUsage > 90) {
      result.warning = true;
      result.message = `High usage rate detected\n` +
                       `Projected: ${Math.round(projectedUsage)}% by week end`;
    }

    return result;
  }

  shouldSendReport() {
    // Send report once per day
    const today = new Date().toISOString().split('T')[0].replace(/-/g, '');
    return this.lastReportDate !== today;
  }

  resetDailyReport() {
    this.lastReportDate = null;
  }

  async createTaskSnapshot(taskId, taskName = '', taskData = null) {
    try {
      logger.debug(`Creating usage snapshot for task ${taskId} (${taskName})`);

      // Get current usage data asynchronously with timing
      // Use --since to limit data to current day only for better performance
      const today = new Date().toISOString().split('T')[0].replace(/-/g, '');
      const command = `npx ccusage -j --breakdown --since ${today}`;
      const startTime = Date.now();
      logger.debug(`[CCUSAGE] Starting snapshot for task: ${taskName}...`);

      const { stdout, stderr } = await execAsync(command, { encoding: 'utf8', timeout: 30000 }); // 30 second timeout

      const duration = Date.now() - startTime;
      logger.debug(`[CCUSAGE] Snapshot created in ${duration}ms for task: ${taskName}`);

      let usageData;
      try {
        usageData = JSON.parse(stdout);
      } catch (parseError) {
        logger.error(`❌ [SNAPSHOT_BEFORE] BROKEN DATA: Failed to parse JSON for task ${taskId} (${taskName})`);
        logger.error(`[SNAPSHOT_BEFORE] Parse error: ${parseError.message}`);
        logger.error(`[SNAPSHOT_BEFORE] Raw stdout (first 500 chars): ${stdout.substring(0, 500)}`);
        return null;
      }

      // Handle first run case: ccusage returns empty array when no usage data exists yet
      if (Array.isArray(usageData) && usageData.length === 0) {
        logger.info(`[SNAPSHOT_BEFORE] First run detected (no prior usage data) - initializing with zero totals for task: ${taskName}`);
        usageData = {
          totals: {
            totalCost: 0,
            totalTokens: 0,
            inputTokens: 0,
            outputTokens: 0
          }
        };
      }

      // Validate snapshot data structure
      if (!usageData || typeof usageData !== 'object') {
        logger.error(`❌ [SNAPSHOT_BEFORE] BROKEN DATA: Invalid usageData structure for task ${taskId} (${taskName})`);
        logger.error(`[SNAPSHOT_BEFORE] Raw data: ${JSON.stringify(usageData)}`);
        return null;
      }

      if (!usageData.totals || typeof usageData.totals !== 'object') {
        logger.error(`❌ [SNAPSHOT_BEFORE] BROKEN DATA: Missing or invalid totals for task ${taskId} (${taskName})`);
        logger.error(`[SNAPSHOT_BEFORE] usageData structure: ${JSON.stringify(Object.keys(usageData))}`);
        return null;
      }

      const totals = usageData.totals;

      const snapshot = {
        taskId,
        taskName,
        timestamp: new Date().toISOString(),
        usage: usageData,
        totals: totals,
        model: taskData?.model || null // Store model preference from task
      };

      this.taskSnapshots.set(`${taskId}_before`, snapshot);
      const modelInfo = snapshot.model ? ` (model: ${snapshot.model})` : '';
      logger.info(`📸 [SNAPSHOT_BEFORE] Created usage snapshot for task: ${taskName}${modelInfo} ($${totals.totalCost.toFixed(4)}, ${totals.totalTokens.toLocaleString()} tokens)`);
      logger.debug(`[SNAPSHOT_BEFORE] Task ${taskId}: raw totals = ${JSON.stringify(totals)}`);

      return snapshot;
    } catch (error) {
      logger.error(`Failed to create usage snapshot for task ${taskId}:`, error);
      
      // Log more details about the error
      if (error.stderr) {
        logger.error(`[CCUSAGE] stderr output: ${error.stderr}`);
      }
      if (error.stdout) {
        // Only log first 500 chars of stdout to avoid huge logs
        const truncatedOutput = error.stdout.substring(0, 500);
        logger.error(`[CCUSAGE] stdout output (first 500 chars): ${truncatedOutput}`);
      }
      if (error.code !== undefined) {
        logger.error(`[CCUSAGE] Exit code: ${error.code}`);
      }
      if (error.signal) {
        logger.error(`[CCUSAGE] Terminated by signal: ${error.signal}`);
      }
      
      return null;
    }
  }

  /**
   * Get live usage for a running task by comparing with its before snapshot.
   * This is a non-blocking method that doesn't poll for stabilization.
   * @param {string} taskId - The task ID
   * @returns {Promise<Object|null>} Usage object or null if unavailable
   */
  async getLiveUsage(taskId) {
    try {
      const beforeSnapshot = this.taskSnapshots.get(`${taskId}_before`);
      if (!beforeSnapshot) {
        logger.debug(`[LIVE_USAGE] No before snapshot found for task ${taskId}`);
        return null;
      }

      // Get current usage data (single query, no polling)
      const today = new Date().toISOString().split('T')[0].replace(/-/g, '');
      const command = `npx ccusage -j --breakdown --since ${today}`;

      const { stdout } = await execAsync(command, { encoding: 'utf8', timeout: 10000 });
      const usageData = JSON.parse(stdout);

      if (!usageData || !usageData.totals) {
        return null;
      }

      const currentSnapshot = {
        taskId,
        timestamp: new Date().toISOString(),
        usage: usageData,
        totals: usageData.totals
      };

      // Calculate the difference
      const usage = this.calculateUsageDifference(beforeSnapshot, currentSnapshot);

      logger.debug(`[LIVE_USAGE] Task ${taskId}: cost=$${usage.cost.toFixed(4)}, tokens=${usage.tokens}`);

      return usage;
    } catch (error) {
      logger.debug(`[LIVE_USAGE] Failed to get live usage for task ${taskId}: ${error.message}`);
      return null;
    }
  }

  async createTaskCompletionSnapshot(taskId, taskName = '', taskData = null) {
    try {
      logger.debug(`Creating completion snapshot for task ${taskId} (${taskName})`);

      // Get current usage data asynchronously with timing
      // Use --since to limit data to current day only for better performance
      const today = new Date().toISOString().split('T')[0].replace(/-/g, '');
      const command = `npx ccusage -j --breakdown --since ${today}`;

      // Poll ccusage for up to 10 seconds until cost is updated
      const maxWaitTime = 10000; // 10 seconds
      const pollInterval = 1000; // Check every 1 second
      const startTime = Date.now();
      let lastCost = 0;
      let stableCount = 0;
      let usageData = null;

      logger.debug(`[CCUSAGE] Starting completion snapshot polling for task: ${taskName}...`);

      // Get before snapshot cost for comparison
      const beforeSnapshot = this.taskSnapshots.get(`${taskId}_before`);
      const beforeCost = beforeSnapshot?.totals?.totalCost || 0;

      while (Date.now() - startTime < maxWaitTime) {
        const { stdout } = await execAsync(command, { encoding: 'utf8', timeout: 30000 });
        usageData = JSON.parse(stdout);

        const currentCost = usageData?.totals?.totalCost || 0;
        const costDiff = currentCost - beforeCost;

        logger.debug(`[CCUSAGE] Poll at ${Date.now() - startTime}ms: cost=$${currentCost.toFixed(6)}, diff=$${costDiff.toFixed(6)}`);

        // If cost has increased from before snapshot, we're good
        if (costDiff > 0) {
          // Wait for cost to stabilize (same value twice in a row)
          if (currentCost === lastCost) {
            stableCount++;
            if (stableCount >= 2) {
              const duration = Date.now() - startTime;
              logger.debug(`[CCUSAGE] Cost stabilized at $${currentCost.toFixed(6)} after ${duration}ms`);
              break;
            }
          } else {
            stableCount = 0;
          }
        }

        lastCost = currentCost;
        await new Promise(resolve => setTimeout(resolve, pollInterval));
      }

      const duration = Date.now() - startTime;
      logger.debug(`[CCUSAGE] Completion snapshot created in ${duration}ms for task: ${taskName}`);

      // usageData is already parsed in the polling loop above
      if (!usageData) {
        logger.error(`❌ [SNAPSHOT_AFTER] BROKEN DATA: No usageData available after polling for task ${taskId} (${taskName})`);
        return null;
      }

      // Handle first run case: ccusage returns empty array when no usage data exists yet
      if (Array.isArray(usageData) && usageData.length === 0) {
        logger.info(`[SNAPSHOT_AFTER] First run detected (no prior usage data) - initializing with zero totals for task: ${taskName}`);
        usageData = {
          totals: {
            totalCost: 0,
            totalTokens: 0,
            inputTokens: 0,
            outputTokens: 0
          }
        };
      }

      // Validate snapshot data structure
      if (!usageData || typeof usageData !== 'object') {
        logger.error(`❌ [SNAPSHOT_AFTER] BROKEN DATA: Invalid usageData structure for task ${taskId} (${taskName})`);
        logger.error(`[SNAPSHOT_AFTER] Raw data: ${JSON.stringify(usageData)}`);
        return null;
      }

      if (!usageData.totals || typeof usageData.totals !== 'object') {
        logger.error(`❌ [SNAPSHOT_AFTER] BROKEN DATA: Missing or invalid totals for task ${taskId} (${taskName})`);
        logger.error(`[SNAPSHOT_AFTER] usageData structure: ${JSON.stringify(Object.keys(usageData))}`);
        return null;
      }

      const totals = usageData.totals;

      const snapshot = {
        taskId,
        taskName,
        timestamp: new Date().toISOString(),
        usage: usageData,
        totals: totals,
        model: taskData?.model || null // Store model preference from task
      };

      this.taskSnapshots.set(`${taskId}_after`, snapshot);
      logger.info(`📸 [SNAPSHOT_AFTER] Created completion snapshot for task: ${taskName} ($${totals.totalCost.toFixed(4)}, ${totals.totalTokens.toLocaleString()} tokens)`);
      logger.debug(`[SNAPSHOT_AFTER] Task ${taskId}: raw totals = ${JSON.stringify(totals)}`);

      // Calculate difference if we have a before snapshot (already fetched above)
      if (beforeSnapshot) {
        // Validate beforeSnapshot before calculating difference
        if (!beforeSnapshot.totals || typeof beforeSnapshot.totals !== 'object') {
          logger.error(`❌ [TASK_USAGE] BROKEN DATA: beforeSnapshot exists but has invalid totals for task ${taskId}`);
          logger.error(`[TASK_USAGE] beforeSnapshot keys: ${JSON.stringify(Object.keys(beforeSnapshot))}`);
          logger.error(`[TASK_USAGE] beforeSnapshot.totals: ${JSON.stringify(beforeSnapshot.totals)}`);

          // Continue with fallback
          const after = snapshot.totals;
          const fallbackUsage = {
            cost: after.totalCost || 0,
            tokens: after.totalTokens || 0,
            inputTokens: after.inputTokens || 0,
            outputTokens: after.outputTokens || 0,
            cacheCreationTokens: after.cacheCreationTokens || 0,
            cacheReadTokens: after.cacheReadTokens || 0,
            duration: 0,
            modelsUsed: [],
            modelBreakdowns: [],
            estimatedFromSnapshot: true,
            error: 'beforeSnapshot has invalid totals'
          };
          logger.warn(`📊 [TASK_USAGE] Using fallback estimate: ${taskName} - $${fallbackUsage.cost.toFixed(4)}, ${fallbackUsage.tokens.toLocaleString()} tokens`);
          return fallbackUsage;
        }

        const usage = this.calculateUsageDifference(beforeSnapshot, snapshot);

        // Check if usage calculation returned an error
        if (usage.error) {
          logger.error(`❌ [TASK_USAGE] Failed to calculate usage difference: ${usage.error}`);
        }

        const modelInfo = taskData?.model ? ` (model: ${taskData.model})` : '';
        logger.info(`📊 [TASK_USAGE] Task usage: ${taskName}${modelInfo} - $${usage.cost.toFixed(4)}, ${usage.tokens.toLocaleString()} tokens`);

        // Store the calculated difference with model information
        this.taskSnapshots.set(`${taskId}_diff`, {
          taskId,
          taskName,
          startTime: beforeSnapshot.timestamp,
          endTime: snapshot.timestamp,
          model: taskData?.model || beforeSnapshot.model || null,
          usage
        });

        // Clean up _before and _after snapshots - diff is all we need
        this.taskSnapshots.delete(`${taskId}_before`);
        this.taskSnapshots.delete(`${taskId}_after`);

        return usage;
      } else {
        logger.warn(`No before snapshot found for task ${taskId} - using after snapshot totals as estimate`);

        // Fallback: use the after snapshot totals as a rough estimate
        // This is better than returning null and losing all cost data
        const after = snapshot.totals;
        const fallbackUsage = {
          cost: after.totalCost || 0,
          tokens: after.totalTokens || 0,
          inputTokens: after.inputTokens || 0,
          outputTokens: after.outputTokens || 0,
          cacheCreationTokens: after.cacheCreationTokens || 0,
          cacheReadTokens: after.cacheReadTokens || 0,
          duration: 0,
          modelsUsed: [],
          modelBreakdowns: [],
          estimatedFromSnapshot: true // Flag to indicate this is an estimate
        };

        logger.info(`📊 [TASK_USAGE] Task usage (estimated): ${taskName} - $${fallbackUsage.cost.toFixed(4)}, ${fallbackUsage.tokens.toLocaleString()} tokens`);

        return fallbackUsage;
      }
    } catch (error) {
      logger.error(`Failed to create completion snapshot for task ${taskId}:`, error);
      
      // Log more details about the error
      if (error.stderr) {
        logger.error(`[CCUSAGE] stderr output: ${error.stderr}`);
      }
      if (error.stdout) {
        // Only log first 500 chars of stdout to avoid huge logs
        const truncatedOutput = error.stdout.substring(0, 500);
        logger.error(`[CCUSAGE] stdout output (first 500 chars): ${truncatedOutput}`);
      }
      if (error.code !== undefined) {
        logger.error(`[CCUSAGE] Exit code: ${error.code}`);
      }
      if (error.signal) {
        logger.error(`[CCUSAGE] Terminated by signal: ${error.signal}`);
      }
      
      return null;
    }
  }

  calculateUsageDifference(beforeSnapshot, afterSnapshot) {
    // Validate snapshot data integrity
    if (!beforeSnapshot || !beforeSnapshot.totals) {
      logger.error('❌ [USAGE_DIFF] BROKEN DATA: beforeSnapshot is missing or has no totals');
      logger.error(`[USAGE_DIFF] beforeSnapshot: ${JSON.stringify(beforeSnapshot)}`);
      return {
        cost: 0,
        tokens: 0,
        inputTokens: 0,
        outputTokens: 0,
        cacheCreationTokens: 0,
        cacheReadTokens: 0,
        duration: 0,
        modelsUsed: [],
        modelBreakdowns: [],
        error: 'Invalid beforeSnapshot data'
      };
    }

    if (!afterSnapshot || !afterSnapshot.totals) {
      logger.error('❌ [USAGE_DIFF] BROKEN DATA: afterSnapshot is missing or has no totals');
      logger.error(`[USAGE_DIFF] afterSnapshot: ${JSON.stringify(afterSnapshot)}`);
      return {
        cost: 0,
        tokens: 0,
        inputTokens: 0,
        outputTokens: 0,
        cacheCreationTokens: 0,
        cacheReadTokens: 0,
        duration: 0,
        modelsUsed: [],
        modelBreakdowns: [],
        error: 'Invalid afterSnapshot data'
      };
    }

    const before = beforeSnapshot.totals;
    const after = afterSnapshot.totals;

    // Calculate the raw difference - these are the actual values from ccusage
    let costDiff = after.totalCost - before.totalCost;
    const tokenDiff = after.totalTokens - before.totalTokens;
    const inputDiff = (after.inputTokens || 0) - (before.inputTokens || 0);
    const outputDiff = (after.outputTokens || 0) - (before.outputTokens || 0);

    // Debug logging with more detail
    logger.debug(`[USAGE_DIFF] Before snapshot: cost=${before.totalCost}, tokens=${before.totalTokens}, input=${before.inputTokens}, output=${before.outputTokens}`);
    logger.debug(`[USAGE_DIFF] After snapshot: cost=${after.totalCost}, tokens=${after.totalTokens}, input=${after.inputTokens}, output=${after.outputTokens}`);
    logger.debug(`[USAGE_DIFF] Calculated diff: cost=${costDiff}, tokens=${tokenDiff}, inputDiff=${inputDiff}, outputDiff=${outputDiff}`);

    // Log warning if no cost detected but tokens changed
    if (costDiff === 0 && tokenDiff > 0) {
      logger.warn(`[USAGE_DIFF] ⚠️  Tokens changed (${tokenDiff}) but cost is still 0 - possible pricing delay`);
    }

    // Log warning if negative values detected
    if (costDiff < 0 || tokenDiff < 0) {
      logger.warn(`[USAGE_DIFF] ⚠️  Negative diff detected - cost=${costDiff}, tokens=${tokenDiff}`);
    }

    // Extract model information from daily data
    const modelsUsed = [];
    const modelBreakdowns = [];

    if (afterSnapshot.usage && afterSnapshot.usage.daily && afterSnapshot.usage.daily.length > 0) {
      const dailyData = afterSnapshot.usage.daily[0]; // Get today's data
      if (dailyData.modelsUsed) {
        modelsUsed.push(...dailyData.modelsUsed);
      }
      if (dailyData.modelBreakdowns) {
        // Calculate the difference in model usage for this task
        const beforeModels = beforeSnapshot.usage?.daily?.[0]?.modelBreakdowns || [];
        const afterModels = dailyData.modelBreakdowns || [];

        logger.debug(`[USAGE_DIFF] Found ${afterModels.length} models in after snapshot`);
        for (const afterModel of afterModels) {
          const beforeModel = beforeModels.find(m => m.modelName === afterModel.modelName);
          const beforeCost = beforeModel ? beforeModel.cost : 0;
          const modelCostDiff = Math.max(0, afterModel.cost - beforeCost);

          logger.debug(`[USAGE_DIFF] Model ${afterModel.modelName}: before=$${beforeCost.toFixed(6)}, after=$${afterModel.cost.toFixed(6)}, diff=$${modelCostDiff.toFixed(6)}`);

          // Only include models that had usage during this task
          if (modelCostDiff > 0) {
            modelBreakdowns.push({
              modelName: afterModel.modelName,
              cost: modelCostDiff,
              inputTokens: Math.max(0, (afterModel.inputTokens || 0) - (beforeModel?.inputTokens || 0)),
              outputTokens: Math.max(0, (afterModel.outputTokens || 0) - (beforeModel?.outputTokens || 0)),
              cacheCreationTokens: Math.max(0, (afterModel.cacheCreationTokens || 0) - (beforeModel?.cacheCreationTokens || 0)),
              cacheReadTokens: Math.max(0, (afterModel.cacheReadTokens || 0) - (beforeModel?.cacheReadTokens || 0))
            });
            logger.debug(`[USAGE_DIFF] ✅ Added ${afterModel.modelName} to breakdown`);
          } else {
            logger.debug(`[USAGE_DIFF] ⏭️  Skipped ${afterModel.modelName} (no cost diff)`);
          }
        }
        logger.debug(`[USAGE_DIFF] Total models in breakdown: ${modelBreakdowns.length}`);
      }
    }

    // Build usage v2 format from model breakdowns
    // Each entry contains: modelId, inputTokens, inputCachedTokens, outputTokens, costUsd
    const usageV2 = modelBreakdowns.map(breakdown => ({
      modelId: breakdown.modelName,
      inputTokens: breakdown.inputTokens || 0,
      inputCachedTokens: breakdown.cacheReadTokens || 0,
      outputTokens: breakdown.outputTokens || 0,
      costUsd: breakdown.cost || 0
    }));

    // Return actual values from ccusage, even if they're 0
    return {
      cost: Math.max(0, costDiff),
      tokens: Math.max(0, tokenDiff),
      inputTokens: Math.max(0, inputDiff),
      outputTokens: Math.max(0, outputDiff),
      cacheCreationTokens: Math.max(0, (after.cacheCreationTokens || 0) - (before.cacheCreationTokens || 0)),
      cacheReadTokens: Math.max(0, (after.cacheReadTokens || 0) - (before.cacheReadTokens || 0)),
      duration: new Date(afterSnapshot.timestamp) - new Date(beforeSnapshot.timestamp),
      modelsUsed: Array.from(new Set(modelsUsed)), // Remove duplicates
      modelBreakdowns: modelBreakdowns,
      usageV2: usageV2 // New v2 format for per-model storage
    };
  }

  getTaskUsage(taskId) {
    return this.taskSnapshots.get(`${taskId}_diff`);
  }

  getAllTaskUsage() {
    const usage = [];
    for (const [key, value] of this.taskSnapshots.entries()) {
      if (key.endsWith('_diff')) {
        usage.push(value);
      }
    }
    return usage.sort((a, b) => new Date(b.startTime) - new Date(a.startTime));
  }

  cleanupTaskSnapshots(olderThanHours = 24) {
    const cutoff = new Date(Date.now() - olderThanHours * 60 * 60 * 1000);
    let cleaned = 0;
    
    for (const [key, value] of this.taskSnapshots.entries()) {
      const timestamp = new Date(value.startTime || value.timestamp);
      if (timestamp < cutoff) {
        this.taskSnapshots.delete(key);
        cleaned++;
      }
    }
    
    if (cleaned > 0) {
      logger.debug(`Cleaned up ${cleaned} old task snapshots`);
    }
  }
}

import chalk from 'chalk';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { existsSync, readFileSync, readdirSync } from 'fs';

// Helper function to process preset templates
export async function processPresets(inputText) {
  if (!inputText) return { text: inputText, presets: [] };

  // Check for @preset.md syntax - supports wildcards and regex patterns
  const presetMatches = inputText.match(/@([\w*-]+)\.md/g);
  if (!presetMatches) return { text: inputText, presets: [] };

  const __dirname = dirname(fileURLToPath(import.meta.url));
  const presetsDir = join(__dirname, 'presets');

  // Store all matching preset contents
  const matchedPresets = new Set();
  const presetMetadata = []; // Track preset files with their descriptions
  let combinedPresetContent = '';

  for (const match of presetMatches) {
    // Extract pattern from @pattern.md
    const pattern = match.replace('@', '').replace('.md', '');

    // Check if directory exists
    if (!existsSync(presetsDir)) {
      console.error(chalk.red(`✗ Presets directory not found: ${presetsDir}`));
      process.exit(1);
    }

    // Get all .md files in presets dir
    const allPresets = readdirSync(presetsDir).filter(f => f.endsWith('.md'));

    // Find matching files based on pattern
    let matchingFiles = [];
    if (pattern.includes('*')) {
      // Convert wildcard pattern to regex
      const regexPattern = pattern.replace(/\*/g, '.*');
      const regex = new RegExp(`^${regexPattern}$`);
      matchingFiles = allPresets.filter(f => regex.test(f.replace('.md', '')));
    } else {
      // Exact match
      const exactFile = `${pattern}.md`;
      if (allPresets.includes(exactFile)) {
        matchingFiles = [exactFile];
      }
    }

    // Read matching files
    for (const file of matchingFiles) {
      // Skip if already processed (for unique constraint)
      if (matchedPresets.has(file)) {
        continue;
      }
      matchedPresets.add(file);

      const presetFile = join(presetsDir, file);
      try {
        const content = readFileSync(presetFile, 'utf8');
        console.log(chalk.green(`✓ Found preset: ${file}`));

        // Extract first heading from content as description
        const headingMatch = content.match(/^#\s+(.+)$/m);
        const description = headingMatch ? headingMatch[1].trim() : file.replace('.md', '');

        // Store metadata for this preset
        presetMetadata.push({
          file: `@${file.replace('.md', '')}.md`,
          description: description
        });

        // Add header for each preset if multiple
        if (matchedPresets.size > 1 || matchingFiles.length > 1) {
          combinedPresetContent += `\n\n# From preset: ${file}\n`;
        }
        combinedPresetContent += content;
      } catch (error) {
        console.error(chalk.red(`✗ Failed to read preset file ${file}: ${error.message}`));
        process.exit(1);
      }
    }

    // If no matches found for this pattern
    if (matchingFiles.length === 0) {
      console.error(chalk.red(`✗ No presets found matching pattern: ${pattern}`));
      console.log(chalk.yellow(`💡 Available presets in ${presetsDir}:`));
      allPresets.forEach(p => console.log(chalk.gray(`  - @${p.replace('.md', '')}.md`)));
      process.exit(1);
    }
  }

  // Remove all @preset.md patterns from the input but keep user's text
  let userText = inputText;
  for (const match of presetMatches) {
    userText = userText.replace(match, '');
  }
  userText = userText.trim();

  // Combine user text with preset content - user's instructions come first
  let result;
  if (userText && combinedPresetContent) {
    // User's prompt is primary, preset is wrapped in tags as reference
    // Extract preset names for tag generation
    const presetNames = Array.from(matchedPresets).map(f => f.replace('.md', ''));

    // Wrap long content in XML-style tags for better structure
    if (combinedPresetContent.split('\n').length > 20) {
      // For long content, use tags to clearly separate reference material
      if (presetNames.length === 1) {
        result = `${userText}\n\n<${presetNames[0]}>\n${combinedPresetContent}\n</${presetNames[0]}>`;
      } else {
        result = `${userText}\n\n<reference-presets>\n${combinedPresetContent}\n</reference-presets>`;
      }
    } else {
      // For shorter content, use simple separator
      result = `${userText}\n\n---\n# Reference Template Content\n${combinedPresetContent}`;
    }
  } else if (combinedPresetContent) {
    // Only preset content (no additional user text)
    result = combinedPresetContent;
  } else {
    // Only user text (shouldn't happen if we found presets)
    result = userText;
  }

  // Report summary
  const fileCount = matchedPresets.size;
  if (fileCount > 1) {
    console.log(chalk.blue(`📚 Loaded ${fileCount} preset files`));
  }

  return {
    text: result,
    presets: presetMetadata
  };
}
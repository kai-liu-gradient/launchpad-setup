import { config } from './config.js';
import { SecureUploader } from './utils/secure-upload.js';

class Logger {
  constructor() {
    this.levels = {
      error: 0,
      warn: 1,
      info: 2,
      debug: 3
    };
    this.currentLevel = this.levels[config.logging.level] || this.levels.info;
  }

  maskSensitiveData(text) {
    if (!text) return text;

    // Convert to string if it's an object
    if (typeof text === 'object') {
      text = JSON.stringify(text);
    }

    // Use SecureUploader's maskCredentials method
    return SecureUploader.maskCredentials(String(text));
  }

  formatMessage(args, isError = false) {
    // Convert all arguments to a single string message
    const parts = [];
    const MAX_JSON_LENGTH = 500; // Maximum length for JSON strings in errors

    for (let i = 0; i < args.length; i++) {
      const arg = args[i];
      if (arg instanceof Error) {
        const errorParts = [];
        if (arg.name) {
          errorParts.push(arg.name);
        }
        if (arg.message) {
          errorParts.push(arg.message);
        }
        const header = errorParts.length > 0 ? errorParts.join(': ') : 'Error';
        const stack = arg.stack ? `\n${arg.stack}` : '';
        parts.push(`${header}${stack}`);
        continue;
      }
      if (typeof arg === 'object') {
        // Single-line JSON format for objects
        let jsonStr = JSON.stringify(arg);

        // For error messages with long JSON, truncate it
        if (isError && jsonStr.length > MAX_JSON_LENGTH) {
          // Try to extract meaningful info first
          if (arg instanceof Error) {
            jsonStr = `Error: ${arg.message || 'Unknown error'}${arg.code ? ` (code: ${arg.code})` : ''}`;
          } else if (arg.error || arg.message) {
            // Extract error/message fields if they exist
            const summary = {
              message: arg.message || arg.error?.message,
              code: arg.code || arg.error?.code,
              type: arg.type || arg.error?.type
            };
            jsonStr = JSON.stringify(summary);
          } else {
            // Truncate long JSON and add indicator
            jsonStr = jsonStr.substring(0, MAX_JSON_LENGTH) + '... (truncated)';
          }
        }
        parts.push(jsonStr);
      } else {
        parts.push(String(arg));
      }
    }
    return parts.join(' ');
  }

  error(...args) {
    if (this.currentLevel >= this.levels.error) {
      // Format and mask sensitive data in the message (with error truncation)
      const message = this.formatMessage(args, true);
      const maskedMessage = this.maskSensitiveData(message);
      // Add red light emoji for ERROR
      console.error('🔴 ERROR:', maskedMessage);
    }
  }

  warn(...args) {
    if (this.currentLevel >= this.levels.warn) {
      // Format and mask sensitive data in warnings too
      const message = this.formatMessage(args);
      const maskedMessage = this.maskSensitiveData(message);
      console.warn('WARN:', maskedMessage);
    }
  }

  info(...args) {
    if (this.currentLevel >= this.levels.info) {
      // Format and mask sensitive data in info messages
      const message = this.formatMessage(args);
      const maskedMessage = this.maskSensitiveData(message);
      console.log('INFO:', maskedMessage);
    }
  }

  debug(...args) {
    if (this.currentLevel >= this.levels.debug) {
      // Format and mask sensitive data in debug messages
      const message = this.formatMessage(args);
      const maskedMessage = this.maskSensitiveData(message);
      console.log('DEBUG:', maskedMessage);
    }
  }

  success(...args) {
    if (this.currentLevel >= this.levels.info) {
      const message = this.formatMessage(args);
      const maskedMessage = this.maskSensitiveData(message);
      console.log('✓', maskedMessage);
    }
  }
}

export const logger = new Logger();

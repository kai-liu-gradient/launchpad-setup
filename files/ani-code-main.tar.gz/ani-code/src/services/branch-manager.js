import { exec } from 'child_process';
import util from 'util';
const execPromise = util.promisify(exec);
import chalk from 'chalk';
import { logger } from '../logger.js';

class BranchManager {
  constructor() {
    this.logger = logger;
  }

  async getCurrentBranch() {
    try {
      const { stdout } = await execPromise('git branch --show-current');
      return stdout.trim();
    } catch (error) {
      this.logger.error('Failed to get current branch:', error);
      throw new Error('Failed to get current git branch');
    }
  }

  async getGitStatus() {
    try {
      const { stdout } = await execPromise('git status --porcelain');
      return stdout.trim();
    } catch (error) {
      this.logger.error('Failed to get git status:', error);
      throw new Error('Failed to get git status');
    }
  }

  async hasUncommittedChanges() {
    const status = await this.getGitStatus();
    return status.length > 0;
  }

  async getGitDiff() {
    try {
      const { stdout: stagedDiff } = await execPromise('git diff --cached');
      const { stdout: unstagedDiff } = await execPromise('git diff');
      return {
        staged: stagedDiff.trim(),
        unstaged: unstagedDiff.trim(),
        hasDiff: stagedDiff.trim().length > 0 || unstagedDiff.trim().length > 0
      };
    } catch (error) {
      this.logger.error('Failed to get git diff:', error);
      throw new Error('Failed to get git diff');
    }
  }

  async createBranch(branchName) {
    try {
      await execPromise(`git checkout -b ${branchName}`);
      return branchName;
    } catch (error) {
      this.logger.error(`Failed to create branch ${branchName}:`, error);
      throw new Error(`Failed to create branch: ${error.message}`);
    }
  }

  async switchBranch(branchName) {
    try {
      await execPromise(`git checkout ${branchName}`);
      return branchName;
    } catch (error) {
      this.logger.error(`Failed to switch to branch ${branchName}:`, error);
      throw new Error(`Failed to switch branch: ${error.message}`);
    }
  }

  async branchExists(branchName) {
    try {
      await execPromise(`git show-ref --verify --quiet refs/heads/${branchName}`);
      return true;
    } catch (error) {
      return false;
    }
  }

  async stashChanges(message = '') {
    try {
      const stashMsg = message || `Stash before branch switch - ${new Date().toISOString()}`;
      await execPromise(`git stash push -m "${stashMsg}"`);
      return true;
    } catch (error) {
      this.logger.error('Failed to stash changes:', error);
      throw new Error('Failed to stash changes');
    }
  }

  async generateBranchNameFromChanges(ipcClient, cwd) {
    const prompt = `You are a git branch name generator. Run 'git diff --cached' and 'git diff' to see changes, then 'git log --oneline -5' to understand branch naming style.

Generate a branch name based on the changes. Requirements:
- Keep it concise (2-4 words max)
- Use lowercase with hyphens
- Start with feat/, fix/, chore/, docs/, refactor/, test/, or style/ based on change type
- Follow the project's existing branch naming conventions
- Focus on the main purpose of the changes

Output ONLY the branch name. No explanations, no additional text. Just the branch name.`;

    const { basename } = await import('path');
    const projectDir = basename(cwd || process.cwd());
    const now = new Date();
    const hour = now.getHours().toString().padStart(2, '0');
    const minute = now.getMinutes().toString().padStart(2, '0');
    const taskName = `${projectDir}-branch-name-${hour}${minute}`;
    
    // Create task and wait for result
    const task = await ipcClient.addTask(taskName, prompt, { cwd });
    
    // Poll for completion
    let attempts = 0;
    const maxAttempts = 60; // 1 minute timeout
    
    while (attempts < maxAttempts) {
      await new Promise(resolve => setTimeout(resolve, 1000));
      attempts++;
      
      let currentTask = await ipcClient.getTask(task.id);
      if (!currentTask) {
        const history = await ipcClient.getTaskHistory();
        currentTask = history.find(t => t.id === task.id);
      }
      
      if (currentTask && currentTask.status === 'completed' && currentTask.output) {
        const branchName = currentTask.output.trim().split('\n')[0].trim();
        // Validate branch name format
        if (branchName && /^[a-z0-9\-\/]+$/.test(branchName)) {
          return branchName;
        } else {
          throw new Error('Invalid branch name generated');
        }
      } else if (currentTask && currentTask.status === 'failed') {
        throw new Error('Failed to generate branch name');
      }
    }
    
    throw new Error('Timeout generating branch name');
  }

  parseBranchReason(reason) {
    if (!reason) {
      return { type: 'auto', name: null };
    }

    // Check if it looks like a branch name (starts with common prefixes or contains /)
    const branchPrefixes = ['feat/', 'feature/', 'fix/', 'bugfix/', 'chore/', 'docs/', 
                            'refactor/', 'test/', 'style/', 'perf/', 'build/', 'ci/'];
    
    const looksLikeBranchName = branchPrefixes.some(prefix => reason.startsWith(prefix)) ||
                                reason.startsWith('feat-') || 
                                reason.startsWith('feature-') ||
                                /^[a-z0-9\-\/]+$/.test(reason);

    if (looksLikeBranchName) {
      return { type: 'explicit', name: reason };
    }

    // Otherwise treat as description for branch generation
    return { type: 'description', description: reason };
  }

  async handleBranchCommand(reason, options = {}) {
    const { ipcClient, cwd, verbose } = options;
    
    try {
      // Parse the reason
      const parsed = this.parseBranchReason(reason);
      
      // Check current status
      const currentBranch = await this.getCurrentBranch();
      const hasChanges = await this.hasUncommittedChanges();
      
      if (verbose) {
        this.logger.debug(`Current branch: ${currentBranch}, has changes: ${hasChanges}`);
        this.logger.debug(`Parsed reason:`, parsed);
      }

      let targetBranch;
      
      if (parsed.type === 'explicit') {
        // User provided explicit branch name
        targetBranch = parsed.name;
      } else if (parsed.type === 'description') {
        // Generate branch name from description
        if (!hasChanges) {
          throw new Error('No changes to create branch from. Please make some changes first or provide a branch name.');
        }
        
        // Create a simpler prompt using the description
        const descPrompt = `Generate a git branch name for: "${parsed.description}"
        
Requirements:
- Use format: type/short-description (e.g., feat/user-auth, fix/login-bug)
- Keep it concise (2-4 words max)
- Use lowercase with hyphens
- Common types: feat, fix, chore, docs, refactor, test, style

Output ONLY the branch name.`;
        
        if (!ipcClient) {
          throw new Error('Daemon not running - cannot generate branch name. Start with: ani-code daemon --start');
        }
        
        targetBranch = await this.generateBranchNameFromChanges(ipcClient, cwd);
      } else {
        // Auto mode - no reason provided
        if (!hasChanges) {
          throw new Error('No changes detected and no branch name provided. Make changes first or specify a branch name.');
        }
        
        if (!ipcClient) {
          throw new Error('Daemon not running - cannot generate branch name. Start with: ani-code daemon --start');
        }
        
        targetBranch = await this.generateBranchNameFromChanges(ipcClient, cwd);
      }

      // Check if branch already exists
      const branchExists = await this.branchExists(targetBranch);
      
      if (branchExists) {
        // Switch to existing branch
        if (hasChanges) {
          // Need to stash changes first
          await this.stashChanges(`Switching to branch ${targetBranch}`);
          await this.switchBranch(targetBranch);
          return {
            success: true,
            action: 'switched',
            branch: targetBranch,
            stashed: true,
            previousBranch: currentBranch
          };
        } else {
          await this.switchBranch(targetBranch);
          return {
            success: true,
            action: 'switched',
            branch: targetBranch,
            stashed: false,
            previousBranch: currentBranch
          };
        }
      } else {
        // Create new branch
        await this.createBranch(targetBranch);
        return {
          success: true,
          action: 'created',
          branch: targetBranch,
          previousBranch: currentBranch
        };
      }
    } catch (error) {
      this.logger.error('Branch operation failed:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  formatBranchResult(result) {
    if (!result.success) {
      return `❌ Branch operation failed: ${result.error}`;
    }

    let message = '';
    if (result.action === 'created') {
      message = `✅ Created and switched to new branch: ${chalk.green(result.branch)}`;
    } else {
      message = `✅ Switched to existing branch: ${chalk.green(result.branch)}`;
    }

    if (result.stashed) {
      message += '\n' + chalk.yellow('⚠️  Changes were stashed. Run "git stash pop" to restore them.');
    }

    if (result.previousBranch) {
      message += '\n' + chalk.gray(`Previous branch: ${result.previousBranch}`);
    }

    return message;
  }
}

export { BranchManager };
const crypto = require('crypto');
const fs = require('fs').promises;
const path = require('path');

class TokenService {
  constructor() {
    this.tokens = new Map();
    this.tokenFile = path.join(process.env.HOME || '/tmp', '.anicode', 'tokens.json');
    this.loadTokens();
  }

  async loadTokens() {
    try {
      const data = await fs.readFile(this.tokenFile, 'utf8');
      const tokens = JSON.parse(data);
      this.tokens = new Map(Object.entries(tokens));
    } catch (error) {
      // File doesn't exist or is invalid, start with empty tokens
      this.tokens = new Map();
    }
  }

  async saveTokens() {
    try {
      const dir = path.dirname(this.tokenFile);
      await fs.mkdir(dir, { recursive: true });
      
      const tokens = Object.fromEntries(this.tokens);
      await fs.writeFile(this.tokenFile, JSON.stringify(tokens, null, 2));
    } catch (error) {
      console.error('Failed to save tokens:', error);
    }
  }

  generateToken(projectId, metadata = {}) {
    const token = crypto.randomBytes(32).toString('hex');
    const tokenData = {
      token,
      projectId,
      createdAt: Date.now(),
      expiresAt: Date.now() + (24 * 60 * 60 * 1000), // 24 hours
      metadata: {
        ...metadata,
        workDir: process.cwd(),
        hostname: require('os').hostname()
      }
    };
    
    this.tokens.set(token, tokenData);
    this.saveTokens();
    
    return {
      token,
      url: this.getConnectionUrl(token),
      expiresAt: tokenData.expiresAt
    };
  }

  getConnectionUrl(token) {
    const baseUrl = process.env.ANICODE_PLUGIN_URL || 'ws://localhost:6502';
    const url = new URL(baseUrl);
    url.searchParams.set('token', token);
    return url.toString();
  }

  validateToken(token) {
    const tokenData = this.tokens.get(token);
    if (!tokenData) {
      return { valid: false, reason: 'Token not found' };
    }
    
    if (Date.now() > tokenData.expiresAt) {
      this.tokens.delete(token);
      this.saveTokens();
      return { valid: false, reason: 'Token expired' };
    }
    
    return { valid: true, data: tokenData };
  }

  revokeToken(token) {
    const deleted = this.tokens.delete(token);
    if (deleted) {
      this.saveTokens();
    }
    return deleted;
  }

  getTokenByProject(projectId) {
    for (const [token, data] of this.tokens) {
      if (data.projectId === projectId) {
        return { token, ...data };
      }
    }
    return null;
  }

  cleanExpiredTokens() {
    const now = Date.now();
    let cleaned = 0;
    
    for (const [token, data] of this.tokens) {
      if (now > data.expiresAt) {
        this.tokens.delete(token);
        cleaned++;
      }
    }
    
    if (cleaned > 0) {
      this.saveTokens();
    }
    
    return cleaned;
  }

  listTokens() {
    const tokens = [];
    for (const [token, data] of this.tokens) {
      tokens.push({
        token: token.substring(0, 8) + '...',
        projectId: data.projectId,
        createdAt: new Date(data.createdAt).toISOString(),
        expiresAt: new Date(data.expiresAt).toISOString(),
        expired: Date.now() > data.expiresAt
      });
    }
    return tokens;
  }
}

module.exports = new TokenService();
import axios from 'axios';
import os from 'os';
import { logger } from '../logger.js';
import { config } from '../config.js';
import { gatewayState } from '../gateway-state.js';
import { getGatewayUserAgent } from '../utils/gateway-request.js';

/**
 * Gateway Registration Service
 * Handles optional registration with ani-code-gateway
 */
class GatewayRegistrationService {
  constructor() {
    this.gatewayUrl = process.env.GATEWAY_URL;
    this.aniCodeUrl = process.env.ANI_CODE_URL || 'http://localhost:3000';
    this.enabled = !!this.gatewayUrl;
    this.heartbeatInterval = null;
  }

  /**
   * Check if gateway integration is enabled
   */
  isEnabled() {
    return this.enabled;
  }

  /**
   * Get User-Agent string for external API calls
   */
  getUserAgent() {
    return getGatewayUserAgent();
  }

  /**
   * Register workspace token with gateway
   * @param {string} workspaceToken - The workspace token to register
   * @param {string} workspaceName - Name of the workspace
   * @param {object} metadata - Additional metadata
   * @returns {Promise<object|null>} Gateway response or null if disabled
   */
  async registerToken(workspaceToken, workspaceName, metadata = {}) {
    if (!this.enabled) {
      logger.debug('Gateway integration disabled, skipping token registration');
      return null;
    }

    try {
      const response = await axios.post(
        `${this.gatewayUrl}/api/tokens/register`,
        {
          instanceUrl: this.aniCodeUrl,
          workspaceToken: workspaceToken,
          projectName: workspaceName,
          description: metadata.description || '',
          owner: metadata.owner || ''
        },
        {
          timeout: 5000,
          headers: {
            'Content-Type': 'application/json',
            'X-API-Key': process.env.GATEWAY_API_KEY || '',
            'User-Agent': this.getUserAgent()
          }
        }
      );

      logger.info('Token registered with gateway', {
        workspaceName,
        gatewayToken: response.data.gatewayToken?.substring(0, 8) + '...'
      });

      // Store the gateway token using state manager for persistence
      if (response.data.gatewayToken) {
        gatewayState.setGatewayToken(response.data.gatewayToken);
        logger.debug('Stored gateway token via state manager', {
          tokenPrefix: response.data.gatewayToken.substring(0, 8) + '...'
        });
      }

      return response.data;
    } catch (error) {
      logger.error('Failed to register token with gateway', {
        error: error.message,
        workspaceName,
        gatewayUrl: this.gatewayUrl
      });
      // Don't throw - gateway registration failure shouldn't break token creation
      return null;
    }
  }

  /**
   * Send heartbeat to gateway
   * Updates last_seen timestamp for this instance
   */
  async sendHeartbeat() {
    if (!this.enabled) {
      return;
    }

    try {
      await axios.post(
        `${this.gatewayUrl}/api/registry/instance`,
        {
          url: this.aniCodeUrl,
          metadata: {
            version: '1.2.0',  // Updated to match package.json version
            capabilities: ['telegram', 'lark', 'cli'],
            lastHeartbeat: new Date().toISOString(),
            projectId: config.gateway.projectId
          }
        },
        {
          timeout: 5000,
          headers: {
            'Content-Type': 'application/json',
            'X-API-Key': process.env.GATEWAY_API_KEY || '',
            'User-Agent': this.getUserAgent()
          }
        }
      );

      logger.debug('Heartbeat sent to gateway');
    } catch (error) {
      logger.debug('Heartbeat failed', { error: error.message });
      // Silently fail - heartbeat is not critical
    }
  }

  /**
   * Start periodic heartbeat
   */
  startHeartbeat() {
    if (!this.enabled) {
      return;
    }

    // Send initial heartbeat
    this.sendHeartbeat();

    // Send heartbeat every 30 seconds
    this.heartbeatInterval = setInterval(() => {
      this.sendHeartbeat();
    }, 30000);

    logger.info('Gateway heartbeat started', {
      gatewayUrl: this.gatewayUrl,
      aniCodeUrl: this.aniCodeUrl
    });
  }

  /**
   * Stop heartbeat
   */
  stopHeartbeat() {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
      logger.info('Gateway heartbeat stopped');
    }
  }
}

export const gatewayRegistration = new GatewayRegistrationService();
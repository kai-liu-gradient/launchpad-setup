const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

async function getGitLog(limit = 10) {
  try {
    const { stdout } = await execPromise(
      `git log --oneline -n ${limit} --pretty=format:"%h|%an|%ae|%ad|%s" --date=relative`
    );
    
    const logs = stdout.split('\n').filter(line => line.trim()).map(line => {
      const [hash, author, email, date, message] = line.split('|');
      return { hash, author, email, date, message };
    });
    
    return logs;
  } catch (error) {
    console.error('Git log error:', error);
    return [];
  }
}

async function getGitStatus() {
  try {
    const { stdout } = await execPromise('git status --porcelain');
    const files = stdout.split('\n').filter(line => line.trim()).map(line => {
      const status = line.substring(0, 2);
      const file = line.substring(3);
      return { status, file };
    });
    
    return files;
  } catch (error) {
    console.error('Git status error:', error);
    return [];
  }
}

async function getGitBranch() {
  try {
    const { stdout } = await execPromise('git branch --show-current');
    return stdout.trim();
  } catch (error) {
    console.error('Git branch error:', error);
    return 'unknown';
  }
}

module.exports = {
  getGitLog,
  getGitStatus,
  getGitBranch
};
import axios from 'axios';
import { writeFileSync, mkdirSync, existsSync, unlinkSync, readFileSync, readdirSync, statSync } from 'fs';
import { join, extname, basename } from 'path';
import crypto from 'crypto';
import { logger } from '../logger.js';

/**
 * Image Handler Service
 * Downloads images from URLs and prepares them for multimodal AI prompts
 */

// Supported image MIME types
const SUPPORTED_MIME_TYPES = [
  'image/jpeg',
  'image/png',
  'image/gif',
  'image/webp'
];

// Extension to MIME type mapping
const EXTENSION_TO_MIME = {
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.gif': 'image/gif',
  '.webp': 'image/webp'
};

/**
 * Download image from URL and save to temp file
 * @param {string} url - Image URL (e.g., S3 pre-signed URL)
 * @param {string} workingDir - Working directory for temp storage
 * @param {string} taskId - Task ID for unique file naming
 * @returns {Promise<{filePath: string, mimeType: string, size: number}>}
 */
// Image cache for retry scenarios - keyed by URL hash
const imageCache = new Map();
const CACHE_TTL_MS = 5 * 60 * 1000; // 5 minute cache TTL

/**
 * Get cached image if available and not expired
 * @param {string} url - Image URL
 * @returns {Object|null} Cached image data or null
 */
function getCachedImage(url) {
  const cacheKey = crypto.createHash('md5').update(url).digest('hex');
  const cached = imageCache.get(cacheKey);

  if (cached && Date.now() - cached.timestamp < CACHE_TTL_MS) {
    logger.debug(`[ImageHandler] Cache hit for image: ${url.substring(0, 50)}...`);
    return cached;
  }

  // Remove expired entry
  if (cached) {
    imageCache.delete(cacheKey);
  }

  return null;
}

/**
 * Cache downloaded image data
 * @param {string} url - Image URL
 * @param {Buffer} buffer - Image buffer
 * @param {string} mimeType - MIME type
 */
function cacheImage(url, buffer, mimeType) {
  const cacheKey = crypto.createHash('md5').update(url).digest('hex');
  imageCache.set(cacheKey, {
    buffer,
    mimeType,
    timestamp: Date.now()
  });

  // Limit cache size to 50 entries
  if (imageCache.size > 50) {
    const firstKey = imageCache.keys().next().value;
    imageCache.delete(firstKey);
  }
}

export async function downloadImage(url, workingDir, taskId = null) {
  const id = taskId || crypto.randomBytes(4).toString('hex');
  const startTime = Date.now();

  logger.info(`[ImageHandler] Downloading image from URL: ${url.substring(0, 80)}...`);

  try {
    // Check cache first for retry scenarios
    const cached = getCachedImage(url);
    let buffer, mimeType;

    if (cached) {
      buffer = cached.buffer;
      mimeType = cached.mimeType;
      logger.info(`[ImageHandler] Using cached image (${buffer.length} bytes, ${mimeType})`);
    } else {
      const response = await axios.get(url, {
        responseType: 'arraybuffer',
        timeout: 30000, // 30 second timeout
        maxContentLength: 20 * 1024 * 1024, // 20MB max
        headers: {
          'User-Agent': 'ani-code/1.0'
        }
      });

      buffer = Buffer.from(response.data);

      // Determine MIME type from response headers or URL
      mimeType = response.headers['content-type']?.split(';')[0]?.trim();

      // If no content-type, try to infer from URL
      if (!mimeType || !SUPPORTED_MIME_TYPES.includes(mimeType)) {
        const urlPath = new URL(url).pathname;
        const ext = extname(urlPath).toLowerCase();
        mimeType = EXTENSION_TO_MIME[ext] || 'image/jpeg';
      }

      // Validate MIME type
      if (!SUPPORTED_MIME_TYPES.includes(mimeType)) {
        throw new Error(`Unsupported image type: ${mimeType}. Supported types: ${SUPPORTED_MIME_TYPES.join(', ')}`);
      }

      // Cache for retry scenarios
      cacheImage(url, buffer, mimeType);
    }

    // Create temp directory for images in .ani-code/tmp/
    const aniCodeDir = join(workingDir, '.ani-code');
    const tmpDir = join(aniCodeDir, 'tmp');
    if (!existsSync(tmpDir)) {
      mkdirSync(tmpDir, { recursive: true });
      // Add .gitignore to prevent temp files from being committed
      const gitignorePath = join(tmpDir, '.gitignore');
      if (!existsSync(gitignorePath)) {
        writeFileSync(gitignorePath, '# Temporary files - auto-generated\n*\n!.gitignore\n');
      }
    }

    // Generate filename with proper extension
    const ext = mimeType === 'image/jpeg' ? '.jpg' :
                mimeType === 'image/png' ? '.png' :
                mimeType === 'image/gif' ? '.gif' : '.webp';
    const fileName = `task-${id}-image-${Date.now()}${ext}`;
    const filePath = join(tmpDir, fileName);

    // Write to file
    writeFileSync(filePath, buffer);

    const downloadTime = Date.now() - startTime;
    logger.info(`[ImageHandler] Downloaded image: ${filePath} (${buffer.length} bytes, ${mimeType}, ${downloadTime}ms)`);

    return {
      filePath,
      mimeType,
      size: buffer.length,
      downloadTime
    };
  } catch (error) {
    logger.error(`[ImageHandler] Failed to download image: ${error.message}`);
    throw new Error(`Failed to download image: ${error.message}`);
  }
}

/**
 * Download image and convert to base64
 * @param {string} url - Image URL
 * @returns {Promise<{base64: string, mimeType: string}>}
 */
export async function downloadImageAsBase64(url) {
  logger.info(`[ImageHandler] Downloading image as base64: ${url.substring(0, 80)}...`);

  try {
    const response = await axios.get(url, {
      responseType: 'arraybuffer',
      timeout: 30000,
      maxContentLength: 20 * 1024 * 1024,
      headers: {
        'User-Agent': 'ani-code/1.0'
      }
    });

    const buffer = Buffer.from(response.data);
    const base64 = buffer.toString('base64');

    // Determine MIME type
    let mimeType = response.headers['content-type']?.split(';')[0]?.trim();
    if (!mimeType || !SUPPORTED_MIME_TYPES.includes(mimeType)) {
      const urlPath = new URL(url).pathname;
      const ext = extname(urlPath).toLowerCase();
      mimeType = EXTENSION_TO_MIME[ext] || 'image/jpeg';
    }

    logger.info(`[ImageHandler] Downloaded image as base64: ${buffer.length} bytes, ${mimeType}`);

    return { base64, mimeType };
  } catch (error) {
    logger.error(`[ImageHandler] Failed to download image as base64: ${error.message}`);
    throw new Error(`Failed to download image: ${error.message}`);
  }
}

/**
 * Convert local file to base64
 * @param {string} filePath - Path to local image file
 * @returns {{base64: string, mimeType: string}}
 */
export function fileToBase64(filePath) {
  const buffer = readFileSync(filePath);
  const base64 = buffer.toString('base64');

  const ext = extname(filePath).toLowerCase();
  const mimeType = EXTENSION_TO_MIME[ext] || 'image/jpeg';

  return { base64, mimeType };
}

/**
 * Format image for Claude API (multimodal content block)
 * @param {string} base64 - Base64 encoded image data
 * @param {string} mimeType - MIME type of the image
 * @returns {Object} Claude API image content block
 */
export function formatForClaude(base64, mimeType) {
  return {
    type: 'image',
    source: {
      type: 'base64',
      media_type: mimeType,
      data: base64
    }
  };
}

/**
 * Format image for Gemini API
 * @param {string} base64 - Base64 encoded image data
 * @param {string} mimeType - MIME type of the image
 * @returns {Object} Gemini API image content block
 */
export function formatForGemini(base64, mimeType) {
  return {
    inlineData: {
      mimeType: mimeType,
      data: base64
    }
  };
}

/**
 * Process attachments array and download images
 * @param {Array} attachments - Array of attachment objects with type and url
 * @param {string} workingDir - Working directory for temp storage
 * @param {string} taskId - Task ID for unique file naming
 * @returns {Promise<Array<{filePath: string, mimeType: string, originalUrl: string}>>}
 */
export async function processAttachments(attachments, workingDir, taskId = null) {
  if (!attachments || !Array.isArray(attachments) || attachments.length === 0) {
    return [];
  }

  const imageAttachments = attachments.filter(a => a.type === 'image' && a.url);

  if (imageAttachments.length === 0) {
    return [];
  }

  const startTime = Date.now();
  logger.info(`[ImageHandler] Processing ${imageAttachments.length} image attachment(s)`);

  const results = [];

  for (let i = 0; i < imageAttachments.length; i++) {
    const attachment = imageAttachments[i];
    try {
      const uniqueId = taskId ? `${taskId}-${i}` : `${Date.now()}-${i}`;
      const result = await downloadImage(attachment.url, workingDir, uniqueId);
      results.push({
        ...result,
        originalUrl: attachment.url,
        originalMimeType: attachment.mimeType
      });
    } catch (error) {
      logger.error(`[ImageHandler] Failed to process attachment ${i}: ${error.message}`);
      // Continue with other attachments even if one fails
    }
  }

  // Log aggregate stats
  const totalTime = Date.now() - startTime;
  const totalSize = results.reduce((sum, r) => sum + (r.size || 0), 0);
  const totalSizeKB = (totalSize / 1024).toFixed(1);
  logger.info(`[ImageHandler] Successfully processed ${results.length}/${imageAttachments.length} image(s) - ${totalSizeKB}KB total, ${totalTime}ms`);

  return results;
}

/**
 * Clean up temporary image files for a task
 * @param {string} workingDir - Working directory
 * @param {string} taskId - Task ID to match files
 */
export function cleanupTaskImages(workingDir, taskId) {
  try {
    const tmpDir = join(workingDir, '.ani-code', 'tmp');
    if (!existsSync(tmpDir)) {
      return;
    }

    const files = readdirSync(tmpDir);

    let cleanedCount = 0;
    for (const file of files) {
      if (file.includes(`task-${taskId}-`)) {
        const filePath = join(tmpDir, file);
        try {
          unlinkSync(filePath);
          cleanedCount++;
        } catch (err) {
          logger.debug(`[ImageHandler] Failed to delete temp image ${file}: ${err.message}`);
        }
      }
    }

    if (cleanedCount > 0) {
      logger.info(`[ImageHandler] Cleaned up ${cleanedCount} temp image(s) for task ${taskId}`);
    }
  } catch (error) {
    logger.debug(`[ImageHandler] Cleanup failed: ${error.message}`);
  }
}

/**
 * Clean up old temporary image files (older than specified hours)
 * @param {string} workingDir - Working directory
 * @param {number} maxAgeHours - Maximum age in hours before cleanup (default: 24)
 */
export function cleanupOldImages(workingDir, maxAgeHours = 24) {
  try {
    const tmpDir = join(workingDir, '.ani-code', 'tmp');
    if (!existsSync(tmpDir)) {
      return;
    }

    const files = readdirSync(tmpDir);
    const maxAgeMs = maxAgeHours * 60 * 60 * 1000;
    const now = Date.now();

    let cleanedCount = 0;
    for (const file of files) {
      // Skip .gitignore
      if (file === '.gitignore') continue;

      const filePath = join(tmpDir, file);
      try {
        const stats = statSync(filePath);
        if (now - stats.mtimeMs > maxAgeMs) {
          unlinkSync(filePath);
          cleanedCount++;
        }
      } catch (err) {
        // File might have been deleted already
      }
    }

    if (cleanedCount > 0) {
      logger.info(`[ImageHandler] Cleaned up ${cleanedCount} old temp file(s)`);
    }
  } catch (error) {
    logger.debug(`[ImageHandler] Old file cleanup failed: ${error.message}`);
  }
}

/**
 * Build prompt with image URL references
 * CLI tools don't support --files flag, so we include URLs directly in the prompt
 * Uses same format as Telegram image handling for consistency
 * @param {string} textPrompt - The text prompt
 * @param {Array<{originalUrl?: string, url?: string}>} images - Array of images with URLs
 * @returns {string} The prompt with image URLs appended
 */
export function buildPromptWithImageUrls(textPrompt, images) {
  if (!images || images.length === 0) {
    return textPrompt;
  }

  const imageUrls = images
    .filter(img => img.originalUrl || img.url)
    .map(img => img.originalUrl || img.url);

  if (imageUrls.length === 0) {
    return textPrompt;
  }

  const imageList = imageUrls.length === 1
    ? `Image: ${imageUrls[0]}`
    : `Images:\n${imageUrls.map((url, i) => `${i + 1}. ${url}`).join('\n')}`;

  const imageContext = `${imageList}\n\nNote: Download to .ani-code/tmp/ folder using wget with the original filename from the URL (not a generic name like image.jpg) and analyze`;

  return `${textPrompt}\n\n${imageContext}`;
}

/**
 * @deprecated Use buildPromptWithImageUrls instead - CLI tools don't support --files flag
 */
export function buildClaudePromptWithImages(textPrompt, images) {
  // Redirect to new function for backwards compatibility
  return { prompt: buildPromptWithImageUrls(textPrompt, images), imageFlags: [] };
}

/**
 * Clear the in-memory image cache
 * Useful for freeing memory or forcing re-downloads
 */
export function clearImageCache() {
  const count = imageCache.size;
  imageCache.clear();
  if (count > 0) {
    logger.info(`[ImageHandler] Cleared ${count} cached image(s)`);
  }
}

/**
 * Get cache statistics
 * @returns {{size: number, entries: Array<{key: string, age: number}>}}
 */
/**
 * Ensure the .ani-code/tmp directory exists with a .gitignore file
 * @param {string} workingDir - The working directory (workspace path)
 * @returns {string} - Path to the tmp directory
 */
export function ensureTmpDir(workingDir) {
  const aniCodeDir = join(workingDir, '.ani-code');
  const tmpDir = join(aniCodeDir, 'tmp');

  if (!existsSync(tmpDir)) {
    mkdirSync(tmpDir, { recursive: true });
  }

  // Always ensure .gitignore exists (in case directory was created without it)
  const gitignorePath = join(tmpDir, '.gitignore');
  if (!existsSync(gitignorePath)) {
    writeFileSync(gitignorePath, '# Temporary files - auto-generated\n*\n!.gitignore\n');
    logger.debug(`[ImageHandler] Created .gitignore in ${tmpDir}`);
  }

  return tmpDir;
}

export function getCacheStats() {
  const now = Date.now();
  const entries = [];

  for (const [key, value] of imageCache.entries()) {
    entries.push({
      key,
      age: now - value.timestamp,
      size: value.buffer?.length || 0
    });
  }

  return {
    size: imageCache.size,
    entries
  };
}

export default {
  downloadImage,
  downloadImageAsBase64,
  fileToBase64,
  formatForClaude,
  formatForGemini,
  processAttachments,
  cleanupTaskImages,
  cleanupOldImages,
  buildPromptWithImageUrls,
  buildClaudePromptWithImages, // deprecated
  clearImageCache,
  getCacheStats,
  ensureTmpDir,
  SUPPORTED_MIME_TYPES
};

import { extractProviderFromPrompt, extractModelFromPrompt } from '../model-utils.js';

const DEFAULT_CONTINUE_DESCRIPTION = 'Continue previous task';
const DEFAULT_SHELL_DESCRIPTION = 'Run shell command';

function parseRawPlanStep(rawText) {
  const raw = (rawText ?? '').trim();
  if (!raw) {
    return {
      executor: 'add',
      prompt: '',
      description: ''
    };
  }

  const slashMatch = raw.match(/^\/(\w+)(?:\s+([\s\S]*))?$/);
  if (slashMatch) {
    const command = slashMatch[1].toLowerCase();
    const payload = (slashMatch[2] || '').trim();
    switch (command) {
      case 'add':
        return {
          executor: 'add',
          prompt: payload,
          description: payload || ''
        };
      case 'continue':
        return {
          executor: 'continue',
          prompt: payload,
          description: payload || DEFAULT_CONTINUE_DESCRIPTION
        };
      case 'shell':
        return {
          executor: 'shell',
          prompt: payload,
          description: payload || DEFAULT_SHELL_DESCRIPTION
        };
      default:
        return {
          executor: 'add',
          prompt: raw,
          description: raw
        };
    }
  }

  const shellMatch = raw.match(/^shell:\s*([\s\S]*)$/i);
  if (shellMatch) {
    const payload = (shellMatch[1] || '').trim();
    return {
      executor: 'shell',
      prompt: payload,
      description: payload || DEFAULT_SHELL_DESCRIPTION
    };
  }

  const continueMatch = raw.match(/^-c\b\s*([\s\S]*)$/i);
  if (continueMatch) {
    const payload = (continueMatch[1] || '').trim();
    return {
      executor: 'continue',
      prompt: payload,
      description: payload || DEFAULT_CONTINUE_DESCRIPTION
    };
  }

  return {
    executor: 'add',
    prompt: raw,
    description: raw
  };
}

function buildCommand(executor, prompt, providerId = null, model = null, rawText = null) {
  const promptText = (prompt ?? '').trim();
  
  // Build command with @@ patterns preserved for CLI processor
  // The prompt should already have @@ patterns from the raw text, but if they were
  // extracted and not preserved in prompt, add them back so CLI processor can parse them
  let commandPrompt = promptText;
  
  // Add @@ patterns if they were extracted but not present in prompt
  if (providerId && !promptText.includes(`@@${providerId}`)) {
    commandPrompt = `${commandPrompt} @@${providerId}`.trim();
  }
  if (model && !promptText.includes(`@@${model}`)) {
    commandPrompt = `${commandPrompt} @@${model}`.trim();
  }
  
  switch (executor) {
    case 'continue':
      return commandPrompt ? `-c ${commandPrompt}` : '-c';
    case 'shell':
      return `shell:${commandPrompt}`;
    default:
      return commandPrompt;
  }
}

export function normalizePlanStep(step, options = {}) {
  const { validProviders = null, force = false } = options;

  if (!force && step && typeof step === 'object' && !Array.isArray(step) && step.__normalized) {
    return step;
  }

  const base = (step && typeof step === 'object' && !Array.isArray(step)) ? { ...step } : {};
  const raw = typeof step === 'string' ? step : (base.raw ?? base.original ?? base.source ?? base.description ?? base.prompt ?? base.command ?? '');
  const trimmedRaw = typeof raw === 'string' ? raw.trim() : '';

  const parsed = parseRawPlanStep(trimmedRaw);

  const executor = (base.executor ?? parsed.executor ?? 'add').toLowerCase();
  const prompt = (base.prompt ?? base.command ?? parsed.prompt ?? '').trim();

  const descriptionSource = base.description ?? parsed.description ?? prompt ?? trimmedRaw;
  const description = typeof descriptionSource === 'string' ? descriptionSource.trim() : '';

  let providerId = base.providerId ?? base.provider ?? null;
  if (!providerId && prompt) {
    providerId = extractProviderFromPrompt(prompt, validProviders) || null;
  }

  let model = base.model ?? null;
  if (!model && prompt) {
    model = extractModelFromPrompt(prompt) || null;
  }

  const status = base.status ?? base.state ?? 'pending';
  const taskId = base.taskId ?? null;

  const normalized = {
    ...base,
    raw: trimmedRaw,
    executor,
    prompt,
    description: description || prompt || trimmedRaw,
    providerId,
    model,
    status,
    taskId,
    command: base.command ?? buildCommand(executor, prompt, providerId, model, trimmedRaw)
  };

  Object.defineProperty(normalized, '__normalized', {
    value: true,
    enumerable: false,
    configurable: false
  });

  return normalized;
}

export function normalizePlanSteps(steps, options = {}) {
  if (!Array.isArray(steps)) {
    return [];
  }
  return steps.map(step => normalizePlanStep(step, options));
}

export function stepsToPlanDescription(steps, options = {}) {
  if (!Array.isArray(steps)) {
    return '';
  }
  return steps
    .map(step => normalizePlanStep(step, options).raw)
    .filter(text => typeof text === 'string' && text.length > 0)
    .join('\n');
}

export function getPlanStepDisplayText(step, options = {}) {
  const info = normalizePlanStep(step, options);
  if (info.raw) {
    return info.raw;
  }
  if (info.prompt) {
    switch (info.executor) {
      case 'continue':
        return `/continue ${info.prompt}`.trim();
      case 'shell':
        return `/shell ${info.prompt}`.trim();
      default:
        return info.prompt;
    }
  }
  return info.description || '';
}

export function formatError(error, context = {}) {
  const formatted = {
    message: error.message || 'Unknown error',
    name: error.name || 'Error',
    timestamp: new Date().toISOString()
  };

  // Add context if provided
  if (context.operation) {
    formatted.operation = context.operation;
  }
  if (context.location) {
    formatted.location = context.location;
  }

  // Handle Axios errors specially
  if (error.isAxiosError || error.name === 'AxiosError') {
    formatted.type = 'HTTP';

    // Extract request info
    if (error.config) {
      formatted.request = {
        method: error.config.method?.toUpperCase(),
        url: cleanUrl(error.config.url),
        baseURL: cleanUrl(error.config.baseURL),
        timeout: error.config.timeout
      };

      // Add headers if they exist (but remove sensitive ones)
      if (error.config.headers) {
        formatted.request.headers = sanitizeHeaders(error.config.headers);
      }
    }

    // Extract response info
    if (error.response) {
      formatted.response = {
        status: error.response.status,
        statusText: error.response.statusText,
        data: truncateData(error.response.data)
      };
    } else if (error.code) {
      // Network errors
      formatted.networkError = {
        code: error.code,
        syscall: error.syscall,
        address: error.address,
        port: error.port
      };
    }
  }

  // Add stack trace (filtered)
  if (error.stack) {
    formatted.stack = formatStackTrace(error.stack);
  }

  // Add any additional error properties
  if (error.code && !formatted.networkError) {
    formatted.code = error.code;
  }
  if (error.errno) {
    formatted.errno = error.errno;
  }

  return formatted;
}

export function formatErrorMessage(error, context = {}) {
  const formatted = formatError(error, context);
  const lines = [];

  // Main error line
  lines.push(`ERROR: ${formatted.message}`);

  // Add context info
  if (formatted.operation) {
    lines.push(`Operation: ${formatted.operation}`);
  }
  if (formatted.location) {
    lines.push(`Location: ${formatted.location}`);
  }

  // HTTP request details
  if (formatted.request) {
    lines.push(`Request: ${formatted.request.method || 'GET'} ${formatted.request.url || formatted.request.baseURL || 'unknown'}`);
    if (formatted.request.timeout) {
      lines.push(`Timeout: ${formatted.request.timeout}ms`);
    }
  }

  // HTTP response details
  if (formatted.response) {
    lines.push(`Response: ${formatted.response.status} ${formatted.response.statusText}`);
    if (formatted.response.data) {
      lines.push(`Response Data: ${formatted.response.data}`);
    }
  }

  // Network error details
  if (formatted.networkError) {
    lines.push(`Network Error: ${formatted.networkError.code}`);
    if (formatted.networkError.address) {
      lines.push(`Address: ${formatted.networkError.address}:${formatted.networkError.port || 'unknown'}`);
    }
  }

  // Stack trace (if present)
  if (formatted.stack && formatted.stack.length > 0) {
    lines.push('Stack:');
    formatted.stack.forEach(line => lines.push(`  ${line}`));
  }

  return lines.join('\\n');
}

function cleanUrl(url) {
  if (!url) return null;

  // Remove sensitive tokens from URLs
  let cleaned = url;

  // Remove bot tokens from Telegram URLs
  cleaned = cleaned.replace(/bot\\d{9,10}:[A-Za-z0-9_-]{35}/g, 'bot***MASKED***');

  // Remove API keys from query params
  cleaned = cleaned.replace(/([?&])(api[_-]?key|token|secret|password|auth)=([^&]*)/gi, '$1$2=***MASKED***');

  // Truncate very long URLs
  if (cleaned.length > 200) {
    cleaned = cleaned.substring(0, 197) + '...';
  }

  return cleaned;
}

function sanitizeHeaders(headers) {
  if (!headers) return null;

  const sensitive = ['authorization', 'cookie', 'x-api-key', 'x-auth-token', 'x-secret'];
  const sanitized = {};

  for (const [key, value] of Object.entries(headers)) {
    const lowerKey = key.toLowerCase();
    if (sensitive.includes(lowerKey) || lowerKey.includes('token') || lowerKey.includes('secret')) {
      sanitized[key] = '***MASKED***';
    } else if (typeof value === 'string' && value.length > 100) {
      sanitized[key] = value.substring(0, 97) + '...';
    } else {
      sanitized[key] = value;
    }
  }

  return sanitized;
}

function truncateData(data) {
  if (!data) return null;

  let str;
  if (typeof data === 'string') {
    str = data;
  } else {
    try {
      str = JSON.stringify(data);
    } catch {
      str = String(data);
    }
  }

  // Remove any actual binary data indicators (but not escaped sequences in JSON)
  // Only check for real null bytes, not escaped sequences like \n
  const hasBinaryData = /[\x00-\x08\x0B\x0C\x0E-\x1F]/.test(str) && !str.includes('\\');
  if (hasBinaryData) {
    return '[Binary data omitted]';
  }

  // Truncate long data
  if (str.length > 500) {
    return str.substring(0, 497) + '...';
  }

  return str;
}

function formatStackTrace(stack) {
  if (!stack) return [];

  const lines = stack.split('\\n');
  const filtered = [];
  let count = 0;

  for (const line of lines) {
    // Skip the first line (error message)
    if (count === 0 && !line.trim().startsWith('at ')) {
      count++;
      continue;
    }

    // Skip node_modules entries
    if (line.includes('node_modules')) {
      continue;
    }

    // Skip internal node entries
    if (line.includes('node:internal') || line.includes('node:async_hooks')) {
      continue;
    }

    // Clean and add the line
    const cleaned = line.trim();
    if (cleaned) {
      filtered.push(cleaned);
      count++;
    }

    // Only keep first 5 relevant stack frames
    if (count >= 5) {
      break;
    }
  }

  return filtered;
}

export default {
  formatError,
  formatErrorMessage
};
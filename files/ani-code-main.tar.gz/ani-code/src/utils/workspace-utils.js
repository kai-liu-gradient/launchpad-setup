import { logger } from '../logger.js';

/**
 * Get workspace info and protection status for a given chat
 * @param {string} chatId - The chat ID (e.g., '394977994' or 'telegram:394977994')
 * @param {string} channel - The channel type (e.g., 'telegram', 'lark')
 * @param {string} taskCwd - Optional task working directory to find workspace
 * @returns {Promise<Object>} Workspace info with protection metadata
 */
export async function getWorkspaceProtectionInfo(chatId, channel = 'telegram', taskCwd = null) {
  try {
    const { WorkspaceManager } = await import('../workspace-manager.js');
    const manager = new WorkspaceManager();
    await manager.initialize();

    let workspace = null;
    let workspaceInfo = {
      workspace: null,
      isProtected: false,
      yoloStatus: null,
      protectionMode: null,
      error: null
    };

    // Try to find workspace by path first if provided
    if (taskCwd) {
      workspace = await manager.getWorkspaceByPath(taskCwd);
    }

    // If not found by path, try by chat ID
    if (!workspace && chatId) {
      // Normalize chat ID (remove channel prefix if present)
      const plainChatId = chatId.startsWith(`${channel}:`)
        ? chatId.substring(`${channel}:`.length + 1)
        : chatId;

      // Try to find workspace associated with this chat
      if (channel === 'telegram') {
        const telegramChat = await manager.getTelegramChat(plainChatId);
        if (telegramChat && telegramChat.workspace_id) {
          workspace = await manager.getWorkspace(telegramChat.workspace_id);
        }
      }
      // Add support for other channels as needed
    }

    if (workspace) {
      // Get YOLO status for the workspace
      const yoloStatus = await manager.getYoloStatus(workspace.id);

      workspaceInfo = {
        workspace: {
          id: workspace.id,
          name: workspace.name,
          path: workspace.path,
          settings: workspace.settings
        },
        isProtected: yoloStatus && yoloStatus.active,
        yoloStatus: yoloStatus,
        protectionMode: yoloStatus && yoloStatus.active ? 'yolo' : null,
        error: null
      };
    } else {
      workspaceInfo.error = 'Workspace not found';
    }

    await manager.close();
    return workspaceInfo;

  } catch (error) {
    logger.debug(`Failed to get workspace protection info: ${error.message}`);
    return {
      workspace: null,
      isProtected: false,
      yoloStatus: null,
      protectionMode: null,
      error: error.message
    };
  }
}

/**
 * Check if a task should be blocked due to workspace protection
 * @param {Object} task - The task object with chatId and cwd properties
 * @returns {Promise<boolean>} True if task notifications should be blocked
 */
export async function shouldBlockTaskNotification(task) {
  if (!task || !task.cwd) {
    return false;
  }

  const info = await getWorkspaceProtectionInfo(task.chatId, 'telegram', task.cwd);
  return info.isProtected;
}

/**
 * Check if a workspace is in YOLO mode by path
 * @param {string} workspacePath - The workspace path
 * @returns {Promise<boolean>} True if workspace is in YOLO mode
 */
export async function isWorkspaceInYoloMode(workspacePath) {
  if (!workspacePath) {
    return false;
  }

  try {
    const { WorkspaceManager } = await import('../workspace-manager.js');
    const manager = new WorkspaceManager();
    await manager.initialize();

    const workspace = await manager.getWorkspaceByPath(workspacePath);
    if (!workspace) {
      await manager.close();
      return false;
    }

    const yoloStatus = await manager.getYoloStatus(workspace.id);
    await manager.close();

    return yoloStatus && yoloStatus.active;
  } catch (error) {
    logger.debug(`Failed to check YOLO mode: ${error.message}`);
    return false;
  }
}
import os from 'os';
import { logger } from '../logger.js';

/**
 * Get standardized User-Agent string for all gateway requests
 * Format: "{hostname} ani-code-daemon"
 */
export function getGatewayUserAgent() {
  return `${os.hostname()} ani-code-daemon`;
}

/**
 * Make a request to the gateway with standardized headers
 * @param {string} url - Gateway endpoint URL
 * @param {object} options - fetch options
 * @param {object} gatewayConfig - Gateway configuration (instanceId, token)
 * @returns {Promise<Response>} - fetch response
 */
export async function gatewayFetch(url, options = {}, gatewayConfig = {}) {
  const headers = {
    'Content-Type': 'application/json',
    'User-Agent': getGatewayUserAgent(),
    ...options.headers
  };

  // Add gateway-specific headers if provided
  if (gatewayConfig.instanceId) {
    headers['x-instance-id'] = gatewayConfig.instanceId;
  }
  if (gatewayConfig.token) {
    headers['x-gateway-token'] = gatewayConfig.token;
  }

  const fetchOptions = {
    ...options,
    headers
  };

  logger.debug(`[Gateway Request] ${options.method || 'GET'} ${url}`, {
    userAgent: headers['User-Agent'],
    instanceId: gatewayConfig.instanceId ? '***' : 'none'
  });

  return fetch(url, fetchOptions);
}

/**
 * Convenience method for POST requests to gateway
 * @param {string} url - Gateway endpoint URL
 * @param {object} payload - Request body
 * @param {object} gatewayConfig - Gateway configuration
 * @param {object} options - Additional fetch options
 * @returns {Promise<Response>} - fetch response
 */
export async function gatewayPost(url, payload, gatewayConfig = {}, options = {}) {
  return gatewayFetch(url, {
    method: 'POST',
    body: JSON.stringify(payload),
    timeout: options.timeout || 10000,
    ...options
  }, gatewayConfig);
}

/**
 * Goals Utilities
 * Common utility functions for goal management operations
 */

import { existsSync, readdirSync, readFileSync, writeFileSync, statSync, mkdirSync } from 'fs';
import { join, basename } from 'path';
import chalk from 'chalk';

/**
 * Status normalization mapping
 */
const STATUS_NORMALIZATION_MAP = {
  // Not Started variations
  'pending': 'Not Started',
  'not started': 'Not Started',
  'notstarted': 'Not Started',
  'todo': 'Not Started',

  // In Progress variations
  'in progress': 'In Progress',
  'inprogress': 'In Progress',
  'ongoing': 'In Progress',
  'active': 'In Progress',
  'wip': 'In Progress',
  'work in progress': 'In Progress',

  // Completed variations
  'completed': 'Completed',
  'complete': 'Completed',
  'done': 'Completed',
  'finished': 'Completed',
  '✅ completed': 'Completed',
  '✅ complete': 'Completed',
  '100% complete': 'Completed',
  '100%': 'Completed',

  // Abandoned variations
  'abandoned': 'Abandoned',
  'abort': 'Abandoned',
  'aborted': 'Abandoned',

  // Cancelled variations
  'cancelled': 'Cancelled',
  'canceled': 'Cancelled',
  'cancel': 'Cancelled',

  // On Hold variations
  'on hold': 'On Hold',
  'onhold': 'On Hold',
  'paused': 'On Hold',
  'blocked': 'On Hold'
};

/**
 * Valid status values after normalization
 */
export const VALID_STATUSES = [
  'Not Started',
  'In Progress',
  'Completed',
  'Abandoned',
  'Cancelled',
  'On Hold'
];

/**
 * Status values that indicate a goal is finalized
 */
export const COMPLETED_STATUSES = ['Completed', 'Abandoned', 'Cancelled'];

/**
 * Extract status from markdown content using various patterns
 * @param {string} text - Markdown content
 * @returns {string|null} Extracted status or null
 */
export function extractStatus(text) {
  // Try multiple patterns for status extraction
  const patterns = [
    /^-\s*Status:\s*\*\*(.+?)\*\*/m,       // - Status: **Text**
    /^-\s*Status:\s*(.+?)$/m,               // - Status: Text
    /^-\s*\*\*Status\*\*:\s*(.+?)$/m,       // - **Status**: Text
    /^Status:\s*\*\*(.+?)\*\*/m,           // Status: **Text**
    /^Status:\s*(.+?)$/m,                  // Status: Text
    /^\*\*Status\*\*:\s*(.+?)$/m            // **Status**: Text
  ];

  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match) {
      return match[1].trim();
    }
  }

  return null;
}

/**
 * Normalize status to standard values
 * @param {string} rawStatus - Raw status string
 * @returns {string} Normalized status
 */
export function normalizeStatus(rawStatus) {
  if (!rawStatus) return 'Not Started';

  const cleaned = rawStatus
    .toLowerCase()
    .trim()
    .replace(/[^\w\s%✅]/g, '') // Remove special chars except checkmark
    .replace(/\s+/g, ' ');

  // Check against normalization map
  return STATUS_NORMALIZATION_MAP[cleaned] || rawStatus;
}

/**
 * Find all goal files in a directory
 * @param {string} goalsDir - Goals directory path
 * @returns {Array} Array of goal file paths
 */
export function findGoalFiles(goalsDir) {
  if (!existsSync(goalsDir)) {
    return [];
  }

  try {
    const files = readdirSync(goalsDir);
    return files
      .filter(file => {
        // Must be .md file starting with number
        return file.endsWith('.md') && /^\d+/.test(file);
      })
      .map(file => join(goalsDir, file))
      .sort((a, b) => {
        // Sort by numeric prefix
        const aId = extractGoalId(basename(a));
        const bId = extractGoalId(basename(b));
        return (aId || 0) - (bId || 0);
      });
  } catch (error) {
    console.error(chalk.red('Error reading goals directory:'), error.message);
    return [];
  }
}

/**
 * Extract goal ID from filename
 * @param {string} filename - Goal filename
 * @returns {number|null} Goal ID or null
 */
export function extractGoalId(filename) {
  const match = filename.match(/^(\d+)/);
  return match ? parseInt(match[1]) : null;
}

/**
 * Find goal file by ID
 * @param {number} goalId - Goal ID
 * @param {Array} goalFiles - Array of goal file paths
 * @returns {string|null} Goal file path or null
 */
export function findGoalFileById(goalId, goalFiles) {
  return goalFiles.find(file => {
    const id = extractGoalId(basename(file));
    return id === goalId;
  }) || null;
}

/**
 * Quick scan goal file for completion status
 * @param {string} goalFile - Path to goal file
 * @returns {Object} Quick scan result with id, file, isCompleted, status
 */
export function quickScanGoalStatus(goalFile) {
  const filename = basename(goalFile);
  const id = extractGoalId(filename) || 0;

  try {
    const content = readFileSync(goalFile, 'utf8');
    const rawStatus = extractStatus(content);

    if (!rawStatus) {
      return { id, file: filename, isCompleted: false };
    }

    const normalizedStatus = normalizeStatus(rawStatus);

    // Check if status indicates completion
    const isCompleted = COMPLETED_STATUSES.includes(normalizedStatus);

    return { id, file: filename, isCompleted, status: normalizedStatus };
  } catch (err) {
    return { id: 0, file: basename(goalFile), isCompleted: false };
  }
}

/**
 * Parse goal file and extract structured data
 * @param {string} filePath - Path to goal file
 * @returns {Object} Parsed goal data
 */
export function parseGoalFile(filePath) {
  const filename = basename(filePath);
  const id = extractGoalId(filename);
  const content = readFileSync(filePath, 'utf8');

  // Extract title
  const titleMatch = content.match(/^#\s+Goal:\s*(.+)$/m);
  const title = titleMatch ? titleMatch[1].trim() : filename;

  // Extract objective
  const objectiveMatch = content.match(/## Objective\s*\n([\s\S]*?)(?=\n##|$)/);
  const objective = objectiveMatch ? objectiveMatch[1].trim() : '';

  // Extract and parse tasks
  const tasksMatch = content.match(/## Tasks\s*\n([\s\S]*?)(?=\n##|$)/);
  let tasks = [];
  let tasksComplete = 0;

  if (tasksMatch) {
    const taskLines = tasksMatch[1].split('\n');
    tasks = taskLines
      .filter(line => line.trim().match(/^-\s*\[[ x]\]/i))
      .map(line => {
        const completed = line.includes('[x]') || line.includes('[X]');
        if (completed) tasksComplete++;
        const description = line.replace(/^-\s*\[[ x]\]\s*/i, '').trim();
        return { description, completed };
      });
  }

  // Extract and parse phases (alternative to tasks)
  const phasesMatch = content.match(/## Phases\s*\n([\s\S]*?)(?=\n##|$)/);
  let phases = [];
  let phasesComplete = 0;

  if (phasesMatch) {
    const phaseBlocks = phasesMatch[1].split(/\n### Phase \d+:/);
    phases = phaseBlocks
      .filter(block => block.trim())
      .map(block => {
        const lines = block.trim().split('\n');
        const nameMatch = lines[0].match(/^\s*(.+?)(?:\s*\(.*?\))?$/);
        const name = nameMatch ? nameMatch[1].trim() : 'Unknown Phase';

        const phaseTasks = lines
          .filter(line => line.trim().match(/^-\s*\[[ x]\]/i))
          .map(line => {
            const completed = line.includes('[x]') || line.includes('[X]');
            const description = line.replace(/^-\s*\[[ x]\]\s*/i, '').trim();
            return { description, completed };
          });

        const phaseCompleted = phaseTasks.length > 0 && phaseTasks.every(t => t.completed);
        if (phaseCompleted) phasesComplete++;

        return { name, tasks: phaseTasks, completed: phaseCompleted };
      });
  }

  // Extract status and dates
  const rawStatus = extractStatus(content);
  const status = normalizeStatus(rawStatus);

  // Extract dates
  const startDateMatch = content.match(/Start Date:\s*(.+?)$/m);
  const completionDateMatch = content.match(/Completion Date:\s*(.+?)$/m);
  const startDate = startDateMatch ? startDateMatch[1].trim() : '-';
  const completionDate = completionDateMatch ? completionDateMatch[1].trim() : '-';

  // Calculate completion percentage
  let completionPercentage = 0;
  if (tasks.length > 0) {
    completionPercentage = Math.round((tasksComplete / tasks.length) * 100);
  } else if (phases.length > 0) {
    completionPercentage = Math.round((phasesComplete / phases.length) * 100);
  }

  return {
    id,
    file: filename,
    path: filePath,
    title,
    objective,
    status,
    tasks,
    phases,
    taskCount: tasks.length,
    tasksComplete,
    phaseCount: phases.length,
    phasesComplete,
    completionPercentage,
    progress: {
      status,
      startDate,
      completionDate
    }
  };
}

/**
 * Calculate summary statistics from goals
 * @param {Array} goals - Array of goal objects
 * @param {number} totalGoals - Total number of goals
 * @returns {Object} Summary statistics
 */
export function calculateSummary(goals, totalGoals) {
  const statusCounts = {};
  let totalTasks = 0;
  let completedTasks = 0;

  VALID_STATUSES.forEach(status => {
    statusCounts[status] = 0;
  });

  goals.forEach(goal => {
    // Count status
    const status = goal.status || goal.progress?.status || 'Not Started';
    if (statusCounts[status] !== undefined) {
      statusCounts[status]++;
    }

    // Count tasks
    if (goal.taskCount > 0) {
      totalTasks += goal.taskCount;
      completedTasks += goal.tasksComplete || 0;
    } else if (goal.phaseCount > 0) {
      totalTasks += goal.phaseCount;
      completedTasks += goal.phasesComplete || 0;
    }
  });

  const overallCompletion = totalTasks > 0
    ? Math.round((completedTasks / totalTasks) * 100)
    : 0;

  return {
    totalGoals,
    statusCounts,
    overallCompletion,
    tasksComplete: completedTasks,
    totalTasks
  };
}

/**
 * Generate a progress bar string
 * @param {number} percentage - Completion percentage
 * @param {number} width - Bar width in characters
 * @returns {string} Progress bar string
 */
export function generateProgressBar(percentage, width = 20) {
  const filled = Math.round((percentage / 100) * width);
  const empty = width - filled;
  return '[' + '█'.repeat(filled) + '░'.repeat(empty) + ']';
}

/**
 * Convert CSV data to goals cache structure
 * @param {string} csvData - CSV data from Claude
 * @param {Array} existingGoals - Existing goals to preserve
 * @param {Array} goalFiles - All goal files for path mapping
 * @returns {Object} Cache data structure
 */
export function convertCsvToGoalsCache(csvData, existingGoals = [], goalFiles = []) {
  const lines = csvData.trim().split('\n');
  const goals = [];

  // Skip header if present
  const startIdx = lines[0].includes('id,file,status') ? 1 : 0;

  for (let i = startIdx; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;

    // Parse CSV line (handle quoted values)
    const parts = line.match(/(?:[^,"]|"(?:[^"]|"")*")+/g) || [];
    if (parts.length < 10) continue;

    const [id, file, status, completionPct, phaseCount, phasesComplete,
           taskCount, tasksComplete, startDate, completionDate] = parts.map(p =>
      p.replace(/^"|"$/g, '').replace(/""/g, '"')
    );

    // Find path for this goal
    const goalPath = goalFiles.find(f => basename(f) === file) || null;

    goals.push({
      id: parseInt(id) || 0,
      file,
      path: goalPath,
      status: status || 'Not Started',
      completionPercentage: parseInt(completionPct) || 0,
      phaseCount: parseInt(phaseCount) || 0,
      phasesComplete: parseInt(phasesComplete) || 0,
      taskCount: parseInt(taskCount) || 0,
      tasksComplete: parseInt(tasksComplete) || 0,
      progress: {
        status: status || 'Not Started',
        startDate: startDate === '-' ? null : startDate,
        completionDate: completionDate === '-' ? null : completionDate
      }
    });
  }

  // Merge with existing goals
  const mergedGoalsMap = new Map();

  // Add all existing goals to map
  existingGoals.forEach(goal => {
    mergedGoalsMap.set(goal.file, goal);
  });

  // Update or add goals from current batch
  goals.forEach(goal => {
    mergedGoalsMap.set(goal.file, goal);
  });

  // Convert back to array and sort by ID
  const mergedGoals = Array.from(mergedGoalsMap.values())
    .sort((a, b) => (a.id || 0) - (b.id || 0));

  return {
    goals: mergedGoals,
    totalGoals: mergedGoals.length,
    lastUpdated: new Date().toISOString()
  };
}

/**
 * Validate cache data against actual goal files
 * @param {Object} cacheData - Cache data to validate
 * @param {Array} goalFiles - Array of goal file paths
 * @param {Set} skipFiles - Set of files to skip validation
 * @returns {Object} Validation result with errors and problematic goals
 */
export function validateCacheWithFiles(cacheData, goalFiles, skipFiles = new Set()) {
  const errors = [];
  const warnings = [];
  const problematicGoals = [];

  if (!cacheData || !cacheData.goals) {
    errors.push('Cache data missing or invalid');
    return { errors, problematicGoals };
  }

  // Create map of cached goals
  const cachedGoals = new Map();
  cacheData.goals.forEach(goal => {
    cachedGoals.set(goal.file, goal);
  });

  // Validate each goal file
  goalFiles.forEach(goalFile => {
    const filename = basename(goalFile);

    // Skip if in skip set
    if (skipFiles.has(filename)) {
      return;
    }

    const cachedGoal = cachedGoals.get(filename);
    if (!cachedGoal) {
      errors.push(`Missing in cache: ${filename}`);
      problematicGoals.push(filename);
      return;
    }

    try {
      // Parse actual file
      const parsed = parseGoalFile(goalFile);

      // Validate status matches
      if (parsed.status !== cachedGoal.status) {
        errors.push(`Status mismatch for ${filename}: file="${parsed.status}" vs cache="${cachedGoal.status}"`);
        problematicGoals.push(filename);
      }

      // Task/phase counts - warn only, don't trigger fix
      // Task counts from file parsing vs AI extraction often differ due to parsing heuristics
      if (parsed.taskCount !== cachedGoal.taskCount) {
        warnings.push(`Task count mismatch for ${filename}: file=${parsed.taskCount} vs cache=${cachedGoal.taskCount}`);
      }

      if (parsed.tasksComplete !== cachedGoal.tasksComplete) {
        warnings.push(`Tasks complete mismatch for ${filename}: file=${parsed.tasksComplete} vs cache=${cachedGoal.tasksComplete}`);
      }

    } catch (err) {
      errors.push(`Failed to parse ${filename}: ${err.message}`);
      problematicGoals.push(filename);
    }
  });

  return {
    errors,
    warnings,
    problematicGoals: [...new Set(problematicGoals)] // Remove duplicates
  };
}

/**
 * Get iteration history file path for a goal
 * @param {string} workspacePath - Workspace root path
 * @param {number} goalId - Goal ID
 * @returns {string} Path to iteration history file
 */
export function getIterationHistoryPath(workspacePath, goalId) {
  const historyDir = join(workspacePath, '.ani-code', 'iteration-history');
  mkdirSync(historyDir, { recursive: true });

  return join(historyDir, `goal-${String(goalId).padStart(3, '0')}.json`);
}

/**
 * Add iteration to goal's history file
 * @param {string} workspacePath - Workspace root path
 * @param {Object} goal - Goal object
 * @param {Object} iterationData - Iteration data to add
 * @returns {Object} Iteration entry that was added
 */
export function addIterationToHistory(workspacePath, goal, iterationData) {
  const historyPath = getIterationHistoryPath(workspacePath, goal.id);

  // Load existing history
  let history = { goalId: goal.id, goalFile: goal.file, iterations: [] };
  if (existsSync(historyPath)) {
    try {
      const content = readFileSync(historyPath, 'utf8');
      history = JSON.parse(content);
    } catch (err) {
      console.error('Failed to read iteration history:', err.message);
    }
  }

  // Create new iteration entry
  const iteration = {
    timestamp: new Date().toISOString(),
    iterationNumber: history.iterations.length + 1,
    duration: iterationData.duration || 0,
    tokensUsed: iterationData.tokensUsed || 0,
    commitsMade: iterationData.commitsMade || 0,
    output: iterationData.output || '',
    status: iterationData.status || 'completed',
    taskId: iterationData.taskId || null,
    ...iterationData
  };

  // Add to history
  history.iterations.push(iteration);
  history.lastUpdated = new Date().toISOString();
  history.totalIterations = history.iterations.length;

  // Save to file
  writeFileSync(historyPath, JSON.stringify(history, null, 2));

  return iteration;
}

/**
 * Get recent iterations from history file
 * @param {string} workspacePath - Workspace root path
 * @param {number} goalId - Goal ID
 * @param {number} count - Number of recent iterations to retrieve
 * @returns {Array} Recent iterations
 */
export function getRecentIterations(workspacePath, goalId, count = 3) {
  const historyPath = getIterationHistoryPath(workspacePath, goalId);

  if (!existsSync(historyPath)) {
    return [];
  }

  try {
    const content = readFileSync(historyPath, 'utf8');
    const history = JSON.parse(content);

    if (!history.iterations || history.iterations.length === 0) {
      return [];
    }

    return history.iterations
      .slice(-count)
      .map(iter => ({
        iteration: iter.iterationNumber,
        timestamp: iter.timestamp,
        duration: iter.duration,
        tokensUsed: iter.tokensUsed,
        commitsMade: iter.commitsMade,
        summary: iter.output ? iter.output.substring(0, 300) : '',
        status: iter.status
      }));
  } catch (err) {
    console.error('Failed to read iteration history:', err.message);
    return [];
  }
}

/**
 * Clear the ANICODE_BREAK marker from the last iteration's failureReason.
 * This allows the goal to be retried on the next goalloop invocation
 * while preserving the iteration history record.
 * @param {string} workspacePath - Workspace root path
 * @param {number} goalId - Goal ID
 * @returns {boolean} True if cleared, false if nothing to clear
 */
export function clearAnicodeBreak(workspacePath, goalId) {
  const historyPath = getIterationHistoryPath(workspacePath, goalId);

  if (!existsSync(historyPath)) {
    return false;
  }

  try {
    const content = readFileSync(historyPath, 'utf8');
    const history = JSON.parse(content);

    if (!history.iterations || history.iterations.length === 0) {
      return false;
    }

    const lastIter = history.iterations[history.iterations.length - 1];
    if (lastIter.failureReason && lastIter.failureReason.includes('ANICODE_BREAK')) {
      // Rename the marker to indicate it was acknowledged, removing the blocking signal
      lastIter.failureReason = lastIter.failureReason.replace('ANICODE_BREAK: ', 'ANICODE_BREAK_HANDLED: ');
      // Also sanitize output and conclusion so secondary regex checks don't re-detect it
      if (lastIter.output) {
        lastIter.output = lastIter.output.replace(/__ANICODE_BREAK\(/g, '__ANICODE_BREAK_HANDLED(');
      }
      if (lastIter.conclusion) {
        lastIter.conclusion = lastIter.conclusion.replace(/__ANICODE_BREAK\(/g, '__ANICODE_BREAK_HANDLED(');
      }
      history.lastUpdated = new Date().toISOString();
      writeFileSync(historyPath, JSON.stringify(history, null, 2));
      return true;
    }

    return false;
  } catch (err) {
    console.error('Failed to clear ANICODE_BREAK:', err.message);
    return false;
  }
}

/**
 * Get last iteration info for context awareness
 * Returns the most recent iteration with its conclusion/failure information
 * @param {string} workspacePath - Workspace root path
 * @param {number} goalId - Goal ID
 * @returns {Object|null} Last iteration info or null if no history
 */
export function getLastIterationInfo(workspacePath, goalId) {
  const historyPath = getIterationHistoryPath(workspacePath, goalId);

  if (!existsSync(historyPath)) {
    return null;
  }

  try {
    const content = readFileSync(historyPath, 'utf8');
    const history = JSON.parse(content);

    if (!history.iterations || history.iterations.length === 0) {
      return null;
    }

    const lastIter = history.iterations[history.iterations.length - 1];

    return {
      iterationNumber: lastIter.iterationNumber,
      timestamp: lastIter.timestamp,
      duration: lastIter.duration,
      tokensUsed: lastIter.tokensUsed,
      commitsMade: lastIter.commitsMade,
      status: lastIter.status,
      output: lastIter.output || '',
      failureReason: lastIter.failureReason || null,
      conclusion: lastIter.conclusion || lastIter.output || '',
      totalIterations: history.totalIterations || history.iterations.length
    };
  } catch (err) {
    console.error('Failed to read iteration history:', err.message);
    return null;
  }
}

/**
 * Format iteration history for prompt injection
 * Creates a concise summary of recent iterations for Claude's context
 * @param {string} workspacePath - Workspace root path
 * @param {number} goalId - Goal ID
 * @param {number} count - Number of recent iterations to include
 * @returns {string} Formatted iteration history string
 */
export function formatIterationHistoryForPrompt(workspacePath, goalId, count = 3) {
  const historyPath = getIterationHistoryPath(workspacePath, goalId);

  if (!existsSync(historyPath)) {
    return '';
  }

  try {
    const content = readFileSync(historyPath, 'utf8');
    const history = JSON.parse(content);

    if (!history.iterations || history.iterations.length === 0) {
      return '';
    }

    const recentIterations = history.iterations.slice(-count);

    let formatted = `## Previous Iterations (${history.totalIterations || history.iterations.length} total)\n\n`;

    recentIterations.forEach((iter, idx) => {
      const date = new Date(iter.timestamp).toLocaleString();
      const durationMins = Math.floor((iter.duration || 0) / 60);
      const durationSecs = (iter.duration || 0) % 60;

      formatted += `### Iteration ${iter.iterationNumber} (${date})\n`;
      formatted += `- **Status:** ${iter.status || 'unknown'}\n`;
      formatted += `- **Duration:** ${durationMins}m ${durationSecs}s\n`;
      formatted += `- **Commits:** ${iter.commitsMade || 0}\n`;

      if (iter.failureReason) {
        formatted += `- **Failure Reason:** ${iter.failureReason}\n`;
      }

      if (iter.output) {
        // Truncate output to avoid bloating prompt
        const truncatedOutput = iter.output.length > 500
          ? iter.output.substring(0, 500) + '...'
          : iter.output;
        formatted += `- **Conclusion:**\n\`\`\`\n${truncatedOutput}\n\`\`\`\n`;
      }

      formatted += '\n';
    });

    // Add last failure warning if applicable
    const lastIter = recentIterations[recentIterations.length - 1];
    if (lastIter && lastIter.status === 'failed') {
      formatted += `⚠️ **IMPORTANT:** The last iteration FAILED. Review the failure reason above and avoid repeating the same mistake.\n\n`;
    }

    return formatted;
  } catch (err) {
    console.error('Failed to format iteration history:', err.message);
    return '';
  }
}

/**
 * Wait for task completion with timeout
 * @param {Object} client - IPC client instance
 * @param {string} taskId - Task ID to wait for
 * @param {number} timeoutSeconds - Timeout in seconds
 * @returns {Promise<boolean>} True if completed, false if timed out
 */
export async function waitForTaskCompletion(client, taskId, timeoutSeconds = 300) {
  const startTime = Date.now();
  const timeoutMs = timeoutSeconds * 1000;

  while (Date.now() - startTime < timeoutMs) {
    const taskInfo = await client.getTask(taskId);

    if (taskInfo && (taskInfo.status === 'completed' || taskInfo.status === 'failed')) {
      return true;
    }

    // Wait 2 seconds before checking again
    await new Promise(resolve => setTimeout(resolve, 2000));
  }

  return false;
}
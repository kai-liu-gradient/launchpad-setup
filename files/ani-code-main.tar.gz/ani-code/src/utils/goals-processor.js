/**
 * Goals Processor
 * Unified processing logic for all goal operations
 */

import chalk from 'chalk';
import { existsSync, readFileSync, writeFileSync, mkdirSync, statSync } from 'fs';
import { join, basename } from 'path';
import { DaemonClient } from '../daemon-client.js';
import { IPCClient } from '../ipc-client.js';
import { WorkspaceManager } from '../workspace-manager.js';
import {
  findGoalFiles,
  quickScanGoalStatus,
  parseGoalFile,
  calculateSummary,
  validateCacheWithFiles,
  convertCsvToGoalsCache,
  waitForTaskCompletion,
  extractStatus,
  normalizeStatus,
  COMPLETED_STATUSES,
  VALID_STATUSES
} from './goals-utils.js';
import {
  buildGoalAnalysisPrompt,
  buildValidationPrompt
} from '../prompts/goals-prompts.js';

/**
 * Unified goals processing configuration
 */
export class GoalsProcessor {
  constructor(goalsDir, options = {}) {
    this.goalsDir = goalsDir;
    this.workspacePath = goalsDir.replace(/\/pd\/goals\/?$/, '');
    this.options = options;
    this.batchSize = options.batchSize || 10;
    this.cacheDir = join(this.workspacePath, '.ani-code');
    this.cacheFile = join(this.cacheDir, 'goals-cache.json');
  }

  /**
   * Load cache from workspace
   */
  async loadCache() {
    if (!existsSync(this.cacheFile)) {
      return { data: null, exists: false };
    }

    try {
      const cacheContent = readFileSync(this.cacheFile, 'utf8');
      const data = JSON.parse(cacheContent);
      return { data, exists: true };
    } catch (error) {
      console.error(chalk.red('Error loading cache:'), error.message);
      return { data: null, exists: false, error: error.message };
    }
  }

  /**
   * Save cache to workspace
   */
  async saveCache(data) {
    try {
      // Ensure cache directory exists
      mkdirSync(this.cacheDir, { recursive: true });

      // Calculate summary if not present
      if (!data.summary) {
        data.summary = calculateSummary(data.goals, data.totalGoals);
      }

      // Sort goals by ID before saving
      data.goals = data.goals.sort((a, b) => (a.id || 0) - (b.id || 0));

      // Save cache
      writeFileSync(this.cacheFile, JSON.stringify(data, null, 2));
      return true;
    } catch (error) {
      console.error(chalk.red('Error saving cache:'), error.message);
      return false;
    }
  }

  /**
   * Check if cache is valid
   */
  async isCacheValid() {
    const { data: cacheData } = await this.loadCache();

    if (!cacheData || !cacheData.lastUpdated) {
      return { valid: false, reason: 'Cache missing or has no timestamp' };
    }

    if (!existsSync(this.goalsDir)) {
      return { valid: true }; // No source files, cache is valid
    }

    const cacheTime = new Date(cacheData.lastUpdated).getTime();
    const goalFiles = findGoalFiles(this.goalsDir);

    // Build map of cached goals
    const cachedGoals = new Map();
    if (cacheData.goals) {
      cacheData.goals.forEach(g => {
        cachedGoals.set(g.file, g);
      });
    }

    // Check for new or modified files
    const newFiles = [];
    const modifiedFiles = [];

    for (const file of goalFiles) {
      const filename = basename(file);
      const cachedGoal = cachedGoals.get(filename);

      if (!cachedGoal) {
        newFiles.push(filename);
        continue;
      }

      // Skip completed goals
      const status = cachedGoal.status || cachedGoal.progress?.status;
      if (COMPLETED_STATUSES.includes(status)) {
        continue;
      }

      // Check if file was modified
      const stats = existsSync(file) ? statSync(file) : null;
      if (stats && stats.mtimeMs > (cacheTime + 1000)) {
        modifiedFiles.push(filename);
      }
    }

    if (newFiles.length > 0 || modifiedFiles.length > 0) {
      return {
        valid: false,
        reason: `Found ${newFiles.length} new and ${modifiedFiles.length} modified files`,
        newFiles,
        modifiedFiles
      };
    }

    return { valid: true };
  }

  /**
   * Pre-validate goal files
   */
  preValidateGoalFiles(goalFiles) {
    const problematicFiles = [];
    const validationMap = new Map();

    for (const goalFile of goalFiles) {
      const filename = basename(goalFile);
      const errors = [];

      try {
        const content = readFileSync(goalFile, 'utf8');

        // Check for Status line
        const rawStatus = extractStatus(content);
        if (!rawStatus) {
          errors.push('Missing Status line in Progress section');
        } else {
          const status = normalizeStatus(rawStatus);
          if (!VALID_STATUSES.includes(status)) {
            errors.push(`Invalid status: "${rawStatus}" needs normalization`);
          }
        }

        // Check task format
        const taskMatches = content.match(/^-\s*\[[ x]\]/gm);
        if (taskMatches) {
          const invalidTasks = taskMatches.filter(t =>
            !t.match(/^-\s*\[[x ]\]/i)
          );
          if (invalidTasks.length > 0) {
            errors.push(`${invalidTasks.length} malformed task checkboxes`);
          }
        }

        if (errors.length > 0) {
          problematicFiles.push({ file: filename, errors });
          validationMap.set(filename, errors);
        }
      } catch (err) {
        problematicFiles.push({ file: filename, error: err.message });
        validationMap.set(filename, [err.message]);
      }
    }

    return { problematicFiles, validationMap };
  }

  /**
   * Process goals with unified logic
   * This is the main processing function used by all subcommands
   */
  async processGoals(mode = 'sync') {
    const { fullResync, skipFix, fastMode } = this.options;
    const skipFixMode = skipFix || fastMode;

    // Display mode information
    if (fastMode) {
      console.log(chalk.yellow('Fast mode enabled — skipping auto-fix and reusing cached completed goals.'));
    } else if (skipFix) {
      console.log(chalk.yellow('Skipping auto-fix phase (--no-fix).'));
    }

    // Find goal files
    const goalFiles = findGoalFiles(this.goalsDir);
    if (goalFiles.length === 0) {
      console.log(chalk.yellow('No goal files found in'), chalk.cyan(this.goalsDir));
      return { success: false, message: 'No goal files found' };
    }

    console.log(chalk.cyan(`Processing ${goalFiles.length} goal files...\n`));

    // Check daemon
    const daemonClient = new DaemonClient();
    if (!daemonClient.isDaemonRunning()) {
      console.error(chalk.red('Error: Daemon is not running'));
      console.log(chalk.yellow('Start the daemon with: ani-code daemon --start'));
      return { success: false, message: 'Daemon not running' };
    }

    // Handle full resync confirmation
    if (fullResync) {
      const { data: existingCache } = await this.loadCache();
      if (existingCache && existingCache.goals && existingCache.goals.length > 0) {
        console.log(chalk.yellow('\n⚠ Warning: Full resync mode enabled'));
        console.log(chalk.gray(`  Existing cache contains ${existingCache.goals.length} goal(s)`));
        console.log(chalk.yellow('  This will re-analyze all goals and override the cache.\n'));

        // In processor, we assume confirmation was already handled
        // or we proceed automatically based on options
        if (this.options.autoConfirm !== true) {
          // Caller should handle confirmation
          return { success: false, message: 'Full resync requires confirmation', needsConfirmation: true };
        }
      }
    }

    // Pre-validate files
    console.log(chalk.gray('Pre-validating goal files...'));
    const preValidationResult = this.preValidateGoalFiles(goalFiles);

    // Filter out completed goals from validation issues
    const quickCompletedScan = goalFiles.map(f => quickScanGoalStatus(f)).filter(r => r.isCompleted);
    const quickCompletedSet = new Set(quickCompletedScan.map(r => r.file));

    const nonCompletedProblematic = preValidationResult.problematicFiles.filter(p =>
      !quickCompletedSet.has(p.file)
    );

    if (nonCompletedProblematic.length > 0) {
      console.log(chalk.yellow(`Found ${nonCompletedProblematic.length} non-completed files with issues`));
      nonCompletedProblematic.slice(0, 5).forEach(item => {
        const errors = item.errors || [item.error];
        console.log(chalk.dim(`  - ${item.file}: ${errors.join('; ')}`));
      });
      if (nonCompletedProblematic.length > 5) {
        console.log(chalk.dim(`  ... and ${nonCompletedProblematic.length - 5} more`));
      }
    }

    // Prepare files to analyze
    let filesToAnalyze = goalFiles;
    let completedGoals = [];

    if (!fullResync) {
      // Load existing cache and skip completed goals AND manual override goals
      const { data: existingCache } = await this.loadCache();
      if (existingCache && existingCache.goals) {
        const cacheTime = new Date(existingCache.lastUpdated).getTime();

        completedGoals = existingCache.goals
          .filter(goal => {
            const status = goal.status || goal.progress?.status;
            // Include completed statuses OR manual overrides (preserve user's manual status changes)
            const shouldSkip = COMPLETED_STATUSES.includes(status) || goal.manualOverride;
            if (!shouldSkip) return false;

            const goalFile = goalFiles.find(f => basename(f) === goal.file);
            if (!goalFile) return false;

            if (fastMode || goal.manualOverride) return true; // Skip file time check in fast mode or for manual overrides

            // Check if file was modified
            const stats = existsSync(goalFile) ? statSync(goalFile) : null;
            return !stats || stats.mtimeMs <= (cacheTime + 1000);
          })
          .map(goal => {
            const goalFile = goalFiles.find(f => basename(f) === goal.file);
            return { ...goal, path: goalFile };
          });

        // Filter out files to analyze
        const skippedFiles = new Set(completedGoals.map(g => g.file));
        filesToAnalyze = goalFiles.filter(f => !skippedFiles.has(basename(f)));

        // Log what we're skipping
        const manualOverrideCount = completedGoals.filter(g => g.manualOverride).length;
        const completedCount = completedGoals.length - manualOverrideCount;
        if (completedCount > 0) {
          console.log(chalk.green(`Skipping ${completedCount} completed goals`));
        }
        if (manualOverrideCount > 0) {
          console.log(chalk.yellow(`Preserving ${manualOverrideCount} manual override goals`));
        }
      }
    } else {
      // Full resync: scan for completed goals BUT preserve manual overrides from cache
      console.log(chalk.gray('Scanning for completed goals...'));
      const quickScanResults = goalFiles.map(f => quickScanGoalStatus(f));
      const completedFiles = quickScanResults.filter(r => r.isCompleted);

      // Load existing cache to preserve manual overrides even in full resync
      const { data: existingCache } = await this.loadCache();
      const manualOverrideGoals = (existingCache?.goals || [])
        .filter(g => g.manualOverride)
        .map(goal => {
          const goalFile = goalFiles.find(f => basename(f) === goal.file);
          return { ...goal, path: goalFile };
        });

      const manualOverrideFiles = new Set(manualOverrideGoals.map(g => g.file));

      completedGoals = completedFiles
        .filter(r => !manualOverrideFiles.has(r.file)) // Don't duplicate manual override goals
        .map(r => {
          const goalFile = goalFiles.find(f => basename(f) === r.file);
          return {
            id: r.id,
            file: r.file,
            path: goalFile,
            status: r.status,
            simplifiedAnalysis: true
          };
        });

      // Add manual override goals (preserved from cache)
      completedGoals = [...completedGoals, ...manualOverrideGoals];

      const skippedFileSet = new Set(completedGoals.map(g => g.file));
      filesToAnalyze = goalFiles.filter(f => !skippedFileSet.has(basename(f)));

      if (completedGoals.length > 0) {
        const manualCount = manualOverrideGoals.length;
        const completedCount = completedGoals.length - manualCount;
        if (completedCount > 0) {
          console.log(chalk.green(`Found ${completedCount} completed goals (simplified analysis)`));
        }
        if (manualCount > 0) {
          console.log(chalk.yellow(`Preserving ${manualCount} manual override goals`));
        }
      }
    }

    if (filesToAnalyze.length === 0) {
      console.log(chalk.green('All goals are completed and unchanged'));
      return { success: true, message: 'All goals up to date' };
    }

    // Process goals in batches with Claude
    const client = new IPCClient();
    await client.connect();

    try {
      // Phase 1: Analysis
      console.log(chalk.cyan('\nPhase 1: Analyzing goals...'));
      const analysisResult = await this.analyzeGoalsInBatches(
        client,
        filesToAnalyze,
        completedGoals
      );

      if (!analysisResult.success) {
        return analysisResult;
      }

      // Save initial cache
      console.log(chalk.cyan('\nSaving cache...'));
      await this.saveCache(analysisResult.cacheData);
      console.log(chalk.green('Cache saved successfully'));

      // Phase 2: Validation and fixes
      if (!skipFixMode) {
        const validationResult = await this.validateAndFixGoals(
          client,
          analysisResult.cacheData,
          goalFiles,
          preValidationResult.validationMap
        );

        if (validationResult.updated) {
          await this.saveCache(validationResult.cacheData);
          console.log(chalk.green('Cache updated with fixes'));
        }
      }

      await client.disconnect();
      return { success: true, message: 'Goals processed successfully' };

    } catch (error) {
      await client.disconnect();
      console.error(chalk.red('Processing error:'), error.message);
      return { success: false, message: error.message };
    }
  }

  /**
   * Analyze goals in batches using Claude
   */
  async analyzeGoalsInBatches(client, filesToAnalyze, completedGoals) {
    const totalBatches = Math.ceil(filesToAnalyze.length / this.batchSize);
    let accumulatedGoals = [...completedGoals];

    console.log(chalk.gray(`Processing ${filesToAnalyze.length} files in ${totalBatches} batch(es)...`));

    for (let batchIndex = 0; batchIndex < totalBatches; batchIndex++) {
      const startIdx = batchIndex * this.batchSize;
      const endIdx = Math.min(startIdx + this.batchSize, filesToAnalyze.length);
      const batchFiles = filesToAnalyze.slice(startIdx, endIdx);

      console.log(chalk.cyan(`\nBatch ${batchIndex + 1}/${totalBatches}: ${batchFiles.length} files`));

      // Build prompt
      const prompt = buildGoalAnalysisPrompt(batchFiles, accumulatedGoals);
      const task = await client.addTask('goals-sync', prompt, { cwd: this.workspacePath });

      // Wait for completion (30 minutes minimum for ani-code task)
      console.log(chalk.gray('Waiting for Claude...'));
      const completed = await waitForTaskCompletion(client, task.id, 1800);

      if (!completed) {
        console.error(chalk.red(`Batch ${batchIndex + 1} timed out after 30 minutes`));
        return { success: false, message: 'Batch processing timed out' };
      }

      // Get output
      const taskInfo = await client.getTask(task.id);
      if (!taskInfo || !taskInfo.output) {
        console.error(chalk.red(`No output from batch ${batchIndex + 1}`));
        return { success: false, message: 'No output from Claude' };
      }

      // Parse CSV output
      let csvData = taskInfo.output.trim();

      // Extract CSV from markdown if needed
      if (csvData.includes('```csv')) {
        const match = csvData.match(/```csv\n([\s\S]*?)\n```/);
        if (match) csvData = match[1].trim();
      } else if (csvData.includes('```')) {
        const match = csvData.match(/```\n([\s\S]*?)\n```/);
        if (match) csvData = match[1].trim();
      }

      // Convert to cache format
      const batchCache = convertCsvToGoalsCache(csvData, accumulatedGoals, findGoalFiles(this.goalsDir));

      // Update accumulated goals - batchCache.goals already contains merged data from convertCsvToGoalsCache
      const previousCount = accumulatedGoals.length;
      accumulatedGoals = batchCache.goals;
      const newGoalsCount = accumulatedGoals.length - previousCount;

      console.log(chalk.green(`✓ Batch complete - ${newGoalsCount} new goals analyzed`));
      console.log(chalk.gray(`  Total accumulated: ${accumulatedGoals.length}`));
    }

    // Create final cache
    const cacheData = {
      goals: accumulatedGoals,
      totalGoals: findGoalFiles(this.goalsDir).length,
      lastUpdated: new Date().toISOString(),
      summary: calculateSummary(accumulatedGoals, accumulatedGoals.length)
    };

    return { success: true, cacheData };
  }

  /**
   * Validate and fix goals if needed
   */
  async validateAndFixGoals(client, cacheData, goalFiles, preValidationMap) {
    console.log(chalk.cyan('\nPhase 2: Validating cache...'));

    // Skip validation for completed goals
    const completedFiles = new Set(
      cacheData.goals
        .filter(g => COMPLETED_STATUSES.includes(g.status || g.progress?.status))
        .map(g => g.file)
    );

    // Validate cache
    const validationResult = validateCacheWithFiles(cacheData, goalFiles, completedFiles);

    // Log warnings (task count mismatches - info only, no fix needed)
    if (validationResult.warnings?.length > 0) {
      console.log(chalk.yellow(`⚠ ${validationResult.warnings.length} task count warning(s):`));
      validationResult.warnings.forEach(w => console.log(chalk.dim(`  - ${w}`)));
    }

    // Merge validation issues
    const allProblematicGoals = new Set([
      ...Array.from(preValidationMap.keys()),
      ...validationResult.problematicGoals
    ]);

    // Filter out completed goals
    const problematicGoals = Array.from(allProblematicGoals)
      .filter(file => !completedFiles.has(file));

    if (problematicGoals.length === 0) {
      console.log(chalk.green('✓ Validation passed'));
      return { updated: false, cacheData };
    }

    console.log(chalk.yellow(`Found ${problematicGoals.length} goals needing fixes`));

    // Fix goals in batches
    console.log(chalk.cyan('\nPhase 2b: Fixing problematic goals...'));
    const fixBatches = Math.ceil(problematicGoals.length / this.batchSize);

    for (let batchIndex = 0; batchIndex < fixBatches; batchIndex++) {
      const startIdx = batchIndex * this.batchSize;
      const endIdx = Math.min(startIdx + this.batchSize, problematicGoals.length);
      const batchGoals = problematicGoals.slice(startIdx, endIdx);

      console.log(chalk.cyan(`\nFix batch ${batchIndex + 1}/${fixBatches}: ${batchGoals.length} files`));

      // Build validation prompt
      const prompt = buildValidationPrompt(
        batchGoals.map(f => join(this.goalsDir, f)),
        validationResult.errors,
        preValidationMap
      );

      const task = await client.addTask('goals-validate', prompt, { cwd: this.workspacePath });

      // Wait for completion (30 minutes minimum for ani-code task)
      const completed = await waitForTaskCompletion(client, task.id, 1800);
      if (!completed) {
        console.warn(chalk.yellow(`Fix batch ${batchIndex + 1} timed out after 30 minutes`));
        continue;
      }

      // Re-parse fixed files
      console.log(chalk.gray('Re-parsing fixed files...'));
      const fixedGoals = [];

      for (const goalFile of batchGoals) {
        const goalPath = join(this.goalsDir, goalFile);
        try {
          const parsed = parseGoalFile(goalPath);
          fixedGoals.push(parsed);
        } catch (err) {
          console.warn(chalk.yellow(`Failed to re-parse ${goalFile}`));
        }
      }

      // Update cache
      if (fixedGoals.length > 0) {
        cacheData.goals = cacheData.goals.filter(g => !batchGoals.includes(g.file));
        cacheData.goals.push(...fixedGoals);
        console.log(chalk.green(`✓ Updated ${fixedGoals.length} goals`));
      }
    }

    // Recalculate summary
    cacheData.summary = calculateSummary(cacheData.goals, cacheData.totalGoals);
    return { updated: true, cacheData };
  }
}

/**
 * Export factory function for convenience
 */
export function createGoalsProcessor(goalsDir, options = {}) {
  return new GoalsProcessor(goalsDir, options);
}
import { createReadStream, promises as fs } from 'fs';
import path from 'path';
import crypto from 'crypto';
import chalk from 'chalk';
import { logger } from '../logger.js';
import archiver from 'archiver';
import { pipeline } from 'stream/promises';
import { createWriteStream } from 'fs';
import fetch from 'node-fetch';

// Dynamic import for optional AWS SDK
let S3Client, PutObjectCommand;
try {
  const awsSdk = await import('@aws-sdk/client-s3');
  S3Client = awsSdk.S3Client;
  PutObjectCommand = awsSdk.PutObjectCommand;
} catch {
  // AWS SDK not installed - S3 uploads will be disabled
  logger.debug('@aws-sdk/client-s3 not installed - S3 uploads disabled');
}

export class SecureUploader {
  constructor() {
    this.bucketName = process.env.S3_CACHE_BUCKET;
    this.s3Endpoint = process.env.S3_ENDPOINT;
    this.s3Client = null;
    this.endpoint = null;
    this.initialized = false;
  }

  /**
   * Initialize S3 client with credentials
   */
  async initialize() {
    if (this.initialized) return true;

    if (!S3Client) {
      throw new Error('@aws-sdk/client-s3 is not installed. Run: npm install @aws-sdk/client-s3');
    }

    if (!this.bucketName) {
      throw new Error('S3_CACHE_BUCKET environment variable not set');
    }

    if (!this.s3Endpoint) {
      throw new Error('S3_ENDPOINT environment variable not set');
    }

    // Parse S3 endpoint securely
    const endpointMatch = this.s3Endpoint.match(/^s3:\/\/([^:]+):([^@]+)@(.+)$/);
    if (!endpointMatch) {
      throw new Error('Invalid S3_ENDPOINT format. Expected: s3://ACCESS_KEY:SECRET_KEY@endpoint-url');
    }

    const [, accessKeyId, secretAccessKey, endpoint] = endpointMatch;
    this.endpoint = endpoint;

    // Initialize S3 client
    this.s3Client = new S3Client({
      endpoint: `https://${endpoint}`,
      region: 'auto',
      credentials: {
        accessKeyId,
        secretAccessKey
      },
      forcePathStyle: process.env.S3_FORCE_PATH_STYLE === 'true'
    });

    this.initialized = true;
    return true;
  }

  /**
   * Mask sensitive credentials in messages
   */
  static maskCredentials(text) {
    if (!text) return text;

    // Patterns to mask
    const patterns = [
      // Telegram bot tokens in URLs (highest priority)
      /https?:\/\/api\.telegram\.org\/(file\/)?bot\d{9,10}:[A-Za-z0-9_-]{30,}/gi,
      
      // Bot tokens (Telegram, Discord, etc)
      /\b\d{9,10}:[A-Za-z0-9_-]{30,}\b/g, // Telegram bot token
      /Bot\s+[A-Za-z0-9._-]{50,}/gi, // Discord bot token
      
      // API keys and secrets
      /\b(api[_-]?key|apikey|secret[_-]?key|access[_-]?key|private[_-]?key)\s*[:=]\s*['"]*([A-Za-z0-9_\-]{20,})['"]*\b/gi,
      
      // AWS credentials
      /\b(AKIA[A-Z0-9]{16})\b/g, // AWS Access Key ID
      // Removed overly broad AWS Secret Key pattern - was matching git hashes and other legitimate strings
      
      // S3 endpoint with credentials
      /s3:\/\/[^:]+:[^@]+@[^\s]+/g,
      
      // Bearer tokens
      /Bearer\s+[A-Za-z0-9._-]{20,}/gi,
      
      // Generic secrets in environment variable format (require = sign to avoid false positives)
      /\b[A-Z_]{2,}_TOKEN\s*=\s*['"]*[A-Za-z0-9_\-]{20,}['"]*\b/g,
      /\b[A-Z_]{2,}_SECRET\s*=\s*['"]*[A-Za-z0-9_\-]{20,}['"]*\b/g,
    ];

    let maskedText = text;
    
    // Apply all patterns
    patterns.forEach(pattern => {
      maskedText = maskedText.replace(pattern, (match) => {
        // Special handling for Telegram API URLs
        if (match.includes('api.telegram.org')) {
          // Preserve the actual endpoint path for better debugging
          return match.replace(/\/(file\/)?bot\d{9,10}:[A-Za-z0-9_-]{30,}/, (m) => {
            return m.startsWith('/file/') ? '/file/bot***MASKED***' : '/bot***MASKED***';
          });
        }
        
        // Keep first and last 2 characters for partial identification
        if (match.length > 10) {
          const prefix = match.substring(0, 3);
          const suffix = match.substring(match.length - 2);
          return `${prefix}***MASKED***${suffix}`;
        }
        return '***MASKED***';
      });
    });

    return maskedText;
  }

  /**
   * Archive a directory into a tar.gz file
   */
  async archiveDirectory(dirPath, outputPath) {
    const output = createWriteStream(outputPath);
    const archive = archiver('tar', {
      gzip: true,
      gzipOptions: {
        level: 9
      }
    });

    const archivePromise = new Promise((resolve, reject) => {
      output.on('close', () => resolve(archive.pointer()));
      archive.on('error', reject);
    });

    archive.pipe(output);
    
    // Add directory to archive
    archive.directory(dirPath, false);
    
    await archive.finalize();
    await archivePromise;
    
    return outputPath;
  }

  /**
   * Upload workspace temp folders
   */
  async uploadWorkspaceTempFolders(workspacePath) {
    await this.initialize();

    const results = [];
    const tempDirs = [];

    // Common temp directory names
    const tempDirNames = ['tmp', 'temp', '.tmp', '.temp', 'cache', '.cache'];
    
    // Find all temp directories in workspace
    for (const tempName of tempDirNames) {
      const tempPath = path.join(workspacePath, tempName);
      try {
        const stat = await fs.stat(tempPath);
        if (stat.isDirectory()) {
          tempDirs.push({
            name: tempName,
            path: tempPath,
            size: await this.getDirectorySize(tempPath)
          });
        }
      } catch (err) {
        // Directory doesn't exist, skip
      }
    }

    // Also check for node_modules/.cache
    const nodeModulesCache = path.join(workspacePath, 'node_modules', '.cache');
    try {
      const stat = await fs.stat(nodeModulesCache);
      if (stat.isDirectory()) {
        tempDirs.push({
          name: 'node_modules/.cache',
          path: nodeModulesCache,
          size: await this.getDirectorySize(nodeModulesCache)
        });
      }
    } catch (err) {
      // Directory doesn't exist, skip
    }

    if (tempDirs.length === 0) {
      logger.info('No temp directories found in workspace');
      return results;
    }

    logger.info(`Found ${tempDirs.length} temp directories to upload`);

    // Create archives and upload
    for (const dir of tempDirs) {
      try {
        // Skip if directory is too large (> 100MB)
        if (dir.size > 100 * 1024 * 1024) {
          logger.warn(`Skipping ${dir.name}: too large (${this.formatFileSize(dir.size)})`);
          continue;
        }

        // Create archive
        const archiveName = `${dir.name.replace(/[\/\\]/g, '-')}-${Date.now()}.tar.gz`;
        const archivePath = path.join('/tmp', archiveName);
        
        logger.info(`Archiving ${dir.name} (${this.formatFileSize(dir.size)})...`);
        await this.archiveDirectory(dir.path, archivePath);
        
        // Get archive size
        const archiveStats = await fs.stat(archivePath);
        
        // Upload archive
        const uploadResult = await this.uploadFile(archivePath, {
          metadata: {
            'source-type': 'temp-folder',
            'source-path': dir.path,
            'workspace': path.basename(workspacePath),
            'original-size': dir.size.toString()
          }
        });

        // Clean up archive
        await fs.unlink(archivePath);

        results.push({
          directory: dir.name,
          originalSize: this.formatFileSize(dir.size),
          archiveSize: this.formatFileSize(archiveStats.size),
          url: uploadResult.url,
          s3Key: uploadResult.s3Key
        });

        logger.info(`Uploaded ${dir.name}: ${uploadResult.url}`);
      } catch (error) {
        logger.error(`Failed to upload ${dir.name}:`, error);
        results.push({
          directory: dir.name,
          error: error.message
        });
      }
    }

    return results;
  }

  /**
   * Upload image or document from URL to S3
   */
  async uploadImageFromUrl(imageUrl, options = {}) {
    await this.initialize();

    try {
      // Download the file with timeout
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 30000); // 30 second timeout
      
      const response = await fetch(imageUrl, {
        signal: controller.signal,
        headers: {
          'Connection': 'close',
          'Cache-Control': 'no-cache'
        },
        keepalive: false
      });
      
      clearTimeout(timeout);
      
      if (!response.ok) {
        throw new Error(`Failed to download file: ${response.status}`);
      }

      const buffer = Buffer.from(await response.arrayBuffer());
      
      // Determine extension from filename, content-type, or default
      let extension = '.jpg';
      const fileName = options.fileName;
      const contentType = response.headers.get('content-type');
      
      // First try to get extension from filename if provided
      if (fileName) {
        const fileExt = fileName.toLowerCase().match(/\.[^.]+$/)?.[0];
        if (fileExt) {
          extension = fileExt;
        }
      } 
      // Otherwise determine from content-type
      else if (contentType) {
        if (contentType.includes('png')) extension = '.png';
        else if (contentType.includes('gif')) extension = '.gif';
        else if (contentType.includes('webp')) extension = '.webp';
        else if (contentType.includes('bmp')) extension = '.bmp';
        else if (contentType.includes('pdf')) extension = '.pdf';
        else if (contentType.includes('msword')) extension = '.doc';
        else if (contentType.includes('wordprocessingml')) extension = '.docx';
        else if (contentType.includes('text/plain')) extension = '.txt';
        else if (contentType.includes('markdown')) extension = '.md';
      }

      // Calculate MD5
      const md5Hash = crypto.createHash('md5').update(buffer).digest('hex');

      // Generate S3 key with improved naming
      const workdir = options.workdir || 'telegram-images';
      const now = new Date();
      const yearMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

      // Normalize and shorten the filename
      let normalizedName = '';
      if (fileName) {
        // Remove extension and special characters, keep only alphanumeric and dash
        normalizedName = fileName
          .replace(/\.[^.]+$/, '') // Remove extension
          .replace(/[^a-zA-Z0-9-]/g, '-') // Replace special chars with dash
          .replace(/-+/g, '-') // Replace multiple dashes with single dash
          .replace(/^-|-$/g, '') // Remove leading/trailing dashes
          .toLowerCase()
          .substring(0, 12); // Max 12 characters
        if (normalizedName) {
          normalizedName = `${normalizedName}-`;
        }
      }

      // Use only first 8 characters of hash for brevity
      const shortHash = md5Hash.substring(0, 8);

      const s3Key = `${workdir}/${yearMonth}/${normalizedName}${shortHash}${extension}`;

      // Prepare metadata
      const metadata = {
        'source-type': options.fileType === 'document' ? 'telegram-document' : 'telegram-image',
        'upload-date': new Date().toISOString(),
        'file-size': buffer.length.toString(),
        'file-name': fileName || '',
        ...options.metadata
      };

      // Upload to S3
      // Try with full metadata first, fallback to minimal metadata if it fails
      let uploadSuccess = false;
      let uploadError = null;
      
      try {
        const command = new PutObjectCommand({
          Bucket: this.bucketName,
          Key: s3Key,
          Body: buffer,
          ContentType: contentType || this.getContentType(extension),
          Metadata: metadata
        });
        await this.s3Client.send(command);
        uploadSuccess = true;
        logger.info(`Upload successful with full metadata: ${s3Key}`);
      } catch (error) {
        uploadError = error;
        logger.warn(`Upload with metadata failed: ${error.message}, trying without metadata...`);
        
        // Try without metadata - just the essential fields
        try {
          const minimalCommand = new PutObjectCommand({
            Bucket: this.bucketName,
            Key: s3Key,
            Body: buffer,
            ContentType: contentType || this.getContentType(extension)
            // No metadata to avoid any character encoding issues
          });
          await this.s3Client.send(minimalCommand);
          uploadSuccess = true;
          logger.info(`Upload successful without metadata: ${s3Key}`);
        } catch (fallbackError) {
          // Both attempts failed, throw the original error
          logger.error(`Upload failed even without metadata: ${fallbackError.message}`);
          throw uploadError;
        }
      }

      // Generate download URL
      const downloadUrl = `https://${this.bucketName}.${this.endpoint}/${s3Key}`;

      // Verify the upload was successful by doing a HEAD request
      // Be lenient - if upload succeeded, assume it worked even if verification fails
      if (uploadSuccess) {
        try {
          logger.info(`Attempting to verify upload at: ${downloadUrl}`);
          
          // Quick verification with short timeout
          const verifyController = new AbortController();
          const verifyTimeout = setTimeout(() => verifyController.abort(), 3000);
          
          const verifyResponse = await fetch(downloadUrl, {
            method: 'HEAD',
            signal: verifyController.signal
          });
          
          clearTimeout(verifyTimeout);
          
          if (verifyResponse.ok) {
            logger.info(`✓ Upload verified successfully: ${s3Key}`);
          } else {
            // Don't fail, just warn
            logger.warn(`Upload verification returned status ${verifyResponse.status}, but file was uploaded`);
          }
        } catch (verifyError) {
          // Verification failed but upload succeeded - that's OK
          logger.debug(`Verification skipped (${verifyError.message}), but upload was successful`);
        }
      }

      return {
        url: downloadUrl,
        s3Key: s3Key,
        md5: md5Hash,
        size: buffer.length
      };
    } catch (error) {
      const errorMessage = error.cause?.message || error.message || 'Unknown error';
      const errorCode = error.cause?.code || error.code || error.name;
      logger.error('Failed to upload image from URL:', {
        error: errorMessage,
        code: errorCode,
        type: error.name,
        url: imageUrl?.replace(/bot\d{9,10}:[A-Za-z0-9_-]{35}/, 'bot***MASKED***'),
        stack: error.stack
      });
      throw error;
    }
  }

  /**
   * Upload a single file to S3
   */
  async uploadFile(filePath, options = {}) {
    await this.initialize();

    // Read file
    const fileContent = await fs.readFile(filePath);
    const fileStats = await fs.stat(filePath);
    
    // Calculate MD5
    const md5Hash = crypto.createHash('md5').update(fileContent).digest('hex');

    // Generate S3 key with improved naming
    const extension = path.extname(filePath);
    const workdir = options.workdir || path.basename(process.cwd());
    const now = new Date();
    const yearMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

    // Normalize and shorten the filename
    const baseName = path.basename(filePath, extension);
    let normalizedName = '';
    if (baseName) {
      // Remove special characters, keep only alphanumeric and dash
      normalizedName = baseName
        .replace(/[^a-zA-Z0-9-]/g, '-') // Replace special chars with dash
        .replace(/-+/g, '-') // Replace multiple dashes with single dash
        .replace(/^-|-$/g, '') // Remove leading/trailing dashes
        .toLowerCase()
        .substring(0, 12); // Max 12 characters
      if (normalizedName) {
        normalizedName = `${normalizedName}-`;
      }
    }

    // Use only first 8 characters of hash for brevity
    const shortHash = md5Hash.substring(0, 8);

    const s3Key = `${workdir}/${yearMonth}/${normalizedName}${shortHash}${extension}`;

    // Prepare metadata
    const metadata = {
      'original-name': path.basename(filePath),
      'upload-date': new Date().toISOString(),
      'workdir': workdir,
      'file-size': fileStats.size.toString(),
      ...options.metadata
    };

    // Upload to S3
    // Try with full metadata first, fallback to minimal metadata if it fails
    let uploadSuccess = false;
    let uploadError = null;
    
    try {
      const command = new PutObjectCommand({
        Bucket: this.bucketName,
        Key: s3Key,
        Body: fileContent,
        ContentType: this.getContentType(extension),
        Metadata: metadata
      });
      await this.s3Client.send(command);
      uploadSuccess = true;
      logger.info(`Upload successful with full metadata: ${s3Key}`);
    } catch (error) {
      uploadError = error;
      logger.warn(`Upload with metadata failed: ${error.message}, trying without metadata...`);
      
      // Try without metadata - just the essential fields
      try {
        const minimalCommand = new PutObjectCommand({
          Bucket: this.bucketName,
          Key: s3Key,
          Body: fileContent,
          ContentType: this.getContentType(extension)
          // No metadata to avoid any character encoding issues
        });
        await this.s3Client.send(minimalCommand);
        uploadSuccess = true;
        logger.info(`Upload successful without metadata: ${s3Key}`);
      } catch (fallbackError) {
        // Both attempts failed, throw the original error
        logger.error(`Upload failed even without metadata: ${fallbackError.message}`);
        throw uploadError;
      }
    }

    // Generate download URL
    const downloadUrl = `https://${this.bucketName}.${this.endpoint}/${s3Key}`;

    return {
      url: downloadUrl,
      s3Key: s3Key,
      md5: md5Hash,
      size: fileStats.size
    };
  }

  /**
   * Get total size of a directory
   */
  async getDirectorySize(dirPath) {
    let totalSize = 0;
    
    async function calculateSize(currentPath) {
      const items = await fs.readdir(currentPath);
      
      for (const item of items) {
        const itemPath = path.join(currentPath, item);
        try {
          const stats = await fs.stat(itemPath);
          
          if (stats.isDirectory()) {
            await calculateSize(itemPath);
          } else {
            totalSize += stats.size;
          }
        } catch (err) {
          // Skip files we can't access
        }
      }
    }
    
    await calculateSize(dirPath);
    return totalSize;
  }

  /**
   * Format file size for display
   */
  formatFileSize(bytes) {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(2)} KB`;
    if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
    return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
  }

  /**
   * Get content type based on file extension
   */
  getContentType(extension) {
    const contentTypes = {
      '.html': 'text/html',
      '.css': 'text/css',
      '.js': 'application/javascript',
      '.json': 'application/json',
      '.png': 'image/png',
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.gif': 'image/gif',
      '.svg': 'image/svg+xml',
      '.pdf': 'application/pdf',
      '.zip': 'application/zip',
      '.tar': 'application/x-tar',
      '.gz': 'application/gzip',
      '.mp4': 'video/mp4',
      '.mp3': 'audio/mpeg',
      '.txt': 'text/plain',
      '.md': 'text/markdown',
      '.markdown': 'text/markdown',
      '.xml': 'application/xml',
      '.csv': 'text/csv',
      '.doc': 'application/msword',
      '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    };
    
    return contentTypes[extension.toLowerCase()] || 'application/octet-stream';
  }
}

// Export singleton instance
export const secureUploader = new SecureUploader();
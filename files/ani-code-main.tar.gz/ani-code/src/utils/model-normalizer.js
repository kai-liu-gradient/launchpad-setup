/**
 * Normalize Claude model names to human-readable format
 *
 * Examples:
 * - claude-sonnet-4-5-20250929 -> sonnet-4.5
 * - claude-opus-4-1-20250805 -> opus-4.1
 * - claude-sonnet-3-5-20240620 -> sonnet-3.5
 * - claude-haiku-3-5-20240307 -> haiku-3.5
 */
export function normalizeModelName(modelName) {
  if (!modelName || typeof modelName !== 'string') {
    return modelName;
  }

  // Pattern: claude-{family}-{major}-{minor?}-{date}
  // Examples:
  // - claude-sonnet-4-5-20250929 (family=sonnet, major=4, minor=5)
  // - claude-opus-4-1-20250805 (family=opus, major=4, minor=1)
  // - claude-sonnet-3-5-20240620 (family=sonnet, major=3, minor=5)
  // - claude-haiku-3-20240307 (family=haiku, major=3, no minor)

  const parts = modelName.split('-');

  // Must start with 'claude'
  if (parts[0] !== 'claude') {
    return modelName;
  }

  // Extract family (sonnet, opus, haiku, etc.)
  const family = parts[1];
  if (!family) {
    return modelName;
  }

  // Extract version numbers
  // Format: claude-{family}-{major}-{minor?}-{date}
  // We need to find where the date starts (8 digit number)
  let major = null;
  let minor = null;

  for (let i = 2; i < parts.length; i++) {
    const part = parts[i];

    // If we hit the date (8 digits), stop
    if (/^\d{8}$/.test(part)) {
      break;
    }

    // If it's a number, it's a version component
    if (/^\d+$/.test(part)) {
      if (major === null) {
        major = part;
      } else if (minor === null) {
        minor = part;
      }
    }
  }

  // Build the normalized name
  if (major === null) {
    // No version found, return as-is
    return modelName;
  }

  // Capitalize first letter of family
  const capitalizedFamily = family.charAt(0).toUpperCase() + family.slice(1);

  if (minor !== null) {
    return `${capitalizedFamily}-${major}.${minor}`;
  } else {
    return `${capitalizedFamily}-${major}`;
  }
}

/**
 * Normalize model name to lowercase format (for display in compact spaces)
 */
export function normalizeModelNameLowercase(modelName) {
  const normalized = normalizeModelName(modelName);
  // If it looks like it was normalized (has a hyphen and starts with capital)
  if (/^[A-Z]/.test(normalized)) {
    return normalized.toLowerCase();
  }
  return normalized;
}
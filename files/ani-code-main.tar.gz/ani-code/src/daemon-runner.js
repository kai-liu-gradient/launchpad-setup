#!/usr/bin/env node

import { AniCodeDaemon } from './daemon.js';
import { logger } from './logger.js';
import { config } from './config.js';
import v8 from 'v8';
import fs from 'fs';
import path from 'path';

// Log memory usage periodically (every 5 minutes)
const MEMORY_LOG_INTERVAL_MS = 5 * 60 * 1000;
let memoryLogInterval = null;

function logMemoryUsage() {
  const mem = process.memoryUsage();
  logger.info('Memory usage:', {
    rss: `${(mem.rss / 1024 / 1024).toFixed(1)}MB`,
    heapTotal: `${(mem.heapTotal / 1024 / 1024).toFixed(1)}MB`,
    heapUsed: `${(mem.heapUsed / 1024 / 1024).toFixed(1)}MB`,
    external: `${(mem.external / 1024 / 1024).toFixed(1)}MB`,
    uptime: `${(process.uptime() / 3600).toFixed(1)}h`
  });
}

// Write heap snapshot on SIGUSR2
process.on('SIGUSR2', () => {
  const snapshotDir = path.join(process.cwd(), '.ani-code', 'heapdumps');
  if (!fs.existsSync(snapshotDir)) {
    fs.mkdirSync(snapshotDir, { recursive: true });
  }
  const filename = path.join(snapshotDir, `heap-${Date.now()}.heapsnapshot`);
  logger.info(`Writing heap snapshot to ${filename}...`);
  v8.writeHeapSnapshot(filename);
  logger.info(`Heap snapshot written: ${filename}`);
});

async function main() {
  try {
    const daemon = new AniCodeDaemon();
    
    // Start the daemon
    const success = daemon.start();
    
    if (!success) {
      logger.error('Failed to start daemon');
      process.exit(1);
    }

    // Start periodic memory logging
    memoryLogInterval = setInterval(logMemoryUsage, MEMORY_LOG_INTERVAL_MS);
    logMemoryUsage(); // Log initial memory usage

    // Keep the process running
    process.stdin.resume();

  } catch (error) {
    logger.error('Failed to start daemon:', error);
    process.exit(1);
  }
}

// Handle process termination
process.on('SIGTERM', () => {
  logger.info('Received SIGTERM, shutting down...');
  process.exit(0);
});

process.on('SIGINT', () => {
  logger.info('Received SIGINT, shutting down...');
  process.exit(0);
});

// Start the daemon
main().catch(error => {
  logger.error('Unhandled error in daemon:', error);
  process.exit(1);
});

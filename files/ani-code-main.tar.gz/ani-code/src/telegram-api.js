import axios from 'axios';
import dns from 'dns';
import http from 'http';
import https from 'https';
import { logger } from './logger.js';
import { config } from './config.js';
import { SecureUploader } from './utils/secure-upload.js';

// Force IPv4 for DNS lookups
dns.setDefaultResultOrder('ipv4first');

export class TelegramAPI {
  constructor(botToken = null) {
    this.botToken = botToken || config.telegram?.botToken;
    if (!this.botToken) {
      throw new Error('Telegram bot token not configured');
    }
    this.baseURL = `https://api.telegram.org/bot${this.botToken}`;
    
    // Create custom agents that force IPv4
    const httpAgent = new http.Agent({
      family: 4, // Force IPv4
      keepAlive: true,
      keepAliveMsecs: 1000,
      maxSockets: 50
    });
    
    const httpsAgent = new https.Agent({
      family: 4, // Force IPv4
      keepAlive: true,
      keepAliveMsecs: 1000,
      maxSockets: 50,
      rejectUnauthorized: true
    });
    
    // Create axios instance with default config and IPv4 agents
    this.client = axios.create({
      baseURL: this.baseURL,
      timeout: 10000, // 10 seconds default timeout
      headers: {
        'Content-Type': 'application/json'
      },
      httpAgent: httpAgent,
      httpsAgent: httpsAgent
    });
    
    // Add request interceptor for logging
    this.client.interceptors.request.use(
      (config) => {
        // Start timing
        config.metadata = { startTime: Date.now() };
        
        // Mask sensitive data in URL and payload
        const maskedUrl = config.url ? config.url.replace(/bot\d{9,10}:[A-Za-z0-9_-]{35}/, 'bot***MASKED***') : '';
        const maskedData = config.data ? SecureUploader.maskCredentials(JSON.stringify(config.data)) : null;
        
        logger.debug('[TELEGRAM API] Request:', {
          method: config.method?.toUpperCase(),
          endpoint: maskedUrl,
          timeout: config.timeout,
          hasData: !!config.data,
          dataSize: maskedData ? maskedData.length : 0,
          headers: config.headers
        });
        
        // Log full payload in verbose mode (masked)
        if (config.data) {
          logger.debug('[TELEGRAM API] Request payload:', maskedData);
        }
        
        return config;
      },
      (error) => {
        logger.error('[TELEGRAM API] Request interceptor error:', error.message);
        return Promise.reject(error);
      }
    );
    
    // Add response interceptor for logging
    this.client.interceptors.response.use(
      (response) => {
        const duration = Date.now() - response.config.metadata.startTime;
        
        logger.debug('[TELEGRAM API] Response:', {
          endpoint: response.config.url?.replace(/bot\d{9,10}:[A-Za-z0-9_-]{35}/, 'bot***MASKED***'),
          status: response.status,
          duration: `${duration}ms`,
          ok: response.data?.ok,
          hasResult: !!response.data?.result
        });
        
        // Log response details in verbose mode
        if (response.data && !response.data.ok) {
          logger.warn('[TELEGRAM API] Response not OK:', {
            error_code: response.data.error_code,
            description: response.data.description
          });
        }
        
        return response;
      },
      (error) => {
        const duration = error.config?.metadata ? Date.now() - error.config.metadata.startTime : 0;
        
        if (error.response) {
          // The request was made and the server responded with a status code
          logger.error('[TELEGRAM API] Response error:', {
            endpoint: error.config?.url?.replace(/bot\d{9,10}:[A-Za-z0-9_-]{35}/, 'bot***MASKED***'),
            status: error.response.status,
            statusText: error.response.statusText,
            duration: `${duration}ms`,
            error_code: error.response.data?.error_code,
            description: error.response.data?.description,
            retry_after: error.response.data?.parameters?.retry_after
          });
        } else if (error.request) {
          logger.error('error object', {message: error.message, code: error.code});
          // The request was made but no response was received
          logger.error('[TELEGRAM API] No response received:', {
            endpoint: error.config?.url?.replace(/bot\d{9,10}:[A-Za-z0-9_-]{35}/, 'bot***MASKED***'),
            duration: `${duration}ms`,
            code: error.code,
            message: error.message
          });
        } else {
          // Something happened in setting up the request
          logger.error('[TELEGRAM API] Request setup error:', {
            message: error.message,
            duration: `${duration}ms`
          });
        }
        
        return Promise.reject(error);
      }
    );
  }
  
  // Helper method for exponential backoff
  async withRetry(fn, options = {}) {
    const {
      maxRetries = 3,
      baseDelay = 1000,
      maxDelay = 30000,
      onRetry = null
    } = options;
    
    let lastError;
    
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        return await fn();
      } catch (error) {
        lastError = error;
        
        // Check if this is a rate limit error
        if (error.response?.status === 429) {
          const retryAfter = error.response.data?.parameters?.retry_after || 1;
          const waitTime = Math.min(retryAfter * 1000, maxDelay);
          
          if (attempt < maxRetries) {
            logger.warn(`[TELEGRAM API] Rate limited, waiting ${retryAfter}s before retry (attempt ${attempt + 1}/${maxRetries})`);
            if (onRetry) onRetry(attempt, waitTime, error);
            await this.delay(waitTime);
            continue;
          }
        }
        
        // Check if this is a server error (5xx)
        if (error.response?.status >= 500 && error.response?.status < 600) {
          if (attempt < maxRetries) {
            const waitTime = Math.min(baseDelay * Math.pow(2, attempt), maxDelay);
            const jitter = Math.floor(Math.random() * 500); // 0-500ms jitter
            const totalWait = waitTime + jitter;
            
            logger.warn(`[TELEGRAM API] Server error ${error.response.status}, retrying in ${totalWait}ms (attempt ${attempt + 1}/${maxRetries})`);
            if (onRetry) onRetry(attempt, totalWait, error);
            await this.delay(totalWait);
            continue;
          }
        }
        
        // Check for network errors (including timeout errors)
        if (!error.response && error.code && ['ECONNRESET', 'ETIMEDOUT', 'ENOTFOUND', 'ECONNREFUSED', 'ECONNABORTED'].includes(error.code)) {
          if (attempt < maxRetries) {
            const waitTime = Math.min(baseDelay * Math.pow(2, attempt), maxDelay);
            const jitter = Math.floor(Math.random() * 500);
            const totalWait = waitTime + jitter;
            
            logger.warn(`[TELEGRAM API] Network error ${error.code}, retrying in ${totalWait}ms (attempt ${attempt + 1}/${maxRetries})`);
            if (onRetry) onRetry(attempt, totalWait, error);
            await this.delay(totalWait);
            continue;
          }
        }
        
        // Non-retryable error or max retries reached
        throw error;
      }
    }
    
    throw lastError;
  }
  
  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  
  // Core API methods
  async sendMessage(chatId, text, options = {}) {
    const startTime = Date.now();
    const { maxRetries = 3, workspaceName, ...telegramOptions } = options;

    // Strip null/undefined reply_markup - Telegram API rejects null values
    if (telegramOptions.reply_markup == null) {
      delete telegramOptions.reply_markup;
    }

    // Don't mask the actual message sent to Telegram - only mask for logging
    const maskedTextForLogging = SecureUploader.maskCredentials(text);
    logger.debug(`[TELEGRAM API] Message content (masked): ${maskedTextForLogging.substring(0, 200)}...`);

    try {
      const response = await this.withRetry(
        () => this.client.post('/sendMessage', {
          chat_id: chatId,
          text: text,  // Send original text, not masked
          ...telegramOptions
        }),
        { maxRetries }
      );

      const duration = Date.now() - startTime;
      const messageId = response.data.result?.message_id;
      const workspaceInfo = workspaceName ? `, workspace: ${workspaceName}` : '';
      logger.info(`[TELEGRAM API] ✓ Message sent to chat ${chatId} in ${duration}ms (id: ${messageId}, len: ${text.length}${workspaceInfo})`);

      return response.data;
    } catch (error) {
      const duration = Date.now() - startTime;
      logger.error(`[TELEGRAM API] ✗ Failed to send to chat ${chatId} after ${duration}ms: ${error.message}`);
      throw error;
    }
  }
  
  async editMessageText(chatId, messageId, text, options = {}) {
    const startTime = Date.now();
    const { maxRetries = 2, workspaceName, ...telegramOptions } = options;

    // Strip null/undefined reply_markup - Telegram API rejects null values
    if (telegramOptions.reply_markup == null) {
      delete telegramOptions.reply_markup;
    }

    // Don't mask the actual message sent to Telegram - only mask for logging
    const maskedTextForLogging = SecureUploader.maskCredentials(text);
    logger.debug(`[TELEGRAM API] Edit message content (masked): ${maskedTextForLogging.substring(0, 200)}...`);

    try {
      const response = await this.withRetry(
        () => this.client.post('/editMessageText', {
          chat_id: chatId,
          message_id: messageId,
          text: text,  // Send original text, not masked
          ...telegramOptions
        }, {
          timeout: 20000  // 20 seconds timeout for edit operations (they may contain large messages)
        }),
        { maxRetries }
      );

      const duration = Date.now() - startTime;
      const workspaceInfo = workspaceName ? `, workspace: ${workspaceName}` : '';
      logger.info(`[TELEGRAM API] ✓ Message ${messageId} edited in chat ${chatId} (${duration}ms${workspaceInfo})`);

      return response.data;
    } catch (error) {
      const duration = Date.now() - startTime;

      // Handle specific Telegram errors
      if (error.response?.data?.description?.includes('message is not modified')) {
        logger.debug(`[TELEGRAM API] Message content unchanged, skipping edit (${duration}ms)`);
        return { ok: true, result: null };
      }

      logger.error(`[TELEGRAM API] ✗ Failed to edit message ${messageId} in chat ${chatId} after ${duration}ms: ${error.message}`);
      throw error;
    }
  }
  
  async deleteMessage(chatId, messageId) {
    const startTime = Date.now();

    try {
      const response = await this.withRetry(
        () => this.client.post('/deleteMessage', {
          chat_id: chatId,
          message_id: messageId
        }),
        { maxRetries: 2 }
      );

      const duration = Date.now() - startTime;
      logger.info(`[TELEGRAM API] ✓ Message ${messageId} deleted from chat ${chatId} (${duration}ms)`);

      return response.data;
    } catch (error) {
      const duration = Date.now() - startTime;
      logger.error(`[TELEGRAM API] ✗ Failed to delete message ${messageId} from chat ${chatId} after ${duration}ms: ${error.message}`);
      throw error;
    }
  }

  async answerCallbackQuery(callbackQueryId, options = {}) {
    const startTime = Date.now();

    try {
      const response = await this.client.post('/answerCallbackQuery', {
        callback_query_id: callbackQueryId,
        ...options
      });

      const duration = Date.now() - startTime;
      logger.debug(`[TELEGRAM API] ✓ Callback ${callbackQueryId} answered (${duration}ms)`);

      return response.data;
    } catch (error) {
      const duration = Date.now() - startTime;
      logger.error(`[TELEGRAM API] ✗ Failed to answer callback ${callbackQueryId} after ${duration}ms: ${error.message}`);
      throw error;
    }
  }
  
  
  async sendPhoto(chatId, photo, options = {}) {
    const startTime = Date.now();
    const { maxRetries = 3, ...telegramOptions } = options;

    logger.info(`[TELEGRAM API] Sending photo to chat ${chatId}`);

    try {
      // Import FormData for Node.js
      const FormData = (await import('form-data')).default;
      const formData = new FormData();

      formData.append('chat_id', chatId);

      // Handle different types of photo input (stream, URL, file_id)
      if (typeof photo === 'string') {
        // It's either a URL or file_id
        formData.append('photo', photo);
      } else {
        // It's a stream or buffer
        formData.append('photo', photo, {
          filename: 'photo.jpg' // Provide a filename for streams
        });
      }

      // Add other options to form data
      Object.entries(telegramOptions).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          formData.append(key, typeof value === 'object' ? JSON.stringify(value) : value);
        }
      });

      const response = await this.withRetry(
        () => this.client.post('/sendPhoto', formData, {
          headers: formData.getHeaders(),
          timeout: 60000 // 60 seconds for file uploads
        }),
        { maxRetries }
      );

      const duration = Date.now() - startTime;
      logger.info(`[TELEGRAM API] Photo sent successfully in ${duration}ms, message_id: ${response.data.result?.message_id}`);

      return response.data;
    } catch (error) {
      const duration = Date.now() - startTime;
      logger.error(`[TELEGRAM API] Failed to send photo after ${duration}ms:`, error.message);
      throw error;
    }
  }

  async sendVideo(chatId, video, options = {}) {
    const startTime = Date.now();
    const { maxRetries = 3, ...telegramOptions } = options;

    logger.info(`[TELEGRAM API] Sending video to chat ${chatId}`);

    try {
      // Import FormData for Node.js
      const FormData = (await import('form-data')).default;
      const formData = new FormData();

      formData.append('chat_id', chatId);

      // Handle different types of video input (stream, URL, file_id)
      if (typeof video === 'string') {
        // It's either a URL or file_id
        formData.append('video', video);
      } else {
        // It's a stream or buffer
        formData.append('video', video, {
          filename: 'video.mp4' // Provide a filename for streams
        });
      }

      // Add other options to form data
      Object.entries(telegramOptions).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          formData.append(key, typeof value === 'object' ? JSON.stringify(value) : value);
        }
      });

      const response = await this.withRetry(
        () => this.client.post('/sendVideo', formData, {
          headers: formData.getHeaders(),
          timeout: 120000 // 120 seconds for video uploads (longer timeout)
        }),
        { maxRetries }
      );

      const duration = Date.now() - startTime;
      logger.info(`[TELEGRAM API] Video sent successfully in ${duration}ms, message_id: ${response.data.result?.message_id}`);

      return response.data;
    } catch (error) {
      const duration = Date.now() - startTime;
      logger.error(`[TELEGRAM API] Failed to send video after ${duration}ms:`, error.message);
      throw error;
    }
  }

  async sendDocument(chatId, document, options = {}) {
    const startTime = Date.now();
    const { maxRetries = 3, ...telegramOptions } = options;

    logger.info(`[TELEGRAM API] Sending document to chat ${chatId}`);

    try {
      // Import FormData for Node.js
      const FormData = (await import('form-data')).default;
      const formData = new FormData();

      formData.append('chat_id', chatId);

      // Handle different types of document input (stream, URL, file_id)
      if (typeof document === 'string') {
        // It's either a URL or file_id
        formData.append('document', document);
      } else {
        // It's a stream or buffer
        // Extract filename if available
        const filename = options.filename || 'document';
        formData.append('document', document, {
          filename: filename
        });
      }

      // Add other options to form data
      Object.entries(telegramOptions).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          formData.append(key, typeof value === 'object' ? JSON.stringify(value) : value);
        }
      });

      const response = await this.withRetry(
        () => this.client.post('/sendDocument', formData, {
          headers: formData.getHeaders(),
          timeout: 60000 // 60 seconds for file uploads
        }),
        { maxRetries }
      );

      const duration = Date.now() - startTime;
      logger.info(`[TELEGRAM API] Document sent successfully in ${duration}ms, message_id: ${response.data.result?.message_id}`);

      return response.data;
    } catch (error) {
      const duration = Date.now() - startTime;
      logger.error(`[TELEGRAM API] Failed to send document after ${duration}ms:`, error.message);
      throw error;
    }
  }
  
  async getFile(fileId) {
    const startTime = Date.now();
    
    logger.info(`[TELEGRAM API] Getting file info for ${fileId}`);
    
    try {
      const response = await this.withRetry(
        () => this.client.get('/getFile', {
          params: { file_id: fileId }
        }),
        { maxRetries: 3 }
      );
      
      const duration = Date.now() - startTime;
      logger.info(`[TELEGRAM API] File info retrieved in ${duration}ms, file_path: ${response.data.result?.file_path}`);
      
      return response.data;
    } catch (error) {
      const duration = Date.now() - startTime;
      logger.error(`[TELEGRAM API] Failed to get file info after ${duration}ms:`, error.message);
      throw error;
    }
  }
  
  async pinChatMessage(chatId, messageId, options = {}) {
    const startTime = Date.now();
    const { maxRetries = 3, disable_notification = true } = options;

    logger.info(`[TELEGRAM API] Pinning message ${messageId} in chat ${chatId}`);

    try {
      const response = await this.withRetry(
        () => this.client.post('/pinChatMessage', {
          chat_id: chatId,
          message_id: messageId,
          disable_notification
        }),
        { maxRetries }
      );

      const duration = Date.now() - startTime;
      logger.info(`[TELEGRAM API] Message pinned successfully in ${duration}ms`);

      return response.data;
    } catch (error) {
      const duration = Date.now() - startTime;
      logger.error(`[TELEGRAM API] Failed to pin message after ${duration}ms:`, error.message);
      throw error;
    }
  }

  async unpinChatMessage(chatId, messageId = null, options = {}) {
    const startTime = Date.now();
    const { maxRetries = 3 } = options;

    logger.info(`[TELEGRAM API] Unpinning message ${messageId || 'latest'} in chat ${chatId}`);

    try {
      const payload = { chat_id: chatId };
      if (messageId) {
        payload.message_id = messageId;
      }

      const response = await this.withRetry(
        () => this.client.post('/unpinChatMessage', payload),
        { maxRetries }
      );

      const duration = Date.now() - startTime;
      logger.info(`[TELEGRAM API] Message unpinned successfully in ${duration}ms`);

      return response.data;
    } catch (error) {
      const duration = Date.now() - startTime;
      logger.error(`[TELEGRAM API] Failed to unpin message after ${duration}ms:`, error.message);
      throw error;
    }
  }

  async unpinAllChatMessages(chatId, options = {}) {
    const startTime = Date.now();
    const { maxRetries = 3 } = options;

    logger.info(`[TELEGRAM API] Unpinning all messages in chat ${chatId}`);

    try {
      const payload = { chat_id: chatId };

      const response = await this.withRetry(
        () => this.client.post('/unpinAllChatMessages', payload),
        { maxRetries }
      );

      const duration = Date.now() - startTime;
      logger.info(`[TELEGRAM API] All messages unpinned successfully in ${duration}ms`);

      return response.data;
    } catch (error) {
      const duration = Date.now() - startTime;
      logger.error(`[TELEGRAM API] Failed to unpin all messages after ${duration}ms:`, error.message);
      throw error;
    }
  }

  async downloadFile(filePath) {
    const startTime = Date.now();
    const fileUrl = `https://api.telegram.org/file/bot${this.botToken}/${filePath}`;

    logger.info(`[TELEGRAM API] Downloading file from path: ${filePath}`);

    // Create IPv4-only agent for file downloads
    const httpsAgent = new https.Agent({
      family: 4, // Force IPv4
      keepAlive: true,
      keepAliveMsecs: 1000,
      maxSockets: 50,
      rejectUnauthorized: true
    });

    try {
      const response = await axios.get(fileUrl, {
        responseType: 'arraybuffer',
        timeout: 60000, // 60 seconds for file downloads
        httpsAgent: httpsAgent
      });
      
      const duration = Date.now() - startTime;
      const sizeKB = (response.data.length / 1024).toFixed(2);
      logger.info(`[TELEGRAM API] File downloaded successfully in ${duration}ms, size: ${sizeKB}KB`);
      
      return response.data;
    } catch (error) {
      const duration = Date.now() - startTime;
      logger.error(`[TELEGRAM API] Failed to download file after ${duration}ms:`, error.message);
      throw error;
    }
  }
  
  async getUpdates(options = {}) {
    const startTime = Date.now();
    
    logger.debug(`[TELEGRAM API] Getting updates with offset: ${options.offset || 0}`);
    
    try {
      const response = await this.client.post('/getUpdates', options);
      
      const duration = Date.now() - startTime;
      const updateCount = response.data.result?.length || 0;
      logger.debug(`[TELEGRAM API] Received ${updateCount} updates in ${duration}ms`);
      
      return response.data;
    } catch (error) {
      const duration = Date.now() - startTime;
      logger.error(`[TELEGRAM API] Failed to get updates after ${duration}ms:`, error.message);
      throw error;
    }
  }
  
  async setWebhook(url, options = {}) {
    const startTime = Date.now();
    
    logger.info(`[TELEGRAM API] Setting webhook to: ${url}`);
    
    try {
      const response = await this.client.post('/setWebhook', {
        url,
        ...options
      });
      
      const duration = Date.now() - startTime;
      logger.info(`[TELEGRAM API] Webhook set successfully in ${duration}ms`);
      
      return response.data;
    } catch (error) {
      const duration = Date.now() - startTime;
      logger.error(`[TELEGRAM API] Failed to set webhook after ${duration}ms:`, error.message);
      throw error;
    }
  }
  
  async deleteWebhook(options = {}) {
    const startTime = Date.now();
    
    logger.info(`[TELEGRAM API] Deleting webhook`);
    
    try {
      const response = await this.client.post('/deleteWebhook', options);
      
      const duration = Date.now() - startTime;
      logger.info(`[TELEGRAM API] Webhook deleted successfully in ${duration}ms`);
      
      return response.data;
    } catch (error) {
      const duration = Date.now() - startTime;
      logger.error(`[TELEGRAM API] Failed to delete webhook after ${duration}ms:`, error.message);
      throw error;
    }
  }
  
  async getWebhookInfo() {
    const startTime = Date.now();
    
    logger.info(`[TELEGRAM API] Getting webhook info`);
    
    try {
      const response = await this.client.get('/getWebhookInfo');
      
      const duration = Date.now() - startTime;
      const info = response.data.result;
      logger.info(`[TELEGRAM API] Webhook info retrieved in ${duration}ms`, {
        url: info?.url,
        has_custom_certificate: info?.has_custom_certificate,
        pending_update_count: info?.pending_update_count,
        last_error_date: info?.last_error_date,
        last_error_message: info?.last_error_message
      });
      
      return response.data;
    } catch (error) {
      const duration = Date.now() - startTime;
      logger.error(`[TELEGRAM API] Failed to get webhook info after ${duration}ms:`, error.message);
      throw error;
    }
  }
  
  async getMe() {
    const startTime = Date.now();
    
    logger.info(`[TELEGRAM API] Getting bot info`);
    
    try {
      const response = await this.client.get('/getMe');
      
      const duration = Date.now() - startTime;
      const bot = response.data.result;
      logger.info(`[TELEGRAM API] Bot info retrieved in ${duration}ms`, {
        id: bot?.id,
        username: bot?.username,
        first_name: bot?.first_name,
        can_join_groups: bot?.can_join_groups,
        can_read_all_group_messages: bot?.can_read_all_group_messages
      });
      
      return response.data;
    } catch (error) {
      const duration = Date.now() - startTime;
      logger.error(`[TELEGRAM API] Failed to get bot info after ${duration}ms:`, error.message);
      throw error;
    }
  }
}
import { logger } from './logger.js';
import { basename } from 'path';
import { config } from './config.js';
import { TelegramNotifierBase } from './telegram-notifier-base.js';

/**
 * DummyTelegramNotifier - A mock Telegram notifier for gateway-only operation
 * This allows ani-code to run without actual Telegram/Lark configuration,
 * enabling remote control via ani-code-gateway.
 *
 * Extends TelegramNotifierBase to inherit all formatting methods.
 */
export class DummyTelegramNotifier extends TelegramNotifierBase {
  constructor() {
    super(); // Call parent constructor to initialize base properties
    this.isDummy = true;
    this.botToken = 'DUMMY';
    this.defaultChatId = 'dummy-chat-id';

    // Create API object with methods that match TelegramAPI interface
    this.api = {
      sendMessage: this.sendMessage.bind(this),
      editMessageText: this.editMessage.bind(this),
      deleteMessage: this.deleteMessage.bind(this),
      pinChatMessage: this.pinChatMessage.bind(this),
      unpinChatMessage: this.unpinChatMessage.bind(this)
    };

    logger.info('[DUMMY-TELEGRAM] Initialized dummy Telegram notifier for gateway-only operation');
  }

  isEnabled() {
    return true; // Always enabled in dummy mode
  }

  // Override parent's escapeMarkdownContent to match TelegramNotifier behavior
  escapeMarkdownContent(text) {
    // More aggressive escaping for content that shouldn't have any formatting
    // This is for user-provided content like commands and prompts
    if (!text) return '';

    // Convert text to string if it's not already (handle objects/arrays)
    const str = typeof text === 'string' ? text : String(text);

    return str
      .replace(/\\/g, '\\\\')  // Escape backslashes first
      .replace(/\*/g, '\\*')    // Escape asterisks
      .replace(/_/g, '\\_')     // Escape underscores
      .replace(/\[/g, '\\[')    // Escape opening brackets
      .replace(/\]/g, '\\]')    // Escape closing brackets
      .replace(/`/g, '\\`')     // Escape backticks
      .replace(/\(/g, '\\(')    // Escape opening parentheses
      .replace(/\)/g, '\\)');   // Escape closing parentheses
  }

  formatMarkdown(text) {
    // Convert basic markdown to Telegram's MarkdownV2 format
    // Bold: **text** -> *text*
    text = text.replace(/\*\*(.+?)\*\*/g, '*$1*');

    // Code blocks: ```code``` -> `code`
    text = text.replace(/```([^`]+)```/g, '`$1`');

    // Inline code: `code` stays the same

    return text;
  }

  sanitizeMessageForTelegram(message) {
    // Additional sanitization for complex messages that may contain JSON or code
    // This is used specifically for task completion messages that may have problematic content

    if (!message) return '';

    // Convert to string if not already
    let text = typeof message === 'string' ? message : String(message);

    // First, ensure no nested code blocks by replacing triple backticks in code blocks
    text = text.replace(/```[\s\S]*?```/g, (match) => {
      // Remove any triple backticks inside code blocks
      const content = match.slice(3, -3); // Remove opening and closing ```
      const cleanedContent = content.replace(/```/g, '   ');
      return '```' + cleanedContent + '```';
    });

    // Remove any remaining unescaped backticks outside of code blocks
    // But preserve inline code (paired backticks like `code`)
    let inCodeBlock = false;
    const lines = text.split('\n');
    const sanitizedLines = lines.map(line => {
      if (line.startsWith('```')) {
        inCodeBlock = !inCodeBlock;
        return line;
      }

      if (!inCodeBlock) {
        // Remove control characters that might break Telegram
        let sanitizedLine = line.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, '');

        // Don't escape backticks - they're used for inline code formatting
        // Telegram's Markdown parser handles inline code with single backticks
        // Only escape truly problematic unpaired backticks
        const backtickCount = (sanitizedLine.match(/(?<!\\)`/g) || []).length;
        if (backtickCount % 2 !== 0) {
          // Odd number of backticks - there's an unpaired one, escape them all
          sanitizedLine = sanitizedLine.replace(/(?<!\\)`/g, '\\`');
        }
        // If even number, leave them as-is for inline code formatting

        return sanitizedLine;
      }

      return line;
    });

    // Join and ensure message length is within Telegram limits
    let result = sanitizedLines.join('\n');

    // Final safety check: ensure we don't have unmatched code blocks
    const codeBlockCount = (result.match(/```/g) || []).length;
    if (codeBlockCount % 2 !== 0) {
      // Unmatched code block - add closing
      result += '\n```';
      logger.warn('[DUMMY-TELEGRAM] Fixed unmatched code block in message');
    }

    return result;
  }


  async sendTaskUpdate(task, status, chatId = null, displayMode = 'full') {
    const targetChatId = chatId || task.chatId || this.defaultChatId;

    logger.info(`[DUMMY-TELEGRAM] sendTaskUpdate called`, {
      taskId: task.id,
      taskName: task.name,
      status,
      chatId: targetChatId,
      gatewayEnabled: config.gateway.enabled,
      displayMode
    });

    // Use simple or full formatting based on display mode
    const message = displayMode === 'simple'
      ? this.formatSimpleTaskUpdateMessage(task, status)
      : await this.formatTaskUpdateMessage(task, status);

    // Get keyboard if applicable (skip in simple mode)
    const keyboard = displayMode === 'simple' ? null : this.getTaskUpdateKeyboard(task, status);
    const options = { parse_mode: 'Markdown' };
    if (keyboard) {
      options.reply_markup = keyboard;
    }

    // In gateway mode, send actual notification via gateway callback
    if (config.gateway.enabled) {
      logger.info(`[DUMMY-TELEGRAM] Routing task update through gateway for chat ${targetChatId}`);
      return this.sendMessage(targetChatId, message, options);
    }

    // Non-gateway mode: return dummy response
    return {
      ok: true,
      result: {
        message_id: Math.floor(Math.random() * 1000000),
        chat: { id: targetChatId },
        date: Date.now() / 1000,
        text: message
      }
    };
  }

  async sendTaskSummary(task, result, taskUsage = null, usageReporter = null, chatId = null, messageId = null, pendingCount = 0, displayMode = 'full') {
    const targetChatId = chatId || task.chatId || this.defaultChatId;

    logger.info(`[DUMMY-TELEGRAM] Task ${result}`, {
      taskId: task.id,
      taskName: task.name,
      exitCode: task.exitCode,
      chatId: targetChatId,
      messageId: messageId || 'NOT_PROVIDED',
      pendingCount
    });

    // Log task output if available (useful for gateway operations)
    if (task.output && task.output.trim()) {
      const lines = task.output.trim().split('\n');
      logger.debug(`[DUMMY-TELEGRAM] Task output (${lines.length} lines):`, {
        preview: lines.slice(0, 5).join('\n')
      });
    }

    // Log cost/usage if available
    if (taskUsage && taskUsage.cost > 0) {
      logger.info(`[DUMMY-TELEGRAM] Task usage:`, {
        cost: `$${taskUsage.cost.toFixed(4)}`,
        tokens: taskUsage.tokens,
        models: taskUsage.modelsUsed
      });
    }

    // CRITICAL: Check if this task was tracked via progress and should have a messageId
    // If progress tracking was active but messageId is missing, that's a bug we need to catch
    const httpServer = global.httpServer;
    let wasTrackedViaProgress = false;

    if (httpServer && httpServer.progressTrackers && task.chatId) {
      let trackerChatId = task.chatId;
      if (task.chatId.startsWith('telegram:')) {
        trackerChatId = task.chatId.replace('telegram:', '');
      }
      const trackerKey = `${trackerChatId}:${task.id}`;
      wasTrackedViaProgress = httpServer.progressTrackers.has(trackerKey);
    }

    // If task was tracked via progress but messageId is missing, log critical error
    if (wasTrackedViaProgress && !messageId) {
      logger.error(`[DUMMY-TELEGRAM] ❌ CRITICAL: Task ${task.id} was tracked via progress but messageId is MISSING!`, {
        taskId: task.id,
        chatId: targetChatId,
        wasTrackedViaProgress: true,
        messageIdProvided: false,
        impact: 'Running status message will NOT be updated - duplicate message will appear',
        troubleshooting: 'Check task-monitor.js handleTaskCompleted() - messageId may not be passed correctly'
      });
    } else if (!messageId) {
      logger.debug(`[DUMMY-TELEGRAM] No messageId provided for task ${task.id} - will send new message (expected if no progress tracking)`);
    }

    // Use simple or full formatting based on display mode
    const message = displayMode === 'simple'
      ? await this.formatSimpleTaskSummaryMessage(task, result, taskUsage, usageReporter, pendingCount)
      : await this.formatTaskSummaryMessage(task, result, taskUsage, usageReporter, pendingCount);

    // Get keyboard if applicable
    const keyboard = await this.getTaskSummaryKeyboard(task, result);
    const options = { parse_mode: 'Markdown' };
    if (keyboard) {
      options.reply_markup = keyboard;
    }

    // If messageId is provided, try to update the existing message
    if (messageId) {
      try {
        logger.info(`[DUMMY-TELEGRAM] ✓ Attempting to update existing message ${messageId} with task summary for task ${task.id}`);
        const editResult = await this.editMessage(targetChatId, messageId, message, options);

        if (editResult.ok) {
          logger.info(`[DUMMY-TELEGRAM] ✓ Successfully updated message ${messageId} - running status message replaced with completion`);
          return editResult;
        } else {
          logger.error(`[DUMMY-TELEGRAM] ❌ Failed to update message ${messageId}: ${editResult.error}`, {
            taskId: task.id,
            messageId,
            chatId: targetChatId,
            error: editResult.error,
            fallback: 'Sending new message instead'
          });
        }
      } catch (error) {
        logger.error(`[DUMMY-TELEGRAM] ❌ Error updating message ${messageId}: ${error.message}`, {
          taskId: task.id,
          messageId,
          chatId: targetChatId,
          error: error.message,
          stack: error.stack,
          fallback: 'Sending new message instead'
        });
      }
    }

    // Send as new message if no messageId or update failed
    logger.warn(`[DUMMY-TELEGRAM] Sending NEW message for task ${task.id} (messageId: ${messageId || 'none'}) - running message will not be updated`);

    // In gateway mode, send actual notification via gateway callback
    if (config.gateway.enabled) {
      logger.info(`[DUMMY-TELEGRAM] Routing task summary through gateway for chat ${targetChatId}`);
      return this.sendMessage(targetChatId, message, options);
    }

    // Non-gateway mode: return dummy response
    // Note: We return a dummy response here, but this should rarely happen in production
    logger.warn(`[DUMMY-TELEGRAM] Gateway not enabled - returning dummy response (not sent to user)`);
    return {
      ok: true,
      result: {
        message_id: Date.now(), // Use timestamp instead of random to make debugging easier
        chat: { id: targetChatId },
        date: Date.now() / 1000,
        text: message
      }
    };
  }

  async sendViaGateway(platform, chatId, text, options = {}) {
    const payload = {
      platform,
      chatId,
      message: {
        text,
        ...options
      },
      instanceId: config.gateway.instanceId,
      timestamp: new Date().toISOString()
    };

    logger.debug(`[Gateway] Sending message to ${chatId} (${text?.length || 0} chars)`);

    try {
      const fetch = (await import('node-fetch')).default;
      const response = await fetch(`${config.gateway.url}/api/callback/message`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-instance-id': config.gateway.instanceId,
          'x-gateway-token': config.gateway.token
        },
        body: JSON.stringify(payload),
        timeout: 10000 // 10 second timeout
      });

      if (!response.ok) {
        const errorText = await response.text();
        logger.error(`[Gateway] Callback failed with HTTP ${response.status}`, {
          status: response.status,
          statusText: response.statusText,
          errorText: errorText.substring(0, 500),
          chatId,
          platform
        });
        throw new Error(`Gateway callback failed: ${response.status} - ${errorText}`);
      }

      const result = await response.json();

      logger.info(`[Gateway] ✓ Sent to ${chatId}`);

      // Normalize gateway response to Telegram API format: { ok, result: { message_id } }
      // Gateway returns { success, platform_response: { ok, result: { message_id } }, message_id }
      // Callers expect Telegram API format where message_id is at result.result.message_id
      if (result.platform_response) {
        return result.platform_response;
      }
      return {
        ok: !!result.success,
        result: result.message_id ? { message_id: result.message_id } : undefined
      };
    } catch (error) {
      logger.error(`[Gateway] ✗ Gateway callback error:`, {
        error: error.message,
        errorCode: error.code,
        platform,
        chatId,
        gatewayUrl: config.gateway.url,
        stack: error.stack?.substring(0, 500)
      });

      // In dummy mode, return success response even if gateway fails
      // This prevents task failures in gateway-only environments
      logger.warn(`[Gateway] ⚠️  Returning dummy response despite gateway error`);
      return {
        ok: true,
        result: {
          message_id: Math.floor(Math.random() * 1000000),
          chat: { id: chatId },
          date: Date.now() / 1000,
          text: text
        }
      };
    }
  }

  async editViaGateway(platform, chatId, messageId, text, options = {}) {
    const payload = {
      platform,
      chatId,
      message: {
        type: 'edit',
        content: text,
        options: {
          messageId,
          ...options
        }
      },
      instanceId: config.gateway.instanceId,
      timestamp: new Date().toISOString()
    };

    logger.debug(`[Gateway] Editing message ${messageId} in ${chatId}`);

    try {
      const fetch = (await import('node-fetch')).default;
      const response = await fetch(`${config.gateway.url}/api/callback/message`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-instance-id': config.gateway.instanceId,
          'x-gateway-token': config.gateway.token
        },
        body: JSON.stringify(payload),
        timeout: 10000 // 10 second timeout
      });

      if (!response.ok) {
        const errorText = await response.text();
        logger.error(`[Gateway] Edit callback failed with HTTP ${response.status}`, {
          status: response.status,
          statusText: response.statusText,
          errorText: errorText.substring(0, 500),
          chatId,
          messageId,
          platform
        });
        throw new Error(`Gateway edit callback failed: ${response.status} - ${errorText}`);
      }

      const result = await response.json();

      logger.info(`[Gateway] ✓ Edited ${messageId} in ${chatId}`);

      // Normalize gateway response to Telegram API format: { ok, result: { message_id } }
      if (result.platform_response) {
        return result.platform_response;
      }
      return {
        ok: !!result.success,
        result: result.message_id ? { message_id: result.message_id } : undefined
      };
    } catch (error) {
      logger.error(`[Gateway] ✗ Gateway edit callback error:`, {
        error: error.message,
        errorCode: error.code,
        platform,
        chatId,
        messageId,
        gatewayUrl: config.gateway.url,
        stack: error.stack?.substring(0, 500)
      });

      // In dummy mode, return success response even if gateway fails
      // This prevents task failures in gateway-only environments
      logger.warn(`[Gateway] ⚠️  Returning dummy response despite gateway edit error`);
      return {
        ok: true,
        result: {
          message_id: messageId,
          chat: { id: chatId },
          date: Date.now() / 1000,
          text: text
        }
      };
    }
  }

  async answerCallbackQueryViaGateway(chatId, callbackQueryId, options = {}) {
    const payload = {
      platform: 'telegram',
      chatId: String(chatId), // Gateway requires chatId for validation
      message: {
        type: 'answerCallback',
        callbackQueryId,
        ...options
      },
      instanceId: config.gateway.instanceId,
      timestamp: new Date().toISOString()
    };

    logger.debug(`[Gateway] Answering callback query ${callbackQueryId}`);

    try {
      const fetch = (await import('node-fetch')).default;
      const response = await fetch(`${config.gateway.url}/api/callback/message`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-instance-id': config.gateway.instanceId,
          'x-gateway-token': config.gateway.token
        },
        body: JSON.stringify(payload),
        timeout: 10000 // 10 second timeout
      });

      if (!response.ok) {
        const errorText = await response.text();
        logger.error(`[Gateway] Answer callback query failed with HTTP ${response.status}`, {
          status: response.status,
          statusText: response.statusText,
          errorText: errorText.substring(0, 500),
          callbackQueryId
        });
        throw new Error(`Gateway answer callback query failed: ${response.status} - ${errorText}`);
      }

      const result = await response.json();
      logger.info(`[Gateway] ✓ Callback answered`);
      return result;
    } catch (error) {
      logger.error(`[Gateway] ✗ Gateway answer callback query error:`, {
        error: error.message,
        errorCode: error.code,
        callbackQueryId,
        gatewayUrl: config.gateway.url,
        stack: error.stack?.substring(0, 500)
      });

      // In dummy mode, return success response even if gateway fails
      logger.warn(`[Gateway] ⚠️  Returning dummy response despite gateway error`);
      return { ok: true };
    }
  }

  async sendMessage(chatId, text, options = {}) {
    // Sanitize the message for Telegram API (inherited from base class)
    const sanitizedText = this.sanitizeMessageForTelegram(text);

    // Route through gateway if in gateway mode
    if (config.gateway.enabled) {
      return this.sendViaGateway('telegram', chatId, sanitizedText, options);
    }

    logger.debug(`[DUMMY-TELEGRAM] Sending message`, {
      chatId,
      textLength: sanitizedText.length,
      hasMarkdown: options.parse_mode === 'Markdown',
      hasKeyboard: !!options.reply_markup
    });

    // Extract key information from the message for logging
    if (sanitizedText.includes('*Task Started*') || sanitizedText.includes('*Task Completed*') || sanitizedText.includes('*Task Failed*')) {
      logger.info(`[DUMMY-TELEGRAM] ${sanitizedText.split('\n')[0].replace(/[*_`]/g, '')}`);
    }

    return {
      ok: true,
      result: {
        message_id: Math.floor(Math.random() * 1000000),
        chat: { id: chatId },
        date: Date.now() / 1000,
        text: sanitizedText
      }
    };
  }

  async editMessage(chatId, messageId, text, options = {}) {
    // Validate messageId is provided
    if (!messageId) {
      logger.error('[DUMMY-TELEGRAM] editMessage called without messageId', {
        chatId,
        textPreview: text?.substring(0, 100),
        stack: new Error().stack
      });
      return { success: false, error: 'messageId is required for edit operations' };
    }

    logger.debug(`[DUMMY-TELEGRAM] Editing message`, {
      chatId,
      messageId,
      textLength: text.length,
      gatewayEnabled: config.gateway.enabled
    });

    // Sanitize the message for Telegram API
    const sanitizedText = this.sanitizeMessageForTelegram(text);

    // Route through gateway if in gateway mode
    if (config.gateway.enabled) {
      return this.editViaGateway('telegram', chatId, messageId, sanitizedText, options);
    }

    // Non-gateway mode: return dummy response
    return {
      ok: true,
      result: {
        message_id: messageId,
        chat: { id: chatId },
        date: Date.now() / 1000,
        text: sanitizedText
      }
    };
  }

  async sendPhoto(chatId, photoUrl, options = {}) {
    logger.debug(`[DUMMY-TELEGRAM] Sending photo`, {
      chatId,
      photoUrl,
      caption: options.caption
    });

    return {
      ok: true,
      result: {
        message_id: Math.floor(Math.random() * 1000000),
        chat: { id: chatId },
        date: Date.now() / 1000
      }
    };
  }

  async sendVideo(chatId, videoUrl, options = {}) {
    logger.debug(`[DUMMY-TELEGRAM] Sending video`, {
      chatId,
      videoUrl,
      caption: options.caption
    });

    return {
      ok: true,
      result: {
        message_id: Math.floor(Math.random() * 1000000),
        chat: { id: chatId },
        date: Date.now() / 1000
      }
    };
  }

  async sendDocument(chatId, documentPath, options = {}) {
    logger.debug(`[DUMMY-TELEGRAM] Sending document`, {
      chatId,
      documentPath,
      caption: options.caption
    });

    return {
      ok: true,
      result: {
        message_id: Math.floor(Math.random() * 1000000),
        chat: { id: chatId },
        date: Date.now() / 1000
      }
    };
  }

  async sendMessageToWorkspace(workspaceId, message, options = {}) {
    logger.info(`[DUMMY-TELEGRAM] Message to workspace`, {
      workspaceId,
      messageLength: message.length,
      hasAttachments: message.includes('@')
    });

    return {
      success: true,
      workspace: workspaceId,
      chatId: this.defaultChatId,
      attachmentCount: 0
    };
  }

  async sendCustomMessage(title, content, chatId = null) {
    const targetChatId = chatId || this.defaultChatId;

    logger.info(`[DUMMY-TELEGRAM] Custom message: ${title}`, {
      chatId: targetChatId,
      contentLength: content.length
    });

    return this.sendMessage(targetChatId, `*${title}*\n\n${content}`, { parse_mode: 'Markdown' });
  }

  async sendInteractiveMessage(title, content, actions = [], chatId = null) {
    const targetChatId = chatId || this.defaultChatId;

    logger.info(`[DUMMY-TELEGRAM] Interactive message: ${title}`, {
      chatId: targetChatId,
      actionCount: actions.length
    });

    return this.sendMessage(targetChatId, `*${title}*\n\n${content}`, { parse_mode: 'Markdown' });
  }

  async sendHelpMessage(chatId, currentWorkdirName) {
    logger.info(`[DUMMY-TELEGRAM] Help message requested`, {
      chatId,
      workspace: currentWorkdirName
    });

    let helpContent = `🤖 *AniCode Bot Commands*\n\n`;
    helpContent += `*Task Commands:*\n`;
    helpContent += `• /add [prompt] - Create a new Claude task\n`;
    helpContent += `• /continue [prompt] - Continue previous Claude task\n`;
    helpContent += `• /remember [info] - Save info to CLAUDE.md\n`;
    helpContent += `• /rulecompress [context] - Compress and organize CLAUDE.md\n`;
    helpContent += `• /check - Run completion checklist\n`;
    helpContent += `• /print - Show complete output of last task\n`;
    helpContent += `• /status - Show running tasks\n`;
    helpContent += `• /rank - Show daily usage report\n`;
    helpContent += `• /usage - Check Claude API usage (sessions, Opus)\n`;
    helpContent += `• /usage reset all - Reset all usage cache (session + opus)\n`;
    helpContent += `• /usage reset opus - Reset opus usage cache only\n`;
    helpContent += `• /history - Get HTML view of latest Claude session\n`;
    helpContent += `• /daystat - Show 24-hour task statistics\n`;
    helpContent += `• /weekstat - Show 7-day task statistics\n`;
    helpContent += `• /monthstat - Show 30-day task statistics\n`;
    helpContent += `• /yearstat - Show 12-month task statistics\n`;
    helpContent += `• /report - Generate token usage heatmap report\n`;
    helpContent += `• /url - Get public URL of last image\n`;
    helpContent += `• /img - Extract and send images from last task output\n`;
    helpContent += `• /branch [name/desc] - Create or switch git branches\n`;
    helpContent += `• /macros - List all macro commands\n`;
    helpContent += `\n*Goal Commands:*\n`;
    helpContent += `• /goals - List all project goals\n`;
    helpContent += `• /goals show <id> - View goal details\n`;
    helpContent += `• /goaladd <desc> - Create new goal\n`;
    helpContent += `• /goaladdmulti <desc> - Create multiple goals\n`;
    helpContent += `• /goalcheck - Check completion status\n`;
    helpContent += `• /goalsync [--fast|--full] - Sync goals cache\n`;
    helpContent += `• /goalloop [opts] - Run automation loop\n`;
    helpContent += `\n*Project Health:*\n`;
    helpContent += `• /healthcheck - Run audit with AI analysis\n`;
    helpContent += `• /healthcheck fix - Auto-fix vulnerabilities\n`;
    helpContent += `• /healthcheck only-json - Skip AI, raw report only\n`;
    helpContent += `\n*Plan Commands:*\n`;
    helpContent += `• /plan [steps] - Create a new plan with steps\n`;
    helpContent += `• /plans - List all plans for the workspace\n`;
    helpContent += `• /next [plan-id] - Execute the next plan or specific plan\n`;
    helpContent += `• /yolo - Execute ALL pending plans with commits\n`;
    helpContent += `• /stopyolo - Stop ongoing YOLO execution\n`;
    helpContent += `• /cleanup - Remove all completed plans\n`;
    helpContent += `• /purge confirm - Force reset all plans (⚠️ dangerous)\n`;

    if (!currentWorkdirName) {
      helpContent += `\n*Workspace Settings:*\n`;
      helpContent += `• /connect [token] - Connect this chat to a workspace\n`;
      helpContent += `\n❌ *No workspace connected* - use /connect [token] to connect`;
    } else {
      helpContent += `\n📁 *Working in:* ${currentWorkdirName}`;
    }

    helpContent += await this.formatFooter('help');

    // Build inline keyboard for quick actions
    const keyboard = { inline_keyboard: [] };

    keyboard.inline_keyboard.push([
      {
        text: '📊 Status',
        callback_data: JSON.stringify({ action: 'show_status' })
      }
    ]);

    if (currentWorkdirName) {
      keyboard.inline_keyboard.push([
        {
          text: '🔄 Continue',
          callback_data: JSON.stringify({ action: 'claude_continue' })
        },
        {
          text: '💾 Commit',
          callback_data: JSON.stringify({
            action: 'run_task',
            command: 'ani-code commit -y'
          })
        }
      ]);
    }

    return this.sendMessage(chatId, helpContent, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    });
  }

  async formatYoloStatusMessage(workspaceName, totalPlans, completedPlans, currentPlan = null, status = 'executing', executionData = {}) {
    logger.debug(`[DUMMY-TELEGRAM] YOLO status`, {
      workspace: workspaceName,
      totalPlans,
      completedPlans,
      status,
      hasCurrentPlan: !!currentPlan
    });

    return `🚀 YOLO Mode - ${completedPlans}/${totalPlans} plans (${status})`;
  }

  async sendYoloStatus(chatId, message, options = {}) {
    logger.info(`[DUMMY-TELEGRAM] YOLO status message`, {
      chatId,
      workspace: options.workspace?.name,
      showButtons: options.showButtons
    });

    this.yoloProtectedChats.add(chatId);

    return this.sendMessage(chatId, message, { parse_mode: 'Markdown' });
  }

  async updateYoloStatus(chatId, messageId, message, options = {}) {
    logger.debug(`[DUMMY-TELEGRAM] YOLO status update`, {
      chatId,
      messageId,
      showCompletedButtons: options.showCompletedButtons
    });

    if (options.showCompletedButtons) {
      this.yoloProtectedChats.delete(chatId);
    }

    return this.editMessage(chatId, messageId, message, { parse_mode: 'Markdown' });
  }

  isYoloProtected(chatId) {
    return this.yoloProtectedChats.has(chatId);
  }

  clearYoloProtection(chatId) {
    this.yoloProtectedChats.delete(chatId);
    logger.debug(`[DUMMY-TELEGRAM] Cleared YOLO protection for chat ${chatId}`);
  }

  async deleteMessage(chatId, messageId) {
    logger.debug(`[DUMMY-TELEGRAM] Deleting message ${messageId} in chat ${chatId}`, {
      gatewayEnabled: config.gateway.enabled
    });

    // Route through gateway if in gateway mode
    if (config.gateway.enabled) {
      return this.deleteViaGateway('telegram', chatId, messageId);
    }

    return { ok: true };
  }

  async pinChatMessage(chatId, messageId, options = {}) {
    logger.debug(`[DUMMY-TELEGRAM] Pinning message ${messageId} in chat ${chatId}`, {
      gatewayEnabled: config.gateway.enabled,
      disableNotification: options.disable_notification
    });

    // Route through gateway if in gateway mode
    if (config.gateway.enabled) {
      return this.pinViaGateway('telegram', chatId, messageId, options);
    }

    return { ok: true };
  }

  async unpinChatMessage(chatId, messageId) {
    logger.debug(`[DUMMY-TELEGRAM] Unpinning message ${messageId} in chat ${chatId}`, {
      gatewayEnabled: config.gateway.enabled
    });

    // Route through gateway if in gateway mode
    if (config.gateway.enabled) {
      return this.unpinViaGateway('telegram', chatId, messageId);
    }

    return { ok: true };
  }

  async deleteViaGateway(platform, chatId, messageId) {
    const payload = {
      platform,
      chatId,
      message: {
        type: 'delete',
        options: {
          messageId
        }
      },
      instanceId: config.gateway.instanceId,
      timestamp: new Date().toISOString()
    };

    logger.debug(`[Gateway] Deleting message ${messageId} in ${chatId}`);

    try {
      const fetch = (await import('node-fetch')).default;
      const response = await fetch(`${config.gateway.url}/api/callback/message`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-instance-id': config.gateway.instanceId,
          'x-gateway-token': config.gateway.token
        },
        body: JSON.stringify(payload),
        timeout: 10000
      });

      if (!response.ok) {
        const errorText = await response.text();
        logger.error(`[Gateway] Delete callback failed with HTTP ${response.status}`, {
          status: response.status,
          statusText: response.statusText,
          errorText: errorText.substring(0, 500),
          chatId,
          messageId,
          platform
        });
        throw new Error(`Gateway delete callback failed: ${response.status} - ${errorText}`);
      }

      const result = await response.json();
      logger.info(`[Gateway] ✓ Deleted ${messageId} in ${chatId}`);
      return result;
    } catch (error) {
      logger.error(`[Gateway] ✗ Gateway delete callback error:`, {
        error: error.message,
        errorCode: error.code,
        platform,
        chatId,
        messageId,
        gatewayUrl: config.gateway.url,
        stack: error.stack?.substring(0, 500)
      });

      logger.warn(`[Gateway] ⚠️  Returning dummy response despite gateway delete error`);
      return { ok: true };
    }
  }

  async pinViaGateway(platform, chatId, messageId, options = {}) {
    const payload = {
      platform,
      chatId,
      message: {
        type: 'pin',
        options: {
          messageId,
          disable_notification: options.disable_notification
        }
      },
      instanceId: config.gateway.instanceId,
      timestamp: new Date().toISOString()
    };

    logger.debug(`[Gateway] Pinning message ${messageId} in ${chatId}`);

    try {
      const fetch = (await import('node-fetch')).default;
      const response = await fetch(`${config.gateway.url}/api/callback/message`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-instance-id': config.gateway.instanceId,
          'x-gateway-token': config.gateway.token
        },
        body: JSON.stringify(payload),
        timeout: 10000
      });

      if (!response.ok) {
        const errorText = await response.text();
        logger.error(`[Gateway] Pin callback failed with HTTP ${response.status}`, {
          status: response.status,
          statusText: response.statusText,
          errorText: errorText.substring(0, 500),
          chatId,
          messageId,
          platform
        });
        throw new Error(`Gateway pin failed: ${response.status} - ${errorText}`);
      }

      const result = await response.json();
      logger.info(`[Gateway] ✓ Pinned ${messageId} in ${chatId}`);
      return result;
    } catch (error) {
      logger.error(`[Gateway] ✗ Gateway pin error:`, {
        error: error.message,
        errorCode: error.code,
        platform,
        chatId,
        messageId,
        gatewayUrl: config.gateway.url,
        stack: error.stack?.substring(0, 500)
      });

      logger.warn(`[Gateway] ⚠️  Returning dummy response despite gateway pin error`);
      return { ok: true };
    }
  }

  async unpinViaGateway(platform, chatId, messageId = null) {
    const payload = {
      platform,
      chatId,
      message: {
        type: 'unpin',
        options: {
          messageId
        }
      },
      instanceId: config.gateway.instanceId,
      timestamp: new Date().toISOString()
    };

    logger.debug(`[Gateway] Unpinning message ${messageId || 'latest'} in ${chatId}`);

    try {
      const fetch = (await import('node-fetch')).default;
      const response = await fetch(`${config.gateway.url}/api/callback/message`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-instance-id': config.gateway.instanceId,
          'x-gateway-token': config.gateway.token
        },
        body: JSON.stringify(payload),
        timeout: 10000
      });

      if (!response.ok) {
        const errorText = await response.text();
        logger.error(`[Gateway] Unpin callback failed with HTTP ${response.status}`, {
          status: response.status,
          statusText: response.statusText,
          errorText: errorText.substring(0, 500),
          chatId,
          messageId: messageId || 'latest',
          platform
        });
        throw new Error(`Gateway unpin failed: ${response.status} - ${errorText}`);
      }

      const result = await response.json();
      logger.info(`[Gateway] ✓ Unpinned ${messageId || 'latest'} in ${chatId}`);
      return result;
    } catch (error) {
      logger.error(`[Gateway] ✗ Gateway unpin error:`, {
        error: error.message,
        errorCode: error.code,
        platform,
        chatId,
        messageId: messageId || 'latest',
        gatewayUrl: config.gateway.url,
        stack: error.stack?.substring(0, 500)
      });

      logger.warn(`[Gateway] ⚠️  Returning dummy response despite gateway unpin error`);
      return { ok: true };
    }
  }

  async sendErrorNotification(error, context = {}) {
    logger.error(`[DUMMY-TELEGRAM] Error notification`, {
      error: error.message || error,
      source: context.source,
      taskId: context.taskId,
      operation: context.operation,
      suggestion: context.suggestion
    });

    return { ok: true };
  }

  // Use parent's buildCostTokenLine for full token/model info display
  // (removed simplified override that only showed cost)

  getSimplifiedPromptDescription(command, taskName) {
    return taskName || 'Task';
  }

  isTemplateStylePrompt(command) {
    return false;
  }

  shortenHostname(hostname) {
    return hostname;
  }
}
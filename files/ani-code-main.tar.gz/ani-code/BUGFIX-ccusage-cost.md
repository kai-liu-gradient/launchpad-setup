# Bug Fix: ccusage Cost Calculation Issue

## Problem
When using `ccusage` with the `--since` date filter, the command returns `totalCost: 0` even though tokens are properly counted and model breakdowns contain valid cost data.

## Root Cause
The `ccusage` tool (version 16.2.4) has a bug where the `totals.totalCost` aggregation doesn't work correctly when filtering by date using `--since`. However, the individual model breakdown costs are still calculated correctly.

## Test Case
```bash
# With --since filter
ccusage -j --offline --breakdown --since 20250930
# Returns: totalCost: 0, but tokens are counted

# Without --since filter
ccusage -j --offline --breakdown
# Returns: totalCost: 462.35, tokens counted correctly
```

## Solution
Implemented a workaround in `src/usage-reporter.js` to detect when `totalCost` is 0 but `totalTokens` > 0, and calculate the cost by summing up the individual model breakdown costs.

## Changes Made

### 1. `formatUsageReport()` method (lines 73-94)
Added workaround to calculate cost from model breakdowns when totals.totalCost is 0:
```javascript
if (totals.totalCost === 0 && totals.totalTokens > 0) {
  // Calculate from model breakdowns in daily data
  let calculatedCost = 0;
  for (const model of usageData.daily[0].modelBreakdowns) {
    calculatedCost += model.cost;
  }
  totals = { ...totals, totalCost: calculatedCost };
}
```

### 2. `createTaskSnapshot()` method (lines 228-244)
Added same workaround for "before" task snapshots.

### 3. `createTaskCompletionSnapshot()` method (lines 302-318)
Added same workaround for "after" task snapshots.

### 4. `calculateUsageDifference()` method (lines 338-363)
Added workaround to calculate cost difference from model breakdown differences when totals show 0 cost but have token usage.

## Impact
- Daily usage reports now show correct costs
- Task usage tracking now properly calculates costs per task
- Lark notifications will show accurate cost information
- No impact on cases where ccusage already returns correct costs

## Testing
Created test scripts:
- `test-ccusage-format.js` - Demonstrates the original issue
- `test-cost-fix.js` - Validates the fix works correctly

## Future Considerations
This is a workaround for a ccusage bug. If ccusage is updated to fix the `--since` aggregation issue, this workaround will gracefully do nothing (since the condition checks for totalCost === 0).

Monitor ccusage updates:
```bash
npm list ccusage -g
# Current version: 16.2.4
```

## Files Modified
- `src/usage-reporter.js` - Added cost calculation workarounds in 4 methods
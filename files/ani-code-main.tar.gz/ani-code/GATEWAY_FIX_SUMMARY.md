# Gateway Integration Fix - Message Response Issue

## Problem Statement

When receiving commands from the gateway (e.g., `/add` command from Telegram chat `-4868224422`), ani-code was not sending response messages back through the gateway callback mechanism. Users received no feedback when:

1. No working directory was configured for the chat
2. The configured working directory was no longer available
3. Other error conditions occurred during task creation

## Root Cause Analysis

The issue was caused by insufficient logging and error tracking in the gateway callback path:

1. **Silent Failures**: The `sendViaGateway` method had minimal logging, making it difficult to diagnose failures
2. **No Error Context**: When error messages were sent from `createTelegramTask`, there was no logging to confirm the messages were routed through the gateway
3. **Difficult Debugging**: Without detailed logs, it was impossible to determine if:
   - The gateway callback was being attempted
   - The gateway callback was failing
   - The error message was being sent at all

## Solution Implemented

### 1. Enhanced Gateway Callback Logging (`src/telegram-notifier.js`)

Added comprehensive logging to `sendViaGateway` method:

- **Before sending**: Log attempt with full configuration details
  - Platform, chat ID, message length
  - Gateway URL, instance ID, token presence
  - Endpoint being called

- **On success**: Log successful delivery with response details
  - Message sent confirmation
  - Response status

- **On error**: Log detailed error information
  - Error message and code
  - Stack trace (truncated)
  - Gateway configuration
  - Fallback behavior

### 2. Added Gateway Logging in Error Paths (`src/http-server.js`)

Enhanced `createTelegramTask` with gateway-aware logging:

- **Before sending error messages**: Log warning with context
  - Chat ID and available workdirs
  - Gateway enabled status

- **After sending error messages**: Confirm message was sent
  - Log successful send confirmation

### 3. Enhanced sendMessage Routing (`src/telegram-notifier.js`)

Added debug logging when routing through gateway:
- Confirms gateway routing decision
- Logs message length and gateway URL

## Testing the Fix

### Manual Test Steps

1. Send `/add hi` command from Telegram chat that has no workdir configured
2. Check logs for the following sequence:

```
[Gateway] No workdir configured for chat -4868224422, sending error message
[Gateway] Routing message through gateway for chat -4868224422
[Gateway] Attempting to send message via gateway callback
[Gateway] ✓ Message sent successfully via gateway
[Gateway] Error message sent to chat -4868224422 about missing workdir
```

3. Verify user receives the error message in Telegram

### Expected Behavior

- User receives immediate feedback: "❌ No working directory selected"
- Logs show gateway callback attempt and success/failure
- If gateway callback fails, fallback to direct Telegram API is attempted
- All error paths are logged for debugging

## Log Examples

### Successful Gateway Callback
```
INFO: [Gateway] Attempting to send message via gateway callback {
  "platform": "telegram",
  "chatId": -4868224422,
  "messageLength": 78,
  "gatewayUrl": "https://launchpad.corp.anispark.xyz/gatewayproxy/",
  "instanceId": "project-p-6o0kp4lu",
  "hasToken": true,
  "endpoint": "/api/callback/message"
}
INFO: [Gateway] ✓ Message sent successfully via gateway {
  "platform": "telegram",
  "chatId": -4868224422,
  "messageLength": 78,
  "responseOk": true
}
```

### Failed Gateway Callback with Fallback
```
ERROR: [Gateway] ✗ Gateway callback error: {
  "error": "Gateway callback failed: 500 - Internal Server Error",
  "errorCode": "ECONNREFUSED",
  "platform": "telegram",
  "chatId": -4868224422,
  "gatewayUrl": "https://launchpad.corp.anispark.xyz/gatewayproxy/",
  "stack": "Error: Gateway callback failed..."
}
WARN: [Gateway] ⚠️  Falling back to direct telegram send for chat -4868224422
INFO: [TELEGRAM API] ✓ Message sent to chat -4868224422 in 523ms (id: 12345, len: 78)
```

## Files Changed

1. **src/telegram-notifier.js**
   - Enhanced `sendViaGateway` method with detailed logging
   - Added debug logging in `sendMessage` for gateway routing

2. **src/http-server.js**
   - Added gateway-aware logging in `createTelegramTask` error paths
   - Logs before and after error message sends

## Benefits

1. **Improved Debugging**: Detailed logs make it easy to diagnose gateway callback issues
2. **Better Monitoring**: Clear visibility into gateway callback success/failure rates
3. **Automatic Fallback**: Direct Telegram API fallback prevents message loss
4. **User Feedback**: Users always receive error messages, even if gateway fails
5. **Production Readiness**: Comprehensive logging enables quick issue resolution

## Next Steps

1. Monitor logs after deployment to verify fix works correctly
2. Add metrics tracking for gateway callback success/failure rates
3. Consider adding retry logic for transient gateway failures
4. Document gateway callback protocol for future maintenance

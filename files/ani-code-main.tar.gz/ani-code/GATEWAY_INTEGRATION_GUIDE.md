# Ani-Code Gateway Integration Guide

Complete guide for integrating ani-code instances with ani-code-gateway.

## Table of Contents
1. [Quick Start](#quick-start)
2. [Environment Configuration](#environment-configuration)
3. [Port Configuration](#port-configuration)
4. [Connection Verification](#connection-verification)
5. [Token Management](#token-management)
6. [Troubleshooting](#troubleshooting)

---

## Quick Start

### Prerequisites
- ani-code daemon running
- ani-code-gateway deployed and accessible
- Network connectivity between ani-code and gateway

### 4-Step Setup

**Step 1: Verify Current Configuration**
```bash
# Check current gateway settings
ani-code gateway config
```

**Step 2: Configure Environment Variables**
```bash
# In your ani-code .env file or environment
export GATEWAY_URL=http://your-gateway-host:6555
export ANI_CODE_URL=http://your-ani-code-host:6501
export GATEWAY_API_KEY=your-api-key  # Optional, depends on gateway setup
```

**Step 3: Restart Daemon**
```bash
# The daemon will auto-register with gateway on startup
ani-code daemon --status
```

**Step 4: Verify Connection**
```bash
# NEW: Direct verification from CLI
ani-code gateway status

# Detailed connectivity test
ani-code gateway test
```

---

## Environment Configuration

### Complete Environment Variables

```bash
# ============================================
# ANI-CODE GATEWAY INTEGRATION
# ============================================

# Gateway Configuration (Optional - leave empty for standalone mode)
GATEWAY_URL=http://your-gateway-host:6555
ANI_CODE_URL=http://your-ani-code-host:6501
GATEWAY_API_KEY=dev-key-1  # Optional - gateway may require this

# Kubernetes/Pod Metadata (Optional - for K8s deployments)
PROJECT_ID=my-project
WORKSPACE_ID=my-workspace
POD_NAME=ani-code-pod-xyz
POD_IP=10.244.0.5

# ============================================
# ANI-CODE DAEMON CONFIGURATION
# ============================================

# HTTP API Server (Gateway connects to this)
ANI_CODE_DAEMON_PORT=6501        # Primary port setting
HTTP_CALLBACK_HOST=0.0.0.0       # MUST be 0.0.0.0 for gateway access
# Alternative port settings (lower priority):
# HTTP_CALLBACK_PORT=6501        # Legacy fallback
# PORT=6501                       # Generic fallback

# WebSocket Service (Optional - for real-time updates)
ANICODE_WS_PORT=6502

# ============================================
# OPERATION MODE
# ============================================

# Dummy Mode (No Telegram/Lark required for gateway control)
ANI_CODE_DUMMY_MODE=true

# OR if using Telegram/Lark:
# TELEGRAM_BOT_TOKEN=your-bot-token
# TELEGRAM_CHAT_ID=your-chat-id

# ============================================
# LOGGING
# ============================================

LOG_LEVEL=info  # debug for verbose gateway registration logs
```

---

## Port Configuration

### Port Overview

| Port | Service | Used By | Binding | Required |
|------|---------|---------|---------|----------|
| 6501 | HTTP API | Gateway registration & routing | 0.0.0.0 | ✅ Yes |
| 6502 | WebSocket | Real-time updates (optional) | 0.0.0.0 | ❌ No |
| 6555 | Gateway API | Gateway's own API | N/A | N/A |

### Critical: HTTP API Must Bind to 0.0.0.0

**Default Configuration (already correct):**
```javascript
// src/config.js:60
host: process.env.HTTP_CALLBACK_HOST || '0.0.0.0'
```

**Why 0.0.0.0?**
- `127.0.0.1` = Only localhost can access (gateway can't connect)
- `0.0.0.0` = All network interfaces (gateway can connect)

**Verify Binding:**
```bash
# Check what the daemon is listening on
netstat -tlnp | grep 6501

# Expected output:
# tcp  0  0 0.0.0.0:6501  0.0.0.0:*  LISTEN  12345/node
#           ^^^^^^^^^ Should be 0.0.0.0, NOT 127.0.0.1
```

**Override if Needed:**
```bash
# Force binding to all interfaces
export HTTP_CALLBACK_HOST=0.0.0.0
```

---

## Connection Verification

### Step-by-Step Verification

**1. Check Gateway Configuration**
```bash
# NEW: Direct gateway configuration check
ani-code gateway config

# Shows all gateway-related environment variables
```

**2. Check Gateway Registration Status**
```bash
# NEW: Direct gateway status check
ani-code gateway status

# Shows:
# - Gateway mode enabled/disabled
# - Registration status
# - Heartbeat status
# - Gateway health
# - Instance details
```

**3. Test Gateway Connectivity**
```bash
# NEW: Test gateway connection
ani-code gateway test

# Tests:
# - Gateway health endpoint
# - Instance registration
# - Network connectivity
```

**4. Check Daemon Status**
```bash
ani-code daemon --status

# Expected output includes:
# ✓ Daemon is running
# HTTP callback server: 0.0.0.0:6501  ← Verify 0.0.0.0
```

**5. Check Daemon Logs** (optional)
```bash
# View systemd logs
journalctl -u ani-code -f

# Look for these lines:
# ✓ "Registered with gateway: instanceId: xxx"
# ✓ "Gateway heartbeat started"

# If not found, check for errors:
# ⚠ "Gateway unavailable (continuing in standalone mode)"
# ⚠ "Gateway authentication failed - check GATEWAY_API_KEY"
```

**6. Test Local HTTP API** (if needed)
```bash
# From ani-code host
curl http://localhost:6501/health

# Expected: {"status":"ok","timestamp":"..."}

# From another machine (test network access)
curl http://your-ani-code-host:6501/health
```

**Note:** The new `ani-code gateway status` and `ani-code gateway test` commands handle most verification automatically. Manual curl commands are only needed for deeper troubleshooting.

---

## Token Management

### Understanding Token Flow

```
┌─────────────┐         ┌──────────────┐         ┌─────────────┐
│  Admin CLI  │────1───>│   ani-code   │────2───>│   Gateway   │
└─────────────┘         └──────────────┘         └─────────────┘
                               │
                               │ 3
                               ▼
                        ┌──────────────┐
                        │ Returns Both │
                        │  - ws_token  │
                        │  - gw_token  │
                        └──────────────┘
```

1. Admin generates token via CLI
2. ani-code registers token with gateway
3. Both workspace and gateway tokens returned

### Generate Connection Token

**From Workspace Directory:**
```bash
cd /path/to/workspace
ani-code workspace token gen -n "Team Connection"
```

**Output:**
```
✓ Token generated successfully:
  ws_abc123xyz789...  ← Workspace token (direct connection)

  Token details:
    ID: tok_456
    Workspace: my-project
    Type: api
    Permissions: read, write

  Save this token securely. It won't be shown again.

Registering with gateway...
✓ Registered with gateway
  Gateway Token: gw_xyz789abc123...  ← Gateway token (for users)

  For Telegram: /start gw_xyz789abc123...
  Webhook URL: http://gateway:6555/api/gateway/webhook/telegram?token=gw_xyz789abc123...
```

### Token Types

**Workspace Token (ws_xxx):**
- Direct connection to this ani-code instance
- Used by: Chrome plugin, direct API calls
- Bypasses gateway

**Gateway Token (gw_xxx):**
- Routes through gateway to this instance
- Used by: Telegram/Lark users in multi-instance setup
- Share this with team members

### Share Token with Users

**For Telegram Users:**
```
1. Share gateway token: gw_xyz789abc123...
2. User opens Telegram bot
3. User sends: /start gw_xyz789abc123...
4. Bot confirms connection to your workspace
5. User can now send commands directly
```

**For API Integrations:**
```bash
# Use workspace token for direct API calls
curl -X POST http://your-ani-code-host:6501/api/tasks/add \
  -H "Authorization: Bearer ws_abc123xyz789..." \
  -H "Content-Type: application/json" \
  -d '{"prompt": "run tests"}'
```

### List Existing Tokens

```bash
# From workspace directory
ani-code workspace token list

# Or specify workspace
ani-code workspace token list my-project
```

### Revoke Token

```bash
# Using token ID prefix
ani-code workspace token revoke tok_456

# Full token ID
ani-code workspace token revoke tok_456789abc123
```

---

## Troubleshooting

### Issue: Gateway Not Registering

**Symptoms:**
- No "Registered with gateway" log message
- Gateway lists no instances

**Quick Diagnosis:**
```bash
# Use built-in diagnostic commands
ani-code gateway config   # Check configuration
ani-code gateway status   # Check registration status
ani-code gateway test     # Test connectivity
```

**Detailed Diagnosis:**
```bash
# 1. Check environment variables
env | grep GATEWAY

# Expected:
# GATEWAY_URL=http://gateway:6555
# ANI_CODE_URL=http://ani-code:6501

# 2. Test gateway connectivity
curl http://your-gateway-host:6555/api/health

# 3. Test with verbose logging
LOG_LEVEL=debug ani-code daemon --start
```

**Solutions:**
- Verify `GATEWAY_URL` is set and reachable
- Check `ANI_CODE_URL` matches your actual hostname/IP
- Ensure port 6555 is accessible on gateway
- Check `GATEWAY_API_KEY` if gateway requires authentication

---

### Issue: Gateway Can't Reach Ani-Code

**Symptoms:**
- Instance shows "unhealthy" in gateway
- Health checks failing

**Diagnosis:**
```bash
# 1. Verify binding
netstat -tlnp | grep 6501
# MUST show: 0.0.0.0:6501 (not 127.0.0.1:6501)

# 2. Test from gateway server
curl http://ani-code-host:6501/health

# 3. Check firewall
sudo iptables -L -n | grep 6501
```

**Solutions:**
- Set `HTTP_CALLBACK_HOST=0.0.0.0`
- Open firewall port 6501
- Verify `ANI_CODE_URL` uses correct hostname (not localhost)
- Check Docker/K8s network policies

---

### Issue: Token Not Registering with Gateway

**Symptoms:**
- Token generation succeeds
- No gateway token returned
- Warning: "Gateway registration failed"

**Diagnosis:**
```bash
# Check gateway token endpoint
curl http://gateway:6555/api/tokens/register \
  -H "X-API-Key: your-key" \
  -H "Content-Type: application/json" \
  -d '{
    "instanceUrl": "http://ani-code:6501",
    "workspaceToken": "ws_test",
    "projectName": "Test"
  }'
```

**Solutions:**
- Verify gateway API is running: `curl http://gateway:6555/api/health`
- Check `GATEWAY_API_KEY` matches gateway configuration
- Ensure gateway database is initialized
- Check gateway logs for errors

---

### Issue: Heartbeat Failing

**Symptoms:**
- Instance disappears from gateway after 1 hour
- Log shows: "Gateway heartbeat failed"

**Diagnosis:**
```bash
# Check daemon logs
journalctl -u ani-code -f | grep heartbeat

# Look for:
# "Gateway heartbeat started"  ← Good
# "Gateway heartbeat failed"   ← Bad
```

**Solutions:**
- Verify network connectivity is stable
- Check gateway is not rate-limiting requests
- Ensure ani-code daemon stays running
- Restart daemon to re-establish connection

---

### Issue: Multiple Instances Conflicting

**Symptoms:**
- Tokens route to wrong instance
- Users get unexpected workspace

**Diagnosis:**
```bash
# List all registered instances
curl http://gateway:6555/api/registry/instances

# Check token mappings
curl http://gateway:6555/api/tokens/mappings
```

**Solutions:**
- Use unique `ANI_CODE_URL` for each instance
- Set unique `PROJECT_ID` and `WORKSPACE_ID` in K8s
- Ensure each instance has distinct workspaces
- Clear stale instances from gateway

---

## Advanced Configurations

### Docker Compose Example

```yaml
version: '3.8'

services:
  ani-code-gateway:
    image: ani-code-gateway:latest
    ports:
      - "6555:6555"
    environment:
      - NODE_ENV=production
      - PORT_API=6555
    networks:
      - ani-network

  ani-code-instance-1:
    image: ani-code:latest
    ports:
      - "6501:6501"
    environment:
      - GATEWAY_URL=http://ani-code-gateway:6555
      - ANI_CODE_URL=http://ani-code-instance-1:6501
      - ANI_CODE_DAEMON_PORT=6501
      - HTTP_CALLBACK_HOST=0.0.0.0
      - ANI_CODE_DUMMY_MODE=true
      - PROJECT_ID=project-a
      - WORKSPACE_ID=workspace-1
    volumes:
      - ./workspace1:/workspace
    networks:
      - ani-network

  ani-code-instance-2:
    image: ani-code:latest
    ports:
      - "6502:6501"
    environment:
      - GATEWAY_URL=http://ani-code-gateway:6555
      - ANI_CODE_URL=http://ani-code-instance-2:6501
      - ANI_CODE_DAEMON_PORT=6501
      - HTTP_CALLBACK_HOST=0.0.0.0
      - ANI_CODE_DUMMY_MODE=true
      - PROJECT_ID=project-b
      - WORKSPACE_ID=workspace-2
    volumes:
      - ./workspace2:/workspace
    networks:
      - ani-network

networks:
  ani-network:
    driver: bridge
```

### Kubernetes Example

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: ani-code-config
data:
  GATEWAY_URL: "http://ani-code-gateway:6555"
  ANI_CODE_DAEMON_PORT: "6501"
  HTTP_CALLBACK_HOST: "0.0.0.0"
  ANI_CODE_DUMMY_MODE: "true"

---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ani-code-instance
spec:
  replicas: 3
  selector:
    matchLabels:
      app: ani-code
  template:
    metadata:
      labels:
        app: ani-code
    spec:
      containers:
      - name: ani-code
        image: ani-code:latest
        ports:
        - containerPort: 6501
          name: http-api
        env:
        - name: POD_IP
          valueFrom:
            fieldRef:
              fieldPath: status.podIP
        - name: POD_NAME
          valueFrom:
            fieldRef:
              fieldPath: metadata.name
        - name: ANI_CODE_URL
          value: "http://$(POD_IP):6501"
        envFrom:
        - configMapRef:
            name: ani-code-config
        volumeMounts:
        - name: workspace
          mountPath: /workspace
      volumes:
      - name: workspace
        persistentVolumeClaim:
          claimName: ani-code-workspace

---
apiVersion: v1
kind: Service
metadata:
  name: ani-code-gateway
spec:
  selector:
    app: gateway
  ports:
  - port: 6555
    targetPort: 6555
  type: ClusterIP
```

---

## Summary

### Checklist for Gateway Integration

- [ ] Run `ani-code gateway config` to check current settings
- [ ] Set `GATEWAY_URL` pointing to gateway
- [ ] Set `ANI_CODE_URL` with your instance's accessible URL
- [ ] Verify `HTTP_CALLBACK_HOST=0.0.0.0` (default is correct)
- [ ] Port 6501 accessible from gateway
- [ ] Restart daemon
- [ ] Run `ani-code gateway status` to verify registration
- [ ] Run `ani-code gateway test` to test connectivity
- [ ] Verify heartbeat active in status output
- [ ] Generate workspace token
- [ ] Verify gateway token returned
- [ ] Test token with Telegram/API

### Key Takeaways

1. **Port 6501** is used for gateway registration and routing (not 6502)
2. **0.0.0.0 binding** is essential for gateway access (already default)
3. **Two tokens** are generated: workspace (direct) and gateway (routed)
4. **Heartbeat** keeps instance alive in gateway registry
5. **Dummy mode** allows operation without Telegram/Lark

### Getting Help

**Built-in Diagnostic Commands:**
```bash
ani-code gateway config   # Show configuration
ani-code gateway status   # Check registration status
ani-code gateway test     # Test connectivity
ani-code gateway --help   # Show all commands
```

**Manual Diagnostics:**
- Check logs: `journalctl -u ani-code -f`
- Gateway status: `curl http://gateway:6555/api/health`
- Instance health: `curl http://ani-code:6501/health`
- Debug mode: `LOG_LEVEL=debug`

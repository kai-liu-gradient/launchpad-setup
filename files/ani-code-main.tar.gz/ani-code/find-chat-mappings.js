#!/usr/bin/env node

import { WorkspaceManager } from './src/workspace-manager.js';

async function findChatMappings() {
  const manager = new WorkspaceManager();
  
  try {
    await manager.initialize();
    
    console.log('Checking chat-to-workspace mappings...\n');
    
    // Get chat to workspace mappings
    const mappings = await manager.getChatWorkspaceMappings();
    
    console.log('All chat-to-workspace mappings:');
    mappings.forEach(mapping => {
      console.log(`  Chat ID: ${mapping.chatId}`);
      console.log(`    Workspace: ${mapping.workspaceName} (${mapping.workspaceId})`);
      console.log(`    Path: ${mapping.workspacePath}`);
      console.log(`    Connected: ${mapping.connectedAt}`);
      console.log('');
    });
    
    // Find ani-code specific mappings
    const aniCodeMappings = mappings.filter(m => 
      m.workspaceName?.toLowerCase().includes('ani-code') || 
      m.workspacePath?.includes('ani-code')
    );
    
    if (aniCodeMappings.length > 0) {
      console.log('✅ Found chat IDs connected to ani-code workspace:');
      aniCodeMappings.forEach(mapping => {
        console.log(`   Chat ID: ${mapping.chatId}`);
        console.log(`   Connected at: ${mapping.connectedAt}`);
      });
      
      const latestChatId = aniCodeMappings[0].chatId;
      console.log('\n📝 To use this chat ID as default for error notifications:');
      console.log(`   Add to .env file:`);
      console.log(`   TELEGRAM_CHAT_ID=${latestChatId}`);
    } else {
      console.log('❌ No chat IDs found connected to ani-code workspace');
    }
    
    // Also check authorized Telegram chats
    console.log('\n\nAuthorized Telegram chats:');
    const authorizedChats = await manager.getAuthorizedTelegramChats();
    authorizedChats.forEach(chat => {
      console.log(`  Chat ID: ${chat.chatId}`);
      console.log(`    Username: ${chat.username || 'N/A'}`);
      console.log(`    First Name: ${chat.firstName || 'N/A'}`);
      console.log(`    Type: ${chat.chatType}`);
      console.log(`    Status: ${chat.status}`);
      console.log(`    Workspace: ${chat.workspaceName || 'Not connected'}`);
      console.log('');
    });
    
    await manager.close();
  } catch (error) {
    console.error('Error:', error);
    await manager.close();
  }
}

findChatMappings();
# Telegram Bot Setup Guide

This guide will help you set up the Telegram bot integration for ani-code.

## Prerequisites

- A Telegram account
- Access to @BotFather on Telegram

## Step 1: Create a Telegram Bot

1. Open Telegram and search for **@BotFather**
2. Start a conversation with BotFather
3. Send the command `/newbot`
4. Follow the prompts:
   - Choose a name for your bot (e.g., "AniCode Assistant")
   - Choose a username for your bot (must end with 'bot', e.g., `anicode_assistant_bot`)
5. BotFather will provide you with a **Bot Token** (looks like: `1234567890:ABCdefGHIjklMNOpqrsTUVwxyz`)
6. Save this token - you'll need it for configuration

## Step 2: Configure ani-code

Add the following to your `.env` file:

```bash
# Telegram Bot Configuration
TELEGRAM_BOT_TOKEN=your_bot_token_here
TELEGRAM_CHAT_ID=            # Optional: default chat ID for notifications
TELEGRAM_USE_WEBHOOK=false    # Set to true for webhook mode (requires HTTPS)
TELEGRAM_VERIFICATION_TOKEN=  # Optional: Security token for webhook
TELEGRAM_ALLOWED_CHATS=       # Optional: Comma-separated list of allowed chat/user IDs
TELEGRAM_WORKDIRS=            # Optional: same format as LARK_WORKDIRS (name:path,name2:path2)
```

### Configuration Options

- **TELEGRAM_BOT_TOKEN** (required): The token you received from BotFather
- **TELEGRAM_CHAT_ID** (optional): Default chat ID for notifications. You can get this later from the bot
- **TELEGRAM_USE_WEBHOOK**: 
  - `false` (default): Uses polling mode - easier for development, no HTTPS required
  - `true`: Uses webhook mode - better for production, requires HTTPS endpoint (webhook URL is auto-configured)
- **TELEGRAM_VERIFICATION_TOKEN**: Security token for webhook requests (recommended for production)
- **TELEGRAM_ALLOWED_CHATS**: Comma-separated list of allowed chat or user IDs (leave empty for token-based auth)
- **TELEGRAM_WORKDIRS**: Working directories available to the bot (inherits from LARK_WORKDIRS if not set)

## Step 3: Start the Bot

### Polling Mode (Recommended for Development)

1. Ensure `TELEGRAM_USE_WEBHOOK=false` in your `.env`
2. Restart the ani-code daemon:
   ```bash
   ani-code daemon --restart
   ```
3. The bot will automatically start polling for messages

### Webhook Mode (For Production)

1. Set `TELEGRAM_USE_WEBHOOK=true` in your `.env`
2. (Optional) Set `TELEGRAM_VERIFICATION_TOKEN` for webhook security:
   ```bash
   # Generate a secure token
   openssl rand -hex 32
   ```
3. Ensure your server is accessible via HTTPS on the configured port (default: 8080)
4. Restart the daemon:
   ```bash
   ani-code daemon --restart
   ```
5. The webhook will be automatically registered using your server's public IP or hostname
   - Default endpoint: `https://your-server:8080/callback/telegram`
   - If verification token is set, it will be: `https://your-server:8080/callback/telegram?token=YOUR_TOKEN`

#### Validating and Registering the Webhook

You can manually validate and register your webhook using the Telegram Bot API:

**Check current webhook status:**
```bash
curl https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getWebhookInfo
```

**Set webhook manually (if needed):**
```bash
# Without verification token
curl -X POST "https://api.telegram.org/bot<YOUR_BOT_TOKEN>/setWebhook" \
  -d "url=https://your-domain.com:8080/callback/telegram"

# With verification token
curl -X POST "https://api.telegram.org/bot<YOUR_BOT_TOKEN>/setWebhook" \
  -d "url=https://your-domain.com:8080/callback/telegram?token=YOUR_VERIFICATION_TOKEN"
```

**Delete webhook (to switch back to polling):**
```bash
curl -X POST "https://api.telegram.org/bot<YOUR_BOT_TOKEN>/deleteWebhook"
```

**Test webhook connectivity:**
```bash
# Test if your endpoint is reachable
curl -X POST https://your-domain.com:8080/callback/telegram \
  -H "Content-Type: application/json" \
  -d '{"test": true}'
```

## Step 4: Start Using the Bot

1. Find your bot on Telegram by searching for its username
2. Start a conversation with `/start` or `/help`
3. Available commands:

### Basic Commands
- `/start` or `/help` - Show help message and available commands
- `/status` - Show current running tasks
- `/workdir` - List available working directories
- `/workdir [name]` - Set the current working directory

### Task Management
- `/add [prompt]` - Create a new Claude task
- `/continue [prompt]` - Continue the previous Claude task
- `/shell [command]` - Run a shell command
- `/cancel [task_id]` - Cancel a running task

### Workspace Management
- `/connect [token]` - Connect this chat to a workspace using a token
- `/disconnect` - Disconnect from the current workspace

## Features

### Interactive Buttons
The bot provides interactive inline keyboards for common actions:
- Quick task creation
- Working directory selection
- Task retry and cancellation
- Git operations (commit, push, pull, etc.)

### Task Notifications
You'll receive real-time notifications for:
- Task started (with cancel button)
- Task completed (with retry button for failures)
- Task progress updates
- Cost and token usage information

### Smart Message Handling
- Non-command text shows an interactive menu
- Template-style prompts are automatically detected and simplified
- Shell command outputs are formatted nicely
- Long outputs are truncated intelligently

## Getting Your Chat ID

To get your Telegram chat ID (useful for default notifications):

1. Send any message to your bot
2. Check the daemon logs:
   ```bash
   ani-code daemon --logs | grep "Telegram message from chat"
   ```
3. You'll see your chat ID in the logs
4. Add it to `TELEGRAM_CHAT_ID` in your `.env` file

## Troubleshooting

### Bot Not Responding
- Check if the bot token is correct in `.env`
- Ensure the daemon is running: `ani-code daemon --status`
- Check logs: `ani-code daemon --logs`

### Webhook Issues
- Ensure your server has a valid SSL certificate
- Check webhook status: `curl https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getWebhookInfo`
- Verify the callback URL is accessible from the internet
- Check for SSL certificate issues in the webhook info response
- Common webhook error codes:
  - 403: Invalid token or IP restrictions
  - 404: Endpoint not found - check your port and path
  - 502/504: Server not responding - check if daemon is running
- Try switching to polling mode for testing

### Permission Issues
- Make sure the bot has been started (send `/start` to the bot)
- For group chats, ensure the bot is added as an admin

## Security and Access Control

### Authentication Methods

The bot supports multiple authentication methods:

1. **Token-based Authentication** (Recommended)
   - Generate workspace tokens using: `ani-code workspace token <workspace-name>`
   - Connect chats using: `/connect <token>`
   - Each chat connects to a specific workspace
   - Tokens can be revoked at any time

2. **Environment-based Allow List**
   - Set `TELEGRAM_ALLOWED_CHATS` with comma-separated chat/user IDs
   - Example: `TELEGRAM_ALLOWED_CHATS=123456789,987654321`
   - Good for small, fixed sets of users

3. **No Configuration = Deny by Default**
   - If no authentication is configured, all access is denied
   - Users must use `/connect <token>` to authenticate

### Workspace Token Management

Generate a token for a workspace:
```bash
# Create or use existing workspace
ani-code workspace create myproject /path/to/project

# Generate a token
ani-code workspace token myproject

# List all tokens
ani-code workspace tokens

# Revoke a token
ani-code workspace revoke-token <token-id>
```

### Security Best Practices

- **Keep your bot token secret** - anyone with the token can control your bot
- Consider using webhook mode with HTTPS in production
- **Use TELEGRAM_VERIFICATION_TOKEN** in webhook mode to prevent unauthorized requests
- Use token-based authentication for better access control
- Regularly review and revoke unused tokens
- Use working directory restrictions to limit file system access
- Each chat maintains its own session and workspace context

## Differences from Lark Bot

While the Telegram bot provides similar functionality to the Lark bot, there are some differences:

1. **Message Format**: Telegram uses Markdown instead of Lark's card format
2. **Buttons**: Inline keyboards instead of card actions
3. **File Handling**: No direct file uploads (coming in future updates)
4. **Authentication**: Uses bot token instead of app credentials
5. **Deployment**: Supports both polling and webhook modes

## Support

If you encounter issues or have questions:
1. Check the logs: `ani-code daemon --logs`
2. Report issues at: https://github.com/anthropics/claude-code/issues
3. Review the main documentation in README.md
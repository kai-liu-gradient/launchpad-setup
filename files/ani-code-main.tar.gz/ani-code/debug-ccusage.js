#!/usr/bin/env node
import { execSync } from 'child_process';

const today = new Date().toISOString().split('T')[0].replace(/-/g, '');

console.log('Test 1: With --since filter');
const cmd1 = `npx ccusage -j --offline --breakdown --since ${today}`;
const out1 = execSync(cmd1, { encoding: 'utf8' });
const data1 = JSON.parse(out1);

console.log('\nDaily data (first entry):');
if (data1.daily && data1.daily[0]) {
  console.log(JSON.stringify(data1.daily[0], null, 2));
}

console.log('\nTotals:');
console.log(JSON.stringify(data1.totals, null, 2));

console.log('\n\nTest 2: Without --since filter');
const cmd2 = `npx ccusage -j --offline --breakdown`;
const out2 = execSync(cmd2, { encoding: 'utf8' });
const data2 = JSON.parse(out2);

console.log('\nDaily data (first entry):');
if (data2.daily && data2.daily[0]) {
  console.log(JSON.stringify(data2.daily[0], null, 2));
}

console.log('\nTotals:');
console.log(JSON.stringify(data2.totals, null, 2));
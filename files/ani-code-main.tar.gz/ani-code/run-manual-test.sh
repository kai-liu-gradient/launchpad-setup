#!/bin/bash

# Script to run manual test files

if [ -z "$1" ]; then
    echo "Usage: ./run-manual-test.sh <test-name>"
    echo ""
    echo "Available tests:"
    ls tests/manual/test-*.js | sed 's|tests/manual/test-||g' | sed 's|.js||g' | sort
    exit 1
fi

TEST_FILE="tests/manual/test-$1.js"

if [ ! -f "$TEST_FILE" ]; then
    echo "Error: Test file '$TEST_FILE' not found"
    echo ""
    echo "Available tests:"
    ls tests/manual/test-*.js | sed 's|tests/manual/test-||g' | sed 's|.js||g' | sort
    exit 1
fi

echo "Running manual test: $1"
echo "========================="
node "$TEST_FILE"
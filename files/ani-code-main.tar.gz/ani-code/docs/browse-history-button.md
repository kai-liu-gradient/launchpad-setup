# Browse History Button Feature

## Overview

Task completion messages now include a **Browse History** button (📜 Browse) that generates an HTML export of **only that specific task's conversation**, filtered by the task's start and end time.

## How It Works

### 1. Task Completion Message

When a task completes successfully, the message includes three buttons:

```
✅ Task Completed Successfully

[📜 Browse] [💾 Commit] [🌐 Open]
```

### 2. Browse Button Behavior

When user clicks **📜 Browse**:

1. Bot sends: "Generating task history..."
2. Extracts task start/end times from callback data
3. Filters Claude Code session to that timeframe
4. Generates compact HTML with only relevant messages
5. Sends HTML file with metadata caption
6. Deletes loading message

### 3. Caption Metadata

```
TASK HISTORY

Project: ani-code
Time: 10:30:00 AM - 10:45:23 AM
Messages: 12
Tokens: 34,567

Download and open in browser.
```

## Implementation Details

### Button Data Structure

```javascript
{
  text: '📜 Browse',
  callback_data: JSON.stringify({
    a: 'history',      // action
    s: task.startedAt, // start time (milliseconds)
    e: task.completedAt || Date.now() // end time
  })
}
```

### Time Filtering

The `ClaudeHistoryViewer.generateFilteredHTML()` method:

1. Parses entire session JSONL file
2. Filters messages where `timestamp >= startTime && timestamp <= endTime`
3. Generates HTML with only filtered messages
4. Calculates tokens for filtered messages only

### Handler Flow

```javascript
case 'history': {
  // Extract times from callback
  const startTime = actionData.s;
  const endTime = actionData.e;

  // Generate filtered HTML
  const html = await viewer.generateFilteredHTML(
    projectPath,
    startTime,
    endTime
  );

  // Send with metadata caption
  await sendDocument(chatId, htmlFile, { caption });
}
```

## Advantages

### Focused Context
- Shows only messages related to that specific task
- Removes unrelated conversation
- Easier to review what happened during task execution

### Accurate Timeframe
- Uses actual task start/end timestamps
- Captures all assistant responses, tool calls, and results
- Includes thinking and token usage for that task

### Quick Access
- One-click from task completion message
- No need to remember task times
- Automatic filtering

## Example Scenarios

### Scenario 1: Debug Failed Task
```
Task: "Fix authentication bug"
Duration: 15 minutes
Messages: 23
Tokens: 45,000

Browse button shows:
- Initial prompt
- Claude's debugging steps
- Tool calls (Read, Edit)
- Error messages
- Fix attempts
- Final solution
```

### Scenario 2: Review API Implementation
```
Task: "Add /users endpoint"
Duration: 30 minutes
Messages: 45
Tokens: 78,000

Browse button shows:
- API design discussion
- Code generation
- File edits
- Testing steps
- Documentation updates
```

### Scenario 3: Compare Approaches
```
Multiple tasks for same feature:
- Task 1: First approach (failed)
- Task 2: Alternative approach (succeeded)

Each Browse button shows different conversation
User can compare what worked vs what didn't
```

## Technical Specifications

### Callback Data Limits
- Telegram limit: 64 bytes for callback_data
- Using shortened keys: `a`, `s`, `e`
- Timestamps as milliseconds (13 digits)
- Fits within limit: ~40 bytes

### Message Filtering
```javascript
const filteredMessages = allMessages.filter(msg =>
  msg.timestamp >= startTime && msg.timestamp <= endTime
);
```

### Time Precision
- Start time: `task.startedAt` (when task begins)
- End time: `task.completedAt || Date.now()` (when task finishes or current time)
- Millisecond precision for accurate filtering

## Files Modified

### 1. telegram-notifier.js
**Location:** `src/telegram-notifier.js:705-716`

Added Browse History button to success keyboards:
```javascript
if (task.startedAt) {
  const endTime = task.completedAt || Date.now();
  buttons.push({
    text: '📜 Browse',
    callback_data: JSON.stringify({
      a: 'history',
      s: task.startedAt,
      e: endTime
    })
  });
}
```

### 2. http-server.js
**Location:** `src/http-server.js:3907-4031`

Added `case 'history'` handler in `processCardAction()`:
- Extracts start/end times
- Generates filtered HTML
- Sends with task-specific caption
- Handles errors gracefully

**Location:** `src/http-server.js:6694-6704`

Added time parameters to callback normalization:
```javascript
s: action.s,  // Start time for history filtering
e: action.e   // End time for history filtering
```

### 3. claude-history-viewer.js
**Location:** `src/claude-history-viewer.js:453-495`

Added `generateFilteredHTML()` method:
```javascript
async generateFilteredHTML(projectPath, startTime, endTime) {
  const allMessages = await this.parseSession(sessionFile);
  const filteredMessages = allMessages.filter(msg =>
    msg.timestamp >= startTime && msg.timestamp <= endTime
  );
  return this.generateHTML(filteredMessages, sessionFile);
}
```

## Usage

### For Users

1. Run any Claude task (e.g., `/add Fix the login bug`)
2. Wait for task to complete
3. See completion message with Browse button
4. Click **📜 Browse**
5. Receive HTML file showing only that task's conversation
6. Download and open in browser

### For Developers

```javascript
// When creating task
const task = {
  startedAt: Date.now(),  // Record start time
  // ... other task properties
};

// When task completes
task.completedAt = Date.now();  // Record end time

// Button automatically added to completion message
// Clicking button triggers filtered history generation
```

## Benefits vs /history Command

| Feature | /history | Browse Button |
|---------|----------|---------------|
| Scope | Entire session | Single task only |
| Filtering | None (or manual args) | Automatic by task time |
| Context | Requires remembering when task ran | Embedded in completion message |
| Use case | Review full session | Review specific task |
| Messages | 300+ | 10-50 typically |
| Tokens | Full session total | Task-specific only |

## Error Handling

### No Messages in Timeframe
```
Error: No messages found in the specified time range
```
**Cause:** Task completed too quickly or timestamp mismatch
**Solution:** Use /history command instead for full session

### Session File Not Found
```
Error: No session file found
```
**Cause:** Project not in ~/.claude/projects/
**Solution:** Ensure working in tracked workspace

### Invalid Time Parameters
```
Error: Missing time parameters for history
```
**Cause:** Old task without startedAt timestamp
**Solution:** Button won't appear on old tasks

## Future Enhancements

### Potential Improvements
- [ ] Add "Download PDF" option
- [ ] Include file diffs in export
- [ ] Show before/after code comparison
- [ ] Add search within task history
- [ ] Link to related tasks
- [ ] Export to markdown format

## Conclusion

The Browse History button provides **focused, time-filtered HTML exports** of individual task conversations, making it easier to review, debug, and document specific Claude interactions without wading through the entire session history.

**Key advantages:**
- ✅ Task-specific filtering
- ✅ One-click access
- ✅ Compact, mobile-friendly HTML
- ✅ Accurate metadata (time, tokens, messages)
- ✅ No manual timestamp entry needed

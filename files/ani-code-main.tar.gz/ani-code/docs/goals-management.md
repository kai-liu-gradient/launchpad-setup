# Goal Management Commands

## Overview
The ani-code goals command now includes powerful management capabilities for automated goal execution and tracking.

## New Commands

### 1. `ani-code goals add [description]`
Add or update a goal with Claude's assistance.

**Options:**
- `-u, --update <goal-id>`: Update existing goal (ID or description)
- `-m, --merge`: Merge with existing goal content

**Examples:**
```bash
# Create new goal
ani-code goals add "Implement user authentication system"

# Update existing goal
ani-code goals add "Add OAuth support" -u 3

# Merge new requirements with existing goal
ani-code goals add "Add two-factor authentication" -u authentication -m
```

### 2. `ani-code goals check`
Check current goal completion status across all goals.

**Options:**
- `-v, --verbose`: Show detailed task breakdowns

**Examples:**
```bash
# Quick status overview
ani-code goals check

# Detailed breakdown with task lists
ani-code goals check -v
```

**Output includes:**
- Overall progress percentage
- Task completion statistics
- Goal status distribution
- Suggested next actions
- Visual progress bars

### 3. `ani-code goals loop`
Automated goal execution loop - reads PRD, implements tasks, and updates progress.

**Options:**
- `-g, --goal <id>`: Focus on specific goal (ID or description)
- `-l, --limit <n>`: Limit number of iterations (default: 5)
- `-s, --skip-validation`: Skip implementation validation

**Examples:**
```bash
# Execute automated implementation
ani-code goals loop

# Focus on specific goal
ani-code goals loop -g 3
ani-code goals loop -g "authentication"

# Run more iterations
ani-code goals loop -l 10

# Skip validation for faster execution
ani-code goals loop -s
```

## Workflow Integration

### Typical Development Flow

1. **Create goals from requirements:**
   ```bash
   ani-code goals add "Implement core API endpoints"
   ```

2. **Check current status:**
   ```bash
   ani-code goals check -v
   ```

3. **Execute automated implementation:**
   ```bash
   ani-code goals loop
   ```

4. **Review progress:**
   ```bash
   ani-code goals progress
   ```

### Automated Goal Execution

The `loop` command provides fully automated implementation:

1. **Reads project PRD** from `pd/prd.md`
2. **Selects appropriate goals** (in-progress or not-started)
3. **Implements tasks** autonomously
4. **Updates goal files** with progress
5. **Validates implementation** (optional)
6. **Documents changes** and blockers

### Key Features

- **Autonomous decision making**: No user interaction required
- **Smart goal selection**: Prioritizes in-progress goals
- **UI Kit integration**: Uses ani-uikit components when available
- **Service auto-reload**: No manual restarts needed
- **Progress tracking**: Real-time updates to goal files
- **Error handling**: Documents blockers in goal notes

### Best Practices

1. **Maintain clear PRD**: Keep `pd/prd.md` updated with requirements
2. **Break down tasks**: Use specific, measurable tasks in goals
3. **Set realistic iterations**: Start with 5 iterations, increase as needed
4. **Review after automation**: Check implemented changes
5. **Document blockers**: Review Progress notes for issues

## Integration with CLAUDE.md

The goal management system follows all standards defined in CLAUDE.md:

- **Version management**: Updates trigger version increments
- **No service restarts**: Respects auto-reload configuration
- **Documentation**: Updates `pd/` folder as needed
- **Validation**: Runs syntax checks without restarts
- **Autonomous operation**: Makes decisions without user prompts

## Goal File Format

Goals follow this structure:
```markdown
# Goal: [Clear name]

## Objective
[2-3 sentences describing the goal]

## Tasks
- [ ] Task 1
- [x] Task 2 (completed)
- [ ] Task 3

## Acceptance Criteria
- Criteria 1
- Criteria 2

## Progress
- Status: **In Progress**
- Start Date: 2025-11-06
- Completion Date: -
- Notes: Implementation notes

## Dependencies
- Goal 1: Foundation setup
```

## Status Management

Goals can have these statuses:
- **Not Started**: No tasks completed
- **In Progress**: Some tasks completed
- **Completed**: All tasks done
- **Abandoned**: Manually set
- **Cancelled**: Manually set
- **On Hold**: Manually set

Status is auto-calculated from task completion unless manually overridden.

## Cache System

The goals system uses workspace-aware caching:
- Cache stored in workspace metadata
- Auto-sync when files change
- Manual refresh with `--refresh` flag
- Fallback to `.ani-code/goals-cache.json`

## Error Handling

The system handles various scenarios:
- **Missing PRD**: Continues with goals only
- **No goals directory**: Creates automatically
- **Timeout during implementation**: Continues to next iteration
- **Service errors**: Documents in goal notes
- **Validation failures**: Attempts fixes in next iteration

## Performance Tips

1. **Use specific goal targeting**: `-g <id>` for focused work
2. **Skip validation**: `-s` flag for faster execution
3. **Limit iterations**: Start small, increase as needed
4. **Keep PRD concise**: Faster parsing and understanding
5. **Clear task definitions**: Easier automated implementation

## Telegram Bot Integration

The goal management commands are fully integrated with the Telegram bot for remote management.

### Telegram Commands

#### `/goals` - List and view goals
```bash
/goals          # List all goals
/goals show 3   # Show details of goal 3
```

#### `/goaladd <description>` - Create new goal
```bash
/goaladd Implement user authentication system
/goaladd Add payment processing with Stripe
```

#### `/goalcheck` - Check completion status
Shows visual progress with statistics:
- Overall progress percentage
- Task completion counts
- Goal status distribution
- Progress bar visualization

#### `/goalloop [options]` - Run automation loop
```bash
/goalloop              # Run default 5 iterations
/goalloop 3            # Focus on goal 3
/goalloop limit 10     # Run 10 iterations
/goalloop "auth" skip  # Work on auth goal, skip validation
```

### Telegram Features

- **Visual Progress Bars**: See completion at a glance
- **Interactive Buttons**: Watch task progress in real-time
- **Workspace Aware**: Works with selected workspace
- **Task Monitoring**: Track Claude's implementation
- **Error Handling**: Clear error messages and recovery

### Remote Workflow

1. **Check status from anywhere:**
   ```
   /goalcheck
   ```

2. **Add goals on the go:**
   ```
   /goaladd Fix critical bug in payment system
   ```

3. **Start automation remotely:**
   ```
   /goalloop
   ```

4. **Monitor progress:**
   Click "Watch Progress" button or use `/process <task-id>`

### Telegram Bot Setup

1. **Connect workspace:**
   ```
   /connect <workspace-token>
   ```

2. **Select working directory:**
   ```
   /workdir <name>
   ```

3. **Start using goal commands:**
   ```
   /goals
   /goalcheck
   ```

### Telegram Advantages

- **Remote Access**: Manage goals from mobile
- **Push Notifications**: Get updates on completion
- **Quick Actions**: Interactive buttons for common tasks
- **Multi-Workspace**: Switch between projects easily
- **Team Collaboration**: Share bot with team members
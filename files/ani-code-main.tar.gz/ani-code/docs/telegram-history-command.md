# Telegram /history Command

## Overview

The `/history` command generates a professional HTML view of your latest Claude Code session and sends it to you via Telegram. The HTML file can be opened in any web browser to review the complete conversation.

## Features

### Professional UI
- **Gradient header** with session metadata
- **Responsive design** for mobile and desktop
- **Color-coded messages** (user, assistant, tool results)
- **Smooth animations** for better UX

### Content Display
- **User messages** with timestamps
- **Assistant responses** including:
  - Text content with basic markdown formatting
  - Extended thinking (collapsible)
  - Tool calls (collapsible with JSON formatting)
  - Token usage statistics (input, output, cache)
- **Tool results** displayed separately

### Design Inspiration
Based on research of open-source Claude Code history viewers:
- **clog** (HillviewCap/clog) - Web-based viewer with real-time monitoring
- **claude-code-log** (daaain/claude-code-log) - Python CLI tool for HTML conversion
- **claude-code-viewer** (d-kimuson) - Full-featured web client

## Usage

### Basic Command
```
/history
```

This will:
1. Find the latest Claude Code session for the current project
2. Parse the JSONL conversation log
3. Generate a professional HTML file
4. Send it to you via Telegram as a document

### Expected Output

**Message from bot:**
```
⏳ Generating session history HTML...

This may take a moment.
```

**Delivered file:**
```
📊 Claude Code Session History

Download and open this HTML file in your browser to view the conversation.

📎 claude-history-1234567890.html
```

## Implementation Details

### File Locations
- **Module**: `src/claude-history-viewer.js`
- **Integration**: `src/http-server.js` (command handler)
- **Help text**: `src/telegram-notifier.js`
- **Test**: `tests/manual/test-history-command.js`

### How It Works

1. **Session Discovery**
   - Looks in `~/.claude/projects/[encoded-path]/`
   - Finds most recently modified `.jsonl` file
   - Path encoding: `/root/workspace/ani-code` → `-root-workspace-ani-code`

2. **JSONL Parsing**
   - Reads line-by-line JSON entries
   - Extracts user messages, assistant responses, and tool results
   - Preserves timestamps, token usage, and metadata

3. **HTML Generation**
   - Professional CSS with gradient backgrounds
   - Responsive design (mobile/desktop)
   - Collapsible sections for thinking and tool calls
   - Token usage visualization
   - Markdown formatting for text content

4. **Delivery**
   - Saves HTML to `/tmp/claude-history-{timestamp}.html`
   - Sends via Telegram as document
   - Cleans up temp file after sending

### Supported Message Types
- ✅ User text messages
- ✅ Assistant text responses
- ✅ Extended thinking blocks
- ✅ Tool use calls (Read, Write, Edit, Bash, etc.)
- ✅ Tool results
- ✅ Token usage statistics
- ✅ Timestamps

### Markdown Features
- **Bold** (`**text**`)
- *Italic* (`*text*`)
- `Inline code` (\`code\`)
- Code blocks (```language```)
- [Links](url)

## Testing

### Manual Test
```bash
node tests/manual/test-history-command.js
```

**Expected output:**
```
Testing Claude History Viewer...

1. Finding latest session...
✅ Found session: /root/.claude/projects/-root-workspace-ani-code/5178a038-8d17-402d-aa09-97a4b9c84e30.jsonl

2. Parsing session...
✅ Parsed 157 messages

3. First 3 messages:
[...]

4. Generating HTML...
✅ Generated HTML (151633 bytes)

✅ Saved to: /tmp/test-claude-history.html
```

### Telegram Test
1. Open Telegram and message your bot
2. Send: `/history`
3. Wait for HTML document
4. Download and open in browser
5. Verify:
   - All messages display correctly
   - Timestamps are accurate
   - Token usage shows correctly
   - Collapsible sections work
   - Mobile/desktop responsive

## Styling Details

### Color Scheme
- **Primary gradient**: Purple (#667eea) to Dark Purple (#764ba2)
- **User messages**: Light blue background (#f0f7ff)
- **Assistant messages**: Light gray background (#f9fafb)
- **Tool results**: Light yellow background (#fffbeb)

### Typography
- **Font family**: System fonts (San Francisco, Segoe UI, Roboto)
- **Code font**: SF Mono, Monaco, Consolas (monospace)
- **Base size**: 16px with 1.6 line height

### Interactive Elements
- **Hover effects** on collapsible sections
- **Smooth transitions** for expand/collapse
- **Custom scrollbar** styling
- **Fade-in animations** for messages

## Error Handling

### No Session Found
```
❌ Error generating session history. Please try again later.

Error: No session file found
```

### Parse Error
```
❌ Error generating session history. Please try again later.

Error: Failed to parse session
```

### File Send Error
```
❌ Error generating session history. Please try again later.

Error: Failed to send document
```

## Future Enhancements

### Potential Features
- [ ] Filter by date range
- [ ] Search within conversation
- [ ] Export to Markdown
- [ ] Include file changes/diffs
- [ ] Session comparison
- [ ] Token cost estimation
- [ ] Theme customization (dark mode)

### Performance Optimizations
- [ ] Streaming for large sessions
- [ ] Pagination for very long conversations
- [ ] Client-side search/filter
- [ ] Lazy loading of tool results

## Related Commands

- `/status` - Show running tasks
- `/usage` - Check Claude API usage
- `/rank` - Show daily usage report
- `/daystat` - Show 24-hour statistics

## Credits

Inspired by these open-source projects:
- [clog](https://github.com/HillviewCap/clog) by HillviewCap
- [claude-code-log](https://github.com/daaain/claude-code-log) by daaain
- [claude-code-viewer](https://github.com/d-kimuson/claude-code-viewer) by d-kimuson
- [cclogviewer](https://github.com/Brads3290/cclogviewer) by Brads3290

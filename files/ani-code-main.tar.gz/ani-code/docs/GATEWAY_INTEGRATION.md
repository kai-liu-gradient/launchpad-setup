# Gateway Integration Guide

## Overview

Ani-code can operate in **gateway mode**, allowing centralized routing and management of multiple ani-code instances through a gateway service. This enables scalability, load balancing, and unified authentication for multi-platform bot deployments.

## Architecture

```
┌─────────────┐          ┌──────────────┐          ┌──────────────┐
│  Telegram   │          │              │          │  Ani-Code    │
│   /Lark     │─────────▶│   Gateway    │─────────▶│  Instance 1  │
│  Webhooks   │          │              │          └──────────────┘
└─────────────┘          │              │          ┌──────────────┐
                         │  - Routes    │─────────▶│  Ani-Code    │
                         │  - Auth      │          │  Instance 2  │
                         │  - Load Bal  │          └──────────────┘
                         └──────────────┘                 │
                                ▲                         │
                                └─────────────────────────┘
                                    Callback Messages
```

## How It Works

### 1. Request Flow (Incoming Webhooks)

1. **Gateway receives webhook** from Telegram/Lark
2. **Gateway validates user** against authorized users list
3. **Gateway routes to appropriate instance** based on workspace/user mapping
4. **Gateway forwards request** with trust headers:
   - `x-gateway-token`: Authentication token
   - `x-gateway-url`: Gateway base URL
   - `x-original-chat`: Original chat ID
   - `x-original-user`: Original user ID
   - `x-original-platform`: Source platform (telegram/lark)

### 2. Response Flow (Outgoing Messages)

1. **Ani-code processes request** (trusts gateway via header validation)
2. **Ani-code sends response to gateway** callback endpoint
3. **Gateway routes response** to correct platform API
4. **Gateway delivers message** to user via Telegram/Lark

### 3. Instance Registration

On startup, each ani-code instance:
1. Registers with gateway at `/api/instances/register`
2. Provides capabilities (telegram, lark, cli)
3. Provides endpoint URL for request routing
4. Provides version and workspace information

## Configuration

### Environment Variables

```bash
# Gateway Mode Configuration
GATEWAY_URL=http://gateway:6555          # Gateway base URL
GATEWAY_TOKEN=your-secure-token          # Authentication token
INSTANCE_ID=ani-code-instance-1          # Unique instance identifier
GATEWAY_REGISTER=true                    # Auto-register on startup (default: true)

# Existing Configuration (still required)
TELEGRAM_BOT_TOKEN=your-bot-token        # For direct API fallback
LARK_APP_ID=your-app-id                  # For direct API fallback
# ... other config vars
```

### Configuration Object

```javascript
// src/config.js
gateway: {
  enabled: process.env.GATEWAY_URL ? true : false,
  url: process.env.GATEWAY_URL,
  token: process.env.GATEWAY_TOKEN || process.env.GATEWAY_API_KEY,
  instanceId: process.env.INSTANCE_ID || os.hostname(),
  registerOnStartup: process.env.GATEWAY_REGISTER !== 'false'
}
```

## Gateway Trust Authentication

### Authorization Bypass

When in gateway mode, ani-code **trusts the gateway** to validate users. The `checkTelegramAuthorization()` method bypasses normal user validation when:

1. Gateway mode is enabled (`config.gateway.enabled === true`)
2. Request contains valid `x-gateway-token` header
3. Request contains valid `x-gateway-url` header
4. Both headers match configured gateway credentials

```javascript
// src/http-server.js
async checkTelegramAuthorization(chatId, userId, request = null) {
  // Gateway trust bypass - MUST BE FIRST
  if (config.gateway.enabled && request?.headers) {
    const gatewayToken = request.headers['x-gateway-token'];
    const gatewayUrl = request.headers['x-gateway-url'];

    if (gatewayToken === config.gateway.token &&
        gatewayUrl === config.gateway.url) {
      logger.info(`✓ Gateway trust auth bypass for chat ${chatId}`);
      return true; // TRUST THE GATEWAY
    }
  }

  // Continue with normal auth checks...
}
```

### Security Considerations

- **Token Security**: Use strong, randomly generated tokens
- **Token Rotation**: Rotate gateway tokens periodically
- **Network Security**: Gateway and instances should communicate over private network
- **Audit Logging**: All gateway trust events are logged for auditing
- **Fallback**: If gateway fails, instances fall back to direct API calls

## Callback Routing

### Message Routing

All outgoing messages are routed through gateway when in gateway mode:

```javascript
// src/telegram-notifier.js
async sendMessage(chatId, text, options = {}) {
  // Route through gateway if in gateway mode
  if (config.gateway.enabled) {
    return this.sendViaGateway('telegram', chatId, text, options);
  }

  // Direct send (existing code)
  return this.api.sendMessage(chatId, text, options);
}
```

### Gateway Callback Endpoint

**Endpoint**: `POST /api/callback/message`

**Headers**:
- `Content-Type: application/json`
- `x-instance-id: <instance-id>`
- `x-gateway-token: <token>`

**Payload**:
```json
{
  "platform": "telegram",
  "chatId": "123456789",
  "message": {
    "text": "Message content",
    "parse_mode": "Markdown",
    "messageId": "456",
    "action": "edit"
  },
  "instanceId": "ani-code-instance-1",
  "timestamp": "2025-01-01T12:00:00.000Z"
}
```

### Fallback Behavior

If gateway callback fails:
1. Log error with context
2. **Fallback to direct API call** (requires bot token/credentials)
3. Continue operation (graceful degradation)

## Instance Registration

### Registration Endpoint

**Endpoint**: `POST /api/instances/register`

**Headers**:
- `Content-Type: application/json`
- `x-gateway-token: <token>`

**Payload**:
```json
{
  "instanceId": "ani-code-instance-1",
  "token": "instance-specific-token",
  "capabilities": ["telegram", "lark", "cli"],
  "endpoint": "http://ani-code-instance-1:6501",
  "version": "2.0.0",
  "workspaces": ["workspace1", "workspace2"],
  "hostname": "ani-code-instance-1"
}
```

**Response**:
```json
{
  "registered": true,
  "instanceId": "ani-code-instance-1",
  "message": "Instance registered successfully"
}
```

### Registration Lifecycle

1. **Startup**: Instance registers with gateway
2. **Heartbeat** (future): Periodic health checks
3. **Shutdown**: Instance deregisters (future)

### Registration Failure Handling

- Registration failures **do not crash the daemon**
- Instance continues in "direct mode" without gateway
- Warning logged for operational visibility
- Gateway can discover instances via other means

## Testing

### Manual Testing

#### 1. Start Gateway
```bash
cd ani-code-gateway
npm start
```

#### 2. Configure Instance
```bash
cd ani-code
cat > .env <<EOF
GATEWAY_URL=http://localhost:6555
GATEWAY_TOKEN=test-secure-token
INSTANCE_ID=test-instance-1
TELEGRAM_BOT_TOKEN=your-bot-token
EOF
```

#### 3. Start Instance
```bash
npm run daemon:start
```

#### 4. Verify Registration
```bash
# Check gateway logs for registration
curl http://localhost:6555/api/instances
```

#### 5. Send Test Message
```bash
# Send message via gateway
curl -X POST http://localhost:6555/api/webhook/telegram \
  -H "Content-Type: application/json" \
  -d '{
    "message": {
      "chat": {"id": 123456},
      "from": {"id": 123456},
      "text": "/status"
    }
  }'
```

### Automated Tests

Run the test suite:
```bash
npm test -- tests/gateway-*.test.js
```

Test coverage:
- Gateway trust authentication
- Callback routing
- Instance registration
- Fallback behavior
- Error handling

## Deployment

### Docker Compose

```yaml
version: '3.8'

services:
  gateway:
    image: ani-code-gateway:latest
    ports:
      - "6555:6555"
    environment:
      - GATEWAY_TOKEN=secure-random-token
      - PORT=6555
    networks:
      - ani-network

  ani-code-1:
    image: ani-code:latest
    environment:
      - GATEWAY_URL=http://gateway:6555
      - GATEWAY_TOKEN=secure-random-token
      - INSTANCE_ID=ani-code-1
      - TELEGRAM_BOT_TOKEN=${TELEGRAM_BOT_TOKEN}
    networks:
      - ani-network
    depends_on:
      - gateway

  ani-code-2:
    image: ani-code:latest
    environment:
      - GATEWAY_URL=http://gateway:6555
      - GATEWAY_TOKEN=secure-random-token
      - INSTANCE_ID=ani-code-2
      - TELEGRAM_BOT_TOKEN=${TELEGRAM_BOT_TOKEN}
    networks:
      - ani-network
    depends_on:
      - gateway

networks:
  ani-network:
    driver: bridge
```

### Kubernetes

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: gateway-config
data:
  GATEWAY_TOKEN: "secure-random-token"
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ani-code-gateway
spec:
  replicas: 1
  selector:
    matchLabels:
      app: gateway
  template:
    metadata:
      labels:
        app: gateway
    spec:
      containers:
      - name: gateway
        image: ani-code-gateway:latest
        ports:
        - containerPort: 6555
        env:
        - name: GATEWAY_TOKEN
          valueFrom:
            configMapKeyRef:
              name: gateway-config
              key: GATEWAY_TOKEN
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ani-code-instances
spec:
  replicas: 2
  selector:
    matchLabels:
      app: ani-code
  template:
    metadata:
      labels:
        app: ani-code
    spec:
      containers:
      - name: ani-code
        image: ani-code:latest
        env:
        - name: GATEWAY_URL
          value: "http://ani-code-gateway:6555"
        - name: GATEWAY_TOKEN
          valueFrom:
            configMapKeyRef:
              name: gateway-config
              key: GATEWAY_TOKEN
        - name: INSTANCE_ID
          valueFrom:
            fieldRef:
              fieldPath: metadata.name
        - name: TELEGRAM_BOT_TOKEN
          valueFrom:
            secretKeyRef:
              name: telegram-secret
              key: bot-token
```

## Monitoring

### Health Checks

```bash
# Gateway health
curl http://gateway:6555/health

# Instance health
curl http://ani-code-1:6501/health
```

### Metrics

- Instance registration count
- Request routing latency
- Callback success/failure rate
- Fallback activation count
- Authentication bypass events

### Logs

Key log patterns to monitor:
- `✓ Gateway trust auth bypass` - Successful gateway auth
- `✗ Invalid gateway auth attempt` - Failed gateway auth (potential security issue)
- `✓ Successfully registered with gateway` - Instance registered
- `✗ Gateway registration failed` - Registration failure
- `⚠️  Falling back to direct send` - Gateway callback failed, using fallback

## Troubleshooting

### Instance Not Registering

**Problem**: Instance starts but doesn't register with gateway

**Solutions**:
1. Check `GATEWAY_URL` is accessible from instance
2. Verify `GATEWAY_TOKEN` matches on both sides
3. Check gateway logs for registration errors
4. Ensure `GATEWAY_REGISTER=true` (default)

### Messages Not Being Delivered

**Problem**: Commands sent but no response

**Solutions**:
1. Check gateway logs for routing errors
2. Verify instance endpoint is accessible from gateway
3. Check gateway trust headers are being sent
4. Verify bot token is configured (for fallback)

### Gateway Auth Failures

**Problem**: `✗ Invalid gateway auth attempt` in logs

**Solutions**:
1. Verify `GATEWAY_TOKEN` matches on gateway and instance
2. Verify `GATEWAY_URL` matches exactly (including protocol, port)
3. Check request headers are being forwarded correctly
4. Ensure no middleware is stripping headers

### Fallback Not Working

**Problem**: Gateway fails but direct send also fails

**Solutions**:
1. Ensure `TELEGRAM_BOT_TOKEN` or `LARK_APP_ID` is configured
2. Verify bot credentials are valid
3. Check network access to Telegram/Lark APIs
4. Review error logs for specific API failures

## Backward Compatibility

Gateway mode is **fully backward compatible**:

- If `GATEWAY_URL` is not set, ani-code runs in **direct mode** (current behavior)
- Existing configurations continue to work without changes
- Gateway mode is **opt-in** via environment variables
- No breaking changes to existing APIs or behavior

## Migration Guide

### From Direct Mode to Gateway Mode

1. **Deploy Gateway**:
   ```bash
   cd ani-code-gateway
   npm install
   npm start
   ```

2. **Update Instance Configuration**:
   ```bash
   # Add to .env
   GATEWAY_URL=http://gateway:6555
   GATEWAY_TOKEN=secure-random-token
   INSTANCE_ID=unique-instance-id
   ```

3. **Restart Instance**:
   ```bash
   ani-code daemon restart
   ```

4. **Verify Registration**:
   ```bash
   # Check instance logs
   ani-code daemon logs | grep "Successfully registered"
   ```

5. **Test Functionality**:
   - Send test command via gateway webhook
   - Verify response is delivered
   - Check logs for gateway trust events

### Rolling Update

For zero-downtime migration:

1. Deploy gateway alongside existing instances
2. Update instances one by one
3. Monitor logs for successful registration
4. Verify functionality for each instance
5. Update webhook URLs to gateway after all instances migrated

## API Reference

### Gateway Headers

| Header | Description | Example |
|--------|-------------|---------|
| `x-gateway-token` | Authentication token | `secure-token-123` |
| `x-gateway-url` | Gateway base URL | `http://gateway:6555` |
| `x-original-chat` | Original chat ID | `123456789` |
| `x-original-user` | Original user ID | `987654321` |
| `x-original-platform` | Source platform | `telegram` or `lark` |
| `x-instance-id` | Instance identifier (callbacks) | `ani-code-1` |

### Gateway Endpoints

#### Register Instance
- **Method**: `POST`
- **Path**: `/api/instances/register`
- **Auth**: `x-gateway-token` header
- **Payload**: Instance registration data
- **Response**: Registration confirmation

#### Callback Message
- **Method**: `POST`
- **Path**: `/api/callback/message`
- **Auth**: `x-gateway-token` header
- **Payload**: Message data with platform info
- **Response**: Delivery confirmation

## Support

For issues, questions, or contributions:
- GitHub Issues: https://github.com/anthropics/ani-code/issues
- Gateway Repository: https://github.com/yourusername/ani-code-gateway
- Documentation: https://github.com/anthropics/ani-code/tree/master/docs

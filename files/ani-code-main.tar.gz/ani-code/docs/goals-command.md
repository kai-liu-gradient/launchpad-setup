# Goals Command Documentation

The `ani-code goals` command provides comprehensive project goal management capabilities, allowing you to track progress, analyze goals, and export data in structured formats.

## Overview

The goals command uses Claude AI to analyze markdown files in your project's goals directory (default: `pd/goals/`) and provides insights into project progress, task completion, and goal status.

**Key Features:**
- **AI-Powered Analysis**: Uses Claude to parse and understand goal files
- **Cached Performance**: Reads from structured cache for fast responses
- **Automatic Refresh**: Detects when source files change
- **Multiple Views**: List, detail, progress, and export formats

## Command Structure

```bash
ani-code goals [options] [command]
```

### Global Options

- `-d, --dir <directory>` - Specify goals directory (default: `pd/goals`)
- `-h, --help` - Display help information

## Subcommands

### 1. Sync Goals (`sync` or `refresh`)

Analyze goal markdown files with Claude and update the cache.

```bash
ani-code goals sync              # Incremental (skip completed goals)
ani-code goals sync --full       # Full resync (analyze all goals)
ani-code goals sync --no-fix     # Skip Phase 2 auto-fix (report issues only)
ani-code goals sync --fast       # Fast mode (skip fix + reuse cached completed goals)
ani-code goals refresh           # Alias for sync
```

**Options:**
- `--full` - Force full resync, analyze all goals including completed ones
- `--no-fix` - Skip Phase 2 auto-fix; validation errors are logged but not repaired
- `--fast` - Reuse cached completed goals even if files changed and skip auto-fix (implies `--no-fix`)

**What it does:**

**Phase 1: Initial Analysis**
- Finds all `.md` files in goals directory
- Sends file paths to Claude (not content - efficient!)
- **Claude can organize/rename files first** (optional - makes it tidy!)
- Claude reads each file using Read tool
- Parses structure, tasks, progress, dependencies
- Calculates completion percentages
- Saves to workspace metadata database

**Phase 2: Validation & Correction**
- Claude loads the cache it just created
- Spot-checks 10-20% of goals (random sample)
- Validates task counts and status calculations
- Fixes any errors found
- Verifies overall statistics
- Saves corrected cache back to metadata

**Incremental Sync (Default):**
- Checks existing cache for completed goals
- Skips completed goals if file hasn't changed
- Only analyzes new/modified/incomplete goals
- Merges results with cached completed goals
- Much faster for large projects (90+ goals)

**Why Two Phases?**
- Self-validation catches parsing errors
- Status calculation verified (100% tasks = Completed)
- Statistics double-checked for accuracy
- More reliable with large goal sets (90+ files)

**When to Use `--full`:**
- First time running sync
- After major goal file reorganization
- When you suspect cache is corrupted
- To force re-analysis of all goals

**Claude's Freedom:**
Claude is empowered to:
- Rename files for better conventions (e.g., 001-foundation.md)
- Fix markdown formatting issues
- Standardize naming patterns
- Reorganize file structure
- Clean up messy formatting

**When to use:**
- After creating new goal files
- After updating goal content
- When cache shows outdated warning
- To get Claude's fresh analysis

**Output (Incremental Sync):**
```
🔄 Analyzing goal files with Claude...

✓ Skipping 45 completed goals (unchanged)
  Analyzing 45 goals

Analyzing 45 goal file(s)...
Merging with 45 completed goal(s)...
This may take a moment...

Phase 1: Initial analysis...
⏳ Waiting for Claude to analyze goals...
  Still working... (0m 40s)
✓ Phase 1 complete
  Analyzed: 45 files
  Merged: 45 completed goals

Phase 2: Validation & correction...
⏳ Validating and correcting...
✓ Phase 2 complete

Saving to workspace metadata...
✓ Goals cache updated successfully
  Location: workspace metadata (ani-launchpad)
  Total goals: 90
  Newly analyzed: 45
  Skipped (completed): 45
  Validation: passed
```

**Output (Full Resync with `--full`):**
```
🔄 Analyzing goal files with Claude...

Analyzing 90 goal file(s)...
This may take a moment...

Phase 1: Initial analysis...
⏳ Waiting for Claude to analyze goals...
✓ Phase 1 complete
  Analyzed: 90 files

Phase 2: Validation & correction...
✓ Phase 2 complete

✓ Goals cache updated successfully
  Location: workspace metadata (ani-launchpad)
  Total goals: 90
  Newly analyzed: 90
  Validation: passed
```

### 2. List Goals (`list` or `ls`)

Display a summary of all goals with key metrics (reads from cache).

```bash
ani-code goals list
ani-code goals ls
ani-code goals list --refresh  # Force refresh from source files
```

**Options:**
- `-r, --refresh` - Skip cache and parse source files directly

**Output includes:**
- Overall summary statistics
- Total goals count
- Status breakdown (Not Started, In Progress, Completed)
- Overall progress percentage
- Individual goal summaries with:
  - Goal title
  - Current status
  - Task completion percentage
  - Objective preview
  - Source filename

**Example Output:**
```
📊 Goals Summary

Total Goals: 3
Not Started: 1
In Progress: 2
Completed: 0

Overall Progress: 0%
──────────────────────────────────────────────────

📋 Goals List

[1] Foundation Setup
Status: In Progress
Tasks: 3/5 (60%)
Objective: Set up the initial project infrastructure...
File: 001-foundation.md
```

### 2. Show Goal Details (`show` or `view`)

Display comprehensive information about a specific goal.

```bash
ani-code goals show <goal-id>
ani-code goals view <goal-id>
```

**Arguments:**
- `<goal-id>` - Goal identifier (index number or filename)
  - Index: `1`, `2`, `3`, etc.
  - Filename: `001-foundation.md` or `001-foundation`

**Output includes:**
- Goal title
- Current status
- Source filename
- Objective description
- Complete task list with checkboxes
- Task completion statistics
- Acceptance criteria
- Dependencies
- Progress details (start date, completion date, notes)

**Example:**
```bash
ani-code goals show 1
ani-code goals show 001-foundation.md
```

**Example Output:**
```
📌 Foundation Setup

Status: In Progress
File: 001-foundation.md

Objective:
Set up the initial project infrastructure including directory structure...

Tasks:
  ✓ Create project directory structure
  ✓ Initialize git repository
  ✓ Set up .gitignore file
  ☐ Configure ESLint and Prettier
  ☐ Set up testing framework

  Progress: 3/5 tasks (60%)

Acceptance Criteria:
  • Project structure follows standard conventions
  • All configuration files are properly set up
  • Development environment is ready for coding

Dependencies:
  • None - this is the first goal

Progress Details:
  Start Date: 2025-01-15
  Completion Date: -
  Notes: Basic setup complete, need to finalize linting configuration
```

### 3. Show Progress (`progress` or `status`)

Display visual progress statistics for all goals.

```bash
ani-code goals progress
ani-code goals status
```

**Output includes:**
- Overall summary statistics
- Visual progress bars for each goal
- Task completion counts
- Status indicators (emoji)
- Start and completion dates

**Example Output:**
```
📊 Goals Summary

Total Goals: 3
Not Started: 1
In Progress: 2
Completed: 0

Overall Progress: 0%
──────────────────────────────────────────────────

📈 Detailed Progress

🔄 Foundation Setup
   [████████████░░░░░░░░] 60%
   3/5 tasks
   Started: 2025-01-15

🔄 Core Features Implementation
   [███████░░░░░░░░░░░░░] 33%
   2/6 tasks
   Started: 2025-01-20

⏸️ Testing & Quality Assurance
   [░░░░░░░░░░░░░░░░░░░░] 0%
   0/5 tasks
```

**Status Emojis:**
- ✅ Completed
- 🔄 In Progress
- ⏸️ Not Started

### 4. Export Goals (`export`)

Export all goals data to structured JSON format.

```bash
ani-code goals export [options]
```

**Options:**
- `-o, --output <file>` - Custom output file path (default: `.ani-code/goals-export.json`)

**Example:**
```bash
ani-code goals export
ani-code goals export -o my-goals.json
```

**Output:**
```
✓ Goals exported successfully
  Location: /path/to/.ani-code/goals-export.json
  Goals: 3
  Completed: 0
  In Progress: 2
  Not Started: 1
```

**JSON Structure:**
```json
{
  "exportDate": "2025-11-05T16:09:37.106Z",
  "totalGoals": 3,
  "summary": {
    "notStarted": 1,
    "inProgress": 2,
    "completed": 0
  },
  "goals": [
    {
      "file": "001-foundation.md",
      "path": "/full/path/to/file.md",
      "title": "Foundation Setup",
      "objective": "Set up the initial project infrastructure...",
      "tasks": [
        {
          "completed": true,
          "description": "Create project directory structure"
        }
      ],
      "acceptanceCriteria": ["..."],
      "progress": {
        "status": "In Progress",
        "startDate": "2025-01-15",
        "completionDate": "-",
        "notes": "...",
        "taskCompletion": {
          "completed": 3,
          "total": 5,
          "percentage": 60
        }
      },
      "dependencies": ["..."]
    }
  ]
}
```

### 5. Update Goal Status (`update`)

Manually update the status of a specific goal. This creates a **manual override** that persists through sync operations.

```bash
ani-code goals update <goal-id> <status>
```

**Arguments:**
- `<goal-id>` - Goal identifier (index number or filename)
- `<status>` - New status value

**Valid Status Values:**
- `Not Started` - Goal hasn't been started yet
- `In Progress` - Currently working on this goal
- `Completed` - Goal successfully completed
- `Abandoned` - Goal was abandoned/deprecated (use for old goals)
- `Cancelled` - Goal was cancelled
- `On Hold` - Goal is paused/on hold

**Manual Override Behavior:**
- Status set manually will **NOT be recalculated** during sync
- Useful for marking old/deprecated goals as "Abandoned"
- Allows overriding automatic status calculation from tasks
- Manual override persists until cleared with `clear-override` command

**Automatic Updates:**
- When set to "In Progress": Updates start date if not already set
- When set to "Completed", "Abandoned", or "Cancelled": Updates completion date to current date

**Example:**
```bash
ani-code goals update 1 "In Progress"
ani-code goals update 42 "Abandoned"    # Mark old goal as abandoned
ani-code goals update 003-testing.md "Completed"
```

**Output:**
```
✓ Goal status updated
  Goal: 042-old-feature.md
  Status: Abandoned
  Manual override: This status will persist through sync operations
```

### 6. Bulk Update Goals (`bulk-update`)

Update multiple goals at once with a confirmation prompt.

```bash
ani-code goals bulk-update <range> <status>
```

**Arguments:**
- `<range>` - Goal range or list
  - Range format: `1-15` (updates goals 1 through 15)
  - Comma-separated: `1,3,5,7` (updates specific goals)
- `<status>` - New status for all goals

**Features:**
- Shows preview of all goals to be updated
- Displays current status → new status for each goal
- Requires explicit confirmation (yes/no)
- Updates cache automatically
- Sets manual override on all updated goals

**Example:**
```bash
# Update goals 1-15 to Abandoned
ani-code goals bulk-update 1-15 "Abandoned"

# Update specific goals
ani-code goals bulk-update 10,15,20,25 "Cancelled"
```

**Interactive Output:**
```
📝 Bulk Status Update

Will update 15 goal(s) to: Abandoned

Goals to update:
  [1] Legacy Authentication System
      Current: In Progress → New: Abandoned
      File: 001-legacy-auth.md
  [2] Old Dashboard V1
      Current: In Progress → New: Abandoned
      File: 002-old-dashboard.md
  ...
  [15] Deprecated API Endpoints
      Current: Completed → New: Abandoned
      File: 015-deprecated-api.md

Proceed with bulk update? (yes/no): yes

🔄 Updating goals...

  ✓ [1] 001-legacy-auth.md
  ✓ [2] 002-old-dashboard.md
  ...
  ✓ [15] 015-deprecated-api.md

  Cache updated

📊 Bulk Update Summary

  ✓ Success: 15
  Manual override set for all updated goals
  Status will persist through sync operations
```

**Use Cases:**
- Mark old/deprecated goals as "Abandoned" (e.g., goals 1-15)
- Cancel multiple features at once
- Put multiple goals on hold
- Batch status updates for project reorganization

### 7. Clear Manual Override (`clear-override`)

Remove manual status override from a goal, allowing automatic calculation from task completion.

```bash
ani-code goals clear-override <goal-id>
```

**Arguments:**
- `<goal-id>` - Goal identifier (index number or filename)

**What it does:**
- Removes manual override flag
- Recalculates status from task completion percentage:
  - 100% tasks done → "Completed"
  - 1-99% tasks done → "In Progress"
  - 0% tasks done → "Not Started"
- Updates cache immediately

**Example:**
```bash
ani-code goals clear-override 42
```

**Output:**
```
✓ Manual override cleared
  Goal: 042-feature.md
  New status (auto-calculated): In Progress
  Status will now be calculated from task completion during sync
```

## Goal File Format

Goals must be markdown files following this structure:

```markdown
# Goal: [Goal Name]

## Objective
[Clear description of what this stage aims to achieve]

## Tasks
- [ ] Task 1 description
- [x] Task 2 description (completed)
- [ ] Task 3 description

## Acceptance Criteria
- Criteria 1
- Criteria 2
- Criteria 3

## Progress
- Status: **Not Started** | **In Progress** | **Completed** | **Abandoned** | **Cancelled** | **On Hold**
- Start Date: -
- Completion Date: -
- Notes: [Any relevant notes or blockers]

## Dependencies
- [List any dependencies on other goals]
```

**Important Format Requirements:**
- Status must be wrapped in `**bold**` markdown
- Tasks use `- [ ]` for incomplete and `- [x]` for completed
- Dates use ISO format (YYYY-MM-DD) or `-` for unset
- Section headers must be `## Header Name`

**Status Values:**
- **Not Started** - Goal hasn't been started yet (auto-calculated: 0% tasks)
- **In Progress** - Currently working on this goal (auto-calculated: 1-99% tasks)
- **Completed** - Goal successfully completed (auto-calculated: 100% tasks)
- **Abandoned** - Goal was abandoned/deprecated (manual only)
- **Cancelled** - Goal was cancelled (manual only)
- **On Hold** - Goal is paused/on hold (manual only)

**Note:** During sync, status is automatically calculated from task completion unless a manual override is set using `ani-code goals update`.

## Manual Status Override

The goals command supports manual status overrides for situations where automatic calculation doesn't fit your needs.

### When to Use Manual Override

1. **Old/Abandoned Goals**: Mark goals that are no longer relevant as "Abandoned"
2. **Cancelled Features**: Mark goals for cancelled features
3. **On Hold**: Mark goals that are paused but not abandoned
4. **Status Mismatch**: Override automatic calculation when it doesn't reflect reality

### How Manual Override Works

**Setting an Override:**
```bash
ani-code goals update 42 "Abandoned"
```

**What Happens:**
- Status is updated in both file and cache
- `manualOverride: true` flag is set in cache
- `manualOverrideDate` is recorded
- Status will **NOT** be recalculated during future syncs
- Goal displays with `[MANUAL]` indicator in list/progress views

**Clearing an Override:**
```bash
ani-code goals clear-override 42
```

**What Happens:**
- Manual override flags are removed from cache
- Status is immediately recalculated from task completion
- Future syncs will auto-calculate status normally

### Visual Indicators

Goals with manual overrides display:
- **List view**: `[MANUAL]` tag in yellow after status
- **Progress view**: `[MANUAL]` tag after goal title
- **Show view**: `⚠ Manual override active (set 2025-01-15)` message

### Examples

**Marking old goals as abandoned:**
```bash
# Option 1: Update one by one
ani-code goals update 15 "Abandoned"
ani-code goals update 16 "Abandoned"
ani-code goals update 17 "Abandoned"

# Option 2: Bulk update with confirmation (recommended)
ani-code goals bulk-update 15-17 "Abandoned"
# Shows preview and asks: Proceed with bulk update? (yes/no)

# Verify with list
ani-code goals list
# Output shows: ⊘ [15] Old Feature X (2/5 tasks, 015-old.md) [MANUAL]
```

**Putting a goal on hold:**
```bash
ani-code goals update 8 "On Hold"
# Status persists through sync operations
```

**Resetting to auto-calculation:**
```bash
# Remove override and recalculate from tasks
ani-code goals clear-override 8
# If 60% of tasks are done, status becomes "In Progress"
```

## Use Cases

### Daily Standup
```bash
ani-code goals progress
```
Get quick visual overview of all goal progress for team updates.

### Sprint Planning
```bash
ani-code goals list
ani-code goals show 1
ani-code goals show 2
```
Review goals and their details to plan sprint work.

### Progress Reporting
```bash
ani-code goals export -o sprint-report.json
```
Export structured data for reporting tools or dashboards.

### Goal Tracking
```bash
ani-code goals update 2 "In Progress"
ani-code goals progress
```
Update goal status as work progresses and verify changes.

### Quick Status Check
```bash
ani-code goals list
```
Get instant overview without opening files.

## Integration with Workflows

### Git Hooks
Add to `.git/hooks/pre-commit`:
```bash
#!/bin/bash
ani-code goals export
git add .ani-code/goals-export.json
```

### CI/CD Pipelines
```yaml
- name: Export Goals
  run: ani-code goals export -o artifacts/goals.json
```

### Dashboard Integration
```javascript
const goalsData = require('./.ani-code/goals-export.json');
// Use structured data in your dashboard
```

## Tips & Best Practices

1. **Consistent Naming**: Use numbered prefixes for goals (001-, 002-, etc.) to maintain order
2. **Regular Updates**: Update goal status as progress is made
3. **Detailed Tasks**: Break down objectives into specific, measurable tasks
4. **Export Regularly**: Export data for version control and tracking over time
5. **Use Indices**: Goal index numbers are easier to type than full filenames
6. **Status Standards**: Stick to the three standard statuses for consistency

## Troubleshooting

### No goals found
- Verify goals directory exists (default: `pd/goals/`)
- Check that files have `.md` extension
- Use `-d` option to specify custom directory

### Status not updating
- Ensure status is wrapped in `**bold**` markdown
- Check exact format: `- Status: **In Progress**`
- Verify you have write permissions to the file

### Parse errors
- Review goal file format matches template
- Ensure proper markdown syntax
- Check for missing section headers

## Advanced Usage

### Custom Goals Directory
```bash
ani-code goals -d documentation/milestones list
```

### Scripting
```bash
# Get completion percentage
ani-code goals export
jq '.summary.completed / .totalGoals * 100' .ani-code/goals-export.json

# List incomplete goals
jq '.goals[] | select(.progress.status != "Completed") | .title' \
  .ani-code/goals-export.json
```

### Automated Status Updates
```bash
# Mark all goals as in progress (careful!)
for i in {1..3}; do
  ani-code goals update $i "In Progress"
done
```

## Quick Reference

### Basic Workflow

1. **Create goal files** in `pd/goals/` following the template
2. **Sync with Claude**: `ani-code goals sync`
3. **View progress**: `ani-code goals list` or `ani-code goals progress`
4. **Check details**: `ani-code goals show <id>`
5. **Update status**: `ani-code goals update <id> "In Progress"`
6. **Re-sync** when files change: `ani-code goals sync`

### Cache System

**Cache Location**: Workspace metadata (database)
**Fallback**: `.ani-code/goals-cache.json` (if no workspace)

**How it works:**
- `sync` command analyzes markdown files with Claude
- Cache stores structured data in workspace metadata
- Commands read from cache automatically
- Cache is validated against source file modification times
- Stale cache triggers warning with sync reminder
- Per-workspace isolation - each workspace has its own goals cache

**Cache invalidation:**
- Automatic when source files are newer than cache
- Manual with `--refresh` flag on list command
- Regenerate with `sync` command

### Command Cheat Sheet

```bash
# First time setup
ani-code goals sync

# Daily usage
ani-code goals list              # Quick overview
ani-code goals progress          # Visual progress bars
ani-code goals show 1            # Detailed view

# Making changes
ani-code goals update 2 "Completed"
ani-code goals update 42 "Abandoned"  # Mark old goal as abandoned
ani-code goals clear-override 8       # Remove manual override
ani-code goals sync                   # Refresh cache

# Export for reports
ani-code goals export -o report.json

# Advanced
ani-code goals -d custom/path sync    # Custom directory
ani-code goals list --refresh         # Bypass cache
ani-code goals sync --full            # Force full resync
```

### Status Management Quick Guide

```bash
# Auto-calculated statuses (based on task completion)
ani-code goals sync              # Updates status based on tasks

# Manual statuses (persists through sync)
ani-code goals update 15 "Abandoned"         # Single goal
ani-code goals bulk-update 1-15 "Abandoned"  # Multiple goals with confirmation
ani-code goals bulk-update 10,20,30 "Cancelled"  # Specific goals

# Reset to auto-calculation
ani-code goals clear-override 8       # Recalculate from tasks
```

### Bulk Operations Guide

```bash
# Mark old goals as abandoned (with confirmation)
ani-code goals bulk-update 1-15 "Abandoned"

# Cancel specific features
ani-code goals bulk-update 10,15,20 "Cancelled"

# Put multiple goals on hold
ani-code goals bulk-update 5-10 "On Hold"
```

### Performance Notes

- **First run**: Requires `sync` to build cache (~5-30 seconds)
- **Cached reads**: Instant (<100ms)
- **Sync frequency**: Only when files change
- **Large projects**: Cache scales well (tested with 50+ goals)

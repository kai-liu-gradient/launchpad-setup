#!/usr/bin/env node
import { UsageReporter } from './src/usage-reporter.js';

async function testCostCalculation() {
  console.log('Testing cost calculation fix...\n');

  const reporter = new UsageReporter();

  // Test 1: Generate daily report (uses --since filter)
  console.log('Test 1: Daily Report Generation');
  console.log('================================');
  const report = await reporter.generateDailyReport();

  if (report) {
    console.log('Title:', report.title);
    console.log('Totals:', report.totals);
    console.log('\nReport Content:');
    console.log(report.content);
    console.log('\n✅ Daily report generated successfully');

    if (report.totals.totalCost > 0) {
      console.log('✅ Cost is properly calculated:', report.totals.totalCost);
    } else if (report.totals.totalTokens > 0) {
      console.log('⚠️  Warning: Tokens exist but cost is still 0');
    } else {
      console.log('ℹ️  No usage data for today');
    }
  } else {
    console.log('❌ Failed to generate daily report');
  }

  console.log('\n\nTest 2: Task Snapshot Creation');
  console.log('================================');
  const testTaskId = 'test-task-' + Date.now();

  // Create before snapshot
  const beforeSnapshot = await reporter.createTaskSnapshot(testTaskId, 'Test Task');

  if (beforeSnapshot) {
    console.log('Before Snapshot:');
    console.log('- Cost:', beforeSnapshot.totals.totalCost);
    console.log('- Tokens:', beforeSnapshot.totals.totalTokens);

    if (beforeSnapshot.totals.totalCost > 0 || beforeSnapshot.totals.totalTokens === 0) {
      console.log('✅ Before snapshot cost properly calculated');
    } else {
      console.log('⚠️  Before snapshot has tokens but cost is 0');
    }
  } else {
    console.log('❌ Failed to create before snapshot');
  }

  // Simulate some usage (wait a bit)
  console.log('\nWaiting 2 seconds...');
  await new Promise(resolve => setTimeout(resolve, 2000));

  // Create after snapshot
  const usage = await reporter.createTaskCompletionSnapshot(testTaskId, 'Test Task');

  if (usage) {
    console.log('\nTask Usage Difference:');
    console.log('- Cost:', usage.cost);
    console.log('- Tokens:', usage.tokens);
    console.log('- Input Tokens:', usage.inputTokens);
    console.log('- Output Tokens:', usage.outputTokens);

    if (usage.cost > 0 || usage.tokens === 0) {
      console.log('✅ Task usage cost properly calculated');
    } else {
      console.log('⚠️  Task has token usage but cost is 0');
    }
  } else {
    console.log('ℹ️  No usage difference detected (expected for this test)');
  }

  console.log('\n\nTest Complete!');
}

testCostCalculation().catch(error => {
  console.error('Test failed:', error);
  process.exit(1);
});
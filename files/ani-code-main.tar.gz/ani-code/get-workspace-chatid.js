#!/usr/bin/env node

import { WorkspaceManager } from './src/workspace-manager.js';
import { logger } from './src/logger.js';

async function getAniCodeWorkspaceChatId() {
  const manager = new WorkspaceManager();
  
  try {
    await manager.initialize();
    
    // Get all workspaces
    const workspaces = await manager.listWorkspaces(true);
    
    // Find ani-code workspace
    const aniCodeWorkspace = workspaces.find(ws => 
      ws.name.toLowerCase().includes('ani-code') || 
      ws.path?.includes('ani-code')
    );
    
    if (aniCodeWorkspace) {
      console.log('Found ani-code workspace:', aniCodeWorkspace.name);
      console.log('Path:', aniCodeWorkspace.path);
      
      if (aniCodeWorkspace.chatId) {
        console.log('Chat ID:', aniCodeWorkspace.chatId);
        return aniCodeWorkspace.chatId;
      } else {
        console.log('No chat ID set for this workspace');
      }
      
      // Check settings
      if (aniCodeWorkspace.settings) {
        console.log('Settings:', JSON.stringify(aniCodeWorkspace.settings, null, 2));
      }
    } else {
      console.log('No ani-code workspace found');
      console.log('\nAvailable workspaces:');
      workspaces.forEach(ws => {
        console.log(`- ${ws.name} (${ws.path}) - Chat ID: ${ws.chatId || 'none'}`);
      });
    }
    
    // Check telegram chat mappings
    console.log('\nChecking telegram chat mappings...');
    const chatMappings = await manager.getChatWorkspaceMappings();
    console.log('All chat mappings:', chatMappings);
    
    // Find mapping for ani-code workspace
    const aniCodeMapping = chatMappings.find(mapping => 
      mapping.workspace_id === aniCodeWorkspace?.id
    );
    
    if (aniCodeMapping) {
      console.log('\nFound chat mapping for ani-code workspace:');
      console.log('Chat ID:', aniCodeMapping.chat_id);
      return aniCodeMapping.chat_id;
    }
    
    // Also check authorized telegram chats
    console.log('\nChecking authorized telegram chats...');
    const authorizedChats = await manager.db.all(`
      SELECT * FROM telegram_chats 
      WHERE workspace_id IS NOT NULL
    `);
    
    console.log('Authorized telegram chats:', authorizedChats);
    
    // Check all telegram chats
    console.log('\nChecking all telegram chats...');
    const allTelegramChats = await manager.db.all(`
      SELECT * FROM telegram_chats
    `);
    console.log('All telegram chats:', allTelegramChats);
    
    const aniCodeChat = authorizedChats.find(chat => 
      chat.workspace_id === aniCodeWorkspace?.id
    );
    
    if (aniCodeChat) {
      console.log('\nFound authorized telegram chat for ani-code:');
      console.log('Chat ID:', aniCodeChat.chat_id);
      return aniCodeChat.chat_id;
    }
    
    await manager.close();
  } catch (error) {
    console.error('Error:', error);
    await manager.close();
  }
}

getAniCodeWorkspaceChatId();
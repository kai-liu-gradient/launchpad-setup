#!/usr/bin/env node

/**
 * Test script for Gateway Registration Feature
 * Tests both standalone and gateway modes
 */

import { GatewayClient } from './src/gateway-client.js';

console.log('=== Gateway Registration Test Suite ===\n');

// Test 1: Standalone Mode (no env vars)
console.log('Test 1: Standalone Mode');
console.log('-----------------------');
const standaloneClient = new GatewayClient();
console.log('GATEWAY_URL:', standaloneClient.gatewayUrl || '(not set)');
console.log('Is enabled:', standaloneClient.isEnabled());
console.log('Expected: Should run in standalone mode');
console.log('Result:', !standaloneClient.isEnabled() ? '✅ PASS' : '❌ FAIL');
console.log();

// Test 2: Gateway Mode Simulation
console.log('Test 2: Gateway Mode (simulated with env vars)');
console.log('----------------------------------------------');

// Temporarily set env vars for testing
process.env.GATEWAY_URL = 'http://localhost:6555';
process.env.GATEWAY_API_KEY = 'dev-key-1';
process.env.PROJECT_ID = 'test-proj';
process.env.WORKSPACE_ID = 'test-ws';
process.env.POD_NAME = 'test-pod';

const gatewayClient = new GatewayClient();
console.log('GATEWAY_URL:', gatewayClient.gatewayUrl);
console.log('API_KEY:', gatewayClient.apiKey);
console.log('PROJECT_ID:', gatewayClient.projectId);
console.log('WORKSPACE_ID:', gatewayClient.workspaceId);
console.log('POD_NAME:', gatewayClient.podName);
console.log('Pod IP:', gatewayClient.podIp);
console.log('Port:', gatewayClient.port);
console.log('Is enabled:', gatewayClient.isEnabled());
console.log('Expected: Should be configured for gateway mode');
console.log('Result:', gatewayClient.isEnabled() ? '✅ PASS' : '❌ FAIL');
console.log();

// Test 3: Registration attempt (will fail gracefully if gateway not running)
console.log('Test 3: Gateway Registration (graceful fallback)');
console.log('------------------------------------------------');
console.log('Attempting to register with gateway...');

try {
  const instanceId = await gatewayClient.register();

  if (instanceId) {
    console.log('✅ Successfully registered with gateway!');
    console.log('Instance ID:', instanceId);

    // Test deregistration
    console.log('Testing deregistration...');
    await gatewayClient.deregister();
    console.log('✅ Successfully deregistered from gateway');
  } else {
    console.log('⚠️  Registration returned null (gateway unavailable or disabled)');
    console.log('✅ Gracefully falling back to standalone mode');
  }
} catch (error) {
  console.log('❌ Unexpected error:', error.message);
}

console.log();

// Test 4: Health Check Endpoint Format
console.log('Test 4: Health Check Endpoint');
console.log('-----------------------------');
console.log('Expected format: { status: "ok", ready: true, ... }');

try {
  const response = await fetch('http://localhost:6501/health');
  if (response.ok) {
    const data = await response.json();
    console.log('Response:', JSON.stringify(data, null, 2));

    const hasRequiredFields = data.status && data.ready !== undefined;
    console.log('Has required fields (status, ready):', hasRequiredFields ? '✅ PASS' : '❌ FAIL');
  } else {
    console.log('❌ Health endpoint returned status:', response.status);
  }
} catch (error) {
  console.log('⚠️  Cannot reach health endpoint (daemon may not be running)');
}

console.log();

// Cleanup
console.log('=== Test Suite Complete ===');

// Clean up env vars
delete process.env.GATEWAY_URL;
delete process.env.GATEWAY_API_KEY;
delete process.env.PROJECT_ID;
delete process.env.WORKSPACE_ID;
delete process.env.POD_NAME;

process.exit(0);
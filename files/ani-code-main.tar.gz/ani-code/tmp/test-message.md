# Test Message

This is a test of the file attachment feature.

## Features:
- Send files using @filename syntax
- Automatic detection of images vs documents
- Multiple attachments supported
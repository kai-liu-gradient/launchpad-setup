# ANI-CODE Port Configuration

## Port Summary

| Port | Service | Purpose | Used By |
|------|---------|---------|---------|
| 6501 | HTTP API | REST endpoints for task management | CLI, direct API calls |
| 6502 | WebSocket | Real-time control & gateway integration | ani-code-gateway |

## Detailed Configuration

### Port 6501 - HTTP REST API
**Purpose**: Direct task creation, status checks, health monitoring

**Environment Variables**:
```bash
ANI_CODE_DAEMON_PORT=6501  # Primary (recommended)
HTTP_CALLBACK_PORT=6501    # Legacy fallback
PORT=6501                  # Generic fallback
```

**Endpoints**:
- `POST /api/tasks/add` - Create new task
- `GET /api/tasks/status` - Get task status
- `GET /api/tasks/list` - List all tasks
- `POST /api/tasks/cancel` - Cancel task
- `GET /health` - Health check
- `GET /version` - Version info

**Usage**:
```bash
curl -X POST http://localhost:6501/api/tasks/add \
  -H "Content-Type: application/json" \
  -d '{"task": "echo Hello"}'
```

### Port 6502 - WebSocket Service
**Purpose**: Real-time control, gateway integration, bidirectional communication

**Environment Variables**:
```bash
ANICODE_WS_PORT=6502  # WebSocket port (default: 6502)
```

**Features**:
- Real-time task updates
- Token-based authentication
- Gateway remote control
- Plugin communication (Chrome extension)

**Usage**:
```javascript
const ws = new WebSocket('ws://localhost:6502?token=YOUR_TOKEN');
ws.onmessage = (event) => {
  console.log('Task update:', event.data);
};
```

## Gateway Integration

**ani-code-gateway connects via port 6502 (WebSocket)**, not port 6501.

### Configuration Example
```javascript
// Gateway instance configuration
{
  instanceUrl: 'http://ani-code-host:6502',  // WebSocket port
  wsUrl: 'ws://ani-code-host:6502',         // WebSocket URL
  name: 'instance-1'
}
```

### Environment Setup for Gateway
```bash
# ani-code daemon
ANI_CODE_DUMMY_MODE=true        # Enable dummy mode
ANI_CODE_DAEMON_PORT=6501       # HTTP API port
ANICODE_WS_PORT=6502            # WebSocket port (gateway connects here)

# Start daemon
ani-code daemon --start
```

## Docker Configuration

```dockerfile
FROM node:18

# Configure ports
ENV ANI_CODE_DUMMY_MODE=true
ENV ANI_CODE_DAEMON_PORT=6501
ENV ANICODE_WS_PORT=6502

# Expose both ports
EXPOSE 6501 6502

WORKDIR /app
COPY . .

CMD ["node", "src/daemon-runner.js"]
```

### Docker Compose
```yaml
services:
  ani-code:
    image: ani-code:latest
    ports:
      - "6501:6501"  # HTTP API
      - "6502:6502"  # WebSocket (gateway)
    environment:
      ANI_CODE_DUMMY_MODE: "true"
      ANI_CODE_DAEMON_PORT: "6501"
      ANICODE_WS_PORT: "6502"
```

## Kubernetes Configuration

```yaml
apiVersion: v1
kind: Service
metadata:
  name: ani-code
spec:
  selector:
    app: ani-code
  ports:
  - name: http
    port: 6501
    targetPort: 6501
  - name: websocket
    port: 6502
    targetPort: 6502

---

apiVersion: apps/v1
kind: Deployment
metadata:
  name: ani-code
spec:
  replicas: 1
  selector:
    matchLabels:
      app: ani-code
  template:
    metadata:
      labels:
        app: ani-code
    spec:
      containers:
      - name: ani-code
        image: ani-code:latest
        ports:
        - containerPort: 6501
          name: http
        - containerPort: 6502
          name: websocket
        env:
        - name: ANI_CODE_DUMMY_MODE
          value: "true"
        - name: ANI_CODE_DAEMON_PORT
          value: "6501"
        - name: ANICODE_WS_PORT
          value: "6502"
```

## Firewall Configuration

### UFW (Ubuntu)
```bash
sudo ufw allow 6501/tcp  # HTTP API
sudo ufw allow 6502/tcp  # WebSocket
```

### iptables
```bash
iptables -A INPUT -p tcp --dport 6501 -j ACCEPT
iptables -A INPUT -p tcp --dport 6502 -j ACCEPT
```

### firewalld
```bash
firewall-cmd --permanent --add-port=6501/tcp
firewall-cmd --permanent --add-port=6502/tcp
firewall-cmd --reload
```

## Testing Connectivity

### Test HTTP API (6501)
```bash
curl http://localhost:6501/health
```

### Test WebSocket (6502)
```bash
# Using websocat
websocat ws://localhost:6502

# Using wscat
wscat -c ws://localhost:6502
```

## Common Issues

### Gateway can't connect
**Problem**: Gateway fails to connect to ani-code instance

**Solution**:
1. Verify port 6502 is open: `nc -zv localhost 6502`
2. Check ANICODE_WS_PORT environment variable
3. Ensure daemon is running: `ani-code daemon --status`
4. Check firewall rules

### Wrong port configuration
**Problem**: Gateway configured with port 6501 instead of 6502

**Solution**:
```javascript
// Wrong
instanceUrl: 'http://ani-code:6501'  // HTTP API port

// Correct
instanceUrl: 'http://ani-code:6502'  // WebSocket port
```

## Port Selection Logic

### HTTP API Port (6501)
```javascript
const port = process.env.ANI_CODE_DAEMON_PORT ||
             process.env.HTTP_CALLBACK_PORT ||
             process.env.PORT ||
             6501;
```

### WebSocket Port (6502)
```javascript
const wsPort = parseInt(process.env.ANICODE_WS_PORT || '6502');
```

## Summary

- **For CLI and direct API access**: Use port 6501
- **For gateway integration**: Use port 6502
- **For both**: Expose both ports in containers/k8s
- **Default behavior**: Both services start automatically with daemon

#!/usr/bin/env node

import fs from 'fs';
import path from 'path';
import http from 'http';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Create a sample EML file for testing
const sampleEmlContent = `From: sender@example.com
To: recipient@example.com
Subject: Verify Your Email
Date: Thu, 26 Sep 2025 10:00:00 +0000
Message-ID: <123456@example.com>
MIME-Version: 1.0
Content-Type: multipart/alternative; boundary="boundary123"

--boundary123
Content-Type: text/plain; charset=UTF-8

Hello,

Please verify your email address by clicking the link below:
https://example.com/verify?token=abc123

Best regards,
The Example Team

--boundary123
Content-Type: text/html; charset=UTF-8

<html>
<body>
<h1>Hello!</h1>
<p>Please verify your email address by clicking the link below:</p>
<a href="https://example.com/verify?token=abc123">Verify Email</a>
<p>Best regards,<br>The Example Team</p>
</body>
</html>

--boundary123--
`;

// Save sample EML file
const emlPath = path.join(__dirname, 'sample-test.eml');
fs.writeFileSync(emlPath, sampleEmlContent);
console.log(`✓ Created sample EML file: ${emlPath}`);

// Simulate Telegram webhook message with EML document
const simulatedMessage = {
  update_id: 999999999,
  message: {
    message_id: 24110,
    from: {
      id: 394977994,
      is_bot: false,
      first_name: "Test",
      username: "testuser",
      language_code: "en"
    },
    chat: {
      id: -4859374111,
      title: "Test Group",
      type: "group"
    },
    date: Math.floor(Date.now() / 1000),
    document: {
      file_name: "Verify Your Email.eml",
      mime_type: "message/rfc822",
      file_id: "TEST_FILE_ID_123456",
      file_unique_id: "TEST_UNIQUE_ID_123",
      file_size: sampleEmlContent.length
    },
    caption: "/add this is an example eml, can you use this to test and run the simulation test?"
  }
};

console.log('\n📧 Simulated Telegram message with EML document:');
console.log(JSON.stringify(simulatedMessage, null, 2));

// Test the MIME type check logic
console.log('\n🔍 Testing EML file support logic:');

const supportedMimeTypes = [
  'image/',
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'text/plain',
  'text/markdown',
  'text/x-markdown',
  'message/rfc822',  // EML email files
  'application/octet-stream'
];

const supportedExtensions = ['.pdf', '.doc', '.docx', '.txt', '.md', '.markdown', '.eml'];

// Test cases
const testCases = [
  { mimeType: 'message/rfc822', fileName: 'email.eml', expected: true },
  { mimeType: 'application/octet-stream', fileName: 'email.eml', expected: true },
  { mimeType: 'text/plain', fileName: 'email.eml', expected: true },
  { mimeType: 'unknown', fileName: 'email.eml', expected: true },
  { mimeType: 'message/rfc822', fileName: null, expected: true },
  { mimeType: 'application/x-unsupported', fileName: 'file.xyz', expected: false }
];

testCases.forEach((testCase) => {
  const { mimeType, fileName, expected } = testCase;
  const fileExtension = fileName ? fileName.toLowerCase().match(/\.[^.]+$/)?.[0] : null;

  const isSupportedMime = supportedMimeTypes.some(type => mimeType.startsWith(type));
  const isSupportedExtension = fileExtension && supportedExtensions.includes(fileExtension);
  const isSupported = isSupportedMime || isSupportedExtension;

  const result = isSupported === expected ? '✓' : '✗';
  console.log(`${result} MIME: ${mimeType}, File: ${fileName || 'null'} => Supported: ${isSupported} (Expected: ${expected})`);
});

// Send test request to local server
console.log('\n📤 Sending test request to local server...');

const postData = JSON.stringify(simulatedMessage);

const options = {
  hostname: 'localhost',
  port: 3456,
  path: '/webhook/telegram',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(postData)
  }
};

const req = http.request(options, (res) => {
  console.log(`Status: ${res.statusCode}`);

  let data = '';
  res.on('data', (chunk) => {
    data += chunk;
  });

  res.on('end', () => {
    console.log('Response:', data || '(empty)');
    console.log('\n✅ EML support test completed!');

    // Cleanup
    fs.unlinkSync(emlPath);
    console.log(`✓ Cleaned up test file: ${emlPath}`);
  });
});

req.on('error', (error) => {
  console.error('❌ Error sending request:', error.message);
  console.log('\n💡 Make sure the ani-code server is running on port 3456');

  // Cleanup even on error
  if (fs.existsSync(emlPath)) {
    fs.unlinkSync(emlPath);
    console.log(`✓ Cleaned up test file: ${emlPath}`);
  }
});

req.write(postData);
req.end();
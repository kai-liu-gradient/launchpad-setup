#!/usr/bin/env node

import { spawn } from 'child_process';

const proc = spawn('ani-code', ['goals', 'sync', '--full'], {
  cwd: '/root/workspace/ghisha-helix',
  stdio: 'inherit',
  env: process.env
});

proc.on('close', (code) => {
  console.log(`\nSync process exited with code ${code}`);
});
#!/bin/bash

# AniCode REST API Examples using curl
# This script demonstrates how to interact with AniCode API using curl

# Configuration
API_URL="http://localhost:6502"
TOKEN="${ANICODE_TOKEN:-}"  # Set ANICODE_TOKEN environment variable or pass as argument

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if token is provided
if [ -z "$TOKEN" ] && [ -z "$1" ]; then
    echo -e "${RED}Error: No token provided${NC}"
    echo "Usage: $0 <workspace-token>"
    echo "   or: ANICODE_TOKEN=<token> $0"
    echo ""
    echo "Get a token with: ani-code workspace token gen"
    exit 1
fi

# Use first argument as token if environment variable not set
if [ -z "$TOKEN" ]; then
    TOKEN="$1"
fi

echo -e "${BLUE}=== AniCode API Examples ===${NC}\n"

# Function to pretty print JSON
pretty_json() {
    if command -v jq &> /dev/null; then
        jq '.'
    else
        cat
    fi
}

# 1. Submit a new task
echo -e "${GREEN}1. Submitting a new task...${NC}"
TASK_RESPONSE=$(curl -s -X POST "$API_URL/api/task" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test task from curl",
    "priority": "normal",
    "metadata": {
      "source": "curl-example",
      "timestamp": "'$(date -u +%Y-%m-%dT%H:%M:%SZ)'"
    }
  }')

echo "$TASK_RESPONSE" | pretty_json
TASK_ID=$(echo "$TASK_RESPONSE" | grep -o '"taskId":"[^"]*' | cut -d'"' -f4)

if [ -z "$TASK_ID" ]; then
    echo -e "${RED}Failed to create task${NC}"
    exit 1
fi

echo -e "${GREEN}Task created with ID: $TASK_ID${NC}\n"

# 2. Get task status
echo -e "${GREEN}2. Getting task status...${NC}"
sleep 2
curl -s -X GET "$API_URL/api/task/$TASK_ID" \
  -H "Authorization: Bearer $TOKEN" | pretty_json

echo ""

# 3. List all tasks
echo -e "${GREEN}3. Listing recent tasks...${NC}"
curl -s -X GET "$API_URL/api/tasks?limit=5" \
  -H "Authorization: Bearer $TOKEN" | pretty_json

echo ""

# 4. Submit a task with custom command
echo -e "${GREEN}4. Submitting task with custom command...${NC}"
CUSTOM_TASK=$(curl -s -X POST "$API_URL/api/task" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Run tests",
    "command": "npm test",
    "priority": "high"
  }')

echo "$CUSTOM_TASK" | pretty_json
CUSTOM_TASK_ID=$(echo "$CUSTOM_TASK" | grep -o '"taskId":"[^"]*' | cut -d'"' -f4)

echo ""

# 5. Cancel a task (optional - commented out by default)
echo -e "${YELLOW}5. Example: Cancel a task (commented out)${NC}"
echo "# To cancel a task, uncomment and run:"
echo "# curl -X DELETE \"$API_URL/api/task/\$TASK_ID\" \\"
echo "#   -H \"Authorization: Bearer $TOKEN\""

echo ""

# 6. Monitor task progress
echo -e "${GREEN}6. Monitoring task progress...${NC}"
echo "Checking status of task: $TASK_ID"

MAX_ATTEMPTS=30
ATTEMPT=0

while [ $ATTEMPT -lt $MAX_ATTEMPTS ]; do
    STATUS_RESPONSE=$(curl -s -X GET "$API_URL/api/task/$TASK_ID" \
      -H "Authorization: Bearer $TOKEN")
    
    STATUS=$(echo "$STATUS_RESPONSE" | grep -o '"status":"[^"]*' | cut -d'"' -f4)
    PROGRESS=$(echo "$STATUS_RESPONSE" | grep -o '"progress":[^,]*' | cut -d':' -f2)
    
    if [ "$STATUS" = "completed" ] || [ "$STATUS" = "failed" ] || [ "$STATUS" = "cancelled" ]; then
        echo -e "\n${GREEN}Task $STATUS${NC}"
        break
    fi
    
    echo -ne "\rStatus: $STATUS, Progress: ${PROGRESS:-0}%    "
    sleep 2
    ATTEMPT=$((ATTEMPT + 1))
done

echo -e "\n"

# 7. Advanced: Submit multiple tasks
echo -e "${GREEN}7. Example: Submitting multiple tasks${NC}"
cat << 'EOF'
# Submit multiple tasks in parallel
for i in {1..3}; do
  curl -s -X POST "$API_URL/api/task" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{
      \"name\": \"Parallel task $i\",
      \"priority\": \"normal\"
    }" &
done
wait
EOF

echo -e "\n${BLUE}=== Examples Complete ===${NC}"
echo ""
echo "Additional examples:"
echo "  - Filter tasks by status: curl -X GET \"$API_URL/api/tasks?status=running\" -H \"Authorization: Bearer $TOKEN\""
echo "  - Get task checklist: curl -X GET \"$API_URL/api/task/$TASK_ID/checklist\" -H \"Authorization: Bearer $TOKEN\""
echo "  - Paginate tasks: curl -X GET \"$API_URL/api/tasks?limit=10&offset=10\" -H \"Authorization: Bearer $TOKEN\""
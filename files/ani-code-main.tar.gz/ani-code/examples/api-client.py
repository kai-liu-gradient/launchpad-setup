#!/usr/bin/env python3
"""
AniCode API Client Example
Demonstrates how to interact with AniCode REST API
"""

import requests
import json
import time
import sys
from typing import Optional, Dict, Any

class AniCodeClient:
    """Client for interacting with AniCode REST API"""
    
    def __init__(self, token: str, base_url: str = "http://localhost:6502"):
        """
        Initialize the AniCode client
        
        Args:
            token: Workspace token (get with: ani-code workspace token gen)
            base_url: Base URL of AniCode API server
        """
        self.token = token
        self.base_url = base_url
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
    
    def submit_task(self, name: str, command: Optional[str] = None, 
                   priority: str = "normal", metadata: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Submit a new task to AniCode
        
        Args:
            name: Task description/name
            command: Command to execute (defaults to ani-code continue)
            priority: Task priority (low, normal, high)
            metadata: Additional metadata for the task
        
        Returns:
            Task creation response with task ID
        """
        payload = {
            "name": name,
            "priority": priority
        }
        
        if command:
            payload["command"] = command
        if metadata:
            payload["metadata"] = metadata
        
        response = requests.post(
            f"{self.base_url}/api/task",
            headers=self.headers,
            json=payload
        )
        response.raise_for_status()
        return response.json()
    
    def get_task_status(self, task_id: str) -> Dict[str, Any]:
        """
        Get status of a specific task
        
        Args:
            task_id: ID of the task to check
        
        Returns:
            Task status information
        """
        response = requests.get(
            f"{self.base_url}/api/task/{task_id}",
            headers=self.headers
        )
        response.raise_for_status()
        return response.json()
    
    def list_tasks(self, status: Optional[str] = None, 
                  limit: int = 50, offset: int = 0) -> Dict[str, Any]:
        """
        List tasks for the workspace
        
        Args:
            status: Filter by status (queued, running, completed, failed)
            limit: Maximum number of tasks to return
            offset: Pagination offset
        
        Returns:
            List of tasks with pagination info
        """
        params = {
            "limit": limit,
            "offset": offset
        }
        if status:
            params["status"] = status
        
        response = requests.get(
            f"{self.base_url}/api/tasks",
            headers=self.headers,
            params=params
        )
        response.raise_for_status()
        return response.json()
    
    def cancel_task(self, task_id: str) -> Dict[str, Any]:
        """
        Cancel a running or queued task
        
        Args:
            task_id: ID of the task to cancel
        
        Returns:
            Cancellation result
        """
        response = requests.delete(
            f"{self.base_url}/api/task/{task_id}",
            headers=self.headers
        )
        response.raise_for_status()
        return response.json()
    
    def wait_for_task(self, task_id: str, poll_interval: int = 2, 
                     timeout: Optional[int] = None) -> Dict[str, Any]:
        """
        Wait for a task to complete
        
        Args:
            task_id: ID of the task to wait for
            poll_interval: Seconds between status checks
            timeout: Maximum seconds to wait (None for no timeout)
        
        Returns:
            Final task status
        """
        start_time = time.time()
        
        while True:
            status = self.get_task_status(task_id)
            
            if status["status"] in ["completed", "failed", "cancelled"]:
                return status
            
            if timeout and (time.time() - start_time) > timeout:
                raise TimeoutError(f"Task {task_id} did not complete within {timeout} seconds")
            
            print(f"Task {status['status']}: {status.get('progress', 0)}%", end='\r')
            time.sleep(poll_interval)

def main():
    """Example usage of AniCode API client"""
    
    # Get token from environment or command line
    if len(sys.argv) < 2:
        print("Usage: python api-client.py <workspace-token> [task-description]")
        print("\nGet a token with: ani-code workspace token gen")
        sys.exit(1)
    
    token = sys.argv[1]
    task_description = sys.argv[2] if len(sys.argv) > 2 else "Test task from Python client"
    
    # Create client
    client = AniCodeClient(token)
    
    try:
        # Submit a task
        print(f"Submitting task: {task_description}")
        result = client.submit_task(
            name=task_description,
            priority="normal",
            metadata={"source": "python-client", "version": "1.0"}
        )
        
        task_id = result["taskId"]
        print(f"Task created: {task_id}")
        print(f"Workspace: {result['workspace']}")
        print(f"Queue position: {result.get('queuePosition', 'Running')}")
        
        # Wait for task to complete
        print("\nWaiting for task to complete...")
        final_status = client.wait_for_task(task_id, poll_interval=3)
        
        print(f"\n\nTask completed with status: {final_status['status']}")
        
        if final_status.get("error"):
            print(f"Error: {final_status['error']}")
        else:
            print("Task completed successfully!")
            
            # Show output snippet
            output = final_status.get("output", "")
            if output:
                lines = output.split('\n')
                print(f"\nOutput preview (last 10 lines):")
                for line in lines[-10:]:
                    print(f"  {line}")
        
        # List recent tasks
        print("\n\nRecent tasks in workspace:")
        tasks = client.list_tasks(limit=5)
        for task in tasks["tasks"]:
            print(f"  - {task['name']} [{task['status']}]")
        
    except requests.exceptions.HTTPError as e:
        print(f"API Error: {e}")
        if e.response.text:
            print(f"Details: {e.response.text}")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
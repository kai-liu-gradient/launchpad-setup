#!/usr/bin/env node
/**
 * AniCode API Client Example for Node.js
 * Demonstrates how to interact with AniCode REST API
 */

const axios = require('axios');

class AniCodeClient {
  /**
   * Initialize the AniCode client
   * @param {string} token - Workspace token (get with: ani-code workspace token gen)
   * @param {string} baseUrl - Base URL of AniCode API server
   */
  constructor(token, baseUrl = 'http://localhost:6502') {
    this.token = token;
    this.baseUrl = baseUrl;
    this.headers = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    };
  }

  /**
   * Submit a new task to AniCode
   * @param {string} name - Task description/name
   * @param {string} command - Command to execute (optional)
   * @param {string} priority - Task priority (low, normal, high)
   * @param {object} metadata - Additional metadata for the task
   * @returns {Promise<object>} Task creation response with task ID
   */
  async submitTask(name, command = null, priority = 'normal', metadata = null) {
    const payload = { name, priority };
    
    if (command) payload.command = command;
    if (metadata) payload.metadata = metadata;
    
    try {
      const response = await axios.post(
        `${this.baseUrl}/api/task`,
        payload,
        { headers: this.headers }
      );
      return response.data;
    } catch (error) {
      throw this.handleError(error);
    }
  }

  /**
   * Get status of a specific task
   * @param {string} taskId - ID of the task to check
   * @returns {Promise<object>} Task status information
   */
  async getTaskStatus(taskId) {
    try {
      const response = await axios.get(
        `${this.baseUrl}/api/task/${taskId}`,
        { headers: this.headers }
      );
      return response.data;
    } catch (error) {
      throw this.handleError(error);
    }
  }

  /**
   * List tasks for the workspace
   * @param {string} status - Filter by status (queued, running, completed, failed)
   * @param {number} limit - Maximum number of tasks to return
   * @param {number} offset - Pagination offset
   * @returns {Promise<object>} List of tasks with pagination info
   */
  async listTasks(status = null, limit = 50, offset = 0) {
    const params = { limit, offset };
    if (status) params.status = status;
    
    try {
      const response = await axios.get(
        `${this.baseUrl}/api/tasks`,
        { headers: this.headers, params }
      );
      return response.data;
    } catch (error) {
      throw this.handleError(error);
    }
  }

  /**
   * Cancel a running or queued task
   * @param {string} taskId - ID of the task to cancel
   * @returns {Promise<object>} Cancellation result
   */
  async cancelTask(taskId) {
    try {
      const response = await axios.delete(
        `${this.baseUrl}/api/task/${taskId}`,
        { headers: this.headers }
      );
      return response.data;
    } catch (error) {
      throw this.handleError(error);
    }
  }

  /**
   * Wait for a task to complete
   * @param {string} taskId - ID of the task to wait for
   * @param {number} pollInterval - Seconds between status checks
   * @param {number} timeout - Maximum seconds to wait (null for no timeout)
   * @returns {Promise<object>} Final task status
   */
  async waitForTask(taskId, pollInterval = 2, timeout = null) {
    const startTime = Date.now();
    
    while (true) {
      const status = await this.getTaskStatus(taskId);
      
      if (['completed', 'failed', 'cancelled'].includes(status.status)) {
        return status;
      }
      
      if (timeout && (Date.now() - startTime) > timeout * 1000) {
        throw new Error(`Task ${taskId} did not complete within ${timeout} seconds`);
      }
      
      process.stdout.write(`\rTask ${status.status}: ${status.progress || 0}%`);
      await new Promise(resolve => setTimeout(resolve, pollInterval * 1000));
    }
  }

  /**
   * Handle API errors
   * @private
   */
  handleError(error) {
    if (error.response) {
      const message = error.response.data?.error || error.message;
      const err = new Error(`API Error: ${message}`);
      err.status = error.response.status;
      err.details = error.response.data;
      return err;
    }
    return error;
  }
}

/**
 * Example usage of AniCode API client
 */
async function main() {
  // Get token from command line
  const args = process.argv.slice(2);
  
  if (args.length < 1) {
    console.log('Usage: node api-client.js <workspace-token> [task-description]');
    console.log('\nGet a token with: ani-code workspace token gen');
    process.exit(1);
  }
  
  const token = args[0];
  const taskDescription = args[1] || 'Test task from Node.js client';
  
  // Create client
  const client = new AniCodeClient(token);
  
  try {
    // Submit a task
    console.log(`Submitting task: ${taskDescription}`);
    const result = await client.submitTask(
      taskDescription,
      null, // Let it default to ani-code continue
      'normal',
      { source: 'nodejs-client', version: '1.0' }
    );
    
    const taskId = result.taskId;
    console.log(`Task created: ${taskId}`);
    console.log(`Workspace: ${result.workspace}`);
    console.log(`Queue position: ${result.queuePosition || 'Running'}`);
    
    // Wait for task to complete
    console.log('\nWaiting for task to complete...');
    const finalStatus = await client.waitForTask(taskId, 3);
    
    console.log(`\n\nTask completed with status: ${finalStatus.status}`);
    
    if (finalStatus.error) {
      console.log(`Error: ${finalStatus.error}`);
    } else {
      console.log('Task completed successfully!');
      
      // Show output snippet
      const output = finalStatus.output || '';
      if (output) {
        const lines = output.split('\n');
        console.log('\nOutput preview (last 10 lines):');
        lines.slice(-10).forEach(line => {
          console.log(`  ${line}`);
        });
      }
    }
    
    // List recent tasks
    console.log('\n\nRecent tasks in workspace:');
    const tasks = await client.listTasks(null, 5);
    tasks.tasks.forEach(task => {
      console.log(`  - ${task.name} [${task.status}]`);
    });
    
  } catch (error) {
    console.error(`Error: ${error.message}`);
    if (error.details) {
      console.error('Details:', error.details);
    }
    process.exit(1);
  }
}

// Export for use as module
module.exports = AniCodeClient;

// Run if called directly
if (require.main === module) {
  main().catch(console.error);
}
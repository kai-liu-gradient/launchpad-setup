// Test script for domain-specific token storage
// Run this in the Chrome Extension background console to test

async function testDomainTokens() {
  console.log('=== Testing Domain-Specific Token Storage ===');
  
  // Test data
  const testTokens = [
    {
      token: 'eyJwcm9qZWN0IjoicHJvamVjdDEiLCJzZXJ2ZXJVcmwiOiJ3czovL2xvY2FsaG9zdDo4NzY1IiwiZXhwaXJlc0F0IjoxNzM1MzQ0MDAwMDAwfQ==.signature1.secret1',
      domain: 'localhost',
      info: { project: 'project1', serverUrl: 'ws://localhost:6502', expiresAt: 1735344000000 }
    },
    {
      token: 'eyJwcm9qZWN0IjoicHJvamVjdDIiLCJzZXJ2ZXJVcmwiOiJ3czovL2RldjEuZXhhbXBsZS5jb206ODA4MCIsImV4cGlyZXNBdCI6MTczNTM0NDAwMDAwMH0=.signature2.secret2',
      domain: 'dev1.example.com',
      info: { project: 'project2', serverUrl: 'ws://dev1.example.com:8080', expiresAt: 1735344000000 }
    },
    {
      token: 'eyJwcm9qZWN0IjoicHJvamVjdDMiLCJzZXJ2ZXJVcmwiOiJ3czovL2RldjIuZXhhbXBsZS5jb206OTA5MCIsImV4cGlyZXNBdCI6MTczNTM0NDAwMDAwMH0=.signature3.secret3',
      domain: 'dev2.example.com',
      info: { project: 'project3', serverUrl: 'ws://dev2.example.com:9090', expiresAt: 1735344000000 }
    }
  ];
  
  // Clear all existing tokens first
  console.log('1. Clearing all existing tokens...');
  await chrome.storage.local.clear();
  
  // Test storing tokens for different domains
  console.log('\n2. Storing tokens for different domains...');
  for (const testToken of testTokens) {
    console.log(`   Storing token for domain: ${testToken.domain}`);
    await chrome.runtime.sendMessage({
      type: 'SET_TOKEN',
      token: testToken.token,
      tokenInfo: testToken.info
    });
  }
  
  // Verify tokens are stored correctly
  console.log('\n3. Verifying stored tokens...');
  const allStoredTokens = await chrome.runtime.sendMessage({
    type: 'GET_ALL_STORED_TOKENS'
  });
  console.log('   All stored tokens:', allStoredTokens);
  
  // Test retrieving tokens for specific domains
  console.log('\n4. Testing domain-specific token retrieval...');
  for (const testToken of testTokens) {
    const retrieved = await chrome.runtime.sendMessage({
      type: 'GET_STORED_TOKEN',
      domain: testToken.domain
    });
    console.log(`   Token for ${testToken.domain}:`, retrieved?.token ? 'Found ✓' : 'Not found ✗');
    if (retrieved?.token) {
      const tokenMatches = retrieved.token.token === testToken.token;
      console.log(`     Token matches: ${tokenMatches ? '✓' : '✗'}`);
    }
  }
  
  // Test clearing specific domain token
  console.log('\n5. Testing domain-specific token clearing...');
  console.log('   Clearing token for dev1.example.com');
  await chrome.runtime.sendMessage({
    type: 'CLEAR_TOKEN',
    domain: 'dev1.example.com'
  });
  
  // Verify token was cleared
  const clearedCheck = await chrome.runtime.sendMessage({
    type: 'GET_STORED_TOKEN',
    domain: 'dev1.example.com'
  });
  console.log(`   Token for dev1.example.com after clearing: ${clearedCheck?.token ? 'Still exists ✗' : 'Cleared ✓'}`);
  
  // Verify other tokens still exist
  console.log('\n6. Verifying other tokens are unaffected...');
  for (const testToken of testTokens) {
    if (testToken.domain !== 'dev1.example.com') {
      const retrieved = await chrome.runtime.sendMessage({
        type: 'GET_STORED_TOKEN',
        domain: testToken.domain
      });
      console.log(`   Token for ${testToken.domain}: ${retrieved?.token ? 'Still exists ✓' : 'Missing ✗'}`);
    }
  }
  
  console.log('\n=== Test Complete ===');
  console.log('To manually inspect storage, run: chrome.storage.local.get(null, console.log)');
}

// Run the test
testDomainTokens().catch(console.error);
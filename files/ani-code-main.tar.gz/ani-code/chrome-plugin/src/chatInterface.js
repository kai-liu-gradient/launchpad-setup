// Chat Interface for AniCode Chrome Extension
export class ChatInterface {
  constructor() {
    this.isOpen = false;
    this.messages = [];
    this.selectedElements = [];
    this.chatContainer = null;
  }

  open(selectedElements = []) {
    console.log('[AniCode Chat] Opening chat interface with', selectedElements.length, 'selected elements');
    this.selectedElements = selectedElements;
    
    if (this.isOpen) {
      this.focus();
      return;
    }
    
    this.createChatUI();
    this.isOpen = true;
    
    // Add selected elements as context if any
    if (selectedElements.length > 0) {
      this.addSystemMessage(`Context: ${selectedElements.length} elements selected from the page`);
      this.addElementsToContext(selectedElements);
    }
  }

  createChatUI() {
    // Create overlay
    const overlay = document.createElement('div');
    overlay.id = 'anicode-chat-overlay';
    overlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      z-index: 2147483645;
      display: flex;
      align-items: center;
      justify-content: center;
      animation: fadeIn 0.2s ease;
    `;
    
    // Create chat container
    this.chatContainer = document.createElement('div');
    this.chatContainer.id = 'anicode-chat-container';
    this.chatContainer.innerHTML = `
      <style>
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        
        @keyframes slideUp {
          from { transform: translateY(20px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        
        #anicode-chat-container {
          width: 90%;
          max-width: 600px;
          height: 70vh;
          background: white;
          border-radius: 12px;
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
          display: flex;
          flex-direction: column;
          animation: slideUp 0.3s ease;
          font-family: system-ui, -apple-system, sans-serif;
        }
        
        .chat-header {
          padding: 16px 20px;
          border-bottom: 1px solid #e2e8f0;
          display: flex;
          justify-content: space-between;
          align-items: center;
          background: #2563eb;
          color: white;
          border-radius: 12px 12px 0 0;
        }
        
        .chat-header h2 {
          margin: 0;
          font-size: 18px;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        
        .chat-header button {
          background: transparent;
          border: none;
          color: white;
          font-size: 24px;
          cursor: pointer;
          padding: 0;
          width: 30px;
          height: 30px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 4px;
          transition: background 0.2s;
        }
        
        .chat-header button:hover {
          background: rgba(255, 255, 255, 0.2);
        }
        
        .chat-messages {
          flex: 1;
          overflow-y: auto;
          padding: 20px;
          display: flex;
          flex-direction: column;
          gap: 12px;
        }
        
        .message {
          padding: 10px 14px;
          border-radius: 8px;
          max-width: 80%;
          word-wrap: break-word;
        }
        
        .message.user {
          align-self: flex-end;
          background: #2563eb;
          color: white;
        }
        
        .message.assistant {
          align-self: flex-start;
          background: #f1f5f9;
          color: #1e293b;
        }
        
        .message.system {
          align-self: center;
          background: #fef3c7;
          color: #92400e;
          font-size: 12px;
          max-width: 90%;
          text-align: center;
        }
        
        .element-context {
          background: #f8fafc;
          border: 1px solid #cbd5e1;
          border-radius: 4px;
          padding: 8px;
          margin: 4px 0;
          font-size: 11px;
          font-family: monospace;
          color: #475569;
        }
        
        .chat-input-container {
          padding: 16px;
          border-top: 1px solid #e2e8f0;
          display: flex;
          gap: 8px;
        }
        
        .chat-input {
          flex: 1;
          padding: 10px 14px;
          border: 1px solid #cbd5e1;
          border-radius: 6px;
          font-size: 14px;
          outline: none;
          transition: border-color 0.2s;
        }
        
        .chat-input:focus {
          border-color: #2563eb;
        }
        
        .chat-send-btn {
          padding: 10px 20px;
          background: #2563eb;
          color: white;
          border: none;
          border-radius: 6px;
          cursor: pointer;
          font-size: 14px;
          font-weight: 500;
          transition: background 0.2s;
        }
        
        .chat-send-btn:hover {
          background: #1d4ed8;
        }
        
        .chat-send-btn:disabled {
          background: #94a3b8;
          cursor: not-allowed;
        }
        
        .task-toggle {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 8px 0;
        }
        
        .task-toggle input {
          width: 18px;
          height: 18px;
          cursor: pointer;
        }
        
        .task-toggle label {
          font-size: 14px;
          cursor: pointer;
        }
        
        .typing-indicator {
          display: flex;
          gap: 4px;
          padding: 10px 14px;
          background: #f1f5f9;
          border-radius: 8px;
          width: fit-content;
        }
        
        .typing-indicator span {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #64748b;
          animation: typing 1.4s infinite;
        }
        
        .typing-indicator span:nth-child(2) {
          animation-delay: 0.2s;
        }
        
        .typing-indicator span:nth-child(3) {
          animation-delay: 0.4s;
        }
        
        @keyframes typing {
          0%, 60%, 100% {
            transform: translateY(0);
            opacity: 0.5;
          }
          30% {
            transform: translateY(-10px);
            opacity: 1;
          }
        }
      </style>
      
      <div class="chat-header">
        <h2>
          <span>🤖</span>
          <span>AniCode Assistant</span>
        </h2>
        <button id="close-chat-btn" title="Close">✕</button>
      </div>
      
      <div class="chat-messages" id="chat-messages">
        <div class="message assistant">
          Hello! I'm connected to your AniCode project. How can I help you today?
        </div>
      </div>
      
      <div class="chat-input-container">
        <input 
          type="text" 
          class="chat-input" 
          id="chat-input" 
          placeholder="Type your message or paste element references..."
          autofocus
        />
        <button class="chat-send-btn" id="chat-send-btn">Send</button>
      </div>
    `;
    
    overlay.appendChild(this.chatContainer);
    document.body.appendChild(overlay);
    
    // Add event handlers
    document.getElementById('close-chat-btn').addEventListener('click', () => this.close());
    document.getElementById('chat-send-btn').addEventListener('click', () => this.sendMessage());
    document.getElementById('chat-input').addEventListener('keypress', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        this.sendMessage();
      }
    });
    
    // Close on overlay click
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        this.close();
      }
    });
  }

  addElementsToContext(elements) {
    const contextDiv = document.createElement('div');
    contextDiv.className = 'element-context';
    
    const contextText = elements.map((el, index) => {
      return `[${index + 1}] ${el.tagName}${el.id ? '#' + el.id : ''} - "${el.text?.substring(0, 50)}..."`;
    }).join('\n');
    
    contextDiv.textContent = contextText;
    document.getElementById('chat-messages').appendChild(contextDiv);
  }

  sendMessage() {
    const input = document.getElementById('chat-input');
    const message = input.value.trim();
    
    if (!message) return;
    
    console.log('[AniCode Chat] Sending message:', message);
    
    // Add user message to UI
    this.addMessage(message, 'user');
    
    // Clear input
    input.value = '';
    
    // Show typing indicator
    this.showTypingIndicator();
    
    // Prepare the message with context
    const messageData = {
      type: 'CHAT_MESSAGE',
      message: message,
      context: {
        selectedElements: this.selectedElements,
        timestamp: Date.now()
      }
    };
    
    // Send to background script
    chrome.runtime.sendMessage(messageData, (response) => {
      this.hideTypingIndicator();
      
      if (chrome.runtime.lastError) {
        console.error('[AniCode Chat] Error:', chrome.runtime.lastError);
        this.addMessage('Error: Failed to send message', 'system');
        return;
      }
      
      if (response && response.reply) {
        this.addMessage(response.reply, 'assistant');
      } else {
        // For now, show a placeholder response
        this.addMessage('Message sent to AniCode. Feature in development.', 'assistant');
      }
    });
  }

  addMessage(text, type = 'user') {
    const messagesContainer = document.getElementById('chat-messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}`;
    messageDiv.textContent = text;
    messagesContainer.appendChild(messageDiv);
    
    // Scroll to bottom
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }

  addSystemMessage(text) {
    this.addMessage(text, 'system');
  }

  showTypingIndicator() {
    const messagesContainer = document.getElementById('chat-messages');
    const indicator = document.createElement('div');
    indicator.className = 'typing-indicator';
    indicator.id = 'typing-indicator';
    indicator.innerHTML = '<span></span><span></span><span></span>';
    messagesContainer.appendChild(indicator);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }

  hideTypingIndicator() {
    const indicator = document.getElementById('typing-indicator');
    if (indicator) {
      indicator.remove();
    }
  }

  close() {
    console.log('[AniCode Chat] Closing chat interface');
    const overlay = document.getElementById('anicode-chat-overlay');
    if (overlay) {
      overlay.style.animation = 'fadeOut 0.2s ease';
      setTimeout(() => {
        overlay.remove();
        this.isOpen = false;
        this.messages = [];
        this.selectedElements = [];
      }, 200);
    }
  }

  focus() {
    const input = document.getElementById('chat-input');
    if (input) {
      input.focus();
    }
  }
}

// Add fade out animation
if (!document.getElementById('anicode-chat-animations')) {
  const style = document.createElement('style');
  style.id = 'anicode-chat-animations';
  style.textContent = `
    @keyframes fadeOut {
      from { opacity: 1; }
      to { opacity: 0; }
    }
  `;
  document.head.appendChild(style);
}
// Task management for AniCode operations
export class TaskManager {
  constructor() {
    this.tasks = new Map(); // tabId -> tasks array
  }

  addTask(tabId, task) {
    if (!this.tasks.has(tabId)) {
      this.tasks.set(tabId, []);
    }
    
    const taskWithMeta = {
      ...task,
      id: this.generateTaskId(),
      createdAt: Date.now(),
      status: 'pending'
    };
    
    this.tasks.get(tabId).push(taskWithMeta);
    return taskWithMeta;
  }

  updateTask(tabId, taskUpdate) {
    const tasks = this.tasks.get(tabId);
    if (!tasks) return null;
    
    const taskIndex = tasks.findIndex(t => t.id === taskUpdate.id);
    if (taskIndex === -1) {
      // New task from AniCode
      this.addTask(tabId, taskUpdate);
      return taskUpdate;
    }
    
    tasks[taskIndex] = {
      ...tasks[taskIndex],
      ...taskUpdate,
      updatedAt: Date.now()
    };
    
    return tasks[taskIndex];
  }

  getTasks(tabId) {
    return this.tasks.get(tabId) || [];
  }

  getTask(tabId, taskId) {
    const tasks = this.tasks.get(tabId);
    return tasks?.find(t => t.id === taskId);
  }

  removeTask(tabId, taskId) {
    const tasks = this.tasks.get(tabId);
    if (!tasks) return false;
    
    const index = tasks.findIndex(t => t.id === taskId);
    if (index === -1) return false;
    
    tasks.splice(index, 1);
    return true;
  }

  clearTasks(tabId) {
    this.tasks.delete(tabId);
  }

  generateTaskId() {
    return `task_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  getActiveTasks(tabId) {
    const tasks = this.getTasks(tabId);
    return tasks.filter(t => t.status === 'in_progress');
  }

  getCompletedTasks(tabId) {
    const tasks = this.getTasks(tabId);
    return tasks.filter(t => t.status === 'completed');
  }

  getFailedTasks(tabId) {
    const tasks = this.getTasks(tabId);
    return tasks.filter(t => t.status === 'failed');
  }

  getTaskStats(tabId) {
    const tasks = this.getTasks(tabId);
    return {
      total: tasks.length,
      pending: tasks.filter(t => t.status === 'pending').length,
      inProgress: tasks.filter(t => t.status === 'in_progress').length,
      completed: tasks.filter(t => t.status === 'completed').length,
      failed: tasks.filter(t => t.status === 'failed').length
    };
  }
}
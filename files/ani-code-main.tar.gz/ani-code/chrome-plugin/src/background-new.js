// Background service worker for AniCode Chrome Extension
import { WebSocketBridge } from './wsBridge.js';
import { TaskManager } from './taskManager.js';

class AniCodeBridge {
  constructor() {
    this.wsBridge = null;
    this.taskManager = new TaskManager();
    this.currentSession = null;
    this.init();
  }

  async init() {
    // Listen for extension installation
    chrome.runtime.onInstalled.addListener(() => {
      console.log('AniCode Bridge installed');
      this.setupContextMenus();
    });

    // Listen for messages from content scripts and popup
    chrome.runtime.onMessage.addListener(this.handleMessage.bind(this));

    // Listen for tab updates
    chrome.tabs.onUpdated.addListener(this.handleTabUpdate.bind(this));
    
    // Listen for tab removal
    chrome.tabs.onRemoved.addListener(this.handleTabRemoved.bind(this));
  }

  setupContextMenus() {
    chrome.contextMenus.create({
      id: 'anicode-edit',
      title: 'Edit with AniCode',
      contexts: ['page', 'selection']
    });

    chrome.contextMenus.onClicked.addListener((info, tab) => {
      if (info.menuItemId === 'anicode-edit') {
        this.enableEditMode(tab.id);
      }
    });
  }

  async handleMessage(request, sender, sendResponse) {
    try {
      switch (request.type) {
        case 'CONNECT':
          await this.handleConnect(request);
          sendResponse({ success: true });
          break;
          
        case 'DISCONNECT':
          await this.handleDisconnect();
          sendResponse({ success: true });
          break;
          
        case 'CHECK_CONNECTION':
          sendResponse({ connected: this.isConnected() });
          break;
          
        case 'SEND_PROMPT':
          await this.sendPrompt(request.prompt, sender.tab?.id);
          sendResponse({ success: true });
          break;
          
        case 'GET_TASKS':
          const tasks = await this.taskManager.getTasks(sender.tab?.id);
          sendResponse({ tasks });
          break;
          
        case 'GET_GIT_LOG':
          const gitLog = await this.getGitLog();
          sendResponse({ gitLog });
          break;
          
        case 'ENABLE_EDIT_MODE':
          await this.enableEditMode(sender.tab?.id);
          sendResponse({ success: true });
          break;
          
        case 'DISABLE_EDIT_MODE':
          await this.disableEditMode(sender.tab?.id);
          sendResponse({ success: true });
          break;
          
        default:
          sendResponse({ error: 'Unknown message type' });
      }
    } catch (error) {
      console.error('Error handling message:', error);
      sendResponse({ error: error.message });
    }
    return true; // Keep message channel open for async response
  }

  async handleConnect(request) {
    const { token, payload } = request;
    
    if (!token || !payload) {
      throw new Error('Invalid connection request');
    }
    
    // Extract server URL from payload
    const serverUrl = payload.serverUrl || 'ws://localhost:6502';
    
    // Create WebSocket connection with token
    this.wsBridge = new WebSocketBridge(serverUrl, token);
    
    this.wsBridge.on('message', (data) => {
      this.handleAniCodeMessage(data);
    });
    
    this.wsBridge.on('task-update', (task) => {
      this.handleTaskUpdate(task);
    });
    
    this.wsBridge.on('git-update', (gitData) => {
      this.handleGitUpdate(gitData);
    });
    
    this.wsBridge.on('connected', () => {
      this.currentSession = {
        token,
        payload,
        connectedAt: Date.now()
      };
      this.notifyConnectionStatus(true);
    });
    
    this.wsBridge.on('disconnected', () => {
      this.currentSession = null;
      this.notifyConnectionStatus(false);
    });
    
    await this.wsBridge.connect();
  }

  async handleDisconnect() {
    if (this.wsBridge) {
      this.wsBridge.disconnect();
      this.wsBridge = null;
    }
    this.currentSession = null;
    this.notifyConnectionStatus(false);
  }

  isConnected() {
    return this.wsBridge?.isConnected || false;
  }

  async sendPrompt(prompt, tabId) {
    if (!this.isConnected()) {
      throw new Error('Not connected to AniCode');
    }
    
    // Get current tab info
    let context = {};
    if (tabId) {
      const tab = await chrome.tabs.get(tabId);
      context.url = tab.url;
      context.title = tab.title;
      
      // Get selected text if any
      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId },
          func: () => window.getSelection()?.toString() || ''
        });
        context.selection = results[0]?.result || '';
      } catch (e) {
        // Tab might not allow script injection
      }
    }
    
    // Send prompt to AniCode
    this.wsBridge.send({
      type: 'PROMPT',
      prompt,
      context,
      timestamp: Date.now()
    });
  }

  async getGitLog() {
    if (!this.isConnected()) {
      throw new Error('Not connected to AniCode');
    }
    
    return new Promise((resolve) => {
      this.wsBridge.once('git-log-response', (data) => {
        resolve(data);
      });
      
      this.wsBridge.send({
        type: 'GET_GIT_LOG'
      });
      
      // Timeout after 5 seconds
      setTimeout(() => resolve([]), 5000);
    });
  }

  async enableEditMode(tabId) {
    if (!tabId) return;
    
    // Inject edit mode scripts
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ['src/editMode.js']
      });
    } catch (e) {
      // Script might already be injected
    }
    
    // Notify content script
    this.notifyTab(tabId, { type: 'ENABLE_EDIT_MODE' });
  }

  async disableEditMode(tabId) {
    if (!tabId) return;
    this.notifyTab(tabId, { type: 'DISABLE_EDIT_MODE' });
  }

  handleAniCodeMessage(data) {
    // Broadcast to all tabs
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        this.notifyTab(tab.id, {
          type: 'ANICODE_MESSAGE',
          data
        });
      });
    });
  }

  handleTaskUpdate(task) {
    // Store task
    this.taskManager.updateTask(0, task); // Use 0 as global tab ID
    
    // Notify all tabs and popup
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        this.notifyTab(tab.id, { type: 'TASK_UPDATE', task });
      });
    });
    
    // Also notify popup if open
    chrome.runtime.sendMessage({ type: 'TASK_UPDATE', task }).catch(() => {
      // Popup might not be open
    });
  }

  handleGitUpdate(gitData) {
    // Notify all tabs and popup
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        this.notifyTab(tab.id, { type: 'GIT_UPDATE', gitData });
      });
    });
    
    chrome.runtime.sendMessage({ type: 'GIT_UPDATE', gitData }).catch(() => {
      // Popup might not be open
    });
  }

  handleTabUpdate(tabId, changeInfo, tab) {
    if (changeInfo.status === 'complete' && this.isConnected()) {
      // Notify AniCode of page navigation
      this.wsBridge.send({
        type: 'PAGE_NAVIGATED',
        url: tab.url,
        title: tab.title
      });
    }
  }

  handleTabRemoved(tabId) {
    // Clean up any tab-specific data
    this.taskManager.clearTasks(tabId);
  }

  notifyTab(tabId, message) {
    chrome.tabs.sendMessage(tabId, message).catch(err => {
      // Tab might not have content script injected
    });
  }

  notifyConnectionStatus(connected) {
    // Notify popup
    chrome.runtime.sendMessage({ 
      type: 'CONNECTION_STATUS', 
      connected 
    }).catch(() => {
      // Popup might not be open
    });
    
    // Update extension icon
    chrome.action.setBadgeText({
      text: connected ? '●' : ''
    });
    
    chrome.action.setBadgeBackgroundColor({
      color: connected ? '#4ade80' : '#ef4444'
    });
  }
}

// Initialize the bridge
const aniCodeBridge = new AniCodeBridge();

export default aniCodeBridge;
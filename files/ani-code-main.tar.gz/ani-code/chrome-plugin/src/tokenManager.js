// Token management for AniCode connections
export class TokenManager {
  constructor() {
    this.storageKey = 'anicode_tokens';
  }

  async getToken(projectId) {
    const tokens = await this.getAllTokens();
    return tokens[projectId];
  }

  async setToken(projectId, token, url) {
    const tokens = await this.getAllTokens();
    tokens[projectId] = {
      token,
      url,
      createdAt: Date.now()
    };
    await chrome.storage.local.set({ [this.storageKey]: tokens });
  }

  async removeToken(projectId) {
    const tokens = await this.getAllTokens();
    delete tokens[projectId];
    await chrome.storage.local.set({ [this.storageKey]: tokens });
  }

  async getAllTokens() {
    const result = await chrome.storage.local.get(this.storageKey);
    return result[this.storageKey] || {};
  }

  async validateToken(projectId, token) {
    try {
      const tokenData = await this.getToken(projectId);
      if (!tokenData) return false;
      
      // Check token expiry (24 hours)
      const expiryTime = 24 * 60 * 60 * 1000;
      if (Date.now() - tokenData.createdAt > expiryTime) {
        await this.removeToken(projectId);
        return false;
      }
      
      return tokenData.token === token;
    } catch (error) {
      console.error('Token validation error:', error);
      return false;
    }
  }

  async generateConnectionUrl(projectId, baseUrl) {
    const token = await this.getToken(projectId);
    if (!token) {
      throw new Error('No token found for project');
    }
    
    const url = new URL(baseUrl || token.url);
    url.searchParams.set('token', token.token);
    url.searchParams.set('projectId', projectId);
    return url.toString();
  }
}
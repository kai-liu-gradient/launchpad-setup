// Injected edit mode script for AniCode Chrome Extension
// This is only injected when edit mode is activated

(function() {
  let isActive = false;
  let selectedElement = null;
  let overlay = null;
  let selectionInfo = null;

  // Listen for activation messages from content script
  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    
    if (event.data.type === 'ANICODE_ACTIVATE_EDIT_MODE') {
      activateEditMode();
    } else if (event.data.type === 'ANICODE_DEACTIVATE_EDIT_MODE') {
      deactivateEditMode();
    }
  });

  function activateEditMode() {
    if (isActive) return;
    isActive = true;
    
    // Create minimal overlay
    createOverlay();
    
    // Add hover and click handlers
    document.addEventListener('mouseover', handleMouseOver, true);
    document.addEventListener('mouseout', handleMouseOut, true);
    document.addEventListener('click', handleClick, true);
    
    // Add keyboard shortcuts
    document.addEventListener('keydown', handleKeydown, true);
    
    document.body.classList.add('anicode-edit-mode');
  }

  function deactivateEditMode() {
    if (!isActive) return;
    isActive = false;
    
    // Remove handlers
    document.removeEventListener('mouseover', handleMouseOver, true);
    document.removeEventListener('mouseout', handleMouseOut, true);
    document.removeEventListener('click', handleClick, true);
    document.removeEventListener('keydown', handleKeydown, true);
    
    // Remove overlay
    if (overlay) {
      overlay.remove();
      overlay = null;
    }
    
    // Clear selection
    if (selectedElement) {
      selectedElement.classList.remove('anicode-selected');
      selectedElement = null;
    }
    
    document.body.classList.remove('anicode-edit-mode');
  }

  function createOverlay() {
    overlay = document.createElement('div');
    overlay.className = 'anicode-edit-overlay';
    overlay.innerHTML = `
      <div class="anicode-edit-bar">
        <div class="anicode-logo">🎯 AniCode Edit Mode</div>
        <div class="anicode-selection-display" id="selectionDisplay">
          Click an element to select
        </div>
        <div class="anicode-actions">
          <button id="anicode-prompt-btn" disabled>Prompt with Selection</button>
          <button id="anicode-copy-btn" disabled>Copy Info</button>
          <button id="anicode-exit-btn">Exit</button>
        </div>
      </div>
    `;
    
    document.body.appendChild(overlay);
    
    selectionInfo = overlay.querySelector('#selectionDisplay');
    
    overlay.querySelector('#anicode-prompt-btn').onclick = promptWithSelection;
    overlay.querySelector('#anicode-copy-btn').onclick = copySelectionInfo;
    overlay.querySelector('#anicode-exit-btn').onclick = () => {
      chrome.runtime.sendMessage({ type: 'DISABLE_EDIT_MODE' });
    };
  }

  function handleMouseOver(e) {
    if (!isActive) return;
    if (isOverlayElement(e.target)) return;
    
    e.target.classList.add('anicode-hover');
    e.stopPropagation();
  }

  function handleMouseOut(e) {
    if (!isActive) return;
    if (isOverlayElement(e.target)) return;
    
    e.target.classList.remove('anicode-hover');
    e.stopPropagation();
  }

  function handleClick(e) {
    if (!isActive) return;
    if (isOverlayElement(e.target)) return;
    
    e.preventDefault();
    e.stopPropagation();
    
    // Clear previous selection
    if (selectedElement) {
      selectedElement.classList.remove('anicode-selected');
    }
    
    // Select new element
    selectedElement = e.target;
    selectedElement.classList.add('anicode-selected');
    
    // Extract and display element info
    const info = extractElementInfo(selectedElement);
    displaySelectionInfo(info);
    
    // Enable action buttons
    overlay.querySelector('#anicode-prompt-btn').disabled = false;
    overlay.querySelector('#anicode-copy-btn').disabled = false;
  }

  function handleKeydown(e) {
    if (!isActive) return;
    
    // ESC to exit edit mode
    if (e.key === 'Escape') {
      chrome.runtime.sendMessage({ type: 'DISABLE_EDIT_MODE' });
      e.preventDefault();
    }
    
    // Enter to prompt with selection
    if (e.key === 'Enter' && selectedElement) {
      promptWithSelection();
      e.preventDefault();
    }
  }

  function extractElementInfo(element) {
    const info = {
      tagName: element.tagName.toLowerCase(),
      id: element.id,
      classes: Array.from(element.classList).filter(c => !c.startsWith('anicode-')),
      xpath: getXPath(element),
      selector: generateSelector(element),
      text: element.textContent?.substring(0, 100),
      attributes: {},
      component: null,
      source: null
    };
    
    // Extract AniCode metadata
    const acAttrs = {};
    for (const attr of element.attributes) {
      if (attr.name.startsWith('data-ac-')) {
        const key = attr.name.replace('data-ac-', '');
        acAttrs[key] = attr.value;
      } else if (!attr.name.startsWith('class') && !attr.name.startsWith('style')) {
        info.attributes[attr.name] = attr.value;
      }
    }
    
    if (acAttrs.component) {
      info.component = acAttrs.component;
      info.source = acAttrs.source || null;
      info.line = acAttrs.line || null;
      info.props = acAttrs.props || null;
    }
    
    // Try to get React component info
    const reactInfo = getReactInfo(element);
    if (reactInfo) {
      info.react = reactInfo;
    }
    
    // Try to get Vue component info
    const vueInfo = getVueInfo(element);
    if (vueInfo) {
      info.vue = vueInfo;
    }
    
    return info;
  }

  function getXPath(element) {
    if (element.id !== '') {
      return `//*[@id="${element.id}"]`;
    }
    
    const parts = [];
    while (element && element.nodeType === Node.ELEMENT_NODE) {
      let index = 0;
      let sibling = element.previousSibling;
      while (sibling) {
        if (sibling.nodeType === Node.ELEMENT_NODE && sibling.tagName === element.tagName) {
          index++;
        }
        sibling = sibling.previousSibling;
      }
      
      const tagName = element.tagName.toLowerCase();
      const xpathIndex = index > 0 ? `[${index + 1}]` : '';
      parts.unshift(`${tagName}${xpathIndex}`);
      
      element = element.parentElement;
    }
    
    return '/' + parts.join('/');
  }

  function generateSelector(element) {
    if (element.id) {
      return `#${element.id}`;
    }
    
    const path = [];
    while (element && element.nodeType === Node.ELEMENT_NODE) {
      let selector = element.tagName.toLowerCase();
      
      if (element.id) {
        selector = `#${element.id}`;
        path.unshift(selector);
        break;
      }
      
      if (element.className && typeof element.className === 'string') {
        const classes = element.className.split(' ')
          .filter(c => c && !c.startsWith('anicode-'))
          .join('.');
        if (classes) {
          selector += `.${classes}`;
        }
      }
      
      path.unshift(selector);
      element = element.parentElement;
    }
    
    return path.join(' > ');
  }

  function getReactInfo(element) {
    const key = Object.keys(element).find(key => 
      key.startsWith('__reactInternalInstance$') || 
      key.startsWith('__reactFiber$')
    );
    
    if (!key) return null;
    
    const fiber = element[key];
    if (!fiber) return null;
    
    return {
      componentName: fiber.elementType?.name || fiber.type?.name || 'Unknown',
      props: fiber.memoizedProps,
      state: fiber.memoizedState
    };
  }

  function getVueInfo(element) {
    if (!element.__vue__) return null;
    
    const instance = element.__vue__;
    return {
      componentName: instance.$options.name || instance.$options._componentTag || 'Unknown',
      props: instance.$props,
      data: instance.$data
    };
  }

  function displaySelectionInfo(info) {
    let display = `<strong>${info.tagName}</strong>`;
    
    if (info.id) {
      display += ` <span class="info-id">#${info.id}</span>`;
    }
    
    if (info.classes.length > 0) {
      display += ` <span class="info-class">.${info.classes.join('.')}</span>`;
    }
    
    if (info.component) {
      display += ` <span class="info-component">📦 ${info.component}</span>`;
    } else if (info.react) {
      display += ` <span class="info-component">⚛️ ${info.react.componentName}</span>`;
    } else if (info.vue) {
      display += ` <span class="info-component">🅅 ${info.vue.componentName}</span>`;
    }
    
    if (info.source) {
      display += ` <span class="info-source">📄 ${info.source}:${info.line || '?'}</span>`;
    }
    
    selectionInfo.innerHTML = display;
  }

  function promptWithSelection() {
    if (!selectedElement) return;
    
    const info = extractElementInfo(selectedElement);
    
    // Build prompt template
    const prompt = buildPromptTemplate(info);
    
    // Send to background script
    chrome.runtime.sendMessage({
      type: 'PROMPT_WITH_ELEMENT',
      elementInfo: info,
      prompt: prompt,
      pageUrl: window.location.href,
      pageTitle: document.title
    });
  }

  function buildPromptTemplate(info) {
    let prompt = `Regarding the ${info.tagName} element`;
    
    if (info.component) {
      prompt += ` (${info.component} component`;
      if (info.source) {
        prompt += ` at ${info.source}:${info.line || '?'}`;
      }
      prompt += ')';
    } else if (info.react) {
      prompt += ` (React: ${info.react.componentName})`;
    } else if (info.vue) {
      prompt += ` (Vue: ${info.vue.componentName})`;
    }
    
    prompt += `\nPage: ${window.location.pathname}\n`;
    prompt += `XPath: ${info.xpath}\n`;
    prompt += `Selector: ${info.selector}\n`;
    
    if (info.text) {
      prompt += `\nContent: "${info.text}..."\n`;
    }
    
    prompt += '\n[Describe what you want to do with this element]';
    
    return prompt;
  }

  function copySelectionInfo() {
    if (!selectedElement) return;
    
    const info = extractElementInfo(selectedElement);
    const text = JSON.stringify(info, null, 2);
    
    navigator.clipboard.writeText(text).then(() => {
      // Show temporary success message
      const btn = overlay.querySelector('#anicode-copy-btn');
      const originalText = btn.textContent;
      btn.textContent = 'Copied!';
      setTimeout(() => {
        btn.textContent = originalText;
      }, 2000);
    });
  }

  function isOverlayElement(element) {
    return element.closest('.anicode-edit-overlay') !== null;
  }
})();
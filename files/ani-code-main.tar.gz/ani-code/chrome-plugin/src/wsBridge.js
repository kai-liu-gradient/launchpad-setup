// WebSocket bridge for real-time communication with AniCode
export class WebSocketBridge extends EventTarget {
  constructor(url, token) {
    super();
    this.url = url;
    this.token = token;
    this.ws = null;
    this.pingInterval = null;
    this.messageQueue = [];
    this.isConnected = false;
    this.hasConnected = false;
    this.authenticationFailed = false; // Track if auth failed
  }

  async connect() {
    console.log('[WebSocketBridge] Starting connection to:', this.url);
    console.log('[WebSocketBridge] Token present:', !!this.token);
    
    return new Promise((resolve, reject) => {
      try {
        // Add token to URL for authentication
        const wsUrl = new URL(this.url);
        console.log('[WebSocketBridge] Parsed URL:', wsUrl.toString());
        wsUrl.searchParams.set('token', this.token);
        
        console.log('WebSocketBridge: Attempting to connect to:', wsUrl.origin + wsUrl.pathname);
        
        // Set up connection timeout
        const connectionTimeout = setTimeout(() => {
          if (!this.isConnected) {
            this.ws?.close();
            reject(new Error('WebSocket connection timeout after 10 seconds'));
          }
        }, 10000);
        
        this.ws = new WebSocket(wsUrl.toString());
        
        this.ws.onopen = () => {
          clearTimeout(connectionTimeout);
          console.log('WebSocket connected to AniCode');
          this.isConnected = true;
          this.hasConnected = true;
          this.startPing();
          this.flushMessageQueue();
          this.emit('connected');
          resolve();
        };
        
        this.ws.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);
            this.handleMessage(data);
          } catch (error) {
            console.error('Failed to parse WebSocket message:', error);
          }
        };
        
        this.ws.onerror = (error) => {
          clearTimeout(connectionTimeout);
          console.error('WebSocket error event:', error);
          
          // Create a more descriptive error message
          let errorMessage = 'WebSocket connection failed';
          
          // Check for common error scenarios
          if (error.message) {
            errorMessage = error.message;
          } else if (error.type === 'error') {
            // Check if it's a CSP violation
            errorMessage = 'WebSocket connection blocked. This might be due to Content Security Policy restrictions. Please reload the extension.';
          }
          
          const detailedError = new Error(errorMessage);
          detailedError.originalError = error;
          
          this.emit('error', detailedError);
          
          // If we haven't connected yet, reject the promise
          if (!this.isConnected) {
            reject(detailedError);
          }
        };
        
        this.ws.onclose = (event) => {
          clearTimeout(connectionTimeout);
          console.log('WebSocket disconnected with code:', event.code, 'reason:', event.reason);
          
          // Log specific close codes for debugging
          const closeCodeMessages = {
            1000: 'Normal closure',
            1001: 'Endpoint is going away',
            1002: 'Protocol error',
            1003: 'Unsupported data type',
            1006: 'Abnormal closure - no close frame received',
            1007: 'Invalid frame payload data',
            1008: 'Policy violation',
            1009: 'Message too large',
            1010: 'Mandatory extension missing',
            1011: 'Internal server error',
            1015: 'TLS handshake failure'
          };
          
          console.log('Close code meaning:', closeCodeMessages[event.code] || 'Unknown close code');
          
          this.isConnected = false;
          this.stopPing();
          this.emit('disconnected');
          
          // If connection was never established, reject with error
          // Use hasConnected flag to track if we ever successfully connected
          if (!this.hasConnected && event.code !== 1000) {
            let errorMessage = 'WebSocket connection closed unexpectedly';
            let isAuthError = false;
            
            if (event.reason) {
              errorMessage += ': ' + event.reason;
              console.error('Server rejection reason:', event.reason);
              
              // Check for authentication-specific errors
              const authErrorKeywords = ['Token', 'auth', 'Auth', 'JWT', 'Invalid token', 'expired', 'algorithm', 'signature'];
              isAuthError = authErrorKeywords.some(keyword => event.reason.includes(keyword));
              
              if (isAuthError) {
                console.error('Authentication error detected:', event.reason);
                this.authenticationFailed = true;
                errorMessage = `Authentication failed: ${event.reason}. Please generate a new token.`;
              }
            } else if (event.code === 1006) {
              errorMessage = 'WebSocket connection failed. Check if the server is running and accessible.';
            } else if (event.code === 1008) {
              // Code 1008 often indicates policy violation which could be auth related
              errorMessage = `Server rejected connection: ${event.reason || 'Policy violation'}`;
              if (!event.reason || event.reason.includes('Token') || event.reason.includes('auth')) {
                isAuthError = true;
                this.authenticationFailed = true;
                errorMessage = 'Authentication failed. Please generate a new token.';
              }
            }
            
            reject(new Error(errorMessage));
          } else if (this.hasConnected) {
            // Don't attempt to reconnect - just notify that connection was lost
            console.log('WebSocket connection lost. User must manually reconnect.');
            this.emit('disconnected');
          }
        };
        
      } catch (error) {
        console.error('WebSocketBridge: Error creating WebSocket:', error);
        reject(new Error(`Failed to create WebSocket connection: ${error.message}`));
      }
    });
  }

  disconnect() {
    this.stopPing();
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this.isConnected = false;
  }

  send(data) {
    const message = typeof data === 'string' ? data : JSON.stringify(data);
    
    if (this.isConnected && this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(message);
    } else {
      // Queue message for later sending
      this.messageQueue.push(message);
    }
  }

  handleMessage(data) {
    console.log('[WebSocketBridge] Received message type:', data.type);
    switch (data.type) {
      case 'PONG':
        // Handle ping response - emit event for latency calculation
        console.log('[WebSocketBridge] Received PONG response');
        this.emit('pong', data);
        break;
        
      case 'TASK_UPDATE':
        this.emit('task-update', data.task);
        break;
        
      case 'task_created':
        console.log('[WebSocketBridge] Received task_created response');
        this.emit('task_created', data);
        break;
        
      case 'GIT_UPDATE':
        this.emit('git-update', data.gitData);
        break;
        
      case 'GIT_LOG_RESPONSE':
        console.log('[WebSocketBridge] Received GIT_LOG_RESPONSE');
        this.emit('git-log-response', data);
        break;
        
      case 'task-list-response':
      case 'TASK_LIST_RESPONSE':
        console.log('[WebSocketBridge] Received task-list-response with', data.tasks?.length || 0, 'tasks');
        this.emit('task-list-response', data);
        break;
        
      case 'PROMPT_RESPONSE':
        this.emit('prompt-response', data.response);
        break;
        
      case 'ERROR':
        this.emit('error', new Error(data.message));
        break;
        
      default:
        this.emit('message', data);
    }
  }

  startPing() {
    this.pingInterval = setInterval(() => {
      if (this.isConnected) {
        this.send({ type: 'PING' });
      }
    }, 30000); // Ping every 30 seconds
  }

  stopPing() {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
  }

  // Removed attemptReconnect method - no automatic reconnection

  flushMessageQueue() {
    while (this.messageQueue.length > 0) {
      const message = this.messageQueue.shift();
      this.ws.send(message);
    }
  }

  emit(eventName, data) {
    this.dispatchEvent(new CustomEvent(eventName, { detail: data }));
  }

  on(eventName, handler) {
    this.addEventListener(eventName, (e) => handler(e.detail));
  }

  once(eventName, handler) {
    const onceHandler = (e) => {
      handler(e.detail);
      this.removeEventListener(eventName, onceHandler);
    };
    this.addEventListener(eventName, onceHandler);
  }
}
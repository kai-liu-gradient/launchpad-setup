// Minimal content script for AniCode Chrome Extension
// Only listens for messages, doesn't inject anything until edit mode is enabled

(function() {
  let editModeInjected = false;
  let editModeActive = false;

  // Listen for messages from background script
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    switch (request.type) {
      case 'ENABLE_EDIT_MODE':
        enableEditMode();
        sendResponse({ success: true });
        break;
        
      case 'DISABLE_EDIT_MODE':
        disableEditMode();
        sendResponse({ success: true });
        break;
        
      case 'GET_ELEMENT_INFO':
        // Get element info without injecting edit mode
        const info = getElementAtPoint(request.x, request.y);
        sendResponse(info);
        break;
        
      case 'CHECK_EDIT_MODE':
        sendResponse({ active: editModeActive });
        break;
    }
    return true;
  });

  async function enableEditMode() {
    if (editModeActive) return;
    
    // Inject edit mode scripts only when needed
    if (!editModeInjected) {
      await injectEditMode();
      editModeInjected = true;
    }
    
    // Activate edit mode
    editModeActive = true;
    window.postMessage({ type: 'ANICODE_ACTIVATE_EDIT_MODE' }, '*');
  }

  function disableEditMode() {
    if (!editModeActive) return;
    
    editModeActive = false;
    window.postMessage({ type: 'ANICODE_DEACTIVATE_EDIT_MODE' }, '*');
  }

  async function injectEditMode() {
    // Inject the edit mode script
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('src/editModeInjected.js');
    script.onload = function() {
      this.remove();
    };
    (document.head || document.documentElement).appendChild(script);

    // Inject styles
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = chrome.runtime.getURL('styles/editMode.css');
    document.head.appendChild(link);
  }

  function getElementAtPoint(x, y) {
    const element = document.elementFromPoint(x, y);
    if (!element) return null;
    
    return {
      tagName: element.tagName,
      id: element.id,
      className: element.className,
      xpath: getXPath(element),
      componentInfo: extractComponentInfo(element),
      text: element.textContent?.substring(0, 100)
    };
  }

  function getXPath(element) {
    if (element.id !== '') {
      return `//*[@id="${element.id}"]`;
    }
    
    if (element === document.body) {
      return '/html/body';
    }
    
    let ix = 0;
    const siblings = element.parentNode?.childNodes;
    
    if (siblings) {
      for (let i = 0; i < siblings.length; i++) {
        const sibling = siblings[i];
        if (sibling === element) {
          return getXPath(element.parentNode) + '/' + element.tagName.toLowerCase() + '[' + (ix + 1) + ']';
        }
        if (sibling.nodeType === 1 && sibling.tagName === element.tagName) {
          ix++;
        }
      }
    }
    
    return '';
  }

  function extractComponentInfo(element) {
    const info = {};
    
    // Look for AniCode metadata attributes
    if (element.hasAttribute('data-ac-component')) {
      info.component = element.getAttribute('data-ac-component');
    }
    if (element.hasAttribute('data-ac-source')) {
      info.source = element.getAttribute('data-ac-source');
    }
    if (element.hasAttribute('data-ac-line')) {
      info.line = element.getAttribute('data-ac-line');
    }
    if (element.hasAttribute('data-ac-props')) {
      try {
        info.props = JSON.parse(element.getAttribute('data-ac-props'));
      } catch (e) {
        info.props = element.getAttribute('data-ac-props');
      }
    }
    
    // Look for React fiber
    const reactFiber = getReactFiber(element);
    if (reactFiber) {
      info.react = {
        component: reactFiber.elementType?.name || reactFiber.type?.name,
        props: reactFiber.memoizedProps
      };
    }
    
    // Look for Vue instance
    const vueInstance = element.__vue__;
    if (vueInstance) {
      info.vue = {
        component: vueInstance.$options.name || vueInstance.$options._componentTag,
        props: vueInstance.$props
      };
    }
    
    return Object.keys(info).length > 0 ? info : null;
  }

  function getReactFiber(element) {
    const key = Object.keys(element).find(key => 
      key.startsWith('__reactInternalInstance$') || 
      key.startsWith('__reactFiber$')
    );
    return element[key];
  }
})();
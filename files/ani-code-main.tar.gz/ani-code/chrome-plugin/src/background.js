// Background service worker for AniCode Chrome Extension
console.log('=== BACKGROUND SCRIPT LOADING STARTED ===', new Date().toISOString());

import { TokenManager } from './tokenManager.js';
import { WebSocketBridge } from './wsBridge.js';
import { TaskManager } from './taskManager.js';
import { MessageRouter } from './messageRouter.js';

console.log('=== ALL IMPORTS LOADED SUCCESSFULLY ===');

class AniCodeBridge {
  constructor() {
    console.log('Background: AniCodeBridge initialized at', new Date().toISOString());
    this.tokenManager = new TokenManager();
    this.wsBridge = null;
    this.taskManager = new TaskManager();
    this.connections = new Map(); // tabId -> connection
    this.currentToken = null; // Store current token
    this.pingTimestamps = new Map(); // Store ping timestamps for RTT calculation
    this.messageRouter = new MessageRouter(); // New message router
    this.popupPort = null; // Direct connection to popup
    
    // Keep service worker alive
    this.keepAlive();
    
    this.init();
  }
  
  // Keep service worker alive (Manifest V3 workaround)
  keepAlive() {
    // Send a message to ourselves every 20 seconds to prevent suspension
    setInterval(() => {
      chrome.runtime.sendMessage({ type: 'KEEP_ALIVE' }, () => {
        if (chrome.runtime.lastError) {
          // Expected when no listeners
        }
      });
    }, 20000);
  }

  async init() {
    console.log('Background: Initializing AniCodeBridge...');
    try {
      // Clean up any undefined tokens on startup
      await this.cleanupUndefinedTokens();
      
      // Listen for extension installation
      chrome.runtime.onInstalled.addListener(() => {
        console.log('AniCode Bridge installed');
        this.setupContextMenus();
      });

      // Listen for port connections (persistent connections from popup)
      chrome.runtime.onConnect.addListener((port) => {
        console.log('Background: Port connected:', port.name);
        
        if (port.name === 'popup') {
          this.popupPort = port;
          
          port.onDisconnect.addListener(() => {
            console.log('Background: Popup port disconnected');
            this.popupPort = null;
          });
          
          // Send any queued messages
          port.onMessage.addListener((msg) => {
            console.log('Background: Received message from popup port:', msg);
          });
        }
      });

      // Listen for messages from content scripts and popup
      chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        console.log('Background: Message listener triggered for:', request.type);
        console.log('Background: Full message:', request);
        console.log('Background: Sender:', sender);
        
        // Handle the message without async/await in the listener itself
        // This is Chrome's recommended pattern for async responses
        this.handleMessageWrapper(request, sender, sendResponse);
        
        // Return true synchronously to keep the message channel open
        return true;
      });

      // Listen for tab updates
      chrome.tabs.onUpdated.addListener(this.handleTabUpdate.bind(this));
      
      // Listen for tab removal
      chrome.tabs.onRemoved.addListener(this.handleTabRemoved.bind(this));
      
      console.log('Background: AniCodeBridge initialized successfully');
    } catch (error) {
      console.error('Background: Error during initialization:', error);
    }
  }

  setupContextMenus() {
    chrome.contextMenus.create({
      id: 'anicode-edit',
      title: 'Edit with AniCode',
      contexts: ['page', 'selection']
    });

    chrome.contextMenus.onClicked.addListener((info, tab) => {
      if (info.menuItemId === 'anicode-edit') {
        this.enableEditMode(tab.id);
      }
    });
  }

  // Wrapper to handle async messages properly per Chrome's requirements
  handleMessageWrapper(request, sender, sendResponse) {
    // Execute async operation
    this.handleMessage(request, sender)
      .then(result => {
        console.log('Background: Sending response for', request.type, ':', result);
        // Send the response - this must be called exactly once
        sendResponse(result);
      })
      .catch(error => {
        console.error('Background: Error handling', request.type, ':', error);
        // Send error response - this must be called exactly once
        sendResponse({ success: false, error: error.message });
      });
  }

  async handleMessage(request, sender) {
    console.log('Background: Processing message:', request.type);
    
    switch (request.type) {
      // Health check
      case 'PING_BACKGROUND':
        console.log('Background: Responding to health check');
        return { success: true, message: 'Background script is running', timestamp: Date.now() };
        
      // Simple test
      case 'TEST_SIMPLE':
        console.log('Background: TEST_SIMPLE received with data:', request.data);
        return { success: true, message: 'Test successful', echo: request.data, timestamp: Date.now() };
      
      // Test messages
      case 'TEST_SYNC':
        console.log('Background: Handling TEST_SYNC - VERSION 2.0');
        return { success: true, message: 'Sync test successful (v2.0)', timestamp: Date.now(), version: '2.0' };
        
      case 'TEST_ASYNC':
        console.log('Background: Handling TEST_ASYNC - VERSION 2.0');
        // Simulate async operation with storage
        await new Promise(resolve => setTimeout(resolve, 100));
        const testData = { test: 'data', timestamp: Date.now(), version: '2.0' };
        await new Promise((resolve, reject) => {
          chrome.storage.local.set({ test_async: testData }, () => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
            } else {
              resolve();
            }
          });
        });
        return { success: true, message: 'Async test successful (v2.0)', data: testData };
        
      case 'CONNECT':
        console.log('Background: Handling CONNECT');
        console.log('Background: Connect request details:', {
          url: request.url,
          projectId: request.projectId,
          tabId: request.tabId,
          hasToken: !!request.token,
          hasPayload: !!request.payload
        });
        try {
          // Store token with domain from payload if available
          if (request.token && request.payload) {
            const domain = request.payload.serverUrl ? new URL(request.payload.serverUrl).hostname : null;
            await this.setStoredToken(request.token, request.payload, domain);
          }
          
          console.log('Background: Calling handleConnect...');
          // Use 'popup-connection' for popup connections (no tab context)
          const connectionId = request.tabId || sender.tab?.id || 'popup-connection';
          await this.handleConnect(request, connectionId);
          console.log('Background: handleConnect completed successfully');
          return { success: true, message: 'Connected successfully' };
        } catch (error) {
          console.error('Background: CONNECT failed:', error);
          console.error('Background: Error stack:', error.stack);
          // Return a detailed error message
          return { 
            success: false, 
            error: error.message || 'Connection failed',
            details: {
              type: error.name,
              message: error.message,
              url: request.url,
              stack: error.stack
            }
          };
        }
        
      case 'DISCONNECT':
        console.log('Background: Handling DISCONNECT');
        const disconnectId = request.tabId || sender.tab?.id || 'popup-connection';
        await this.handleDisconnect(disconnectId);
        return { success: true };
        
      case 'CLEAR_TOKEN':
        console.log('Background: Handling CLEAR_TOKEN');
        const clearDomain = request.domain || null;
        await this.clearStoredToken(clearDomain);
        return { success: true };
        
      case 'CHECK_CONNECTION':
        const isConnected = request.tabId ? this.connections.has(request.tabId) : false;
        console.log('Background: Connection check for tab', request.tabId, ':', isConnected);
        return { connected: isConnected };
        
      case 'GET_STORED_TOKEN':
        console.log('Background: Handling GET_STORED_TOKEN');
        const requestedDomain = request.domain || null;
        const storedToken = await this.getStoredToken(requestedDomain);
        return { token: storedToken };
        
      case 'GET_ALL_STORED_TOKENS':
        console.log('Background: Handling GET_ALL_STORED_TOKENS');
        const allTokens = await this.getAllStoredTokens();
        return { tokens: allTokens };
        
      case 'CLEANUP_UNDEFINED_TOKENS':
        console.log('Background: Handling CLEANUP_UNDEFINED_TOKENS');
        await this.cleanupUndefinedTokens();
        return { success: true };
        
      case 'SET_TOKEN':
        console.log('Background: Handling SET_TOKEN');
        console.log('Background: Token info:', request.tokenInfo);
        try {
          // Pass domain from tokenInfo if available
          const domain = request.tokenInfo?.serverUrl ? new URL(request.tokenInfo.serverUrl).hostname : null;
          await this.setStoredToken(request.token, request.tokenInfo, domain);
          console.log('Background: Token stored successfully, returning success');
          return { success: true, message: 'Token stored' };
        } catch (error) {
          console.error('Background: Error storing token:', error);
          return { success: false, error: error.message };
        }
        
      case 'GET_TOKEN':
        console.log('Background: Handling GET_TOKEN');
        const token = await this.tokenManager.getToken(request.projectId);
        return { token };
        
      case 'SEND_PROMPT':
        console.log('Background: Handling SEND_PROMPT');
        // Use request.tabId if provided, otherwise sender.tab?.id, or 'popup-connection' for popup
        const promptTabId = request.tabId || sender.tab?.id || 'popup-connection';
        await this.sendPrompt(request.prompt, promptTabId);
        return { success: true };
        
      case 'SEND_PING':
        console.log('Background: Handling SEND_PING');
        try {
          const tabId = request.tabId || sender.tab?.id || 'popup-connection';
          const timestamp = Date.now();
          this.pingTimestamps.set(tabId, timestamp);
          await this.sendPing(tabId);
          return { success: true, timestamp };
        } catch (error) {
          console.error('Background: Error sending ping:', error);
          return { success: false, error: error.message };
        }
        
      case 'GET_TASKS':
        console.log('Background: Handling GET_TASKS');
        try {
          const tabId = request.tabId || sender.tab?.id || 'popup-connection';
          const connection = this.connections.get(tabId);
          
          if (!connection) {
            console.log('No connection for tab:', tabId);
            return { success: false, error: 'Not connected to AniCode', tasks: [] };
          }
          
          // Send request to WebSocket and wait for response with longer timeout
          return new Promise((resolve) => {
            console.log('Background: Setting up GET_TASKS timeout (10s)');
            const timeout = setTimeout(() => {
              console.warn('Background: GET_TASKS timeout after 10 seconds');
              resolve({ success: false, error: 'Request timeout - server may be busy', tasks: [] });
            }, 10000); // Increased timeout to 10 seconds
            
            connection.bridge.once('task-list-response', (data) => {
              clearTimeout(timeout);
              console.log('Background: Received task list response with', data.tasks?.length || 0, 'tasks');
              resolve({ success: true, tasks: data.tasks || [] });
            });
            
            console.log('Background: Sending GET_TASKS request to WebSocket');
            connection.bridge.send({ type: 'GET_TASKS' });
          });
        } catch (error) {
          console.error('Error getting tasks:', error);
          return { success: false, error: error.message, tasks: [] };
        }
        
      case 'GET_GIT_LOG':
        console.log('Background: Handling GET_GIT_LOG');
        try {
          const tabId = request.tabId || sender.tab?.id || 'popup-connection';
          const connection = this.connections.get(tabId);
          
          if (!connection) {
            console.log('No connection for tab:', tabId);
            return { success: false, error: 'Not connected to AniCode', gitLog: {} };
          }
          
          // Use the same simple pattern as GET_TASKS
          return new Promise((resolve) => {
            console.log('Background: Setting up GET_GIT_LOG timeout (10s)');
            const timeout = setTimeout(() => {
              console.warn('Background: GET_GIT_LOG timeout after 10 seconds');
              resolve({ success: false, error: 'Request timeout - server may be busy', gitLog: {} });
            }, 10000); // 10 second timeout
            
            connection.bridge.once('git-log-response', (data) => {
              clearTimeout(timeout);
              console.log('Background: Received git log response');
              resolve({ success: true, gitLog: data || {} });
            });
            
            console.log('Background: Sending GET_GIT_LOG request to WebSocket');
            connection.bridge.send({ type: 'GET_GIT_LOG' });
          });
        } catch (error) {
          console.error('Error getting git log:', error);
          return { success: false, error: error.message, gitLog: {} };
        }
        
      case 'GIT_LOG_ACK':
        console.log('Background: Received GIT_LOG_ACK from popup:', request);
        // Log the acknowledgment for debugging
        if (request.success) {
          console.log('Background: Git log successfully received by popup');
        } else {
          console.log('Background: Git log failed in popup:', request.error);
        }
        return { success: true };
        
      case 'SEND_PROMPT':
        console.log('Background: Handling SEND_PROMPT');
        try {
          const tabId = request.tabId || sender.tab?.id || 'popup-connection';
          
          // Try to get connection - popup connections might have a different key
          let connection = this.connections.get(tabId);
          
          // If no connection and this is from popup, try to find any active connection
          if (!connection && tabId === 'popup-connection') {
            // Get the first active connection (usually there's only one)
            if (this.connections.size > 0) {
              connection = this.connections.values().next().value;
              console.log('Using first available connection for popup');
            }
          }
          
          if (!connection) {
            console.log('No connection available. TabId:', tabId, 'Active connections:', Array.from(this.connections.keys()));
            return { success: false, error: 'Not connected to AniCode. Please connect first.' };
          }
          
          // Send prompt to WebSocket
          const messageType = request.promptType === 'continue' ? 'CONTINUE' : 'ADD';
          const payload = {
            type: messageType,
            prompt: request.prompt || ''
          };
          
          console.log('Background: Sending prompt to WebSocket:', payload);
          connection.bridge.send(payload);
          
          return { success: true, message: 'Prompt sent successfully' };
        } catch (error) {
          console.error('Error sending prompt:', error);
          return { success: false, error: error.message };
        }
        
      case 'OPEN_CHAT_WITH_ELEMENTS':
        console.log('Background: Handling OPEN_CHAT_WITH_ELEMENTS');
        try {
          // Store elements for the chat context
          this.chatElements = request.elements;
          // In the future, this would open a chat interface or send to AniCode
          console.log('Background: Stored', request.elements?.length || 0, 'elements for chat context');
          return { success: true, message: 'Elements stored for chat context' };
        } catch (error) {
          console.error('Error handling chat elements:', error);
          return { success: false, error: error.message };
        }
        
      case 'CHAT_MESSAGE':
        console.log('Background: Handling CHAT_MESSAGE');
        try {
          // Forward message to WebSocket if connected
          const chatTabId = sender.tab?.id || 'popup-connection';
          const chatConnection = this.connections.get(chatTabId);
          
          if (chatConnection) {
            console.log('Background: Forwarding chat message to WebSocket');
            chatConnection.bridge.send({
              type: 'CHAT_MESSAGE',
              message: request.message,
              context: request.context
            });
            return { success: true, reply: 'Message sent to AniCode' };
          } else {
            return { success: false, error: 'Not connected to AniCode' };
          }
        } catch (error) {
          console.error('Error handling chat message:', error);
          return { success: false, error: error.message };
        }
        
      case 'ADD_TASK':
        console.log('Background: Handling ADD_TASK');
        // Forward to SEND_PROMPT with promptType 'add'
        return this.handleMessage({
          type: 'SEND_PROMPT',
          prompt: request.prompt,
          promptType: 'add',
          tabId: request.tabId
        }, sender);
        
      case 'CONTINUE_TASK':
        console.log('Background: Handling CONTINUE_TASK');
        // Forward to SEND_PROMPT with promptType 'continue'
        return this.handleMessage({
          type: 'SEND_PROMPT',
          prompt: request.prompt,
          promptType: 'continue',
          tabId: request.tabId
        }, sender);
        
      default:
        console.warn('Background: Unknown message type:', request.type);
        return { success: false, error: 'Unknown message type' };
    }
  }

  async setStoredToken(token, tokenInfo, providedDomain = null) {
    console.log('Background: Storing token and token info');
    this.currentToken = token;
    
    // Use provided domain or extract from tokenInfo serverUrl, fallback to current tab
    let domain = providedDomain;
    
    if (!domain && tokenInfo?.serverUrl) {
      try {
        domain = new URL(tokenInfo.serverUrl).hostname;
        console.log('Background: Extracted domain from token serverUrl:', domain);
      } catch (error) {
        console.error('Background: Error extracting domain from serverUrl:', error);
      }
    }
    
    if (!domain) {
      // Fall back to current tab domain only if no domain provided
      try {
        // Properly promisify chrome.tabs.query
        const tabs = await new Promise((resolve) => {
          chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            resolve(tabs);
          });
        });
        if (tabs && tabs.length > 0) {
          const currentTab = tabs[0];
          if (currentTab.url) {
            domain = new URL(currentTab.url).hostname;
            console.log('Background: Detected domain from current tab:', domain);
          } else {
            console.log('Background: No URL in current tab, using default domain');
            domain = 'default';
          }
        } else {
          console.log('Background: No active tab found, using default domain');
          domain = 'default';
        }
      } catch (error) {
        console.error('Background: Error getting current tab domain:', error);
        domain = 'default';
      }
    }
    
    const tokenData = {
      token: token,
      tokenInfo: tokenInfo,
      domain: domain,
      storedAt: Date.now()
    };
    
    // Store token per domain
    const storageKey = `anicode_token_${domain}`;
    
    // Properly promisify chrome.storage.local.set
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ [storageKey]: tokenData }, () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve();
        }
      });
    });
    
    console.log('Background: Token stored successfully for domain:', domain);
  }

  async getStoredToken(requestedDomain = null) {
    try {
      // Use requested domain or get from current tab
      let domain = requestedDomain || 'default';
      
      if (!requestedDomain) {
        try {
          const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
          if (tabs && tabs.length > 0) {
            const currentTab = tabs[0];
            if (currentTab.url) {
              domain = new URL(currentTab.url).hostname;
              console.log('Background: Detected domain from current tab:', domain);
            } else {
              console.log('Background: No URL in current tab, using default domain');
              domain = 'default';
            }
          } else {
            console.log('Background: No active tab found, using default domain');
            domain = 'default';
          }
        } catch (error) {
          console.error('Background: Error getting current tab domain:', error);
          domain = 'default';
        }
      }
      
      const storageKey = `anicode_token_${domain}`;
      
      // Properly promisify chrome.storage.local.get
      const result = await new Promise((resolve) => {
        chrome.storage.local.get(storageKey, (data) => {
          resolve(data);
        });
      });
      const tokenData = result[storageKey];
      
      if (tokenData) {
        console.log('Background: Retrieved stored token for domain:', domain);
        
        // Check if token is expired
        if (tokenData.tokenInfo && tokenData.tokenInfo.expiresAt) {
          const now = new Date();
          const expiresAt = new Date(tokenData.tokenInfo.expiresAt);
          
          if (now > expiresAt) {
            console.log('Background: Token is expired, removing from storage');
            await this.clearStoredToken();
            return null;
          }
        }
        
        this.currentToken = tokenData.token;
        return tokenData;
      }
      
      return null;
    } catch (error) {
      console.error('Background: Error getting stored token:', error);
      return null;
    }
  }

  async clearStoredToken(requestedDomain = null) {
    console.log('Background: Clearing stored token');
    this.currentToken = null;
    
    // Use requested domain or get from current tab
    let domain = requestedDomain || 'default';
    
    if (!requestedDomain) {
      try {
        // Properly promisify chrome.tabs.query
        const tabs = await new Promise((resolve) => {
          chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            resolve(tabs);
          });
        });
        if (tabs && tabs.length > 0) {
          const currentTab = tabs[0];
          if (currentTab.url) {
            domain = new URL(currentTab.url).hostname;
            console.log('Background: Detected domain from current tab:', domain);
          } else {
            console.log('Background: No URL in current tab, using default domain');
            domain = 'default';
          }
        } else {
          console.log('Background: No active tab found, using default domain');
          domain = 'default';
        }
      } catch (error) {
        console.error('Background: Error getting current tab domain:', error);
        domain = 'default';
      }
    }
    
    const storageKey = `anicode_token_${domain}`;
    
    // Properly promisify chrome.storage.local.remove
    await new Promise((resolve, reject) => {
      chrome.storage.local.remove(storageKey, () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve();
        }
      });
    });
    
    console.log('Background: Token cleared successfully for domain:', domain);
  }

  async getAllStoredTokens() {
    try {
      // Properly promisify chrome.storage.local.get for all items
      const result = await new Promise((resolve) => {
        chrome.storage.local.get(null, (data) => {
          resolve(data);
        });
      });
      const tokens = {};
      
      for (const [key, value] of Object.entries(result)) {
        if (key.startsWith('anicode_token_')) {
          const domain = key.replace('anicode_token_', '');
          tokens[domain] = value;
        }
      }
      
      console.log('Background: All stored tokens:', tokens);
      return tokens;
    } catch (error) {
      console.error('Background: Error getting all stored tokens:', error);
      return {};
    }
  }

  async cleanupUndefinedTokens() {
    try {
      console.log('Background: Cleaning up undefined tokens...');
      // Properly promisify chrome.storage.local.get for all items
      const result = await new Promise((resolve) => {
        chrome.storage.local.get(null, (data) => {
          resolve(data);
        });
      });
      
      for (const [key, value] of Object.entries(result)) {
        if (key === 'anicode_token_undefined') {
          console.log('Background: Removing undefined token:', key);
          // Properly promisify chrome.storage.local.remove
          await new Promise((resolve, reject) => {
            chrome.storage.local.remove(key, () => {
              if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
              } else {
                resolve();
              }
            });
          });
        }
      }
      
      console.log('Background: Cleanup completed');
    } catch (error) {
      console.error('Background: Error cleaning up undefined tokens:', error);
    }
  }

  async handleConnect(request, tabId) {
    console.log('Background: === handleConnect START ===');
    console.log('Background: handleConnect called with:', { request, tabId });
    
    // If no tabId, this might be a popup-initiated connection
    // Use a special identifier for popup connections
    if (!tabId) {
      console.log('Background: No tabId provided - using popup connection mode');
      tabId = 'popup-connection';
    }
    
    const { projectId, token, url, payload } = request;
    const wsUrl = url || (payload?.serverUrl ? payload.serverUrl : 'ws://localhost:6502');
    console.log('Background: Connection params:', { 
      projectId, 
      token: token ? `${token.substring(0, 20)}...` : 'missing', 
      url,
      tokenLength: token?.length 
    });
    
    if (!token) {
      throw new Error('No token provided for connection');
    }
    
    if (!url) {
      throw new Error('No URL provided for connection');
    }
    
    try {
      // Create WebSocket connection to AniCode
      console.log('Background: Creating WebSocketBridge...');
      console.log('Background: Original URL:', wsUrl);
      
      // Ensure the URL includes the /socket path
      let finalWsUrl = wsUrl;
      // Add /socket path if not already present
      if (!finalWsUrl.endsWith('/socket')) {
        finalWsUrl = finalWsUrl.replace(/\/$/, '') + '/socket';
      }
      
      console.log('Background: Final WebSocket URL:', finalWsUrl);
      const bridge = new WebSocketBridge(finalWsUrl, token);
      console.log('Background: WebSocketBridge created');
      
      console.log('Background: Setting up event listeners...');
      bridge.on('message', (data) => {
        console.log('Background: Received message:', data);
        this.handleAniCodeMessage(data, tabId);
      });
      
      bridge.on('task-update', (task) => {
        console.log('Background: Task update:', task);
        this.taskManager.updateTask(tabId, task);
        this.notifyTab(tabId, { type: 'TASK_UPDATE', task });
      });
      
      bridge.on('task_created', (data) => {
        console.log('Background: Task created:', data);
        this.notifyTab(tabId, { type: 'TASK_CREATED', taskId: data.taskId, task: data.task });
      });
      
      bridge.on('git-update', (gitData) => {
        console.log('Background: Git update:', gitData);
        this.notifyTab(tabId, { type: 'GIT_UPDATE', gitData });
      });
      
      // No need for complex git-log-response handler - using once() in GET_GIT_LOG
      
      bridge.on('pong', (data) => {
        const now = Date.now();
        const pingTimestamp = this.pingTimestamps.get(tabId);
        const rtt = pingTimestamp ? now - pingTimestamp : null;
        
        console.log(`Background: Received PONG - RTT: ${rtt}ms`);
        this.pingTimestamps.delete(tabId);
        
        // Notify popup with RTT information
        this.notifyTab(tabId, { 
          type: 'LATENCY_PONG', 
          timestamp: data.timestamp,
          rtt: rtt 
        });
      });
      
      bridge.on('error', (error) => {
        console.error('Background: WebSocket error:', error);
        // Notify popup of error
        this.notifyTab(tabId, { 
          type: 'CONNECTION_ERROR', 
          error: error.message 
        });
      });
      
      bridge.on('close', (code, reason) => {
        console.log('Background: WebSocket closed:', { code, reason });
      });
      
      bridge.on('disconnected', () => {
        console.log('Background: WebSocket disconnected for tab:', tabId);
        // Clean up the connection
        this.connections.delete(tabId);
        // Notify popup that connection is lost
        this.notifyTab(tabId, { 
          type: 'CONNECTION_LOST',
          message: 'WebSocket connection lost. Please reconnect.'
        });
      });
      
      bridge.on('auth-failed', (data) => {
        console.error('Background: Authentication failed:', data.message);
        // Clean up the connection
        this.connections.delete(tabId);
        // Notify popup of auth failure
        this.notifyTab(tabId, { 
          type: 'AUTH_FAILED',
          message: data.message || 'Authentication failed. Please generate a new token.',
          requireNewToken: true
        });
      });
      
      // No automatic reconnection - user must manually reconnect
      
      console.log('Background: Attempting to connect to WebSocket...');
      try {
        await bridge.connect();
        console.log('Background: WebSocket connection successful!');
      } catch (wsError) {
        console.error('Background: WebSocket connection failed:', wsError);
        console.error('Background: WebSocket error details:', {
          message: wsError.message,
          stack: wsError.stack,
          url: finalWsUrl
        });
        throw new Error(`WebSocket connection failed: ${wsError.message}`);
      }
      
      this.connections.set(tabId, { bridge, projectId });
      console.log('Background: Connection stored for tab:', tabId);
      console.log('Background: === handleConnect SUCCESS ===');
      
    } catch (error) {
      console.error('Background: Connection failed:', error);
      console.error('Background: Error message:', error.message);
      console.error('Background: Error stack:', error.stack);
      
      // Enhance error message based on error type
      let enhancedError = error;
      
      // Check for authentication errors first
      const authErrorKeywords = ['Authentication failed', 'Token', 'auth', 'JWT', 'Invalid token', 
                                  'expired', 'algorithm', 'signature', 'Policy violation'];
      const isAuthError = authErrorKeywords.some(keyword => error.message?.includes(keyword));
      
      if (isAuthError) {
        enhancedError = new Error(
          'Authentication failed. Please generate a new token using "ani-code plugin new-token" command.'
        );
        enhancedError.originalError = error;
        enhancedError.isAuthError = true;
        
        // Notify popup of auth failure
        this.notifyTab(tabId, { 
          type: 'AUTH_FAILED',
          message: enhancedError.message,
          requireNewToken: true
        });
      } else if (error.message?.includes('Content Security Policy') || 
          error.message?.includes('CSP') ||
          error.message?.includes('blocked')) {
        enhancedError = new Error(
          'WebSocket connection blocked by Content Security Policy. ' +
          'Please reload the extension from chrome://extensions/ and try again.'
        );
        enhancedError.originalError = error;
      } else if (error.message?.includes('timeout')) {
        enhancedError = new Error(
          'Connection timeout. Please check if the AniCode server is running and accessible.'
        );
        enhancedError.originalError = error;
      } else if (error.message?.includes('refused') || error.message?.includes('failed')) {
        enhancedError = new Error(
          `Connection failed to ${wsUrl}. Please verify the server is running and the URL is correct.`
        );
        enhancedError.originalError = error;
      }
      
      throw enhancedError;
    }
  }

  async handleDisconnect(tabId) {
    if (!tabId) return;
    
    const connection = this.connections.get(tabId);
    if (connection) {
      connection.bridge.disconnect();
      this.connections.delete(tabId);
      // Notify popup that connection was disconnected
      this.notifyTab(tabId, { 
        type: 'CONNECTION_DISCONNECTED',
        message: 'Disconnected from AniCode'
      });
    }
  }

  async sendPrompt(prompt, tabId) {
    const connection = this.connections.get(tabId);
    if (!connection) {
      throw new Error('No active connection for this tab');
    }
    
    // Send task creation request to AniCode
    connection.bridge.send({
      type: 'task',
      action: 'create',
      taskData: {
        name: 'Chrome Plugin Task',
        command: prompt,
        cwd: connection.projectId || process.cwd()
      }
    });
  }

  async sendPing(tabId) {
    const connection = this.connections.get(tabId || 'popup-connection');
    if (!connection) {
      throw new Error('No active connection');
    }
    
    const timestamp = Date.now();
    console.log(`Background: Sending PING at ${timestamp}`);
    
    // Send ping to AniCode
    connection.bridge.send({
      type: 'PING',
      timestamp: timestamp
    });
  }

  async getGitLog(tabId) {
    const connection = this.connections.get(tabId);
    if (!connection) {
      throw new Error('No active connection for this tab');
    }
    
    return new Promise((resolve) => {
      connection.bridge.once('git-log-response', (data) => {
        resolve(data);
      });
      
      connection.bridge.send({
        type: 'GET_GIT_LOG'
      });
    });
  }

  // Edit mode methods removed - functionality no longer needed

  handleAniCodeMessage(data, tabId) {
    // Forward AniCode messages to content script
    this.notifyTab(tabId, {
      type: 'ANICODE_MESSAGE',
      data
    });
  }

  handleTabUpdate(tabId, changeInfo, tab) {
    if (changeInfo.status === 'complete') {
      // Check if we have an active connection for this tab
      const connection = this.connections.get(tabId);
      if (connection) {
        // Notify AniCode of page navigation
        connection.bridge.send({
          type: 'PAGE_NAVIGATED',
          url: tab.url
        });
      }
    }
  }

  handleTabRemoved(tabId) {
    // Clean up connection when tab is closed
    this.handleDisconnect(tabId);
  }

  async getTabUrl(tabId) {
    // Handle popup connections that don't have a tab
    if (tabId === 'popup-connection') {
      return 'chrome-extension://popup';
    }
    
    // Properly promisify chrome.tabs.get
    const tab = await new Promise((resolve, reject) => {
      chrome.tabs.get(tabId, (tab) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(tab);
        }
      });
    });
    return tab.url;
  }

  async getTabSelection(tabId) {
    // Handle popup connections that don't have a tab
    if (tabId === 'popup-connection') {
      return '';
    }
    
    // Properly promisify chrome.scripting.executeScript
    const results = await new Promise((resolve, reject) => {
      chrome.scripting.executeScript({
        target: { tabId },
        func: () => window.getSelection()?.toString() || ''
      }, (results) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(results);
        }
      });
    });
    return results[0]?.result || '';
  }

  notifyTab(tabId, message) {
    console.log(`Background: Notifying tab ${tabId} with message:`, message.type, message);
    
    // For popup connections, use multiple strategies
    if (tabId === 'popup-connection') {
      // Strategy 1: Use persistent port connection if available
      if (this.popupPort) {
        try {
          this.popupPort.postMessage(message);
          console.log('Background: Message sent via popup port:', message.type);
        } catch (e) {
          console.error('Background: Failed to send via port:', e);
          this.popupPort = null; // Clear dead port
        }
      }
      
      // Strategy 2: Send via chrome.runtime.sendMessage
      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) {
          console.debug('Background: chrome.runtime.sendMessage failed:', message.type, chrome.runtime.lastError.message);
        } else {
          console.log('Background: Message sent via chrome.runtime.sendMessage:', message.type);
        }
      });
      
      // Strategy 3: Direct view access
      try {
        const views = chrome.extension.getViews({ type: 'popup' });
        views.forEach(view => {
          if (view && view !== window) {
            try {
              // Direct window postMessage for popup
              view.postMessage({ source: 'anicode-background', ...message }, '*');
              console.log('Background: Direct message sent to popup view');
            } catch (e) {
              console.debug('Background: Could not post message to popup view:', e);
            }
          }
        });
      } catch (e) {
        console.debug('Background: getViews failed:', e);
      }
    } else if (typeof tabId === 'number') {
      // For regular tabs, use tab messaging
      chrome.tabs.sendMessage(tabId, message, (response) => {
        if (chrome.runtime.lastError) {
          console.debug(`Background: Tab ${tabId} not available:`, chrome.runtime.lastError.message);
        }
      });
    } else {
      console.warn(`Background: Invalid tabId for notifyTab: ${tabId}`);
    }
  }
}

// Initialize the bridge with error handling
console.log('Background: Starting initialization at', new Date().toISOString());

try {
  console.log('Background: Creating AniCodeBridge instance...');
  const aniCodeBridge = new AniCodeBridge();
  console.log('Background: AniCodeBridge instance created successfully');
  
  // Make it globally available for debugging
  globalThis.aniCodeBridge = aniCodeBridge;
} catch (error) {
  console.error('Background: FATAL ERROR during initialization:', error);
  console.error('Background: Error stack:', error.stack);
  
  // Set up a minimal message handler for error reporting
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('Background: Emergency handler - message type:', request.type);
    sendResponse({ 
      success: false, 
      error: 'Background script failed to initialize: ' + error.message,
      stack: error.stack 
    });
    return false;
  });
}
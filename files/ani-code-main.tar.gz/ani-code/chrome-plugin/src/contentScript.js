// Content script for AniCode Chrome Extension - Element Selection Mode
(function() {
  let isEditMode = false;
  let selectedElements = [];
  let hoveredElement = null;
  let selectionOverlay = null;
  let selectionMenu = null;
  let copiedTemplates = [];

  // Listen for messages from background
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('[AniCode Content] Received message:', request);
    
    switch (request.type) {
      case 'ENABLE_EDIT_MODE':
        enableEditMode();
        sendResponse({ success: true });
        break;
      case 'DISABLE_EDIT_MODE':
        disableEditMode();
        sendResponse({ success: true });
        break;
      case 'GET_SELECTED_ELEMENTS':
        sendResponse({ elements: selectedElements });
        break;
    }
  });

  function enableEditMode() {
    console.log('[AniCode] Enabling edit mode');
    isEditMode = true;
    
    // Create selection menu UI
    createSelectionMenu();
    
    // Add event listeners
    document.addEventListener('mouseover', handleMouseOver, true);
    document.addEventListener('mouseout', handleMouseOut, true);
    document.addEventListener('click', handleClick, true);
    document.addEventListener('keydown', handleKeyDown, true);
    
    // Create overlay for highlighting
    createSelectionOverlay();
    
    // Show notification
    showNotification('Edit mode enabled - Click elements to select, ESC to exit');
  }

  function disableEditMode() {
    console.log('[AniCode] Disabling edit mode');
    isEditMode = false;
    
    // Remove event listeners
    document.removeEventListener('mouseover', handleMouseOver, true);
    document.removeEventListener('mouseout', handleMouseOut, true);
    document.removeEventListener('click', handleClick, true);
    document.removeEventListener('keydown', handleKeyDown, true);
    
    // Remove UI elements
    if (selectionOverlay) {
      selectionOverlay.remove();
      selectionOverlay = null;
    }
    
    if (selectionMenu) {
      selectionMenu.remove();
      selectionMenu = null;
    }
    
    // Clear selections
    selectedElements = [];
    hoveredElement = null;
    
    showNotification('Edit mode disabled');
  }

  function createSelectionMenu() {
    // Create floating menu
    selectionMenu = document.createElement('div');
    selectionMenu.id = 'anicode-selection-menu';
    selectionMenu.innerHTML = `
      <style>
        #anicode-selection-menu {
          position: fixed;
          top: 20px;
          right: 20px;
          background: white;
          border: 2px solid #2563eb;
          border-radius: 8px;
          padding: 16px;
          box-shadow: 0 4px 12px rgba(0,0,0,0.15);
          z-index: 2147483647;
          font-family: system-ui, -apple-system, sans-serif;
          max-width: 300px;
        }
        
        #anicode-selection-menu h3 {
          margin: 0 0 12px 0;
          font-size: 16px;
          color: #1e293b;
        }
        
        #anicode-selection-menu .menu-section {
          margin-bottom: 12px;
        }
        
        #anicode-selection-menu .toggle-container {
          display: flex;
          align-items: center;
          gap: 8px;
          margin-bottom: 12px;
        }
        
        #anicode-selection-menu .toggle-switch {
          position: relative;
          width: 44px;
          height: 24px;
          background: #cbd5e1;
          border-radius: 12px;
          cursor: pointer;
          transition: background 0.3s;
        }
        
        #anicode-selection-menu .toggle-switch.active {
          background: #2563eb;
        }
        
        #anicode-selection-menu .toggle-switch::after {
          content: '';
          position: absolute;
          top: 2px;
          left: 2px;
          width: 20px;
          height: 20px;
          background: white;
          border-radius: 50%;
          transition: transform 0.3s;
        }
        
        #anicode-selection-menu .toggle-switch.active::after {
          transform: translateX(20px);
        }
        
        #anicode-selection-menu .selected-list {
          max-height: 200px;
          overflow-y: auto;
          border: 1px solid #e2e8f0;
          border-radius: 4px;
          padding: 8px;
          margin-bottom: 12px;
          font-size: 12px;
        }
        
        #anicode-selection-menu .selected-item {
          padding: 4px 8px;
          margin: 4px 0;
          background: #f1f5f9;
          border-radius: 4px;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        
        #anicode-selection-menu .selected-item button {
          padding: 2px 6px;
          background: #ef4444;
          color: white;
          border: none;
          border-radius: 3px;
          cursor: pointer;
          font-size: 11px;
        }
        
        #anicode-selection-menu button {
          padding: 8px 12px;
          margin: 4px;
          background: #2563eb;
          color: white;
          border: none;
          border-radius: 4px;
          cursor: pointer;
          font-size: 14px;
          transition: background 0.2s;
        }
        
        #anicode-selection-menu button:hover {
          background: #1d4ed8;
        }
        
        #anicode-selection-menu button.secondary {
          background: #64748b;
        }
        
        #anicode-selection-menu button.secondary:hover {
          background: #475569;
        }
        
        #anicode-selection-menu .status {
          font-size: 12px;
          color: #64748b;
          margin-top: 8px;
        }
      </style>
      <h3>🎯 AniCode Element Selector</h3>
      <div class="menu-section">
        <div class="toggle-container">
          <span>Selection Mode:</span>
          <div class="toggle-switch active" id="selection-toggle"></div>
        </div>
      </div>
      <div class="menu-section">
        <div class="selected-list" id="selected-list">
          <div style="color: #94a3b8; text-align: center;">No elements selected</div>
        </div>
      </div>
      <div class="menu-section">
        <button id="copy-templates-btn">📋 Copy Templates</button>
        <button id="open-chat-btn">💬 Open Chat</button>
        <button id="clear-btn" class="secondary">Clear All</button>
        <button id="exit-btn" class="secondary">Exit Mode</button>
      </div>
      <div class="status" id="selection-status">
        Click on elements to select them
      </div>
    `;
    
    document.body.appendChild(selectionMenu);
    
    // Add event handlers for menu buttons
    document.getElementById('selection-toggle').addEventListener('click', toggleSelectionMode);
    document.getElementById('copy-templates-btn').addEventListener('click', copyTemplates);
    document.getElementById('open-chat-btn').addEventListener('click', openChatWithTemplates);
    document.getElementById('clear-btn').addEventListener('click', clearSelections);
    document.getElementById('exit-btn').addEventListener('click', disableEditMode);
  }

  function createSelectionOverlay() {
    selectionOverlay = document.createElement('div');
    selectionOverlay.id = 'anicode-selection-overlay';
    selectionOverlay.style.cssText = `
      position: absolute;
      pointer-events: none;
      border: 2px solid #2563eb;
      background: rgba(37, 99, 235, 0.1);
      z-index: 2147483646;
      transition: all 0.2s ease;
      display: none;
    `;
    document.body.appendChild(selectionOverlay);
  }

  function handleMouseOver(e) {
    if (!isEditMode) return;
    
    const element = e.target;
    if (element === selectionMenu || selectionMenu.contains(element)) {
      return;
    }
    
    hoveredElement = element;
    highlightElement(element);
    
    // Update status
    updateStatus(`Hovering: ${getElementDescription(element)}`);
  }

  function handleMouseOut(e) {
    if (!isEditMode) return;
    
    if (selectionOverlay) {
      selectionOverlay.style.display = 'none';
    }
    hoveredElement = null;
  }

  function handleClick(e) {
    if (!isEditMode) return;
    
    const element = e.target;
    
    // Don't select the menu itself
    if (element === selectionMenu || selectionMenu.contains(element)) {
      return;
    }
    
    e.preventDefault();
    e.stopPropagation();
    
    // Add element to selection
    const elementData = {
      xpath: getXPath(element),
      selector: getCSSSelector(element),
      text: element.textContent?.substring(0, 100),
      tagName: element.tagName,
      id: element.id,
      className: element.className,
      timestamp: Date.now()
    };
    
    selectedElements.push(elementData);
    
    // Update UI
    updateSelectedList();
    
    // Log to console for troubleshooting
    console.log('[AniCode] Element selected:', elementData);
    
    // Flash the overlay to show selection
    flashElement(element);
    
    // Show notification
    showFloatingNotification(`Selected: ${getElementDescription(element)}`);
  }

  function handleKeyDown(e) {
    if (!isEditMode) return;
    
    // ESC to exit edit mode
    if (e.key === 'Escape') {
      disableEditMode();
    }
    
    // Ctrl+C to copy templates
    if (e.ctrlKey && e.key === 'c') {
      copyTemplates();
    }
  }

  function highlightElement(element) {
    if (!selectionOverlay) return;
    
    const rect = element.getBoundingClientRect();
    selectionOverlay.style.left = rect.left + window.scrollX + 'px';
    selectionOverlay.style.top = rect.top + window.scrollY + 'px';
    selectionOverlay.style.width = rect.width + 'px';
    selectionOverlay.style.height = rect.height + 'px';
    selectionOverlay.style.display = 'block';
  }

  function flashElement(element) {
    const rect = element.getBoundingClientRect();
    const flash = document.createElement('div');
    flash.style.cssText = `
      position: absolute;
      left: ${rect.left + window.scrollX}px;
      top: ${rect.top + window.scrollY}px;
      width: ${rect.width}px;
      height: ${rect.height}px;
      background: rgba(34, 197, 94, 0.3);
      border: 2px solid #22c55e;
      pointer-events: none;
      z-index: 2147483646;
      animation: flash 0.5s ease;
    `;
    
    const style = document.createElement('style');
    style.textContent = `
      @keyframes flash {
        0% { opacity: 0; }
        50% { opacity: 1; }
        100% { opacity: 0; }
      }
    `;
    document.head.appendChild(style);
    document.body.appendChild(flash);
    
    setTimeout(() => {
      flash.remove();
      style.remove();
    }, 500);
  }

  function getXPath(element) {
    if (!element) return '';
    
    if (element.id) {
      return `//*[@id="${element.id}"]`;
    }
    
    const parts = [];
    let current = element;
    
    while (current && current.nodeType === Node.ELEMENT_NODE) {
      let index = 0;
      let sibling = current.previousSibling;
      
      while (sibling) {
        if (sibling.nodeType === Node.ELEMENT_NODE && sibling.nodeName === current.nodeName) {
          index++;
        }
        sibling = sibling.previousSibling;
      }
      
      const tagName = current.nodeName.toLowerCase();
      const part = index > 0 ? `${tagName}[${index + 1}]` : tagName;
      parts.unshift(part);
      
      current = current.parentNode;
    }
    
    return '/' + parts.join('/');
  }

  function getCSSSelector(element) {
    if (!element) return '';
    
    if (element.id) {
      return `#${element.id}`;
    }
    
    const path = [];
    let current = element;
    
    while (current && current.nodeType === Node.ELEMENT_NODE) {
      let selector = current.nodeName.toLowerCase();
      
      if (current.id) {
        selector = `#${current.id}`;
        path.unshift(selector);
        break;
      } else if (current.className) {
        selector += `.${current.className.split(' ').join('.')}`;
      }
      
      path.unshift(selector);
      current = current.parentElement;
    }
    
    return path.join(' > ');
  }

  function getElementDescription(element) {
    let desc = element.tagName.toLowerCase();
    if (element.id) desc += `#${element.id}`;
    if (element.className) desc += `.${element.className.split(' ')[0]}`;
    return desc;
  }

  function updateSelectedList() {
    const list = document.getElementById('selected-list');
    if (!list) return;
    
    if (selectedElements.length === 0) {
      list.innerHTML = '<div style="color: #94a3b8; text-align: center;">No elements selected</div>';
      return;
    }
    
    list.innerHTML = selectedElements.map((el, index) => `
      <div class="selected-item">
        <span>${el.tagName.toLowerCase()}${el.id ? '#' + el.id : ''}</span>
        <button onclick="removeSelection(${index})">Remove</button>
      </div>
    `).join('');
  }

  function removeSelection(index) {
    selectedElements.splice(index, 1);
    updateSelectedList();
    console.log('[AniCode] Element removed from selection');
  }

  function copyTemplates() {
    if (selectedElements.length === 0) {
      showNotification('No elements selected to copy');
      return;
    }
    
    const templates = selectedElements.map(el => {
      return `Element: ${el.tagName}${el.id ? '#' + el.id : ''}
XPath: ${el.xpath}
CSS: ${el.selector}
Content: "${el.text?.substring(0, 50)}..."`;
    }).join('\n\n');
    
    // Copy to clipboard
    navigator.clipboard.writeText(templates).then(() => {
      showNotification('Templates copied to clipboard!');
      console.log('[AniCode] Templates copied:', templates);
    }).catch(err => {
      console.error('[AniCode] Failed to copy templates:', err);
      showNotification('Failed to copy templates');
    });
  }

  function openChatWithTemplates() {
    if (selectedElements.length === 0) {
      showNotification('No elements selected');
      return;
    }
    
    // Send selected elements to background
    chrome.runtime.sendMessage({
      type: 'OPEN_CHAT_WITH_ELEMENTS',
      elements: selectedElements
    }, response => {
      console.log('[AniCode] Chat opened with elements');
    });
    
    // Optionally disable edit mode after opening chat
    setTimeout(() => disableEditMode(), 500);
  }

  function clearSelections() {
    selectedElements = [];
    updateSelectedList();
    updateStatus('All selections cleared');
    console.log('[AniCode] All selections cleared');
  }

  function toggleSelectionMode() {
    const toggle = document.getElementById('selection-toggle');
    toggle.classList.toggle('active');
    
    const isActive = toggle.classList.contains('active');
    updateStatus(isActive ? 'Selection mode ON' : 'Selection mode OFF (view only)');
  }

  function updateStatus(message) {
    const status = document.getElementById('selection-status');
    if (status) {
      status.textContent = message;
    }
  }

  function showNotification(message) {
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed;
      bottom: 20px;
      left: 50%;
      transform: translateX(-50%);
      background: #1e293b;
      color: white;
      padding: 12px 24px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
      z-index: 2147483647;
      font-family: system-ui, -apple-system, sans-serif;
      font-size: 14px;
      animation: slideUp 0.3s ease;
    `;
    
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
      notification.style.animation = 'slideDown 0.3s ease';
      setTimeout(() => notification.remove(), 300);
    }, 3000);
  }

  function showFloatingNotification(message) {
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed;
      top: 80px;
      right: 20px;
      background: #22c55e;
      color: white;
      padding: 8px 16px;
      border-radius: 4px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.15);
      z-index: 2147483647;
      font-family: system-ui, -apple-system, sans-serif;
      font-size: 12px;
      animation: fadeIn 0.2s ease;
    `;
    
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
      notification.style.animation = 'fadeOut 0.2s ease';
      setTimeout(() => notification.remove(), 200);
    }, 1500);
  }

  // Make removeSelection globally available
  window.removeSelection = removeSelection;
  
  // Add animation styles
  const style = document.createElement('style');
  style.textContent = `
    @keyframes slideUp {
      from { transform: translateX(-50%) translateY(20px); opacity: 0; }
      to { transform: translateX(-50%) translateY(0); opacity: 1; }
    }
    @keyframes slideDown {
      from { transform: translateX(-50%) translateY(0); opacity: 1; }
      to { transform: translateX(-50%) translateY(20px); opacity: 0; }
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateX(20px); }
      to { opacity: 1; transform: translateX(0); }
    }
    @keyframes fadeOut {
      from { opacity: 1; transform: translateX(0); }
      to { opacity: 0; transform: translateX(20px); }
    }
  `;
  document.head.appendChild(style);
  
  console.log('[AniCode Content Script] Loaded and ready');
})();
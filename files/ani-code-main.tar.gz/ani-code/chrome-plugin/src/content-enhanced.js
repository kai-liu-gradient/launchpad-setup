// Enhanced Content Script for AniCode Chrome Extension
// This version includes improved element selection and chat interface
(function() {
  let isEditMode = false;
  let selectedElements = [];
  let hoveredElement = null;
  let selectionOverlay = null;
  let selectionMenu = null;
  let chatInterface = null;
  let isConnected = false;

  // Import chat interface module
  const { ChatInterface } = (() => {
    class ChatInterface {
      constructor() {
        this.isOpen = false;
        this.messages = [];
        this.selectedElements = [];
        this.chatContainer = null;
      }

      open(selectedElements = []) {
        console.log('[AniCode Chat] Opening with', selectedElements.length, 'elements');
        this.selectedElements = selectedElements;
        if (this.isOpen) {
          this.focus();
          return;
        }
        this.createChatUI();
        this.isOpen = true;
        if (selectedElements.length > 0) {
          this.addSystemMessage(`Context: ${selectedElements.length} elements selected`);
          this.addElementsToContext(selectedElements);
        }
      }

      createChatUI() {
        const overlay = document.createElement('div');
        overlay.id = 'anicode-chat-overlay';
        overlay.style.cssText = `
          position: fixed; top: 0; left: 0; width: 100%; height: 100%;
          background: rgba(0, 0, 0, 0.5); z-index: 2147483645;
          display: flex; align-items: center; justify-content: center;
        `;

        this.chatContainer = document.createElement('div');
        this.chatContainer.innerHTML = this.getChatHTML();
        overlay.appendChild(this.chatContainer);
        document.body.appendChild(overlay);

        // Event handlers
        document.getElementById('close-chat-btn').addEventListener('click', () => this.close());
        document.getElementById('chat-send-btn').addEventListener('click', () => this.sendMessage());
        document.getElementById('chat-input').addEventListener('keypress', (e) => {
          if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            this.sendMessage();
          }
        });

        overlay.addEventListener('click', (e) => {
          if (e.target === overlay) this.close();
        });
      }

      getChatHTML() {
        return `
          <style>
            #anicode-chat-container {
              width: 90%; max-width: 600px; height: 70vh; background: white;
              border-radius: 12px; box-shadow: 0 8px 32px rgba(0,0,0,0.2);
              display: flex; flex-direction: column; font-family: system-ui, -apple-system, sans-serif;
            }
            .chat-header {
              padding: 16px 20px; border-bottom: 1px solid #e2e8f0;
              display: flex; justify-content: space-between; align-items: center;
              background: #2563eb; color: white; border-radius: 12px 12px 0 0;
            }
            .chat-header h2 { margin: 0; font-size: 18px; }
            .chat-header button {
              background: transparent; border: none; color: white; font-size: 24px;
              cursor: pointer; padding: 0; width: 30px; height: 30px;
            }
            .chat-messages {
              flex: 1; overflow-y: auto; padding: 20px;
              display: flex; flex-direction: column; gap: 12px;
            }
            .message {
              padding: 10px 14px; border-radius: 8px; max-width: 80%;
            }
            .message.user { align-self: flex-end; background: #2563eb; color: white; }
            .message.assistant { align-self: flex-start; background: #f1f5f9; color: #1e293b; }
            .message.system {
              align-self: center; background: #fef3c7; color: #92400e;
              font-size: 12px; max-width: 90%; text-align: center;
            }
            .chat-input-container {
              padding: 16px; border-top: 1px solid #e2e8f0; display: flex; gap: 8px;
            }
            .chat-input {
              flex: 1; padding: 10px 14px; border: 1px solid #cbd5e1;
              border-radius: 6px; font-size: 14px; outline: none;
            }
            .chat-send-btn {
              padding: 10px 20px; background: #2563eb; color: white;
              border: none; border-radius: 6px; cursor: pointer;
            }
          </style>
          <div id="anicode-chat-container">
            <div class="chat-header">
              <h2>🤖 AniCode Assistant</h2>
              <button id="close-chat-btn">✕</button>
            </div>
            <div class="chat-messages" id="chat-messages">
              <div class="message assistant">Hello! How can I help you today?</div>
            </div>
            <div class="chat-input-container">
              <input type="text" class="chat-input" id="chat-input" placeholder="Type your message..." autofocus />
              <button class="chat-send-btn" id="chat-send-btn">Send</button>
            </div>
          </div>
        `;
      }

      addElementsToContext(elements) {
        const contextDiv = document.createElement('div');
        contextDiv.style.cssText = 'background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 4px; padding: 8px; margin: 4px 0; font-size: 11px; font-family: monospace;';
        contextDiv.textContent = elements.map((el, i) => 
          `[${i+1}] ${el.tagName}${el.id ? '#' + el.id : ''} - "${el.text?.substring(0, 50)}..."`
        ).join('\n');
        document.getElementById('chat-messages').appendChild(contextDiv);
      }

      sendMessage() {
        const input = document.getElementById('chat-input');
        const message = input.value.trim();
        if (!message) return;

        console.log('[AniCode Chat] Sending:', message);
        this.addMessage(message, 'user');
        input.value = '';

        chrome.runtime.sendMessage({
          type: 'CHAT_MESSAGE',
          message: message,
          context: { selectedElements: this.selectedElements }
        }, (response) => {
          if (response && response.reply) {
            this.addMessage(response.reply, 'assistant');
          } else {
            this.addMessage('Message sent to AniCode.', 'assistant');
          }
        });
      }

      addMessage(text, type = 'user') {
        const messagesContainer = document.getElementById('chat-messages');
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}`;
        messageDiv.textContent = text;
        messagesContainer.appendChild(messageDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
      }

      addSystemMessage(text) {
        this.addMessage(text, 'system');
      }

      close() {
        const overlay = document.getElementById('anicode-chat-overlay');
        if (overlay) {
          overlay.remove();
          this.isOpen = false;
        }
      }

      focus() {
        const input = document.getElementById('chat-input');
        if (input) input.focus();
      }
    }
    return { ChatInterface };
  })();

  // Initialize
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('[AniCode] Message received:', request.type);
    
    switch (request.type) {
      case 'ENABLE_EDIT_MODE':
        enableEditMode();
        sendResponse({ success: true });
        break;
      case 'DISABLE_EDIT_MODE':
        disableEditMode();
        sendResponse({ success: true });
        break;
      case 'GET_SELECTED_ELEMENTS':
        sendResponse({ elements: selectedElements });
        break;
      case 'CONNECTED':
        isConnected = true;
        console.log('[AniCode] Connected to server');
        break;
      case 'DISCONNECTED':
        isConnected = false;
        console.log('[AniCode] Disconnected from server');
        break;
    }
  });

  function enableEditMode() {
    console.log('[AniCode] Edit mode enabled');
    isEditMode = true;
    createSelectionMenu();
    document.addEventListener('mouseover', handleMouseOver, true);
    document.addEventListener('mouseout', handleMouseOut, true);
    document.addEventListener('click', handleClick, true);
    document.addEventListener('keydown', handleKeyDown, true);
    createSelectionOverlay();
    showNotification('Edit mode enabled - Click elements to select');
  }

  function disableEditMode() {
    console.log('[AniCode] Edit mode disabled');
    isEditMode = false;
    document.removeEventListener('mouseover', handleMouseOver, true);
    document.removeEventListener('mouseout', handleMouseOut, true);
    document.removeEventListener('click', handleClick, true);
    document.removeEventListener('keydown', handleKeyDown, true);
    if (selectionOverlay) selectionOverlay.remove();
    if (selectionMenu) selectionMenu.remove();
    selectedElements = [];
    showNotification('Edit mode disabled');
  }

  function createSelectionMenu() {
    selectionMenu = document.createElement('div');
    selectionMenu.id = 'anicode-selection-menu';
    selectionMenu.innerHTML = getSelectionMenuHTML();
    document.body.appendChild(selectionMenu);

    // Event handlers
    document.getElementById('copy-templates-btn').addEventListener('click', copyTemplates);
    document.getElementById('open-chat-btn').addEventListener('click', openChatWithTemplates);
    document.getElementById('clear-btn').addEventListener('click', clearSelections);
    document.getElementById('exit-btn').addEventListener('click', disableEditMode);
  }

  function getSelectionMenuHTML() {
    return `
      <style>
        #anicode-selection-menu {
          position: fixed; top: 20px; right: 20px; background: white;
          border: 2px solid #2563eb; border-radius: 8px; padding: 16px;
          box-shadow: 0 4px 12px rgba(0,0,0,0.15); z-index: 2147483647;
          font-family: system-ui, -apple-system, sans-serif; max-width: 300px;
        }
        #anicode-selection-menu h3 { margin: 0 0 12px 0; font-size: 16px; }
        #anicode-selection-menu button {
          padding: 8px 12px; margin: 4px; background: #2563eb; color: white;
          border: none; border-radius: 4px; cursor: pointer; font-size: 14px;
        }
        #anicode-selection-menu button.secondary { background: #64748b; }
        #anicode-selection-menu .selected-list {
          max-height: 200px; overflow-y: auto; border: 1px solid #e2e8f0;
          border-radius: 4px; padding: 8px; margin-bottom: 12px; font-size: 12px;
        }
        #anicode-selection-menu .status {
          font-size: 12px; color: #64748b; margin-top: 8px;
        }
      </style>
      <h3>🎯 Element Selector</h3>
      <div class="selected-list" id="selected-list">
        <div style="color: #94a3b8; text-align: center;">No elements selected</div>
      </div>
      <button id="copy-templates-btn">📋 Copy</button>
      <button id="open-chat-btn">💬 Chat</button>
      <button id="clear-btn" class="secondary">Clear</button>
      <button id="exit-btn" class="secondary">Exit</button>
      <div class="status" id="selection-status">Click elements to select</div>
    `;
  }

  function createSelectionOverlay() {
    selectionOverlay = document.createElement('div');
    selectionOverlay.style.cssText = `
      position: absolute; pointer-events: none; border: 2px solid #2563eb;
      background: rgba(37, 99, 235, 0.1); z-index: 2147483646; display: none;
    `;
    document.body.appendChild(selectionOverlay);
  }

  function handleMouseOver(e) {
    if (!isEditMode) return;
    const element = e.target;
    if (element === selectionMenu || selectionMenu?.contains(element)) return;
    hoveredElement = element;
    highlightElement(element);
    updateStatus(`Hovering: ${getElementDescription(element)}`);
  }

  function handleMouseOut(e) {
    if (!isEditMode || !selectionOverlay) return;
    selectionOverlay.style.display = 'none';
    hoveredElement = null;
  }

  function handleClick(e) {
    if (!isEditMode) return;
    const element = e.target;
    if (element === selectionMenu || selectionMenu?.contains(element)) return;
    
    e.preventDefault();
    e.stopPropagation();
    
    const elementData = {
      xpath: getXPath(element),
      selector: getCSSSelector(element),
      text: element.textContent?.substring(0, 100),
      tagName: element.tagName,
      id: element.id,
      className: element.className
    };
    
    selectedElements.push(elementData);
    updateSelectedList();
    console.log('[AniCode] Selected:', elementData);
    showFloatingNotification(`Selected: ${getElementDescription(element)}`);
  }

  function handleKeyDown(e) {
    if (!isEditMode) return;
    if (e.key === 'Escape') disableEditMode();
    if (e.ctrlKey && e.key === 'c') copyTemplates();
  }

  function highlightElement(element) {
    if (!selectionOverlay) return;
    const rect = element.getBoundingClientRect();
    Object.assign(selectionOverlay.style, {
      left: rect.left + window.scrollX + 'px',
      top: rect.top + window.scrollY + 'px',
      width: rect.width + 'px',
      height: rect.height + 'px',
      display: 'block'
    });
  }

  function getXPath(element) {
    if (element.id) return `//*[@id="${element.id}"]`;
    const parts = [];
    let current = element;
    while (current && current.nodeType === Node.ELEMENT_NODE) {
      let index = 0;
      let sibling = current.previousSibling;
      while (sibling) {
        if (sibling.nodeType === Node.ELEMENT_NODE && sibling.nodeName === current.nodeName) index++;
        sibling = sibling.previousSibling;
      }
      const tagName = current.nodeName.toLowerCase();
      parts.unshift(index > 0 ? `${tagName}[${index + 1}]` : tagName);
      current = current.parentNode;
    }
    return '/' + parts.join('/');
  }

  function getCSSSelector(element) {
    if (element.id) return `#${element.id}`;
    const path = [];
    let current = element;
    while (current && current.nodeType === Node.ELEMENT_NODE) {
      let selector = current.nodeName.toLowerCase();
      if (current.id) {
        path.unshift(`#${current.id}`);
        break;
      } else if (current.className) {
        selector += `.${current.className.split(' ').join('.')}`;
      }
      path.unshift(selector);
      current = current.parentElement;
    }
    return path.join(' > ');
  }

  function getElementDescription(element) {
    let desc = element.tagName.toLowerCase();
    if (element.id) desc += `#${element.id}`;
    if (element.className) desc += `.${element.className.split(' ')[0]}`;
    return desc;
  }

  function updateSelectedList() {
    const list = document.getElementById('selected-list');
    if (!list) return;
    if (selectedElements.length === 0) {
      list.innerHTML = '<div style="color: #94a3b8; text-align: center;">No elements selected</div>';
    } else {
      list.innerHTML = selectedElements.map((el, i) => 
        `<div>${i+1}. ${el.tagName.toLowerCase()}${el.id ? '#' + el.id : ''}</div>`
      ).join('');
    }
  }

  function copyTemplates() {
    if (selectedElements.length === 0) {
      showNotification('No elements selected');
      return;
    }
    const templates = selectedElements.map(el => 
      `XPath: ${el.xpath}\nCSS: ${el.selector}\nContent: "${el.text?.substring(0, 50)}..."`
    ).join('\n\n');
    navigator.clipboard.writeText(templates).then(() => {
      showNotification('Templates copied!');
      console.log('[AniCode] Copied templates');
    });
  }

  function openChatWithTemplates() {
    if (!chatInterface) chatInterface = new ChatInterface();
    chatInterface.open(selectedElements);
    setTimeout(() => disableEditMode(), 500);
  }

  function clearSelections() {
    selectedElements = [];
    updateSelectedList();
    updateStatus('Selections cleared');
  }

  function updateStatus(message) {
    const status = document.getElementById('selection-status');
    if (status) status.textContent = message;
  }

  function showNotification(message) {
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%);
      background: #1e293b; color: white; padding: 12px 24px;
      border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.2);
      z-index: 2147483647; font-family: system-ui, -apple-system, sans-serif;
    `;
    notification.textContent = message;
    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 3000);
  }

  function showFloatingNotification(message) {
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed; top: 80px; right: 20px; background: #22c55e;
      color: white; padding: 8px 16px; border-radius: 4px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.15); z-index: 2147483647;
      font-family: system-ui, -apple-system, sans-serif; font-size: 12px;
    `;
    notification.textContent = message;
    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 1500);
  }

  console.log('[AniCode] Enhanced content script loaded');
})();
// Edit mode enhancement for AniCode Chrome Extension
(function() {
  // Enhanced element selection and editing
  
  let currentMode = 'select'; // select, edit, inspect
  let editHistory = [];
  let historyIndex = -1;
  
  // Create floating edit toolbar
  function createEditToolbar() {
    const toolbar = document.createElement('div');
    toolbar.className = 'anicode-edit-toolbar';
    toolbar.innerHTML = `
      <div class="toolbar-section">
        <button data-action="undo" title="Undo">↶</button>
        <button data-action="redo" title="Redo">↷</button>
      </div>
      <div class="toolbar-section">
        <button data-action="edit-text" title="Edit Text">T</button>
        <button data-action="edit-html" title="Edit HTML">HTML</button>
        <button data-action="edit-css" title="Edit CSS">CSS</button>
      </div>
      <div class="toolbar-section">
        <button data-action="inspect" title="Inspect">🔍</button>
        <button data-action="delete" title="Delete">🗑️</button>
        <button data-action="clone" title="Clone">📋</button>
      </div>
      <div class="toolbar-section">
        <button data-action="ai-suggest" title="AI Suggestions">✨</button>
      </div>
    `;
    
    // Make toolbar draggable
    makeElementDraggable(toolbar);
    
    // Attach event handlers
    toolbar.addEventListener('click', handleToolbarAction);
    
    return toolbar;
  }
  
  function handleToolbarAction(e) {
    const button = e.target.closest('button');
    if (!button) return;
    
    const action = button.dataset.action;
    const selectedElement = document.querySelector('.anicode-selected');
    
    if (!selectedElement && !['undo', 'redo'].includes(action)) {
      alert('Please select an element first');
      return;
    }
    
    switch (action) {
      case 'undo':
        undoEdit();
        break;
      case 'redo':
        redoEdit();
        break;
      case 'edit-text':
        editElementText(selectedElement);
        break;
      case 'edit-html':
        editElementHTML(selectedElement);
        break;
      case 'edit-css':
        editElementCSS(selectedElement);
        break;
      case 'inspect':
        inspectElement(selectedElement);
        break;
      case 'delete':
        deleteElement(selectedElement);
        break;
      case 'clone':
        cloneElement(selectedElement);
        break;
      case 'ai-suggest':
        getAISuggestions(selectedElement);
        break;
    }
  }
  
  function editElementText(element) {
    const originalText = element.innerText;
    
    // Create inline editor
    const editor = document.createElement('textarea');
    editor.className = 'anicode-inline-editor';
    editor.value = originalText;
    
    // Position editor over element
    const rect = element.getBoundingClientRect();
    editor.style.position = 'fixed';
    editor.style.left = rect.left + 'px';
    editor.style.top = rect.top + 'px';
    editor.style.width = rect.width + 'px';
    editor.style.height = rect.height + 'px';
    editor.style.zIndex = '10003';
    
    document.body.appendChild(editor);
    editor.focus();
    editor.select();
    
    // Save on Enter or blur
    function saveEdit() {
      const newText = editor.value;
      if (newText !== originalText) {
        saveToHistory(element, 'text', originalText, newText);
        element.innerText = newText;
      }
      editor.remove();
    }
    
    editor.addEventListener('blur', saveEdit);
    editor.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        saveEdit();
      }
      if (e.key === 'Escape') {
        editor.remove();
      }
    });
  }
  
  function editElementHTML(element) {
    const originalHTML = element.outerHTML;
    
    // Create HTML editor dialog
    const dialog = document.createElement('div');
    dialog.className = 'anicode-html-editor-dialog';
    dialog.innerHTML = `
      <div class="dialog-header">
        <span>Edit HTML</span>
        <button class="close">×</button>
      </div>
      <div class="dialog-body">
        <textarea class="html-editor">${originalHTML}</textarea>
      </div>
      <div class="dialog-footer">
        <button class="save">Save</button>
        <button class="cancel">Cancel</button>
      </div>
    `;
    
    document.body.appendChild(dialog);
    
    const textarea = dialog.querySelector('.html-editor');
    textarea.focus();
    
    dialog.querySelector('.save').onclick = () => {
      const newHTML = textarea.value;
      if (newHTML !== originalHTML) {
        saveToHistory(element, 'html', originalHTML, newHTML);
        
        // Create temporary element to parse HTML
        const temp = document.createElement('div');
        temp.innerHTML = newHTML;
        
        if (temp.firstElementChild) {
          element.replaceWith(temp.firstElementChild);
        }
      }
      dialog.remove();
    };
    
    dialog.querySelector('.cancel').onclick = () => dialog.remove();
    dialog.querySelector('.close').onclick = () => dialog.remove();
  }
  
  function editElementCSS(element) {
    const computedStyle = window.getComputedStyle(element);
    const currentStyles = {};
    
    // Get current inline styles
    const inlineStyle = element.getAttribute('style') || '';
    
    // Create CSS editor dialog
    const dialog = document.createElement('div');
    dialog.className = 'anicode-css-editor-dialog';
    dialog.innerHTML = `
      <div class="dialog-header">
        <span>Edit CSS</span>
        <button class="close">×</button>
      </div>
      <div class="dialog-body">
        <div class="css-property-list">
          <div class="css-property">
            <label>Display:</label>
            <select name="display">
              <option value="">Default</option>
              <option value="block">Block</option>
              <option value="inline">Inline</option>
              <option value="inline-block">Inline-Block</option>
              <option value="flex">Flex</option>
              <option value="grid">Grid</option>
              <option value="none">None</option>
            </select>
          </div>
          <div class="css-property">
            <label>Width:</label>
            <input type="text" name="width" placeholder="e.g., 100px, 50%">
          </div>
          <div class="css-property">
            <label>Height:</label>
            <input type="text" name="height" placeholder="e.g., 100px, auto">
          </div>
          <div class="css-property">
            <label>Margin:</label>
            <input type="text" name="margin" placeholder="e.g., 10px, 10px 20px">
          </div>
          <div class="css-property">
            <label>Padding:</label>
            <input type="text" name="padding" placeholder="e.g., 10px, 10px 20px">
          </div>
          <div class="css-property">
            <label>Background:</label>
            <input type="text" name="background" placeholder="e.g., #fff, red">
          </div>
          <div class="css-property">
            <label>Color:</label>
            <input type="text" name="color" placeholder="e.g., #000, blue">
          </div>
          <div class="css-property">
            <label>Font Size:</label>
            <input type="text" name="font-size" placeholder="e.g., 16px, 1.2em">
          </div>
        </div>
        <div class="css-custom">
          <label>Custom CSS:</label>
          <textarea class="css-editor" placeholder="Enter CSS properties...">${inlineStyle}</textarea>
        </div>
      </div>
      <div class="dialog-footer">
        <button class="save">Apply</button>
        <button class="cancel">Cancel</button>
      </div>
    `;
    
    document.body.appendChild(dialog);
    
    dialog.querySelector('.save').onclick = () => {
      const originalStyle = element.getAttribute('style') || '';
      
      // Collect CSS from inputs
      const cssProps = {};
      dialog.querySelectorAll('.css-property input, .css-property select').forEach(input => {
        if (input.value) {
          cssProps[input.name] = input.value;
        }
      });
      
      // Get custom CSS
      const customCSS = dialog.querySelector('.css-editor').value;
      
      // Build style string
      let styleString = '';
      for (const [prop, value] of Object.entries(cssProps)) {
        styleString += `${prop}: ${value}; `;
      }
      if (customCSS) {
        styleString += customCSS;
      }
      
      if (styleString !== originalStyle) {
        saveToHistory(element, 'css', originalStyle, styleString);
        element.setAttribute('style', styleString);
      }
      
      dialog.remove();
    };
    
    dialog.querySelector('.cancel').onclick = () => dialog.remove();
    dialog.querySelector('.close').onclick = () => dialog.remove();
  }
  
  function inspectElement(element) {
    const info = {
      tagName: element.tagName,
      id: element.id,
      classList: Array.from(element.classList),
      attributes: {},
      computedStyle: {},
      dimensions: element.getBoundingClientRect(),
      parent: element.parentElement ? element.parentElement.tagName : null,
      children: element.children.length
    };
    
    // Get attributes
    for (const attr of element.attributes) {
      info.attributes[attr.name] = attr.value;
    }
    
    // Get key computed styles
    const styles = window.getComputedStyle(element);
    ['display', 'position', 'width', 'height', 'margin', 'padding', 'color', 'background-color', 'font-size'].forEach(prop => {
      info.computedStyle[prop] = styles.getPropertyValue(prop);
    });
    
    // Display inspection results
    const inspectorPanel = document.createElement('div');
    inspectorPanel.className = 'anicode-inspector-panel';
    inspectorPanel.innerHTML = `
      <div class="inspector-header">
        <span>Element Inspector</span>
        <button class="close">×</button>
      </div>
      <div class="inspector-body">
        <pre>${JSON.stringify(info, null, 2)}</pre>
      </div>
    `;
    
    document.body.appendChild(inspectorPanel);
    
    inspectorPanel.querySelector('.close').onclick = () => inspectorPanel.remove();
  }
  
  function deleteElement(element) {
    if (confirm('Are you sure you want to delete this element?')) {
      const parent = element.parentElement;
      const nextSibling = element.nextSibling;
      
      saveToHistory(element, 'delete', {
        parent,
        nextSibling,
        html: element.outerHTML
      }, null);
      
      element.remove();
    }
  }
  
  function cloneElement(element) {
    const clone = element.cloneNode(true);
    clone.classList.remove('anicode-selected', 'anicode-hover');
    
    saveToHistory(element, 'clone', null, clone);
    
    element.parentElement.insertBefore(clone, element.nextSibling);
  }
  
  function getAISuggestions(element) {
    // Send element info to background for AI suggestions
    chrome.runtime.sendMessage({
      type: 'SEND_PROMPT',
      prompt: `Suggest improvements for this HTML element: ${element.outerHTML.substring(0, 500)}`,
      context: {
        elementType: element.tagName,
        elementClasses: element.className,
        elementId: element.id
      }
    });
    
    // Show loading indicator
    const notification = document.createElement('div');
    notification.className = 'anicode-notification info';
    notification.textContent = 'Getting AI suggestions...';
    document.body.appendChild(notification);
    
    setTimeout(() => notification.remove(), 3000);
  }
  
  function saveToHistory(element, action, oldValue, newValue) {
    // Trim future history if we're not at the end
    if (historyIndex < editHistory.length - 1) {
      editHistory = editHistory.slice(0, historyIndex + 1);
    }
    
    editHistory.push({
      element,
      action,
      oldValue,
      newValue,
      timestamp: Date.now()
    });
    
    historyIndex = editHistory.length - 1;
    
    // Limit history size
    if (editHistory.length > 50) {
      editHistory.shift();
      historyIndex--;
    }
  }
  
  function undoEdit() {
    if (historyIndex < 0) return;
    
    const edit = editHistory[historyIndex];
    
    switch (edit.action) {
      case 'text':
        edit.element.innerText = edit.oldValue;
        break;
      case 'html':
        const temp = document.createElement('div');
        temp.innerHTML = edit.oldValue;
        if (temp.firstElementChild) {
          edit.element.replaceWith(temp.firstElementChild);
        }
        break;
      case 'css':
        if (edit.oldValue) {
          edit.element.setAttribute('style', edit.oldValue);
        } else {
          edit.element.removeAttribute('style');
        }
        break;
      case 'delete':
        const { parent, nextSibling, html } = edit.oldValue;
        const temp2 = document.createElement('div');
        temp2.innerHTML = html;
        if (temp2.firstElementChild) {
          parent.insertBefore(temp2.firstElementChild, nextSibling);
        }
        break;
      case 'clone':
        edit.newValue.remove();
        break;
    }
    
    historyIndex--;
  }
  
  function redoEdit() {
    if (historyIndex >= editHistory.length - 1) return;
    
    historyIndex++;
    const edit = editHistory[historyIndex];
    
    switch (edit.action) {
      case 'text':
        edit.element.innerText = edit.newValue;
        break;
      case 'html':
        const temp = document.createElement('div');
        temp.innerHTML = edit.newValue;
        if (temp.firstElementChild) {
          edit.element.replaceWith(temp.firstElementChild);
        }
        break;
      case 'css':
        edit.element.setAttribute('style', edit.newValue);
        break;
      case 'delete':
        edit.element.remove();
        break;
      case 'clone':
        edit.element.parentElement.insertBefore(edit.newValue, edit.element.nextSibling);
        break;
    }
  }
  
  function makeElementDraggable(element) {
    let isDragging = false;
    let startX, startY, initialX, initialY;
    
    element.addEventListener('mousedown', (e) => {
      if (e.target.tagName === 'BUTTON' || e.target.tagName === 'INPUT') return;
      
      isDragging = true;
      startX = e.clientX;
      startY = e.clientY;
      
      const rect = element.getBoundingClientRect();
      initialX = rect.left;
      initialY = rect.top;
      
      e.preventDefault();
    });
    
    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      
      const deltaX = e.clientX - startX;
      const deltaY = e.clientY - startY;
      
      element.style.left = (initialX + deltaX) + 'px';
      element.style.top = (initialY + deltaY) + 'px';
    });
    
    document.addEventListener('mouseup', () => {
      isDragging = false;
    });
  }
  
  // Initialize edit toolbar
  const toolbar = createEditToolbar();
  document.body.appendChild(toolbar);
  
  // Position toolbar
  toolbar.style.position = 'fixed';
  toolbar.style.top = '100px';
  toolbar.style.right = '20px';
  toolbar.style.zIndex = '10002';
})();
// Content script for AniCode Chrome Extension
(function() {
  let editMode = false;
  let selectedElement = null;
  let overlay = null;
  let chatDialog = null;
  let taskPanel = null;
  let isConnected = false;

  // Initialize content script
  function init() {
    console.log('AniCode content script loaded');
    
    // Listen for messages from background script
    chrome.runtime.onMessage.addListener(handleMessage);
    
    // Set up keyboard shortcuts
    document.addEventListener('keydown', handleKeyboard);
    
    // Check if we should auto-connect
    checkAutoConnect();
  }

  function handleMessage(request, sender, sendResponse) {
    switch (request.type) {
      case 'ENABLE_EDIT_MODE':
        enableEditMode();
        break;
        
      case 'DISABLE_EDIT_MODE':
        disableEditMode();
        break;
        
      case 'ANICODE_MESSAGE':
        handleAniCodeMessage(request.data);
        break;
        
      case 'TASK_UPDATE':
        updateTaskDisplay(request.task);
        break;
        
      case 'GIT_UPDATE':
        updateGitDisplay(request.gitData);
        break;
        
      case 'CONNECTED':
        handleConnected();
        break;
        
      case 'DISCONNECTED':
        handleDisconnected();
        break;
    }
  }

  function enableEditMode() {
    if (editMode) return;
    
    editMode = true;
    document.body.classList.add('anicode-edit-mode');
    
    // Create overlay
    createOverlay();
    
    // Add element selection handlers
    document.addEventListener('mouseover', handleMouseOver);
    document.addEventListener('mouseout', handleMouseOut);
    document.addEventListener('click', handleElementClick);
    
    // Show notification
    showNotification('Edit mode enabled. Click any element to select it.');
  }

  function disableEditMode() {
    if (!editMode) return;
    
    editMode = false;
    document.body.classList.remove('anicode-edit-mode');
    
    // Remove overlay
    if (overlay) {
      overlay.remove();
      overlay = null;
    }
    
    // Remove element selection handlers
    document.removeEventListener('mouseover', handleMouseOver);
    document.removeEventListener('mouseout', handleMouseOut);
    document.removeEventListener('click', handleElementClick);
    
    // Clear selection
    if (selectedElement) {
      selectedElement.classList.remove('anicode-selected');
      selectedElement = null;
    }
    
    showNotification('Edit mode disabled');
  }

  function createOverlay() {
    overlay = document.createElement('div');
    overlay.className = 'anicode-overlay';
    overlay.innerHTML = `
      <div class="anicode-toolbar">
        <div class="anicode-brand">
          <span class="anicode-logo">🤖</span>
          <span>AniCode Editor</span>
        </div>
        <div class="anicode-tools">
          <button id="anicode-chat" title="Open Chat">💬</button>
          <button id="anicode-tasks" title="View Tasks">📋</button>
          <button id="anicode-git" title="Git Log">📊</button>
          <button id="anicode-select" title="Select Element">🎯</button>
          <button id="anicode-prompt" title="Quick Prompt">✏️</button>
          <button id="anicode-exit" title="Exit Edit Mode">❌</button>
        </div>
      </div>
      <div class="anicode-selection-info"></div>
    `;
    
    document.body.appendChild(overlay);
    
    // Attach event handlers
    document.getElementById('anicode-chat').onclick = toggleChat;
    document.getElementById('anicode-tasks').onclick = toggleTasks;
    document.getElementById('anicode-git').onclick = showGitLog;
    document.getElementById('anicode-select').onclick = toggleSelection;
    document.getElementById('anicode-prompt').onclick = quickPrompt;
    document.getElementById('anicode-exit').onclick = () => {
      chrome.runtime.sendMessage({ type: 'DISABLE_EDIT_MODE' });
    };
  }

  function handleMouseOver(e) {
    if (!editMode || e.target === overlay || overlay.contains(e.target)) return;
    
    e.target.classList.add('anicode-hover');
  }

  function handleMouseOut(e) {
    if (!editMode) return;
    
    e.target.classList.remove('anicode-hover');
  }

  function handleElementClick(e) {
    if (!editMode || e.target === overlay || overlay.contains(e.target)) return;
    
    e.preventDefault();
    e.stopPropagation();
    
    // Clear previous selection
    if (selectedElement) {
      selectedElement.classList.remove('anicode-selected');
    }
    
    // Select new element
    selectedElement = e.target;
    selectedElement.classList.add('anicode-selected');
    
    // Update selection info
    updateSelectionInfo();
  }

  function updateSelectionInfo() {
    if (!selectedElement || !overlay) return;
    
    const info = overlay.querySelector('.anicode-selection-info');
    const tagName = selectedElement.tagName.toLowerCase();
    const className = selectedElement.className || 'no-class';
    const id = selectedElement.id || 'no-id';
    
    info.innerHTML = `
      <strong>Selected:</strong> &lt;${tagName}&gt;
      ${id !== 'no-id' ? ` #${id}` : ''}
      ${className !== 'no-class' ? ` .${className.split(' ').join('.')}` : ''}
    `;
  }

  function toggleChat() {
    if (!chatDialog) {
      createChatDialog();
    } else {
      chatDialog.style.display = chatDialog.style.display === 'none' ? 'block' : 'none';
    }
  }

  function createChatDialog() {
    chatDialog = document.createElement('div');
    chatDialog.className = 'anicode-chat-dialog';
    chatDialog.innerHTML = `
      <div class="anicode-chat-header">
        <span>AniCode Chat</span>
        <button class="anicode-close">×</button>
      </div>
      <div class="anicode-chat-messages"></div>
      <div class="anicode-chat-input">
        <textarea placeholder="Enter your prompt here..."></textarea>
        <button class="anicode-send">Send</button>
      </div>
    `;
    
    document.body.appendChild(chatDialog);
    
    // Position the chat dialog
    chatDialog.style.position = 'fixed';
    chatDialog.style.right = '20px';
    chatDialog.style.bottom = '20px';
    chatDialog.style.width = '400px';
    chatDialog.style.height = '500px';
    chatDialog.style.zIndex = '10001';
    
    // Attach handlers
    chatDialog.querySelector('.anicode-close').onclick = () => {
      chatDialog.style.display = 'none';
    };
    
    chatDialog.querySelector('.anicode-send').onclick = sendChatMessage;
    
    chatDialog.querySelector('textarea').addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && e.ctrlKey) {
        sendChatMessage();
      }
    });
  }

  function sendChatMessage() {
    const textarea = chatDialog.querySelector('textarea');
    const prompt = textarea.value.trim();
    
    if (!prompt) return;
    
    // Add message to chat
    addChatMessage('You', prompt);
    
    // Clear input
    textarea.value = '';
    
    // Send to background
    chrome.runtime.sendMessage({
      type: 'SEND_PROMPT',
      prompt: prompt,
      context: {
        url: window.location.href,
        selectedElement: selectedElement ? {
          tagName: selectedElement.tagName,
          id: selectedElement.id,
          className: selectedElement.className,
          innerText: selectedElement.innerText?.substring(0, 200)
        } : null
      }
    });
    
    addChatMessage('AniCode', 'Processing your request...');
  }

  function addChatMessage(sender, message) {
    if (!chatDialog) return;
    
    const messagesDiv = chatDialog.querySelector('.anicode-chat-messages');
    const messageEl = document.createElement('div');
    messageEl.className = `anicode-message ${sender === 'You' ? 'user' : 'assistant'}`;
    messageEl.innerHTML = `
      <strong>${sender}:</strong> ${message}
    `;
    
    messagesDiv.appendChild(messageEl);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
  }

  function toggleTasks() {
    if (!taskPanel) {
      createTaskPanel();
    } else {
      taskPanel.style.display = taskPanel.style.display === 'none' ? 'block' : 'none';
    }
    
    // Request current tasks
    chrome.runtime.sendMessage({ type: 'GET_TASKS' }, (response) => {
      if (response && response.tasks) {
        displayTasks(response.tasks);
      }
    });
  }

  function createTaskPanel() {
    taskPanel = document.createElement('div');
    taskPanel.className = 'anicode-task-panel';
    taskPanel.innerHTML = `
      <div class="anicode-panel-header">
        <span>Tasks</span>
        <button class="anicode-close">×</button>
      </div>
      <div class="anicode-task-list"></div>
    `;
    
    document.body.appendChild(taskPanel);
    
    // Position the panel
    taskPanel.style.position = 'fixed';
    taskPanel.style.left = '20px';
    taskPanel.style.top = '100px';
    taskPanel.style.width = '300px';
    taskPanel.style.maxHeight = '400px';
    taskPanel.style.zIndex = '10001';
    
    taskPanel.querySelector('.anicode-close').onclick = () => {
      taskPanel.style.display = 'none';
    };
  }

  function displayTasks(tasks) {
    if (!taskPanel) return;
    
    const listDiv = taskPanel.querySelector('.anicode-task-list');
    listDiv.innerHTML = '';
    
    if (tasks.length === 0) {
      listDiv.innerHTML = '<p>No active tasks</p>';
      return;
    }
    
    tasks.forEach(task => {
      const taskEl = document.createElement('div');
      taskEl.className = `anicode-task ${task.status}`;
      taskEl.innerHTML = `
        <div class="task-status">${getStatusIcon(task.status)}</div>
        <div class="task-content">
          <div class="task-prompt">${task.prompt?.substring(0, 50)}...</div>
          <div class="task-time">${new Date(task.createdAt).toLocaleTimeString()}</div>
        </div>
      `;
      listDiv.appendChild(taskEl);
    });
  }

  function updateTaskDisplay(task) {
    // Update task in panel if visible
    displayTasks([task]); // This should append/update, not replace
    
    // Show notification for status changes
    if (task.status === 'completed') {
      showNotification(`Task completed: ${task.prompt?.substring(0, 30)}...`);
    } else if (task.status === 'failed') {
      showNotification(`Task failed: ${task.error}`, 'error');
    }
  }

  function getStatusIcon(status) {
    const icons = {
      pending: '⏳',
      in_progress: '🔄',
      completed: '✅',
      failed: '❌'
    };
    return icons[status] || '❓';
  }

  function showGitLog() {
    chrome.runtime.sendMessage({ type: 'GET_GIT_LOG' }, (response) => {
      if (response && response.gitLog) {
        displayGitLog(response.gitLog);
      }
    });
  }

  function displayGitLog(logs) {
    const gitPanel = document.createElement('div');
    gitPanel.className = 'anicode-git-panel';
    gitPanel.innerHTML = `
      <div class="anicode-panel-header">
        <span>Git Log</span>
        <button class="anicode-close">×</button>
      </div>
      <div class="anicode-git-log">
        ${logs.map(log => `
          <div class="git-commit">
            <span class="git-hash">${log.hash}</span>
            <span class="git-message">${log.message}</span>
            <span class="git-author">${log.author}</span>
            <span class="git-date">${log.date}</span>
          </div>
        `).join('')}
      </div>
    `;
    
    document.body.appendChild(gitPanel);
    
    // Position and style
    gitPanel.style.position = 'fixed';
    gitPanel.style.right = '20px';
    gitPanel.style.top = '100px';
    gitPanel.style.width = '500px';
    gitPanel.style.maxHeight = '400px';
    gitPanel.style.zIndex = '10001';
    
    gitPanel.querySelector('.anicode-close').onclick = () => {
      gitPanel.remove();
    };
  }

  function quickPrompt() {
    const prompt = window.prompt('Enter your AniCode prompt:');
    if (prompt) {
      chrome.runtime.sendMessage({
        type: 'SEND_PROMPT',
        prompt: prompt
      });
      showNotification('Prompt sent to AniCode');
    }
  }

  function toggleSelection() {
    // Toggle element selection mode
    // This is already handled by the edit mode
  }

  function handleKeyboard(e) {
    // Ctrl+Shift+E: Toggle edit mode
    if (e.ctrlKey && e.shiftKey && e.key === 'E') {
      if (editMode) {
        chrome.runtime.sendMessage({ type: 'DISABLE_EDIT_MODE' });
      } else {
        chrome.runtime.sendMessage({ type: 'ENABLE_EDIT_MODE' });
      }
    }
    
    // Ctrl+Shift+A: Quick prompt
    if (e.ctrlKey && e.shiftKey && e.key === 'A' && editMode) {
      quickPrompt();
    }
  }

  function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `anicode-notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Position
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.zIndex = '10002';
    
    // Auto-remove after 3 seconds
    setTimeout(() => {
      notification.remove();
    }, 3000);
  }

  function checkAutoConnect() {
    // Check if this domain has a stored connection
    chrome.storage.local.get(['autoConnect'], (result) => {
      if (result.autoConnect && result.autoConnect[window.location.hostname]) {
        // Auto-connect to AniCode
        connectToAniCode(result.autoConnect[window.location.hostname]);
      }
    });
  }

  function connectToAniCode(config) {
    chrome.runtime.sendMessage({
      type: 'CONNECT',
      projectId: config.projectId,
      token: config.token,
      url: config.url
    });
  }

  function handleConnected() {
    isConnected = true;
    showNotification('Connected to AniCode');
  }

  function handleDisconnected() {
    isConnected = false;
    showNotification('Disconnected from AniCode', 'warning');
  }

  function handleAniCodeMessage(data) {
    // Handle messages from AniCode
    if (data.type === 'PROMPT_RESPONSE' && chatDialog) {
      addChatMessage('AniCode', data.response.message || 'Response received');
    }
  }

  // Initialize
  init();
})();
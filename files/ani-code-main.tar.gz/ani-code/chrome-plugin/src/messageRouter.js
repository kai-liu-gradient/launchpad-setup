// Message Router for Chrome Extension
// Handles communication between popup, background, and content scripts

class MessageRouter {
  constructor() {
    this.listeners = new Map();
    this.pendingResponses = new Map();
    this.responseTimeout = 10000; // 10 seconds default
    this.debugMode = true;
  }

  log(...args) {
    if (this.debugMode) {
      console.log('[MessageRouter]', ...args);
    }
  }

  // Register a message handler
  on(messageType, handler) {
    if (!this.listeners.has(messageType)) {
      this.listeners.set(messageType, []);
    }
    this.listeners.get(messageType).push(handler);
    this.log(`Registered handler for: ${messageType}`);
  }

  // Remove a message handler
  off(messageType, handler) {
    const handlers = this.listeners.get(messageType);
    if (handlers) {
      const index = handlers.indexOf(handler);
      if (index > -1) {
        handlers.splice(index, 1);
        this.log(`Removed handler for: ${messageType}`);
      }
    }
  }

  // Send a message and wait for response
  async sendMessage(message, options = {}) {
    const messageId = `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const timeout = options.timeout || this.responseTimeout;
    
    return new Promise((resolve, reject) => {
      // Set up timeout
      const timeoutId = setTimeout(() => {
        this.pendingResponses.delete(messageId);
        reject(new Error(`Message timeout: ${message.type}`));
      }, timeout);

      // Store the response handler
      this.pendingResponses.set(messageId, {
        resolve: (response) => {
          clearTimeout(timeoutId);
          this.pendingResponses.delete(messageId);
          resolve(response);
        },
        reject: (error) => {
          clearTimeout(timeoutId);
          this.pendingResponses.delete(messageId);
          reject(error);
        }
      });

      // Send the message with ID
      const messageWithId = { ...message, __messageId: messageId };
      
      this.log(`Sending message: ${message.type} with ID: ${messageId}`);
      
      // Try different sending methods based on context
      if (typeof chrome !== 'undefined' && chrome.runtime) {
        chrome.runtime.sendMessage(messageWithId, (response) => {
          if (chrome.runtime.lastError) {
            this.log(`Error sending message: ${chrome.runtime.lastError.message}`);
            const pending = this.pendingResponses.get(messageId);
            if (pending) {
              pending.reject(new Error(chrome.runtime.lastError.message));
            }
          } else if (response && response.__isResponse && response.__responseToId === messageId) {
            const pending = this.pendingResponses.get(messageId);
            if (pending) {
              pending.resolve(response.data);
            }
          }
        });
      }
    });
  }

  // Broadcast a message without waiting for response
  broadcast(message) {
    this.log(`Broadcasting: ${message.type}`);
    
    // Send to all contexts
    if (typeof chrome !== 'undefined' && chrome.runtime) {
      // Send to background/popup
      chrome.runtime.sendMessage(message).catch(err => {
        this.log(`Broadcast to runtime failed:`, err.message);
      });
      
      // Send to all tabs
      if (chrome.tabs) {
        chrome.tabs.query({}, (tabs) => {
          tabs.forEach(tab => {
            chrome.tabs.sendMessage(tab.id, message).catch(err => {
              this.log(`Broadcast to tab ${tab.id} failed:`, err.message);
            });
          });
        });
      }
    }
  }

  // Handle incoming messages
  handleMessage(request, sender, sendResponse) {
    this.log(`Received message: ${request.type}`, request);
    
    // Check if this is a response to a pending request
    if (request.__isResponse && request.__responseToId) {
      const pending = this.pendingResponses.get(request.__responseToId);
      if (pending) {
        pending.resolve(request.data);
        return false; // Synchronous response
      }
    }
    
    // Handle regular messages
    const handlers = this.listeners.get(request.type);
    if (handlers && handlers.length > 0) {
      // Execute handlers
      Promise.all(handlers.map(handler => {
        try {
          return Promise.resolve(handler(request, sender));
        } catch (error) {
          this.log(`Handler error for ${request.type}:`, error);
          return Promise.reject(error);
        }
      })).then(results => {
        // If message has an ID, send response
        if (request.__messageId) {
          const response = {
            __isResponse: true,
            __responseToId: request.__messageId,
            data: results[0] // Use first handler's result
          };
          sendResponse(response);
        } else if (sendResponse) {
          // Legacy response for messages without ID
          sendResponse(results[0]);
        }
      }).catch(error => {
        this.log(`Error handling ${request.type}:`, error);
        if (request.__messageId) {
          sendResponse({
            __isResponse: true,
            __responseToId: request.__messageId,
            error: error.message
          });
        } else if (sendResponse) {
          sendResponse({ error: error.message });
        }
      });
      
      return true; // Async response
    }
    
    // No handler found
    this.log(`No handler for message type: ${request.type}`);
    return false;
  }

  // Initialize the router (call in background and popup)
  init() {
    if (typeof chrome !== 'undefined' && chrome.runtime) {
      chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        return this.handleMessage(request, sender, sendResponse);
      });
      this.log('Message router initialized');
    }
  }
}

// Export for ES6 modules only (as specified in manifest.json)
export { MessageRouter };
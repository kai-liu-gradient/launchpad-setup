# 16x16
sips -z 16 16 logo.png --out icon16.png

# 48x48
sips -z 48 48 logo.png --out icon48.png

# 128x128
sips -z 128 128 logo.png --out icon128.png

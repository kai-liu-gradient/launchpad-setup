// Popup script for AniCode Chrome Extension
document.addEventListener('DOMContentLoaded', () => {
  // Elements
  const elements = {
    connectionStatus: document.getElementById('connectionStatus'),
    connectionToken: document.getElementById('connectionToken'),
    connectionInfo: document.getElementById('connectionInfo'),
    projectName: document.getElementById('projectName'),
    serverUrl: document.getElementById('serverUrl'),
    tokenExpiry: document.getElementById('tokenExpiry'),
    connectBtn: document.getElementById('connectBtn'),
    disconnectBtn: document.getElementById('disconnectBtn'),
    clearBtn: document.getElementById('clearBtn'),
    actionsSection: document.getElementById('actionsSection'),
    editModeBtn: document.getElementById('editModeBtn'),
    tasksBtn: document.getElementById('tasksBtn'),
    gitLogBtn: document.getElementById('gitLogBtn'),
    chatBtn: document.getElementById('chatBtn'),
    tasksSection: document.getElementById('tasksSection'),
    taskList: document.getElementById('taskList'),
    gitSection: document.getElementById('gitSection'),
    gitBranch: document.getElementById('gitBranch'),
    lastCommit: document.getElementById('lastCommit'),
    autoConnect: document.getElementById('autoConnect'),
    showNotifications: document.getElementById('showNotifications'),
    darkMode: document.getElementById('darkMode'),
    helpLink: document.getElementById('helpLink')
  };

  let isConnected = false;
  let currentTasks = [];
  let decodedToken = null;

  // Load saved settings
  loadSettings();

  // Event listeners
  elements.connectionToken.addEventListener('input', handleTokenInput);
  elements.connectBtn.addEventListener('click', connect);
  elements.disconnectBtn.addEventListener('click', disconnect);
  elements.clearBtn.addEventListener('click', clearToken);
  elements.editModeBtn.addEventListener('click', toggleEditMode);
  elements.tasksBtn.addEventListener('click', toggleTasks);
  elements.gitLogBtn.addEventListener('click', showGitLog);
  elements.chatBtn.addEventListener('click', openChat);
  elements.autoConnect.addEventListener('change', saveSettings);
  elements.showNotifications.addEventListener('change', saveSettings);
  elements.darkMode.addEventListener('change', toggleDarkMode);
  elements.helpLink.addEventListener('click', showHelp);

  // Listen for messages from background
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    switch (request.type) {
      case 'CONNECTION_STATUS':
        updateConnectionStatus(request.connected);
        break;
      case 'TASK_UPDATE':
        updateTask(request.task);
        break;
      case 'GIT_UPDATE':
        updateGitInfo(request.gitData);
        break;
    }
  });

  function loadSettings() {
    chrome.storage.local.get(['anicode_settings'], (result) => {
      const settings = result.anicode_settings || {};
      
      if (settings.token) {
        elements.connectionToken.value = settings.token;
        handleTokenInput();
      }
      
      elements.autoConnect.checked = settings.autoConnect !== false;
      elements.showNotifications.checked = settings.showNotifications !== false;
      elements.darkMode.checked = settings.darkMode || false;
      
      if (settings.darkMode) {
        document.body.classList.add('dark-mode');
      }
      
      // Auto-connect if enabled and token exists
      if (settings.autoConnect && settings.token) {
        setTimeout(() => {
          if (decodedToken) {
            connect();
          }
        }, 500);
      }
    });
  }

  function saveSettings() {
    const settings = {
      token: elements.connectionToken.value,
      autoConnect: elements.autoConnect.checked,
      showNotifications: elements.showNotifications.checked,
      darkMode: elements.darkMode.checked
    };
    
    chrome.storage.local.set({ anicode_settings: settings });
  }

  function handleTokenInput() {
    const token = elements.connectionToken.value.trim();
    
    if (!token) {
      elements.connectionInfo.style.display = 'none';
      decodedToken = null;
      return;
    }
    
    try {
      // Decode and validate token
      const decoded = decodeToken(token);
      
      if (decoded.valid) {
        decodedToken = decoded;
        displayTokenInfo(decoded.payload);
        elements.connectionInfo.style.display = 'block';
        elements.connectBtn.disabled = false;
      } else {
        showError(`Invalid token: ${decoded.error}`);
        elements.connectionInfo.style.display = 'none';
        decodedToken = null;
        elements.connectBtn.disabled = true;
      }
    } catch (error) {
      // Invalid token format, don't show error until user tries to connect
      elements.connectionInfo.style.display = 'none';
      decodedToken = null;
    }
  }

  function decodeToken(tokenString) {
    try {
      const parts = tokenString.split('.');
      
      if (parts.length !== 3) {
        return { valid: false, error: 'Invalid token format' };
      }
      
      const [encodedPayload, signature, secret] = parts;
      
      // Decode payload
      const payload = JSON.parse(atob(encodedPayload));
      
      // Check expiry
      if (Date.now() > payload.expiresAt) {
        return { valid: false, error: 'Token expired' };
      }
      
      return { 
        valid: true, 
        payload,
        token: tokenString,
        secret
      };
    } catch (error) {
      return { valid: false, error: error.message };
    }
  }

  function displayTokenInfo(payload) {
    elements.projectName.textContent = payload.project || 'Unknown';
    elements.serverUrl.textContent = payload.serverUrl || 'Unknown';
    elements.tokenExpiry.textContent = new Date(payload.expiresAt).toLocaleString();
  }

  async function connect() {
    if (!decodedToken) {
      showError('Please enter a valid token');
      return;
    }
    
    // Save token before connecting
    saveSettings();
    
    // Extract serverUrl for proper connection
    const serverUrl = decodedToken.payload?.serverUrl || 'ws://localhost:6502';
    
    // Send connection request to background with full token and server URL
    chrome.runtime.sendMessage({
      type: 'CONNECT',
      token: decodedToken.token,
      payload: decodedToken.payload,
      url: serverUrl,
      projectId: decodedToken.payload?.project || 'default'
    }, (response) => {
      if (chrome.runtime.lastError) {
        showError('Failed to connect: ' + chrome.runtime.lastError.message);
        return;
      }
      
      if (response && response.success) {
        updateConnectionStatus(true);
        showSuccess('Connected to AniCode');
      } else {
        showError(response?.error || 'Connection failed');
      }
    });
  }

  function disconnect() {
    chrome.runtime.sendMessage({ type: 'DISCONNECT' }, (response) => {
      if (response && response.success) {
        updateConnectionStatus(false);
        showSuccess('Disconnected from AniCode');
      }
    });
  }

  function clearToken() {
    if (isConnected) {
      disconnect();
    }
    
    // Get domain from current token if available
    let domain = null;
    if (decodedToken?.payload?.serverUrl) {
      try {
        domain = new URL(decodedToken.payload.serverUrl).hostname;
      } catch (e) {
        console.error('Error extracting domain from serverUrl:', e);
      }
    }
    
    elements.connectionToken.value = '';
    elements.connectionInfo.style.display = 'none';
    decodedToken = null;
    
    // Clear saved token
    chrome.storage.local.get(['anicode_settings'], (result) => {
      const settings = result.anicode_settings || {};
      delete settings.token;
      chrome.storage.local.set({ anicode_settings: settings });
    });
    
    // Clear token for specific domain in background
    chrome.runtime.sendMessage({ 
      type: 'CLEAR_TOKEN',
      domain: domain 
    });
    
    showSuccess('Token cleared');
  }

  function toggleEditMode() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { 
          type: isEditMode ? 'DISABLE_EDIT_MODE' : 'ENABLE_EDIT_MODE' 
        });
        isEditMode = !isEditMode;
        elements.editModeBtn.classList.toggle('active', isEditMode);
      }
    });
  }

  function toggleTasks() {
    const isVisible = elements.tasksSection.style.display !== 'none';
    elements.tasksSection.style.display = isVisible ? 'none' : 'block';
    
    if (!isVisible) {
      // Request current tasks
      chrome.runtime.sendMessage({ type: 'GET_TASKS' }, (response) => {
        if (response && response.tasks) {
          displayTasks(response.tasks);
        }
      });
    }
  }

  function displayTasks(tasks) {
    currentTasks = tasks;
    
    if (tasks.length === 0) {
      elements.taskList.innerHTML = '<p class="no-tasks">No active tasks</p>';
      return;
    }
    
    elements.taskList.innerHTML = tasks.map(task => `
      <div class="task-item ${task.status}">
        <span class="task-status">${getStatusIcon(task.status)}</span>
        <div class="task-content">
          <div class="task-prompt">${task.prompt?.substring(0, 50)}...</div>
          <div class="task-time">${new Date(task.createdAt).toLocaleTimeString()}</div>
        </div>
      </div>
    `).join('');
  }

  function updateTask(task) {
    // Update task in list
    const index = currentTasks.findIndex(t => t.id === task.id);
    if (index !== -1) {
      currentTasks[index] = task;
    } else {
      currentTasks.push(task);
    }
    
    if (elements.tasksSection.style.display !== 'none') {
      displayTasks(currentTasks);
    }
    
    // Show notification for completed tasks
    if (task.status === 'completed' && elements.showNotifications.checked) {
      showSuccess(`Task completed: ${task.prompt?.substring(0, 30)}...`);
    }
  }

  function showGitLog() {
    elements.gitSection.style.display = 
      elements.gitSection.style.display === 'none' ? 'block' : 'none';
    
    if (elements.gitSection.style.display !== 'none') {
      chrome.runtime.sendMessage({ type: 'GET_GIT_LOG' }, (response) => {
        if (response && response.gitLog && response.gitLog.length > 0) {
          const latestCommit = response.gitLog[0];
          elements.lastCommit.textContent = 
            `${latestCommit.hash} - ${latestCommit.message}`;
        }
      });
    }
  }

  function updateGitInfo(gitData) {
    if (gitData.branch) {
      elements.gitBranch.textContent = gitData.branch;
    }
    if (gitData.lastCommit) {
      elements.lastCommit.textContent = 
        `${gitData.lastCommit.hash} - ${gitData.lastCommit.message}`;
    }
  }

  function openChat() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        // First ensure edit mode is enabled
        chrome.tabs.sendMessage(tabs[0].id, { type: 'ENABLE_EDIT_MODE' });
        // Then open chat
        chrome.tabs.sendMessage(tabs[0].id, { type: 'OPEN_CHAT' });
        // Close popup
        window.close();
      }
    });
  }

  function toggleDarkMode() {
    document.body.classList.toggle('dark-mode', elements.darkMode.checked);
    saveSettings();
  }

  function updateConnectionStatus(connected) {
    isConnected = connected;
    
    const indicator = elements.connectionStatus.querySelector('.status-indicator');
    const text = elements.connectionStatus.querySelector('.status-text');
    
    if (connected) {
      indicator.className = 'status-indicator connected';
      text.textContent = 'Connected';
      elements.connectBtn.disabled = true;
      elements.disconnectBtn.disabled = false;
      elements.actionsSection.style.display = 'block';
    } else {
      indicator.className = 'status-indicator disconnected';
      text.textContent = 'Disconnected';
      elements.connectBtn.disabled = false;
      elements.disconnectBtn.disabled = true;
      elements.actionsSection.style.display = 'none';
    }
  }

  function getStatusIcon(status) {
    const icons = {
      pending: '⏳',
      in_progress: '🔄',
      completed: '✅',
      failed: '❌'
    };
    return icons[status] || '❓';
  }

  function showError(message) {
    showNotification(message, 'error');
  }

  function showSuccess(message) {
    showNotification(message, 'success');
  }

  function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
      notification.classList.add('show');
    }, 10);
    
    setTimeout(() => {
      notification.classList.remove('show');
      setTimeout(() => notification.remove(), 300);
    }, 3000);
  }

  function showHelp() {
    const helpText = `
AniCode Chrome Plugin Help

1. Generate a token in your project:
   Run: anicode plugin new-token

2. Paste the token in this popup

3. Click Connect to establish connection

4. Use the action buttons to:
   - Enable edit mode on webpages
   - View and manage tasks
   - Monitor git activity
   - Chat with AniCode AI

Keyboard shortcuts:
- Ctrl+Shift+E: Toggle edit mode
- Ctrl+Shift+A: Quick prompt
    `;
    alert(helpText);
  }

  let isEditMode = false;
});
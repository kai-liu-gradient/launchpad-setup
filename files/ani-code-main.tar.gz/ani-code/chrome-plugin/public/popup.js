// Popup script for AniCode Chrome Extension - Mobile Style UI
document.addEventListener('DOMContentLoaded', () => {
  // ===========================
  // State Management
  // ===========================
  const state = {
    isConnected: false,
    currentTab: 'homeTab',
    chatMode: 'add',
    tasks: [],
    connectionInfo: null,
    pingInterval: null,
    backgroundPort: null,
    currentDomain: null,
    availableTokens: {}
  };

  // ===========================
  // Element References
  // ===========================
  const elements = {
    // Header
    statusIndicator: document.getElementById('statusIndicator'),
    statusText: document.getElementById('statusText'),
    statusLatency: document.getElementById('statusLatency'),
    
    // Navigation
    navItems: document.querySelectorAll('.nav-item'),
    tabPanels: document.querySelectorAll('.tab-panel'),
    
    // Home Tab
    tokenInput: document.getElementById('tokenInput'),
    connectionPreview: document.getElementById('connectionPreview'),
    previewProject: document.getElementById('previewProject'),
    previewServer: document.getElementById('previewServer'),
    connectBtn: document.getElementById('connectBtn'),
    clearTokenBtn: document.getElementById('clearTokenBtn'),
    connectionCard: document.getElementById('connectionCard'),
    connectedCard: document.getElementById('connectedCard'),
    connectedProject: document.getElementById('connectedProject'),
    connectedServer: document.getElementById('connectedServer'),
    latencyValue: document.getElementById('latencyValue'),
    disconnectBtn: document.getElementById('disconnectBtn'),
    quickActions: document.getElementById('quickActions'),
    
    // Chat Tab
    chatMessages: document.getElementById('chatMessages'),
    chatInput: document.getElementById('chatInput'),
    chatSendBtn: document.getElementById('chatSendBtn'),
    
    // Tasks Tab
    tasksList: document.getElementById('tasksList'),
    taskCounter: document.getElementById('taskCounter'),
    tasksBadge: document.getElementById('tasksBadge'),
    refreshTasksBtn: document.getElementById('refreshTasksBtn'),
    
    // Settings Tab
    autoConnect: document.getElementById('autoConnect'),
    rememberToken: document.getElementById('rememberToken'),
    showNotifications: document.getElementById('showNotifications'),
    soundEnabled: document.getElementById('soundEnabled'),
    darkMode: document.getElementById('darkMode'),
    compactView: document.getElementById('compactView'),
    gitBranch: document.getElementById('gitBranch'),
    lastCommit: document.getElementById('lastCommit'),
    gitChanges: document.getElementById('gitChanges'),
    refreshGitBtn: document.getElementById('refreshGitBtn'),
    
    // Toast Container
    toastContainer: document.getElementById('toastContainer')
  };

  // ===========================
  // Initialize
  // ===========================
  function init() {
    console.log('=== AniCode Popup Initialized ===');
    setupEventListeners();
    loadSettings();
    establishBackgroundConnection();
    checkConnectionStatus();
    
    // Load saved token if remember is enabled
    loadSavedToken();
  }

  // ===========================
  // Event Listeners
  // ===========================
  function setupEventListeners() {
    // Navigation
    elements.navItems.forEach(item => {
      item.addEventListener('click', () => {
        // Check if chat tab is being selected while disconnected
        if (item.dataset.tab === 'chatTab' && !state.isConnected) {
          showToast('Connect first to use chat', 'warning');
          return;
        }
        switchTab(item.dataset.tab);
      });
    });
    
    // Connection
    elements.connectBtn?.addEventListener('click', handleConnect);
    elements.disconnectBtn?.addEventListener('click', handleDisconnect);
    elements.clearTokenBtn?.addEventListener('click', clearToken);
    elements.tokenInput?.addEventListener('input', handleTokenInput);
    
    // Chat
    elements.chatSendBtn?.addEventListener('click', sendChatMessage);
    elements.chatInput?.addEventListener('keydown', (e) => {
      // Shift+Tab to toggle mode
      if (e.key === 'Tab' && e.shiftKey) {
        e.preventDefault();
        toggleChatMode();
      }
      // Enter sends message (Shift+Enter for new line)
      else if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendChatMessage();
      }
    });
    
    // Auto-resize textarea
    elements.chatInput?.addEventListener('input', () => {
      elements.chatInput.style.height = 'auto';
      elements.chatInput.style.height = Math.min(elements.chatInput.scrollHeight, 120) + 'px';
    });
    
    // Quick Actions
    document.getElementById('quickAddTask')?.addEventListener('click', () => {
      if (!state.isConnected) {
        showToast('Connect first to use chat', 'warning');
        return;
      }
      switchTab('chatTab');
      state.chatMode = 'add';
      updateChatPlaceholder();
    });
    document.getElementById('quickContinue')?.addEventListener('click', () => {
      if (!state.isConnected) {
        showToast('Connect first to use chat', 'warning');
        return;
      }
      switchTab('chatTab');
      state.chatMode = 'continue';
      updateChatPlaceholder();
    });
    document.getElementById('quickViewTasks')?.addEventListener('click', () => {
      switchTab('tasksTab');
    });
    document.getElementById('quickGitStatus')?.addEventListener('click', () => {
      switchTab('settingsTab');
      loadGitStatus();
    });
    
    // Settings
    elements.autoConnect?.addEventListener('change', saveSettings);
    elements.rememberToken?.addEventListener('change', saveSettings);
    elements.showNotifications?.addEventListener('change', saveSettings);
    elements.soundEnabled?.addEventListener('change', saveSettings);
    elements.darkMode?.addEventListener('change', toggleDarkMode);
    elements.compactView?.addEventListener('change', saveSettings);
    elements.refreshGitBtn?.addEventListener('click', loadGitStatus);
    
    // Tasks
    elements.refreshTasksBtn?.addEventListener('click', () => {
      loadTasks();
      showToast('Tasks refreshed', 'success');
    });
  }

  // ===========================
  // Tab Navigation
  // ===========================
  function switchTab(tabId) {
    // Update state
    state.currentTab = tabId;
    
    // Update UI
    elements.tabPanels.forEach(panel => {
      panel.classList.toggle('active', panel.id === tabId);
    });
    
    elements.navItems.forEach(item => {
      item.classList.toggle('active', item.dataset.tab === tabId);
    });
    
    // Tab-specific actions
    if (tabId === 'tasksTab') {
      // Always update tasks UI to show connection notice if needed
      if (state.isConnected) {
        loadTasks();
      } else {
        updateTasksUI();
      }
    } else if (tabId === 'settingsTab' && state.isConnected) {
      loadGitStatus();
    }
  }

  // ===========================
  // Connection Management
  // ===========================
  function handleTokenInput() {
    const token = elements.tokenInput.value.trim();
    if (!token) {
      elements.connectionPreview.style.display = 'none';
      return;
    }

    try {
      let tokenData;
      
      // Check if it's a raw JWT token (format: payload.signature.secret)
      if (token.split('.').length === 3 && !token.includes('{')) {
        // Parse the JWT payload for preview
        const [encodedPayload] = token.split('.');
        const payload = JSON.parse(atob(encodedPayload));
        
        tokenData = {
          project: payload.project || 'Unknown',
          url: payload.serverUrl || 'ws://localhost:6502'
        };
      } else {
        // Try to decode as base64-encoded config
        tokenData = JSON.parse(atob(token));
      }
      
      if (tokenData.project && tokenData.url) {
        elements.connectionPreview.style.display = 'block';
        elements.previewProject.textContent = tokenData.project;
        elements.previewServer.textContent = tokenData.url.replace('ws://', '').replace('wss://', '');
      }
    } catch (e) {
      elements.connectionPreview.style.display = 'none';
    }
  }

  function handleConnect() {
    const token = elements.tokenInput.value.trim();
    
    if (!token) {
      showToast('Please enter a connection token', 'error');
      return;
    }

    // Decode and validate token
    let tokenData;
    
    try {
      console.log('Attempting to parse token...');
      
      // Check if it's a raw JWT token (format: payload.signature.secret)
      if (token.split('.').length === 3 && !token.includes('{')) {
        console.log('Detected raw JWT token format');
        
        // Parse the JWT payload
        const [encodedPayload] = token.split('.');
        const payload = JSON.parse(atob(encodedPayload));
        console.log('JWT payload decoded:', payload);
        
        // For raw JWT tokens, extract server URL from payload and use the token directly
        tokenData = {
          project: payload.project || 'Unknown',
          url: payload.serverUrl || 'ws://localhost:6502',
          token: token
        };
      } else {
        // Try to decode as base64-encoded config
        console.log('Attempting to decode as base64 config...');
        tokenData = JSON.parse(atob(token));
      }
      
      console.log('Token data extracted:', { 
        project: tokenData.project, 
        url: tokenData.url,
        hasToken: !!tokenData.token
      });
      
      if (!tokenData.url || !tokenData.project || !tokenData.token) {
        const missingFields = [];
        if (!tokenData.url) missingFields.push('url');
        if (!tokenData.project) missingFields.push('project');
        if (!tokenData.token) missingFields.push('token');
        showToast(`Invalid token format - missing: ${missingFields.join(', ')}`, 'error');
        return;
      }

      // Show connecting state
      const btnText = elements.connectBtn.querySelector('.btn-text');
      const btnSpinner = elements.connectBtn.querySelector('.btn-spinner');
      elements.connectBtn.disabled = true;
      btnText.textContent = 'Connecting...';
      btnSpinner.style.display = 'inline-block';

      // Save token with domain association if remember is enabled
      if (elements.rememberToken?.checked) {
        // Store token with domain info in background
        chrome.runtime.sendMessage({
          type: 'SET_TOKEN',
          token: tokenData.token,
          tokenInfo: {
            project: tokenData.project,
            serverUrl: tokenData.url,
            domain: state.currentDomain
          }
        });
      }

      // Send connection request to background with full token data
      chrome.runtime.sendMessage({
        type: 'CONNECT',
        token: tokenData.token,
        url: tokenData.url,
        projectId: tokenData.project,
        payload: tokenData  // Include full payload for domain extraction
      }, (response) => {
        elements.connectBtn.disabled = false;
        btnText.textContent = 'Connect';
        btnSpinner.style.display = 'none';

        if (chrome.runtime.lastError) {
          console.error('Chrome runtime error:', chrome.runtime.lastError);
          showToast('Failed to connect: ' + chrome.runtime.lastError.message, 'error');
        } else if (response && response.success) {
          console.log('Connection successful!');
          state.isConnected = true;
          state.connectionInfo = tokenData;
          
          // Ensure we have the current domain captured
          if (!state.currentDomain) {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
              if (tabs && tabs.length > 0 && tabs[0].url) {
                try {
                  state.currentDomain = new URL(tabs[0].url).hostname;
                  console.log('Captured domain during connection:', state.currentDomain);
                } catch (e) {
                  console.error('Error capturing domain:', e);
                }
              }
            });
          }
          
          updateConnectionUI(true);
          showToast('Connected successfully!', 'success');
          startLatencyCheck();
          
          // Auto-redirect to chat tab after successful connection
          setTimeout(() => {
            switchTab('chatTab');
          }, 500);
        } else {
          console.error('Connection failed:', response);
          showToast(response?.error || 'Failed to connect', 'error');
          // Return to home tab on connection failure
          switchTab('homeTab');
        }
      });
    } catch (e) {
      console.error('Token validation failed:', e);
      showToast('Invalid token format', 'error');
      // Return to home tab on token validation failure
      switchTab('homeTab');
    }
  }

  function handleDisconnect() {
    // Clear token for current domain to prevent auto-reconnect
    if (state.currentDomain && elements.rememberToken?.checked) {
      chrome.runtime.sendMessage({
        type: 'CLEAR_TOKEN',
        domain: state.currentDomain
      }, (response) => {
        console.log('Token cleared for domain:', state.currentDomain);
      });
    }
    
    chrome.runtime.sendMessage({ type: 'DISCONNECT' }, () => {
      state.isConnected = false;
      state.connectionInfo = null;
      updateConnectionUI(false);
      stopLatencyCheck();
      showToast('Disconnected', 'success');
      
      // Clear token input to prevent immediate reconnection
      elements.tokenInput.value = '';
      elements.connectionPreview.style.display = 'none';
      
      // Always return to home tab on disconnect
      switchTab('homeTab');
    });
  }

  function clearToken() {
    elements.tokenInput.value = '';
    elements.connectionPreview.style.display = 'none';
    
    // Clear token for current domain
    chrome.runtime.sendMessage({
      type: 'CLEAR_TOKEN',
      domain: state.currentDomain
    }, (response) => {
      if (response && response.success) {
        showToast(`Token cleared for ${state.currentDomain || 'current domain'}`, 'success');
        // Refresh available tokens
        loadSavedToken();
      }
    });
  }

  function updateConnectionUI(connected) {
    // Update header status
    elements.statusIndicator.classList.toggle('connected', connected);
    elements.statusText.textContent = connected ? 'Connected' : 'Disconnected';
    
    // Show/hide latency
    if (connected && elements.statusLatency) {
      elements.statusLatency.style.display = 'inline';
    } else if (elements.statusLatency) {
      elements.statusLatency.style.display = 'none';
      elements.statusLatency.textContent = '';
    }
    
    // Clear connection info if disconnected
    if (!connected) {
      state.connectionInfo = null;
      // Stop any pending operations
      if (state.pingInterval) {
        clearInterval(state.pingInterval);
        state.pingInterval = null;
      }
    }
    
    // Update chat tab navigation
    const chatNavItem = document.getElementById('navChat');
    if (chatNavItem) {
      chatNavItem.classList.toggle('disabled', !connected);
    }
    
    // Update home tab
    if (connected && state.connectionInfo) {
      elements.connectionCard.style.display = 'none';
      elements.connectedCard.style.display = 'block';
      elements.quickActions.style.display = 'block';
      
      elements.connectedProject.textContent = state.connectionInfo.project;
      elements.connectedServer.textContent = state.connectionInfo.url.replace('ws://', '').replace('wss://', '');
      
      // Display domain info if available
      if (state.currentDomain) {
        displayConnectedDomain();
      }
      
      // Enable chat
      elements.chatInput.disabled = false;
      elements.chatSendBtn.disabled = false;
      updateChatPlaceholder();
    } else {
      elements.connectionCard.style.display = 'block';
      elements.connectedCard.style.display = 'none';
      elements.quickActions.style.display = 'none';
      
      // Disable chat
      elements.chatInput.disabled = true;
      elements.chatSendBtn.disabled = true;
    }
  }

  // ===========================
  // Chat Management
  // ===========================
  function toggleChatMode() {
    state.chatMode = state.chatMode === 'add' ? 'continue' : 'add';
    updateChatPlaceholder();
    showToast(`Mode: ${state.chatMode === 'add' ? 'Add Task' : 'Continue'}`, 'info');
  }
  
  function updateChatPlaceholder() {
    elements.chatInput.placeholder = state.chatMode === 'add' ? 
      'Type /add for new task' : 
      'Type /continue message';
  }

  function sendChatMessage() {
    const message = elements.chatInput.value.trim();
    if (!message || !state.isConnected) return;

    // Add user message to chat
    addChatMessage(message, 'user');
    
    // Clear input
    elements.chatInput.value = '';

    // Send to background
    chrome.runtime.sendMessage({
      type: state.chatMode === 'add' ? 'ADD_TASK' : 'CONTINUE_TASK',
      prompt: message
    }, (response) => {
      if (chrome.runtime.lastError) {
        addChatMessage('Failed to send message', 'system');
      } else if (response && response.success) {
        addChatMessage(`Task ${state.chatMode === 'add' ? 'added' : 'continued'} successfully!`, 'assistant');
      } else {
        addChatMessage('Failed to process request', 'system');
      }
    });
  }

  function addChatMessage(message, type = 'user') {
    // Remove welcome message if it exists
    const welcome = elements.chatMessages.querySelector('.chat-welcome');
    if (welcome) welcome.remove();
    
    const messageDiv = document.createElement('div');
    messageDiv.className = `chat-message ${type}`;
    
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    contentDiv.textContent = message;
    
    messageDiv.appendChild(contentDiv);
    elements.chatMessages.appendChild(messageDiv);
    
    // Scroll to bottom
    elements.chatMessages.scrollTop = elements.chatMessages.scrollHeight;
  }

  // ===========================
  // Task Management
  // ===========================
  function loadTasks() {
    chrome.runtime.sendMessage({ type: 'GET_TASKS' }, (response) => {
      if (chrome.runtime.lastError || !response?.tasks) {
        state.tasks = [];
        updateTasksUI();
        return;
      }
      
      state.tasks = response.tasks;
      updateTasksUI();
    });
  }

  function updateTasksUI() {
    const runningTasks = state.tasks.filter(t => t.status === 'running');
    const taskCount = runningTasks.length;
    
    // Update counter
    elements.taskCounter.textContent = taskCount.toString();
    elements.tasksBadge.textContent = taskCount.toString();
    elements.tasksBadge.style.display = taskCount > 0 ? 'block' : 'none';
    
    // Update list
    if (!state.isConnected) {
      // Show connection required message
      elements.tasksList.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">⚡</div>
          <h3>Connection Required</h3>
          <p>Please connect to view and manage tasks</p>
          <button class="btn btn-primary" onclick="document.getElementById('navHome').click();">Connect Now</button>
        </div>
      `;
    } else if (state.tasks.length === 0) {
      elements.tasksList.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">📋</div>
          <h3>No Active Tasks</h3>
          <p>Tasks will appear here when you start them</p>
        </div>
      `;
    } else {
      // Create flattened task list without unnecessary wrapper divs
      elements.tasksList.innerHTML = state.tasks.map(task => {
        const startTime = task.startTime ? new Date(task.startTime).toLocaleTimeString() : '-';
        const duration = task.startTime ? 
          Math.floor((Date.now() - new Date(task.startTime).getTime()) / 1000) : 0;
        const durationStr = duration > 0 ? 
          `${Math.floor(duration / 60)}m ${duration % 60}s` : '-';
        
        return `
          <div class="task-item ${task.status}">
            <div class="task-header">
              <span class="task-title">Task #${task.id || 'Unknown'}</span>
              <span class="task-status ${task.status}">${task.status}</span>
            </div>
            <div class="task-prompt">${task.prompt || 'No description'}</div>
            <div class="task-details">
              <div class="task-detail-item">
                <span class="detail-icon">🕐</span>
                <span class="detail-label">Started:</span>
                <span class="detail-value">${startTime}</span>
              </div>
              <div class="task-detail-item">
                <span class="detail-icon">⏱️</span>
                <span class="detail-label">Duration:</span>
                <span class="detail-value">${durationStr}</span>
              </div>
              ${task.progress ? `
              <div class="task-detail-item">
                <span class="detail-icon">📊</span>
                <span class="detail-label">Progress:</span>
                <span class="detail-value">${task.progress}%</span>
              </div>` : ''}
              ${task.currentStep ? `
              <div class="task-detail-item full-width">
                <span class="detail-icon">▶️</span>
                <span class="detail-label">Current:</span>
                <span class="detail-value">${task.currentStep}</span>
              </div>` : ''}
            </div>
          </div>
        `;
      }).join('');
    }
  }

  // ===========================
  // Git Status
  // ===========================
  function loadGitStatus() {
    chrome.runtime.sendMessage({ type: 'GET_GIT_STATUS' }, (response) => {
      if (chrome.runtime.lastError || !response?.gitData) {
        elements.gitBranch.textContent = 'Not available';
        elements.lastCommit.textContent = 'Not available';
        elements.gitChanges.textContent = 'Not available';
        return;
      }
      
      const { gitData } = response;
      elements.gitBranch.textContent = gitData.branch || 'Unknown';
      elements.lastCommit.textContent = gitData.lastCommit ? 
        `${gitData.lastCommit.substring(0, 7)} - ${gitData.lastCommitMessage}` : 
        'No commits';
      elements.gitChanges.textContent = gitData.changes || '0 files';
    });
  }

  // ===========================
  // Latency Check
  // ===========================
  function startLatencyCheck() {
    if (state.pingInterval) return;
    
    const checkLatency = () => {
      if (!state.isConnected) return;
      
      // Request background to send a ping to the WebSocket server
      // The RTT will be measured in background.js and sent back via LATENCY_PONG message
      chrome.runtime.sendMessage({ type: 'SEND_PING' }, (response) => {
        if (chrome.runtime.lastError) {
          console.error('Ping request failed:', chrome.runtime.lastError);
        }
      });
    };
    
    checkLatency(); // Initial check
    state.pingInterval = setInterval(checkLatency, 30000); // Check every 30s
  }

  function stopLatencyCheck() {
    if (state.pingInterval) {
      clearInterval(state.pingInterval);
      state.pingInterval = null;
    }
    elements.latencyValue.textContent = '-';
    if (elements.statusLatency) {
      elements.statusLatency.textContent = '';
    }
  }

  // ===========================
  // Settings Management
  // ===========================
  function loadSettings() {
    chrome.storage.sync.get([
      'autoConnect', 
      'rememberToken',
      'showNotifications', 
      'soundEnabled',
      'darkMode',
      'compactView'
    ], (result) => {
      elements.autoConnect.checked = result.autoConnect || false;
      elements.rememberToken.checked = result.rememberToken !== false;
      elements.showNotifications.checked = result.showNotifications !== false;
      elements.soundEnabled.checked = result.soundEnabled || false;
      elements.darkMode.checked = result.darkMode || false;
      elements.compactView.checked = result.compactView || false;
      
      if (result.darkMode) {
        document.body.classList.add('dark-mode');
      }
    });
  }

  function saveSettings() {
    chrome.storage.sync.set({
      autoConnect: elements.autoConnect.checked,
      rememberToken: elements.rememberToken.checked,
      showNotifications: elements.showNotifications.checked,
      soundEnabled: elements.soundEnabled.checked,
      darkMode: elements.darkMode.checked,
      compactView: elements.compactView.checked
    });
  }

  function toggleDarkMode() {
    const isDark = elements.darkMode.checked;
    document.body.classList.toggle('dark-mode', isDark);
    saveSettings();
  }

  async function loadSavedToken() {
    try {
      // Get current tab's domain
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabs && tabs.length > 0) {
        const currentTab = tabs[0];
        if (currentTab.url) {
          state.currentDomain = new URL(currentTab.url).hostname;
          console.log('Current domain:', state.currentDomain);
          
          // Display current domain in the UI
          displayCurrentDomain();
        }
      }
      
      // Get all stored tokens to check availability
      chrome.runtime.sendMessage({ type: 'GET_ALL_STORED_TOKENS' }, (response) => {
        if (response && response.tokens) {
          state.availableTokens = response.tokens;
          console.log('Available tokens for domains:', Object.keys(state.availableTokens));
          
          // Display available domains if any
          displayAvailableDomains();
        }
      });
      
      // Only auto-load token if remember is enabled and not previously disconnected
      if (!elements.rememberToken?.checked) {
        console.log('Remember token disabled, not auto-loading');
        return;
      }
      
      // Get token for current domain or last used token
      chrome.runtime.sendMessage({ 
        type: 'GET_STORED_TOKEN',
        domain: state.currentDomain 
      }, (response) => {
        if (response && response.token) {
          const tokenData = response.token;
          console.log('Found token for domain:', tokenData.domain);
          
          // Use the raw token if available
          if (tokenData.token && elements.tokenInput) {
            elements.tokenInput.value = tokenData.token;
            handleTokenInput(); // Show preview
            
            // Display which domain's token is being used
            if (tokenData.domain !== state.currentDomain) {
              showToast(`Using token from ${tokenData.domain}`, 'info');
            }
            
            // Auto-connect if domain matches JWT domain (regardless of autoConnect setting)
            // or if autoConnect is enabled for other domains
            const shouldAutoConnect = (tokenData.domain === state.currentDomain) || elements.autoConnect?.checked;
            
            if (shouldAutoConnect) {
              console.log('Auto-connecting: domain match =', tokenData.domain === state.currentDomain, ', autoConnect =', elements.autoConnect?.checked);
              setTimeout(() => {
                if (!state.isConnected) {
                  handleConnect();
                }
              }, 500);
            }
          }
        } else if (elements.autoConnect?.checked) {
          // Try to find most recently used token from any domain only if auto-connect is enabled
          findMostRecentToken();
        }
      });
    } catch (error) {
      console.error('Error loading saved token:', error);
    }
  }
  
  function findMostRecentToken() {
    if (Object.keys(state.availableTokens).length > 0) {
      // Find the most recently stored token
      let mostRecentToken = null;
      let mostRecentTime = 0;
      
      for (const [domain, tokenData] of Object.entries(state.availableTokens)) {
        if (tokenData.storedAt && tokenData.storedAt > mostRecentTime) {
          mostRecentTime = tokenData.storedAt;
          mostRecentToken = { ...tokenData, sourceDomain: domain };
        }
      }
      
      if (mostRecentToken && mostRecentToken.token && elements.tokenInput) {
        elements.tokenInput.value = mostRecentToken.token;
        handleTokenInput();
        showToast(`Using last token from ${mostRecentToken.sourceDomain}`, 'info');
        
        // Auto-connect if domain matches JWT domain (regardless of autoConnect setting)
        // or if autoConnect is enabled for other domains
        const shouldAutoConnect = (mostRecentToken.domain === state.currentDomain) || elements.autoConnect?.checked;
        
        if (shouldAutoConnect) {
          console.log('Auto-connecting with recent token: domain match =', mostRecentToken.domain === state.currentDomain, ', autoConnect =', elements.autoConnect?.checked);
          setTimeout(() => {
            if (!state.isConnected) {
              handleConnect();
            }
          }, 500);
        }
      }
    }
  }
  
  function displayCurrentDomain() {
    // Add domain info to the connection card
    const connectionCard = document.getElementById('connectionCard');
    if (connectionCard && state.currentDomain) {
      // Check if domain display already exists
      let domainDisplay = document.getElementById('currentDomainDisplay');
      if (!domainDisplay) {
        domainDisplay = document.createElement('div');
        domainDisplay.id = 'currentDomainDisplay';
        domainDisplay.className = 'domain-info';
        domainDisplay.innerHTML = `
          <div class="domain-display">
            <span class="domain-icon">🌐</span>
            <span class="domain-label">Current Domain:</span>
            <span class="domain-value">${state.currentDomain}</span>
          </div>
        `;
        // Insert after the card title
        const cardTitle = connectionCard.querySelector('.card-title');
        if (cardTitle) {
          cardTitle.insertAdjacentElement('afterend', domainDisplay);
        }
      }
    }
  }
  
  function displayAvailableDomains() {
    const domainCount = Object.keys(state.availableTokens).length;
    if (domainCount > 0) {
      // Add a small indicator showing available tokens
      const connectionCard = document.getElementById('connectionCard');
      if (connectionCard) {
        let tokenIndicator = document.getElementById('tokenIndicator');
        if (!tokenIndicator) {
          tokenIndicator = document.createElement('div');
          tokenIndicator.id = 'tokenIndicator';
          tokenIndicator.className = 'token-indicator';
          tokenIndicator.innerHTML = `
            <small class="token-count">${domainCount} stored token${domainCount > 1 ? 's' : ''} available</small>
          `;
          const formHelp = connectionCard.querySelector('.form-help');
          if (formHelp) {
            formHelp.insertAdjacentElement('afterend', tokenIndicator);
          }
        }
      }
    }
  }
  
  function displayConnectedDomain() {
    // Add domain info to the connected card
    const connectedCard = document.getElementById('connectedCard');
    if (connectedCard && state.currentDomain) {
      // Check if domain display already exists
      let domainDisplay = document.getElementById('connectedDomainDisplay');
      if (!domainDisplay) {
        domainDisplay = document.createElement('div');
        domainDisplay.id = 'connectedDomainDisplay';
        domainDisplay.className = 'domain-info connected';
        domainDisplay.innerHTML = `
          <div class="domain-display">
            <span class="domain-icon">🌐</span>
            <span class="domain-label">Domain:</span>
            <span class="domain-value">${state.currentDomain}</span>
          </div>
        `;
        // Insert after the connection details
        const connectionDetails = connectedCard.querySelector('.connection-details');
        if (connectionDetails) {
          connectionDetails.insertAdjacentElement('afterend', domainDisplay);
        }
      } else {
        // Update existing display
        const domainValue = domainDisplay.querySelector('.domain-value');
        if (domainValue) {
          domainValue.textContent = state.currentDomain;
        }
      }
    }
  }

  // ===========================
  // Background Connection
  // ===========================
  function establishBackgroundConnection() {
    try {
      state.backgroundPort = chrome.runtime.connect({ name: 'popup' });
      
      state.backgroundPort.onMessage.addListener((msg) => {
        console.log('Popup received:', msg);
        
        switch(msg.type) {
          case 'CONNECTION_STATUS':
            state.isConnected = msg.connected;
            updateConnectionUI(msg.connected);
            break;
          case 'CONNECTION_LOST':
          case 'CONNECTION_DISCONNECTED':
            console.log('Connection lost:', msg.message);
            state.isConnected = false;
            updateConnectionUI(false);
            // Switch back to home tab when connection is lost
            switchTab('homeTab');
            // Stop ping interval
            if (state.pingInterval) {
              clearInterval(state.pingInterval);
              state.pingInterval = null;
            }
            break;
          case 'CONNECTION_ERROR':
            console.error('Connection error:', msg.error);
            state.isConnected = false;
            updateConnectionUI(false);
            showToast(`Connection error: ${msg.error}`, 'error');
            // Switch back to home tab on connection error
            switchTab('homeTab');
            break;
          case 'AUTH_FAILED':
            console.error('Authentication failed:', msg.message);
            state.isConnected = false;
            updateConnectionUI(false);
            showToast(msg.message || 'Authentication failed. Please generate a new token.', 'error');
            // Switch back to home tab when auth fails
            switchTab('homeTab');
            // Clear the invalid token
            elements.tokenInput.value = '';
            break;
          case 'TASK_UPDATE':
            updateTask(msg.task);
            break;
          case 'LATENCY_PONG':
            if (msg.rtt) {
              elements.latencyValue.textContent = `${msg.rtt}ms`;
              if (elements.statusLatency) {
                elements.statusLatency.textContent = `${msg.rtt}ms`;
              }
            }
            break;
        }
      });
      
      state.backgroundPort.onDisconnect.addListener(() => {
        console.log('Background port disconnected');
        setTimeout(establishBackgroundConnection, 1000);
      });
    } catch (e) {
      console.error('Failed to establish background connection:', e);
    }
  }

  function checkConnectionStatus() {
    chrome.runtime.sendMessage({ type: 'GET_CONNECTION_STATUS' }, (response) => {
      if (!chrome.runtime.lastError && response?.connected) {
        state.isConnected = true;
        state.connectionInfo = response.connectionInfo;
        updateConnectionUI(true);
        startLatencyCheck();
      }
    });
  }

  function updateTask(task) {
    const existingIndex = state.tasks.findIndex(t => t.id === task.id);
    if (existingIndex >= 0) {
      state.tasks[existingIndex] = task;
    } else {
      state.tasks.push(task);
    }
    
    if (state.currentTab === 'tasksTab') {
      updateTasksUI();
    }
    
    // Update badge
    const runningCount = state.tasks.filter(t => t.status === 'running').length;
    elements.tasksBadge.textContent = runningCount.toString();
    elements.tasksBadge.style.display = runningCount > 0 ? 'block' : 'none';
    
    // Show notification
    if (elements.showNotifications?.checked) {
      if (task.status === 'completed') {
        showToast(`Task #${task.id} completed!`, 'success');
      } else if (task.status === 'failed') {
        showToast(`Task #${task.id} failed`, 'error');
      }
    }
  }

  // ===========================
  // Toast Notifications
  // ===========================
  function showToast(message, type = 'info') {
    // Limit to maximum 2 toasts
    const existingToasts = elements.toastContainer.querySelectorAll('.toast');
    if (existingToasts.length >= 2) {
      // Remove oldest toast
      existingToasts[0].remove();
    }
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    
    elements.toastContainer.appendChild(toast);
    
    // Remove after 3 seconds
    setTimeout(() => {
      toast.style.opacity = '0';
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  // ===========================
  // Message Listener
  // ===========================
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('Popup received message:', request);
    
    switch (request.type) {
      case 'CONNECTION_STATUS':
        state.isConnected = request.connected;
        updateConnectionUI(request.connected);
        break;
      case 'CONNECTION_LOST':
      case 'CONNECTION_DISCONNECTED':
        console.log('Connection lost via message:', request.message);
        state.isConnected = false;
        updateConnectionUI(false);
        // Switch back to home tab when connection is lost
        switchTab('homeTab');
        // Stop ping interval
        if (state.pingInterval) {
          clearInterval(state.pingInterval);
          state.pingInterval = null;
        }
        break;
      case 'CONNECTION_ERROR':
        console.error('Connection error via message:', request.error);
        state.isConnected = false;
        updateConnectionUI(false);
        showToast(`Connection error: ${request.error}`, 'error');
        // Switch back to home tab on connection error
        switchTab('homeTab');
        break;
      case 'AUTH_FAILED':
        console.error('Authentication failed via message:', request.message);
        state.isConnected = false;
        updateConnectionUI(false);
        showToast(request.message || 'Authentication failed. Please generate a new token.', 'error');
        // Switch back to home tab when auth fails
        switchTab('homeTab');
        // Clear the invalid token
        elements.tokenInput.value = '';
        break;
      case 'TASK_UPDATE':
        updateTask(request.task);
        break;
      case 'GIT_UPDATE':
        if (request.gitData) {
          elements.gitBranch.textContent = request.gitData.branch || 'Unknown';
          elements.lastCommit.textContent = request.gitData.lastCommit || 'No commits';
          elements.gitChanges.textContent = request.gitData.changes || '0 files';
        }
        break;
    }
    
    sendResponse({ received: true });
    return false;
  });

  // Start the app
  init();
});
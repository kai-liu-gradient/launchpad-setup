#!/usr/bin/env node

import { existsSync, readFileSync } from 'fs';
import { join } from 'path';

async function checkCache(workspacePath) {
  console.log(`\nChecking cache for workspace: ${workspacePath}`);

  // Try workspace metadata cache first
  try {
    // Import the goals module
    const { loadCache } = await import('./src/commands/goals.js');
    const cache = await loadCache(workspacePath);

    if (cache) {
      console.log('Found workspace cache!');
      return cache;
    }
  } catch (error) {
    console.log('Could not load from workspace metadata:', error.message);
  }

  // Try fallback cache file
  const fallbackPath = join(workspacePath, '.ani-code', 'goals-cache.json');
  if (existsSync(fallbackPath)) {
    console.log(`Found fallback cache at: ${fallbackPath}`);
    return JSON.parse(readFileSync(fallbackPath, 'utf8'));
  }

  console.log('No cache found');
  return null;
}

async function main() {
  const workspacePath = '/root/workspace/ghisha-helix';
  const cache = await checkCache(workspacePath);

  if (!cache) {
    console.log('No cache exists - need to run: ani-code goals sync');
    return;
  }

  console.log(`\nCache info:`);
  console.log(`- Total goals: ${cache.totalGoals || 'unknown'}`);
  console.log(`- Goals in cache: ${cache.goals ? cache.goals.length : 0}`);
  console.log(`- Last updated: ${cache.lastUpdated || 'unknown'}`);

  if (cache.goals) {
    // Check for goal 061
    const goal061 = cache.goals.find(g => g.id === 61 || g.file?.includes('061'));
    if (goal061) {
      console.log(`\n✅ Goal 061 FOUND in cache:`);
      console.log(`  - File: ${goal061.file}`);
      console.log(`  - Title: ${goal061.title}`);
      console.log(`  - Status: ${goal061.progress?.status || 'unknown'}`);
    } else {
      console.log(`\n❌ Goal 061 NOT found in cache`);
    }

    // List all goal IDs
    const goalIds = cache.goals.map(g => g.id).sort((a, b) => a - b);
    console.log(`\nAll goal IDs in cache: ${goalIds.join(', ')}`);

    // Check for gaps
    const maxId = Math.max(...goalIds);
    const missing = [];
    for (let i = 1; i <= maxId; i++) {
      if (!goalIds.includes(i)) {
        missing.push(i);
      }
    }

    if (missing.length > 0) {
      console.log(`\n⚠️  Missing goal IDs: ${missing.join(', ')}`);
    }
  }
}

main().catch(console.error);
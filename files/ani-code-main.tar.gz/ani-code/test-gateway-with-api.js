#!/usr/bin/env node

/**
 * Test Gateway Registration with actual API
 */

import axios from 'axios';
import os from 'os';

const GATEWAY_URL = 'http://localhost:6555';
const API_KEY = 'dev-key-1';
const USER_AGENT = `${os.hostname()} ani-code-daemon`;

console.log('=== Testing Gateway Registration API ===\n');

// Test 1: Register an instance
console.log('Test 1: Register Instance');
console.log('-------------------------');

try {
  const registerData = {
    url: 'http://10.60.0.11:6501',
    metadata: {
      projectId: 'test-proj-123',
      workspaceId: 'test-ws-456',
      podName: 'test-pod-ani',
      version: '1.2.0',
      capabilities: ['telegram', 'lark', 'cli', 'http', 'websocket']
    }
  };

  console.log('Sending registration request to:', `${GATEWAY_URL}/registry/instance`);
  console.log('Request data:', JSON.stringify(registerData, null, 2));

  const response = await axios.post(
    `${GATEWAY_URL}/registry/instance`,
    registerData,
    {
      headers: {
        'x-api-key': API_KEY,
        'Content-Type': 'application/json',
        'User-Agent': USER_AGENT
      },
      timeout: 5000
    }
  );

  console.log('✅ Registration successful!');
  console.log('Response:', JSON.stringify(response.data, null, 2));

  const instanceId = response.data.id;

  // Test 2: List instances
  console.log('\nTest 2: List Instances');
  console.log('----------------------');

  const listResponse = await axios.get(
    `${GATEWAY_URL}/registry/instances`,
    {
      headers: {
        'x-api-key': API_KEY,
        'User-Agent': USER_AGENT
      },
      timeout: 5000
    }
  );

  console.log('Registered instances:', JSON.stringify(listResponse.data, null, 2));

  // Test 3: Deregister
  console.log('\nTest 3: Deregister Instance');
  console.log('---------------------------');

  const deleteResponse = await axios.delete(
    `${GATEWAY_URL}/registry/instance/${instanceId}`,
    {
      headers: {
        'x-api-key': API_KEY,
        'User-Agent': USER_AGENT
      },
      timeout: 5000
    }
  );

  console.log('✅ Deregistration successful!');
  console.log('Response:', deleteResponse.data || 'OK');

  console.log('\n=== All Gateway API Tests Passed ===');
} catch (error) {
  if (error.code === 'ECONNREFUSED') {
    console.log('❌ Gateway service is not running at', GATEWAY_URL);
    console.log('   Please start the gateway with: systemctl start ani-code-gateway');
  } else if (error.response) {
    console.log('❌ API Error:', error.response.status, error.response.statusText);
    console.log('Response:', error.response.data);
  } else {
    console.log('❌ Error:', error.message);
  }
}

process.exit(0);
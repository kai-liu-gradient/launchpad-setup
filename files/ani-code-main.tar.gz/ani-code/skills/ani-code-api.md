---
description: Use this skill when the user wants to control ani-code via REST API. Provides comprehensive reference for all ani-code daemon HTTP API endpoints including authentication setup, task management, plans, goals, providers, hints, and WebSocket integration.
---

# Ani-Code REST API Control Reference

This skill provides guidance for controlling the ani-code agent system through the daemon's REST API with proper authentication.

## Base Configuration

```
HTTP API:     http://localhost:6501
WebSocket:    ws://localhost:6502/socket
```

Ports can be configured via environment variables:
- `ANI_CODE_DAEMON_PORT` - HTTP API port (default: 6501)
- `ANICODE_WS_PORT` - WebSocket port (default: 6502)

## Authentication Setup

All API endpoints require Bearer token authentication.

### Step 1: Create Workspace

```bash
ani-code workspace create my-project
```

### Step 2: Generate API Token

```bash
# Generate permanent API token
ani-code workspace token gen -n "API Client" -t api

# Generate temporary token (30 days)
ani-code workspace token gen -n "Temp Access" -e 30
```

### Step 3: Use Token in Requests

```bash
# Store token for reuse
export ANI_CODE_TOKEN="your_token_here"

# Use in curl requests
curl -H "Authorization: Bearer $ANI_CODE_TOKEN" \
     http://localhost:6501/api/tasks
```

### Token Management

```bash
# List all tokens
ani-code workspace token list

# Revoke a token
ani-code workspace token revoke <token_id>
```

---

## Task Management API

### Submit Task

**POST** `/api/task`

```bash
curl -X POST http://localhost:6501/api/task \
  -H "Authorization: Bearer $ANI_CODE_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Build user dashboard",
    "command": "implement dashboard component",
    "priority": "normal",
    "model": "sonnet",
    "metadata": {
      "source": "api",
      "requestId": "req-123"
    }
  }'
```

**Request Body:**
| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `name` | string | Yes | Task description |
| `command` | string | No | Additional command/prompt |
| `priority` | string | No | `low`, `normal`, `high` |
| `model` | string | No | `sonnet` or `opus` |
| `metadata` | object | No | Custom metadata |

**Response:**
```json
{
  "success": true,
  "taskId": "ac-20250906-example-7d139350",
  "status": "queued",
  "workspace": "my-project",
  "queuePosition": 1
}
```

### Get Task Status

**GET** `/api/task/{taskId}`

```bash
curl -X GET http://localhost:6501/api/task/ac-20250906-example-7d139350 \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"
```

**Response:**
```json
{
  "id": "ac-20250906-example-7d139350",
  "name": "Build user dashboard",
  "status": "running",
  "progress": 45,
  "output": "Task output here...",
  "error": null,
  "startedAt": "2025-01-15T10:30:00Z",
  "completedAt": null,
  "workspace": "my-project",
  "queuePosition": null
}
```

**Status Values:**
- `queued` - Waiting in queue
- `running` - Currently executing
- `completed` - Finished successfully
- `failed` - Encountered error
- `cancelled` - Stopped by user

### List Tasks

**GET** `/api/tasks`

```bash
# Get all tasks
curl -X GET "http://localhost:6501/api/tasks" \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"

# Filter by status
curl -X GET "http://localhost:6501/api/tasks?status=running" \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"

# With pagination
curl -X GET "http://localhost:6501/api/tasks?limit=10&offset=0" \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"
```

**Query Parameters:**
| Parameter | Default | Description |
|-----------|---------|-------------|
| `status` | - | Filter: queued, running, completed, failed |
| `limit` | 50 | Max results |
| `offset` | 0 | Pagination offset |

### Cancel Task

**DELETE** `/api/task/{taskId}`

```bash
curl -X DELETE http://localhost:6501/api/task/ac-20250906-example-7d139350 \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"
```

### Update Task Channel (Redirect)

**PATCH** `/api/task/{taskId}/channel`

Redirect task notifications to a different channel (e.g., from gateway to Telegram).

```bash
curl -X PATCH http://localhost:6501/api/task/ac-20250906-example-7d139350/channel \
  -H "Authorization: Bearer $ANI_CODE_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "chatId": "telegram:123456789",
    "source": "telegram"
  }'
```

### Get Task Checklist

**GET** `/api/task/{taskId}/checklist`

```bash
curl -X GET http://localhost:6501/api/task/ac-20250906-example-7d139350/checklist \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"
```

---

## Plan Management API

### Create Plan

**POST** `/api/plan`

```bash
curl -X POST http://localhost:6501/api/plan \
  -H "Authorization: Bearer $ANI_CODE_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Deploy to production",
    "description": "Complete deployment workflow",
    "steps": [
      "Run all tests",
      "Build production bundle",
      "Deploy to staging",
      "Run smoke tests",
      "Deploy to production"
    ],
    "metadata": {
      "category": "deployment"
    }
  }'
```

### Get Plan Details

**GET** `/api/plan/{planId}`

```bash
curl -X GET http://localhost:6501/api/plan/acp-0115-myproject-A51001 \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"
```

### Update Plan

**PUT** `/api/plan/{planId}`

```bash
curl -X PUT http://localhost:6501/api/plan/acp-0115-myproject-A51001 \
  -H "Authorization: Bearer $ANI_CODE_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "status": "paused",
    "currentStep": 2
  }'
```

### Delete Plan

**DELETE** `/api/plan/{planId}`

```bash
curl -X DELETE http://localhost:6501/api/plan/acp-0115-myproject-A51001 \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"
```

### List Plans

**GET** `/api/plans`

```bash
curl -X GET "http://localhost:6501/api/plans?status=pending&limit=10" \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"
```

### Execute Plan

**POST** `/api/plan/execute`

```bash
# Execute specific plan
curl -X POST http://localhost:6501/api/plan/execute \
  -H "Authorization: Bearer $ANI_CODE_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "planId": "acp-0115-myproject-A51001",
    "priority": "high"
  }'

# Execute next pending plan (FIFO)
curl -X POST http://localhost:6501/api/plan/execute \
  -H "Authorization: Bearer $ANI_CODE_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{}'
```

### Get Plans Summary

**GET** `/api/plans/summary`

```bash
curl -X GET http://localhost:6501/api/plans/summary \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"
```

---

## Goals API

### List Goals

**GET** `/api/goals`

```bash
# All goals
curl -X GET http://localhost:6501/api/goals \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"

# Filter by status
curl -X GET "http://localhost:6501/api/goals?status=in_progress" \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"
```

**Query Parameters:**
| Parameter | Default | Description |
|-----------|---------|-------------|
| `status` | - | not_started, in_progress, completed, abandoned, cancelled, on_hold |
| `limit` | 100 | Max results |
| `offset` | 0 | Pagination offset |

### Get Goal Details

**GET** `/api/goals/{goalId}`

```bash
curl -X GET http://localhost:6501/api/goals/042 \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"
```

### Create Goal

**POST** `/api/goals`

```bash
curl -X POST http://localhost:6501/api/goals \
  -H "Authorization: Bearer $ANI_CODE_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Implement User Authentication",
    "objective": "Add JWT-based authentication",
    "stage": "Stage 5: Authentication",
    "tasks": [
      "Install JWT library",
      "Create auth middleware",
      "Add login endpoint"
    ],
    "acceptanceCriteria": [
      "Users can login with email/password",
      "JWT tokens expire after 24 hours"
    ],
    "priority": "high"
  }'
```

### Update Goal

**PUT** `/api/goals/{goalId}`

```bash
curl -X PUT http://localhost:6501/api/goals/042 \
  -H "Authorization: Bearer $ANI_CODE_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "status": "in_progress",
    "progress": 35,
    "tasks": [
      { "text": "Install JWT library", "completed": true },
      { "text": "Create auth middleware", "completed": false }
    ]
  }'
```

### Delete/Archive Goal

**DELETE** `/api/goals/{goalId}`

```bash
# Archive (default)
curl -X DELETE http://localhost:6501/api/goals/042 \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"

# Permanent delete
curl -X DELETE "http://localhost:6501/api/goals/042?archive=false" \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"
```

### Get Running Goals

**GET** `/api/goals/running`

```bash
curl -X GET http://localhost:6501/api/goals/running \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"
```

### Sync Goals

**POST** `/api/goals/sync`

```bash
curl -X POST http://localhost:6501/api/goals/sync \
  -H "Authorization: Bearer $ANI_CODE_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "force": false,
    "verbose": true
  }'
```

---

## Providers API

### List Providers

**GET** `/api/providers`

```bash
# Available providers only
curl -X GET http://localhost:6501/api/providers \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"

# Include unavailable
curl -X GET "http://localhost:6501/api/providers?all=true" \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"
```

### Get Provider Details

**GET** `/api/providers/{providerId}`

```bash
curl -X GET http://localhost:6501/api/providers/copilot \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"
```

### Get Provider Models

**GET** `/api/providers/{providerId}/models`

```bash
# All models
curl -X GET http://localhost:6501/api/providers/copilot/models \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"

# Enabled models only
curl -X GET "http://localhost:6501/api/providers/copilot/models?enabled=true" \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"
```

### Update Provider

**PATCH** `/api/providers/{providerId}`

```bash
# Disable provider
curl -X PATCH http://localhost:6501/api/providers/copilot \
  -H "Authorization: Bearer $ANI_CODE_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{ "enabled": false }'

# Set as current provider
curl -X PATCH http://localhost:6501/api/providers/copilot \
  -H "Authorization: Bearer $ANI_CODE_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{ "current": true }'
```

### Update Provider Model

**PATCH** `/api/providers/{providerId}/models/{modelId}`

```bash
# Set default model
curl -X PATCH http://localhost:6501/api/providers/copilot/models/gpt-5 \
  -H "Authorization: Bearer $ANI_CODE_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{ "default": true }'

# Disable model
curl -X PATCH http://localhost:6501/api/providers/copilot/models/gpt-5 \
  -H "Authorization: Bearer $ANI_CODE_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{ "enabled": false }'
```

---

## Hints API

### List Hints

**GET** `/api/hints`

```bash
# Active hints only
curl -X GET http://localhost:6501/api/hints \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"

# All hints (including acknowledged)
curl -X GET "http://localhost:6501/api/hints?all=true" \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"
```

### Create Hint

**POST** `/api/hints`

```bash
curl -X POST http://localhost:6501/api/hints \
  -H "Authorization: Bearer $ANI_CODE_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "content": "Browser console shows TypeError on login page",
    "source": "api"
  }'
```

### Get Hint

**GET** `/api/hints/{hintId}`

```bash
curl -X GET http://localhost:6501/api/hints/ab12 \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"
```

### Acknowledge Hint

**POST** `/api/hints/{hintId}/ack`

```bash
curl -X POST http://localhost:6501/api/hints/ab12/ack \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"
```

### Delete Hint

**DELETE** `/api/hints/{hintId}`

```bash
curl -X DELETE http://localhost:6501/api/hints/ab12 \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"
```

### Clear All Hints

**DELETE** `/api/hints`

```bash
curl -X DELETE http://localhost:6501/api/hints \
  -H "Authorization: Bearer $ANI_CODE_TOKEN"
```

---

## WebSocket API

For real-time task updates, connect to the WebSocket endpoint.

### JavaScript Example

```javascript
const WebSocket = require('ws');

const ws = new WebSocket('ws://localhost:6502/socket', {
  headers: {
    'Authorization': `Bearer ${process.env.ANI_CODE_TOKEN}`
  }
});

ws.on('open', () => {
  console.log('Connected to ani-code WebSocket');
});

ws.on('message', (data) => {
  const message = JSON.parse(data);
  console.log('Task update:', message);

  // Handle different message types
  switch (message.type) {
    case 'task_started':
      console.log(`Task ${message.taskId} started`);
      break;
    case 'task_progress':
      console.log(`Task ${message.taskId}: ${message.progress}%`);
      break;
    case 'task_completed':
      console.log(`Task ${message.taskId} completed`);
      break;
    case 'task_failed':
      console.error(`Task ${message.taskId} failed: ${message.error}`);
      break;
  }
});

ws.on('error', (error) => {
  console.error('WebSocket error:', error);
});

ws.on('close', () => {
  console.log('Disconnected from ani-code');
});
```

---

## Client Libraries

### Python Client

```python
import requests
import os

class AniCodeClient:
    def __init__(self, token=None, base_url="http://localhost:6501"):
        self.token = token or os.environ.get("ANI_CODE_TOKEN")
        self.base_url = base_url
        self.headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }

    def submit_task(self, name, command=None, model=None, priority="normal"):
        payload = {"name": name, "priority": priority}
        if command:
            payload["command"] = command
        if model:
            payload["model"] = model

        response = requests.post(
            f"{self.base_url}/api/task",
            headers=self.headers,
            json=payload
        )
        return response.json()

    def get_task(self, task_id):
        response = requests.get(
            f"{self.base_url}/api/task/{task_id}",
            headers=self.headers
        )
        return response.json()

    def list_tasks(self, status=None, limit=50):
        params = {"limit": limit}
        if status:
            params["status"] = status

        response = requests.get(
            f"{self.base_url}/api/tasks",
            headers=self.headers,
            params=params
        )
        return response.json()

    def cancel_task(self, task_id):
        response = requests.delete(
            f"{self.base_url}/api/task/{task_id}",
            headers=self.headers
        )
        return response.json()

# Usage
client = AniCodeClient()
task = client.submit_task("Build feature", model="sonnet")
print(f"Task ID: {task['taskId']}")

# Wait and check status
import time
while True:
    status = client.get_task(task['taskId'])
    if status['status'] in ['completed', 'failed', 'cancelled']:
        print(f"Final status: {status['status']}")
        break
    time.sleep(5)
```

### Node.js Client

```javascript
const axios = require('axios');

class AniCodeClient {
  constructor(token, baseUrl = 'http://localhost:6501') {
    this.token = token || process.env.ANI_CODE_TOKEN;
    this.baseUrl = baseUrl;
    this.headers = {
      'Authorization': `Bearer ${this.token}`,
      'Content-Type': 'application/json'
    };
  }

  async submitTask(name, options = {}) {
    const { command, model, priority = 'normal', metadata } = options;
    const response = await axios.post(
      `${this.baseUrl}/api/task`,
      { name, command, model, priority, metadata },
      { headers: this.headers }
    );
    return response.data;
  }

  async getTask(taskId) {
    const response = await axios.get(
      `${this.baseUrl}/api/task/${taskId}`,
      { headers: this.headers }
    );
    return response.data;
  }

  async listTasks(options = {}) {
    const { status, limit = 50, offset = 0 } = options;
    const params = { limit, offset };
    if (status) params.status = status;

    const response = await axios.get(
      `${this.baseUrl}/api/tasks`,
      { headers: this.headers, params }
    );
    return response.data;
  }

  async cancelTask(taskId) {
    const response = await axios.delete(
      `${this.baseUrl}/api/task/${taskId}`,
      { headers: this.headers }
    );
    return response.data;
  }

  async createGoal(goalData) {
    const response = await axios.post(
      `${this.baseUrl}/api/goals`,
      goalData,
      { headers: this.headers }
    );
    return response.data;
  }

  async listProviders(includeAll = false) {
    const response = await axios.get(
      `${this.baseUrl}/api/providers`,
      {
        headers: this.headers,
        params: includeAll ? { all: true } : {}
      }
    );
    return response.data;
  }
}

// Usage
async function main() {
  const client = new AniCodeClient();

  // Submit task
  const task = await client.submitTask('Build dashboard', {
    model: 'sonnet',
    priority: 'high'
  });
  console.log(`Task ID: ${task.taskId}`);

  // Poll for completion
  const poll = async () => {
    const status = await client.getTask(task.taskId);
    if (['completed', 'failed', 'cancelled'].includes(status.status)) {
      console.log(`Final: ${status.status}`);
      return status;
    }
    await new Promise(r => setTimeout(r, 5000));
    return poll();
  };

  await poll();
}

main();
```

---

## Rate Limits

| Limit | Value |
|-------|-------|
| Requests per minute per token | 100 |
| Concurrent tasks per workspace | 10 |
| WebSocket connections per token | 5 |

---

## Error Responses

All errors follow this format:

```json
{
  "success": false,
  "error": "Error message description"
}
```

**HTTP Status Codes:**
| Code | Description |
|------|-------------|
| 400 | Bad Request - Invalid parameters |
| 401 | Unauthorized - Missing or invalid token |
| 403 | Forbidden - Access denied |
| 404 | Not Found - Resource not found |
| 429 | Too Many Requests - Rate limited |
| 500 | Internal Server Error |

---

## Quick Start Workflow

```bash
# 1. Setup
ani-code workspace create my-api-project
export ANI_CODE_TOKEN=$(ani-code workspace token gen -n "API" -t api | grep "Token:" | awk '{print $2}')

# 2. Submit a task
TASK_ID=$(curl -s -X POST http://localhost:6501/api/task \
  -H "Authorization: Bearer $ANI_CODE_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name": "Implement user auth", "model": "sonnet"}' | jq -r '.taskId')

echo "Task ID: $TASK_ID"

# 3. Monitor progress
watch -n 5 "curl -s -H 'Authorization: Bearer $ANI_CODE_TOKEN' \
  http://localhost:6501/api/task/$TASK_ID | jq '.status, .progress'"

# 4. Get final output
curl -s -H "Authorization: Bearer $ANI_CODE_TOKEN" \
  http://localhost:6501/api/task/$TASK_ID | jq '.output'
```

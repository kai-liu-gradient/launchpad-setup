---
description: Use this skill when the user wants to control ani-code via CLI commands. Provides comprehensive reference for all ani-code CLI commands including task management, workspace operations, goals, providers, hints, and daemon control.
---

# Ani-Code CLI Control Reference

This skill provides guidance for controlling the ani-code agent system through command line interface.

## Quick Reference

### Task Management (Most Common)

```bash
# Add a new task
ani-code add "Your task description"
ani-code add -f prompt.md                    # From markdown file
ani-code add -f prompt.md -w ./src           # With working directory

# Continue conversation
ani-code continue                             # Continue last task
ani-code continue "Additional context"        # With context
ani-code continue -f reply.md                 # From file

# Task status and monitoring
ani-code status                               # Show current tasks
ani-code status -v                            # Verbose with process info
ani-code watch <taskId>                       # Real-time output
ani-code task <taskId>                        # Task details
ani-code history                              # Recent task history

# Task control
ani-code cancel <taskId>                      # Cancel running task
ani-code retry [taskId]                       # Retry failed task
ani-code retry -c                             # Retry keeping workdir
```

### Plan Management

```bash
# Create and manage plans
ani-code plan list                            # List all plans
ani-code plan show <planId>                   # Show plan details
ani-code plan reset                           # Clear workspace plans
ani-code plan delete <planId>                 # Delete specific plan

# Execute plans
ani-code next                                 # Execute next plan
ani-code next <planId>                        # Execute specific plan
ani-code next -s 2                            # Start from step 2
ani-code next -a                              # Auto-execute all steps
```

### Quick Workflows

```bash
# Git commit workflow
ani-code commit                               # Interactive commit
ani-code commit "message"                     # Direct commit
ani-code commit -a                            # Add all changes
ani-code commit -s                            # With summary task
ani-code commit -y                            # YOLO mode (auto-accept)

# Documentation and testing
ani-code doc                                  # Generate documentation
ani-code doc -y                               # Auto-accept
ani-code test                                 # Implement and run tests
ani-code test -r                              # Run existing tests only

# Other utilities
ani-code run <command>                        # Run shell command
ani-code message "text"                       # Send to chat
ani-code upload <file>                        # Upload to S3
ani-code upload --workspace-temp              # Upload all temp folders
```

### Hints (Transient Context)

```bash
# Add hints for next task iteration
ani-code hint "Browser shows TypeError on login"
ani-code hint -f error-log.txt                # From file
cat console.log | ani-code hint               # From stdin

# Manage hints
ani-code hint --list                          # List active hints
ani-code hint --ack <id>                      # Acknowledge/resolve
ani-code hint --clear                         # Clear all hints
```

### Workspace Management

```bash
# Workspace operations
ani-code workspace create <name>              # Create workspace
ani-code workspace list                       # List workspaces
ani-code workspace switch <name>              # Switch workspace
ani-code workspace delete <name>              # Delete workspace
ani-code workspace info                       # Current workspace info

# Token management
ani-code workspace token gen -n "API" -t api  # Generate API token
ani-code workspace token gen -e 30            # Temp token (30 days)
ani-code workspace token list                 # List tokens
ani-code workspace token revoke <id>          # Revoke token

# Workspace metadata
ani-code workspace meta set model opus        # Set default model
ani-code workspace meta get model             # Get current model
ani-code workspace meta set cliProvider copilot  # Set provider

# Macros
ani-code workspace macro list                 # List macros
ani-code workspace macro set <name> "<cmd>"   # Create macro
ani-code workspace macro delete <name>        # Delete macro
```

### Goals Management

```bash
# Goal operations
ani-code goals list                           # List all goals
ani-code goals list --status in_progress      # Filter by status
ani-code goals show <goalId>                  # Show goal details
ani-code goals sync                           # Sync from filesystem
ani-code goals sync --full                    # Full resync

# Goal loop
ani-code goals loop                           # Start goal loop
ani-code goals loop --goal <id>               # Specific goal
ani-code goals loop --dry-run                 # Preview only
```

### Provider Management

```bash
# List and switch providers
ani-code providers                            # List available
ani-code providers copilot                    # Switch provider
ani-code providers opencode --save            # Switch and save
ani-code providers --all                      # Show unavailable too

# Provider configuration
ani-code provider info                        # Current provider info
ani-code provider models                      # List models
```

### Daemon & Service

```bash
# Daemon control (READ-ONLY - NEVER restart!)
ani-code daemon --status                      # Check status
ani-code daemon --start                       # Start daemon
ani-code daemon --stop                        # Stop daemon (CAREFUL!)

# Service management
ani-code service install                      # Install systemd service
ani-code service install --user               # User-level service
ani-code service status                       # Check service status

# Diagnosis
ani-code diagnosis                            # Run system checks
```

### Healthcheck & Projects

```bash
# Healthcheck
ani-code healthcheck                          # Auto-detect and check
ani-code healthcheck --stack node             # Specific techstack
ani-code healthcheck --analyze                # With AI analysis
ani-code healthcheck --output json            # JSON output only
ani-code healthcheck --cleanup 30             # Remove old reports

# Projects
ani-code projects                             # Scan for projects
ani-code projects list                        # List discovered
ani-code projects list --tree                 # Tree view
ani-code projects show <name>                 # Project details
ani-code projects burst <name>                # Increment version
ani-code projects burst-all                   # Burst all versions
```

### Gateway Integration

```bash
# Gateway commands
ani-code gateway status                       # Registration status
ani-code gateway test                         # Test connectivity
ani-code gateway config                       # Show configuration
ani-code gateway register                     # Manual registration
```

### Debug & Utilities

```bash
# Debug commands
ani-code debug usage                          # Check Claude API usage
ani-code debug sessions                       # List active sessions

# Init and setup
ani-code init                                 # Initialize settings
ani-code init --preset full                   # With permission preset
ani-code init --global                        # User-level settings
ani-code unlink                               # Unlink global command
```

## Model Selection

Use `@@` syntax to select models in prompts:

```bash
ani-code add "Complex analysis @@opus"        # Use Opus model
ani-code add "Quick task @@sonnet"            # Use Sonnet model
```

Priority order:
1. Task-specific model (`@@opus` or `@@sonnet` in prompt)
2. Workspace default (`ani-code workspace meta set model`)
3. Provider default model

## Provider Targeting

Target specific providers with `@@` syntax:

```bash
ani-code add "Implement feature @@copilot"    # Use GitHub Copilot
ani-code add "Analyze code @@opencode"        # Use OpenCode
```

## Environment Variables

Key environment variables for configuration:

```bash
# Daemon ports
ANI_CODE_DAEMON_PORT=6501                     # HTTP API port
ANICODE_WS_PORT=6502                          # WebSocket port

# Provider selection
CLI_PROVIDER_ID=claude                        # Default provider

# Hints configuration
HINT_TTL_HOURS=1                              # Hint expiry time
HINT_MAX_INJECT=5                             # Max hints per prompt

# Task configuration
MAX_CONCURRENT_TASKS=3                        # Concurrent task limit
TASK_TIMEOUT_MS=300000                        # Task timeout
```

## Tips

1. **Watch tasks**: Use `ani-code watch <id>` for real-time output
2. **Use hints**: Add context with `ani-code hint` for complex debugging
3. **Model selection**: Use `@@opus` for complex tasks, `@@sonnet` for quick ones
4. **Workspace macros**: Create shortcuts with `workspace macro set`
5. **Goal loops**: Automate implementation with `goals loop`

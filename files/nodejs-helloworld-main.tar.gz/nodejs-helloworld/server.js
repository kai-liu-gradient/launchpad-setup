const express = require('express');
const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Health check endpoint
app.get('/health', (req, res) => {
  const healthData = {
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    version: process.env.npm_package_version || '1.0.0'
  };

  const formatUptime = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    return hours + 'h ' + minutes + 'm ' + secs + 's';
  };

  res.send(
    '<!DOCTYPE html>' +
    '<html>' +
    '<head>' +
    '  <title>Health Status</title>' +
    '  <style>' +
    '    body {' +
    '      background-color: #121212;' +
    '      color: #ffffff;' +
    '      font-family: "Courier New", Consolas, monospace;' +
    '      margin: 0;' +
    '      padding: 0;' +
    '      height: 100vh;' +
    '      display: flex;' +
    '      justify-content: center;' +
    '      align-items: center;' +
    '    }' +
    '    .health-container {' +
    '      background: #1e1e1e;' +
    '      border: 1px solid #333;' +
    '      border-radius: 10px;' +
    '      padding: 40px;' +
    '      max-width: 500px;' +
    '      width: 90%;' +
    '      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);' +
    '    }' +
    '    .health-title {' +
    '      font-size: 2rem;' +
    '      font-weight: 300;' +
    '      text-align: center;' +
    '      margin: 0 0 30px 0;' +
    '      color: #4ade80;' +
    '    }' +
    '    .status-indicator {' +
    '      display: inline-flex;' +
    '      align-items: center;' +
    '      gap: 10px;' +
    '      background: #064e3b;' +
    '      color: #4ade80;' +
    '      padding: 8px 16px;' +
    '      border-radius: 20px;' +
    '      font-size: 0.9rem;' +
    '      font-weight: bold;' +
    '      margin-bottom: 20px;' +
    '    }' +
    '    .status-dot {' +
    '      width: 8px;' +
    '      height: 8px;' +
    '      background: #4ade80;' +
    '      border-radius: 50%;' +
    '      animation: pulse 2s infinite;' +
    '    }' +
    '    @keyframes pulse {' +
    '      0%, 100% { opacity: 1; }' +
    '      50% { opacity: 0.5; }' +
    '    }' +
    '    .health-item {' +
    '      display: flex;' +
    '      justify-content: space-between;' +
    '      align-items: center;' +
    '      padding: 12px 0;' +
    '      border-bottom: 1px solid #333;' +
    '    }' +
    '    .health-item:last-child {' +
    '      border-bottom: none;' +
    '    }' +
    '    .health-label {' +
    '      color: #888;' +
    '      font-size: 0.9rem;' +
    '    }' +
    '    .health-value {' +
    '      color: #fff;' +
    '      font-weight: bold;' +
    '      font-size: 0.9rem;' +
    '    }' +
    '    .back-link {' +
    '      display: block;' +
    '      text-align: center;' +
    '      margin-top: 30px;' +
    '      color: #6b7280;' +
    '      text-decoration: none;' +
    '      font-size: 0.9rem;' +
    '      transition: color 0.3s;' +
    '    }' +
    '    .back-link:hover {' +
    '      color: #9ca3af;' +
    '    }' +
    '  </style>' +
    '</head>' +
    '<body>' +
    '  <div class="health-container">' +
    '    <h1 class="health-title">Health Status</h1>' +
    '    <div style="text-align: center;">' +
    '      <div class="status-indicator">' +
    '        <span class="status-dot"></span>' +
    '        <span>' + healthData.status.toUpperCase() + '</span>' +
    '      </div>' +
    '    </div>' +
    '    <div class="health-item">' +
    '      <span class="health-label">Status</span>' +
    '      <span class="health-value">' + healthData.status + '</span>' +
    '    </div>' +
    '    <div class="health-item">' +
    '      <span class="health-label">Uptime</span>' +
    '      <span class="health-value">' + formatUptime(healthData.uptime) + '</span>' +
    '    </div>' +
    '    <div class="health-item">' +
    '      <span class="health-label">Version</span>' +
    '      <span class="health-value">' + healthData.version + '</span>' +
    '    </div>' +
    '    <div class="health-item">' +
    '      <span class="health-label">Timestamp</span>' +
    '      <span class="health-value">' + new Date(healthData.timestamp).toLocaleString() + '</span>' +
    '    </div>' +
    '    <a href="/" class="back-link">← Back to Home</a>' +
    '  </div>' +
    '</body>' +
    '</html>'
  );
});

// Root endpoint
app.get('/', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Hello World</title>
      <style>
        body {
          background-color: #0f172a;
          background-image: url("data:image/svg+xml,%3Csvg width='40' height='40' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 40L20 0H40L20 40z' fill='%23ffffff' fill-opacity='0.05'/%3E%3C/svg%3E"), linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%);
          background-blend-mode: overlay, normal;
          background-size: 40px 40px, 200% 200%;
          background-attachment: fixed, fixed;
          animation: gradientShift 8s ease infinite, triangleFloat 20s linear infinite;
          color: #ffffff;
          font-family: 'Courier New', Consolas, monospace;
          margin: 0;
          padding: 0;
          height: 100vh;
          display: flex;
          justify-content: center;
          align-items: center;
          overflow: hidden;
          position: relative;
        }
        @keyframes gradientShift {
          0% { background-position: 0% 50%, 0% 50%; }
          50% { background-position: 100% 50%, 100% 50%; }
          100% { background-position: 0% 50%, 0% 50%; }
        }
        @keyframes triangleFloat {
          0% { background-position: 0 0, 0% 50%; }
          100% { background-position: 40px 40px, 0% 50%; }
        }
        .animated-bg {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          pointer-events: none;
          z-index: -1;
        }
        .floating-triangle {
          position: absolute;
          width: 0;
          height: 0;
          border-left: 15px solid transparent;
          border-right: 15px solid transparent;
          border-bottom: 26px solid rgba(255, 255, 255, 0.1);
          animation: float 15s infinite linear;
        }
        @keyframes float {
          0% {
            transform: translateY(100vh) rotate(0deg);
            opacity: 0;
          }
          10% {
            opacity: 0.3;
          }
          90% {
            opacity: 0.3;
          }
          100% {
            transform: translateY(-100px) rotate(360deg);
            opacity: 0;
          }
        }
        .typewriter {
          font-size: 3rem;
          font-weight: 300;
          text-align: center;
          margin: 0;
          position: relative;
        }
        .typewriter-container {
          display: inline-flex;
          align-items: flex-end;
          justify-content: center;
          position: relative;
          vertical-align: bottom;
        }
        .cursor {
          display: inline-block;
          font-size: 3rem;
          font-weight: 300;
          color: #ffffff;
          vertical-align: bottom;
          animation: blink 1s infinite;
        }
        @keyframes blink {
          0%, 50% { opacity: 1; }
          51%, 100% { opacity: 0; }
        }
        .tech-stack {
          color: #bfdbfe;
          font-size: 1.2rem;
          text-align: center;
          margin-top: 20px;
          opacity: 0;
          animation: fadeIn 1s ease-in-out 1s forwards;
        }
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        .nav-link {
          display: inline-block;
          margin-top: 30px;
          padding: 12px 24px;
          background: rgba(30, 58, 138, 0.3);
          color: #60a5fa;
          text-decoration: none;
          border: 1px solid rgba(96, 165, 250, 0.3);
          border-radius: 6px;
          font-size: 0.9rem;
          transition: all 0.3s ease;
          opacity: 0;
          animation: fadeIn 1s ease-in-out 4s forwards;
          cursor: pointer;
        }
        .nav-link:hover {
          background: rgba(30, 58, 138, 0.5);
          border-color: #60a5fa;
          transform: translateY(-2px);
        }
        .toast {
          position: fixed;
          top: 20px;
          right: 20px;
          background: #1e1e1e;
          border: 1px solid #4ade80;
          border-radius: 8px;
          padding: 20px;
          max-width: 400px;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.5);
          z-index: 1000;
          transform: translateX(500px);
          transition: transform 0.3s ease-out;
        }
        .toast.show {
          transform: translateX(0);
        }
        .toast-header {
          display: flex;
          align-items: center;
          gap: 10px;
          margin-bottom: 15px;
          color: #4ade80;
          font-weight: bold;
          font-size: 1rem;
        }
        .toast-status {
          width: 8px;
          height: 8px;
          background: #4ade80;
          border-radius: 50%;
          animation: pulse 2s infinite;
        }
        .toast-content {
          color: #fff;
          font-size: 0.9rem;
          line-height: 1.4;
        }
        .toast-item {
          display: flex;
          justify-content: space-between;
          padding: 4px 0;
          border-bottom: 1px solid #333;
        }
        .toast-item:last-child {
          border-bottom: none;
        }
        .toast-label {
          color: #888;
          font-size: 0.8rem;
        }
        .toast-value {
          color: #fff;
          font-weight: bold;
          font-size: 0.8rem;
        }
        .toast-close {
          position: absolute;
          top: 10px;
          right: 10px;
          background: none;
          border: none;
          color: #888;
          font-size: 1.2rem;
          cursor: pointer;
          padding: 0;
          width: 20px;
          height: 20px;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .toast-close:hover {
          color: #fff;
        }
      </style>
    </head>
    <body>
      <div class="animated-bg" id="animatedBg"></div>
      <div>
        <h1 class="typewriter">
          <span class="typewriter-container">
            <span id="typewriter"></span>
            <span class="cursor">_</span>
          </span>
        </h1>
        <div class="tech-stack">
          <span>Node.js</span> •
          <span>Express</span> •
          <span>HTML/CSS/JavaScript</span>
        </div>
        <div style="text-align: center;">
          <button class="nav-link" onclick="showHealthStatus()">🏥 Health Status</button>
        </div>
      </div>

      <!-- Toast Container -->
      <div id="healthToast" class="toast">
        <button class="toast-close" onclick="hideToast()">×</button>
        <div class="toast-header">
          <span class="toast-status"></span>
          <span>Health Status</span>
        </div>
        <div class="toast-content" id="toastContent">
          Loading...
        </div>
      </div>

      <script>
        const text = 'Hello World!';
        const element = document.getElementById('typewriter');
        let index = 0;

        function typeWriter() {
          if (index < text.length) {
            element.textContent += text.charAt(index);
            index++;
            setTimeout(typeWriter, 80);
          }
        }

        typeWriter();

        function formatUptime(seconds) {
          const hours = Math.floor(seconds / 3600);
          const minutes = Math.floor((seconds % 3600) / 60);
          const secs = Math.floor(seconds % 60);
          return hours + 'h ' + minutes + 'm ' + secs + 's';
        }

        function showToast() {
          const toast = document.getElementById('healthToast');
          toast.classList.add('show');
        }

        function hideToast() {
          const toast = document.getElementById('healthToast');
          toast.classList.remove('show');
        }

        function showHealthStatus() {
          showToast();

          // Fetch health data from API
          fetch('/api/health')
            .then(function(response) {
              return response.json();
            })
            .then(function(data) {
              const toastContent = document.getElementById('toastContent');
              var html = '';
              html += '<div class="toast-item">';
              html += '<span class="toast-label">Status</span>';
              html += '<span class="toast-value">' + data.status + '</span>';
              html += '</div>';
              html += '<div class="toast-item">';
              html += '<span class="toast-label">Uptime</span>';
              html += '<span class="toast-value">' + formatUptime(data.uptime) + '</span>';
              html += '</div>';
              html += '<div class="toast-item">';
              html += '<span class="toast-label">Version</span>';
              html += '<span class="toast-value">' + data.version + '</span>';
              html += '</div>';
              html += '<div class="toast-item">';
              html += '<span class="toast-label">Timestamp</span>';
              html += '<span class="toast-value">' + new Date(data.timestamp).toLocaleString() + '</span>';
              html += '</div>';
              toastContent.innerHTML = html;
            })
            .catch(function(error) {
              const toastContent = document.getElementById('toastContent');
              toastContent.innerHTML = '<div style="color: #ef4444;">Error loading health status</div>';
            });

          // Auto-hide after 5 seconds
          setTimeout(hideToast, 5000);
        }

        // Hide toast when clicking outside
        document.addEventListener('click', function(event) {
          const toast = document.getElementById('healthToast');
          const button = event.target.closest('.nav-link');

          if (!toast.contains(event.target) && !button) {
            hideToast();
          }
        });

        // Background animations
        const animatedBg = document.getElementById('animatedBg');

        // Create floating triangles
        function createFloatingTriangle() {
          const triangle = document.createElement('div');
          triangle.className = 'floating-triangle';
          triangle.style.left = Math.random() * window.innerWidth + 'px';
          triangle.style.animationDelay = Math.random() * 15 + 's';
          triangle.style.animationDuration = (15 + Math.random() * 10) + 's';
          animatedBg.appendChild(triangle);

          // Remove triangle after animation completes
          setTimeout(() => {
            triangle.remove();
          }, 25000);
        }

        // Create multiple triangles
        function createTriangles() {
          for (let i = 0; i < 8; i++) {
            setTimeout(() => {
              createFloatingTriangle();
            }, i * 2000);
          }
        }

        // Create particle system
        function createParticleSystem() {
          const canvas = document.createElement('canvas');
          canvas.style.position = 'absolute';
          canvas.style.top = '0';
          canvas.style.left = '0';
          canvas.style.width = '100%';
          canvas.style.height = '100%';
          canvas.style.pointerEvents = 'none';
          canvas.style.opacity = '0.5';
          animatedBg.appendChild(canvas);

          const ctx = canvas.getContext('2d');
          canvas.width = window.innerWidth;
          canvas.height = window.innerHeight;

          const particles = [];
          const particleCount = 50;

          class Particle {
            constructor() {
              this.x = Math.random() * canvas.width;
              this.y = Math.random() * canvas.height;
              this.vx = (Math.random() - 0.5) * 0.5;
              this.vy = (Math.random() - 0.5) * 0.5;
              this.radius = Math.random() * 2 + 1;
            }

            update() {
              this.x += this.vx;
              this.y += this.vy;

              if (this.x < 0 || this.x > canvas.width) this.vx *= -1;
              if (this.y < 0 || this.y > canvas.height) this.vy *= -1;
            }

            draw() {
              ctx.beginPath();
              ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
              ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
              ctx.fill();
            }
          }

          // Initialize particles
          for (let i = 0; i < particleCount; i++) {
            particles.push(new Particle());
          }

          function animate() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            // Draw and update particles
            particles.forEach(particle => {
              particle.update();
              particle.draw();
            });

            // Draw connections
            particles.forEach((particle1, i) => {
              particles.slice(i + 1).forEach(particle2 => {
                const dx = particle1.x - particle2.x;
                const dy = particle1.y - particle2.y;
                const distance = Math.sqrt(dx * dx + dy * dy);

                if (distance < 100) {
                  ctx.beginPath();
                  ctx.moveTo(particle1.x, particle1.y);
                  ctx.lineTo(particle2.x, particle2.y);
                  ctx.strokeStyle = 'rgba(255, 255, 255, ' + (0.2 * (1 - distance / 100)) + ')';
                  ctx.lineWidth = 0.5;
                  ctx.stroke();
                }
              });
            });

            requestAnimationFrame(animate);
          }

          animate();

          // Handle window resize
          window.addEventListener('resize', () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
          });
        }

        // Initialize animations
        createTriangles();
        createParticleSystem();

        // Continue creating triangles periodically
        setInterval(createFloatingTriangle, 3000);
      </script>
    </body>
    </html>
  `);
});

// Health API endpoint for toast
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    version: process.env.npm_package_version || '1.0.0'
  });
});

// API example endpoint
app.get('/api/info', (req, res) => {
  res.json({
    message: 'AniLaunchpad Node.js Template',
    version: '1.0.0',
    node: process.version,
    platform: process.platform,
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    env: process.env.NODE_ENV || 'development'
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    error: 'Not Found',
    path: req.path
  });
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    error: 'Internal Server Error',
    message: err.message
  });
});

// Start server
app.listen(port, '0.0.0.0', () => {
  console.log('[' + new Date().toISOString() + '] Server started');
  console.log('Port: ' + port);
  console.log('Environment: ' + (process.env.NODE_ENV || 'development'));
  console.log('Node.js: ' + process.version);
  console.log('Ready to accept connections');
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully');
  process.exit(0);
});
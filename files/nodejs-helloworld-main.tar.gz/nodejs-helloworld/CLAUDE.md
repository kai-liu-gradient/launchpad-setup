# Project Configuration

## Project Type
This is a Node.js web project using Express.js.

## Project Overview
- This is a **hello world demo project** that will evolve over time
- Future instructions may modify the project scope and features
- When updating the project, ensure the hello world index page is updated if necessary
- The project is intended to become a **multi-page, componentized application**
- Avoid putting all logic in a single `server.js` file; organize code into separate modules/components as the project grows

## Development Environment

### PM2 Process Manager
- The application runs via PM2 at **port 3000**
- Process name: `web`
- PM2 executes `npm start` which triggers nodemon for hot-reload
- Log files:
  - Output: `/var/log/pm2/web-out.log`
  - Errors: `/var/log/pm2/web-error.log`

### Useful PM2 Commands
```bash
pm2 list              # List all processes
pm2 logs web          # View logs for web process
pm2 restart web       # Restart the web process
pm2 show web          # Show detailed process info
```

### Nodemon Configuration
- Hot-reload enabled with nodemon watching for file changes
- Configuration file: `nodemon.json`
- Watches only `.js` and `.json` files in the source directory
- Ignores: `node_modules/`, test files, `.git/`, logs, and temporary files
- Delay: 1000ms (debounce to prevent excessive restarts)

## Entry Point
- Main file: `server.js`
